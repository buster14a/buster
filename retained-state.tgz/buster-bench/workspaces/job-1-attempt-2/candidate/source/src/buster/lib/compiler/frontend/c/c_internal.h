#pragma once

/*
 * Private implementation contract for the GNU C frontend.
 *
 * c.h is the public front door.  This header is intentionally private to the
 * three implementation translation units; it carries the shared runtime
 * includes and the linkage policy used when those units are built separately.
 * The unity aggregator includes the same header so the three files retain one
 * optimized translation unit in Release.
 */
#include <buster/lib/compiler/frontend/c/c.h>
#include <buster/lib/compiler/frontend/c/c_gen_internal.h>
#include <buster/lib/compiler/ir/ir.h>
#include <buster/lib/file.h>
#include <buster/lib/hash.h>
#include <buster/lib/integer.h>
#include <buster/lib/simd.h>
#include <buster/lib/string.h>

#if BUSTER_SIMD_512 && !defined(__BUSTER__)
#define BUSTER_C_LEX_COMPACT 1
#else
#define BUSTER_C_LEX_COMPACT 0
#endif

// The translator uses only the basic F/BW vocabulary. Compact lexing above
// still needs the full feature set and its remaining host-only intrinsics.
#define BUSTER_C_TRANSLATE_AVX512 BUSTER_SIMD_512_BASE

#if BUSTER_UNITY_BUILD
#define BUSTER_C_INTERNAL BUSTER_GLOBAL_LOCAL
#define BUSTER_C_SHARED BUSTER_GLOBAL_LOCAL
#define BUSTER_C_INLINE BUSTER_GLOBAL_LOCAL
#define BUSTER_C_EXTERN BUSTER_GLOBAL_LOCAL
#define BUSTER_C_DATA BUSTER_GLOBAL_LOCAL
#else
#define BUSTER_C_INTERNAL static
#define BUSTER_C_SHARED
#define BUSTER_C_INLINE static
#define BUSTER_C_EXTERN extern
#define BUSTER_C_DATA static
#endif

// The matching-delimiter scan, over the one-byte shape sidecar rather than the
// token rows.
//
// Every caller asks the same question: starting at `open` with depth zero,
// where does the depth return to zero. A shape byte answers it alone -- a
// punctuator's shape is C_TOKEN_SHAPE_PUNCTUATOR | its id -- so the scan reads
// one byte a token instead of reaching into a twelve-byte row for one field,
// and 64 tokens are classified at once: the openers and the closers of a
// window are two masks, and the walk then visits only the lanes that can
// change the depth. Delimiters are about one token in nine here, so eight
// tokens in nine are never looked at individually.
//
// The window skip is what makes a long range cheap: a window can only bring
// the depth to zero if it holds at least `depth` closers, so when it does not,
// the entire window costs two population counts and an add -- no per-token
// work at all, and no branch a scan of ordinary code can mispredict.
//
// **Lane accounting.** One masked load and two compares answer 64 tokens; the
// row scan they replace runs a byte load, a set test and a branch on each of
// them. Every lane of the load is useful (the sidecar is one byte a token and
// the range is contiguous), and both compares are 64 of 64, so the trade is
// positive on a double-pumped 256-bit datapath as well, not only on Zen 5's
// native width.
//
// **The 64-bit spelling of the same algorithm is measured negative and is not
// here.** A `-march=x86-64-v3` build of it -- eight tokens a step, the masks
// out of the classic byte-equality and movemask identities -- costs +13,8 M
// instructions against the row scan on the stage-1 workload, because the
// ranges are short (~16 tokens a query, ~1,4 M queries) and the per-query
// setup and per-window mask arithmetic outweigh a sixteen-iteration loop whose
// branch predicts. The width is the whole of the win: at 64 tokens a window
// the same query is one load and two compares, at eight it is two windows of
// arithmetic. Only the wide path is compiled.
#if BUSTER_C_LEX_COMPACT
#define C_SHAPE_DELIMITER_WINDOW 64u

BUSTER_GLOBAL_LOCAL BUSTER_UNUSED_DECL u32 c_shape_matching_delimiter(CTokenShape const* shapes, u32 open, u32 end, CPunctuator opening,
                                                                     CPunctuator closing)
{
    Simd512 open_lanes = simd512_splat((u8)(C_TOKEN_SHAPE_PUNCTUATOR | (u8)opening));
    Simd512 close_lanes = simd512_splat((u8)(C_TOKEN_SHAPE_PUNCTUATOR | (u8)closing));
    u32 depth = 0;
    for (u32 base = open; base < end; base += C_SHAPE_DELIMITER_WINDOW)
    {
        u32 remaining = end - base;
        u32 window_tokens = remaining < C_SHAPE_DELIMITER_WINDOW ? remaining : C_SHAPE_DELIMITER_WINDOW;
        // The window is read once and asked both questions. Lanes past the
        // range are masked off the load and read as C_TOKEN_INVALID, which no
        // punctuator shape can equal, so the tail needs no separate trim.
        Simd512 window = simd512_load_masked(shapes + base, mask64_prefix(window_tokens));
        Mask64 opens = simd512_equal_byte(window, open_lanes);
        Mask64 closes = simd512_equal_byte(window, close_lanes);
        u32 close_count = mask64_count(closes);
        if (depth > close_count)
        {
            depth += mask64_count(opens) - close_count;
            continue;
        }
        for (Mask64 pending = mask64_or(opens, closes); pending; pending &= pending - 1u)
        {
            u32 lane = mask64_first_set(pending);
            if ((opens >> lane) & 1u)
            {
                depth += 1;
            }
            else
            {
                if (!depth)
                {
                    return UINT32_MAX;
                }
                depth -= 1;
                if (!depth)
                {
                    return base + lane;
                }
            }
        }
    }
    return UINT32_MAX;
}
#endif

typedef struct CTypeParseMachine CTypeParseMachine;
typedef struct CIrDecodedString CIrDecodedString;
#define C_DECLARATION_KEYWORD_SLOT_COUNT 256

/* Source/preprocessor tables consumed by the parser's keyword classifier. */
BUSTER_C_EXTERN String8 const c_declaration_keyword_spellings[75];
BUSTER_C_EXTERN u8 c_declaration_keyword_slots[C_DECLARATION_KEYWORD_SLOT_COUNT];
BUSTER_C_EXTERN bool c_declaration_keyword_slots_built;
BUSTER_C_EXTERN void c_declaration_keyword_slots_build(void);
BUSTER_C_EXTERN u64 c_macro_name_hash(String8 name);
BUSTER_C_EXTERN bool c_preprocess_dialect_is_c23(CPreprocessDialect dialect);
BUSTER_C_EXTERN bool c_preprocess_dialect_is_gnu(CPreprocessDialect dialect);
// Integer spelling admission is shared with parsing and lowering. The reader
// consumes the complete bounded spelling and leaves value unchanged on failure.
BUSTER_C_EXTERN bool c_conditional_number(String8 spelling, u64* value);
BUSTER_C_EXTERN u32 c_integer_msvc_suffix_width(String8 suffix);
BUSTER_C_EXTERN u32 c_integer_msvc_literal_width(String8 spelling, bool* is_unsigned);
BUSTER_C_EXTERN bool c_number_is_float(String8 spelling);
BUSTER_C_EXTERN bool c_parse_auto_type_word(String8 spelling);
BUSTER_C_EXTERN bool c_parse_type_word_for_dialect(String8 spelling, CPreprocessDialect dialect);
BUSTER_C_EXTERN bool c_parse_alignof_word(String8 spelling);
BUSTER_C_EXTERN bool c_parse_alignas_word(String8 spelling);
// The GNU layout attributes the frontend implements, as the parser spells
// them. `__has_attribute` answers from these same predicates so the query
// cannot claim an attribute layout does not implement, or deny one it does
// (#639): packed and aligned reach layout through c_parse_layout_attributes,
// and vector_size reaches the vector types through C_TOKEN_CLASS_VECTOR_SIZE.
BUSTER_C_EXTERN bool c_parse_packed_word(String8 spelling);
BUSTER_C_EXTERN bool c_parse_aligned_attribute_word(String8 spelling);
BUSTER_C_EXTERN bool c_parse_vector_size_word(String8 spelling);
// Whether an alignment record was spelled `_Alignas` rather than as a GNU
// `aligned` attribute; see the definition for why the answer is read back out
// of the token stream instead of stored in the record.
BUSTER_C_EXTERN bool c_alignment_specifier_is_standard(CPreprocessResult preprocess, CAlignmentSpecifier specifier);
BUSTER_C_EXTERN u8 c_parse_token_class_compute(String8 spelling);
BUSTER_C_EXTERN bool c_ir_decode_character_value(Arena* arena, char8 const* spelling_base, CToken token, Target target,
                                                   u64* value_out, CTypeKind* kind_out);
BUSTER_C_EXTERN bool c_ir_tokens_are_string_literals(CPreprocessResult preprocess, u32 start, u32 end);
// Whether the statement at `index` is the substatement a control statement is
// waiting for. Shared by the named-label proof below and by the switch body
// scan, which must not split a case range at a label standing there.
BUSTER_C_EXTERN bool c_ir_control_substatement_position(CPreprocessResult const* preprocess, u32 body_start, u32 index);
// The cold half of c_ir_named_label_at: the full proof, reached only for a
// token that already looks like `<identifier> :`.
BUSTER_C_EXTERN bool c_ir_named_label_proven_at(CPreprocessResult const* preprocess, u32 body_start, u32 index, u32 body_end);
// Whether a named label starts at `index`. Both loops that size and fill a
// body's label table ask this of every body token, so the necessary condition
// — an identifier followed by a colon — is inline and the proof stays out of
// line: the answer is almost always no, and an out-of-line call per body
// token to reach it is the expensive part. The three range tests come first
// because they are what makes the two token reads in bounds.
BUSTER_GLOBAL_LOCAL BUSTER_UNUSED_DECL BUSTER_INLINE bool c_ir_named_label_at(CPreprocessResult const* preprocess, u32 body_start, u32 index,
                                                                             u32 body_end)
{
    return body_end <= preprocess->token_count && index < body_end && index + 1 < body_end &&
           preprocess->tokens[index].kind == C_TOKEN_IDENTIFIER && preprocess->tokens[index + 1].punctuator == C_PUNCTUATOR_COLON &&
           c_ir_named_label_proven_at(preprocess, body_start, index, body_end);
}
BUSTER_C_EXTERN bool c_ir_decode_string_literal_range_for_target(Arena* arena, CPreprocessResult preprocess, Target target,
                                                                  u32 start, u32 end, CIrDecodedString* decoded_out);
// The same answer without the bytes, for the callers that only size or type
// the literal; see the definition.
BUSTER_C_EXTERN bool c_ir_count_string_literal_range_for_target(Arena* arena, CPreprocessResult preprocess, Target target,
                                                                 u32 start, u32 end, CIrDecodedString* decoded_out);
BUSTER_C_EXTERN String8 c_ir_unsupported_gnu_construct(CPreprocessResult preprocess, u32 start, u32 end, u32* token_index_out);
BUSTER_C_EXTERN CTypeKind c_ir_primitive_type_kind(CPreprocessResult preprocess, u32 start, u32 end, u32* declarator_start,
                                                   u32* invalid_specifier);
BUSTER_C_EXTERN bool c_parse_type_name_start_word_token(CPreprocessResult preprocess, CToken token);
BUSTER_C_EXTERN u32 c_symbol_intern(CSymbolTable* table, String8 name);
BUSTER_C_EXTERN bool c_type_parse_buffer_size_add(u64* size, u64 count, u64 element_size, u64 alignment);
BUSTER_C_EXTERN void c_parse_declaration_type(CTypeParseMachine* machine, CParseResult* result, CPreprocessResult preprocess,
                                                CDeclaration* declaration, CTypeId inherited_base);
BUSTER_C_EXTERN bool c_parse_validate_constexpr_declaration(CTypeParseMachine* machine, Arena* arena, CParseResult* result,
                                                            CPreprocessResult preprocess, CDeclaration* declaration);
BUSTER_C_EXTERN CTypeId c_parse_add_type(CParseResult* result, CType type);
// Whether a call through this function type ends control flow because the
// declarator that derived it spelled `noreturn`. The set behind it is empty
// in almost every translation unit; see CParseResult.noreturn_function_types.
BUSTER_C_EXTERN bool c_parse_type_is_noreturn(CParseResult const* result, CTypeId type);
BUSTER_C_EXTERN bool c_parse_validate_constexpr_initializer(CTypeParseMachine* machine, Arena* arena, CParseResult* result,
                                                            CPreprocessResult preprocess, CScopeId scope, CEntityId entity_id,
                                                            u32 initializer_start, u32 initializer_end);
BUSTER_C_EXTERN void c_parse_infer_file_array_bounds(CTypeParseMachine* machine, Arena* arena,
                                                       CPreprocessResult preprocess, CParseResult* result);
typedef struct CIrWideInteger CIrWideInteger;
struct CIrWideInteger
{
    u64 low;
    u64 high;
};

BUSTER_C_EXTERN CIrWideInteger c_ir_wide_negate(CIrWideInteger value);
BUSTER_C_EXTERN bool c_ir_wide_less(CIrWideInteger left, CIrWideInteger right);
BUSTER_C_EXTERN CIrWideInteger c_ir_wide_subtract(CIrWideInteger left, CIrWideInteger right);
BUSTER_C_EXTERN CIrWideInteger c_ir_wide_multiply(CIrWideInteger left, CIrWideInteger right);
BUSTER_C_EXTERN void c_ir_wide_divide(CIrWideInteger dividend, CIrWideInteger divisor, CIrWideInteger* quotient_out, CIrWideInteger* remainder_out);

typedef struct CDeclarationBinding CDeclarationBinding;
struct CDeclarationBinding
{
    String8 alias_target;
    // IR_INITIALIZER_PRIORITY_NONE when the attribute named no priority; the
    // written value otherwise. Meaningful only while the matching flag is set,
    // because zero is a priority a program may write.
    u32 constructor_priority;
    u32 destructor_priority;
    bool is_weak;
    bool is_constructor;
    bool is_destructor;
    u8 reserved[5];
};

BUSTER_C_EXTERN bool c_ir_float_parse(String8 spelling, f64* value_out, char8* suffix_out);

BUSTER_C_EXTERN bool c_ir_declaration_initializer_range(CPreprocessResult preprocess, CDeclaration declaration, u32* start_out, u32* end_out);

BUSTER_C_EXTERN CDeclarationBinding c_declaration_binding(Arena* arena, CPreprocessResult preprocess, CDeclaration declaration);

BUSTER_C_EXTERN void c_parse_static_assert_check(CTypeParseMachine* machine, Arena* arena,
                                                  CPreprocessResult preprocess, CParseResult* result,
                                                  CDeclaration declaration, CScopeId scope);
BUSTER_C_EXTERN void c_parse_bind_function_body(CTypeParseMachine* machine, Arena* result_arena,
                                                 CParseResult* result, CPreprocessResult preprocess,
                                                 u32 declaration_index);
BUSTER_C_EXTERN void c_parse_validate_unattached_cleanup_attributes(CParseResult* result,
                                                                      CPreprocessResult preprocess);
BUSTER_C_EXTERN u64 c_parse_name_hash(u32 symbol, String8 name);
BUSTER_C_EXTERN u32 c_parse_name_symbol(CParseResult* result, String8 name);
BUSTER_C_EXTERN bool c_parse_types_compatible(Arena* result_arena, CParseResult* result, CPreprocessResult preprocess, CTypeId left, CTypeId right);
// `symbol` is the interned id of the entity's name when the creating site
// holds the declaring token, and 0 to have it interned here.
BUSTER_C_EXTERN void c_parse_scope_add_entity(CParseResult* result, CScopeId scope, CEntityId entity, u32 symbol);
BUSTER_C_EXTERN CTypeId c_parse_pointer_chain(CParseResult* result, CPreprocessResult preprocess, CTypeId base, u32* index, u32 end);
BUSTER_C_EXTERN bool c_parse_c23_attribute_at(CPreprocessResult preprocess, u32 index, u32 end, u32* after_out);
BUSTER_C_EXTERN u32 c_parse_skip_attributes(CPreprocessResult preprocess, u32 index, u32 end);
// The first token of `start .. end` past its last typeof operand group: a
// type name's own attributes follow that group, while the attributes inside
// it already shaped the operand's type.
BUSTER_C_EXTERN u32 c_parse_type_name_attribute_start(CPreprocessResult preprocess, u32 start, u32 end);
// The decimal or hexadecimal value of an attribute's integer argument, as it
// is spelled: `aligned(16)`, `constructor(101)`. False when the spelling is
// not one, which every caller reads as "the attribute named no argument".
BUSTER_C_EXTERN bool c_parse_attribute_unsigned(String8 spelling, u32* value_out);
BUSTER_C_EXTERN CTypeId c_parse_array_suffixes(CParseResult* result, CPreprocessResult preprocess, CTypeId element_type, u32* index, u32 end);
BUSTER_C_EXTERN CEntityId c_parse_lookup_entity(CParseResult* result, CScopeId scope, String8 name);
BUSTER_C_EXTERN CEntityId c_parse_lookup_typedef_name(CParseResult* result, String8 name, bool oldest);
// The token forms of the String8 lookups: the token's own interned id keys
// the probe, and only a symbol-0 token (pasted, synthesized, test-built)
// pays an intern of its spelling.
BUSTER_C_EXTERN CEntityId c_parse_lookup_typedef_name_token(CParseResult* result, char8 const* spelling_base, CToken token, bool oldest);
BUSTER_C_EXTERN CEntityId c_parse_lookup_typedef_name_fallback(CParseResult* result, String8 name);
BUSTER_C_EXTERN u32 c_parse_identifier_use_index(CParseResult* result, u32 token_index);
BUSTER_C_EXTERN CEntity* c_parse_first_constant_entity(CParseResult* result, String8 name);
BUSTER_C_EXTERN CEntity* c_parse_first_constant_entity_token(CParseResult* result, char8 const* spelling_base, CToken token);
BUSTER_C_EXTERN void c_parse_index_scope_children(CParseResult* result, Arena* arena);
BUSTER_C_EXTERN void c_parse_position_index_ensure(CParseResult* result, CPreprocessResult preprocess);
BUSTER_C_EXTERN CEntityId c_parse_lookup_entity_at(CParseResult* result, CPreprocessResult preprocess, CScopeId scope,
                                                    String8 name, u32 token_index);
BUSTER_C_EXTERN bool c_parse_result_reserve_types(CParseResult* result, u32 additional);
BUSTER_C_EXTERN CTypeId c_parse_aggregate_unique(CParseResult* result, CTypeKind kind, String8 tag, bool* decided);
#if BUSTER_INCLUDE_TESTS && BUSTER_BENCH_ALLOCATIONS
#define C_AGGREGATE_TAG_SEARCH_COUNT(lookup) do { if (lookup) { (lookup)->lowering_search_type_count += 1; } } while (0)
#else
#define C_AGGREGATE_TAG_SEARCH_COUNT(lookup) ((void)0)
#endif
BUSTER_C_EXTERN void c_type_parse_rollback(CTypeParseMachine* machine, CParseResult* result,
                                             CParseResult checkpoint, u32 mutation_mark);
BUSTER_C_EXTERN bool c_initializer_consume_separator(CToken* tokens, u32 limit, u32* cursor, u64 next_index);
BUSTER_C_EXTERN bool c_initializer_has_top_level_comma(CToken* tokens, u32 start, u32 end);
BUSTER_C_EXTERN CIRLowerResult c_lower_to_ir(Arena* arena, String8 source_path, CPreprocessResult preprocess,
                                              CAnalysisResult parse, Target target);
BUSTER_C_EXTERN CEntityId c_parse_lookup_entity_token(CParseResult* result, char8 const* spelling_base,
                                                       CScopeId scope, CToken const* token);
BUSTER_C_EXTERN CScopeId c_parse_scope_for_token(CParseResult* result, CScopeId root, u32 token_index);
BUSTER_C_EXTERN u32 c_parse_scope_distance(CParseResult* result, CScopeId candidate, CScopeId scope);
BUSTER_C_EXTERN u32 c_parse_definition_scan_start(CParseResult const* result, u32 definition_start);
// CDefinitionIndex diagnostic counts, kept out of ordinary compilers and timing
// builds and out of the canonical-construction census: parse-only runs
// construct no IR, and tests pin that their construction counters stay still.
#if BUSTER_INCLUDE_TESTS && BUSTER_BENCH_ALLOCATIONS
#define C_DEFINITION_INDEX_COUNT(index, field, amount) do { if (index) { (index)->field += (amount); } } while (0)
#else
#define C_DEFINITION_INDEX_COUNT(index, field, amount) ((void)0)
#endif
BUSTER_C_EXTERN bool c_token_spelling_equal(char8 const* spelling_base, CToken token, String8 spelling);
BUSTER_C_EXTERN bool c_parse_clone_incomplete_array_declarator(CTypeParseMachine* machine, CParseResult* result, CTypeId type, CTypeId* type_out);
BUSTER_C_EXTERN void c_parse_diagnostic(CParseResult* result, CSourceLocation location, CDiagnosticKind kind, String8 message);

// One language constraint, not a claim that an expression or translation unit
// has passed all semantic checks. These helpers use C bindings/types only;
// neither a canonical program nor a lowered function is an input.
typedef struct CCallArityDiagnostic CCallArityDiagnostic;
struct CCallArityDiagnostic
{
    String8 message;
    u32 token_index;
};
BUSTER_C_EXTERN bool c_semantic_call_accepts_arity(u32 parameter_count, bool is_variadic, bool is_unprototyped, u32 argument_count);
BUSTER_C_EXTERN String8 c_semantic_call_arity_message(Arena* arena, String8 name, u32 parameter_count, bool is_variadic, u32 argument_count);
BUSTER_C_EXTERN CCallArityDiagnostic c_semantic_check_named_call_arities(Arena* arena, CAnalysisResult* analysis,
                                                                      CPreprocessResult preprocess, u32 start, u32 end);
BUSTER_C_EXTERN bool c_parse_builtin_type_layout(Target target, CTypeKind kind, u64* size_out, u32* alignment_out);
// GNU vectors retain their written lane count while object size rounds to
// the next power of two. Alignment follows the target vector ABI.
BUSTER_C_EXTERN bool c_vector_type_layout(Target target, u64 element_size, u32 logical_byte_size, u64* element_count_out,
                                          u64* storage_size_out, u32* alignment_out);
// `_Atomic T`'s size and alignment, given T's own; both layout engines ask it
// (see c_atomic_promoted_layout in c_parse.c).
BUSTER_C_EXTERN void c_atomic_promoted_layout(u32 atomic_max_width, u64* size, u32* alignment);
BUSTER_C_EXTERN CTypeId c_parse_add_qualified_type(CParseResult* result, CTypeId base, CType qualifiers);
BUSTER_C_EXTERN bool c_parse_atomic_drops_type_alignment(CParseResult const* result, CTypeId base, bool adds_atomic);
BUSTER_C_EXTERN bool c_parse_type_qualifier_word(String8 spelling, CType* type);
BUSTER_C_EXTERN u32 c_preprocess_token_source(CPreprocessResult const* preprocess, CToken token, IrSourceMapCursor* cursor);
BUSTER_C_EXTERN CSourceLocation c_preprocess_token_location_cursor(CPreprocessResult const* preprocess, CToken token,
                                                                     IrSourceMapCursor* cursor);
BUSTER_C_EXTERN bool c_parse_label_address_prefix_with_typedef(CParseResult* result, CPreprocessResult const* preprocess,
                                                                 CScopeId scope, u32 expression_start, u32 index);
// The cold half of c_parse_label_address_prefix: the full proof, reached only
// for a token that is actually the `&&` a label address is spelled with.
BUSTER_C_EXTERN bool c_parse_label_address_prefix_proven(CPreprocessResult const* preprocess, u32 expression_start, u32 index);
// Whether `index` is the `&&` of a GNU label address. c_ir_unsupported_gnu_construct
// asks this of every token it scans, so the necessary condition is inline for
// the same reason as c_ir_named_label_at above.
BUSTER_GLOBAL_LOCAL BUSTER_UNUSED_DECL BUSTER_INLINE bool c_parse_label_address_prefix(CPreprocessResult const* preprocess, u32 expression_start,
                                                                                      u32 index)
{
    return index < preprocess->token_count && preprocess->tokens[index].punctuator == C_PUNCTUATOR_AMPERSAND_AMPERSAND &&
           c_parse_label_address_prefix_proven(preprocess, expression_start, index);
}
BUSTER_C_EXTERN bool c_parse_asm_goto_qualifier(CPreprocessResult preprocess, u32 start, u32 end);
BUSTER_C_EXTERN bool c_parse_type_start(CParseResult* result, CScopeId scope, String8 spelling, CPreprocessDialect dialect);
BUSTER_C_EXTERN bool c_parse_type_start_token(CParseResult* result, CPreprocessResult preprocess, CScopeId scope, CToken token);
typedef struct CSpellingSpace CSpellingSpace;
struct CSpellingSpace
{
    char8* base;
    u64 used;
    u64 capacity;
    Arena* arena;
};
BUSTER_C_EXTERN CSpellingSpace c_space_local(Arena* arena, u64 capacity);
// One compare, and deliberately no kind test: only a C_TOKEN_PUNCTUATOR token
// ever carries a punctuator id, so the id alone answers the question.  Every
// site that retypes a token must keep that invariant.
BUSTER_C_INLINE BUSTER_UNUSED_DECL BUSTER_INLINE bool c_token_is_punctuator(const CToken* token, CPunctuator punctuator)
{
    return token->punctuator == punctuator;
}

// Punctuator sets the frontend asks about repeatedly (see c_punctuator_in_set
// in c.h). The parenthesis pair is what the two backward scans that look for
// a control-statement head classify on; the statement-boundary set is the
// punctuators that can precede a labelled statement without further proof.
#define C_PUNCTUATOR_SET_PARENTHESES (C_PUNCTUATOR_BIT(C_PUNCTUATOR_LEFT_PARENTHESIS) | C_PUNCTUATOR_BIT(C_PUNCTUATOR_RIGHT_PARENTHESIS))
#define C_PUNCTUATOR_SET_STATEMENT_BOUNDARY                                                                                                    \
    (C_PUNCTUATOR_BIT(C_PUNCTUATOR_LEFT_BRACE) | C_PUNCTUATOR_BIT(C_PUNCTUATOR_RIGHT_BRACE) | C_PUNCTUATOR_BIT(C_PUNCTUATOR_SEMICOLON))
// The three nesting pairs a declarator scan tracks, split by side. Each side
// is three ids that are not adjacent in the enum — the pairs interleave — so
// a compare chain over one side does not fold into a range test the way the
// unary-operator chains do; these are the sets worth spelling as sets.
// Digraph spellings carry distinct ids and are absent here, exactly as the
// chains these replaced were written.
#define C_PUNCTUATOR_SET_DELIMITER_OPEN                                                                                                        \
    (C_PUNCTUATOR_BIT(C_PUNCTUATOR_LEFT_PARENTHESIS) | C_PUNCTUATOR_BIT(C_PUNCTUATOR_LEFT_BRACKET) | C_PUNCTUATOR_BIT(C_PUNCTUATOR_LEFT_BRACE))
#define C_PUNCTUATOR_SET_DELIMITER_CLOSE                                                                                                       \
    (C_PUNCTUATOR_BIT(C_PUNCTUATOR_RIGHT_PARENTHESIS) | C_PUNCTUATOR_BIT(C_PUNCTUATOR_RIGHT_BRACKET) |                                         \
     C_PUNCTUATOR_BIT(C_PUNCTUATOR_RIGHT_BRACE))
BUSTER_C_EXTERN u16 c_token_length_field(u64 length);
BUSTER_C_EXTERN CToken c_space_token(CSpellingSpace* space, String8 text, CTokenKind kind, CPunctuator punctuator);
BUSTER_C_EXTERN CToken c_space_retoken(CSpellingSpace* space, char8 const* from_base, CToken token);
BUSTER_C_EXTERN bool c_integer_expression_evaluate(Arena* arena, char8 const* spelling_base, CToken* tokens, u32 token_count, u32 expansion_limit,
                                                    CPreprocessResult* result, u64* value_out);

typedef struct CSymbolSlot CSymbolSlot;
typedef enum CSymbolBuiltin
{
    C_SYMBOL_BUILTIN_NONE,
    C_SYMBOL_BUILTIN_EXPECT,
    C_SYMBOL_BUILTIN_CONSTANT_P,
    C_SYMBOL_BUILTIN_CHOOSE_EXPR,
    C_SYMBOL_BUILTIN_TYPES_COMPATIBLE_P,
    C_SYMBOL_BUILTIN_OBJECT_SIZE,
    C_SYMBOL_BUILTIN_ASSUME_ALIGNED,
    C_SYMBOL_BUILTIN_DEBUGTRAP,
    C_SYMBOL_BUILTIN_SPIN_PAUSE,
    C_SYMBOL_BUILTIN_UNREACHABLE,
    C_SYMBOL_BUILTIN_STRLEN,
    C_SYMBOL_BUILTIN_CLEAR_CACHE,
    C_SYMBOL_BUILTIN_PREFETCH,
    C_SYMBOL_BUILTIN_VA_ARG,
    C_SYMBOL_BUILTIN_VA_START,
    C_SYMBOL_BUILTIN_VA_START_C23,
    C_SYMBOL_BUILTIN_VA_COPY,
    C_SYMBOL_BUILTIN_VA_END,
    C_SYMBOL_BUILTIN_GENERIC,
    C_SYMBOL_BUILTIN_ATOMIC,
    C_SYMBOL_BUILTIN_MATH,
    C_SYMBOL_BUILTIN_MEMORY,
    C_SYMBOL_BUILTIN_COUNT_LEADING_ZEROS,
    C_SYMBOL_BUILTIN_COUNT_TRAILING_ZEROS,
    C_SYMBOL_BUILTIN_FIND_FIRST_SET,
    C_SYMBOL_BUILTIN_POPULATION_COUNT,
    C_SYMBOL_BUILTIN_SIMD,
    C_SYMBOL_BUILTIN_SSE2_IMMEDIATE_SHIFT,
    C_SYMBOL_BUILTIN_FRAME_ADDRESS,
    C_SYMBOL_BUILTIN_ALLOCA,
    C_SYMBOL_BUILTIN_COMPLEX,
    C_SYMBOL_BUILTIN_COUNT,
} CSymbolBuiltin;
BUSTER_C_EXTERN CSymbolBuiltin c_symbol_builtin_from_spelling(String8 spelling);
BUSTER_C_EXTERN CTypeKind c_semantic_integer_count_parameter_kind(CSymbolBuiltin builtin, String8 spelling);

struct CSymbolTable
{
    Arena* arena;
    String8* names;
    CSymbolSlot* slots;
    u8* builtin_kinds;
    u8* class_bits;
    // Specifier-word facts per predefined id (C_WORD_* in c_parse.c), the
    // same dense shape as class_bits: every spelling any of the specifier
    // predicates can accept is interned into the predefined range at create
    // time, so `symbol > predefined_limit` is a constant-time "no" and the
    // id-keyed load replaces the spelling ladders for interned tokens.
    u16* word_bits;
    u32 predefined_limit;
    u32 slot_capacity;
    u32 name_capacity;
    u32 count;
};

// The names a pass compares an identifier token against by hand, and their
// interned ids. c_symbol_table_create interns this list first and in order,
// so an enumerator *is* the id its spelling was assigned: a comparison is
// `token.symbol == C_SYMBOL_WELL_KNOWN_FOR`, one immediate compare against a
// field the token already carries, in place of materializing the spelling
// through c_token_length's oversized guard and running string_equal.
// C_SYMBOL_WELL_KNOWN_NONE is 0 so it coincides with the uninterned marker,
// and the create-time BUSTER_CHECK holds the enum and the table together.
typedef enum CSymbolWellKnown
{
    C_SYMBOL_WELL_KNOWN_NONE,
    C_SYMBOL_WELL_KNOWN_CASE,
    C_SYMBOL_WELL_KNOWN_DEFAULT,
    C_SYMBOL_WELL_KNOWN_IF,
    C_SYMBOL_WELL_KNOWN_FOR,
    C_SYMBOL_WELL_KNOWN_WHILE,
    C_SYMBOL_WELL_KNOWN_SWITCH,
    C_SYMBOL_WELL_KNOWN_DO,
    C_SYMBOL_WELL_KNOWN_ELSE,
    C_SYMBOL_WELL_KNOWN_OVERLOADABLE,
    C_SYMBOL_WELL_KNOWN_STATIC_ASSERT,
    C_SYMBOL_WELL_KNOWN_BREAK,
    C_SYMBOL_WELL_KNOWN_CONTINUE,
    C_SYMBOL_WELL_KNOWN_GOTO,
    C_SYMBOL_WELL_KNOWN_RETURN,
    C_SYMBOL_WELL_KNOWN_TYPEDEF,
    C_SYMBOL_WELL_KNOWN_STRUCT,
    C_SYMBOL_WELL_KNOWN_UNION,
    C_SYMBOL_WELL_KNOWN_ENUM,
    C_SYMBOL_WELL_KNOWN_STATIC,
    C_SYMBOL_WELL_KNOWN_EXTERN,
    C_SYMBOL_WELL_KNOWN_THREAD_LOCAL,
    C_SYMBOL_WELL_KNOWN_THREAD_GNU,
    C_SYMBOL_WELL_KNOWN_ASM,
    C_SYMBOL_WELL_KNOWN_ASM_GNU,
    C_SYMBOL_WELL_KNOWN_ASM_GNU_ALT,
    C_SYMBOL_WELL_KNOWN_ATTRIBUTE,
    C_SYMBOL_WELL_KNOWN_ATTRIBUTE_SHORT,
    C_SYMBOL_WELL_KNOWN_SIZEOF,
    C_SYMBOL_WELL_KNOWN_ALIGNOF,
    C_SYMBOL_WELL_KNOWN_ALIGNOF_GNU,
    C_SYMBOL_WELL_KNOWN_ALIGNOF_GNU_ALT,
    C_SYMBOL_WELL_KNOWN_THREAD_LOCAL_C23,
    C_SYMBOL_WELL_KNOWN_INLINE,
    C_SYMBOL_WELL_KNOWN_INLINE_GNU,
    C_SYMBOL_WELL_KNOWN_INLINE_GNU_ALT,
    C_SYMBOL_WELL_KNOWN_SECTION,
    C_SYMBOL_WELL_KNOWN_SECTION_GNU,
    C_SYMBOL_WELL_KNOWN_WEAK,
    C_SYMBOL_WELL_KNOWN_WEAK_GNU,
    C_SYMBOL_WELL_KNOWN_ALIAS,
    C_SYMBOL_WELL_KNOWN_ALIAS_GNU,
    C_SYMBOL_WELL_KNOWN_CONSTRUCTOR,
    C_SYMBOL_WELL_KNOWN_CONSTRUCTOR_GNU,
    C_SYMBOL_WELL_KNOWN_DESTRUCTOR,
    C_SYMBOL_WELL_KNOWN_DESTRUCTOR_GNU,
    // The two decorations c_parse_skip_attributes steps over beside the
    // attribute spellings above; every specifier scan runs it once per
    // declaration, so the ladder it replaced ran on every identifier there.
    C_SYMBOL_WELL_KNOWN_EXTENSION,
    C_SYMBOL_WELL_KNOWN_DECLSPEC,
    C_SYMBOL_WELL_KNOWN_REGISTER,
    C_SYMBOL_WELL_KNOWN_BUILTIN_OFFSETOF,
    C_SYMBOL_WELL_KNOWN_VOLATILE,
    C_SYMBOL_WELL_KNOWN_VOLATILE_GNU_ALT,
    C_SYMBOL_WELL_KNOWN_CONSTEXPR,
    C_SYMBOL_WELL_KNOWN_CONST,
    C_SYMBOL_WELL_KNOWN_ATOMIC,
    C_SYMBOL_WELL_KNOWN_COUNT,
} CSymbolWellKnown;

// One well-known name as a set bit. The ids stay below 64 so any group of
// them is a u64 the membership test shifts by the token's own symbol,
// turning a ladder of spelling compares into one shift, one mask and one
// branch.
#define C_SYMBOL_WELL_KNOWN_BIT(name) (1ull << (u64)(C_SYMBOL_WELL_KNOWN_##name))
BUSTER_CT_CHECK(C_SYMBOL_WELL_KNOWN_COUNT <= 64);

// The binding walk and __has_attribute share these spelling sets. Keep the
// interned-token fast path: querying support must not add spelling comparisons
// to every declaration's binding scan (#666).
#define C_ATTRIBUTE_WORDS_WEAK (C_SYMBOL_WELL_KNOWN_BIT(WEAK) | C_SYMBOL_WELL_KNOWN_BIT(WEAK_GNU))
#define C_ATTRIBUTE_WORDS_ALIAS (C_SYMBOL_WELL_KNOWN_BIT(ALIAS) | C_SYMBOL_WELL_KNOWN_BIT(ALIAS_GNU))
#define C_ATTRIBUTE_WORDS_CONSTRUCTOR (C_SYMBOL_WELL_KNOWN_BIT(CONSTRUCTOR) | C_SYMBOL_WELL_KNOWN_BIT(CONSTRUCTOR_GNU))
#define C_ATTRIBUTE_WORDS_DESTRUCTOR (C_SYMBOL_WELL_KNOWN_BIT(DESTRUCTOR) | C_SYMBOL_WELL_KNOWN_BIT(DESTRUCTOR_GNU))

// _Noreturn is a declaration specifier, not a GNU attribute query spelling.
BUSTER_C_INLINE BUSTER_UNUSED_DECL BUSTER_INLINE bool c_attribute_noreturn_word(String8 spelling)
{
    return string_equal(spelling, S8("noreturn")) || string_equal(spelling, S8("__noreturn__"));
}

// Only the native object pipeline carries symbol aliases and initializer
// arrays. Core Wasm and eBPF have neither lifecycle registration mechanism.
BUSTER_C_INLINE BUSTER_UNUSED_DECL BUSTER_INLINE bool c_attribute_native_binding_target(Target target)
{
    return target.cpu_arch == CPU_ARCH_X86_64 || target.cpu_arch == CPU_ARCH_AARCH64;
}

// Index 0 is the empty spelling that C_SYMBOL_WELL_KNOWN_NONE never matches.
BUSTER_C_EXTERN String8 const c_symbol_well_known_spellings[C_SYMBOL_WELL_KNOWN_COUNT];

// Is this identifier token spelled `well_known`?  Interned tokens — every
// token the preprocessor produced — settle on the integer compare. Symbol 0
// marks a token that never passed the intern pass (pasted, synthesized, or
// test-built) and falls back to the spelling, so a missed path costs speed
// and never correctness. Both sides read the one spelling table, so the id
// and the fallback spelling cannot drift apart.
BUSTER_C_INLINE BUSTER_UNUSED_DECL BUSTER_INLINE bool c_token_is_well_known(char8 const* spelling_base, CToken token, CSymbolWellKnown well_known)
{
    return token.symbol ? token.symbol == (u32)well_known
                        : string_equal(c_token_spelling(spelling_base, token), c_symbol_well_known_spellings[well_known]);
}

// Is this identifier token spelled as any member of `set`, a union of
// C_SYMBOL_WELL_KNOWN_BIT values?  The interned answer is a shift and a mask
// whatever the set's size; the uninterned fallback walks the set bits and
// compares spellings, which is the same ladder the call sites used to write
// out by hand and runs only for tokens the intern pass never saw.
BUSTER_C_INLINE BUSTER_UNUSED_DECL BUSTER_INLINE bool c_token_in_well_known_set(char8 const* spelling_base, CToken token, u64 set)
{
    bool result;
    if (token.symbol)
    {
        result = token.symbol < 64 && ((set >> token.symbol) & 1);
    }
    else
    {
        String8 spelling = c_token_spelling(spelling_base, token);
        result = false;
        for (u64 remaining = set; remaining && !result; remaining &= remaining - 1)
        {
            result = string_equal(spelling, c_symbol_well_known_spellings[trailing_zeroes_u64(remaining)]);
        }
    }
    return result;
}

// The member of `set` this identifier token spells, as its
// C_SYMBOL_WELL_KNOWN_BIT, or 0 when it spells none: the membership test
// that also says which name matched, for a specifier scan that folds several
// flags out of one pass and reads them off the accumulated bits afterwards.
// The interned answer is a shift and a mask; the uninterned fallback walks
// the set bits the way c_token_in_well_known_set does.
BUSTER_C_INLINE BUSTER_UNUSED_DECL BUSTER_INLINE u64 c_token_well_known_bit(char8 const* spelling_base, CToken token, u64 set)
{
    u64 result;
    if (token.symbol)
    {
        result = token.symbol < 64 ? set & (1ull << token.symbol) : 0;
    }
    else
    {
        String8 spelling = c_token_spelling(spelling_base, token);
        result = 0;
        for (u64 remaining = set; remaining && !result; remaining &= remaining - 1)
        {
            if (string_equal(spelling, c_symbol_well_known_spellings[trailing_zeroes_u64(remaining)]))
            {
                result = remaining & (0 - remaining);
            }
        }
    }
    return result;
}

typedef enum CConditionalOperator
{
    C_CONDITIONAL_OPEN,
    C_CONDITIONAL_INDEX_OPEN,
    C_CONDITIONAL_UNARY_PLUS,
    C_CONDITIONAL_UNARY_MINUS,
    C_CONDITIONAL_LOGICAL_NOT,
    C_CONDITIONAL_BITWISE_NOT,
    // GNU `__real__` and `__imag__`. They are prefix unary operators spelled
    // as identifiers, so the expression walker recognizes them itself instead
    // of through c_conditional_operator, which only classifies punctuators.
    C_CONDITIONAL_REAL_PART,
    C_CONDITIONAL_IMAGINARY_PART,
    C_CONDITIONAL_ADDRESS_OF,
    C_CONDITIONAL_DEREFERENCE,
    C_CONDITIONAL_CAST,
    C_CONDITIONAL_MULTIPLY,
    C_CONDITIONAL_DIVIDE,
    C_CONDITIONAL_REMAINDER,
    C_CONDITIONAL_ADD,
    C_CONDITIONAL_SUBTRACT,
    C_CONDITIONAL_SHIFT_LEFT,
    C_CONDITIONAL_SHIFT_RIGHT,
    C_CONDITIONAL_LESS,
    C_CONDITIONAL_LESS_EQUAL,
    C_CONDITIONAL_GREATER,
    C_CONDITIONAL_GREATER_EQUAL,
    C_CONDITIONAL_EQUAL,
    C_CONDITIONAL_NOT_EQUAL,
    C_CONDITIONAL_BITWISE_AND,
    C_CONDITIONAL_BITWISE_XOR,
    C_CONDITIONAL_BITWISE_OR,
    C_CONDITIONAL_LOGICAL_AND,
    C_CONDITIONAL_LOGICAL_OR,
    C_CONDITIONAL_QUESTION,
    C_CONDITIONAL_SELECT,
    C_CONDITIONAL_COMMA,
    C_CONDITIONAL_OPERATOR_COUNT,
} CConditionalOperator;
BUSTER_C_EXTERN u32 c_conditional_precedence(CConditionalOperator operation);
BUSTER_C_EXTERN bool c_conditional_is_unary(CConditionalOperator operation);
BUSTER_C_EXTERN bool c_conditional_operator(CToken token, bool unary, CConditionalOperator* operation);
typedef enum CIrStringEncoding
{
    C_IR_STRING_ENCODING_ORDINARY,
    C_IR_STRING_ENCODING_UTF8,
    C_IR_STRING_ENCODING_UTF16,
    C_IR_STRING_ENCODING_UTF32,
    C_IR_STRING_ENCODING_WIDE,
} CIrStringEncoding;

struct CIrDecodedString
{
    ByteSlice bytes;
    u64 element_count;
    u32 element_width;
    CTypeKind element_kind;
    CIrStringEncoding encoding;
};

typedef struct CTypeParseFrame CTypeParseFrame;
typedef struct CTypeMutation CTypeMutation;
typedef struct CParseExpressionTypeTask CParseExpressionTypeTask;
typedef struct CParsePromotedMemberWork CParsePromotedMemberWork;

typedef enum CParseExpressionTypeOperation
{
    C_PARSE_EXPRESSION_TYPE_NONE,
    C_PARSE_EXPRESSION_TYPE_COMMA,
    C_PARSE_EXPRESSION_TYPE_ASSIGN,
    C_PARSE_EXPRESSION_TYPE_ARITHMETIC,
    C_PARSE_EXPRESSION_TYPE_SHIFT,
    C_PARSE_EXPRESSION_TYPE_COMPARE,
    C_PARSE_EXPRESSION_TYPE_CONDITIONAL,
    C_PARSE_EXPRESSION_TYPE_UNARY,
    C_PARSE_EXPRESSION_TYPE_UPDATE,
    C_PARSE_EXPRESSION_TYPE_LOGICAL_NOT,
    C_PARSE_EXPRESSION_TYPE_INDIRECTION,
    C_PARSE_EXPRESSION_TYPE_ADDRESS_OF,
    C_PARSE_EXPRESSION_TYPE_COMPLEX_PART,
} CParseExpressionTypeOperation;

typedef enum CTypeParseFrameKind
{
    C_TYPE_PARSE_FRAME_SCALAR,
    C_TYPE_PARSE_FRAME_CORE,
    C_TYPE_PARSE_FRAME_SIZEOF,
    C_TYPE_PARSE_FRAME_EXPRESSION_LEAF,
    C_TYPE_PARSE_FRAME_ALIGNMENT,
    C_TYPE_PARSE_FRAME_AGGREGATE_SEGMENT,
    C_TYPE_PARSE_FRAME_AGGREGATE_RANGE,
    C_TYPE_PARSE_FRAME_PARENTHESIZED,
    C_TYPE_PARSE_FRAME_PARAMETER,
} CTypeParseFrameKind;

typedef enum CTypeParseFrameStage
{
    C_TYPE_PARSE_STAGE_BEGIN,
    C_TYPE_PARSE_STAGE_CHILD,
    C_TYPE_PARSE_STAGE_FALLBACK,
    C_TYPE_PARSE_STAGE_PARAMETERS,
    C_TYPE_PARSE_STAGE_PARAMETER_RESULT,
    C_TYPE_PARSE_STAGE_FINISH,
} CTypeParseFrameStage;

struct CTypeMutation
{
    CTypeId id;
    CType previous;
};

struct CParseExpressionTypeTask
{
    u32 start;
    u32 end;
    u32 split;
    u32 colon;
    CTypeId left_type;
    CParseExpressionTypeOperation operation;
    u8 state;
    // A unary child reuses the top-level operator scan until a group opens.
    bool operators_checked;
    u8 reserved[2];
};

struct CTypeParseFrame
{
    CParseResult* result;
    CParseResult checkpoint;
    CPreprocessResult preprocess;
    Arena* arena;
    CParseExpressionTypeTask* expression_tasks;
    CType qualifiers;
    CType original_type;
    CTypeId type;
    CTypeId base_type;
    CTypeId original_type_id;
    CToken name;
    CToken first;
    CScopeId scope;
    u32 start;
    u32 end;
    u32 index;
    u32 close;
    u32 specifier_index;
    u32 declarator_start;
    u32 declarator_end;
    u32 name_index;
    u32 close_index;
    u32 pointer_start;
    u32 parameter_start;
    u32 written_parameter_count;
    // A parenthesized declarator whose name carries its own parameter list --
    // `void (*getf(int))(void)` -- is a function returning the pointer, so its
    // list is scanned before the outer suffix and the range kept here until
    // the return type is complete.
    u32 inner_parameter_start;
    u32 inner_parameter_count;
    u32 inner_open;
    u32 inner_close;
    // A declarator group may hold another one -- `void (*(*sym)(int))(void)`
    // -- and then this frame owns only the outer suffix and pointer chain,
    // with the group starting here parsed by a child frame over the type they
    // produce.
    u32 nested_start;
    u32 segment_start;
    u32 scan_index;
    u32 depth;
    u32 task_count;
    u32 task_capacity;
    u32 task_mark;
    u32 alignment_start;
    u32 alignment_count;
    // An aggregate segment declares a comma-separated member list over one set
    // of declaration specifiers, and this is where those specifiers end -- the
    // start of the leading declarator.  A marker before it belongs to every
    // member of the list; a marker past it belongs to the one declarator whose
    // own range holds it.
    u32 shared_specifier_end;
    u32 mutation_mark;
    u32 definition_type_start;
    u32 pending_index;
    u64 arena_mark;
    CTypeParseFrameKind kind;
    CTypeParseFrameStage stage;
    bool unqualified;
    bool has_name;
    bool variadic;
    bool has_function_suffix;
    bool original_type_valid;
    bool is_bit_field;
    bool tag_only_declaration;
    bool scanning_inner_parameters;
    bool has_inner_parameters;
    bool inner_variadic;
    bool inner_unprototyped;
    bool nested;
    // A GNU `packed` attribute among the specifiers this segment's declarator
    // list shares. Every member the segment declares takes it; a `packed` a
    // single declarator carries is scanned separately and belongs to that
    // member alone.
    bool is_packed;
};

typedef struct CTypeLayoutCache CTypeLayoutCache;
struct CTypeLayoutCache
{
    u64* sizes;
    u32* alignments;
    u8* states;
    // Every type id whose layout is not committed in `states`, which is the
    // set c_parse_type_layout's seed, solve and commit passes have anything
    // to do for.  Without it each of those three passes walked the whole
    // type table -- 32.141 ids on average for the 39 uncached queries of a
    // stage-1 compile of this tree, for the ~6.200 that were still open.
    // `pending_mark` keeps the list free of duplicates when a record
    // mutation drops an id back onto it, and `pending_seeded` is the
    // high-water mark of ids ever listed, so a query only has to list the
    // types added since the last one.
    u32* pending;
    u8* pending_mark;
    u32 pending_count;
    u32 pending_seeded;
    u32 capacity;
    CToken const* tokens;
};

// Successful expression facts are reused only after all bindings are final,
// within one function. Scope, token end and checking mode are part of the key;
// failed/speculative queries and queries over copied models are never stored.
#define C_PARSE_EXPRESSION_QUERY_VALID 1u
#define C_PARSE_EXPRESSION_QUERY_CHECKED 2u
#define C_PARSE_EXPRESSION_QUERY_RUNTIME 4u
#define C_PARSE_EXPRESSION_QUERY_CONSTANT 8u

typedef struct CParseExpressionQuery CParseExpressionQuery;
struct CParseExpressionQuery
{
    u32 end;
    CScopeId scope;
    CTypeId type;
    u32 flags;
};

struct CTypeParseMachine
{
    CParseExpressionQuery* expression_queries;
    CParseResult* expression_query_result;
    CToken const* expression_query_tokens;
    u32 expression_query_start;
    u32 expression_query_end;
    CTypeParseFrame* frames;
    CTypeMutation* mutations;
    CParseExpressionTypeTask* expression_tasks;
    CTypeId* incomplete_array_chain;
    u32 incomplete_array_chain_capacity;
    Arena* scratch_arena;
    CTypeLayoutCache layout_cache;
    CParsePromotedMemberWork* promoted_member_work;
    u32* promoted_member_visited;
    u32 promoted_member_capacity;
    u32 promoted_member_generation;
    CTypeId result_type;
    u32 result_index;
    u32 frame_count;
    u32 frame_capacity;
    u32 mutation_count;
    u32 mutation_capacity;
    u32 mutation_type_limit;
    u32 expression_task_count;
    u32 expression_task_capacity;
    // The enum currently evaluating an explicit initializer. Earlier members
    // are visible before ordinary entity publication; the start bounds lookup
    // to this definition so an unrelated enum cannot satisfy an identifier.
    u32 enum_constant_member_start;
    bool result_valid;
    bool failed;
    bool semantic_constant_queries;
    bool validate_expression_constraints;
    bool runtime_expression_constraints;
    bool enum_constant_members_active;
    String8 expression_constraint;
    u32 expression_constraint_token;
};

struct CParsePromotedMemberWork
{
    CTypeId type;
    u32 root_field;
    u32 depth;
};

BUSTER_C_EXTERN bool c_semantic_asm_clobber_valid(Target target, String8 clobber);
BUSTER_C_EXTERN bool c_semantic_asm_clobber_matches_constraint(Target target, String8 clobber, u64 constraint);

BUSTER_C_EXTERN void c_parse_index_declarations(CParseResult* result, Arena* arena);

typedef enum CIrConstantValueKind
{
    C_IR_CONSTANT_INVALID,
    C_IR_CONSTANT_UNKNOWN,
    C_IR_CONSTANT_INTEGER,
    C_IR_CONSTANT_FLOAT,
    C_IR_CONSTANT_POINTER,
    C_IR_CONSTANT_LVALUE,
} CIrConstantValueKind;

typedef struct CIrConstantValue CIrConstantValue;
struct CIrConstantValue
{
    IrTypeId type;
    IrSymbolId symbol;
    s64 addend;
    // Integer values, or the target raw image of a wide floating constant.
    // Narrow floating constants alone use the f64 carrier below.
    u64 integer;
    u64 integer_high;
    f64 floating;
    CIrConstantValueKind kind;
};

BUSTER_C_EXTERN bool c_ir_scalar_type_properties(Target target, CTypeKind kind, IrTypeKind* ir_kind, u32* bit_width, bool* is_signed, u32* alignment);
BUSTER_C_EXTERN bool c_ir_constant_wide_float_cast(CIrConstantValue const* source, IrType* source_type,
                                                     IrType const* target, CIrConstantValue* result);
BUSTER_C_EXTERN bool c_ir_constant_wide_float_to_integer(CIrConstantValue const* source, IrType const* source_type,
                                                           IrType const* target, CIrWideInteger* result);
BUSTER_C_EXTERN void c_ir_constant_wide_float_sign(CIrConstantValue* value, IrType const* type, bool negative);
BUSTER_C_EXTERN bool c_ir_constant_float_to_integer(f64 floating, IrType* target, CIrWideInteger* result);
BUSTER_C_EXTERN f64 c_ir_float16_round(f64 value);
BUSTER_C_EXTERN f64 c_ir_bfloat16_round(f64 value);
BUSTER_C_EXTERN bool c_ir_constant_float_literal_for_type(IrType const* type, String8 spelling, CIrConstantValue* result);
BUSTER_C_EXTERN bool c_ir_constant_wide_float_binary(IrTypeId integer_type, CConditionalOperator operation, CIrConstantValue left, CIrConstantValue right, IrType const* type, CIrConstantValue* result);

typedef enum CIrAtomicBuiltin
{
    C_IR_ATOMIC_BUILTIN_LOAD,
    C_IR_ATOMIC_BUILTIN_STORE,
    C_IR_ATOMIC_BUILTIN_INIT,
    C_IR_ATOMIC_BUILTIN_FETCH_ADD,
    C_IR_ATOMIC_BUILTIN_FETCH_SUBTRACT,
    C_IR_ATOMIC_BUILTIN_FETCH_AND,
    C_IR_ATOMIC_BUILTIN_FETCH_OR,
    C_IR_ATOMIC_BUILTIN_FETCH_XOR,
    C_IR_ATOMIC_BUILTIN_FETCH_NAND,
    C_IR_ATOMIC_BUILTIN_EXCHANGE,
    C_IR_ATOMIC_BUILTIN_COMPARE_EXCHANGE_STRONG,
    C_IR_ATOMIC_BUILTIN_COMPARE_EXCHANGE_WEAK,
    C_IR_ATOMIC_BUILTIN_THREAD_FENCE,
    C_IR_ATOMIC_BUILTIN_SIGNAL_FENCE,
    // GCC's legacy full barrier, which takes no ordering argument because it
    // is always sequentially consistent.
    C_IR_ATOMIC_BUILTIN_SYNC_SYNCHRONIZE,
    C_IR_ATOMIC_BUILTIN_IS_LOCK_FREE,
    // GNU-only: an exchange of one into a byte-sized flag reported as a
    // boolean, and the store of zero that releases it again.
    C_IR_ATOMIC_BUILTIN_TEST_AND_SET,
    C_IR_ATOMIC_BUILTIN_CLEAR,
    C_IR_ATOMIC_BUILTIN_COUNT,
} CIrAtomicBuiltin;


typedef struct CIrAtomicBuiltinSpelling CIrAtomicBuiltinSpelling;
struct CIrAtomicBuiltinSpelling
{
    CIrAtomicBuiltin builtin;
    bool gnu;
    bool new_value;
    bool generic;
    bool sequential;
};

BUSTER_C_EXTERN CIrAtomicBuiltinSpelling c_ir_atomic_builtin_spelling(String8 name);
BUSTER_C_EXTERN u32 c_semantic_atomic_builtin_arity(CIrAtomicBuiltinSpelling spelling);
BUSTER_C_EXTERN CTypeKind c_semantic_integer_literal_kind(Target target, u64 const* limits, String8 spelling, u64 value);
BUSTER_C_EXTERN bool c_semantic_ext80_fold_initializer(Arena* arena, CPreprocessResult preprocess, u32 start, u32 end, u64* significand_out, u16* exponent_sign_out, String8* message, u32* location);

BUSTER_C_EXTERN u32 c_semantic_asm_type_class(IrType* type);

BUSTER_C_EXTERN bool c_semantic_asm_vector_operand(IrType* type);

BUSTER_C_EXTERN bool c_semantic_asm_x87_operand(IrType* type);

BUSTER_C_EXTERN bool c_semantic_asm_decimal_reference(String8 bytes, u32* index_out);

BUSTER_C_EXTERN u64 c_semantic_asm_bound_register(Target target, String8 label);

BUSTER_C_EXTERN bool c_semantic_asm_fixed_operands_conflict(u64 const* constraints, u32 count);

BUSTER_C_EXTERN String8 c_semantic_asm_x87_operands_message(u64 const* constraints, u32 count, bool stack_clobber);

BUSTER_C_EXTERN String8 c_ir_math_builtin_link_name(String8 name);

typedef enum CIrSimdArgument
{
    C_IR_SIMD_ARGUMENT_ADDRESS,
    C_IR_SIMD_ARGUMENT_MASK,
    C_IR_SIMD_ARGUMENT_VECTOR,
    C_IR_SIMD_ARGUMENT_BYTE,
    C_IR_SIMD_ARGUMENT_WORD,
    C_IR_SIMD_ARGUMENT_IMMEDIATE,
} CIrSimdArgument;

typedef struct CIrSimdBuiltin CIrSimdBuiltin;
struct CIrSimdBuiltin
{
    String8 name;
    u8 operation;
    u8 arguments[4];
    u32 immediate_limit;
};

// The whole vocabulary, in one table. An immediate is always last, so lowering
// walks the operands in order and evaluates the tail constant afterwards.

BUSTER_C_EXTERN bool c_semantic_simd_builtin(String8 name, CIrSimdBuiltin* entry);

typedef struct CSemanticAsmOperand CSemanticAsmOperand;
struct CSemanticAsmOperand
{
    String8 name;
    u64 size;
    u32 type_class;
};

BUSTER_C_EXTERN String8 c_semantic_asm_special_operands_message(Target target, String8 assembly, u64 const* constraints,
    CSemanticAsmOperand const* operands, u32 operand_count, u32 output_count, bool rbx_clobber);

typedef struct CIrSse2ImmediateShiftBuiltin CIrSse2ImmediateShiftBuiltin;
struct CIrSse2ImmediateShiftBuiltin
{
    String8 name;
    IrBinaryOperation operation;
    u8 lane_width;
    u8 lane_count;
    u8 reserved[2];
};

BUSTER_C_EXTERN bool c_semantic_sse2_immediate_shift_builtin(String8 name, CIrSse2ImmediateShiftBuiltin* entry);
