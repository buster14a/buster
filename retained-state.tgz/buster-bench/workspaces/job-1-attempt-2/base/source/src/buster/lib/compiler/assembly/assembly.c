// The standalone textual assembler: assembly_encode at the bottom takes
// x86-64 (AT&T or Intel) or AArch64 source and returns encoded bytes,
// symbols, relocations, and diagnostics. Two phases over an
// AssemblyBuilder sized from the line count: assembly_source_parse turns
// each statement into an AssemblyInstruction — labels, directives,
// expressions, and operands resolved — and assembly_instructions_emit
// sizes and encodes them, laying out symbols and relocations and
// range-checking branches. Unknown or malformed input is a diagnostic,
// never a guess.
//
// Instruction knowledge is table-driven, not hand-coded per mnemonic: x86
// selection and encoding go through the generated metadata
// (assembly_x86_metadata_select_source_form, x86_64_metadata.h), with the
// assembly_x86_instruction_size/encode paths retaining preliminary size and
// legality checks for many families, including EVEX/APX. LEA and the scalar
// MOVZX/MOVSX/MOVSXD family derive their lengths from metadata selection.
// AArch64 uses the generated
// syntax/semantic tables and compact architectural front doors such as the
// scalar GPR memory family, all encoded through aarch64_encoding.h.
//
// Layout, in file order; each anchor is a definition to search for:
//   assembly_space .. assembly_symbol_intern       builder plumbing, labels,
//                                                  symbol interning
//   assembly_expression_parse,                     constant/symbol expression
//   assembly_expression_merge                      evaluation
//   assembly_register_parse,                       operand parsing for both
//   assembly_x86_memory_parse_intel                dialects and both targets
//   assembly_aarch64_*                             AArch64 operand forms,
//                                                  system registers, SIMD
//                                                  spellings, row selection
//   assembly_x86_vector_form ..                    x86 form classification
//   assembly_x86_instruction_size                  and instruction sizing/
//                                                  encoding
//   assembly_x86_metadata_*                        metadata-driven selection
//                                                  and emission
//   assembly_instruction_parse,                    statement recognition and
//   assembly_source_parse                          the parse phase driver
//   assembly_relocation_append,                    the emit phase and the
//   assembly_instructions_emit, assembly_encode    public entry point

#include <buster/lib/compiler/assembly/assembly.h>
#include <buster/lib/compiler/assembly/aarch64_encoding.h>
#include <buster/lib/compiler/assembly/aarch64_direct_simd_semantics.h>
#include <buster/lib/compiler/assembly/aarch64_control_semantics.h>
#include <buster/lib/compiler/assembly/generated/aarch64-form-ids.generated.h>
#include <buster/lib/compiler/assembly/aarch64_system_semantics.h>
#include <buster/lib/compiler/assembly/aarch64_system_registers.h>
#include <buster/lib/compiler/assembly/aarch64_syntax.h>
#include <buster/lib/compiler/assembly/x86_64_metadata.h>

#include <buster/lib/string.h>

// Shared executable-section padding for source alignment and generated
// function entry alignment. Explicit source fill operands are data and never
// call this helper. AArch64 partial words retain #228's zero-fragment policy.
bool assembly_fill_executable_padding(Target target, u8* output, u64 offset, u64 count)
{
    bool result = false;
    if (!count)
    {
        result = true;
    }
    else if (output && offset <= UINT64_MAX - count)
    {
        if (target.cpu_arch == CPU_ARCH_X86_64)
        {
            result = buster_x86_metadata_fill_nops(output, count);
        }
        else if (target.cpu_arch == CPU_ARCH_AARCH64)
        {
            A64MCInst instruction = {.opcode = A64_OPCODE_NOP};
            u32 word = 0;
            if (a64_mc_encode(&instruction, &word))
            {
                u64 prefix = BUSTER_MIN(count, (4 - (offset & 3)) & 3);
                u64 whole = (count - prefix) & ~(u64)3;
                memset(output, 0, prefix);
                if (whole)
                {
                    for (u32 byte = 0; byte < 4; byte += 1) output[prefix + byte] = (u8)(word >> (byte * 8));
                    // Geometrically copy a derived complete-word pattern.
                    // This preserves a bulk path without another ISA table.
                    u64 filled = 4;
                    while (filled < whole)
                    {
                        u64 copied = BUSTER_MIN(filled, whole - filled);
                        memcpy(output + prefix + filled, output + prefix, copied);
                        filled += copied;
                    }
                }
                memset(output + prefix + whole, 0, count - prefix - whole);
                result = true;
            }
        }
    }
    return result;
}

typedef enum AssemblyOpcode
{
    ASSEMBLY_OPCODE_X86_NOP,
    ASSEMBLY_OPCODE_X86_RET,
    ASSEMBLY_OPCODE_X86_INT3,
    ASSEMBLY_OPCODE_X86_CALL,
    ASSEMBLY_OPCODE_X86_JMP,
    ASSEMBLY_OPCODE_X86_MOV,
    ASSEMBLY_OPCODE_X86_ADD,
    ASSEMBLY_OPCODE_X86_ADC,
    ASSEMBLY_OPCODE_X86_SUB,
    ASSEMBLY_OPCODE_X86_SBB,
    ASSEMBLY_OPCODE_X86_AND,
    ASSEMBLY_OPCODE_X86_OR,
    ASSEMBLY_OPCODE_X86_XOR,
    ASSEMBLY_OPCODE_X86_CMP,
    ASSEMBLY_OPCODE_X86_TEST,
    ASSEMBLY_OPCODE_X86_IMUL,
    ASSEMBLY_OPCODE_X86_MUL,
    ASSEMBLY_OPCODE_X86_DIV,
    ASSEMBLY_OPCODE_X86_IDIV,
    ASSEMBLY_OPCODE_X86_PUSH,
    ASSEMBLY_OPCODE_X86_POP,
    ASSEMBLY_OPCODE_X86_INC,
    ASSEMBLY_OPCODE_X86_DEC,
    ASSEMBLY_OPCODE_X86_NEG,
    ASSEMBLY_OPCODE_X86_NOT,
    ASSEMBLY_OPCODE_X86_SHL,
    ASSEMBLY_OPCODE_X86_SHR,
    ASSEMBLY_OPCODE_X86_SAR,
    ASSEMBLY_OPCODE_X86_LEA,
    ASSEMBLY_OPCODE_X86_MOVZX,
    ASSEMBLY_OPCODE_X86_MOVSX,
    ASSEMBLY_OPCODE_X86_MOVSXD,
    ASSEMBLY_OPCODE_X86_ROL,
    ASSEMBLY_OPCODE_X86_ROR,
    ASSEMBLY_OPCODE_X86_RCL,
    ASSEMBLY_OPCODE_X86_RCR,
    ASSEMBLY_OPCODE_X86_SHLD,
    ASSEMBLY_OPCODE_X86_SHRD,
    ASSEMBLY_OPCODE_X86_BSF,
    ASSEMBLY_OPCODE_X86_BSR,
    ASSEMBLY_OPCODE_X86_BSWAP,
    ASSEMBLY_OPCODE_X86_BT,
    ASSEMBLY_OPCODE_X86_BTC,
    ASSEMBLY_OPCODE_X86_BTR,
    ASSEMBLY_OPCODE_X86_BTS,
    ASSEMBLY_OPCODE_X86_XCHG,
    ASSEMBLY_OPCODE_X86_XADD,
    ASSEMBLY_OPCODE_X86_CMPXCHG,
    ASSEMBLY_OPCODE_X86_CMPXCHG8B,
    ASSEMBLY_OPCODE_X86_CMPXCHG16B,
    ASSEMBLY_OPCODE_X86_POPCNT,
    ASSEMBLY_OPCODE_X86_LZCNT,
    ASSEMBLY_OPCODE_X86_TZCNT,
    ASSEMBLY_OPCODE_X86_CBW,
    ASSEMBLY_OPCODE_X86_CWDE,
    ASSEMBLY_OPCODE_X86_CDQE,
    ASSEMBLY_OPCODE_X86_CWD,
    ASSEMBLY_OPCODE_X86_CDQ,
    ASSEMBLY_OPCODE_X86_CQO,
    ASSEMBLY_OPCODE_X86_JCC,
    ASSEMBLY_OPCODE_X86_SETCC,
    ASSEMBLY_OPCODE_X86_CMOVCC,
    ASSEMBLY_OPCODE_X86_MOVAPS,
    ASSEMBLY_OPCODE_X86_MOVUPS,
    ASSEMBLY_OPCODE_X86_MOVAPD,
    ASSEMBLY_OPCODE_X86_MOVUPD,
    ASSEMBLY_OPCODE_X86_MOVDQA,
    ASSEMBLY_OPCODE_X86_MOVDQU,
    ASSEMBLY_OPCODE_X86_XORPS,
    ASSEMBLY_OPCODE_X86_XORPD,
    ASSEMBLY_OPCODE_X86_PXOR,
    ASSEMBLY_OPCODE_X86_ADDPS,
    ASSEMBLY_OPCODE_X86_ADDPD,
    ASSEMBLY_OPCODE_X86_ADDSS,
    ASSEMBLY_OPCODE_X86_ADDSD,
    ASSEMBLY_OPCODE_X86_SUBPS,
    ASSEMBLY_OPCODE_X86_SUBPD,
    ASSEMBLY_OPCODE_X86_MULPS,
    ASSEMBLY_OPCODE_X86_MULPD,
    ASSEMBLY_OPCODE_X86_DIVPS,
    ASSEMBLY_OPCODE_X86_DIVPD,
    ASSEMBLY_OPCODE_X86_VMOVAPS,
    ASSEMBLY_OPCODE_X86_VMOVUPS,
    ASSEMBLY_OPCODE_X86_VMOVAPD,
    ASSEMBLY_OPCODE_X86_VMOVUPD,
    ASSEMBLY_OPCODE_X86_VXORPS,
    ASSEMBLY_OPCODE_X86_VXORPD,
    ASSEMBLY_OPCODE_X86_VADDPS,
    ASSEMBLY_OPCODE_X86_VADDPD,
    ASSEMBLY_OPCODE_X86_VADDSS,
    ASSEMBLY_OPCODE_X86_VADDSD,
    ASSEMBLY_OPCODE_X86_VSUBPS,
    ASSEMBLY_OPCODE_X86_VSUBPD,
    ASSEMBLY_OPCODE_X86_VMULPS,
    ASSEMBLY_OPCODE_X86_VMULPD,
    ASSEMBLY_OPCODE_X86_VDIVPS,
    ASSEMBLY_OPCODE_X86_VDIVPD,
    ASSEMBLY_OPCODE_X86_VMOVDQA,
    ASSEMBLY_OPCODE_X86_VMOVDQU,
    ASSEMBLY_OPCODE_X86_VPADDB,
    ASSEMBLY_OPCODE_X86_VPADDW,
    ASSEMBLY_OPCODE_X86_VPADDD,
    ASSEMBLY_OPCODE_X86_VPADDQ,
    ASSEMBLY_OPCODE_X86_VPSUBB,
    ASSEMBLY_OPCODE_X86_VPSUBW,
    ASSEMBLY_OPCODE_X86_VPSUBD,
    ASSEMBLY_OPCODE_X86_VPSUBQ,
    ASSEMBLY_OPCODE_X86_VPAND,
    ASSEMBLY_OPCODE_X86_VPOR,
    ASSEMBLY_OPCODE_X86_VPXOR,
    ASSEMBLY_OPCODE_X86_VPCMPEQB,
    ASSEMBLY_OPCODE_X86_VPCMPEQW,
    ASSEMBLY_OPCODE_X86_VPCMPEQD,
    ASSEMBLY_OPCODE_X86_VPCMPEQQ,
    ASSEMBLY_OPCODE_X86_VPCMPGTB,
    ASSEMBLY_OPCODE_X86_VPCMPGTW,
    ASSEMBLY_OPCODE_X86_VPCMPGTD,
    ASSEMBLY_OPCODE_X86_VPCMPGTQ,
    ASSEMBLY_OPCODE_X86_VPMULLW,
    ASSEMBLY_OPCODE_X86_VPMULLD,
    ASSEMBLY_OPCODE_X86_VMOVDQA32,
    ASSEMBLY_OPCODE_X86_VMOVDQU32,
    ASSEMBLY_OPCODE_X86_VMOVDQA64,
    ASSEMBLY_OPCODE_X86_VMOVDQU64,
    ASSEMBLY_OPCODE_X86_VMOVDQU8,
    ASSEMBLY_OPCODE_X86_VMOVDQU16,
    ASSEMBLY_OPCODE_X86_VCMPPS,
    ASSEMBLY_OPCODE_X86_VCMPPD,
    ASSEMBLY_OPCODE_X86_VPCMPD,
    ASSEMBLY_OPCODE_X86_VPCMPQ,
    ASSEMBLY_OPCODE_X86_VPCMPB,
    ASSEMBLY_OPCODE_X86_VPCMPW,
    ASSEMBLY_OPCODE_X86_VPCMPUD,
    ASSEMBLY_OPCODE_X86_VPCMPUQ,
    ASSEMBLY_OPCODE_X86_VRNDSCALEPS,
    ASSEMBLY_OPCODE_X86_VRNDSCALEPD,
    ASSEMBLY_OPCODE_X86_KMOVW,
    ASSEMBLY_OPCODE_X86_KMOVD,
    ASSEMBLY_OPCODE_X86_KMOVQ,
    ASSEMBLY_OPCODE_X86_KADDW,
    ASSEMBLY_OPCODE_X86_KANDW,
    ASSEMBLY_OPCODE_X86_KORW,
    ASSEMBLY_OPCODE_X86_KXORW,
    ASSEMBLY_OPCODE_X86_KNOTW,
    ASSEMBLY_OPCODE_X86_KORTESTW,
    ASSEMBLY_OPCODE_X86_APX_PUSH2,
    ASSEMBLY_OPCODE_X86_APX_POP2,
    ASSEMBLY_OPCODE_X86_LDTILECFG,
    ASSEMBLY_OPCODE_X86_STTILECFG,
    ASSEMBLY_OPCODE_X86_TILELOADD,
    ASSEMBLY_OPCODE_X86_TILELOADDT1,
    ASSEMBLY_OPCODE_X86_TILESTORED,
    ASSEMBLY_OPCODE_X86_TILEZERO,
    ASSEMBLY_OPCODE_X86_TDPBF16PS,
    ASSEMBLY_OPCODE_X86_TDPBSSD,
    ASSEMBLY_OPCODE_X86_TDPBSUD,
    ASSEMBLY_OPCODE_X86_TDPBUSD,
    ASSEMBLY_OPCODE_X86_TDPBUUD,
    ASSEMBLY_OPCODE_X86_EMMS,
    ASSEMBLY_OPCODE_X86_MOVQ_MMX,
    ASSEMBLY_OPCODE_X86_PADDB_MMX,
    ASSEMBLY_OPCODE_X86_PADDW_MMX,
    ASSEMBLY_OPCODE_X86_PADDD_MMX,
    ASSEMBLY_OPCODE_X86_PADDQ_MMX,
    ASSEMBLY_OPCODE_X86_PSUBB_MMX,
    ASSEMBLY_OPCODE_X86_PSUBW_MMX,
    ASSEMBLY_OPCODE_X86_PSUBD_MMX,
    ASSEMBLY_OPCODE_X86_PSUBQ_MMX,
    ASSEMBLY_OPCODE_X86_PAND_MMX,
    ASSEMBLY_OPCODE_X86_POR_MMX,
    ASSEMBLY_OPCODE_X86_PXOR_MMX,
    ASSEMBLY_OPCODE_X86_PCMPEQB_MMX,
    ASSEMBLY_OPCODE_X86_PCMPEQW_MMX,
    ASSEMBLY_OPCODE_X86_PCMPEQD_MMX,
    ASSEMBLY_OPCODE_X86_PCMPGTB_MMX,
    ASSEMBLY_OPCODE_X86_PCMPGTW_MMX,
    ASSEMBLY_OPCODE_X86_PCMPGTD_MMX,
    ASSEMBLY_OPCODE_X86_PMULLW_MMX,
    ASSEMBLY_OPCODE_X86_FLD,
    ASSEMBLY_OPCODE_X86_FST,
    ASSEMBLY_OPCODE_X86_FSTP,
    ASSEMBLY_OPCODE_X86_FILD,
    ASSEMBLY_OPCODE_X86_FIST,
    ASSEMBLY_OPCODE_X86_FISTP,
    ASSEMBLY_OPCODE_X86_FISTTP,
    ASSEMBLY_OPCODE_X86_FADD,
    ASSEMBLY_OPCODE_X86_FMUL,
    ASSEMBLY_OPCODE_X86_FSUB,
    ASSEMBLY_OPCODE_X86_FSUBR,
    ASSEMBLY_OPCODE_X86_FDIV,
    ASSEMBLY_OPCODE_X86_FDIVR,
    ASSEMBLY_OPCODE_X86_FADDP,
    ASSEMBLY_OPCODE_X86_FMULP,
    ASSEMBLY_OPCODE_X86_FSUBP,
    ASSEMBLY_OPCODE_X86_FSUBRP,
    ASSEMBLY_OPCODE_X86_FDIVP,
    ASSEMBLY_OPCODE_X86_FDIVRP,
    ASSEMBLY_OPCODE_X86_FXCH,
    ASSEMBLY_OPCODE_X86_FCOM,
    ASSEMBLY_OPCODE_X86_FCOMP,
    ASSEMBLY_OPCODE_X86_FCOMPP,
    ASSEMBLY_OPCODE_X86_FUCOM,
    ASSEMBLY_OPCODE_X86_FUCOMP,
    ASSEMBLY_OPCODE_X86_FUCOMPP,
    ASSEMBLY_OPCODE_X86_FCOMI,
    ASSEMBLY_OPCODE_X86_FCOMIP,
    ASSEMBLY_OPCODE_X86_FUCOMI,
    ASSEMBLY_OPCODE_X86_FUCOMIP,
    ASSEMBLY_OPCODE_X86_FCMOVCC,
    ASSEMBLY_OPCODE_X86_FIADD,
    ASSEMBLY_OPCODE_X86_FIMUL,
    ASSEMBLY_OPCODE_X86_FISUB,
    ASSEMBLY_OPCODE_X86_FISUBR,
    ASSEMBLY_OPCODE_X86_FIDIV,
    ASSEMBLY_OPCODE_X86_FIDIVR,
    ASSEMBLY_OPCODE_X86_FBLD,
    ASSEMBLY_OPCODE_X86_FBSTP,
    ASSEMBLY_OPCODE_X86_FLDCW,
    ASSEMBLY_OPCODE_X86_FNSTCW,
    ASSEMBLY_OPCODE_X86_FSTCW,
    ASSEMBLY_OPCODE_X86_FLDENV,
    ASSEMBLY_OPCODE_X86_FNSTENV,
    ASSEMBLY_OPCODE_X86_FSTENV,
    ASSEMBLY_OPCODE_X86_FRSTOR,
    ASSEMBLY_OPCODE_X86_FNSAVE,
    ASSEMBLY_OPCODE_X86_FSAVE,
    ASSEMBLY_OPCODE_X86_FNSTSW,
    ASSEMBLY_OPCODE_X86_FSTSW,
    ASSEMBLY_OPCODE_X86_FFREE,
    ASSEMBLY_OPCODE_X86_FFREEP,
    ASSEMBLY_OPCODE_X86_FINCSTP,
    ASSEMBLY_OPCODE_X86_FDECSTP,
    ASSEMBLY_OPCODE_X86_F2XM1,
    ASSEMBLY_OPCODE_X86_FABS,
    ASSEMBLY_OPCODE_X86_FCHS,
    ASSEMBLY_OPCODE_X86_FLD1,
    ASSEMBLY_OPCODE_X86_FLDZ,
    ASSEMBLY_OPCODE_X86_FLDPI,
    ASSEMBLY_OPCODE_X86_FLDL2E,
    ASSEMBLY_OPCODE_X86_FLDL2T,
    ASSEMBLY_OPCODE_X86_FLDLG2,
    ASSEMBLY_OPCODE_X86_FLDLN2,
    ASSEMBLY_OPCODE_X86_FSQRT,
    ASSEMBLY_OPCODE_X86_FSIN,
    ASSEMBLY_OPCODE_X86_FCOS,
    ASSEMBLY_OPCODE_X86_FSINCOS,
    ASSEMBLY_OPCODE_X86_FPTAN,
    ASSEMBLY_OPCODE_X86_FPATAN,
    ASSEMBLY_OPCODE_X86_FYL2X,
    ASSEMBLY_OPCODE_X86_FYL2XP1,
    ASSEMBLY_OPCODE_X86_FRNDINT,
    ASSEMBLY_OPCODE_X86_FSCALE,
    ASSEMBLY_OPCODE_X86_FPREM,
    ASSEMBLY_OPCODE_X86_FPREM1,
    ASSEMBLY_OPCODE_X86_FXTRACT,
    ASSEMBLY_OPCODE_X86_FTST,
    ASSEMBLY_OPCODE_X86_FXAM,
    ASSEMBLY_OPCODE_X86_FNOP,
    ASSEMBLY_OPCODE_X86_FINIT,
    ASSEMBLY_OPCODE_X86_FNINIT,
    ASSEMBLY_OPCODE_X86_FCLEX,
    ASSEMBLY_OPCODE_X86_FNCLEX,
    ASSEMBLY_OPCODE_X86_FWAIT,
    ASSEMBLY_OPCODE_X86_AMD_XOP,
    ASSEMBLY_OPCODE_X86_AMD_FMA4,
    ASSEMBLY_OPCODE_X86_AMD_TBM,
    ASSEMBLY_OPCODE_X86_AMD_3DNOW,
    ASSEMBLY_OPCODE_X86_AMD_FEMMS,
    ASSEMBLY_OPCODE_AARCH64_NOP,
    ASSEMBLY_OPCODE_AARCH64_RET,
    ASSEMBLY_OPCODE_AARCH64_B,
    ASSEMBLY_OPCODE_AARCH64_BL,
    ASSEMBLY_OPCODE_COUNT,
} AssemblyOpcode;

typedef struct AssemblyAmdForm AssemblyAmdForm;

typedef enum AssemblyOperandKind
{
    ASSEMBLY_OPERAND_NONE,
    ASSEMBLY_OPERAND_REGISTER,
    ASSEMBLY_OPERAND_MEMORY,
    ASSEMBLY_OPERAND_EXPRESSION,
    ASSEMBLY_OPERAND_COUNT,
} AssemblyOperandKind;

typedef struct AssemblyExpression AssemblyExpression;
struct AssemblyExpression
{
    s64 addend;
    u64 unsigned_addend;
    u32 symbol;
    bool has_symbol;
    bool has_unsigned_addend;
    u8 reserved[2];
};

typedef struct AssemblyRegister AssemblyRegister;
typedef enum AssemblyRegisterClass
{
    ASSEMBLY_REGISTER_GPR,
    ASSEMBLY_REGISTER_XMM,
    ASSEMBLY_REGISTER_YMM,
    ASSEMBLY_REGISTER_ZMM,
    ASSEMBLY_REGISTER_OPMASK,
    ASSEMBLY_REGISTER_TILE,
    ASSEMBLY_REGISTER_MMX,
    ASSEMBLY_REGISTER_X87,
    ASSEMBLY_REGISTER_BND,
    ASSEMBLY_REGISTER_CONTROL,
    ASSEMBLY_REGISTER_DEBUG,
    ASSEMBLY_REGISTER_SEGMENT,
    ASSEMBLY_REGISTER_SPECIAL,
    ASSEMBLY_REGISTER_CLASS_COUNT,
} AssemblyRegisterClass;

struct AssemblyRegister
{
    u8 index;
    u16 width;
    AssemblyRegisterClass class;
    bool high_byte;
    bool stack_pointer;
};

typedef struct AssemblyMemory AssemblyMemory;
struct AssemblyMemory
{
    AssemblyExpression displacement;
    AssemblyRegister base;
    AssemblyRegister index;
    u8 scale;
    u8 address_size;
    u8 segment;
    u16 width;
    bool has_base;
    bool has_index;
    bool rip_relative;
    bool has_segment;
    bool vsib;
    bool width_explicit;
    // AT&T permits an absolute address without the parenthesized
    // displacement(base,index,scale) form.  Keep this source-level bit so
    // direct branch targets (which use the same bare spelling) can remain
    // expressions while indirect branches still see a memory operand.
    bool absolute;
};

typedef struct AssemblyOperand AssemblyOperand;
struct AssemblyOperand
{
    AssemblyExpression expression;
    AssemblyMemory memory;
    AssemblyRegister reg;
    AssemblyOperandKind kind;
    u8 mask;
    u8 broadcast;
    u8 rounding;
    bool has_mask;
    bool zeroing;
    bool sae;
};

enum
{
    // Generated AArch64 source forms include up to ten visible operands.
    // Keep parser and metadata projections at the same bounded capacity.
    ASSEMBLY_MAX_OPERANDS = 10,
};

typedef struct AssemblyInstruction AssemblyInstruction;

typedef enum AssemblyEncodingKind
{
    ASSEMBLY_ENCODING_HANDWRITTEN,
    ASSEMBLY_ENCODING_AARCH64_FIXED_WORD,
    ASSEMBLY_ENCODING_AARCH64_GPR_ALIAS,
    ASSEMBLY_ENCODING_AARCH64_M1_GPR,
    ASSEMBLY_ENCODING_AARCH64_M1_SCALAR_INTEGER,
    ASSEMBLY_ENCODING_AARCH64_SCALAR_MEMORY,
    ASSEMBLY_ENCODING_AARCH64_CONTROL,
    ASSEMBLY_ENCODING_AARCH64_SYSTEM_SEMANTICS,
    ASSEMBLY_ENCODING_AARCH64_SYSTEM_REGISTER,
    ASSEMBLY_ENCODING_AARCH64_DIRECT_SIMD,
} AssemblyEncodingKind;

typedef enum AssemblyAarch64SystemRegisterOperation
{
    ASSEMBLY_AARCH64_SYSTEM_REGISTER_MRS,
    ASSEMBLY_AARCH64_SYSTEM_REGISTER_MSR,
    ASSEMBLY_AARCH64_SYSTEM_REGISTER_MRRS,
    ASSEMBLY_AARCH64_SYSTEM_REGISTER_MSRR,
} AssemblyAarch64SystemRegisterOperation;

struct AssemblyInstruction
{
    AssemblyOperand operands[ASSEMBLY_MAX_OPERANDS];
    u64 offset;
    u32 line;
    u32 column;
    u32 size;
    AssemblyOpcode opcode;
    AssemblyEncodingKind encoding_kind;
    u8 operand_count;
    u16 width;
    u8 condition;
    bool lock_prefix;
    bool no_flags;
    bool evex;
    u8 rip_relocation_trailing;
    String8 amd_mnemonic;
    AssemblyAmdForm const* amd_form;
    bool metadata;
    u8 metadata_operand_count;
    bool metadata_include_implicit;
    bool metadata_private_pc8_long;
    u32 metadata_form_id;
    u32 fixed_word;
    u32 aarch64_gpr_form_index;
    u32 aarch64_scalar_integer_form_index;
    u32 aarch64_scalar_memory_form_id;
    u32 aarch64_control_row_index;
    u32 aarch64_direct_simd_row_index;
    u8 aarch64_direct_simd_registers[4];
    u8 aarch64_direct_simd_arrangements[4];
    u8 aarch64_direct_simd_conditions[4];
    /* Fixed direct-SIMD spellings are normally SIMD-only.  Mixed rows such
     * as FCVTAS Wd, Sn carry the GPR width/ZR presentation here so emission
     * can build the semantic GPR value without broadening the generic
     * operand parser.  A zero width means that the public operand is SIMD. */
    u8 aarch64_direct_simd_gpr_widths[4];
    u8 aarch64_scalar_integer_operand_count;
    u8 aarch64_scalar_integer_modifier_count;
    u8 aarch64_direct_simd_fixed_field_kind;
    u8 aarch64_direct_simd_fixed_field_value;
    A64ScalarIntOperand aarch64_scalar_integer_operands[4];
    A64ScalarIntModifier aarch64_scalar_integer_modifiers[1];
    BusterAarch64ControlInstruction aarch64_control_instruction;
    AssemblyExpression aarch64_control_expressions[4];
    u8 aarch64_control_expression_mask;
    bool aarch64_control_private_long;
    u8 aarch64_control_private_expression;
    u8 aarch64_control_reserved;
    BusterAarch64SystemInstruction aarch64_system_instruction;
    u16 aarch64_system_register_encoding;
    u8 aarch64_system_register_operation;
    u8 aarch64_system_register_rt;
    u8 aarch64_system_register_rt2;
    u8 aarch64_system_reserved[3];
    String8 metadata_mnemonic;
    u8 metadata_address_size;
    u8 metadata_reserved_address[3];
    BusterX86MetadataPhysicalOperand metadata_operands[ASSEMBLY_MAX_OPERANDS];
    BusterX86MetadataPhysicalAttributes metadata_attributes;
};

typedef struct AssemblyBuilder AssemblyBuilder;
struct AssemblyBuilder
{
    Arena* arena;
    Target target;
    AssemblyEncodeResult result;
    AssemblyInstruction* instructions;
    u32 instruction_count;
    u32 instruction_capacity;
    u32 symbol_capacity;
    u32 relocation_capacity;
    u32 diagnostic_capacity;
    u64 output_capacity;
    u64 output_count;
    bool private_inline_labels;
    // The metadata parser reports this transient semantic fact to the outer
    // source adapter when a feature-gated typed decorator candidate is the
    // authoritative form.  It prevents the handwritten INVALID_OPERANDS
    // fallback from erasing an actual feature-policy diagnostic.
    bool metadata_failure_typed_decorator_authoritative;
};

enum
{
    // A source line can define one label and contain ten metadata operands;
    // each of those can introduce one distinct symbol.
    ASSEMBLY_SOURCE_SYMBOLS_PER_LINE = ASSEMBLY_MAX_OPERANDS + 1,
};

BUSTER_GLOBAL_LOCAL bool assembly_space(char8 value)
{
    return value == ' ' || value == '\t' || value == '\r';
}

BUSTER_GLOBAL_LOCAL String8 assembly_trim(String8 string)
{
    u64 start = 0;
    while (start < string.length && assembly_space(string.pointer[start]))
    {
        start += 1;
    }
    u64 end = string.length;
    while (end > start && assembly_space(string.pointer[end - 1]))
    {
        end -= 1;
    }
    return (String8){.pointer = string.pointer + start, .length = end - start};
}

typedef enum AssemblyOperandSplitStatus
{
    ASSEMBLY_OPERAND_SPLIT_END,
    ASSEMBLY_OPERAND_SPLIT_SUCCESS,
    ASSEMBLY_OPERAND_SPLIT_INVALID,
} AssemblyOperandSplitStatus;

enum
{
    ASSEMBLY_OPERAND_DELIMITER_CAPACITY = 64,
};

BUSTER_GLOBAL_LOCAL AssemblyOperandSplitStatus assembly_operand_split_next(String8 text, u64* cursor, String8* result)
{
    if (*cursor >= text.length)
    {
        return ASSEMBLY_OPERAND_SPLIT_END;
    }
    u64 operand_start = *cursor;
    u64 operand_end = operand_start;
    char8 delimiter_stack[ASSEMBLY_OPERAND_DELIMITER_CAPACITY] = {0};
    u32 delimiter_count = 0;
    while (operand_end < text.length)
    {
        char8 character = text.pointer[operand_end];
        if (character == '(' || character == '[' || character == '{')
        {
            if (delimiter_count == BUSTER_ARRAY_LENGTH(delimiter_stack))
            {
                return ASSEMBLY_OPERAND_SPLIT_INVALID;
            }
            delimiter_stack[delimiter_count++] = character;
        }
        else if (character == ')' || character == ']' || character == '}')
        {
            char8 expected = character == ')' ? '(' : character == ']' ? '[' : '{';
            if (!delimiter_count || delimiter_stack[delimiter_count - 1] != expected)
            {
                return ASSEMBLY_OPERAND_SPLIT_INVALID;
            }
            delimiter_count -= 1;
        }
        else if (character == ',' && !delimiter_count)
        {
            break;
        }
        operand_end += 1;
    }
    if (delimiter_count)
    {
        return ASSEMBLY_OPERAND_SPLIT_INVALID;
    }
    String8 operand = assembly_trim(string_slice(text, operand_start, operand_end));
    if (!operand.length)
    {
        return ASSEMBLY_OPERAND_SPLIT_INVALID;
    }
    *result = operand;
    *cursor = operand_end < text.length ? operand_end + 1 : operand_end;
    return ASSEMBLY_OPERAND_SPLIT_SUCCESS;
}

BUSTER_GLOBAL_LOCAL bool assembly_character_identifier_start(char8 value)
{
    return (value >= 'a' && value <= 'z') || (value >= 'A' && value <= 'Z') || value == '_' || value == '.' || value == '$';
}

BUSTER_GLOBAL_LOCAL bool assembly_character_identifier(char8 value)
{
    return assembly_character_identifier_start(value) || (value >= '0' && value <= '9');
}

BUSTER_GLOBAL_LOCAL bool assembly_identifier(String8 string)
{
    if (!string.length || !assembly_character_identifier_start(string.pointer[0]))
    {
        return false;
    }
    for (u64 index = 1; index < string.length; index += 1)
    {
        if (!assembly_character_identifier(string.pointer[index]))
        {
            return false;
        }
    }
    return true;
}

BUSTER_GLOBAL_LOCAL u64 assembly_leading_label_colon(String8 statement)
{
    u64 token_end = 0;
    while (token_end < statement.length && !assembly_space(statement.pointer[token_end]) && statement.pointer[token_end] != ':')
    {
        token_end += 1;
    }
    if (token_end < statement.length && statement.pointer[token_end] == ':')
    {
        return token_end;
    }
    u64 colon = token_end;
    while (colon < statement.length && assembly_space(statement.pointer[colon]))
    {
        colon += 1;
    }
    if (colon < statement.length && statement.pointer[colon] == ':')
    {
        // A separated colon can be followed immediately by the instruction, as
        // in `label :nop`.  The exception is an AArch64 modifier token such as
        // `:lo12:symbol`, whose second colon makes the first one part of the
        // operand after the mnemonic rather than a label separator.
        u64 modifier_end = colon + 1;
        while (modifier_end < statement.length && assembly_character_identifier(statement.pointer[modifier_end]))
        {
            modifier_end += 1;
        }
        if (modifier_end == colon + 1 || modifier_end >= statement.length || statement.pointer[modifier_end] != ':')
        {
            return colon;
        }
    }

    return BUSTER_STRING_NO_MATCH;
}

BUSTER_GLOBAL_LOCAL char8 assembly_ascii_lower(char8 value)
{
    return value >= 'A' && value <= 'Z' ? (char8)(value + ('a' - 'A')) : value;
}

BUSTER_GLOBAL_LOCAL bool assembly_word_equal(String8 left, String8 right)
{
    if (left.length != right.length)
    {
        return false;
    }
    for (u64 index = 0; index < left.length; index += 1)
    {
        if (assembly_ascii_lower(left.pointer[index]) != assembly_ascii_lower(right.pointer[index]))
        {
            return false;
        }
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_scalar_memory_mnemonic(String8 mnemonic, u8* size, bool* store)
{
    static const struct
    {
        String8 mnemonic;
        u8 size;
        bool store;
    } forms[] = {
        {S8_INITIALIZER("ldr"), 0, false},
        {S8_INITIALIZER("str"), 0, true},
        {S8_INITIALIZER("ldrb"), 1, false},
        {S8_INITIALIZER("strb"), 1, true},
        {S8_INITIALIZER("ldrh"), 2, false},
        {S8_INITIALIZER("strh"), 2, true},
    };
    bool found = false;
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(forms) && !found; index += 1)
    {
        if (assembly_word_equal(mnemonic, forms[index].mnemonic))
        {
            if (size) *size = forms[index].size;
            if (store) *store = forms[index].store;
            found = true;
        }
    }
    return found;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_gpr_register_parse(String8 text, AssemblyRegister* result)
{
    if (!result || !text.pointer || !text.length)
    {
        return false;
    }
    text = assembly_trim(text);
    if (assembly_word_equal(text, S8("sp")) || assembly_word_equal(text, S8("wsp")))
    {
        *result = (AssemblyRegister){.index = 31, .width = assembly_word_equal(text, S8("wsp")) ? 32u : 64u,
                                    .class = ASSEMBLY_REGISTER_GPR, .stack_pointer = true};
        return true;
    }
    if (assembly_word_equal(text, S8("wzr")) || assembly_word_equal(text, S8("xzr")))
    {
        *result = (AssemblyRegister){.index = 31, .width = assembly_word_equal(text, S8("wzr")) ? 32u : 64u,
                                    .class = ASSEMBLY_REGISTER_GPR};
        return true;
    }
    if (text.length < 2 || (assembly_ascii_lower(text.pointer[0]) != 'w' && assembly_ascii_lower(text.pointer[0]) != 'x'))
    {
        return false;
    }
    if (text.length > 2 && text.pointer[1] == '0')
    {
        return false;
    }
    u32 index = 0;
    for (u64 position = 1; position < text.length; position += 1)
    {
        char8 value = text.pointer[position];
        if (value < '0' || value > '9' || index > 31)
        {
            return false;
        }
        index = index * 10u + (u32)(value - '0');
    }
    // Arm's architectural spelling for register 31 is WZR/XZR/WSP/SP.  A
    // literal W31/X31 is never accepted by this front door.
    if (index > 30)
    {
        return false;
    }
    *result = (AssemblyRegister){.index = (u8)index, .width = assembly_ascii_lower(text.pointer[0]) == 'w' ? 32u : 64u,
                                .class = ASSEMBLY_REGISTER_GPR};
    return true;
}

BUSTER_GLOBAL_LOCAL void assembly_diagnostic(AssemblyBuilder* builder, AssemblyDiagnosticKind kind, u32 line, u32 column, u32 length, String8 message)
{
    if (builder->result.diagnostic_count >= builder->diagnostic_capacity)
    {
        return;
    }
    builder->result.diagnostics[builder->result.diagnostic_count++] = (AssemblyDiagnostic){
        .message = message,
        .line = line,
        .column = column,
        .length = length,
        .kind = kind,
    };
}

BUSTER_GLOBAL_LOCAL u32 assembly_symbol_find(AssemblyBuilder* builder, String8 name)
{
    for (u32 symbol_index = 0; symbol_index < builder->result.symbol_count; symbol_index += 1)
    {
        if (string_equal(builder->result.symbols[symbol_index].name, name))
        {
            return symbol_index;
        }
    }
    return UINT32_MAX;
}

BUSTER_GLOBAL_LOCAL u32 assembly_symbol_intern(AssemblyBuilder* builder, String8 name)
{
    u32 existing = assembly_symbol_find(builder, name);
    if (existing != UINT32_MAX)
    {
        return existing;
    }
    if (builder->result.symbol_count >= builder->symbol_capacity)
    {
        return UINT32_MAX;
    }
    u32 result = builder->result.symbol_count++;
    builder->result.symbols[result].name = string_duplicate_arena(builder->arena, name, false);
    return result;
}

BUSTER_GLOBAL_LOCAL bool assembly_parse_s64(String8 string, s64* result)
{
    string = assembly_trim(string);
    if (!string.length || !result)
    {
        return false;
    }
    bool negative = string.pointer[0] == '-';
    u64 cursor = negative || string.pointer[0] == '+' ? 1 : 0;
    u32 base = 10;
    if (cursor + 2 <= string.length && string.pointer[cursor] == '0' &&
        (string.pointer[cursor + 1] == 'x' || string.pointer[cursor + 1] == 'X'))
    {
        base = 16;
        cursor += 2;
    }
    if (cursor == string.length)
    {
        return false;
    }
    u64 value = 0;
    u64 limit = negative ? (u64)INT64_MAX + 1 : (u64)INT64_MAX;
    for (; cursor < string.length; cursor += 1)
    {
        char8 character = string.pointer[cursor];
        u32 digit = character >= '0' && character <= '9' ? (u32)(character - '0')
                    : character >= 'a' && character <= 'f' ? (u32)(character - 'a') + 10
                    : character >= 'A' && character <= 'F' ? (u32)(character - 'A') + 10
                                                            : UINT32_MAX;
        if (digit >= base || value > (limit - digit) / base)
        {
            return false;
        }
        value = value * base + digit;
    }
    if (negative)
    {
        *result = value == (u64)INT64_MAX + 1 ? INT64_MIN : -(s64)value;
    }
    else
    {
        *result = (s64)value;
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_parse_u64(String8 string, u64* result)
{
    string = assembly_trim(string);
    if (!string.length || !result || string.pointer[0] == '-')
    {
        return false;
    }
    u64 cursor = string.pointer[0] == '+' ? 1 : 0;
    u32 base = 10;
    if (cursor + 2 <= string.length && string.pointer[cursor] == '0' &&
        (string.pointer[cursor + 1] == 'x' || string.pointer[cursor + 1] == 'X'))
    {
        base = 16;
        cursor += 2;
    }
    if (cursor == string.length)
    {
        return false;
    }
    u64 value = 0;
    for (; cursor < string.length; cursor += 1)
    {
        char8 character = string.pointer[cursor];
        u32 digit = character >= '0' && character <= '9' ? (u32)(character - '0')
                    : character >= 'a' && character <= 'f' ? (u32)(character - 'a') + 10
                    : character >= 'A' && character <= 'F' ? (u32)(character - 'A') + 10
                                                            : UINT32_MAX;
        if (digit >= base || value > (UINT64_MAX - digit) / base)
        {
            return false;
        }
        value = value * base + digit;
    }
    *result = value;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_expression_parse(AssemblyBuilder* builder, String8 text, AssemblyExpression* result)
{
    text = assembly_trim(text);
    if (!text.length || !result)
    {
        return false;
    }
    // A displacement may be written parenthesized -- `(-1-2)(%rdi,%rdx)` --
    // so strip a pair that encloses the whole expression before reading it.
    while (text.length > 1 && text.pointer[0] == '(' && text.pointer[text.length - 1] == ')')
    {
        u32 depth = 0;
        bool encloses = true;
        for (u64 index = 0; index < text.length && encloses; index += 1)
        {
            depth += text.pointer[index] == '(';
            depth -= text.pointer[index] == ')';
            encloses = depth != 0 || index + 1 == text.length;
        }
        if (!encloses)
        {
            break;
        }
        text = assembly_trim(string_slice(text, 1, text.length - 1));
        if (!text.length)
        {
            return false;
        }
    }
    s64 integer = 0;
    if (assembly_parse_s64(text, &integer))
    {
        result->addend = integer;
        return true;
    }
    u64 unsigned_integer = 0;
    if (assembly_parse_u64(text, &unsigned_integer))
    {
        if (unsigned_integer <= (u64)INT64_MAX)
        {
            result->addend = (s64)unsigned_integer;
        }
        else
        {
            result->unsigned_addend = unsigned_integer;
            result->has_unsigned_addend = true;
        }
        return true;
    }
    // A sum of constants: `0x3fff+13` and `72+8` are how hand-written assembly
    // spells a field built from named parts. Fold it here; a term that is not
    // a number falls through to the symbol form below.
    s64 folded = 0;
    bool constant_sum = false;
    u64 term_start = 0;
    for (u64 index = 1; index <= text.length; index += 1)
    {
        if (index != text.length && text.pointer[index] != '+' && text.pointer[index] != '-')
        {
            continue;
        }
        String8 term = assembly_trim(string_slice(text, term_start, index));
        s64 sign = 1;
        if (term.length && (term.pointer[0] == '+' || term.pointer[0] == '-'))
        {
            sign = term.pointer[0] == '-' ? -1 : 1;
            term = assembly_trim(string_slice(term, 1, term.length));
        }
        s64 term_value = 0;
        u64 term_unsigned = 0;
        if (assembly_parse_s64(term, &term_value))
        {
        }
        else if (assembly_parse_u64(term, &term_unsigned) && term_unsigned <= (u64)INT64_MAX)
        {
            term_value = (s64)term_unsigned;
        }
        else
        {
            constant_sum = false;
            break;
        }
        folded += sign * term_value;
        constant_sum = index != text.length || term_start != 0;
        term_start = index;
    }
    if (constant_sum)
    {
        result->addend = folded;
        return true;
    }
    u64 operator_index = text.length;
    for (u64 index = 1; index < text.length; index += 1)
    {
        if (text.pointer[index] == '+' || text.pointer[index] == '-')
        {
            operator_index = index;
            break;
        }
    }
    String8 name = assembly_trim((String8){.pointer = text.pointer, .length = operator_index});
    if (!assembly_identifier(name))
    {
        return false;
    }
    if (operator_index < text.length)
    {
        String8 addend = assembly_trim((String8){.pointer = text.pointer + operator_index + 1, .length = text.length - operator_index - 1});
        if (!assembly_parse_s64(addend, &integer))
        {
            return false;
        }
        if (text.pointer[operator_index] == '-')
        {
            if (integer == INT64_MIN)
            {
                return false;
            }
            integer = -integer;
        }
    }
    u32 symbol = assembly_symbol_intern(builder, name);
    if (symbol == UINT32_MAX)
    {
        return false;
    }
    *result = (AssemblyExpression){
        .addend = integer,
        .symbol = symbol,
        .has_symbol = true,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_numbered_register_parse(String8 text, String8 prefix, u32 maximum, u16 width,
                                                          AssemblyRegisterClass class, AssemblyRegister* result)
{
    if (text.length <= prefix.length || !assembly_word_equal(string_slice(text, 0, prefix.length), prefix))
    {
        return false;
    }
    if (text.length - prefix.length > 1 && text.pointer[prefix.length] == '0')
    {
        return false;
    }
    u32 value = 0;
    for (u64 index = prefix.length; index < text.length; index += 1)
    {
        char8 character = text.pointer[index];
        if (character < '0' || character > '9' || value > (UINT32_MAX - (u32)(character - '0')) / 10)
        {
            return false;
        }
        value = value * 10 + (u32)(character - '0');
    }
    if (value > maximum)
    {
        return false;
    }
    *result = (AssemblyRegister){.index = (u8)value, .width = width, .class = class};
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_extended_gpr_parse(String8 text, AssemblyRegister* result)
{
    if (text.length < 3 || assembly_ascii_lower(text.pointer[0]) != 'r')
    {
        return false;
    }
    u64 suffix_start = text.length;
    char8 suffix = 0;
    if (text.length && (assembly_ascii_lower(text.pointer[text.length - 1]) == 'b' ||
                        assembly_ascii_lower(text.pointer[text.length - 1]) == 'w' ||
                        assembly_ascii_lower(text.pointer[text.length - 1]) == 'd'))
    {
        suffix_start -= 1;
        suffix = assembly_ascii_lower(text.pointer[text.length - 1]);
    }
    if (suffix_start <= 1)
    {
        return false;
    }
    if (suffix_start - 1 > 1 && text.pointer[1] == '0')
    {
        return false;
    }
    u32 value = 0;
    for (u64 index = 1; index < suffix_start; index += 1)
    {
        char8 character = text.pointer[index];
        if (character < '0' || character > '9' || value > (UINT32_MAX - (u32)(character - '0')) / 10)
        {
            return false;
        }
        value = value * 10 + (u32)(character - '0');
    }
    if (value < 16 || value > 31)
    {
        return false;
    }
    u16 width = suffix == 'b' ? 8 : suffix == 'w' ? 16 : suffix == 'd' ? 32 : 64;
    *result = (AssemblyRegister){.index = (u8)value, .width = width, .class = ASSEMBLY_REGISTER_GPR};
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_register_parse(String8 text, AssemblySyntax syntax, AssemblyRegister* result)
{
    text = assembly_trim(text);
    if (syntax == ASSEMBLY_SYNTAX_ATT)
    {
        if (!text.length || text.pointer[0] != '%')
        {
            return false;
        }
        text.pointer += 1;
        text.length -= 1;
    }
    else if (text.length && text.pointer[0] == '%')
    {
        return false;
    }

    if (assembly_extended_gpr_parse(text, result))
    {
        return true;
    }

    // GNU and LLVM expose the complete four-bit CR/DR encoding domain.  Keep
    // CR0..CR15 and DR0..DR15 selectable as encodable register numbers; a
    // processor may still #UD for an architecturally reserved number when
    // the resulting instruction is executed.
    if (assembly_numbered_register_parse(text, S8("cr"), 15, 64, ASSEMBLY_REGISTER_CONTROL, result) ||
        assembly_numbered_register_parse(text, S8("dr"), 15, 64, ASSEMBLY_REGISTER_DEBUG, result) ||
        assembly_numbered_register_parse(text, S8("bnd"), 3, 128, ASSEMBLY_REGISTER_BND, result))
    {
        return true;
    }
    static String8 const names_segment[] = {
        S8_INITIALIZER("es"), S8_INITIALIZER("cs"), S8_INITIALIZER("ss"),
        S8_INITIALIZER("ds"), S8_INITIALIZER("fs"), S8_INITIALIZER("gs"),
    };
    for (u32 register_index = 0; register_index < BUSTER_ARRAY_LENGTH(names_segment); register_index += 1)
    {
        if (assembly_word_equal(text, names_segment[register_index]))
        {
            *result = (AssemblyRegister){.index = (u8)register_index, .width = 16, .class = ASSEMBLY_REGISTER_SEGMENT};
            return true;
        }
    }

    static String8 const names_64[] = {
        S8_INITIALIZER("rax"), S8_INITIALIZER("rcx"), S8_INITIALIZER("rdx"), S8_INITIALIZER("rbx"),
        S8_INITIALIZER("rsp"), S8_INITIALIZER("rbp"), S8_INITIALIZER("rsi"), S8_INITIALIZER("rdi"),
        S8_INITIALIZER("r8"), S8_INITIALIZER("r9"), S8_INITIALIZER("r10"), S8_INITIALIZER("r11"),
        S8_INITIALIZER("r12"), S8_INITIALIZER("r13"), S8_INITIALIZER("r14"), S8_INITIALIZER("r15"),
    };
    static String8 const names_32[] = {
        S8_INITIALIZER("eax"), S8_INITIALIZER("ecx"), S8_INITIALIZER("edx"), S8_INITIALIZER("ebx"),
        S8_INITIALIZER("esp"), S8_INITIALIZER("ebp"), S8_INITIALIZER("esi"), S8_INITIALIZER("edi"),
        S8_INITIALIZER("r8d"), S8_INITIALIZER("r9d"), S8_INITIALIZER("r10d"), S8_INITIALIZER("r11d"),
        S8_INITIALIZER("r12d"), S8_INITIALIZER("r13d"), S8_INITIALIZER("r14d"), S8_INITIALIZER("r15d"),
    };
    static String8 const names_16[] = {
        S8_INITIALIZER("ax"), S8_INITIALIZER("cx"), S8_INITIALIZER("dx"), S8_INITIALIZER("bx"),
        S8_INITIALIZER("sp"), S8_INITIALIZER("bp"), S8_INITIALIZER("si"), S8_INITIALIZER("di"),
        S8_INITIALIZER("r8w"), S8_INITIALIZER("r9w"), S8_INITIALIZER("r10w"), S8_INITIALIZER("r11w"),
        S8_INITIALIZER("r12w"), S8_INITIALIZER("r13w"), S8_INITIALIZER("r14w"), S8_INITIALIZER("r15w"),
    };
    static String8 const names_high_8[] = {
        S8_INITIALIZER("ah"), S8_INITIALIZER("ch"), S8_INITIALIZER("dh"), S8_INITIALIZER("bh"),
    };
    static String8 const names_8[] = {
        S8_INITIALIZER("al"), S8_INITIALIZER("cl"), S8_INITIALIZER("dl"), S8_INITIALIZER("bl"),
        S8_INITIALIZER("spl"), S8_INITIALIZER("bpl"), S8_INITIALIZER("sil"), S8_INITIALIZER("dil"),
        S8_INITIALIZER("r8b"), S8_INITIALIZER("r9b"), S8_INITIALIZER("r10b"), S8_INITIALIZER("r11b"),
        S8_INITIALIZER("r12b"), S8_INITIALIZER("r13b"), S8_INITIALIZER("r14b"), S8_INITIALIZER("r15b"),
    };
    static const struct
    {
        String8 const* names;
        u16 width;
    } groups[] = {
        {names_64, 64},
        {names_32, 32},
        {names_16, 16},
        {names_8, 8},
    };
    for (u32 group_index = 0; group_index < BUSTER_ARRAY_LENGTH(groups); group_index += 1)
    {
        for (u32 register_index = 0; register_index < 16; register_index += 1)
        {
            if (assembly_word_equal(text, groups[group_index].names[register_index]))
            {
                *result = (AssemblyRegister){.index = (u8)register_index, .width = groups[group_index].width};
                return true;
            }
        }
    }
    for (u32 register_index = 0; register_index < BUSTER_ARRAY_LENGTH(names_high_8); register_index += 1)
    {
        if (assembly_word_equal(text, names_high_8[register_index]))
        {
            *result = (AssemblyRegister){.index = (u8)(register_index + 4), .width = 8, .high_byte = true};
            return true;
        }
    }
    static String8 const names_xmm[] = {
        S8_INITIALIZER("xmm0"), S8_INITIALIZER("xmm1"), S8_INITIALIZER("xmm2"), S8_INITIALIZER("xmm3"),
        S8_INITIALIZER("xmm4"), S8_INITIALIZER("xmm5"), S8_INITIALIZER("xmm6"), S8_INITIALIZER("xmm7"),
        S8_INITIALIZER("xmm8"), S8_INITIALIZER("xmm9"), S8_INITIALIZER("xmm10"), S8_INITIALIZER("xmm11"),
        S8_INITIALIZER("xmm12"), S8_INITIALIZER("xmm13"), S8_INITIALIZER("xmm14"), S8_INITIALIZER("xmm15"),
    };
    for (u32 register_index = 0; register_index < BUSTER_ARRAY_LENGTH(names_xmm); register_index += 1)
    {
        if (assembly_word_equal(text, names_xmm[register_index]))
        {
            *result = (AssemblyRegister){.index = (u8)register_index, .width = 128, .class = ASSEMBLY_REGISTER_XMM};
            return true;
        }
    }
    static String8 const names_ymm[] = {
        S8_INITIALIZER("ymm0"), S8_INITIALIZER("ymm1"), S8_INITIALIZER("ymm2"), S8_INITIALIZER("ymm3"),
        S8_INITIALIZER("ymm4"), S8_INITIALIZER("ymm5"), S8_INITIALIZER("ymm6"), S8_INITIALIZER("ymm7"),
        S8_INITIALIZER("ymm8"), S8_INITIALIZER("ymm9"), S8_INITIALIZER("ymm10"), S8_INITIALIZER("ymm11"),
        S8_INITIALIZER("ymm12"), S8_INITIALIZER("ymm13"), S8_INITIALIZER("ymm14"), S8_INITIALIZER("ymm15"),
    };
    for (u32 register_index = 0; register_index < BUSTER_ARRAY_LENGTH(names_ymm); register_index += 1)
    {
        if (assembly_word_equal(text, names_ymm[register_index]))
        {
            *result = (AssemblyRegister){.index = (u8)register_index, .width = 256, .class = ASSEMBLY_REGISTER_YMM};
            return true;
        }
    }
    if (assembly_numbered_register_parse(text, S8("xmm"), 31, 128, ASSEMBLY_REGISTER_XMM, result) ||
        assembly_numbered_register_parse(text, S8("ymm"), 31, 256, ASSEMBLY_REGISTER_YMM, result) ||
        assembly_numbered_register_parse(text, S8("zmm"), 31, 512, ASSEMBLY_REGISTER_ZMM, result) ||
        assembly_numbered_register_parse(text, S8("k"), 7, 64, ASSEMBLY_REGISTER_OPMASK, result) ||
        assembly_numbered_register_parse(text, S8("tmm"), 7, 0, ASSEMBLY_REGISTER_TILE, result))
    {
        return true;
    }
    // ACE-1's BSRMOV forms name the fixed architectural BSR0 operand when
    // spelling the direction explicitly. It is a 64-bit special register,
    // distinct from the x87 ST* aliases below.
    if (assembly_word_equal(text, S8("bsr0")))
    {
        *result = (AssemblyRegister){.index = 0, .width = 64, .class = ASSEMBLY_REGISTER_SPECIAL};
        return true;
    }
    static String8 const names_mmx[] = {
        S8_INITIALIZER("mm0"), S8_INITIALIZER("mm1"), S8_INITIALIZER("mm2"), S8_INITIALIZER("mm3"),
        S8_INITIALIZER("mm4"), S8_INITIALIZER("mm5"), S8_INITIALIZER("mm6"), S8_INITIALIZER("mm7"),
    };
    for (u32 register_index = 0; register_index < BUSTER_ARRAY_LENGTH(names_mmx); register_index += 1)
    {
        if (assembly_word_equal(text, names_mmx[register_index]))
        {
            *result = (AssemblyRegister){.index = (u8)register_index, .width = 64, .class = ASSEMBLY_REGISTER_MMX};
            return true;
        }
    }
    if (assembly_word_equal(text, S8("st")))
    {
        *result = (AssemblyRegister){.width = 80, .class = ASSEMBLY_REGISTER_X87};
        return true;
    }
    if (text.length == 5 && assembly_ascii_lower(text.pointer[0]) == 's' && assembly_ascii_lower(text.pointer[1]) == 't' &&
        text.pointer[2] == '(' && text.pointer[4] == ')' && text.pointer[3] >= '0' && text.pointer[3] <= '7')
    {
        *result = (AssemblyRegister){.index = (u8)(text.pointer[3] - '0'), .width = 80, .class = ASSEMBLY_REGISTER_X87};
        return true;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_rip_parse(String8 text, AssemblySyntax syntax)
{
    text = assembly_trim(text);
    if (syntax == ASSEMBLY_SYNTAX_ATT)
    {
        if (!text.length || text.pointer[0] != '%')
        {
            return false;
        }
        text.pointer += 1;
        text.length -= 1;
    }
    return assembly_word_equal(text, S8("rip"));
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_segment_parse(String8 text, AssemblySyntax syntax, u8* result)
{
    text = assembly_trim(text);
    if (syntax == ASSEMBLY_SYNTAX_ATT)
    {
        if (!text.length || text.pointer[0] != '%')
        {
            return false;
        }
        text.pointer += 1;
        text.length -= 1;
    }
    static String8 const names[] = {
        S8_INITIALIZER("es"), S8_INITIALIZER("cs"), S8_INITIALIZER("ss"),
        S8_INITIALIZER("ds"), S8_INITIALIZER("fs"), S8_INITIALIZER("gs"),
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(names); index += 1)
    {
        if (assembly_word_equal(text, names[index]))
        {
            if (result)
            {
                *result = (u8)(index + 1);
            }
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_scale_parse(String8 text, u8* result)
{
    s64 value = 0;
    if (!assembly_parse_s64(text, &value) || (value != 1 && value != 2 && value != 4 && value != 8))
    {
        return false;
    }
    *result = (u8)value;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_expression_merge(AssemblyBuilder* builder, AssemblyExpression* destination, String8 text, bool subtract)
{
    AssemblyExpression expression = {0};
    if (!assembly_expression_parse(builder, text, &expression) || expression.has_unsigned_addend ||
        (destination->has_symbol && expression.has_symbol))
    {
        return false;
    }
    if (subtract && expression.has_symbol)
    {
        return false;
    }
    if ((!subtract && expression.addend > 0 && destination->addend > INT64_MAX - expression.addend) ||
        (!subtract && expression.addend < 0 && destination->addend < INT64_MIN - expression.addend) ||
        (subtract && expression.addend < 0 && destination->addend > INT64_MAX + expression.addend) ||
        (subtract && expression.addend > 0 && destination->addend < INT64_MIN + expression.addend))
    {
        return false;
    }
    if (subtract && expression.addend == INT64_MIN)
    {
        destination->addend += INT64_MAX;
        destination->addend += 1;
    }
    else
    {
        destination->addend += subtract ? -expression.addend : expression.addend;
    }
    if (expression.has_symbol)
    {
        destination->has_symbol = true;
        destination->symbol = expression.symbol;
    }
    return true;
}

BUSTER_GLOBAL_LOCAL String8 assembly_x86_memory_strip_segment(String8 text, AssemblySyntax syntax, AssemblyMemory* result)
{
    u64 colon = string_first_code_unit(text, ':');
    if (colon < text.length)
    {
        u8 segment = 0;
        String8 prefix = assembly_trim(string_slice(text, 0, colon));
        if (!result->has_segment && assembly_x86_segment_parse(prefix, syntax, &segment))
        {
            result->has_segment = true;
            result->segment = segment;
            text = assembly_trim(string_slice(text, colon + 1, text.length));
        }
    }
    return text;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_parse_intel(AssemblyBuilder* builder, String8 text, AssemblyMemory* result)
{
    text = assembly_trim(text);
    text = assembly_x86_memory_strip_segment(text, ASSEMBLY_SYNTAX_INTEL, result);
    static const struct
    {
        String8 prefix;
        u16 width;
    } qualifiers[] = {
        {S8_INITIALIZER("byte ptr"), 8},
        {S8_INITIALIZER("word ptr"), 16},
        {S8_INITIALIZER("dword ptr"), 32},
        {S8_INITIALIZER("qword ptr"), 64},
        {S8_INITIALIZER("tbyte ptr"), 80},
        {S8_INITIALIZER("xmmword ptr"), 128},
        {S8_INITIALIZER("ymmword ptr"), 256},
        {S8_INITIALIZER("zmmword ptr"), 512},
    };
    for (u32 qualifier_index = 0; qualifier_index < BUSTER_ARRAY_LENGTH(qualifiers); qualifier_index += 1)
    {
        String8 prefix = qualifiers[qualifier_index].prefix;
        if (text.length > prefix.length && assembly_word_equal(string_slice(text, 0, prefix.length), prefix) &&
            assembly_space(text.pointer[prefix.length]))
        {
            result->width = qualifiers[qualifier_index].width;
            result->width_explicit = true;
            text = assembly_trim(string_slice(text, prefix.length, text.length));
            break;
        }
    }
    text = assembly_x86_memory_strip_segment(text, ASSEMBLY_SYNTAX_INTEL, result);
    if (text.length < 2 || text.pointer[0] != '[' || text.pointer[text.length - 1] != ']')
    {
        return false;
    }
    text = assembly_trim(string_slice(text, 1, text.length - 1));
    if (!text.length)
    {
        return false;
    }
    result->scale = 1;
    u64 cursor = 0;
    bool subtract = false;
    while (cursor < text.length)
    {
        while (cursor < text.length && assembly_space(text.pointer[cursor]))
        {
            cursor += 1;
        }
        if (cursor < text.length && (text.pointer[cursor] == '+' || text.pointer[cursor] == '-'))
        {
            subtract = text.pointer[cursor] == '-';
            cursor += 1;
        }
        u64 end = cursor;
        while (end < text.length && text.pointer[end] != '+' && text.pointer[end] != '-')
        {
            end += 1;
        }
        String8 term = assembly_trim(string_slice(text, cursor, end));
        if (!term.length)
        {
            return false;
        }
        u64 star = string_first_code_unit(term, '*');
        AssemblyRegister reg = {0};
        if (star < term.length)
        {
            String8 register_text = assembly_trim(string_slice(term, 0, star));
            String8 scale_text = assembly_trim(string_slice(term, star + 1, term.length));
            if (subtract || result->has_index || !assembly_register_parse(register_text, ASSEMBLY_SYNTAX_INTEL, &reg) ||
                !assembly_x86_scale_parse(scale_text, &result->scale))
            {
                return false;
            }
            bool vector_index = reg.class == ASSEMBLY_REGISTER_XMM || reg.class == ASSEMBLY_REGISTER_YMM ||
                                reg.class == ASSEMBLY_REGISTER_ZMM;
            if ((!vector_index && (reg.class != ASSEMBLY_REGISTER_GPR || (reg.width != 32 && reg.width != 64) || reg.index == 4)) ||
                (vector_index && result->rip_relative))
            {
                return false;
            }
            if (!vector_index)
            {
                if (result->address_size && result->address_size != reg.width)
                {
                    return false;
                }
                result->address_size = (u8)reg.width;
            }
            result->index = reg;
            result->has_index = true;
            result->vsib = vector_index;
        }
        else if (assembly_x86_rip_parse(term, ASSEMBLY_SYNTAX_INTEL))
        {
            if (subtract || result->rip_relative || result->has_base || result->has_index)
            {
                return false;
            }
            result->rip_relative = true;
        }
        else if (assembly_register_parse(term, ASSEMBLY_SYNTAX_INTEL, &reg))
        {
            if (subtract || reg.class != ASSEMBLY_REGISTER_GPR || (reg.width != 32 && reg.width != 64))
            {
                return false;
            }
            if (result->address_size && result->address_size != reg.width)
            {
                return false;
            }
            result->address_size = (u8)reg.width;
            if (!result->has_base)
            {
                result->base = reg;
                result->has_base = true;
            }
            else if (!result->has_index && reg.index != 4)
            {
                result->index = reg;
                result->has_index = true;
            }
            else
            {
                return false;
            }
        }
        else if (!assembly_expression_merge(builder, &result->displacement, term, subtract))
        {
            return false;
        }
        cursor = end;
        subtract = false;
    }
    return !result->rip_relative || (!result->has_base && !result->has_index);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_parse_att(AssemblyBuilder* builder, String8 text, AssemblyMemory* result)
{
    text = assembly_trim(text);
    text = assembly_x86_memory_strip_segment(text, ASSEMBLY_SYNTAX_ATT, result);
    // The base/index group is the trailing parenthesized one, not the first:
    // a displacement may itself be parenthesized, as in `(-1-2)(%rdi,%rdx)`.
    u64 open = BUSTER_STRING_NO_MATCH;
    for (u64 index = text.length; index && open == BUSTER_STRING_NO_MATCH; index -= 1)
    {
        open = text.pointer[index - 1] == '(' ? index - 1 : open;
    }
    if (open == BUSTER_STRING_NO_MATCH)
    {
        // In AT&T syntax '$' is the immediate marker.  Do not let the
        // expression grammar's '$'-prefixed identifiers turn it into an
        // absolute memory operand before the immediate path sees it.
        if (!text.length || text.pointer[0] == '$' || !assembly_expression_parse(builder, text, &result->displacement))
        {
            return false;
        }
        result->absolute = true;
        result->scale = 1;
        return true;
    }
    if (text.length < open + 2 || text.pointer[text.length - 1] != ')')
    {
        return false;
    }
    String8 displacement = assembly_trim(string_slice(text, 0, open));
    if (displacement.length && !assembly_expression_parse(builder, displacement, &result->displacement))
    {
        return false;
    }
    String8 address = string_slice(text, open + 1, text.length - 1);
    String8 fields[3] = {0};
    u32 field_count = 0;
    u64 field_start = 0;
    for (;;)
    {
        u64 field_end = field_start;
        while (field_end < address.length && address.pointer[field_end] != ',')
        {
            field_end += 1;
        }
        if (field_count >= BUSTER_ARRAY_LENGTH(fields))
        {
            return false;
        }
        fields[field_count++] = assembly_trim(string_slice(address, field_start, field_end));
        if (field_end == address.length)
        {
            break;
        }
        field_start = field_end + 1;
    }
    if (fields[0].length)
    {
        if (assembly_x86_rip_parse(fields[0], ASSEMBLY_SYNTAX_ATT))
        {
            result->rip_relative = true;
        }
        else if (!assembly_register_parse(fields[0], ASSEMBLY_SYNTAX_ATT, &result->base) ||
                 result->base.class != ASSEMBLY_REGISTER_GPR || (result->base.width != 32 && result->base.width != 64))
        {
            return false;
        }
        else
        {
            result->address_size = (u8)result->base.width;
            result->has_base = true;
        }
    }
    result->scale = 1;
    if (field_count >= 2 && fields[1].length)
    {
        if (result->rip_relative || !assembly_register_parse(fields[1], ASSEMBLY_SYNTAX_ATT, &result->index))
        {
            return false;
        }
        bool vector_index = result->index.class == ASSEMBLY_REGISTER_XMM || result->index.class == ASSEMBLY_REGISTER_YMM ||
                            result->index.class == ASSEMBLY_REGISTER_ZMM;
        if ((!vector_index && (result->index.class != ASSEMBLY_REGISTER_GPR ||
                               (result->index.width != 32 && result->index.width != 64) || result->index.index == 4)))
        {
            return false;
        }
        if (!vector_index)
        {
            if (result->address_size && result->address_size != result->index.width)
            {
                return false;
            }
            result->address_size = (u8)result->index.width;
        }
        result->has_index = true;
        result->vsib = vector_index;
    }
    if (field_count == 3 && fields[2].length && (!result->has_index || !assembly_x86_scale_parse(fields[2], &result->scale)))
    {
        return false;
    }
    return result->rip_relative || result->has_base || result->has_index;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_parse(AssemblyBuilder* builder, String8 text, AssemblySyntax syntax, AssemblyMemory* result)
{
    *result = (AssemblyMemory){0};
    return syntax == ASSEMBLY_SYNTAX_ATT ? assembly_x86_memory_parse_att(builder, text, result)
                                         : assembly_x86_memory_parse_intel(builder, text, result);
}

typedef struct AssemblyInstructionInfo AssemblyInstructionInfo;
struct AssemblyInstructionInfo
{
    AssemblyOpcode opcode;
    u8 operand_count;
    u8 suffix_width;
    u8 source_width;
    u8 condition;
    bool no_flags;
    AssemblyEncodingKind encoding_kind;
    u32 fixed_word;
    u32 aarch64_control_row_index;
    u32 aarch64_system_row_index;
    u32 aarch64_direct_simd_row_index;
    u32 aarch64_direct_simd_spelling_first;
    u8 aarch64_direct_simd_spelling_count;
    u8 aarch64_direct_simd_generated;
    u8 aarch64_direct_simd_requirement;
    BusterA64DirectSIMDArrangement aarch64_direct_simd_arrangements[4];
    u8 aarch64_direct_simd_fixed_field_kind;
    u8 aarch64_direct_simd_fixed_field_value;
    AssemblyAmdForm const* amd_form;
};

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_control_condition_parse(String8 text, u64* value)
{
    text = assembly_trim(text);
    if (value && text.length)
    {
        /* AArch64 spells conditions 2 and 3 as either CS/HS and CC/LO.  The
         * generated semantic table keeps one canonical name per encoding; accept
         * the architectural aliases at this shared textual boundary so control
         * instructions and direct-SIMD condition fields agree. */
        if (assembly_word_equal(text, S8("hs")))
        {
            *value = 2;
            return true;
        }
        if (assembly_word_equal(text, S8("lo")))
        {
            *value = 3;
            return true;
        }
        for (u32 index = 0; index < buster_aarch64_control_condition_count(); index += 1)
        {
            BusterAarch64ControlCondition condition = {0};
            String8 name = {0};
            if (buster_aarch64_control_condition((u8)index, &condition) &&
                buster_aarch64_control_semantic_string(condition.name, &name) && assembly_word_equal(text, name))
            {
                *value = index;
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_mnemonic_row(Target target, String8 mnemonic, u32* row)
{
    if (row && buster_aarch64_system_semantic_target_supported(target))
    {
        for (u32 index = 0; index < buster_aarch64_system_semantic_count(); index += 1)
        {
            BusterAarch64SystemSemanticRecord metadata = {0};
            String8 name = {0};
            if (buster_aarch64_system_semantic_row(index, &metadata) &&
                buster_aarch64_system_semantic_string(metadata.mnemonic, &name) && assembly_word_equal(mnemonic, name))
            {
                *row = index;
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_lookup(Target target, String8 mnemonic, AssemblyInstructionInfo* result)
{
    if (!result || !buster_aarch64_system_semantic_target_supported(target))
    {
        return false;
    }
    u32 row = UINT32_MAX;
    if (assembly_word_equal(mnemonic, S8("msr")))
    {
        *result = (AssemblyInstructionInfo){
            .opcode = ASSEMBLY_OPCODE_COUNT,
            .operand_count = 2,
            .encoding_kind = ASSEMBLY_ENCODING_AARCH64_SYSTEM_SEMANTICS,
            .aarch64_system_row_index = UINT32_MAX,
        };
        return true;
    }
    if (!assembly_aarch64_system_mnemonic_row(target, mnemonic, &row))
    {
        return false;
    }
    BusterAarch64SystemSemanticRecord metadata = {0};
    if (!buster_aarch64_system_semantic_row(row, &metadata))
    {
        return false;
    }
    *result = (AssemblyInstructionInfo){
        .opcode = ASSEMBLY_OPCODE_COUNT,
        .operand_count = metadata.field_count,
        .encoding_kind = ASSEMBLY_ENCODING_AARCH64_SYSTEM_SEMANTICS,
        .aarch64_system_row_index = row,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_register_lookup(Target target, String8 mnemonic, AssemblyInstructionInfo* result)
{
    bool supported = result && target.cpu_arch == CPU_ARCH_AARCH64 && target_cpu_features_are_valid(target) &&
                     (assembly_word_equal(mnemonic, S8("mrs")) || assembly_word_equal(mnemonic, S8("msr")));
    if (supported)
    {
        *result = (AssemblyInstructionInfo){
            .opcode = ASSEMBLY_OPCODE_COUNT,
            .operand_count = 2,
            .encoding_kind = ASSEMBLY_ENCODING_AARCH64_SYSTEM_REGISTER,
        };
    }
    return supported;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_fixed_row(Target target, String8 mnemonic, AssemblyInstructionInfo* result)
{
    if (!result || !buster_aarch64_arm_m1_fixed_target(target))
    {
        return false;
    }
    BusterAarch64ArmM1FixedSpelling fixed = {0};
    if (!buster_aarch64_arm_m1_fixed_lookup(mnemonic, &fixed) || !fixed.system ||
        !buster_aarch64_arm_m1_fixed_supported_for_target(fixed, target))
    {
        return false;
    }
    *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_COUNT, .encoding_kind = ASSEMBLY_ENCODING_AARCH64_FIXED_WORD,
                                       .fixed_word = fixed.word};
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_control_lookup(Target target, String8 mnemonic, AssemblyInstructionInfo* result)
{
    // These control, PC-relative and conditional-select forms are base A64;
    // the generated table's historical M1 provenance must not target-gate
    // inline assembly compiled for generic Linux, Darwin or Windows CPUs.
    if (result && target.cpu_arch == CPU_ARCH_AARCH64 && target_cpu_features_are_valid(target))
    {
        bool conditional = false;
        u64 condition = 0;
        if (mnemonic.length > 2 && assembly_word_equal(string_slice(mnemonic, 0, 2), S8("b.")))
        {
            conditional = assembly_aarch64_control_condition_parse(string_slice(mnemonic, 2, mnemonic.length), &condition);
            if (!conditional)
            {
                return false;
            }
        }
        for (u32 row_index = 0; row_index < buster_aarch64_control_semantic_count(); row_index += 1)
        {
            BusterAarch64ControlSemanticRecord row = {0};
            String8 row_mnemonic = {0};
            if (!buster_aarch64_control_semantic_row(row_index, &row) ||
                !buster_aarch64_control_semantic_string(row.mnemonic, &row_mnemonic))
            {
                continue;
            }
            if (row.form == BUSTER_AARCH64_CONTROL_FORM_B || row.form == BUSTER_AARCH64_CONTROL_FORM_BL ||
                row.form == BUSTER_AARCH64_CONTROL_FORM_RET)
            {
                continue;
            }
            bool mnemonic_match = conditional ? row.form == BUSTER_AARCH64_CONTROL_FORM_B_COND
                                              : assembly_word_equal(mnemonic, row_mnemonic);
            if (mnemonic_match)
            {
                *result = (AssemblyInstructionInfo){
                    .opcode = ASSEMBLY_OPCODE_COUNT,
                    .encoding_kind = ASSEMBLY_ENCODING_AARCH64_CONTROL,
                    .condition = (u8)condition,
                    .aarch64_control_row_index = UINT32_MAX,
                };
                return true;
            }
        }
    }

    return false;
}

typedef enum AssemblyAmdEncoding
{
    ASSEMBLY_AMD_ENCODING_XOP_VECTOR2,
    ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT,
    ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_IMMEDIATE,
    ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE,
    ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT,
    ASSEMBLY_AMD_ENCODING_VEX_VECTOR5_IMMEDIATE,
    ASSEMBLY_AMD_ENCODING_VEX_FMA4,
    ASSEMBLY_AMD_ENCODING_XOP_GPR2,
    ASSEMBLY_AMD_ENCODING_XOP_GPR3_BEXTR,
    ASSEMBLY_AMD_ENCODING_XOP_LWP1,
    ASSEMBLY_AMD_ENCODING_XOP_LWP3,
    ASSEMBLY_AMD_ENCODING_3DNOW2,
    ASSEMBLY_AMD_ENCODING_FEMMS,
} AssemblyAmdEncoding;

enum
{
    ASSEMBLY_AMD_FORM_SCALAR = 1u << 0,
    ASSEMBLY_AMD_FORM_DEFAULT_W1 = 1u << 1,
    ASSEMBLY_AMD_FORM_ALLOW_W1 = 1u << 2,
};

struct AssemblyAmdForm
{
    String8 name;
    AssemblyOpcode opcode;
    AssemblyAmdEncoding encoding;
    u8 operand_count;
    u8 vector_width_mask;
    u8 element_bytes;
    u8 flags;
    TargetCpuFeature feature;
};

BUSTER_GLOBAL_LOCAL AssemblyAmdForm const assembly_x86_amd_forms[] = {
    {.name = S8_INITIALIZER("vpermil2ps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_VEX_VECTOR5_IMMEDIATE, .operand_count = 5, .vector_width_mask = 3, .element_bytes = 4, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpermil2pd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_VEX_VECTOR5_IMMEDIATE, .operand_count = 5, .vector_width_mask = 3, .element_bytes = 8, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacssww"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacsswd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacssdql"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacsww"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacswd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacsdql"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcmov"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpperm"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmadcsswd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmadcswd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotb"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_IMMEDIATE, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 1, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_IMMEDIATE, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 2, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_IMMEDIATE, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 4, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_IMMEDIATE, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 8, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotb"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vprotq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacssdd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacssdqh"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacsdd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpmacsdqh"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomb"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 1, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 2, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 4, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 8, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomub"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 1, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomuw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 2, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomud"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 4, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpcomuq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 8, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vfrczps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 3, .element_bytes = 4, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vfrczpd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 3, .element_bytes = 8, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vfrczss"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_SCALAR, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vfrczsd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_SCALAR, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshlb"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshlw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshld"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshlq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddbw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddbd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddbq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddwd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddwq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddubw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddubd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddubq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphadduwd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphadduwq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphsubbw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphsubwd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphsubdq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshab"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshaw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshad"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vpshaq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT, .operand_count = 3, .vector_width_mask = 1, .element_bytes = 0, .flags = ASSEMBLY_AMD_FORM_ALLOW_W1, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphadddq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("vphaddudq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_VECTOR2, .operand_count = 2, .vector_width_mask = 1, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_XOP},
    {.name = S8_INITIALIZER("llwpcb"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_LWP1, .operand_count = 1, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_LWP},
    {.name = S8_INITIALIZER("slwpcb"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_LWP1, .operand_count = 1, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_LWP},
    {.name = S8_INITIALIZER("lwpins"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_LWP3, .operand_count = 3, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_LWP},
    {.name = S8_INITIALIZER("lwpval"), .opcode = ASSEMBLY_OPCODE_X86_AMD_XOP, .encoding = ASSEMBLY_AMD_ENCODING_XOP_LWP3, .operand_count = 3, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_LWP},
    {.name = S8_INITIALIZER("vfmaddsubps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmaddsubpd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmsubaddps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmsubaddpd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmaddps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmaddpd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmaddss"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmaddsd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmsubps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmsubpd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmsubss"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfmsubsd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmaddps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmaddpd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmaddss"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmaddsd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmsubps"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmsubpd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 3, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmsubss"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 4, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("vfnmsubsd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FMA4, .encoding = ASSEMBLY_AMD_ENCODING_VEX_FMA4, .operand_count = 4, .vector_width_mask = 1, .element_bytes = 8, .flags = ASSEMBLY_AMD_FORM_SCALAR | ASSEMBLY_AMD_FORM_DEFAULT_W1, .feature = TARGET_CPU_FEATURE_X86_FMA4},
    {.name = S8_INITIALIZER("bextr"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR3_BEXTR, .operand_count = 3, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("blcfill"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("blci"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("blcic"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("blcmsk"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("blcs"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("blsfill"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("blsic"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("t1mskc"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("tzmsk"), .opcode = ASSEMBLY_OPCODE_X86_AMD_TBM, .encoding = ASSEMBLY_AMD_ENCODING_XOP_GPR2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_TBM},
    {.name = S8_INITIALIZER("femms"), .opcode = ASSEMBLY_OPCODE_X86_AMD_FEMMS, .encoding = ASSEMBLY_AMD_ENCODING_FEMMS, .operand_count = 0, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pi2fw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOWA},
    {.name = S8_INITIALIZER("pi2fd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pf2iw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOWA},
    {.name = S8_INITIALIZER("pf2id"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfnacc"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOWA},
    {.name = S8_INITIALIZER("pfpnacc"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOWA},
    {.name = S8_INITIALIZER("pfcmpge"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfmin"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfrcp"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfrsqrt"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfsub"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfadd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfcmpgt"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfmax"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfrcpit1"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfrsqit1"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfsubr"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfacc"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfcmpeq"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfmul"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pfrcpit2"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pmulhrw"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
    {.name = S8_INITIALIZER("pswapd"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOWA},
    {.name = S8_INITIALIZER("pavgusb"), .opcode = ASSEMBLY_OPCODE_X86_AMD_3DNOW, .encoding = ASSEMBLY_AMD_ENCODING_3DNOW2, .operand_count = 2, .vector_width_mask = 0, .element_bytes = 0, .flags = 0, .feature = TARGET_CPU_FEATURE_X86_3DNOW},
};

BUSTER_GLOBAL_LOCAL AssemblyAmdForm const* assembly_x86_amd_form_lookup(String8 mnemonic)
{
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(assembly_x86_amd_forms); index += 1)
    {
        if (assembly_word_equal(mnemonic, assembly_x86_amd_forms[index].name))
        {
            return assembly_x86_amd_forms + index;
        }
    }
    return 0;
}

BUSTER_GLOBAL_LOCAL AssemblyAmdForm const* assembly_x86_amd_form_select(AssemblyInstruction* instruction)
{
    AssemblyAmdForm const* form = instruction->amd_form;
    if (form && form->encoding == ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_IMMEDIATE && instruction->operand_count == 3 &&
        instruction->operands[2].kind != ASSEMBLY_OPERAND_EXPRESSION)
    {
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(assembly_x86_amd_forms); index += 1)
        {
            AssemblyAmdForm const* candidate = assembly_x86_amd_forms + index;
            if (candidate->encoding == ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT &&
                assembly_word_equal(instruction->amd_mnemonic, candidate->name))
            {
                return candidate;
            }
        }
    }
    return form;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_condition_parse(String8 name, u8* result)
{
    static const struct
    {
        String8 name;
        u8 condition;
    } conditions[] = {
        {S8_INITIALIZER("o"), 0},   {S8_INITIALIZER("no"), 1},  {S8_INITIALIZER("b"), 2},   {S8_INITIALIZER("c"), 2},
        {S8_INITIALIZER("nae"), 2}, {S8_INITIALIZER("ae"), 3},  {S8_INITIALIZER("nb"), 3},  {S8_INITIALIZER("nc"), 3},
        {S8_INITIALIZER("e"), 4},   {S8_INITIALIZER("z"), 4},   {S8_INITIALIZER("ne"), 5},  {S8_INITIALIZER("nz"), 5},
        {S8_INITIALIZER("be"), 6},  {S8_INITIALIZER("na"), 6},  {S8_INITIALIZER("a"), 7},   {S8_INITIALIZER("nbe"), 7},
        {S8_INITIALIZER("s"), 8},   {S8_INITIALIZER("ns"), 9},  {S8_INITIALIZER("p"), 10},  {S8_INITIALIZER("pe"), 10},
        {S8_INITIALIZER("np"), 11}, {S8_INITIALIZER("po"), 11}, {S8_INITIALIZER("l"), 12},  {S8_INITIALIZER("nge"), 12},
        {S8_INITIALIZER("ge"), 13}, {S8_INITIALIZER("nl"), 13}, {S8_INITIALIZER("le"), 14}, {S8_INITIALIZER("ng"), 14},
        {S8_INITIALIZER("g"), 15},  {S8_INITIALIZER("nle"), 15},
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(conditions); index += 1)
    {
        if (assembly_word_equal(name, conditions[index].name))
        {
            *result = conditions[index].condition;
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_lookup_exact(String8 mnemonic, AssemblyInstructionInfo* result)
{
    AssemblyAmdForm const* amd_form = assembly_x86_amd_form_lookup(mnemonic);
    if (amd_form)
    {
        *result = (AssemblyInstructionInfo){.opcode = amd_form->opcode, .operand_count = amd_form->operand_count, .amd_form = amd_form};
        return true;
    }
    static const struct
    {
        String8 name;
        AssemblyOpcode opcode;
        u8 operand_count;
    } instructions[] = {
        {S8_INITIALIZER("nop"), ASSEMBLY_OPCODE_X86_NOP, 0},       {S8_INITIALIZER("ret"), ASSEMBLY_OPCODE_X86_RET, 0},
        {S8_INITIALIZER("int3"), ASSEMBLY_OPCODE_X86_INT3, 0},    {S8_INITIALIZER("call"), ASSEMBLY_OPCODE_X86_CALL, 1},
        {S8_INITIALIZER("jmp"), ASSEMBLY_OPCODE_X86_JMP, 1},      {S8_INITIALIZER("mov"), ASSEMBLY_OPCODE_X86_MOV, 2},
        {S8_INITIALIZER("add"), ASSEMBLY_OPCODE_X86_ADD, 2},      {S8_INITIALIZER("adc"), ASSEMBLY_OPCODE_X86_ADC, 2},
        {S8_INITIALIZER("sub"), ASSEMBLY_OPCODE_X86_SUB, 2},      {S8_INITIALIZER("sbb"), ASSEMBLY_OPCODE_X86_SBB, 2},
        {S8_INITIALIZER("and"), ASSEMBLY_OPCODE_X86_AND, 2},      {S8_INITIALIZER("or"), ASSEMBLY_OPCODE_X86_OR, 2},
        {S8_INITIALIZER("xor"), ASSEMBLY_OPCODE_X86_XOR, 2},      {S8_INITIALIZER("cmp"), ASSEMBLY_OPCODE_X86_CMP, 2},
        {S8_INITIALIZER("test"), ASSEMBLY_OPCODE_X86_TEST, 2},    {S8_INITIALIZER("imul"), ASSEMBLY_OPCODE_X86_IMUL, 2},
        {S8_INITIALIZER("mul"), ASSEMBLY_OPCODE_X86_MUL, 1},      {S8_INITIALIZER("div"), ASSEMBLY_OPCODE_X86_DIV, 1},
        {S8_INITIALIZER("idiv"), ASSEMBLY_OPCODE_X86_IDIV, 1},
        {S8_INITIALIZER("push"), ASSEMBLY_OPCODE_X86_PUSH, 1},    {S8_INITIALIZER("pop"), ASSEMBLY_OPCODE_X86_POP, 1},
        {S8_INITIALIZER("inc"), ASSEMBLY_OPCODE_X86_INC, 1},      {S8_INITIALIZER("dec"), ASSEMBLY_OPCODE_X86_DEC, 1},
        {S8_INITIALIZER("neg"), ASSEMBLY_OPCODE_X86_NEG, 1},      {S8_INITIALIZER("not"), ASSEMBLY_OPCODE_X86_NOT, 1},
        {S8_INITIALIZER("shl"), ASSEMBLY_OPCODE_X86_SHL, 2},      {S8_INITIALIZER("sal"), ASSEMBLY_OPCODE_X86_SHL, 2},
        {S8_INITIALIZER("shr"), ASSEMBLY_OPCODE_X86_SHR, 2},      {S8_INITIALIZER("sar"), ASSEMBLY_OPCODE_X86_SAR, 2},
        {S8_INITIALIZER("lea"), ASSEMBLY_OPCODE_X86_LEA, 2},      {S8_INITIALIZER("movzx"), ASSEMBLY_OPCODE_X86_MOVZX, 2},
        {S8_INITIALIZER("movsx"), ASSEMBLY_OPCODE_X86_MOVSX, 2},  {S8_INITIALIZER("movsxd"), ASSEMBLY_OPCODE_X86_MOVSXD, 2},
        {S8_INITIALIZER("rol"), ASSEMBLY_OPCODE_X86_ROL, 2},      {S8_INITIALIZER("ror"), ASSEMBLY_OPCODE_X86_ROR, 2},
        {S8_INITIALIZER("rcl"), ASSEMBLY_OPCODE_X86_RCL, 2},      {S8_INITIALIZER("rcr"), ASSEMBLY_OPCODE_X86_RCR, 2},
        {S8_INITIALIZER("shld"), ASSEMBLY_OPCODE_X86_SHLD, 3},    {S8_INITIALIZER("shrd"), ASSEMBLY_OPCODE_X86_SHRD, 3},
        {S8_INITIALIZER("bsf"), ASSEMBLY_OPCODE_X86_BSF, 2},      {S8_INITIALIZER("bsr"), ASSEMBLY_OPCODE_X86_BSR, 2},
        {S8_INITIALIZER("bswap"), ASSEMBLY_OPCODE_X86_BSWAP, 1},
        {S8_INITIALIZER("bt"), ASSEMBLY_OPCODE_X86_BT, 2},        {S8_INITIALIZER("btc"), ASSEMBLY_OPCODE_X86_BTC, 2},
        {S8_INITIALIZER("btr"), ASSEMBLY_OPCODE_X86_BTR, 2},      {S8_INITIALIZER("bts"), ASSEMBLY_OPCODE_X86_BTS, 2},
        {S8_INITIALIZER("xchg"), ASSEMBLY_OPCODE_X86_XCHG, 2},    {S8_INITIALIZER("xadd"), ASSEMBLY_OPCODE_X86_XADD, 2},
        {S8_INITIALIZER("cmpxchg"), ASSEMBLY_OPCODE_X86_CMPXCHG, 2},
        {S8_INITIALIZER("cmpxchg8b"), ASSEMBLY_OPCODE_X86_CMPXCHG8B, 1},
        {S8_INITIALIZER("cmpxchg16b"), ASSEMBLY_OPCODE_X86_CMPXCHG16B, 1},
        {S8_INITIALIZER("popcnt"), ASSEMBLY_OPCODE_X86_POPCNT, 2},
        {S8_INITIALIZER("lzcnt"), ASSEMBLY_OPCODE_X86_LZCNT, 2},
        {S8_INITIALIZER("tzcnt"), ASSEMBLY_OPCODE_X86_TZCNT, 2},
        {S8_INITIALIZER("cbw"), ASSEMBLY_OPCODE_X86_CBW, 0},      {S8_INITIALIZER("cwde"), ASSEMBLY_OPCODE_X86_CWDE, 0},
        {S8_INITIALIZER("cdqe"), ASSEMBLY_OPCODE_X86_CDQE, 0},    {S8_INITIALIZER("cbtw"), ASSEMBLY_OPCODE_X86_CBW, 0},
        {S8_INITIALIZER("cwtl"), ASSEMBLY_OPCODE_X86_CWDE, 0},    {S8_INITIALIZER("cltq"), ASSEMBLY_OPCODE_X86_CDQE, 0},
        {S8_INITIALIZER("cwd"), ASSEMBLY_OPCODE_X86_CWD, 0},      {S8_INITIALIZER("cdq"), ASSEMBLY_OPCODE_X86_CDQ, 0},
        {S8_INITIALIZER("cqo"), ASSEMBLY_OPCODE_X86_CQO, 0},      {S8_INITIALIZER("cwtd"), ASSEMBLY_OPCODE_X86_CWD, 0},
        {S8_INITIALIZER("cltd"), ASSEMBLY_OPCODE_X86_CDQ, 0},     {S8_INITIALIZER("cqto"), ASSEMBLY_OPCODE_X86_CQO, 0},
        {S8_INITIALIZER("movaps"), ASSEMBLY_OPCODE_X86_MOVAPS, 2}, {S8_INITIALIZER("movups"), ASSEMBLY_OPCODE_X86_MOVUPS, 2},
        {S8_INITIALIZER("movapd"), ASSEMBLY_OPCODE_X86_MOVAPD, 2}, {S8_INITIALIZER("movupd"), ASSEMBLY_OPCODE_X86_MOVUPD, 2},
        {S8_INITIALIZER("movdqa"), ASSEMBLY_OPCODE_X86_MOVDQA, 2}, {S8_INITIALIZER("movdqu"), ASSEMBLY_OPCODE_X86_MOVDQU, 2},
        {S8_INITIALIZER("xorps"), ASSEMBLY_OPCODE_X86_XORPS, 2},   {S8_INITIALIZER("xorpd"), ASSEMBLY_OPCODE_X86_XORPD, 2},
        {S8_INITIALIZER("pxor"), ASSEMBLY_OPCODE_X86_PXOR_MMX, 2}, {S8_INITIALIZER("addps"), ASSEMBLY_OPCODE_X86_ADDPS, 2},
        {S8_INITIALIZER("addpd"), ASSEMBLY_OPCODE_X86_ADDPD, 2},   {S8_INITIALIZER("addss"), ASSEMBLY_OPCODE_X86_ADDSS, 2},
        {S8_INITIALIZER("addsd"), ASSEMBLY_OPCODE_X86_ADDSD, 2},   {S8_INITIALIZER("subps"), ASSEMBLY_OPCODE_X86_SUBPS, 2},
        {S8_INITIALIZER("subpd"), ASSEMBLY_OPCODE_X86_SUBPD, 2},   {S8_INITIALIZER("mulps"), ASSEMBLY_OPCODE_X86_MULPS, 2},
        {S8_INITIALIZER("mulpd"), ASSEMBLY_OPCODE_X86_MULPD, 2},   {S8_INITIALIZER("divps"), ASSEMBLY_OPCODE_X86_DIVPS, 2},
        {S8_INITIALIZER("divpd"), ASSEMBLY_OPCODE_X86_DIVPD, 2},
        {S8_INITIALIZER("vmovaps"), ASSEMBLY_OPCODE_X86_VMOVAPS, 2}, {S8_INITIALIZER("vmovups"), ASSEMBLY_OPCODE_X86_VMOVUPS, 2},
        {S8_INITIALIZER("vmovapd"), ASSEMBLY_OPCODE_X86_VMOVAPD, 2}, {S8_INITIALIZER("vmovupd"), ASSEMBLY_OPCODE_X86_VMOVUPD, 2},
        {S8_INITIALIZER("vxorps"), ASSEMBLY_OPCODE_X86_VXORPS, 3},   {S8_INITIALIZER("vxorpd"), ASSEMBLY_OPCODE_X86_VXORPD, 3},
        {S8_INITIALIZER("vaddps"), ASSEMBLY_OPCODE_X86_VADDPS, 3},   {S8_INITIALIZER("vaddpd"), ASSEMBLY_OPCODE_X86_VADDPD, 3},
        {S8_INITIALIZER("vaddss"), ASSEMBLY_OPCODE_X86_VADDSS, 3},   {S8_INITIALIZER("vaddsd"), ASSEMBLY_OPCODE_X86_VADDSD, 3},
        {S8_INITIALIZER("vsubps"), ASSEMBLY_OPCODE_X86_VSUBPS, 3},   {S8_INITIALIZER("vsubpd"), ASSEMBLY_OPCODE_X86_VSUBPD, 3},
        {S8_INITIALIZER("vmulps"), ASSEMBLY_OPCODE_X86_VMULPS, 3},   {S8_INITIALIZER("vmulpd"), ASSEMBLY_OPCODE_X86_VMULPD, 3},
        {S8_INITIALIZER("vdivps"), ASSEMBLY_OPCODE_X86_VDIVPS, 3},   {S8_INITIALIZER("vdivpd"), ASSEMBLY_OPCODE_X86_VDIVPD, 3},
        {S8_INITIALIZER("vmovdqa"), ASSEMBLY_OPCODE_X86_VMOVDQA, 2}, {S8_INITIALIZER("vmovdqu"), ASSEMBLY_OPCODE_X86_VMOVDQU, 2},
        {S8_INITIALIZER("vpaddb"), ASSEMBLY_OPCODE_X86_VPADDB, 3},   {S8_INITIALIZER("vpaddw"), ASSEMBLY_OPCODE_X86_VPADDW, 3},
        {S8_INITIALIZER("vpaddd"), ASSEMBLY_OPCODE_X86_VPADDD, 3},   {S8_INITIALIZER("vpaddq"), ASSEMBLY_OPCODE_X86_VPADDQ, 3},
        {S8_INITIALIZER("vpsubb"), ASSEMBLY_OPCODE_X86_VPSUBB, 3},   {S8_INITIALIZER("vpsubw"), ASSEMBLY_OPCODE_X86_VPSUBW, 3},
        {S8_INITIALIZER("vpsubd"), ASSEMBLY_OPCODE_X86_VPSUBD, 3},   {S8_INITIALIZER("vpsubq"), ASSEMBLY_OPCODE_X86_VPSUBQ, 3},
        {S8_INITIALIZER("vpand"), ASSEMBLY_OPCODE_X86_VPAND, 3},     {S8_INITIALIZER("vpor"), ASSEMBLY_OPCODE_X86_VPOR, 3},
        {S8_INITIALIZER("vpxor"), ASSEMBLY_OPCODE_X86_VPXOR, 3},     {S8_INITIALIZER("vpcmpeqb"), ASSEMBLY_OPCODE_X86_VPCMPEQB, 3},
        {S8_INITIALIZER("vpcmpeqw"), ASSEMBLY_OPCODE_X86_VPCMPEQW, 3}, {S8_INITIALIZER("vpcmpeqd"), ASSEMBLY_OPCODE_X86_VPCMPEQD, 3},
        {S8_INITIALIZER("vpcmpeqq"), ASSEMBLY_OPCODE_X86_VPCMPEQQ, 3}, {S8_INITIALIZER("vpcmpgtb"), ASSEMBLY_OPCODE_X86_VPCMPGTB, 3},
        {S8_INITIALIZER("vpcmpgtw"), ASSEMBLY_OPCODE_X86_VPCMPGTW, 3}, {S8_INITIALIZER("vpcmpgtd"), ASSEMBLY_OPCODE_X86_VPCMPGTD, 3},
        {S8_INITIALIZER("vpcmpgtq"), ASSEMBLY_OPCODE_X86_VPCMPGTQ, 3}, {S8_INITIALIZER("vpmullw"), ASSEMBLY_OPCODE_X86_VPMULLW, 3},
        {S8_INITIALIZER("vpmulld"), ASSEMBLY_OPCODE_X86_VPMULLD, 3},
        {S8_INITIALIZER("vmovdqa32"), ASSEMBLY_OPCODE_X86_VMOVDQA32, 2},
        {S8_INITIALIZER("vmovdqu32"), ASSEMBLY_OPCODE_X86_VMOVDQU32, 2},
        {S8_INITIALIZER("vmovdqa64"), ASSEMBLY_OPCODE_X86_VMOVDQA64, 2},
        {S8_INITIALIZER("vmovdqu64"), ASSEMBLY_OPCODE_X86_VMOVDQU64, 2},
        {S8_INITIALIZER("vmovdqu8"), ASSEMBLY_OPCODE_X86_VMOVDQU8, 2},
        {S8_INITIALIZER("vmovdqu16"), ASSEMBLY_OPCODE_X86_VMOVDQU16, 2},
        {S8_INITIALIZER("vcmpps"), ASSEMBLY_OPCODE_X86_VCMPPS, 4},
        {S8_INITIALIZER("vcmppd"), ASSEMBLY_OPCODE_X86_VCMPPD, 4},
        {S8_INITIALIZER("vpcmpd"), ASSEMBLY_OPCODE_X86_VPCMPD, 4},
        {S8_INITIALIZER("vpcmpq"), ASSEMBLY_OPCODE_X86_VPCMPQ, 4},
        {S8_INITIALIZER("vpcmpb"), ASSEMBLY_OPCODE_X86_VPCMPB, 4},
        {S8_INITIALIZER("vpcmpw"), ASSEMBLY_OPCODE_X86_VPCMPW, 4},
        {S8_INITIALIZER("vpcmpud"), ASSEMBLY_OPCODE_X86_VPCMPUD, 4},
        {S8_INITIALIZER("vpcmpuq"), ASSEMBLY_OPCODE_X86_VPCMPUQ, 4},
        {S8_INITIALIZER("vrndscaleps"), ASSEMBLY_OPCODE_X86_VRNDSCALEPS, 3},
        {S8_INITIALIZER("vrndscalepd"), ASSEMBLY_OPCODE_X86_VRNDSCALEPD, 3},
        {S8_INITIALIZER("kmovw"), ASSEMBLY_OPCODE_X86_KMOVW, 2},
        {S8_INITIALIZER("kmovd"), ASSEMBLY_OPCODE_X86_KMOVD, 2},
        {S8_INITIALIZER("kmovq"), ASSEMBLY_OPCODE_X86_KMOVQ, 2},
        {S8_INITIALIZER("kaddw"), ASSEMBLY_OPCODE_X86_KADDW, 3},
        {S8_INITIALIZER("kandw"), ASSEMBLY_OPCODE_X86_KANDW, 3},
        {S8_INITIALIZER("korw"), ASSEMBLY_OPCODE_X86_KORW, 3},
        {S8_INITIALIZER("kxorw"), ASSEMBLY_OPCODE_X86_KXORW, 3},
        {S8_INITIALIZER("knotw"), ASSEMBLY_OPCODE_X86_KNOTW, 2},
        {S8_INITIALIZER("kortestw"), ASSEMBLY_OPCODE_X86_KORTESTW, 2},
        {S8_INITIALIZER("push2"), ASSEMBLY_OPCODE_X86_APX_PUSH2, 2},
        {S8_INITIALIZER("pop2"), ASSEMBLY_OPCODE_X86_APX_POP2, 2},
        {S8_INITIALIZER("ldtilecfg"), ASSEMBLY_OPCODE_X86_LDTILECFG, 1},
        {S8_INITIALIZER("sttilecfg"), ASSEMBLY_OPCODE_X86_STTILECFG, 1},
        {S8_INITIALIZER("tileloadd"), ASSEMBLY_OPCODE_X86_TILELOADD, 2},
        {S8_INITIALIZER("tileloaddt1"), ASSEMBLY_OPCODE_X86_TILELOADDT1, 2},
        {S8_INITIALIZER("tilestored"), ASSEMBLY_OPCODE_X86_TILESTORED, 2},
        {S8_INITIALIZER("tilezero"), ASSEMBLY_OPCODE_X86_TILEZERO, 1},
        {S8_INITIALIZER("tdpbf16ps"), ASSEMBLY_OPCODE_X86_TDPBF16PS, 3},
        {S8_INITIALIZER("tdpbssd"), ASSEMBLY_OPCODE_X86_TDPBSSD, 3},
        {S8_INITIALIZER("tdpbsud"), ASSEMBLY_OPCODE_X86_TDPBSUD, 3},
        {S8_INITIALIZER("tdpbusd"), ASSEMBLY_OPCODE_X86_TDPBUSD, 3},
        {S8_INITIALIZER("tdpbuud"), ASSEMBLY_OPCODE_X86_TDPBUUD, 3},
        {S8_INITIALIZER("emms"), ASSEMBLY_OPCODE_X86_EMMS, 0},
        {S8_INITIALIZER("paddb"), ASSEMBLY_OPCODE_X86_PADDB_MMX, 2}, {S8_INITIALIZER("paddw"), ASSEMBLY_OPCODE_X86_PADDW_MMX, 2},
        {S8_INITIALIZER("paddd"), ASSEMBLY_OPCODE_X86_PADDD_MMX, 2}, {S8_INITIALIZER("paddq"), ASSEMBLY_OPCODE_X86_PADDQ_MMX, 2},
        {S8_INITIALIZER("psubb"), ASSEMBLY_OPCODE_X86_PSUBB_MMX, 2}, {S8_INITIALIZER("psubw"), ASSEMBLY_OPCODE_X86_PSUBW_MMX, 2},
        {S8_INITIALIZER("psubd"), ASSEMBLY_OPCODE_X86_PSUBD_MMX, 2}, {S8_INITIALIZER("psubq"), ASSEMBLY_OPCODE_X86_PSUBQ_MMX, 2},
        {S8_INITIALIZER("pand"), ASSEMBLY_OPCODE_X86_PAND_MMX, 2},   {S8_INITIALIZER("por"), ASSEMBLY_OPCODE_X86_POR_MMX, 2},
        {S8_INITIALIZER("pcmpeqb"), ASSEMBLY_OPCODE_X86_PCMPEQB_MMX, 2},
        {S8_INITIALIZER("pcmpeqw"), ASSEMBLY_OPCODE_X86_PCMPEQW_MMX, 2},
        {S8_INITIALIZER("pcmpeqd"), ASSEMBLY_OPCODE_X86_PCMPEQD_MMX, 2},
        {S8_INITIALIZER("pcmpgtb"), ASSEMBLY_OPCODE_X86_PCMPGTB_MMX, 2},
        {S8_INITIALIZER("pcmpgtw"), ASSEMBLY_OPCODE_X86_PCMPGTW_MMX, 2},
        {S8_INITIALIZER("pcmpgtd"), ASSEMBLY_OPCODE_X86_PCMPGTD_MMX, 2},
        {S8_INITIALIZER("pmullw"), ASSEMBLY_OPCODE_X86_PMULLW_MMX, 2},
        {S8_INITIALIZER("fld"), ASSEMBLY_OPCODE_X86_FLD, 1},       {S8_INITIALIZER("fst"), ASSEMBLY_OPCODE_X86_FST, 1},
        {S8_INITIALIZER("fstp"), ASSEMBLY_OPCODE_X86_FSTP, 1},     {S8_INITIALIZER("fild"), ASSEMBLY_OPCODE_X86_FILD, 1},
        {S8_INITIALIZER("fist"), ASSEMBLY_OPCODE_X86_FIST, 1},     {S8_INITIALIZER("fistp"), ASSEMBLY_OPCODE_X86_FISTP, 1},
        {S8_INITIALIZER("fisttp"), ASSEMBLY_OPCODE_X86_FISTTP, 1},
        {S8_INITIALIZER("fadd"), ASSEMBLY_OPCODE_X86_FADD, 2},     {S8_INITIALIZER("fmul"), ASSEMBLY_OPCODE_X86_FMUL, 2},
        {S8_INITIALIZER("fsub"), ASSEMBLY_OPCODE_X86_FSUB, 2},     {S8_INITIALIZER("fsubr"), ASSEMBLY_OPCODE_X86_FSUBR, 2},
        {S8_INITIALIZER("fdiv"), ASSEMBLY_OPCODE_X86_FDIV, 2},     {S8_INITIALIZER("fdivr"), ASSEMBLY_OPCODE_X86_FDIVR, 2},
        {S8_INITIALIZER("faddp"), ASSEMBLY_OPCODE_X86_FADDP, 2},   {S8_INITIALIZER("fmulp"), ASSEMBLY_OPCODE_X86_FMULP, 2},
        {S8_INITIALIZER("fsubp"), ASSEMBLY_OPCODE_X86_FSUBP, 2},   {S8_INITIALIZER("fsubrp"), ASSEMBLY_OPCODE_X86_FSUBRP, 2},
        {S8_INITIALIZER("fdivp"), ASSEMBLY_OPCODE_X86_FDIVP, 2},   {S8_INITIALIZER("fdivrp"), ASSEMBLY_OPCODE_X86_FDIVRP, 2},
        {S8_INITIALIZER("fxch"), ASSEMBLY_OPCODE_X86_FXCH, 1},     {S8_INITIALIZER("f2xm1"), ASSEMBLY_OPCODE_X86_F2XM1, 0},
        {S8_INITIALIZER("fcom"), ASSEMBLY_OPCODE_X86_FCOM, 1},     {S8_INITIALIZER("fcomp"), ASSEMBLY_OPCODE_X86_FCOMP, 1},
        {S8_INITIALIZER("fcompp"), ASSEMBLY_OPCODE_X86_FCOMPP, 0}, {S8_INITIALIZER("fucom"), ASSEMBLY_OPCODE_X86_FUCOM, 1},
        {S8_INITIALIZER("fucomp"), ASSEMBLY_OPCODE_X86_FUCOMP, 1}, {S8_INITIALIZER("fucompp"), ASSEMBLY_OPCODE_X86_FUCOMPP, 0},
        {S8_INITIALIZER("fcomi"), ASSEMBLY_OPCODE_X86_FCOMI, 2},   {S8_INITIALIZER("fcomip"), ASSEMBLY_OPCODE_X86_FCOMIP, 2},
        {S8_INITIALIZER("fcompi"), ASSEMBLY_OPCODE_X86_FCOMIP, 2}, {S8_INITIALIZER("fucomi"), ASSEMBLY_OPCODE_X86_FUCOMI, 2},
        {S8_INITIALIZER("fucomip"), ASSEMBLY_OPCODE_X86_FUCOMIP, 2}, {S8_INITIALIZER("fucompi"), ASSEMBLY_OPCODE_X86_FUCOMIP, 2},
        {S8_INITIALIZER("fiadd"), ASSEMBLY_OPCODE_X86_FIADD, 1},   {S8_INITIALIZER("fimul"), ASSEMBLY_OPCODE_X86_FIMUL, 1},
        {S8_INITIALIZER("fisub"), ASSEMBLY_OPCODE_X86_FISUB, 1},   {S8_INITIALIZER("fisubr"), ASSEMBLY_OPCODE_X86_FISUBR, 1},
        {S8_INITIALIZER("fidiv"), ASSEMBLY_OPCODE_X86_FIDIV, 1},   {S8_INITIALIZER("fidivr"), ASSEMBLY_OPCODE_X86_FIDIVR, 1},
        {S8_INITIALIZER("fbld"), ASSEMBLY_OPCODE_X86_FBLD, 1},     {S8_INITIALIZER("fbstp"), ASSEMBLY_OPCODE_X86_FBSTP, 1},
        {S8_INITIALIZER("fldcw"), ASSEMBLY_OPCODE_X86_FLDCW, 1},   {S8_INITIALIZER("fnstcw"), ASSEMBLY_OPCODE_X86_FNSTCW, 1},
        {S8_INITIALIZER("fstcw"), ASSEMBLY_OPCODE_X86_FSTCW, 1},   {S8_INITIALIZER("fldenv"), ASSEMBLY_OPCODE_X86_FLDENV, 1},
        {S8_INITIALIZER("fnstenv"), ASSEMBLY_OPCODE_X86_FNSTENV, 1}, {S8_INITIALIZER("fstenv"), ASSEMBLY_OPCODE_X86_FSTENV, 1},
        {S8_INITIALIZER("frstor"), ASSEMBLY_OPCODE_X86_FRSTOR, 1}, {S8_INITIALIZER("fnsave"), ASSEMBLY_OPCODE_X86_FNSAVE, 1},
        {S8_INITIALIZER("fsave"), ASSEMBLY_OPCODE_X86_FSAVE, 1},   {S8_INITIALIZER("fnstsw"), ASSEMBLY_OPCODE_X86_FNSTSW, 1},
        {S8_INITIALIZER("fstsw"), ASSEMBLY_OPCODE_X86_FSTSW, 1},   {S8_INITIALIZER("ffree"), ASSEMBLY_OPCODE_X86_FFREE, 1},
        {S8_INITIALIZER("ffreep"), ASSEMBLY_OPCODE_X86_FFREEP, 1}, {S8_INITIALIZER("fincstp"), ASSEMBLY_OPCODE_X86_FINCSTP, 0},
        {S8_INITIALIZER("fdecstp"), ASSEMBLY_OPCODE_X86_FDECSTP, 0},
        {S8_INITIALIZER("fabs"), ASSEMBLY_OPCODE_X86_FABS, 0},     {S8_INITIALIZER("fchs"), ASSEMBLY_OPCODE_X86_FCHS, 0},
        {S8_INITIALIZER("fld1"), ASSEMBLY_OPCODE_X86_FLD1, 0},     {S8_INITIALIZER("fldz"), ASSEMBLY_OPCODE_X86_FLDZ, 0},
        {S8_INITIALIZER("fldpi"), ASSEMBLY_OPCODE_X86_FLDPI, 0},   {S8_INITIALIZER("fldl2e"), ASSEMBLY_OPCODE_X86_FLDL2E, 0},
        {S8_INITIALIZER("fldl2t"), ASSEMBLY_OPCODE_X86_FLDL2T, 0}, {S8_INITIALIZER("fldlg2"), ASSEMBLY_OPCODE_X86_FLDLG2, 0},
        {S8_INITIALIZER("fldln2"), ASSEMBLY_OPCODE_X86_FLDLN2, 0}, {S8_INITIALIZER("fsqrt"), ASSEMBLY_OPCODE_X86_FSQRT, 0},
        {S8_INITIALIZER("fsin"), ASSEMBLY_OPCODE_X86_FSIN, 0},     {S8_INITIALIZER("fcos"), ASSEMBLY_OPCODE_X86_FCOS, 0},
        {S8_INITIALIZER("fsincos"), ASSEMBLY_OPCODE_X86_FSINCOS, 0}, {S8_INITIALIZER("fptan"), ASSEMBLY_OPCODE_X86_FPTAN, 0},
        {S8_INITIALIZER("fpatan"), ASSEMBLY_OPCODE_X86_FPATAN, 0}, {S8_INITIALIZER("fyl2x"), ASSEMBLY_OPCODE_X86_FYL2X, 0},
        {S8_INITIALIZER("fyl2xp1"), ASSEMBLY_OPCODE_X86_FYL2XP1, 0}, {S8_INITIALIZER("frndint"), ASSEMBLY_OPCODE_X86_FRNDINT, 0},
        {S8_INITIALIZER("fscale"), ASSEMBLY_OPCODE_X86_FSCALE, 0}, {S8_INITIALIZER("fprem"), ASSEMBLY_OPCODE_X86_FPREM, 0},
        {S8_INITIALIZER("fprem1"), ASSEMBLY_OPCODE_X86_FPREM1, 0}, {S8_INITIALIZER("fxtract"), ASSEMBLY_OPCODE_X86_FXTRACT, 0},
        {S8_INITIALIZER("ftst"), ASSEMBLY_OPCODE_X86_FTST, 0},     {S8_INITIALIZER("fxam"), ASSEMBLY_OPCODE_X86_FXAM, 0},
        {S8_INITIALIZER("fnop"), ASSEMBLY_OPCODE_X86_FNOP, 0},     {S8_INITIALIZER("finit"), ASSEMBLY_OPCODE_X86_FINIT, 0},
        {S8_INITIALIZER("fninit"), ASSEMBLY_OPCODE_X86_FNINIT, 0}, {S8_INITIALIZER("fclex"), ASSEMBLY_OPCODE_X86_FCLEX, 0},
        {S8_INITIALIZER("fnclex"), ASSEMBLY_OPCODE_X86_FNCLEX, 0}, {S8_INITIALIZER("fwait"), ASSEMBLY_OPCODE_X86_FWAIT, 0},
        {S8_INITIALIZER("wait"), ASSEMBLY_OPCODE_X86_FWAIT, 0},
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(instructions); index += 1)
    {
        if (assembly_word_equal(mnemonic, instructions[index].name))
        {
            *result = (AssemblyInstructionInfo){.opcode = instructions[index].opcode, .operand_count = instructions[index].operand_count};
            return true;
        }
    }
    static String8 const x87_move_conditions[] = {
        S8_INITIALIZER("b"), S8_INITIALIZER("e"), S8_INITIALIZER("be"), S8_INITIALIZER("u"),
        S8_INITIALIZER("nb"), S8_INITIALIZER("ne"), S8_INITIALIZER("nbe"), S8_INITIALIZER("nu"),
    };
    String8 fcmov_prefix = S8("fcmov");
    if (mnemonic.length > fcmov_prefix.length &&
        assembly_word_equal(string_slice(mnemonic, 0, fcmov_prefix.length), fcmov_prefix))
    {
        String8 condition = string_slice(mnemonic, fcmov_prefix.length, mnemonic.length);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(x87_move_conditions); index += 1)
        {
            if (assembly_word_equal(condition, x87_move_conditions[index]))
            {
                *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_X86_FCMOVCC, .operand_count = 2, .condition = (u8)index};
                return true;
            }
        }
    }
    static const struct
    {
        String8 prefix;
        AssemblyOpcode opcode;
        u8 operand_count;
    } condition_families[] = {
        {S8_INITIALIZER("cmov"), ASSEMBLY_OPCODE_X86_CMOVCC, 2},
        {S8_INITIALIZER("set"), ASSEMBLY_OPCODE_X86_SETCC, 1},
        {S8_INITIALIZER("j"), ASSEMBLY_OPCODE_X86_JCC, 1},
    };
    for (u32 family_index = 0; family_index < BUSTER_ARRAY_LENGTH(condition_families); family_index += 1)
    {
        String8 prefix = condition_families[family_index].prefix;
        if (mnemonic.length > prefix.length && assembly_word_equal(string_slice(mnemonic, 0, prefix.length), prefix) &&
            assembly_x86_condition_parse(string_slice(mnemonic, prefix.length, mnemonic.length), &result->condition))
        {
            result->opcode = condition_families[family_index].opcode;
            result->operand_count = condition_families[family_index].operand_count;
            return true;
        }
    }
    return false;
}

typedef struct AssemblyAarch64DirectSIMDSpelling AssemblyAarch64DirectSIMDSpelling;
struct AssemblyAarch64DirectSIMDSpelling
{
    String8 mnemonic;
    u64 source_digest;
    String8 semantic_id;
    u8 operand_count;
    u8 requirement;
    BusterA64DirectSIMDArrangement arrangements[4];
    /* Spelling-owned semantic field kind; NONE means no override. */
    u8 fixed_field_kind;
    u8 fixed_field_value;
};

BUSTER_GLOBAL_LOCAL AssemblyAarch64DirectSIMDSpelling const assembly_aarch64_direct_simd_spellings[] = {
    {S8_INITIALIZER("abs"), UINT64_C(0x29cfa5a7b75f135a), S8_INITIALIZER("arm-a64@2026-06:ABS_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("abs"), UINT64_C(0xfea2e56971759532), S8_INITIALIZER("arm-a64@2026-06:ABS_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("neg"), UINT64_C(0x6f2db5cd0e80e8df), S8_INITIALIZER("arm-a64@2026-06:NEG_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("neg"), UINT64_C(0x2ecfb0df2a6f90aa), S8_INITIALIZER("arm-a64@2026-06:NEG_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqabs"), UINT64_C(0x1e0368865d6eb3a), S8_INITIALIZER("arm-a64@2026-06:SQABS_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqabs"), UINT64_C(0x660ca7bdaac17cb2), S8_INITIALIZER("arm-a64@2026-06:SQABS_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqneg"), UINT64_C(0x4e67ba58c5625519), S8_INITIALIZER("arm-a64@2026-06:SQNEG_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqneg"), UINT64_C(0x9bf194cfa4c92757), S8_INITIALIZER("arm-a64@2026-06:SQNEG_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("suqadd"), UINT64_C(0x84b681f778c42b07), S8_INITIALIZER("arm-a64@2026-06:SUQADD_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("suqadd"), UINT64_C(0x7e96fdf6e945102a), S8_INITIALIZER("arm-a64@2026-06:SUQADD_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("usqadd"), UINT64_C(0x89f1219b62f3c332), S8_INITIALIZER("arm-a64@2026-06:USQADD_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("usqadd"), UINT64_C(0xb5cc5f5476fff9cb), S8_INITIALIZER("arm-a64@2026-06:USQADD_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fabs"), UINT64_C(0x36f968f48051514a), S8_INITIALIZER("arm-a64@2026-06:FABS_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fabs"), UINT64_C(0x4a4040d9c77df4e6), S8_INITIALIZER("arm-a64@2026-06:FABS_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fabs"), UINT64_C(0x39e725dee11116b4), S8_INITIALIZER("arm-a64@2026-06:FABS_D_floatdp1"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("fabs"), UINT64_C(0x45758f3e89ff2d7c), S8_INITIALIZER("arm-a64@2026-06:FABS_H_floatdp1"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H}},
    {S8_INITIALIZER("fabs"), UINT64_C(0xf59a9698b7dd189a), S8_INITIALIZER("arm-a64@2026-06:FABS_S_floatdp1"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S}},
   {S8_INITIALIZER("fcvtas"), UINT64_C(0x4f0d4aa444a703c3), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0xb136a8c538688714), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0xd33905a6110a18df), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0xe28363804fefc9c0), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0xbd156ab773e3db2d), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0x913328683e893c88), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0xac161d00b51920b9), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0x5eda5c8f175dd96e), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_64D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0xedf3d0506bbe827a), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_64H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtas"), UINT64_C(0x27af20ba2edd15e5), S8_INITIALIZER("arm-a64@2026-06:FCVTAS_64S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0xb808fc3eabf4f50c), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0xb619bd066b0e781c), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0xbd26a7e9e85cefab), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0x7f592e0d916f94ad), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0x3e813e6b1e499209), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0x4de0c9e8dfb514c1), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0x68d8a09a27183810), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0x7dede17ec2c4de3b), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_64D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0xe474e9242969ced3), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_64H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtau"), UINT64_C(0x232bd56f2551067c), S8_INITIALIZER("arm-a64@2026-06:FCVTAU_64S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x767f993e91beca8c), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x7fac83040ecaea0), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x3218cf33b9dd8b1a), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x7e414c84de226956), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0xdb999f823dcbeadf), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x5f900df11447d8eb), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x826eae4d5959097f), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x754d122a7c6bc2a0), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_64D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0x0698365a178984a2), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_64H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtms"), UINT64_C(0xf7f4b327317ab2ae), S8_INITIALIZER("arm-a64@2026-06:FCVTMS_64S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xffc905d99c80d9ff), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0x9b8dcd4d4c67f572), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xba3b6d125a310c48), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xb87eb2968e288a18), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xb09a743c1e19bdaa), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0x9b695075d37a1cc9), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xe28fc4f972b3218c), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xecddac8715a29697), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_64D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xa12cdfe13344872e), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_64H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtmu"), UINT64_C(0xe650588e5f4c16c2), S8_INITIALIZER("arm-a64@2026-06:FCVTMU_64S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtl"), UINT64_C(0x3605be7c9c5b5cdf), S8_INITIALIZER("arm-a64@2026-06:FCVTL_asimdmisc_L"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID},
     BUSTER_A64_DIRECT_SIMD_FIXED_FIELD_COUNT, 0},
    {S8_INITIALIZER("fcvtl2"), UINT64_C(0x3605be7c9c5b5cdf), S8_INITIALIZER("arm-a64@2026-06:FCVTL_asimdmisc_L"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID},
     BUSTER_A64_DIRECT_SIMD_FIXED_FIELD_COUNT, 1},
    {S8_INITIALIZER("fcvtn"), UINT64_C(0x3fe51307652789ca), S8_INITIALIZER("arm-a64@2026-06:FCVTN_asimdmisc_N"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID},
     BUSTER_A64_DIRECT_SIMD_FIXED_FIELD_COUNT, 0},
    {S8_INITIALIZER("fcvtn2"), UINT64_C(0x3fe51307652789ca), S8_INITIALIZER("arm-a64@2026-06:FCVTN_asimdmisc_N"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID},
     BUSTER_A64_DIRECT_SIMD_FIXED_FIELD_COUNT, 1},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0xdfee5c10fef16fc2), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0xb209c6c5774ff80a), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0x7fcee0c14317c554), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0x504f5bfe4c27d8dd), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0xc6547e16a34ec087), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0xebb8428412bf2a40), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0x4a8d8be66b5be011), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0x4b41ddf39c44a620), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_64D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0xad2efe69a1bda08b), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_64H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtns"), UINT64_C(0x534c61c03a514586), S8_INITIALIZER("arm-a64@2026-06:FCVTNS_64S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0x160364019fbe3017), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0xe4f9a16c98f48e48), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0xe01aa9b9b96b7005), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0x2fb59014ba5842cd), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0x920564d643ec86be), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0xc1d9e16f602eaa9f), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0x54458195fb9c7e24), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0xc955d5b1ad9e93d5), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_64D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0xaf4e5e6e9f530f6f), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_64H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtnu"), UINT64_C(0xc2f38acbbc52f90d), S8_INITIALIZER("arm-a64@2026-06:FCVTNU_64S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x1983dc9ac834295f), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x3b232c20144a7a63), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x25cadafa07a55199), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x3aa3182e68a6a6b7), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0xf6ba85f257737b99), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x181471a6b42d7cba), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0xa6082cd58100786d), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x52c5892d0d1d2e46), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_64D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x3e34fdfe3f8990a8), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_64H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtps"), UINT64_C(0x626cef0816527810), S8_INITIALIZER("arm-a64@2026-06:FCVTPS_64S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtpu"), UINT64_C(0x9a182456d9e9844b), S8_INITIALIZER("arm-a64@2026-06:FCVTPU_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtpu"), UINT64_C(0xced186bb58e64235), S8_INITIALIZER("arm-a64@2026-06:FCVTPU_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtpu"), UINT64_C(0x248924da93c591b0), S8_INITIALIZER("arm-a64@2026-06:FCVTPU_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtpu"), UINT64_C(0x2ea736741a06abb2), S8_INITIALIZER("arm-a64@2026-06:FCVTPU_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtpu"), UINT64_C(0x4207dbdaa7a5dde5), S8_INITIALIZER("arm-a64@2026-06:FCVTPU_32D_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtpu"), UINT64_C(0xb3005f0eaa49f0ba), S8_INITIALIZER("arm-a64@2026-06:FCVTPU_32H_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtpu"), UINT64_C(0x1321ee9f6aa27348), S8_INITIALIZER("arm-a64@2026-06:FCVTPU_32S_float2int"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzs"), UINT64_C(0xddc649248bf1c3b0), S8_INITIALIZER("arm-a64@2026-06:FCVTZS_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzs"), UINT64_C(0x7f64b5f5a04de3cf), S8_INITIALIZER("arm-a64@2026-06:FCVTZS_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzs"), UINT64_C(0x825ae0de120e1dc4), S8_INITIALIZER("arm-a64@2026-06:FCVTZS_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzs"), UINT64_C(0x3b2e1ec87178fbdc), S8_INITIALIZER("arm-a64@2026-06:FCVTZS_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzu"), UINT64_C(0x179616cd50c5f96c), S8_INITIALIZER("arm-a64@2026-06:FCVTZU_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzu"), UINT64_C(0x93592f920a7f5cb8), S8_INITIALIZER("arm-a64@2026-06:FCVTZU_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzu"), UINT64_C(0xa919d8c00e6398fb), S8_INITIALIZER("arm-a64@2026-06:FCVTZU_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcvtzu"), UINT64_C(0xf219ada0644460b4), S8_INITIALIZER("arm-a64@2026-06:FCVTZU_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fneg"), UINT64_C(0x7c47809c17721785), S8_INITIALIZER("arm-a64@2026-06:FNEG_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fneg"), UINT64_C(0x70d53a80b294b29d), S8_INITIALIZER("arm-a64@2026-06:FNEG_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frecpe"), UINT64_C(0x8b1d46d53534e1fe), S8_INITIALIZER("arm-a64@2026-06:FRECPE_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecpe"), UINT64_C(0x374ec904f3062ae6), S8_INITIALIZER("arm-a64@2026-06:FRECPE_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecpe"), UINT64_C(0x366d8fabc5069f22), S8_INITIALIZER("arm-a64@2026-06:FRECPE_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecpe"), UINT64_C(0xffc3781afb276d9c), S8_INITIALIZER("arm-a64@2026-06:FRECPE_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frint32x"), UINT64_C(0x418e0ab118cb28ba), S8_INITIALIZER("arm-a64@2026-06:FRINT32X_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FPTOINT,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frint32z"), UINT64_C(0x8dede1d564313c59), S8_INITIALIZER("arm-a64@2026-06:FRINT32Z_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FPTOINT,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frint64x"), UINT64_C(0x956ff9b673405173), S8_INITIALIZER("arm-a64@2026-06:FRINT64X_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FPTOINT,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frint64z"), UINT64_C(0x89795480cfdf8cbf), S8_INITIALIZER("arm-a64@2026-06:FRINT64Z_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FPTOINT,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frinta"), UINT64_C(0xd48a38e1f599a8ee), S8_INITIALIZER("arm-a64@2026-06:FRINTA_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frinta"), UINT64_C(0x998c3ba836d019ad), S8_INITIALIZER("arm-a64@2026-06:FRINTA_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frinti"), UINT64_C(0xe5f3251e48a70096), S8_INITIALIZER("arm-a64@2026-06:FRINTI_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frinti"), UINT64_C(0x5cd7cb8b6a8bc14f), S8_INITIALIZER("arm-a64@2026-06:FRINTI_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frintm"), UINT64_C(0x3bf81ea4d008a284), S8_INITIALIZER("arm-a64@2026-06:FRINTM_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frintm"), UINT64_C(0x71761da42f61fc7d), S8_INITIALIZER("arm-a64@2026-06:FRINTM_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frintn"), UINT64_C(0x40032043f93745e1), S8_INITIALIZER("arm-a64@2026-06:FRINTN_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frintn"), UINT64_C(0x8400e2d2506998f3), S8_INITIALIZER("arm-a64@2026-06:FRINTN_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frintp"), UINT64_C(0x28f5938a3a2d53bc), S8_INITIALIZER("arm-a64@2026-06:FRINTP_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frintp"), UINT64_C(0x6a3f308b38e353fd), S8_INITIALIZER("arm-a64@2026-06:FRINTP_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frintx"), UINT64_C(0x9f66931cf6d997e6), S8_INITIALIZER("arm-a64@2026-06:FRINTX_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frintx"), UINT64_C(0x11f79f67515d515e), S8_INITIALIZER("arm-a64@2026-06:FRINTX_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frintz"), UINT64_C(0x6a39a1e2e0ce2ac), S8_INITIALIZER("arm-a64@2026-06:FRINTZ_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frintz"), UINT64_C(0x18e04695e73b015b), S8_INITIALIZER("arm-a64@2026-06:FRINTZ_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frsqrte"), UINT64_C(0x7d706c36b4a336c5), S8_INITIALIZER("arm-a64@2026-06:FRSQRTE_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frsqrte"), UINT64_C(0xa8946616cf3a7d68), S8_INITIALIZER("arm-a64@2026-06:FRSQRTE_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frsqrte"), UINT64_C(0xd187ef754b422465), S8_INITIALIZER("arm-a64@2026-06:FRSQRTE_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frsqrte"), UINT64_C(0x1c1e583fb0130ded), S8_INITIALIZER("arm-a64@2026-06:FRSQRTE_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fsqrt"), UINT64_C(0x18e5419a44ba4bc6), S8_INITIALIZER("arm-a64@2026-06:FSQRT_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fsqrt"), UINT64_C(0xcf0fa69ade73f29b), S8_INITIALIZER("arm-a64@2026-06:FSQRT_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("scvtf"), UINT64_C(0x8a77ea4691e7f089), S8_INITIALIZER("arm-a64@2026-06:SCVTF_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("scvtf"), UINT64_C(0x8fbf3a3a185ff928), S8_INITIALIZER("arm-a64@2026-06:SCVTF_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("scvtf"), UINT64_C(0x64b916004f70de18), S8_INITIALIZER("arm-a64@2026-06:SCVTF_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("scvtf"), UINT64_C(0x6d3cba1f48df4b78), S8_INITIALIZER("arm-a64@2026-06:SCVTF_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("ucvtf"), UINT64_C(0xa058985515bdf85f), S8_INITIALIZER("arm-a64@2026-06:UCVTF_asimdmisc_R"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("ucvtf"), UINT64_C(0x8a8e6b7c5213fb44), S8_INITIALIZER("arm-a64@2026-06:UCVTF_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("ucvtf"), UINT64_C(0x936bee54d99e33c6), S8_INITIALIZER("arm-a64@2026-06:UCVTF_asimdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("ucvtf"), UINT64_C(0xfa9f851b4423665f), S8_INITIALIZER("arm-a64@2026-06:UCVTF_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fabd"), UINT64_C(0x3aaa3148c5355eb8), S8_INITIALIZER("arm-a64@2026-06:FABD_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fabd"), UINT64_C(0xeccb3d01478f107a), S8_INITIALIZER("arm-a64@2026-06:FABD_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fabd"), UINT64_C(0x8459dce91a7b0745), S8_INITIALIZER("arm-a64@2026-06:FABD_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fabd"), UINT64_C(0x2cdab270dc0ab4a2), S8_INITIALIZER("arm-a64@2026-06:FABD_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("facge"), UINT64_C(0x4f2647a83e1148e2), S8_INITIALIZER("arm-a64@2026-06:FACGE_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("facge"), UINT64_C(0x7dfd30a750682261), S8_INITIALIZER("arm-a64@2026-06:FACGE_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("facge"), UINT64_C(0x867bd108f2152b89), S8_INITIALIZER("arm-a64@2026-06:FACGE_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("facge"), UINT64_C(0x5b5c70d9b7166913), S8_INITIALIZER("arm-a64@2026-06:FACGE_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("facgt"), UINT64_C(0x19ad4ce0297dd364), S8_INITIALIZER("arm-a64@2026-06:FACGT_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("facgt"), UINT64_C(0x1c3144f7e9fc3d66), S8_INITIALIZER("arm-a64@2026-06:FACGT_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("facgt"), UINT64_C(0xb492e8579be4e6c5), S8_INITIALIZER("arm-a64@2026-06:FACGT_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("facgt"), UINT64_C(0x7c16f71cfba82dd1), S8_INITIALIZER("arm-a64@2026-06:FACGT_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("faddp"), UINT64_C(0xef5ccee40ed3b7a9), S8_INITIALIZER("arm-a64@2026-06:FADDP_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("faddp"), UINT64_C(0xe8ad7e0069b990e6), S8_INITIALIZER("arm-a64@2026-06:FADDP_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("faddp"), UINT64_C(0x8b9efc88b9785f10), S8_INITIALIZER("arm-a64@2026-06:FADDP_asisdpair_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("faddp"), UINT64_C(0xc08216e60faa00f1), S8_INITIALIZER("arm-a64@2026-06:FADDP_asisdpair_only_SD"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fadd"), UINT64_C(0xc9074ffe725f66e2), S8_INITIALIZER("arm-a64@2026-06:FADD_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fadd"), UINT64_C(0x2129a5001b94b178), S8_INITIALIZER("arm-a64@2026-06:FADD_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fadd"), UINT64_C(0x24fe9bae9c51ccd5), S8_INITIALIZER("arm-a64@2026-06:FADD_D_floatdp2"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("fadd"), UINT64_C(0xfd3ed77c6e43d89d), S8_INITIALIZER("arm-a64@2026-06:FADD_H_floatdp2"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H}},
    {S8_INITIALIZER("fadd"), UINT64_C(0xacf2c43a6428088e), S8_INITIALIZER("arm-a64@2026-06:FADD_S_floatdp2"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S}},
    {S8_INITIALIZER("fcmp"), UINT64_C(0xc980d99c3ea0fd5b), S8_INITIALIZER("arm-a64@2026-06:FCMP_D_floatcmp"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("fcmp"), UINT64_C(0x88b52875afab530c), S8_INITIALIZER("arm-a64@2026-06:FCMP_H_floatcmp"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H}},
    {S8_INITIALIZER("fcmp"), UINT64_C(0x806ab6babb1e173b), S8_INITIALIZER("arm-a64@2026-06:FCMP_S_floatcmp"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S}},
    {S8_INITIALIZER("fcmpe"), UINT64_C(0x619a154570b3b61a), S8_INITIALIZER("arm-a64@2026-06:FCMPE_D_floatcmp"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("fcmpe"), UINT64_C(0x4fc3e86312b40b5a), S8_INITIALIZER("arm-a64@2026-06:FCMPE_H_floatcmp"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H}},
    {S8_INITIALIZER("fcmpe"), UINT64_C(0x713b8bd2f7c3198f), S8_INITIALIZER("arm-a64@2026-06:FCMPE_S_floatcmp"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S}},
    {S8_INITIALIZER("fcsel"), UINT64_C(0x334422a1dbe54a6a), S8_INITIALIZER("arm-a64@2026-06:FCSEL_D_floatsel"), 4,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcsel"), UINT64_C(0x942ac11ca7582058), S8_INITIALIZER("arm-a64@2026-06:FCSEL_H_floatsel"), 4,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcsel"), UINT64_C(0x39955c862311f855), S8_INITIALIZER("arm-a64@2026-06:FCSEL_S_floatsel"), 4,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_FP,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fcmeq"), UINT64_C(0x8dd7fb0e6e2d0e90), S8_INITIALIZER("arm-a64@2026-06:FCMEQ_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmeq"), UINT64_C(0x928c0820e962783c), S8_INITIALIZER("arm-a64@2026-06:FCMEQ_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmeq"), UINT64_C(0xa717cf4ad6ae012f), S8_INITIALIZER("arm-a64@2026-06:FCMEQ_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmeq"), UINT64_C(0xbc6537df310541d3), S8_INITIALIZER("arm-a64@2026-06:FCMEQ_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fcmge"), UINT64_C(0x3d5884765339045f), S8_INITIALIZER("arm-a64@2026-06:FCMGE_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmge"), UINT64_C(0x947d5d7aedb1f102), S8_INITIALIZER("arm-a64@2026-06:FCMGE_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmge"), UINT64_C(0x1a7a6e28137b76cd), S8_INITIALIZER("arm-a64@2026-06:FCMGE_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmge"), UINT64_C(0xa4523fd8a661e9c3), S8_INITIALIZER("arm-a64@2026-06:FCMGE_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fcmgt"), UINT64_C(0x1046056aa1eb048e), S8_INITIALIZER("arm-a64@2026-06:FCMGT_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmgt"), UINT64_C(0xe27fd863ab16906f), S8_INITIALIZER("arm-a64@2026-06:FCMGT_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmgt"), UINT64_C(0x176d7f8bff8af329), S8_INITIALIZER("arm-a64@2026-06:FCMGT_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fcmgt"), UINT64_C(0xcd717cac1550eac6), S8_INITIALIZER("arm-a64@2026-06:FCMGT_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fdiv"), UINT64_C(0xd58ce4db7021007b), S8_INITIALIZER("arm-a64@2026-06:FDIV_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fdiv"), UINT64_C(0xfbeb22d5f375f8f7), S8_INITIALIZER("arm-a64@2026-06:FDIV_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmaxnmp"), UINT64_C(0xaa8ad07d6b1a44df), S8_INITIALIZER("arm-a64@2026-06:FMAXNMP_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmaxnmp"), UINT64_C(0x9a12fcb3977ce62), S8_INITIALIZER("arm-a64@2026-06:FMAXNMP_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmaxnmp"), UINT64_C(0x5bbbd15e32be1737), S8_INITIALIZER("arm-a64@2026-06:FMAXNMP_asisdpair_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmaxnmp"), UINT64_C(0x0e7a94c880401404), S8_INITIALIZER("arm-a64@2026-06:FMAXNMP_asisdpair_only_SD"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmaxnm"), UINT64_C(0x032995800a2aa37c), S8_INITIALIZER("arm-a64@2026-06:FMAXNM_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmaxnm"), UINT64_C(0x7b4c9bac157b5dcd), S8_INITIALIZER("arm-a64@2026-06:FMAXNM_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmaxp"), UINT64_C(0x32e4c02aa4111d01), S8_INITIALIZER("arm-a64@2026-06:FMAXP_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmaxp"), UINT64_C(0x813457895f7ce0d7), S8_INITIALIZER("arm-a64@2026-06:FMAXP_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmaxp"), UINT64_C(0x4625fcdc5f7b28f4), S8_INITIALIZER("arm-a64@2026-06:FMAXP_asisdpair_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmaxp"), UINT64_C(0xc4f84bdaed7c70c8), S8_INITIALIZER("arm-a64@2026-06:FMAXP_asisdpair_only_SD"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmax"), UINT64_C(0x5c9a075a71ddf8e2), S8_INITIALIZER("arm-a64@2026-06:FMAX_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmax"), UINT64_C(0xfaedf05cf068bf28), S8_INITIALIZER("arm-a64@2026-06:FMAX_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fminnmp"), UINT64_C(0xfd2d346edbeea54e), S8_INITIALIZER("arm-a64@2026-06:FMINNMP_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fminnmp"), UINT64_C(0xe80336897c9a357b), S8_INITIALIZER("arm-a64@2026-06:FMINNMP_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fminnmp"), UINT64_C(0x25afbf2d1bc84bca), S8_INITIALIZER("arm-a64@2026-06:FMINNMP_asisdpair_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fminnmp"), UINT64_C(0xe914f361850bc373), S8_INITIALIZER("arm-a64@2026-06:FMINNMP_asisdpair_only_SD"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fminnm"), UINT64_C(0xda4ddf33c1ba749c), S8_INITIALIZER("arm-a64@2026-06:FMINNM_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fminnm"), UINT64_C(0x995312a626c3649d), S8_INITIALIZER("arm-a64@2026-06:FMINNM_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fminp"), UINT64_C(0x4cd117eb363e2c78), S8_INITIALIZER("arm-a64@2026-06:FMINP_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fminp"), UINT64_C(0xbd6d714d8112f81c), S8_INITIALIZER("arm-a64@2026-06:FMINP_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fminp"), UINT64_C(0x97d575f7b14405de), S8_INITIALIZER("arm-a64@2026-06:FMINP_asisdpair_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fminp"), UINT64_C(0x82de85dfb92fb794), S8_INITIALIZER("arm-a64@2026-06:FMINP_asisdpair_only_SD"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmin"), UINT64_C(0x4056d40a70119de7), S8_INITIALIZER("arm-a64@2026-06:FMIN_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmin"), UINT64_C(0x302b657ec3312835), S8_INITIALIZER("arm-a64@2026-06:FMIN_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmla"), UINT64_C(0x030d357ec711cb60), S8_INITIALIZER("arm-a64@2026-06:FMLA_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmla"), UINT64_C(0x7508cce16fcae6ee), S8_INITIALIZER("arm-a64@2026-06:FMLA_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmlal2"), UINT64_C(0x7cd436e3f3d6fb58), S8_INITIALIZER("arm-a64@2026-06:FMLAL2_asimdsame_F"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FP16FML,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmlal"), UINT64_C(0x424770611f6d4571), S8_INITIALIZER("arm-a64@2026-06:FMLAL_asimdsame_F"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FP16FML,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmlsl2"), UINT64_C(0x3a930821d594548d), S8_INITIALIZER("arm-a64@2026-06:FMLSL2_asimdsame_F"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FP16FML,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmlsl"), UINT64_C(0x7c64660496445a9d), S8_INITIALIZER("arm-a64@2026-06:FMLSL_asimdsame_F"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FP16FML,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmls"), UINT64_C(0x6e7257ac7fc0f865), S8_INITIALIZER("arm-a64@2026-06:FMLS_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmls"), UINT64_C(0xc58e155ad85cea11), S8_INITIALIZER("arm-a64@2026-06:FMLS_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmulx"), UINT64_C(0xe14549b23ddf379a), S8_INITIALIZER("arm-a64@2026-06:FMULX_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmulx"), UINT64_C(0x60d5d68fc850b2b6), S8_INITIALIZER("arm-a64@2026-06:FMULX_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmulx"), UINT64_C(0x7ff0b8514e7d3c1f), S8_INITIALIZER("arm-a64@2026-06:FMULX_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmulx"), UINT64_C(0x895575d4b935c180), S8_INITIALIZER("arm-a64@2026-06:FMULX_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmul"), UINT64_C(0x25d9ffffdd7ad3f9), S8_INITIALIZER("arm-a64@2026-06:FMUL_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fmul"), UINT64_C(0xf4732ebe28fd191a), S8_INITIALIZER("arm-a64@2026-06:FMUL_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frecps"), UINT64_C(0x1cb2a8b2ae0d2f70), S8_INITIALIZER("arm-a64@2026-06:FRECPS_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecps"), UINT64_C(0x3110ab89b094849e), S8_INITIALIZER("arm-a64@2026-06:FRECPS_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecps"), UINT64_C(0x170d5536e6987b00), S8_INITIALIZER("arm-a64@2026-06:FRECPS_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecps"), UINT64_C(0xb1e49304d1f0d40e), S8_INITIALIZER("arm-a64@2026-06:FRECPS_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("frsqrts"), UINT64_C(0x13b28e427f1a5244), S8_INITIALIZER("arm-a64@2026-06:FRSQRTS_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frsqrts"), UINT64_C(0x516f45fa0fa4ea2e), S8_INITIALIZER("arm-a64@2026-06:FRSQRTS_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frsqrts"), UINT64_C(0xe3de087e1013a456), S8_INITIALIZER("arm-a64@2026-06:FRSQRTS_asisdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frsqrts"), UINT64_C(0x992ba276d9a1e1c1), S8_INITIALIZER("arm-a64@2026-06:FRSQRTS_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fsub"), UINT64_C(0x9ac4a4e9274ed9d4), S8_INITIALIZER("arm-a64@2026-06:FSUB_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("fsub"), UINT64_C(0x113061a7dd458da8), S8_INITIALIZER("arm-a64@2026-06:FSUB_asimdsamefp16_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("addp"), UINT64_C(0xabb728ab3eaf08aa), S8_INITIALIZER("arm-a64@2026-06:ADDP_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("addp"), UINT64_C(0x98b8e2d558091216), S8_INITIALIZER("arm-a64@2026-06:ADDP_asisdpair_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D}},
    {S8_INITIALIZER("rev64"), UINT64_C(0x6c9ec232f3f8bb00), S8_INITIALIZER("arm-a64@2026-06:REV64_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("urecpe"), UINT64_C(0xc780556f4e2be721), S8_INITIALIZER("arm-a64@2026-06:URECPE_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("ursqrte"), UINT64_C(0x96a3cec81c08ba35), S8_INITIALIZER("arm-a64@2026-06:URSQRTE_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cmeq"), UINT64_C(0x4bcb414feaab1fcd), S8_INITIALIZER("arm-a64@2026-06:CMEQ_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cmeq"), UINT64_C(0xf0069bc3f3d78400), S8_INITIALIZER("arm-a64@2026-06:CMEQ_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("cmge"), UINT64_C(0x25ce34475d72334d), S8_INITIALIZER("arm-a64@2026-06:CMGE_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cmge"), UINT64_C(0x6eacba4e96135495), S8_INITIALIZER("arm-a64@2026-06:CMGE_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("cmgt"), UINT64_C(0xadc2e6aa5173fc0), S8_INITIALIZER("arm-a64@2026-06:CMGT_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cmgt"), UINT64_C(0x92e7ff05957ea047), S8_INITIALIZER("arm-a64@2026-06:CMGT_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("cmhi"), UINT64_C(0x87794c35ce3a68d0), S8_INITIALIZER("arm-a64@2026-06:CMHI_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cmhi"), UINT64_C(0xaa949f7d1f29089a), S8_INITIALIZER("arm-a64@2026-06:CMHI_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("cmhs"), UINT64_C(0x3bb8226d654e604d), S8_INITIALIZER("arm-a64@2026-06:CMHS_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cmhs"), UINT64_C(0xab6a959d4a8cbef3), S8_INITIALIZER("arm-a64@2026-06:CMHS_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("cmtst"), UINT64_C(0xe637c1caae107056), S8_INITIALIZER("arm-a64@2026-06:CMTST_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cmtst"), UINT64_C(0x4a1317795dfc29c9), S8_INITIALIZER("arm-a64@2026-06:CMTST_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("fcvtxn"), UINT64_C(0xbbe797249dd7b649), S8_INITIALIZER("arm-a64@2026-06:FCVTXN_asisdmisc_N"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
   {S8_INITIALIZER("fmaxnmv"), UINT64_C(0xd828dd77e54a4811), S8_INITIALIZER("arm-a64@2026-06:FMAXNMV_asimdall_only_SD"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("fmaxnmv"), UINT64_C(0xb3cb9d859362f633), S8_INITIALIZER("arm-a64@2026-06:FMAXNMV_asimdall_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fmaxv"), UINT64_C(0xef5540e4a2cff8aa), S8_INITIALIZER("arm-a64@2026-06:FMAXV_asimdall_only_SD"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("fmaxv"), UINT64_C(0x21b9304dfa220ddd), S8_INITIALIZER("arm-a64@2026-06:FMAXV_asimdall_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fminnmv"), UINT64_C(0xd548a439440da4), S8_INITIALIZER("arm-a64@2026-06:FMINNMV_asimdall_only_SD"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("fminnmv"), UINT64_C(0x5b53da56a57e00d1), S8_INITIALIZER("arm-a64@2026-06:FMINNMV_asimdall_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("fminv"), UINT64_C(0x09c8ee383cb4fa15), S8_INITIALIZER("arm-a64@2026-06:FMINV_asimdall_only_SD"), 2,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("fminv"), UINT64_C(0xde29ff8b23c707f9), S8_INITIALIZER("arm-a64@2026-06:FMINV_asimdall_only_H"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("srshl"), UINT64_C(0x786f9a5f46bfbded), S8_INITIALIZER("arm-a64@2026-06:SRSHL_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("srshl"), UINT64_C(0xa6d21f66dfad9d87), S8_INITIALIZER("arm-a64@2026-06:SRSHL_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("sshl"), UINT64_C(0x1357836e8376cb69), S8_INITIALIZER("arm-a64@2026-06:SSHL_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sshl"), UINT64_C(0x45fc861e6aaa921f), S8_INITIALIZER("arm-a64@2026-06:SSHL_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("urshl"), UINT64_C(0x639d8d3a8e981983), S8_INITIALIZER("arm-a64@2026-06:URSHL_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("urshl"), UINT64_C(0xdb7da3f6ffe90b86), S8_INITIALIZER("arm-a64@2026-06:URSHL_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("ushl"), UINT64_C(0x679d133d69c5b677), S8_INITIALIZER("arm-a64@2026-06:USHL_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("ushl"), UINT64_C(0x21a8b95b0103cf0e), S8_INITIALIZER("arm-a64@2026-06:USHL_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D}},
    {S8_INITIALIZER("aesd"), UINT64_C(0x6cacc320d32f7696), S8_INITIALIZER("arm-a64@2026-06:AESD_B_cryptoaes"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_AES, {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B}},
    {S8_INITIALIZER("aese"), UINT64_C(0x64d13665bc040990), S8_INITIALIZER("arm-a64@2026-06:AESE_B_cryptoaes"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_AES, {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B}},
    {S8_INITIALIZER("aesimc"), UINT64_C(0xafd75da1d5d14815), S8_INITIALIZER("arm-a64@2026-06:AESIMC_B_cryptoaes"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_AES, {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B}},
    {S8_INITIALIZER("aesmc"), UINT64_C(0x6a644c32fd7849e2), S8_INITIALIZER("arm-a64@2026-06:AESMC_B_cryptoaes"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_AES, {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B}},
    {S8_INITIALIZER("bcax"), UINT64_C(0xfab88050fa075b6f), S8_INITIALIZER("arm-a64@2026-06:BCAX_VVV16_crypto4"), 4,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA3, {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B,
                                       BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B}},
    {S8_INITIALIZER("eor3"), UINT64_C(0x9a2c72cc6e6d8045), S8_INITIALIZER("arm-a64@2026-06:EOR3_VVV16_crypto4"), 4,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA3, {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B,
                                       BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B}},
    {S8_INITIALIZER("rax1"), UINT64_C(0xd81c13f95e34182a), S8_INITIALIZER("arm-a64@2026-06:RAX1_VVV2_cryptosha512_3"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA3, {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D,
                                       BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D}},
    {S8_INITIALIZER("sha512su0"), UINT64_C(0xe6d957574d81e0ab),
     S8_INITIALIZER("arm-a64@2026-06:SHA512SU0_VV2_cryptosha512_2"), 2, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA3,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D}},
    {S8_INITIALIZER("sha512su1"), UINT64_C(0xf5ea9d105f875216),
     S8_INITIALIZER("arm-a64@2026-06:SHA512SU1_VVV2_cryptosha512_3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA3,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D}},
    {S8_INITIALIZER("sha512h"), UINT64_C(0xb2b7deeed318433f),
     S8_INITIALIZER("arm-a64@2026-06:SHA512H_QQV_cryptosha512_3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA3,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D}},
    {S8_INITIALIZER("sha512h2"), UINT64_C(0xe2ea4e3019bc6fa6),
     S8_INITIALIZER("arm-a64@2026-06:SHA512H2_QQV_cryptosha512_3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA3,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D}},
    {S8_INITIALIZER("sha1c"), UINT64_C(0xc8bf61c1fbc4c68b),
     S8_INITIALIZER("arm-a64@2026-06:SHA1C_QSV_cryptosha3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha1h"), UINT64_C(0x527117bcf01c589e),
     S8_INITIALIZER("arm-a64@2026-06:SHA1H_SS_cryptosha2"), 2, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S}},
    {S8_INITIALIZER("sha1m"), UINT64_C(0xfe21fb23ee0af9be),
     S8_INITIALIZER("arm-a64@2026-06:SHA1M_QSV_cryptosha3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha1p"), UINT64_C(0x6df8cac602cb80f6),
     S8_INITIALIZER("arm-a64@2026-06:SHA1P_QSV_cryptosha3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha1su0"), UINT64_C(0xe03e17b03ab0e566),
     S8_INITIALIZER("arm-a64@2026-06:SHA1SU0_VVV_cryptosha3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha1su1"), UINT64_C(0x91788958671acea8),
     S8_INITIALIZER("arm-a64@2026-06:SHA1SU1_VV_cryptosha2"), 2, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha256su0"), UINT64_C(0x24d8b3ad23b8860c),
     S8_INITIALIZER("arm-a64@2026-06:SHA256SU0_VV_cryptosha2"), 2, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha256su1"), UINT64_C(0xd1c2681e9bf85abd),
     S8_INITIALIZER("arm-a64@2026-06:SHA256SU1_VVV_cryptosha3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha256h"), UINT64_C(0x4d874cec7b60b7a5),
     S8_INITIALIZER("arm-a64@2026-06:SHA256H_QQV_cryptosha3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("sha256h2"), UINT64_C(0x470540cee6a27190),
     S8_INITIALIZER("arm-a64@2026-06:SHA256H2_QQV_cryptosha3"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_SHA2,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S}},
    {S8_INITIALIZER("shadd"), UINT64_C(0x56a53606b665014e),
     S8_INITIALIZER("arm-a64@2026-06:SHADD_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("shsub"), UINT64_C(0x39c9b1410b025abb),
     S8_INITIALIZER("arm-a64@2026-06:SHSUB_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqadd"), UINT64_C(0x29c051de1594276),
     S8_INITIALIZER("arm-a64@2026-06:SQADD_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqadd"), UINT64_C(0x1a9c9e4a34277770),
     S8_INITIALIZER("arm-a64@2026-06:SQADD_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqsub"), UINT64_C(0x2380f016e7cfa4b6),
     S8_INITIALIZER("arm-a64@2026-06:SQSUB_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqsub"), UINT64_C(0xc6f9093527fd096b),
     S8_INITIALIZER("arm-a64@2026-06:SQSUB_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqdmlal"), UINT64_C(0xa880474b2d693e03),
     S8_INITIALIZER("arm-a64@2026-06:SQDMLAL_asisddiff_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqdmlsl"), UINT64_C(0xf39ad3663eebb936),
     S8_INITIALIZER("arm-a64@2026-06:SQDMLSL_asisddiff_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqdmull"), UINT64_C(0x5eaf349cfe4c58fa),
     S8_INITIALIZER("arm-a64@2026-06:SQDMULL_asisddiff_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqxtn"), UINT64_C(0xaba6357972b5fd03),
     S8_INITIALIZER("arm-a64@2026-06:SQXTN_asisdmisc_N"), 2, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqxtun"), UINT64_C(0x947ecbd12b6c0cf8),
     S8_INITIALIZER("arm-a64@2026-06:SQXTUN_asisdmisc_N"), 2, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqadd"), UINT64_C(0x96647d47d1a1270f),
     S8_INITIALIZER("arm-a64@2026-06:UQADD_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqadd"), UINT64_C(0xad945432490cc5ce),
     S8_INITIALIZER("arm-a64@2026-06:UQADD_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqsub"), UINT64_C(0xbbc800b133a7127e),
     S8_INITIALIZER("arm-a64@2026-06:UQSUB_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqsub"), UINT64_C(0xe3c397989fe6f97),
     S8_INITIALIZER("arm-a64@2026-06:UQSUB_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqxtn"), UINT64_C(0xe02de395147ccab2),
     S8_INITIALIZER("arm-a64@2026-06:UQXTN_asisdmisc_N"), 2, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrshl"), UINT64_C(0x47afcf98abce1c03),
     S8_INITIALIZER("arm-a64@2026-06:SQRSHL_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrshl"), UINT64_C(0x750b011252e13008),
     S8_INITIALIZER("arm-a64@2026-06:SQRSHL_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqshl"), UINT64_C(0x45c2d983039f5b3d),
     S8_INITIALIZER("arm-a64@2026-06:SQSHL_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqshl"), UINT64_C(0x5516341c51784243),
     S8_INITIALIZER("arm-a64@2026-06:SQSHL_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqrshl"), UINT64_C(0x8a4d6a781a47059e),
     S8_INITIALIZER("arm-a64@2026-06:UQRSHL_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqrshl"), UINT64_C(0x2ccfbaab1d5abafe),
     S8_INITIALIZER("arm-a64@2026-06:UQRSHL_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqshl"), UINT64_C(0x95df4b1ce0427959),
     S8_INITIALIZER("arm-a64@2026-06:UQSHL_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uqshl"), UINT64_C(0x72614e0c7f4a79c1),
     S8_INITIALIZER("arm-a64@2026-06:UQSHL_asisdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("srhadd"), UINT64_C(0xb30bf50e9939be60),
     S8_INITIALIZER("arm-a64@2026-06:SRHADD_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("urhadd"), UINT64_C(0xd1292fa78044db86),
     S8_INITIALIZER("arm-a64@2026-06:URHADD_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uhadd"), UINT64_C(0x89b06ba4427f41f8),
     S8_INITIALIZER("arm-a64@2026-06:UHADD_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uhsub"), UINT64_C(0xeb24f4f933a10649),
     S8_INITIALIZER("arm-a64@2026-06:UHSUB_asimdsame_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("add"), UINT64_C(0x979101fa1dd62d38), S8_INITIALIZER("arm-a64@2026-06:ADD_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("add"), UINT64_C(0x1f1182a2f55aaad9), S8_INITIALIZER("arm-a64@2026-06:ADD_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("and"), UINT64_C(0x52df93db3d4db99d), S8_INITIALIZER("arm-a64@2026-06:AND_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("bic"), UINT64_C(0x70338c1f69cbc030), S8_INITIALIZER("arm-a64@2026-06:BIC_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cls"), UINT64_C(0xc9168638e385e157), S8_INITIALIZER("arm-a64@2026-06:CLS_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("clz"), UINT64_C(0x0b1fe309be6bba71), S8_INITIALIZER("arm-a64@2026-06:CLZ_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("eor"), UINT64_C(0xa6d57e7ad7709737), S8_INITIALIZER("arm-a64@2026-06:EOR_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("orn"), UINT64_C(0xfb87dd553345428c), S8_INITIALIZER("arm-a64@2026-06:ORN_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("rbit"), UINT64_C(0x15375b291dd8409f), S8_INITIALIZER("arm-a64@2026-06:RBIT_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("rev16"), UINT64_C(0x85e55f83cf9406e7), S8_INITIALIZER("arm-a64@2026-06:REV16_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("rev32"), UINT64_C(0x6be39e0e8b2edb2c), S8_INITIALIZER("arm-a64@2026-06:REV32_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sub"), UINT64_C(0x9353fa8f698b9abb), S8_INITIALIZER("arm-a64@2026-06:SUB_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sub"), UINT64_C(0x5d1dde1d88b9da52), S8_INITIALIZER("arm-a64@2026-06:SUB_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("cnt"), UINT64_C(0x79f29c4b7493d8fc), S8_INITIALIZER("arm-a64@2026-06:CNT_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("trn1"), UINT64_C(0xfdcca525def047b1), S8_INITIALIZER("arm-a64@2026-06:TRN1_asimdperm_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("trn2"), UINT64_C(0xca6a439cf2f40ac5), S8_INITIALIZER("arm-a64@2026-06:TRN2_asimdperm_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uzp1"), UINT64_C(0x0e5927756c402582), S8_INITIALIZER("arm-a64@2026-06:UZP1_asimdperm_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uzp2"), UINT64_C(0x2bebf3b6290a4e95), S8_INITIALIZER("arm-a64@2026-06:UZP2_asimdperm_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("zip1"), UINT64_C(0x7afbf184fc26aab8), S8_INITIALIZER("arm-a64@2026-06:ZIP1_asimdperm_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("zip2"), UINT64_C(0xda9df4e645b716cd), S8_INITIALIZER("arm-a64@2026-06:ZIP2_asimdperm_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("smaxp"), UINT64_C(0x96a7284d46141654), S8_INITIALIZER("arm-a64@2026-06:SMAXP_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("smax"), UINT64_C(0xcf65af24d13a372d), S8_INITIALIZER("arm-a64@2026-06:SMAX_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sminp"), UINT64_C(0xee0b782bb1ced160), S8_INITIALIZER("arm-a64@2026-06:SMINP_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("smin"), UINT64_C(0xffbd05abeecb35f), S8_INITIALIZER("arm-a64@2026-06:SMIN_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("umaxp"), UINT64_C(0x88396959a1584569), S8_INITIALIZER("arm-a64@2026-06:UMAXP_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("umax"), UINT64_C(0x5d011a59ed0fcda6), S8_INITIALIZER("arm-a64@2026-06:UMAX_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uminp"), UINT64_C(0x7d288f64c26fc2e9), S8_INITIALIZER("arm-a64@2026-06:UMINP_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
   {S8_INITIALIZER("umin"), UINT64_C(0x5d3c83c451dba6ec), S8_INITIALIZER("arm-a64@2026-06:UMIN_asimdsame_only"), 3,
    BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
    {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
     BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("addv"), UINT64_C(0x1ab2788d7662a6a1), S8_INITIALIZER("arm-a64@2026-06:ADDV_asimdall_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("saddlv"), UINT64_C(0xd46ae4672b69f63b), S8_INITIALIZER("arm-a64@2026-06:SADDLV_asimdall_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uaddlv"), UINT64_C(0xc96fa72535596354), S8_INITIALIZER("arm-a64@2026-06:UADDLV_asimdall_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("smaxv"), UINT64_C(0xcd22f3f3d228016c), S8_INITIALIZER("arm-a64@2026-06:SMAXV_asimdall_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sminv"), UINT64_C(0x2364eda2023802a2), S8_INITIALIZER("arm-a64@2026-06:SMINV_asimdall_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("umaxv"), UINT64_C(0xf4d19c38ba513cd6), S8_INITIALIZER("arm-a64@2026-06:UMAXV_asimdall_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uminv"), UINT64_C(0xf3ad2c5933a3eee9), S8_INITIALIZER("arm-a64@2026-06:UMINV_asimdall_only"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecpx"), UINT64_C(0x8562c49063307536), S8_INITIALIZER("arm-a64@2026-06:FRECPX_asisdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("frecpx"), UINT64_C(0x342fb1bb0ad35c21), S8_INITIALIZER("arm-a64@2026-06:FRECPX_asisdmiscfp16_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_FULLFP16,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("saba"), UINT64_C(0x255a60ff7d6455c), S8_INITIALIZER("arm-a64@2026-06:SABA_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sabd"), UINT64_C(0x2a073ca005a3dba8), S8_INITIALIZER("arm-a64@2026-06:SABD_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sadalp"), UINT64_C(0xce7ba83208138d21), S8_INITIALIZER("arm-a64@2026-06:SADALP_asimdmisc_P"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("saddlp"), UINT64_C(0x7a84faace4a630d), S8_INITIALIZER("arm-a64@2026-06:SADDLP_asimdmisc_P"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uaba"), UINT64_C(0xf0cb82f41d6dc1e1), S8_INITIALIZER("arm-a64@2026-06:UABA_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uabd"), UINT64_C(0x9ea80ca1d9ca4225), S8_INITIALIZER("arm-a64@2026-06:UABD_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uadalp"), UINT64_C(0x40d028b170dad417), S8_INITIALIZER("arm-a64@2026-06:UADALP_asimdmisc_P"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("uaddlp"), UINT64_C(0xc0aeb2fe0e2bccfc), S8_INITIALIZER("arm-a64@2026-06:UADDLP_asimdmisc_P"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("mla"), UINT64_C(0xbd3bad278da7cdcb), S8_INITIALIZER("arm-a64@2026-06:MLA_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("mls"), UINT64_C(0xfb9748a5a5710377), S8_INITIALIZER("arm-a64@2026-06:MLS_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("mul"), UINT64_C(0xa2bd52b89d3535ba), S8_INITIALIZER("arm-a64@2026-06:MUL_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("pmul"), UINT64_C(0x56afa97474589285), S8_INITIALIZER("arm-a64@2026-06:PMUL_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqdmulh"), UINT64_C(0x346d5eefb9e601d8), S8_INITIALIZER("arm-a64@2026-06:SQDMULH_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqdmulh"), UINT64_C(0x1efd908db4f500ed), S8_INITIALIZER("arm-a64@2026-06:SQDMULH_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrdmulh"), UINT64_C(0x19232e7906dcef5c), S8_INITIALIZER("arm-a64@2026-06:SQRDMULH_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrdmulh"), UINT64_C(0x9f8fd10fed120f41), S8_INITIALIZER("arm-a64@2026-06:SQRDMULH_asisdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrdmlah"), UINT64_C(0x3557225a108dda38),
     S8_INITIALIZER("arm-a64@2026-06:SQRDMLAH_asimdsame2_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_RDM,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrdmlah"), UINT64_C(0x26cc7e6837d3c6f),
     S8_INITIALIZER("arm-a64@2026-06:SQRDMLAH_asisdsame2_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_RDM,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrdmlsh"), UINT64_C(0x03b0c5137f14528a),
     S8_INITIALIZER("arm-a64@2026-06:SQRDMLSH_asimdsame2_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_RDM,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sqrdmlsh"), UINT64_C(0x8f3f8e995448cec5),
     S8_INITIALIZER("arm-a64@2026-06:SQRDMLSH_asisdsame2_only"), 3, BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_RDM,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("bif"), UINT64_C(0x9213cc7938be02c1), S8_INITIALIZER("arm-a64@2026-06:BIF_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("bit"), UINT64_C(0x16db4b3233bce730), S8_INITIALIZER("arm-a64@2026-06:BIT_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("bsl"), UINT64_C(0x8820b97199de36f3), S8_INITIALIZER("arm-a64@2026-06:BSL_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("sdot"), UINT64_C(0x1aab66d054562284), S8_INITIALIZER("arm-a64@2026-06:SDOT_asimdsame2_D"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_DOTPROD,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID},
     BUSTER_A64_DIRECT_SIMD_FIXED_FIELD_SIZE, 2},
    {S8_INITIALIZER("udot"), UINT64_C(0xd40495bc9d9aacdf), S8_INITIALIZER("arm-a64@2026-06:UDOT_asimdsame2_D"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON_DOTPROD,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID},
     BUSTER_A64_DIRECT_SIMD_FIXED_FIELD_SIZE, 2},
    {S8_INITIALIZER("tbl"), UINT64_C(0x7217285bada5df77), S8_INITIALIZER("arm-a64@2026-06:TBL_asimdtbl_L1_1"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("tbl"), UINT64_C(0xb78a5bd0b06eeb02), S8_INITIALIZER("arm-a64@2026-06:TBL_asimdtbl_L2_2"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("tbl"), UINT64_C(0x1d93f8d9ed2b6dd8), S8_INITIALIZER("arm-a64@2026-06:TBL_asimdtbl_L3_3"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("tbl"), UINT64_C(0x0f24e509b0a9d450), S8_INITIALIZER("arm-a64@2026-06:TBL_asimdtbl_L4_4"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("tbx"), UINT64_C(0x804d68c24266e3c4), S8_INITIALIZER("arm-a64@2026-06:TBX_asimdtbl_L1_1"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("tbx"), UINT64_C(0xe298fbaad2ea6fd7), S8_INITIALIZER("arm-a64@2026-06:TBX_asimdtbl_L2_2"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("tbx"), UINT64_C(0x9f7c68cc37209c0f), S8_INITIALIZER("arm-a64@2026-06:TBX_asimdtbl_L3_3"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("tbx"), UINT64_C(0x2050b49463e72e5a), S8_INITIALIZER("arm-a64@2026-06:TBX_asimdtbl_L4_4"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("dup"), UINT64_C(0xe6799413838aec2f), S8_INITIALIZER("arm-a64@2026-06:DUP_asimdins_DR_r"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("not"), UINT64_C(0xb4fad81197ef56dd), S8_INITIALIZER("arm-a64@2026-06:NOT_asimdmisc_R"), 2,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
    {S8_INITIALIZER("orr"), UINT64_C(0xc6e29afad4e09fb3), S8_INITIALIZER("arm-a64@2026-06:ORR_asimdsame_only"), 3,
     BUSTER_A64_DIRECT_SIMD_REQUIREMENT_NEON,
     {BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID,
      BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID, BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID}},
};

#if BUSTER_INCLUDE_TESTS
u32 assembly_test_aarch64_direct_simd_spelling_count(void)
{
    return BUSTER_ARRAY_LENGTH(assembly_aarch64_direct_simd_spellings);
}

bool assembly_test_aarch64_direct_simd_spelling_at(u32 index, AssemblyAarch64DirectSIMDSpellingTest* result)
{
    if (!result || index >= BUSTER_ARRAY_LENGTH(assembly_aarch64_direct_simd_spellings))
    {
        return false;
    }
    AssemblyAarch64DirectSIMDSpelling const spelling = assembly_aarch64_direct_simd_spellings[index];
    *result = (AssemblyAarch64DirectSIMDSpellingTest){.mnemonic = spelling.mnemonic,
                                                      .source_digest = spelling.source_digest,
                                                      .semantic_id = spelling.semantic_id,
                                                      .operand_count = spelling.operand_count,
                                                      .requirement = spelling.requirement,
                                                      .arrangements = {(u8)spelling.arrangements[0],
                                                                       (u8)spelling.arrangements[1],
                                                                       (u8)spelling.arrangements[2],
                                                                       (u8)spelling.arrangements[3]},
                                                      .fixed_field_kind = spelling.fixed_field_kind,
                                                      .fixed_field_value = spelling.fixed_field_value};
    return true;
}
#endif

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_lookup(String8 mnemonic, AssemblyInstructionInfo* result)
{
    if (!result)
    {
        return false;
    }
    u32 spelling_first = UINT32_MAX;
    u32 spelling_count = 0;
    AssemblyAarch64DirectSIMDSpelling first_spelling = {0};
    u32 first_row_index = UINT32_MAX;
    u32 last_spelling_index = UINT32_MAX;
    bool generated = false;
    for (u32 spelling_index = 0; spelling_index < BUSTER_ARRAY_LENGTH(assembly_aarch64_direct_simd_spellings); spelling_index += 1)
    {
        AssemblyAarch64DirectSIMDSpelling spelling = assembly_aarch64_direct_simd_spellings[spelling_index];
        if (!assembly_word_equal(mnemonic, spelling.mnemonic))
        {
            continue;
        }
        u32 row_index = UINT32_MAX;
        if (!buster_a64_direct_simd_find_source_digest(spelling.source_digest, &row_index))
        {
            return false;
        }
        BusterA64DirectSIMDRowInfo row = {0};
        BusterA64SemanticForm form = {0};
        u32 public_operand_count = 0;
        if (!buster_a64_direct_simd_row(row_index, &row) || !row.executable ||
            !buster_a64_semantic_form(row.semantic_form_id, &form) ||
            !assembly_word_equal(row.id, spelling.semantic_id))
        {
            return false;
        }
        bool list_public_seen = false;
        for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
        {
            BusterA64SemanticOperand operand = {0};
            if (!buster_a64_semantic_operand(form.operand_first + operand_index, &operand))
            {
                return false;
            }
            if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LIST ||
                (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LIST_MEMBER) != 0)
            {
                if (!list_public_seen)
                {
                    public_operand_count += 1;
                    list_public_seen = true;
                }
            }
            else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LANE &&
                     (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_INDEX_REGISTER) != 0 &&
                     (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LANE_INDEX) != 0 &&
                     (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0)
            {
                public_operand_count += 1;
            }
            else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER)
            {
                public_operand_count += 1;
            }
            else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER)
            {
                /* Mixed fixed forms (currently the FCVT* GPR/scalar-SIMD
                 * cohort) expose the GPR register directly.  Width, ZR and
                 * SP policy remain semantic-form driven in the candidate
                 * parser; this lookup only counts the public operand. */
                public_operand_count += 1;
            }
            else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_CONDITION &&
                     (operand.flags & BUSTER_A64_SEMANTIC_FLAG_CONDITION_FIELD) != 0)
            {
                public_operand_count += 1;
            }
            else if (operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_ARRANGEMENT &&
                     operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_WIDTH_SELECTOR &&
                     operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_PREFIX_SELECTOR &&
                     operand.kind != BUSTER_A64_SEMANTIC_OPERAND_GPR_WIDTH_SELECTOR &&
                     operand.kind != BUSTER_A64_SEMANTIC_OPERAND_FIXED_CONSTANT)
            {
                return false;
            }
        }
        if (public_operand_count != spelling.operand_count)
        {
            return false;
        }
        if (spelling_first == UINT32_MAX)
        {
            spelling_first = spelling_index;
            first_spelling = spelling;
            first_row_index = row.row_index;
        }
        else if (spelling_index != last_spelling_index + 1)
        {
            return false;
        }
        last_spelling_index = spelling_index;
        generated |= row.transform_bearing;
        spelling_count += 1;
    }
    if (spelling_first == UINT32_MAX || spelling_count > UINT8_MAX)
    {
        return false;
    }
    *result = (AssemblyInstructionInfo){
        .opcode = ASSEMBLY_OPCODE_COUNT,
        .operand_count = first_spelling.operand_count,
        .encoding_kind = ASSEMBLY_ENCODING_AARCH64_DIRECT_SIMD,
        .aarch64_direct_simd_row_index = first_row_index,
        .aarch64_direct_simd_spelling_first = spelling_first,
        .aarch64_direct_simd_spelling_count = (u8)spelling_count,
        .aarch64_direct_simd_generated = generated,
        .aarch64_direct_simd_requirement = first_spelling.requirement,
        .aarch64_direct_simd_fixed_field_kind = first_spelling.fixed_field_kind,
        .aarch64_direct_simd_fixed_field_value = first_spelling.fixed_field_value,
    };
    memcpy(result->aarch64_direct_simd_arrangements, first_spelling.arrangements, sizeof(result->aarch64_direct_simd_arrangements));
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_instruction_lookup(Target target, AssemblySyntax syntax, String8 mnemonic, AssemblyInstructionInfo* result)
{
    if (target.cpu_arch == CPU_ARCH_X86_64)
    {
        if (syntax == ASSEMBLY_SYNTAX_ATT)
        {
            static const struct
            {
                String8 name;
                AssemblyOpcode opcode;
                u8 width;
            } x87_memory_instructions[] = {
                {S8_INITIALIZER("flds"), ASSEMBLY_OPCODE_X86_FLD, 32},     {S8_INITIALIZER("fldl"), ASSEMBLY_OPCODE_X86_FLD, 64},
                {S8_INITIALIZER("fldt"), ASSEMBLY_OPCODE_X86_FLD, 80},     {S8_INITIALIZER("fsts"), ASSEMBLY_OPCODE_X86_FST, 32},
                {S8_INITIALIZER("fstl"), ASSEMBLY_OPCODE_X86_FST, 64},     {S8_INITIALIZER("fstps"), ASSEMBLY_OPCODE_X86_FSTP, 32},
                {S8_INITIALIZER("fstpl"), ASSEMBLY_OPCODE_X86_FSTP, 64},   {S8_INITIALIZER("fstpt"), ASSEMBLY_OPCODE_X86_FSTP, 80},
                {S8_INITIALIZER("filds"), ASSEMBLY_OPCODE_X86_FILD, 16},   {S8_INITIALIZER("fildl"), ASSEMBLY_OPCODE_X86_FILD, 32},
                {S8_INITIALIZER("fildq"), ASSEMBLY_OPCODE_X86_FILD, 64},   {S8_INITIALIZER("fildll"), ASSEMBLY_OPCODE_X86_FILD, 64},
                {S8_INITIALIZER("fists"), ASSEMBLY_OPCODE_X86_FIST, 16},   {S8_INITIALIZER("fistl"), ASSEMBLY_OPCODE_X86_FIST, 32},
                {S8_INITIALIZER("fistps"), ASSEMBLY_OPCODE_X86_FISTP, 16}, {S8_INITIALIZER("fistpl"), ASSEMBLY_OPCODE_X86_FISTP, 32},
                {S8_INITIALIZER("fistpq"), ASSEMBLY_OPCODE_X86_FISTP, 64}, {S8_INITIALIZER("fistpll"), ASSEMBLY_OPCODE_X86_FISTP, 64},
                {S8_INITIALIZER("fisttps"), ASSEMBLY_OPCODE_X86_FISTTP, 16}, {S8_INITIALIZER("fisttpl"), ASSEMBLY_OPCODE_X86_FISTTP, 32},
                {S8_INITIALIZER("fisttpq"), ASSEMBLY_OPCODE_X86_FISTTP, 64}, {S8_INITIALIZER("fisttpll"), ASSEMBLY_OPCODE_X86_FISTTP, 64},
                {S8_INITIALIZER("fadds"), ASSEMBLY_OPCODE_X86_FADD, 32},   {S8_INITIALIZER("faddl"), ASSEMBLY_OPCODE_X86_FADD, 64},
                {S8_INITIALIZER("fmuls"), ASSEMBLY_OPCODE_X86_FMUL, 32},   {S8_INITIALIZER("fmull"), ASSEMBLY_OPCODE_X86_FMUL, 64},
                {S8_INITIALIZER("fsubs"), ASSEMBLY_OPCODE_X86_FSUB, 32},   {S8_INITIALIZER("fsubl"), ASSEMBLY_OPCODE_X86_FSUB, 64},
                {S8_INITIALIZER("fsubrs"), ASSEMBLY_OPCODE_X86_FSUBR, 32}, {S8_INITIALIZER("fsubrl"), ASSEMBLY_OPCODE_X86_FSUBR, 64},
                {S8_INITIALIZER("fdivs"), ASSEMBLY_OPCODE_X86_FDIV, 32},   {S8_INITIALIZER("fdivl"), ASSEMBLY_OPCODE_X86_FDIV, 64},
                {S8_INITIALIZER("fdivrs"), ASSEMBLY_OPCODE_X86_FDIVR, 32}, {S8_INITIALIZER("fdivrl"), ASSEMBLY_OPCODE_X86_FDIVR, 64},
                {S8_INITIALIZER("fcoms"), ASSEMBLY_OPCODE_X86_FCOM, 32},   {S8_INITIALIZER("fcoml"), ASSEMBLY_OPCODE_X86_FCOM, 64},
                {S8_INITIALIZER("fcomps"), ASSEMBLY_OPCODE_X86_FCOMP, 32}, {S8_INITIALIZER("fcompl"), ASSEMBLY_OPCODE_X86_FCOMP, 64},
                {S8_INITIALIZER("fiadds"), ASSEMBLY_OPCODE_X86_FIADD, 16}, {S8_INITIALIZER("fiaddl"), ASSEMBLY_OPCODE_X86_FIADD, 32},
                {S8_INITIALIZER("fimuls"), ASSEMBLY_OPCODE_X86_FIMUL, 16}, {S8_INITIALIZER("fimull"), ASSEMBLY_OPCODE_X86_FIMUL, 32},
                {S8_INITIALIZER("fisubs"), ASSEMBLY_OPCODE_X86_FISUB, 16}, {S8_INITIALIZER("fisubl"), ASSEMBLY_OPCODE_X86_FISUB, 32},
                {S8_INITIALIZER("fisubrs"), ASSEMBLY_OPCODE_X86_FISUBR, 16}, {S8_INITIALIZER("fisubrl"), ASSEMBLY_OPCODE_X86_FISUBR, 32},
                {S8_INITIALIZER("fidivs"), ASSEMBLY_OPCODE_X86_FIDIV, 16}, {S8_INITIALIZER("fidivl"), ASSEMBLY_OPCODE_X86_FIDIV, 32},
                {S8_INITIALIZER("fidivrs"), ASSEMBLY_OPCODE_X86_FIDIVR, 16}, {S8_INITIALIZER("fidivrl"), ASSEMBLY_OPCODE_X86_FIDIVR, 32},
            };
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(x87_memory_instructions); index += 1)
            {
                if (assembly_word_equal(mnemonic, x87_memory_instructions[index].name))
                {
                    *result = (AssemblyInstructionInfo){
                        .opcode = x87_memory_instructions[index].opcode,
                        .operand_count = 1,
                        .suffix_width = x87_memory_instructions[index].width,
                    };
                    return true;
                }
            }
        }
        if (syntax == ASSEMBLY_SYNTAX_INTEL && assembly_word_equal(mnemonic, S8("movq")))
        {
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_X86_MOVQ_MMX, .operand_count = 2};
            return true;
        }
        if (syntax == ASSEMBLY_SYNTAX_ATT)
        {
            static const struct
            {
                String8 name;
                AssemblyOpcode opcode;
                u8 destination_width;
                u8 source_width;
            } scalar_move_aliases[] = {
                {S8_INITIALIZER("movzbw"), ASSEMBLY_OPCODE_X86_MOVZX, 16, 8},
                {S8_INITIALIZER("movzbl"), ASSEMBLY_OPCODE_X86_MOVZX, 32, 8},
                {S8_INITIALIZER("movzbq"), ASSEMBLY_OPCODE_X86_MOVZX, 64, 8},
                {S8_INITIALIZER("movzwl"), ASSEMBLY_OPCODE_X86_MOVZX, 32, 16},
                {S8_INITIALIZER("movzwq"), ASSEMBLY_OPCODE_X86_MOVZX, 64, 16},
                {S8_INITIALIZER("movsbw"), ASSEMBLY_OPCODE_X86_MOVSX, 16, 8},
                {S8_INITIALIZER("movsbl"), ASSEMBLY_OPCODE_X86_MOVSX, 32, 8},
                {S8_INITIALIZER("movsbq"), ASSEMBLY_OPCODE_X86_MOVSX, 64, 8},
                {S8_INITIALIZER("movswl"), ASSEMBLY_OPCODE_X86_MOVSX, 32, 16},
                {S8_INITIALIZER("movswq"), ASSEMBLY_OPCODE_X86_MOVSX, 64, 16},
                {S8_INITIALIZER("movslq"), ASSEMBLY_OPCODE_X86_MOVSXD, 64, 32},
            };
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(scalar_move_aliases); index += 1)
            {
                if (assembly_word_equal(mnemonic, scalar_move_aliases[index].name))
                {
                    *result = (AssemblyInstructionInfo){
                        .opcode = scalar_move_aliases[index].opcode,
                        .operand_count = 2,
                        .suffix_width = scalar_move_aliases[index].destination_width,
                        .source_width = scalar_move_aliases[index].source_width,
                    };
                    return true;
                }
            }
        }
        if (assembly_x86_instruction_lookup_exact(mnemonic, result))
        {
            return true;
        }
        if (syntax == ASSEMBLY_SYNTAX_ATT && mnemonic.length > 1)
        {
            char8 suffix = assembly_ascii_lower(mnemonic.pointer[mnemonic.length - 1]);
            u8 width = suffix == 'b' ? 8 : suffix == 'w' ? 16 : suffix == 'l' ? 32 : suffix == 'q' ? 64 : 0;
            String8 base = {.pointer = mnemonic.pointer, .length = mnemonic.length - 1};
            if (width && assembly_x86_instruction_lookup_exact(base, result))
            {
                if (!result->operand_count && result->opcode != ASSEMBLY_OPCODE_X86_RET)
                {
                    return false;
                }
                if (result->opcode == ASSEMBLY_OPCODE_X86_JCC || result->opcode == ASSEMBLY_OPCODE_X86_SETCC)
                {
                    return false;
                }
                result->suffix_width = width;
                return true;
            }
        }
        return false;
    }
    if (target.cpu_arch == CPU_ARCH_AARCH64)
    {
        if (assembly_word_equal(mnemonic, S8("nop")))
        {
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_AARCH64_NOP};
        }
        else if (assembly_word_equal(mnemonic, S8("ret")))
        {
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_AARCH64_RET};
        }
        else if (assembly_word_equal(mnemonic, S8("b")))
        {
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_AARCH64_B, .operand_count = 1};
        }
        else if (assembly_word_equal(mnemonic, S8("bl")))
        {
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_AARCH64_BL, .operand_count = 1};
        }
        else if (assembly_aarch64_scalar_memory_mnemonic(mnemonic, 0, 0))
        {
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_COUNT, .operand_count = 2,
                                                .encoding_kind = ASSEMBLY_ENCODING_AARCH64_SCALAR_MEMORY};
        }
        else if (assembly_word_equal(mnemonic, S8("mov")))
        {
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_COUNT, .operand_count = 2,
                                                .encoding_kind = ASSEMBLY_ENCODING_AARCH64_GPR_ALIAS};
        }
        else if (assembly_word_equal(mnemonic, S8("cmp")) || assembly_word_equal(mnemonic, S8("cmn")))
        {
            // CMP/CMN are architectural aliases of SUBS/ADDS with ZR as the
            // destination.  The scalar parser materializes that implicit
            // operand so the generated canonical encoder remains authoritative.
            *result = (AssemblyInstructionInfo){.opcode = ASSEMBLY_OPCODE_COUNT, .operand_count = 2,
                                                .encoding_kind = ASSEMBLY_ENCODING_AARCH64_M1_SCALAR_INTEGER};
        }
        else
        {
            if (assembly_aarch64_direct_simd_lookup(mnemonic, result))
            {
                return true;
            }
            if (assembly_aarch64_system_fixed_row(target, mnemonic, result))
            {
                return true;
            }
            if (assembly_aarch64_system_lookup(target, mnemonic, result))
            {
                return true;
            }
            if (!assembly_aarch64_system_register_lookup(target, mnemonic, result))
            {
                if (!target_cpu_features_are_valid(target))
                {
                    return false;
                }
                u32 scalar_form_count = buster_aarch64_arm_m1_scalar_integer_form_count();
                u8 scalar_operand_count = 0;
                bool scalar_found = false;
                for (u32 form_index = 0; form_index < scalar_form_count; form_index += 1)
                {
                    BusterAarch64ArmM1ScalarIntegerForm form = {0};
                    if (!buster_aarch64_arm_m1_scalar_integer_form(form_index, &form) || !assembly_word_equal(mnemonic, form.mnemonic)) continue;
                    if (!scalar_found)
                    {
                        scalar_operand_count = form.operand_count;
                        scalar_found = true;
                    }
                    else if (scalar_operand_count != form.operand_count)
                    {
                        return false;
                    }
                }
                if (scalar_found)
                {
                    *result = (AssemblyInstructionInfo){
                        .opcode = ASSEMBLY_OPCODE_COUNT,
                        .operand_count = scalar_operand_count,
                        .encoding_kind = ASSEMBLY_ENCODING_AARCH64_M1_SCALAR_INTEGER,
                    };
                    return true;
                }
                if (assembly_aarch64_control_lookup(target, mnemonic, result))
                {
                    return true;
                }
                // The canonical direct-GPR projection is target-gated. Keep the
                // mnemonic known even when an explicit feature subtraction later
                // rejects the selected row, so diagnostics distinguish unsupported
                // features from malformed operands.
                u32 form_count = buster_aarch64_arm_m1_gpr_form_count();
                u8 operand_count = 0;
                bool found = false;
                for (u32 form_index = 0; form_index < form_count; form_index += 1)
                {
                    BusterAarch64ArmM1GprForm form = {0};
                    if (!buster_aarch64_arm_m1_gpr_form(form_index, &form) || !assembly_word_equal(mnemonic, form.mnemonic)) continue;
                    if (!found)
                    {
                        operand_count = form.operand_count;
                        found = true;
                    }
                    else if (operand_count != form.operand_count)
                    {
                        return false;
                    }
                }
                if (!found) return false;
                *result = (AssemblyInstructionInfo){
                    .opcode = ASSEMBLY_OPCODE_COUNT,
                    .operand_count = operand_count,
                    .encoding_kind = ASSEMBLY_ENCODING_AARCH64_M1_GPR,
                };
            }
        }
        return true;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_fixed_instruction_lookup(Target target, String8 statement, AssemblyInstructionInfo* result)
{
    if (!result || !buster_aarch64_arm_m1_fixed_target(target))
    {
        return false;
    }
    BusterAarch64ArmM1FixedSpelling fixed = {0};
    if (!buster_aarch64_arm_m1_fixed_lookup(statement, &fixed) ||
        !buster_aarch64_arm_m1_fixed_supported_for_target(fixed, target))
    {
        return false;
    }
    *result = (AssemblyInstructionInfo){
        .opcode = ASSEMBLY_OPCODE_COUNT,
        .encoding_kind = ASSEMBLY_ENCODING_AARCH64_FIXED_WORD,
        .fixed_word = fixed.word,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_sse2(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_MOVAPS && opcode <= ASSEMBLY_OPCODE_X86_DIVPD;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_avx(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_VMOVAPS && opcode <= ASSEMBLY_OPCODE_X86_VPMULLD;
}

typedef enum AssemblyVectorFormFlags
{
    ASSEMBLY_VECTOR_FORM_MOVE = 1u << 0,
    ASSEMBLY_VECTOR_FORM_SCALAR = 1u << 1,
    ASSEMBLY_VECTOR_FORM_INTEGER = 1u << 2,
    ASSEMBLY_VECTOR_FORM_MASK_DESTINATION = 1u << 3,
    ASSEMBLY_VECTOR_FORM_IMMEDIATE = 1u << 4,
    ASSEMBLY_VECTOR_FORM_SOURCE_RM = 1u << 5,
    ASSEMBLY_VECTOR_FORM_AVX512BW = 1u << 6,
    ASSEMBLY_VECTOR_FORM_ROUNDING = 1u << 7,
    ASSEMBLY_VECTOR_FORM_VEX_ONLY = 1u << 8,
    ASSEMBLY_VECTOR_FORM_BROADCAST = 1u << 9,
    ASSEMBLY_VECTOR_FORM_SAE = 1u << 10,
    ASSEMBLY_VECTOR_FORM_AVX512DQ = 1u << 11,
} AssemblyVectorFormFlags;

typedef struct AssemblyVectorForm AssemblyVectorForm;
struct AssemblyVectorForm
{
    AssemblyOpcode opcode;
    u8 map;
    u8 mandatory_prefix;
    u8 opcode_byte;
    u8 element_width;
    u16 flags;
    bool wide;
};

BUSTER_GLOBAL_LOCAL AssemblyVectorForm const* assembly_x86_vector_form(AssemblyOpcode opcode)
{
    static AssemblyVectorForm const forms[] = {
        {ASSEMBLY_OPCODE_X86_VMOVAPS, 1, 0, 0x28, 4, ASSEMBLY_VECTOR_FORM_MOVE, true},
        {ASSEMBLY_OPCODE_X86_VMOVUPS, 1, 0, 0x10, 4, ASSEMBLY_VECTOR_FORM_MOVE, true},
        {ASSEMBLY_OPCODE_X86_VMOVAPD, 1, 1, 0x28, 8, ASSEMBLY_VECTOR_FORM_MOVE, true},
        {ASSEMBLY_OPCODE_X86_VMOVUPD, 1, 1, 0x10, 8, ASSEMBLY_VECTOR_FORM_MOVE, true},
        {ASSEMBLY_OPCODE_X86_VXORPS, 1, 0, 0x57, 4, ASSEMBLY_VECTOR_FORM_BROADCAST | ASSEMBLY_VECTOR_FORM_AVX512DQ, true},
        {ASSEMBLY_OPCODE_X86_VXORPD, 1, 1, 0x57, 8, ASSEMBLY_VECTOR_FORM_BROADCAST | ASSEMBLY_VECTOR_FORM_AVX512DQ, true},
        {ASSEMBLY_OPCODE_X86_VADDPS, 1, 0, 0x58, 4, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VADDPD, 1, 1, 0x58, 8, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VADDSS, 1, 2, 0x58, 4, ASSEMBLY_VECTOR_FORM_SCALAR | ASSEMBLY_VECTOR_FORM_ROUNDING, false},
        {ASSEMBLY_OPCODE_X86_VADDSD, 1, 3, 0x58, 8, ASSEMBLY_VECTOR_FORM_SCALAR | ASSEMBLY_VECTOR_FORM_ROUNDING, false},
        {ASSEMBLY_OPCODE_X86_VSUBPS, 1, 0, 0x5c, 4, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VSUBPD, 1, 1, 0x5c, 8, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VMULPS, 1, 0, 0x59, 4, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VMULPD, 1, 1, 0x59, 8, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VDIVPS, 1, 0, 0x5e, 4, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VDIVPD, 1, 1, 0x5e, 8, ASSEMBLY_VECTOR_FORM_ROUNDING | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQA, 1, 1, 0x6f, 4,
         ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_VEX_ONLY, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQU, 1, 2, 0x6f, 4,
         ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_VEX_ONLY, true},
        {ASSEMBLY_OPCODE_X86_VPADDB, 1, 1, 0xfc, 1, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPADDW, 1, 1, 0xfd, 2, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPADDD, 1, 1, 0xfe, 4, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPADDQ, 1, 1, 0xd4, 8, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPSUBB, 1, 1, 0xf8, 1, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPSUBW, 1, 1, 0xf9, 2, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPSUBD, 1, 1, 0xfa, 4, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPSUBQ, 1, 1, 0xfb, 8, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPAND, 1, 1, 0xdb, 8, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_VEX_ONLY, true},
        {ASSEMBLY_OPCODE_X86_VPOR, 1, 1, 0xeb, 8, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_VEX_ONLY, true},
        {ASSEMBLY_OPCODE_X86_VPXOR, 1, 1, 0xef, 8, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_VEX_ONLY, true},
        {ASSEMBLY_OPCODE_X86_VPCMPEQB, 1, 1, 0x74, 1,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPCMPEQW, 1, 1, 0x75, 2,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPCMPEQD, 1, 1, 0x76, 4, ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPCMPEQQ, 2, 1, 0x29, 8, ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPCMPGTB, 1, 1, 0x64, 1,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPCMPGTW, 1, 1, 0x65, 2,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPCMPGTD, 1, 1, 0x66, 4, ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPCMPGTQ, 2, 1, 0x37, 8, ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPMULLW, 1, 1, 0xd5, 2, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPMULLD, 2, 1, 0x40, 4, ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQA32, 1, 1, 0x6f, 4, ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQU32, 1, 2, 0x6f, 4, ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQA64, 1, 1, 0x6f, 8, ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQU64, 1, 2, 0x6f, 8, ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQU8, 1, 3, 0x6f, 1, ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VMOVDQU16, 1, 3, 0x6f, 2, ASSEMBLY_VECTOR_FORM_MOVE | ASSEMBLY_VECTOR_FORM_INTEGER | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VCMPPS, 1, 0, 0xc2, 4,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_BROADCAST |
             ASSEMBLY_VECTOR_FORM_SAE,
         true},
        {ASSEMBLY_OPCODE_X86_VCMPPD, 1, 1, 0xc2, 8,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_BROADCAST |
             ASSEMBLY_VECTOR_FORM_SAE,
         true},
        {ASSEMBLY_OPCODE_X86_VPCMPD, 3, 1, 0x1f, 4,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPCMPQ, 3, 1, 0x1f, 8,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPCMPB, 3, 1, 0x3f, 1, ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPCMPW, 3, 1, 0x3f, 2, ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_AVX512BW, true},
        {ASSEMBLY_OPCODE_X86_VPCMPUD, 3, 1, 0x1e, 4,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VPCMPUQ, 3, 1, 0x1e, 8,
         ASSEMBLY_VECTOR_FORM_MASK_DESTINATION | ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_BROADCAST, true},
        {ASSEMBLY_OPCODE_X86_VRNDSCALEPS, 3, 1, 0x08, 4,
         ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_SOURCE_RM | ASSEMBLY_VECTOR_FORM_BROADCAST |
             ASSEMBLY_VECTOR_FORM_SAE,
         true},
        {ASSEMBLY_OPCODE_X86_VRNDSCALEPD, 3, 1, 0x09, 8,
         ASSEMBLY_VECTOR_FORM_IMMEDIATE | ASSEMBLY_VECTOR_FORM_SOURCE_RM | ASSEMBLY_VECTOR_FORM_BROADCAST |
             ASSEMBLY_VECTOR_FORM_SAE,
         true},
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(forms); index += 1)
    {
        if (forms[index].opcode == opcode)
        {
            return forms + index;
        }
    }
    return 0;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_vector_register(AssemblyRegister reg)
{
    return reg.class == ASSEMBLY_REGISTER_XMM || reg.class == ASSEMBLY_REGISTER_YMM || reg.class == ASSEMBLY_REGISTER_ZMM;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_target_has_evex(Target target, u16 width, u8 scalar)
{
    u8 avx10 = target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_1) ||
               target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_2);
    bool result;
    if (scalar)
    {
        result = avx10 || target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX512F);
    }
    else if (width == 512)
    {
        result = target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX512F) || target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_512);
    }
    else
    {
        result = avx10 || (target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX512F) && target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX512VL));
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_uses_evex(AssemblyInstruction instruction, Target target)
{
    (void)target;
    if ((instruction.opcode >= ASSEMBLY_OPCODE_X86_VMOVDQA32 &&
         instruction.opcode <= ASSEMBLY_OPCODE_X86_VRNDSCALEPD) ||
        instruction.opcode == ASSEMBLY_OPCODE_X86_APX_PUSH2 || instruction.opcode == ASSEMBLY_OPCODE_X86_APX_POP2)
    {
        return true;
    }
    for (u32 index = 0; index < instruction.operand_count; index += 1)
    {
        AssemblyOperand operand = instruction.operands[index];
        if ((operand.kind == ASSEMBLY_OPERAND_REGISTER &&
             (operand.reg.class == ASSEMBLY_REGISTER_ZMM || operand.reg.class == ASSEMBLY_REGISTER_OPMASK || operand.reg.index >= 16)) || operand.has_mask || operand.zeroing ||
            operand.broadcast || operand.rounding || operand.sae ||
            (operand.kind == ASSEMBLY_OPERAND_MEMORY &&
             ((operand.memory.has_base && operand.memory.base.index >= 16) ||
              (operand.memory.has_index && operand.memory.index.index >= 16))))
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL u16 assembly_x86_instruction_vector_width(AssemblyInstruction instruction, AssemblyVectorForm const* form)
{
    if (!form)
    {
        return 0;
    }
    u32 first = (form->flags & ASSEMBLY_VECTOR_FORM_MASK_DESTINATION) ? 1 : 0;
    for (u32 index = first; index < instruction.operand_count; index += 1)
    {
        AssemblyOperand operand = instruction.operands[index];
        if (operand.kind == ASSEMBLY_OPERAND_REGISTER && assembly_x86_vector_register(operand.reg))
        {
            return operand.reg.width;
        }
    }
    return 512;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_operand_decorators_parse(String8* text, AssemblySyntax syntax, AssemblyOperand* operand,
                                                               bool* no_flags)
{
    u64 first_brace = string_first_code_unit(*text, '{');
    if (first_brace != BUSTER_STRING_NO_MATCH)
    {
        String8 core = assembly_trim(string_slice(*text, 0, first_brace));
        u64 cursor = first_brace;
        while (cursor < text->length)
        {
            while (cursor < text->length && assembly_space(text->pointer[cursor]))
            {
                cursor += 1;
            }
            if (cursor >= text->length || text->pointer[cursor] != '{')
            {
                return false;
            }
            u64 end = cursor + 1;
            while (end < text->length && text->pointer[end] != '}')
            {
                end += 1;
            }
            if (end >= text->length)
            {
                return false;
            }
            String8 decorator = assembly_trim(string_slice(*text, cursor + 1, end));
            if (assembly_word_equal(decorator, S8("z")))
            {
                if (operand->zeroing)
                {
                    return false;
                }
                operand->zeroing = true;
            }
            else if (assembly_word_equal(decorator, S8("sae")))
            {
                if (operand->sae || operand->rounding)
                {
                    return false;
                }
                operand->sae = true;
            }
            else if (assembly_word_equal(decorator, S8("rn-sae")) || assembly_word_equal(decorator, S8("rd-sae")) ||
                     assembly_word_equal(decorator, S8("ru-sae")) || assembly_word_equal(decorator, S8("rz-sae")))
            {
                if (operand->rounding || operand->sae)
                {
                    return false;
                }
                operand->rounding = assembly_word_equal(decorator, S8("rn-sae")) ? 1
                                   : assembly_word_equal(decorator, S8("rd-sae")) ? 2
                                   : assembly_word_equal(decorator, S8("ru-sae")) ? 3
                                                                                    : 4;
                operand->sae = true;
            }
            else if (decorator.length > 3 && assembly_word_equal(string_slice(decorator, 0, 3), S8("1to")))
            {
                s64 lanes = 0;
                if (!assembly_parse_s64(string_slice(decorator, 3, decorator.length), &lanes) || lanes < 2 || lanes > UINT8_MAX)
                {
                    return false;
                }
                if (operand->broadcast)
                {
                    return false;
                }
                operand->broadcast = (u8)lanes;
            }
            else if (assembly_word_equal(decorator, S8("nf")))
            {
                if (!no_flags || *no_flags)
                {
                    return false;
                }
                *no_flags = true;
            }
            else
            {
                AssemblyRegister mask = {0};
                if (operand->has_mask || !assembly_register_parse(decorator, syntax, &mask) ||
                    mask.class != ASSEMBLY_REGISTER_OPMASK)
                {
                    return false;
                }
                operand->mask = mask.index;
                operand->has_mask = true;
            }
            cursor = end + 1;
        }
        *text = core;
    }

    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_avx_move(AssemblyOpcode opcode)
{
    return (opcode >= ASSEMBLY_OPCODE_X86_VMOVAPS && opcode <= ASSEMBLY_OPCODE_X86_VMOVUPD) ||
           opcode == ASSEMBLY_OPCODE_X86_VMOVDQA || opcode == ASSEMBLY_OPCODE_X86_VMOVDQU;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_avx_integer(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_VPADDB && opcode <= ASSEMBLY_OPCODE_X86_VPMULLD;
}

BUSTER_GLOBAL_LOCAL u8 assembly_x86_avx_map(AssemblyOpcode opcode)
{
    return opcode == ASSEMBLY_OPCODE_X86_VPCMPEQQ || opcode == ASSEMBLY_OPCODE_X86_VPCMPGTQ ||
                   opcode == ASSEMBLY_OPCODE_X86_VPMULLD
               ? 2
               : 1;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_legacy_packed(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_MOVQ_MMX && opcode <= ASSEMBLY_OPCODE_X86_PMULLW_MMX;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_data(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_FLD && opcode <= ASSEMBLY_OPCODE_X86_FISTTP;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_arithmetic(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_FADD && opcode <= ASSEMBLY_OPCODE_X86_FDIVR;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_pop_arithmetic(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_FADDP && opcode <= ASSEMBLY_OPCODE_X86_FDIVRP;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_compare(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_FCOM && opcode <= ASSEMBLY_OPCODE_X86_FCMOVCC;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_integer_arithmetic(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_FIADD && opcode <= ASSEMBLY_OPCODE_X86_FIDIVR;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_state_memory(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_FBLD && opcode <= ASSEMBLY_OPCODE_X86_FSTSW;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_stack_control(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_FFREE && opcode <= ASSEMBLY_OPCODE_X86_FDECSTP;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_x87_zero_operand(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_F2XM1 && opcode <= ASSEMBLY_OPCODE_X86_FWAIT;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_operand_count_valid(AssemblyOpcode opcode, u8 count, u8 canonical_count)
{
    if (opcode == ASSEMBLY_OPCODE_X86_SHL || opcode == ASSEMBLY_OPCODE_X86_SHR || opcode == ASSEMBLY_OPCODE_X86_SAR)
    {
        return count == 2 || count == 3;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_IMUL)
    {
        return count >= 1 && count <= 3;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_ADD || opcode == ASSEMBLY_OPCODE_X86_ADC || opcode == ASSEMBLY_OPCODE_X86_SUB ||
        opcode == ASSEMBLY_OPCODE_X86_SBB || opcode == ASSEMBLY_OPCODE_X86_AND || opcode == ASSEMBLY_OPCODE_X86_OR ||
        opcode == ASSEMBLY_OPCODE_X86_XOR)
    {
        return count == 2 || count == 3;
    }
    if (assembly_x86_opcode_is_x87_arithmetic(opcode) || assembly_x86_opcode_is_x87_pop_arithmetic(opcode))
    {
        return count <= 2;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_FXCH || opcode == ASSEMBLY_OPCODE_X86_FCOM || opcode == ASSEMBLY_OPCODE_X86_FCOMP ||
        opcode == ASSEMBLY_OPCODE_X86_FUCOM || opcode == ASSEMBLY_OPCODE_X86_FUCOMP)
    {
        return count <= 1;
    }
    return count == canonical_count;
}

BUSTER_GLOBAL_LOCAL AssemblyOperand assembly_x86_x87_register_operand(u8 index)
{
    return (AssemblyOperand){
        .reg = {.index = index, .width = 80, .class = ASSEMBLY_REGISTER_X87},
        .kind = ASSEMBLY_OPERAND_REGISTER,
    };
}

BUSTER_GLOBAL_LOCAL void assembly_x86_x87_normalize_omitted_operands(AssemblyInstruction* instruction, AssemblySyntax syntax)
{
    if (instruction->operand_count == 0)
    {
        if (assembly_x86_opcode_is_x87_arithmetic(instruction->opcode))
        {
            instruction->opcode = instruction->opcode == ASSEMBLY_OPCODE_X86_FADD ? ASSEMBLY_OPCODE_X86_FADDP
                                  : instruction->opcode == ASSEMBLY_OPCODE_X86_FMUL ? ASSEMBLY_OPCODE_X86_FMULP
                                  : instruction->opcode == ASSEMBLY_OPCODE_X86_FSUB
                                      ? (syntax == ASSEMBLY_SYNTAX_ATT ? ASSEMBLY_OPCODE_X86_FSUBRP : ASSEMBLY_OPCODE_X86_FSUBP)
                                  : instruction->opcode == ASSEMBLY_OPCODE_X86_FSUBR
                                      ? (syntax == ASSEMBLY_SYNTAX_ATT ? ASSEMBLY_OPCODE_X86_FSUBP : ASSEMBLY_OPCODE_X86_FSUBRP)
                                  : instruction->opcode == ASSEMBLY_OPCODE_X86_FDIV
                                      ? (syntax == ASSEMBLY_SYNTAX_ATT ? ASSEMBLY_OPCODE_X86_FDIVRP : ASSEMBLY_OPCODE_X86_FDIVP)
                                      : (syntax == ASSEMBLY_SYNTAX_ATT ? ASSEMBLY_OPCODE_X86_FDIVP : ASSEMBLY_OPCODE_X86_FDIVRP);
            instruction->operands[0] = assembly_x86_x87_register_operand(1);
            instruction->operands[1] = assembly_x86_x87_register_operand(0);
            instruction->operand_count = 2;
        }
        else if (assembly_x86_opcode_is_x87_pop_arithmetic(instruction->opcode))
        {
            if (syntax == ASSEMBLY_SYNTAX_ATT)
            {
                instruction->opcode = instruction->opcode == ASSEMBLY_OPCODE_X86_FSUBP ? ASSEMBLY_OPCODE_X86_FSUBRP
                                      : instruction->opcode == ASSEMBLY_OPCODE_X86_FSUBRP ? ASSEMBLY_OPCODE_X86_FSUBP
                                      : instruction->opcode == ASSEMBLY_OPCODE_X86_FDIVP ? ASSEMBLY_OPCODE_X86_FDIVRP
                                      : instruction->opcode == ASSEMBLY_OPCODE_X86_FDIVRP ? ASSEMBLY_OPCODE_X86_FDIVP
                                                                                          : instruction->opcode;
            }
            instruction->operands[0] = assembly_x86_x87_register_operand(1);
            instruction->operands[1] = assembly_x86_x87_register_operand(0);
            instruction->operand_count = 2;
        }
        else if (instruction->opcode == ASSEMBLY_OPCODE_X86_FXCH || instruction->opcode == ASSEMBLY_OPCODE_X86_FCOM ||
                 instruction->opcode == ASSEMBLY_OPCODE_X86_FCOMP || instruction->opcode == ASSEMBLY_OPCODE_X86_FUCOM ||
                 instruction->opcode == ASSEMBLY_OPCODE_X86_FUCOMP)
        {
            instruction->operands[0] = assembly_x86_x87_register_operand(1);
            instruction->operand_count = 1;
        }
    }
    else if (instruction->operand_count == 1 && instruction->operands[0].kind == ASSEMBLY_OPERAND_REGISTER)
    {
        if (assembly_x86_opcode_is_x87_arithmetic(instruction->opcode))
        {
            instruction->operands[1] = instruction->operands[0];
            instruction->operands[0] = assembly_x86_x87_register_operand(0);
            instruction->operand_count = 2;
        }
        else if (assembly_x86_opcode_is_x87_pop_arithmetic(instruction->opcode))
        {
            if (syntax == ASSEMBLY_SYNTAX_ATT)
            {
                instruction->opcode = instruction->opcode == ASSEMBLY_OPCODE_X86_FSUBP ? ASSEMBLY_OPCODE_X86_FSUBRP
                                      : instruction->opcode == ASSEMBLY_OPCODE_X86_FSUBRP ? ASSEMBLY_OPCODE_X86_FSUBP
                                      : instruction->opcode == ASSEMBLY_OPCODE_X86_FDIVP ? ASSEMBLY_OPCODE_X86_FDIVRP
                                      : instruction->opcode == ASSEMBLY_OPCODE_X86_FDIVRP ? ASSEMBLY_OPCODE_X86_FDIVP
                                                                                          : instruction->opcode;
            }
            instruction->operands[1] = assembly_x86_x87_register_operand(0);
            instruction->operand_count = 2;
        }
    }
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_rex_needed(u16 width, AssemblyRegister first, AssemblyRegister second)
{
    return width == 64 || first.index >= 8 || second.index >= 8 ||
           (width == 8 && ((first.index >= 4 && !first.high_byte) || (second.index >= 4 && !second.high_byte)));
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_extension_rex_needed(u16 width, AssemblyRegister destination, AssemblyRegister source,
                                                            u16 source_width)
{
    return assembly_x86_rex_needed(width, destination, source) ||
           (source_width == 8 && source.index >= 4 && !source.high_byte);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_displacement_size(AssemblyMemory memory, u32* result)
{
    if (memory.rip_relative || !memory.has_base)
    {
        if (!memory.displacement.has_symbol && (memory.displacement.addend < INT32_MIN || memory.displacement.addend > INT32_MAX))
        {
            return false;
        }
        *result = 4;
        return true;
    }
    if (memory.displacement.has_symbol)
    {
        *result = 4;
    }
    else if (!memory.displacement.addend && (memory.base.index & 7) != 5)
    {
        *result = 0;
    }
    else if (memory.displacement.addend >= INT8_MIN && memory.displacement.addend <= INT8_MAX)
    {
        *result = 1;
    }
    else if (memory.displacement.addend >= INT32_MIN && memory.displacement.addend <= INT32_MAX)
    {
        *result = 4;
    }
    else
    {
        return false;
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_encoding_size(AssemblyMemory memory, u32* result)
{
    u32 displacement_size = 0;
    if (!assembly_x86_memory_displacement_size(memory, &displacement_size))
    {
        return false;
    }
    u8 sib = !memory.rip_relative && (memory.has_index || !memory.has_base || (memory.base.index & 7) == 4);
    *result = 1u + (u32)sib + displacement_size;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_rex_needed(u16 width, AssemblyRegister reg, AssemblyMemory memory)
{
    return width == 64 || reg.index >= 8 || (memory.has_base && memory.base.index >= 8) ||
           (memory.has_index && memory.index.index >= 8) || (width == 8 && reg.index >= 4 && !reg.high_byte);
}

BUSTER_GLOBAL_LOCAL u16 assembly_operand_width(AssemblyOperand operand)
{
    return operand.kind == ASSEMBLY_OPERAND_REGISTER ? operand.reg.width
           : operand.kind == ASSEMBLY_OPERAND_MEMORY ? operand.memory.width
                                                      : 0;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_rotate(AssemblyOpcode opcode)
{
    return opcode == ASSEMBLY_OPCODE_X86_ROL || opcode == ASSEMBLY_OPCODE_X86_ROR || opcode == ASSEMBLY_OPCODE_X86_RCL ||
           opcode == ASSEMBLY_OPCODE_X86_RCR;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_count_is_cl(AssemblyOperand operand)
{
    return operand.kind == ASSEMBLY_OPERAND_REGISTER && operand.reg.class == ASSEMBLY_REGISTER_GPR && operand.reg.width == 8 &&
           operand.reg.index == 1;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_vex_three_byte_needed(AssemblyOperand rm)
{
    return (rm.kind == ASSEMBLY_OPERAND_REGISTER && rm.reg.index >= 8) ||
           (rm.kind == ASSEMBLY_OPERAND_MEMORY && ((rm.memory.has_base && rm.memory.base.index >= 8) ||
                                                   (rm.memory.has_index && rm.memory.index.index >= 8)));
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_immediate_fits(s64 value, u16 width, bool signed_only)
{
    if (width == 64)
    {
        return true;
    }
    s64 signed_minimum = -(INT64_C(1) << (width - 1));
    u64 unsigned_maximum = (UINT64_C(1) << width) - 1;
    return value >= signed_minimum && (signed_only ? value <= (s64)(unsigned_maximum >> 1) : value < 0 || (u64)value <= unsigned_maximum);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_count_immediate_valid(AssemblyOperand operand)
{
    return operand.kind == ASSEMBLY_OPERAND_EXPRESSION && !operand.expression.has_symbol &&
           assembly_x86_immediate_fits(operand.expression.addend, 8, false);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_bit_atomic(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_BSF && opcode <= ASSEMBLY_OPCODE_X86_TZCNT;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_target_has_bit_atomic_feature(Target target, TargetCpuFeature feature)
{
    return target_cpu_feature_has(target, feature);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_operand_is_gpr(AssemblyOperand operand)
{
    return operand.kind == ASSEMBLY_OPERAND_REGISTER && operand.reg.class == ASSEMBLY_REGISTER_GPR;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_rex_conflicts_high_byte(u16 width, AssemblyRegister first, AssemblyRegister second)
{
    return assembly_x86_rex_needed(width, first, second) && (first.high_byte || second.high_byte);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_rex_conflicts_high_byte(u16 width, AssemblyRegister reg, AssemblyMemory memory)
{
    return assembly_x86_memory_rex_needed(width, reg, memory) && reg.high_byte;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_memory_set_width(AssemblyOperand* operand, u16 width)
{
    if (operand->memory.width && operand->memory.width != width)
    {
        return false;
    }
    operand->memory.width = width;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_lock_prefix_legal(AssemblyInstruction* instruction)
{
    if (!instruction->lock_prefix)
    {
        return true;
    }
    AssemblyOpcode opcode = instruction->opcode;
    AssemblyOperand first = instruction->operands[0];
    if (opcode == ASSEMBLY_OPCODE_X86_XCHG)
    {
        return first.kind == ASSEMBLY_OPERAND_MEMORY || instruction->operands[1].kind == ASSEMBLY_OPERAND_MEMORY;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_BTC || opcode == ASSEMBLY_OPCODE_X86_BTR || opcode == ASSEMBLY_OPCODE_X86_BTS ||
        opcode == ASSEMBLY_OPCODE_X86_XADD || opcode == ASSEMBLY_OPCODE_X86_CMPXCHG ||
        opcode == ASSEMBLY_OPCODE_X86_CMPXCHG8B || opcode == ASSEMBLY_OPCODE_X86_CMPXCHG16B)
    {
        return first.kind == ASSEMBLY_OPERAND_MEMORY;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_ADD || opcode == ASSEMBLY_OPCODE_X86_ADC || opcode == ASSEMBLY_OPCODE_X86_SUB ||
        opcode == ASSEMBLY_OPCODE_X86_SBB || opcode == ASSEMBLY_OPCODE_X86_AND || opcode == ASSEMBLY_OPCODE_X86_OR ||
        opcode == ASSEMBLY_OPCODE_X86_XOR || opcode == ASSEMBLY_OPCODE_X86_INC || opcode == ASSEMBLY_OPCODE_X86_DEC ||
        opcode == ASSEMBLY_OPCODE_X86_NEG || opcode == ASSEMBLY_OPCODE_X86_NOT)
    {
        return first.kind == ASSEMBLY_OPERAND_MEMORY;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_bit_atomic_instruction_size(AssemblyInstruction* instruction)
{
    AssemblyOpcode opcode = instruction->opcode;
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    u32 lock_size = instruction->lock_prefix ? 1 : 0;
    if (assembly_x86_lock_prefix_legal(instruction))
    {
        if (opcode == ASSEMBLY_OPCODE_X86_BSF || opcode == ASSEMBLY_OPCODE_X86_BSR || opcode == ASSEMBLY_OPCODE_X86_POPCNT ||
            opcode == ASSEMBLY_OPCODE_X86_LZCNT || opcode == ASSEMBLY_OPCODE_X86_TZCNT)
        {
            if (!assembly_x86_operand_is_gpr(*first) || first->reg.width == 8 ||
                (first->reg.width != 16 && first->reg.width != 32 && first->reg.width != 64) ||
                (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY))
            {
                return false;
            }
            instruction->width = first->reg.width;
            if (second->kind == ASSEMBLY_OPERAND_REGISTER)
            {
                if (!assembly_x86_operand_is_gpr(*second) || second->reg.width != instruction->width ||
                    assembly_x86_rex_conflicts_high_byte(instruction->width, first->reg, second->reg))
                {
                    return false;
                }
            }
            else
            {
                if (!assembly_x86_memory_set_width(second, instruction->width) ||
                    assembly_x86_memory_rex_conflicts_high_byte(instruction->width, first->reg, second->memory))
                {
                    return false;
                }
            }
            u32 address_size = 1;
            if (second->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(second->memory, &address_size))
            {
                return false;
            }
            u8 rex = second->kind == ASSEMBLY_OPERAND_REGISTER
                           ? assembly_x86_rex_needed(instruction->width, first->reg, second->reg)
                           : assembly_x86_memory_rex_needed(instruction->width, first->reg, second->memory);
            u32 mandatory_prefix = opcode == ASSEMBLY_OPCODE_X86_BSF || opcode == ASSEMBLY_OPCODE_X86_BSR ? 0 : 1;
            instruction->size = lock_size + (instruction->width == 16 ? 1 : 0) + mandatory_prefix + (rex ? 1 : 0) + 2 + address_size;
            return true;
        }
        if (opcode == ASSEMBLY_OPCODE_X86_BSWAP)
        {
            if (!assembly_x86_operand_is_gpr(*first) || (first->reg.width != 32 && first->reg.width != 64) ||
                instruction->operand_count != 1)
            {
                return false;
            }
            instruction->width = first->reg.width;
            u8 rex = assembly_x86_rex_needed(instruction->width, (AssemblyRegister){0}, first->reg);
            instruction->size = lock_size + (rex ? 1 : 0) + 2;
            return true;
        }
        if (opcode == ASSEMBLY_OPCODE_X86_BT || opcode == ASSEMBLY_OPCODE_X86_BTC || opcode == ASSEMBLY_OPCODE_X86_BTR ||
            opcode == ASSEMBLY_OPCODE_X86_BTS)
        {
            if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
                (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_EXPRESSION))
            {
                return false;
            }
            instruction->width = assembly_operand_width(*first);
            if (second->kind == ASSEMBLY_OPERAND_REGISTER)
            {
                if (!assembly_x86_operand_is_gpr(*second))
                {
                    return false;
                }
                if (!instruction->width)
                {
                    instruction->width = second->reg.width;
                }
                if (second->reg.width != instruction->width)
                {
                    return false;
                }
            }
            else if (!instruction->width)
            {
                return false;
            }
            if (instruction->width != 16 && instruction->width != 32 && instruction->width != 64)
            {
                return false;
            }
            if (first->kind == ASSEMBLY_OPERAND_REGISTER && !assembly_x86_operand_is_gpr(*first))
            {
                return false;
            }
            if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(first, instruction->width))
            {
                return false;
            }
            if (second->kind == ASSEMBLY_OPERAND_EXPRESSION &&
                (second->expression.has_symbol || second->expression.addend < 0 || second->expression.addend > UINT8_MAX))
            {
                return false;
            }
            u8 reg = second->kind == ASSEMBLY_OPERAND_EXPRESSION
                         ? opcode == ASSEMBLY_OPCODE_X86_BT   ? 4
                           : opcode == ASSEMBLY_OPCODE_X86_BTS ? 5
                           : opcode == ASSEMBLY_OPCODE_X86_BTR ? 6
                                                           : 7
                         : second->reg.index;
            u8 rex = first->kind == ASSEMBLY_OPERAND_REGISTER
                           ? assembly_x86_rex_needed(instruction->width, (AssemblyRegister){.index = reg}, first->reg)
                           : assembly_x86_memory_rex_needed(instruction->width, (AssemblyRegister){.index = reg}, first->memory);
            if (first->kind == ASSEMBLY_OPERAND_REGISTER &&
                assembly_x86_rex_conflicts_high_byte(instruction->width, (AssemblyRegister){.index = reg}, first->reg))
            {
                return false;
            }
            u32 address_size = 1;
            if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
            {
                return false;
            }
            instruction->size = lock_size + (instruction->width == 16 ? 1 : 0) + (rex ? 1 : 0) +
                                (second->kind == ASSEMBLY_OPERAND_EXPRESSION ? 3 : 2) + address_size;
            return true;
        }
        if (opcode == ASSEMBLY_OPCODE_X86_XCHG)
        {
            AssemblyOperand* memory = first->kind == ASSEMBLY_OPERAND_MEMORY ? first : second->kind == ASSEMBLY_OPERAND_MEMORY ? second : 0;
            if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
                (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
                (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY))
            {
                return false;
            }
            if (!assembly_x86_operand_is_gpr(*first) && first->kind != ASSEMBLY_OPERAND_MEMORY)
            {
                return false;
            }
            if (!assembly_x86_operand_is_gpr(*second) && second->kind != ASSEMBLY_OPERAND_MEMORY)
            {
                return false;
            }
            instruction->width = first->kind == ASSEMBLY_OPERAND_REGISTER ? first->reg.width : second->reg.width;
            if (instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64)
            {
                return false;
            }
            if (first->kind == ASSEMBLY_OPERAND_REGISTER && second->kind == ASSEMBLY_OPERAND_REGISTER &&
                (first->reg.width != instruction->width || second->reg.width != instruction->width))
            {
                return false;
            }
            if (memory && !assembly_x86_memory_set_width(memory, instruction->width))
            {
                return false;
            }
            if (!memory && instruction->width != 8 && (first->reg.index == 0 || second->reg.index == 0))
            {
                AssemblyRegister other = first->reg.index == 0 ? second->reg : first->reg;
                u8 rex = assembly_x86_rex_needed(instruction->width, (AssemblyRegister){0}, other);
                instruction->size = lock_size + (instruction->width == 16 ? 1 : 0) + (rex ? 1 : 0) + 1;
                return true;
            }
            AssemblyRegister reg = first->kind == ASSEMBLY_OPERAND_MEMORY ? second->reg : first->reg;
            AssemblyOperand* rm = first->kind == ASSEMBLY_OPERAND_MEMORY ? first : second;
            if (rm->kind == ASSEMBLY_OPERAND_REGISTER && assembly_x86_rex_conflicts_high_byte(instruction->width, reg, rm->reg))
            {
                return false;
            }
            u32 address_size = 1;
            u8 rex = rm->kind == ASSEMBLY_OPERAND_MEMORY
                           ? assembly_x86_memory_rex_needed(instruction->width, reg, rm->memory)
                           : assembly_x86_rex_needed(instruction->width, reg, rm->reg);
            if (rm->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(rm->memory, &address_size))
            {
                return false;
            }
            if (rm->kind == ASSEMBLY_OPERAND_MEMORY && assembly_x86_memory_rex_conflicts_high_byte(instruction->width, reg, rm->memory))
            {
                return false;
            }
            instruction->size = lock_size + (instruction->width == 16 ? 1 : 0) + (rex ? 1 : 0) + 1 + address_size;
            return true;
        }
        if (opcode == ASSEMBLY_OPCODE_X86_XADD || opcode == ASSEMBLY_OPCODE_X86_CMPXCHG)
        {
            if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
                !assembly_x86_operand_is_gpr(*second))
            {
                return false;
            }
            instruction->width = assembly_operand_width(*first);
            if (!instruction->width)
            {
                instruction->width = second->reg.width;
            }
            if ((instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64) ||
                second->reg.width != instruction->width || (first->kind == ASSEMBLY_OPERAND_REGISTER && !assembly_x86_operand_is_gpr(*first)))
            {
                return false;
            }
            if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(first, instruction->width))
            {
                return false;
            }
            u32 address_size = 1;
            u8 rex = first->kind == ASSEMBLY_OPERAND_MEMORY
                           ? assembly_x86_memory_rex_needed(instruction->width, second->reg, first->memory)
                           : assembly_x86_rex_needed(instruction->width, second->reg, first->reg);
            if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
            {
                return false;
            }
            if ((first->kind == ASSEMBLY_OPERAND_REGISTER && assembly_x86_rex_conflicts_high_byte(instruction->width, second->reg, first->reg)) ||
                (first->kind == ASSEMBLY_OPERAND_MEMORY && assembly_x86_memory_rex_conflicts_high_byte(instruction->width, second->reg, first->memory)))
            {
                return false;
            }
            instruction->size = lock_size + (instruction->width == 16 ? 1 : 0) + (rex ? 1 : 0) + 2 + address_size;
            return true;
        }
        if (opcode == ASSEMBLY_OPCODE_X86_CMPXCHG8B || opcode == ASSEMBLY_OPCODE_X86_CMPXCHG16B)
        {
            u8 width = opcode == ASSEMBLY_OPCODE_X86_CMPXCHG8B ? 64 : 128;
            if (first->kind == ASSEMBLY_OPERAND_MEMORY && assembly_x86_memory_set_width(first, width))
            {
                u32 address_size = 0;
                if (assembly_x86_memory_encoding_size(first->memory, &address_size))
                {
                    u8 rex = assembly_x86_memory_rex_needed(opcode == ASSEMBLY_OPCODE_X86_CMPXCHG16B ? 64 : 0,
                                                              (AssemblyRegister){.index = 1}, first->memory);
                    instruction->width = width;
                    instruction->size = lock_size + (rex ? 1 : 0) + 2 + address_size;
                    return true;
                }
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_mask(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_KMOVW && opcode <= ASSEMBLY_OPCODE_X86_KORTESTW;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_amx(AssemblyOpcode opcode)
{
    return opcode >= ASSEMBLY_OPCODE_X86_LDTILECFG && opcode <= ASSEMBLY_OPCODE_X86_TDPBUUD;
}

BUSTER_GLOBAL_LOCAL TargetCpuFeature assembly_x86_amx_feature(AssemblyOpcode opcode)
{
    if (opcode == ASSEMBLY_OPCODE_X86_TDPBF16PS)
    {
        return TARGET_CPU_FEATURE_X86_AMX_BF16;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_TDPBSSD || opcode == ASSEMBLY_OPCODE_X86_TDPBSUD ||
        opcode == ASSEMBLY_OPCODE_X86_TDPBUSD || opcode == ASSEMBLY_OPCODE_X86_TDPBUUD)
    {
        return TARGET_CPU_FEATURE_X86_AMX_INT8;
    }
    return TARGET_CPU_FEATURE_X86_AMX_TILE;
}

BUSTER_GLOBAL_LOCAL String8 assembly_x86_amx_feature_name(AssemblyOpcode opcode)
{
    if (opcode == ASSEMBLY_OPCODE_X86_TDPBF16PS)
    {
        return S8("amx-bf16");
    }
    if (opcode == ASSEMBLY_OPCODE_X86_TDPBSSD || opcode == ASSEMBLY_OPCODE_X86_TDPBSUD ||
        opcode == ASSEMBLY_OPCODE_X86_TDPBUSD || opcode == ASSEMBLY_OPCODE_X86_TDPBUUD)
    {
        return S8("amx-int8");
    }
    return S8("amx-tile");
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_target_has_amx_feature(Target target, AssemblyOpcode opcode)
{
    return target_cpu_feature_has(target, assembly_x86_amx_feature(opcode));
}

BUSTER_GLOBAL_LOCAL TargetCpuFeature assembly_x86_mask_feature(AssemblyOpcode opcode)
{
    TargetCpuFeature result;
    if (opcode == ASSEMBLY_OPCODE_X86_KMOVD || opcode == ASSEMBLY_OPCODE_X86_KMOVQ)
    {
        result = TARGET_CPU_FEATURE_X86_AVX512BW;
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_KADDW)
    {
        result = TARGET_CPU_FEATURE_X86_AVX512DQ;
    }
    else
    {
        result = TARGET_CPU_FEATURE_X86_AVX512F;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_target_has_mask_feature(Target target, AssemblyOpcode opcode)
{
    return target_cpu_feature_has(target, assembly_x86_mask_feature(opcode)) ||
           target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_1) ||
           target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_2);
}

BUSTER_GLOBAL_LOCAL String8 assembly_x86_mask_feature_name(AssemblyOpcode opcode)
{
    String8 result;
    if (opcode == ASSEMBLY_OPCODE_X86_KMOVD || opcode == ASSEMBLY_OPCODE_X86_KMOVQ)
    {
        result = S8("opmask instruction requires avx512bw or avx10");
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_KADDW)
    {
        result = S8("kaddw requires avx512dq or avx10");
    }
    else
    {
        result = S8("opmask instruction requires avx512f or avx10");
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_shift(AssemblyOpcode opcode)
{
    return opcode == ASSEMBLY_OPCODE_X86_SHL || opcode == ASSEMBLY_OPCODE_X86_SHR || opcode == ASSEMBLY_OPCODE_X86_SAR;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_apx_ndd(AssemblyOpcode opcode)
{
    return opcode == ASSEMBLY_OPCODE_X86_ADD || opcode == ASSEMBLY_OPCODE_X86_ADC || opcode == ASSEMBLY_OPCODE_X86_SUB ||
           opcode == ASSEMBLY_OPCODE_X86_SBB || opcode == ASSEMBLY_OPCODE_X86_AND || opcode == ASSEMBLY_OPCODE_X86_OR ||
           opcode == ASSEMBLY_OPCODE_X86_XOR || opcode == ASSEMBLY_OPCODE_X86_IMUL || assembly_x86_opcode_is_shift(opcode);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_opcode_is_apx_nf(AssemblyOpcode opcode)
{
    return opcode == ASSEMBLY_OPCODE_X86_ADD || opcode == ASSEMBLY_OPCODE_X86_SUB || opcode == ASSEMBLY_OPCODE_X86_AND ||
           opcode == ASSEMBLY_OPCODE_X86_OR || opcode == ASSEMBLY_OPCODE_X86_XOR || opcode == ASSEMBLY_OPCODE_X86_IMUL ||
           opcode == ASSEMBLY_OPCODE_X86_INC || opcode == ASSEMBLY_OPCODE_X86_DEC || opcode == ASSEMBLY_OPCODE_X86_NEG ||
           assembly_x86_opcode_is_shift(opcode);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_apx_immediate_encoding(u16 width, s64 value, u8* opcode, u8* size)
{
    if (!assembly_x86_immediate_fits(value, width == 64 ? 32 : width, width == 64))
    {
        return false;
    }
    if (width == 8)
    {
        if (!assembly_x86_immediate_fits(value, 8, false))
        {
            return false;
        }
        *opcode = 0x80;
        *size = 1;
    }
    else if (value >= INT8_MIN && value <= INT8_MAX)
    {
        *opcode = 0x83;
        *size = 1;
    }
    else
    {
        *opcode = 0x81;
        *size = (u8)((width == 64 ? 32 : width) / 8);
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_apx_legacy_immediate_encoding(AssemblyOpcode opcode, u16 width, s64 value, u8* immediate_opcode,
                                                                     u8* immediate_size)
{
    if (opcode == ASSEMBLY_OPCODE_X86_TEST)
    {
        u16 full_width = width == 64 ? 32 : width;
        if (!assembly_x86_immediate_fits(value, full_width, width == 64))
        {
            return false;
        }
        *immediate_opcode = width == 8 ? 0xf6 : 0xf7;
        *immediate_size = (u8)(full_width / 8);
        return true;
    }
    return assembly_x86_apx_immediate_encoding(width, value, immediate_opcode, immediate_size);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_has_extended_gpr(AssemblyInstruction instruction)
{
    for (u32 index = 0; index < instruction.operand_count; index += 1)
    {
        AssemblyOperand operand = instruction.operands[index];
        if ((operand.kind == ASSEMBLY_OPERAND_REGISTER && operand.reg.class == ASSEMBLY_REGISTER_GPR && operand.reg.index >= 16) ||
            (operand.kind == ASSEMBLY_OPERAND_MEMORY &&
             ((operand.memory.has_base && operand.memory.base.index >= 16) ||
              (operand.memory.has_index && operand.memory.index.index >= 16))))
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_operand_has_high_byte(AssemblyOperand operand)
{
    bool result;
    if (operand.kind == ASSEMBLY_OPERAND_REGISTER)
    {
        result = operand.reg.high_byte;
    }
    else if (operand.kind == ASSEMBLY_OPERAND_MEMORY)
    {
        result = (operand.memory.has_base && operand.memory.base.high_byte) || (operand.memory.has_index && operand.memory.index.high_byte);
    }
    else
    {
        result = false;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_has_high_byte(AssemblyInstruction instruction)
{
    for (u32 index = 0; index < instruction.operand_count; index += 1)
    {
        if (assembly_x86_operand_has_high_byte(instruction.operands[index]))
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_operand_has_any_decorator(AssemblyOperand operand)
{
    return operand.has_mask || operand.broadcast || operand.rounding || operand.zeroing || operand.sae;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_has_any_decorator(AssemblyInstruction instruction)
{
    for (u32 index = 0; index < instruction.operand_count; index += 1)
    {
        if (assembly_x86_operand_has_any_decorator(instruction.operands[index]))
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_operands_need_rex(AssemblyInstruction instruction)
{
    if (instruction.width == 64)
    {
        return true;
    }
    for (u32 index = 0; index < instruction.operand_count; index += 1)
    {
        AssemblyOperand operand = instruction.operands[index];
        if (operand.kind == ASSEMBLY_OPERAND_REGISTER && operand.reg.class == ASSEMBLY_REGISTER_GPR &&
            (operand.reg.index >= 8 || operand.reg.width == 64 ||
             (operand.reg.width == 8 && operand.reg.index >= 4 && !operand.reg.high_byte)))
        {
            return true;
        }
        if (operand.kind == ASSEMBLY_OPERAND_MEMORY &&
            ((operand.memory.width == 64) || (operand.memory.has_base && operand.memory.base.index >= 8) ||
             (operand.memory.has_index && operand.memory.index.index >= 8)))
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_evex_memory_displacement_size(AssemblyMemory memory, u32 tuple_scale, u32* result)
{
    if (memory.rip_relative || !memory.has_base)
    {
        return assembly_x86_memory_displacement_size(memory, result);
    }
    if (memory.displacement.has_symbol)
    {
        *result = 4;
        return true;
    }
    if (!memory.displacement.addend && (memory.base.index & 7) != 5)
    {
        *result = 0;
        return true;
    }
    if (tuple_scale && memory.displacement.addend % (s64)tuple_scale == 0)
    {
        s64 scaled = memory.displacement.addend / (s64)tuple_scale;
        if (scaled >= INT8_MIN && scaled <= INT8_MAX)
        {
            *result = 1;
            return true;
        }
    }
    if (memory.displacement.addend >= INT32_MIN && memory.displacement.addend <= INT32_MAX)
    {
        *result = 4;
        return true;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_evex_memory_encoding_size(AssemblyMemory memory, u32 tuple_scale, u32* result)
{
    u32 displacement_size = 0;
    if (!assembly_x86_evex_memory_displacement_size(memory, tuple_scale, &displacement_size))
    {
        return false;
    }
    u8 sib = !memory.rip_relative && (memory.has_index || !memory.has_base || (memory.base.index & 7) == 4);
    *result = 1u + (u32)sib + displacement_size;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_evex_instruction_size(AssemblyInstruction* instruction, AssemblyVectorForm const* form)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOperand* third = instruction->operands + 2;
    u8 move = (form->flags & ASSEMBLY_VECTOR_FORM_MOVE) != 0;
    u8 mask_destination = (form->flags & ASSEMBLY_VECTOR_FORM_MASK_DESTINATION) != 0;
    u8 source_rm = (form->flags & ASSEMBLY_VECTOR_FORM_SOURCE_RM) != 0;
    u8 immediate = (form->flags & ASSEMBLY_VECTOR_FORM_IMMEDIATE) != 0;
    AssemblyRegister vector = {0};
    AssemblyOperand* memory = 0;
    if (mask_destination)
    {
        if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_OPMASK ||
            (first->has_mask && first->mask == 0) || first->zeroing || second->kind != ASSEMBLY_OPERAND_REGISTER ||
            !assembly_x86_vector_register(second->reg) ||
            (third->kind != ASSEMBLY_OPERAND_REGISTER && third->kind != ASSEMBLY_OPERAND_MEMORY))
        {
            return false;
        }
        vector = second->reg;
        memory = third->kind == ASSEMBLY_OPERAND_MEMORY ? third : 0;
        if (third->kind == ASSEMBLY_OPERAND_REGISTER && third->reg.class != vector.class)
        {
            return false;
        }
        if (immediate &&
            (instruction->operands[3].kind != ASSEMBLY_OPERAND_EXPRESSION || instruction->operands[3].expression.has_symbol ||
             instruction->operands[3].expression.addend < 0 || instruction->operands[3].expression.addend > UINT8_MAX))
        {
            return false;
        }
        u64 immediate_limit = instruction->opcode == ASSEMBLY_OPCODE_X86_VCMPPS || instruction->opcode == ASSEMBLY_OPCODE_X86_VCMPPD ? 31 : 7;
        if (immediate && (u64)instruction->operands[3].expression.addend > immediate_limit)
        {
            return false;
        }
    }
    else if (source_rm)
    {
        if (first->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_vector_register(first->reg) ||
            (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
            instruction->operands[2].kind != ASSEMBLY_OPERAND_EXPRESSION || instruction->operands[2].expression.has_symbol ||
            instruction->operands[2].expression.addend < INT8_MIN || instruction->operands[2].expression.addend > UINT8_MAX)
        {
            return false;
        }
        vector = first->reg;
        memory = second->kind == ASSEMBLY_OPERAND_MEMORY ? second : 0;
        if (second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.class != vector.class)
        {
            return false;
        }
    }
    else if (move)
    {
        if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
            (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
            (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY))
        {
            return false;
        }
        vector = first->kind == ASSEMBLY_OPERAND_REGISTER ? first->reg : second->reg;
        memory = first->kind == ASSEMBLY_OPERAND_MEMORY ? first : second->kind == ASSEMBLY_OPERAND_MEMORY ? second : 0;
        if (!assembly_x86_vector_register(vector) ||
            (first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class != vector.class) ||
            (second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.class != vector.class))
        {
            return false;
        }
    }
    else
    {
        if (first->kind != ASSEMBLY_OPERAND_REGISTER || second->kind != ASSEMBLY_OPERAND_REGISTER ||
            (third->kind != ASSEMBLY_OPERAND_REGISTER && third->kind != ASSEMBLY_OPERAND_MEMORY) ||
            !assembly_x86_vector_register(first->reg) || second->reg.class != first->reg.class)
        {
            return false;
        }
        vector = first->reg;
        memory = third->kind == ASSEMBLY_OPERAND_MEMORY ? third : 0;
        if (third->kind == ASSEMBLY_OPERAND_REGISTER && third->reg.class != vector.class)
        {
            return false;
        }
    }
    if ((form->flags & ASSEMBLY_VECTOR_FORM_SCALAR) && vector.class != ASSEMBLY_REGISTER_XMM)
    {
        return false;
    }
    if (vector.width != 128 && vector.width != 256 && vector.width != 512)
    {
        return false;
    }
    if (first->broadcast)
    {
        return false;
    }
    if (!mask_destination && (first->has_mask || first->zeroing))
    {
        if (first->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            if (!move || !first->has_mask || first->mask == 0 || first->zeroing)
            {
                return false;
            }
        }
        else if (first->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_vector_register(first->reg) ||
                 (first->has_mask && first->mask == 0) || (first->zeroing && !first->has_mask))
        {
            return false;
        }
    }
    for (u32 operand_index = 1; operand_index < instruction->operand_count; operand_index += 1)
    {
        AssemblyOperand operand = instruction->operands[operand_index];
        if (operand.has_mask || operand.zeroing || operand.rounding || operand.sae ||
            (operand.broadcast && (!memory || instruction->operands + operand_index != memory)))
        {
            return false;
        }
    }
    if (first->rounding || first->sae)
    {
        u8 supports_rounding = (form->flags & ASSEMBLY_VECTOR_FORM_ROUNDING) != 0;
        u8 supports_sae = (form->flags & ASSEMBLY_VECTOR_FORM_SAE) != 0;
        if ((first->rounding &&
             (!supports_rounding || move || memory || (!(form->flags & ASSEMBLY_VECTOR_FORM_SCALAR) && vector.width != 512))) ||
            (first->sae && !first->rounding && (!supports_sae || move || memory || vector.width != 512)) ||
            (first->sae && first->rounding && !supports_rounding))
        {
            return false;
        }
    }
    if (memory)
    {
        u16 element_width = (u16)form->element_width * 8u;
        u16 expected_width = (form->flags & ASSEMBLY_VECTOR_FORM_SCALAR) ? element_width : vector.width;
        if (memory->broadcast)
        {
            if (!(form->flags & ASSEMBLY_VECTOR_FORM_BROADCAST) || move || (form->flags & ASSEMBLY_VECTOR_FORM_SCALAR) ||
                memory->broadcast != vector.width / element_width)
            {
                return false;
            }
            expected_width = element_width;
        }
        if (memory->memory.width && memory->memory.width != expected_width)
        {
            return false;
        }
        memory->memory.width = expected_width;
        u32 tuple_scale = memory->broadcast ? form->element_width :
                            (form->flags & ASSEMBLY_VECTOR_FORM_SCALAR ? form->element_width : vector.width / 8u);
        u32 address_size = 0;
        if (!assembly_x86_evex_memory_encoding_size(memory->memory, tuple_scale, &address_size))
        {
            return false;
        }
        instruction->rip_relocation_trailing = (u8)immediate;
        instruction->size = 4u + 1u + address_size + immediate;
    }
    else
    {
        if (first->broadcast || second->broadcast || third->broadcast)
        {
            return false;
        }
        instruction->rip_relocation_trailing = 0;
        instruction->size = 4u + 1u + 1u + immediate;
    }
    if (memory && (memory->rounding || memory->sae))
    {
        return false;
    }
    instruction->width = vector.width;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amd_vector_register_valid(AssemblyRegister reg, u8 vector_width_mask)
{
    return !reg.high_byte && reg.index < 16 &&
           ((reg.class == ASSEMBLY_REGISTER_XMM && (vector_width_mask & 1)) ||
            (reg.class == ASSEMBLY_REGISTER_YMM && (vector_width_mask & 2)));
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amd_vector_rm_valid(AssemblyAmdForm const* form, AssemblyOperand* operand,
                                                          AssemblyRegister destination, u16 vector_width)
{
    if (operand->kind == ASSEMBLY_OPERAND_REGISTER)
    {
        return assembly_x86_amd_vector_register_valid(operand->reg, form->vector_width_mask) && operand->reg.class == destination.class &&
               operand->reg.width == vector_width;
    }
    if (operand->kind != ASSEMBLY_OPERAND_MEMORY)
    {
        return false;
    }
    u16 memory_width = (form->flags & ASSEMBLY_AMD_FORM_SCALAR) ? (u16)form->element_bytes * 8u : vector_width;
    return assembly_x86_memory_set_width(operand, memory_width);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amd_immediate_valid(AssemblyOperand operand, u64 maximum)
{
    return operand.kind == ASSEMBLY_OPERAND_EXPRESSION && !operand.expression.has_symbol && operand.expression.addend >= 0 &&
           (u64)operand.expression.addend <= maximum;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amd_gpr_valid(AssemblyOperand operand, u16 width)
{
    return operand.kind == ASSEMBLY_OPERAND_REGISTER && operand.reg.class == ASSEMBLY_REGISTER_GPR && !operand.reg.high_byte &&
           operand.reg.index < 16 && operand.reg.width == width;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amd_instruction_size(AssemblyInstruction* instruction, AssemblyAmdForm const* form)
{
    form = assembly_x86_amd_form_select(instruction);
    instruction->amd_form = form;
    if (!instruction->evex && !instruction->lock_prefix && !instruction->no_flags && instruction->operand_count == form->operand_count)
    {
        AssemblyOperand* first = instruction->operands;
        AssemblyOperand* second = instruction->operands + 1;
        u32 address_size = 1;
        switch (form->encoding)
        {
        case ASSEMBLY_AMD_ENCODING_FEMMS:
            instruction->size = 2;
            return instruction->operand_count == 0;
        case ASSEMBLY_AMD_ENCODING_3DNOW2:
        {
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_MMX || first->reg.index >= 8 ||
                first->reg.width != 64 || (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
                (second->kind == ASSEMBLY_OPERAND_REGISTER &&
                 (second->reg.class != ASSEMBLY_REGISTER_MMX || second->reg.index >= 8 || second->reg.width != 64)))
            {
                return false;
            }
            if (second->kind == ASSEMBLY_OPERAND_MEMORY &&
                (!assembly_x86_memory_set_width(second, 64) || !assembly_x86_memory_encoding_size(second->memory, &address_size)))
            {
                return false;
            }
            instruction->rip_relocation_trailing = second->kind == ASSEMBLY_OPERAND_MEMORY;
            instruction->width = 64;
            instruction->size = (u32)(second->kind == ASSEMBLY_OPERAND_MEMORY && assembly_x86_memory_rex_needed(0, first->reg, second->memory)) +
                                2u + address_size + 1u;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_VECTOR2:
        {
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(first->reg, form->vector_width_mask))
            {
                return false;
            }
            u16 vector_width = first->reg.width;
            if ((form->flags & ASSEMBLY_AMD_FORM_SCALAR) && vector_width != 128)
            {
                return false;
            }
            if (!assembly_x86_amd_vector_rm_valid(form, second, first->reg, vector_width))
            {
                return false;
            }
            if (second->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(second->memory, &address_size))
            {
                return false;
            }
            instruction->rip_relocation_trailing = 0;
            instruction->width = vector_width;
            instruction->size = 3u + 1u + address_size;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_SHIFT:
        {
            AssemblyOperand* source_2 = instruction->operands + 1;
            AssemblyOperand* source_3 = instruction->operands + 2;
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(first->reg, form->vector_width_mask))
            {
                return false;
            }
            u16 vector_width = first->reg.width;
            if (source_3->kind == ASSEMBLY_OPERAND_MEMORY)
            {
                if (!(form->flags & ASSEMBLY_AMD_FORM_ALLOW_W1) || source_2->kind != ASSEMBLY_OPERAND_REGISTER ||
                    !assembly_x86_amd_vector_register_valid(source_2->reg, form->vector_width_mask) || source_2->reg.class != first->reg.class ||
                    source_2->reg.width != vector_width || !assembly_x86_amd_vector_rm_valid(form, source_3, first->reg, vector_width))
                {
                    return false;
                }
            }
            else if (source_3->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(source_3->reg, form->vector_width_mask) ||
                     source_3->reg.class != first->reg.class || source_3->reg.width != vector_width ||
                     !assembly_x86_amd_vector_rm_valid(form, source_2, first->reg, vector_width))
            {
                return false;
            }
            if (source_3->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source_3->memory, &address_size))
            {
                return false;
            }
            if (source_2->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source_2->memory, &address_size))
            {
                return false;
            }
            instruction->rip_relocation_trailing = 0;
            instruction->width = vector_width;
            instruction->size = 3u + 1u + address_size;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_IMMEDIATE:
        {
            AssemblyOperand* immediate = instruction->operands + 2;
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(first->reg, form->vector_width_mask) ||
                !assembly_x86_amd_immediate_valid(*immediate, UINT8_MAX) ||
                !assembly_x86_amd_vector_rm_valid(form, second, first->reg, first->reg.width))
            {
                return false;
            }
            if (second->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(second->memory, &address_size))
            {
                return false;
            }
            instruction->rip_relocation_trailing = second->kind == ASSEMBLY_OPERAND_MEMORY;
            instruction->width = first->reg.width;
            instruction->size = 3u + 1u + address_size + 1u;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_VECTOR3_COMPARE_IMMEDIATE:
        {
            AssemblyOperand* source_1 = instruction->operands + 1;
            AssemblyOperand* source_2 = instruction->operands + 2;
            AssemblyOperand* immediate = instruction->operands + 3;
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(first->reg, form->vector_width_mask) ||
                source_1->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(source_1->reg, form->vector_width_mask) ||
                source_1->reg.class != first->reg.class || source_1->reg.width != first->reg.width ||
                !assembly_x86_amd_immediate_valid(*immediate, UINT8_MAX) ||
                !assembly_x86_amd_vector_rm_valid(form, source_2, first->reg, first->reg.width))
            {
                return false;
            }
            if (source_2->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source_2->memory, &address_size))
            {
                return false;
            }
            instruction->rip_relocation_trailing = source_2->kind == ASSEMBLY_OPERAND_MEMORY;
            instruction->width = first->reg.width;
            instruction->size = 3u + 1u + address_size + 1u;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT:
        case ASSEMBLY_AMD_ENCODING_VEX_VECTOR5_IMMEDIATE:
        case ASSEMBLY_AMD_ENCODING_VEX_FMA4:
        {
            AssemblyOperand* source_1 = instruction->operands + 1;
            AssemblyOperand* source_2 = instruction->operands + 2;
            AssemblyOperand* source_3 = instruction->operands + 3;
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(first->reg, form->vector_width_mask) ||
                source_1->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(source_1->reg, form->vector_width_mask) ||
                source_1->reg.class != first->reg.class || source_1->reg.width != first->reg.width)
            {
                return false;
            }
            u16 vector_width = first->reg.width;
            if ((form->flags & ASSEMBLY_AMD_FORM_SCALAR) && vector_width != 128)
            {
                return false;
            }
            if (form->encoding == ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT)
            {
                if (source_3->kind == ASSEMBLY_OPERAND_MEMORY)
                {
                    if (!(form->flags & ASSEMBLY_AMD_FORM_ALLOW_W1) || source_2->kind != ASSEMBLY_OPERAND_REGISTER ||
                        !assembly_x86_amd_vector_rm_valid(form, source_3, first->reg, vector_width))
                    {
                        return false;
                    }
                }
                else if (source_3->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(source_3->reg, form->vector_width_mask) ||
                         source_3->reg.class != first->reg.class || source_3->reg.width != vector_width ||
                         !assembly_x86_amd_vector_rm_valid(form, source_2, first->reg, vector_width))
                {
                    return false;
                }
            }
            else if (source_2->kind == ASSEMBLY_OPERAND_MEMORY)
            {
                if (!assembly_x86_amd_vector_rm_valid(form, source_2, first->reg, vector_width) || source_3->kind != ASSEMBLY_OPERAND_REGISTER ||
                    !assembly_x86_amd_vector_register_valid(source_3->reg, form->vector_width_mask) || source_3->reg.class != first->reg.class ||
                    source_3->reg.width != vector_width)
                {
                    return false;
                }
            }
            else if (source_2->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(source_2->reg, form->vector_width_mask) ||
                     source_2->reg.class != first->reg.class || source_2->reg.width != vector_width)
            {
                return false;
            }
            else if (source_3->kind == ASSEMBLY_OPERAND_MEMORY)
            {
                if (source_2->kind == ASSEMBLY_OPERAND_MEMORY || !assembly_x86_amd_vector_rm_valid(form, source_3, first->reg, vector_width))
                {
                    return false;
                }
            }
            else if (source_3->kind != ASSEMBLY_OPERAND_REGISTER || !assembly_x86_amd_vector_register_valid(source_3->reg, form->vector_width_mask) ||
                     source_3->reg.class != first->reg.class || source_3->reg.width != vector_width)
            {
                return false;
            }
            if (form->encoding == ASSEMBLY_AMD_ENCODING_VEX_VECTOR5_IMMEDIATE &&
                !assembly_x86_amd_immediate_valid(instruction->operands[4], 15))
            {
                return false;
            }
            if (source_2->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source_2->memory, &address_size))
            {
                return false;
            }
            if (source_3->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source_3->memory, &address_size))
            {
                return false;
            }
            instruction->rip_relocation_trailing = (u8)(source_2->kind == ASSEMBLY_OPERAND_MEMORY || source_3->kind == ASSEMBLY_OPERAND_MEMORY);
            instruction->width = vector_width;
            instruction->size = (form->encoding == ASSEMBLY_AMD_ENCODING_XOP_VECTOR4_SELECT ? 3u : 3u) + 1u + address_size + 1u;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_GPR2:
        {
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte || first->reg.index >= 16 ||
                (first->reg.width != 32 && first->reg.width != 64) ||
                (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY))
            {
                return false;
            }
            u16 width = first->reg.width;
            if (second->kind == ASSEMBLY_OPERAND_REGISTER && !assembly_x86_amd_gpr_valid(*second, width))
            {
                return false;
            }
            if (second->kind == ASSEMBLY_OPERAND_MEMORY &&
                (!assembly_x86_memory_set_width(second, width) || !assembly_x86_memory_encoding_size(second->memory, &address_size)))
            {
                return false;
            }
            instruction->rip_relocation_trailing = 0;
            instruction->width = width;
            instruction->size = 3u + 1u + address_size;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_GPR3_BEXTR:
        {
            AssemblyOperand* immediate = instruction->operands + 2;
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte || first->reg.index >= 16 ||
                (first->reg.width != 32 && first->reg.width != 64) ||
                (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
                !assembly_x86_amd_immediate_valid(*immediate, UINT32_MAX))
            {
                return false;
            }
            u16 width = first->reg.width;
            if (second->kind == ASSEMBLY_OPERAND_REGISTER && !assembly_x86_amd_gpr_valid(*second, width))
            {
                return false;
            }
            if (second->kind == ASSEMBLY_OPERAND_MEMORY &&
                (!assembly_x86_memory_set_width(second, width) || !assembly_x86_memory_encoding_size(second->memory, &address_size)))
            {
                return false;
            }
            instruction->rip_relocation_trailing = second->kind == ASSEMBLY_OPERAND_MEMORY ? 4 : 0;
            instruction->width = width;
            instruction->size = 3u + 1u + address_size + 4u;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_LWP1:
        {
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte || first->reg.index >= 16 ||
                first->reg.width != 64)
            {
                return false;
            }
            instruction->rip_relocation_trailing = 0;
            instruction->width = 64;
            instruction->size = 5;
            return true;
        }
        case ASSEMBLY_AMD_ENCODING_XOP_LWP3:
        {
            AssemblyOperand* immediate = instruction->operands + 2;
            if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte || first->reg.index >= 16 ||
                first->reg.width != 64 || (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
                !assembly_x86_amd_immediate_valid(*immediate, UINT32_MAX))
            {
                return false;
            }
            if (second->kind == ASSEMBLY_OPERAND_REGISTER)
            {
                if (!assembly_x86_amd_gpr_valid(*second, 32))
                {
                    return false;
                }
            }
            else if (!assembly_x86_memory_set_width(second, 32) || !assembly_x86_memory_encoding_size(second->memory, &address_size))
            {
                return false;
            }
            instruction->rip_relocation_trailing = second->kind == ASSEMBLY_OPERAND_MEMORY ? 4 : 0;
            instruction->width = 64;
            instruction->size = 3u + 1u + address_size + 4u;
            return true;
        }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amx_memory_size(AssemblyMemory memory, bool forced_sib, u32* result)
{
    if (forced_sib && memory.rip_relative)
    {
        return false;
    }
    u32 address_size = 0;
    if (!assembly_x86_memory_encoding_size(memory, &address_size))
    {
        return false;
    }
    u8 needs_forced_sib = forced_sib && !memory.has_index && memory.has_base && (memory.base.index & 7) != 4;
    *result = address_size + (u32)needs_forced_sib;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amx_memory_uses_apx_evex(AssemblyMemory memory)
{
    return (memory.has_base && memory.base.index >= 16) || (memory.has_index && memory.index.index >= 16);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_amx_instruction_size(AssemblyInstruction* instruction)
{
    AssemblyOpcode opcode = instruction->opcode;
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    if (opcode == ASSEMBLY_OPCODE_X86_LDTILECFG || opcode == ASSEMBLY_OPCODE_X86_STTILECFG)
    {
        if (instruction->operand_count != 1 || first->kind != ASSEMBLY_OPERAND_MEMORY)
        {
            return false;
        }
        u32 address_size = 0;
        if (!assembly_x86_amx_memory_size(first->memory, false, &address_size))
        {
            return false;
        }
        instruction->size = (assembly_x86_amx_memory_uses_apx_evex(first->memory) ? 4u : 3u) + 1u + address_size;
        return true;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_TILELOADD || opcode == ASSEMBLY_OPCODE_X86_TILELOADDT1)
    {
        if (instruction->operand_count != 2 || first->kind != ASSEMBLY_OPERAND_REGISTER ||
            first->reg.class != ASSEMBLY_REGISTER_TILE || second->kind != ASSEMBLY_OPERAND_MEMORY)
        {
            return false;
        }
        u32 address_size = 0;
        if (!assembly_x86_amx_memory_size(second->memory, true, &address_size))
        {
            return false;
        }
        instruction->size = (assembly_x86_amx_memory_uses_apx_evex(second->memory) ? 4u : 3u) + 1u + address_size;
        return true;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_TILESTORED)
    {
        if (instruction->operand_count != 2 || first->kind != ASSEMBLY_OPERAND_MEMORY ||
            second->kind != ASSEMBLY_OPERAND_REGISTER || second->reg.class != ASSEMBLY_REGISTER_TILE)
        {
            return false;
        }
        u32 address_size = 0;
        if (!assembly_x86_amx_memory_size(first->memory, true, &address_size))
        {
            return false;
        }
        instruction->size = (assembly_x86_amx_memory_uses_apx_evex(first->memory) ? 4u : 3u) + 1u + address_size;
        return true;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_TILEZERO)
    {
        if (instruction->operand_count != 1 || first->kind != ASSEMBLY_OPERAND_REGISTER ||
            first->reg.class != ASSEMBLY_REGISTER_TILE)
        {
            return false;
        }
        instruction->size = 3u + 1u + 1u;
        return true;
    }
    if (instruction->operand_count != 3 || first->kind != ASSEMBLY_OPERAND_REGISTER ||
        second->kind != ASSEMBLY_OPERAND_REGISTER || instruction->operands[2].kind != ASSEMBLY_OPERAND_REGISTER ||
        first->reg.class != ASSEMBLY_REGISTER_TILE || second->reg.class != ASSEMBLY_REGISTER_TILE ||
        instruction->operands[2].reg.class != ASSEMBLY_REGISTER_TILE || first->reg.index == second->reg.index ||
        first->reg.index == instruction->operands[2].reg.index || second->reg.index == instruction->operands[2].reg.index)
    {
        return false;
    }
    instruction->size = 3u + 1u + 1u;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_mask_instruction_size(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOpcode opcode = instruction->opcode;
    if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_OPMASK)
    {
        return false;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_KMOVW || opcode == ASSEMBLY_OPCODE_X86_KMOVD || opcode == ASSEMBLY_OPCODE_X86_KMOVQ ||
        opcode == ASSEMBLY_OPCODE_X86_KNOTW || opcode == ASSEMBLY_OPCODE_X86_KORTESTW)
    {
        if (instruction->operand_count != 2 || second->kind != ASSEMBLY_OPERAND_REGISTER ||
            second->reg.class != ASSEMBLY_REGISTER_OPMASK)
        {
            return false;
        }
        instruction->size = opcode == ASSEMBLY_OPCODE_X86_KMOVW ? 4 : 5;
        return true;
    }
    if (instruction->operand_count != 3 || instruction->operands[2].kind != ASSEMBLY_OPERAND_REGISTER ||
        instruction->operands[2].reg.class != ASSEMBLY_REGISTER_OPMASK)
    {
        return false;
    }
    instruction->size = 4;
    return opcode == ASSEMBLY_OPCODE_X86_KADDW || opcode == ASSEMBLY_OPCODE_X86_KANDW || opcode == ASSEMBLY_OPCODE_X86_KORW ||
           opcode == ASSEMBLY_OPCODE_X86_KXORW;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_apx_legacy_instruction_size(AssemblyInstruction* instruction)
{
    if (!assembly_x86_instruction_has_extended_gpr(*instruction))
    {
        return false;
    }
    AssemblyOperand* first = instruction->operands;
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_PUSH || instruction->opcode == ASSEMBLY_OPCODE_X86_POP)
    {
        if (instruction->operand_count != 1 || first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR ||
            first->reg.width != 64)
        {
            return false;
        }
        instruction->size = 3;
        return true;
    }
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_CALL || instruction->opcode == ASSEMBLY_OPCODE_X86_JMP)
    {
        if (instruction->operand_count != 1)
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_REGISTER)
        {
            if (first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.width != 64 || first->reg.high_byte)
            {
                return false;
            }
            instruction->width = 64;
            instruction->size = 4;
            return true;
        }
        if (first->kind != ASSEMBLY_OPERAND_MEMORY || (first->memory.width && first->memory.width != 64))
        {
            return false;
        }
        first->memory.width = 64;
        u32 address_size = 1;
        if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        instruction->width = 64;
        instruction->size = 3u + address_size;
        return true;
    }
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_LEA)
    {
        if (instruction->operand_count != 2 || first->kind != ASSEMBLY_OPERAND_REGISTER ||
            first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte ||
            (first->reg.width != 16 && first->reg.width != 32 && first->reg.width != 64) ||
            instruction->operands[1].kind != ASSEMBLY_OPERAND_MEMORY)
        {
            return false;
        }
        AssemblyMemory memory = instruction->operands[1].memory;
        u32 address_size = 1;
        if (!assembly_x86_memory_encoding_size(memory, &address_size))
        {
            return false;
        }
        instruction->width = first->reg.width;
        instruction->size = (u32)(instruction->width == 16) + 3u + address_size;
        return true;
    }
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_INC || instruction->opcode == ASSEMBLY_OPCODE_X86_DEC ||
        instruction->opcode == ASSEMBLY_OPCODE_X86_NEG || instruction->opcode == ASSEMBLY_OPCODE_X86_NOT)
    {
        if (instruction->operand_count != 1 ||
            (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
            !assembly_x86_lock_prefix_legal(instruction))
        {
            return false;
        }
        u16 width = assembly_operand_width(*first);
        if (width != 8 && width != 16 && width != 32 && width != 64)
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_REGISTER &&
            (first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte))
        {
            return false;
        }
        u32 address_size = 1;
        if (first->kind == ASSEMBLY_OPERAND_MEMORY &&
            (!assembly_x86_memory_set_width(first, width) || !assembly_x86_memory_encoding_size(first->memory, &address_size)))
        {
            return false;
        }
        instruction->width = width;
        instruction->rip_relocation_trailing = 0;
        instruction->size = (instruction->lock_prefix ? 1u : 0u) + (u32)(width == 16) + 3u + address_size;
        return true;
    }
    if (assembly_x86_opcode_is_sse2(instruction->opcode))
    {
        u8 move = instruction->opcode >= ASSEMBLY_OPCODE_X86_MOVAPS && instruction->opcode <= ASSEMBLY_OPCODE_X86_MOVDQU;
        AssemblyOperand* second = instruction->operands + 1;
        if (instruction->operand_count != 2 ||
            (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
            (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
            (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY) ||
            (!move && first->kind != ASSEMBLY_OPERAND_REGISTER) ||
            (first->kind == ASSEMBLY_OPERAND_REGISTER &&
             (first->reg.class != ASSEMBLY_REGISTER_XMM || first->reg.index >= 16)) ||
            (second->kind == ASSEMBLY_OPERAND_REGISTER &&
             (second->reg.class != ASSEMBLY_REGISTER_XMM || second->reg.index >= 16)))
        {
            return false;
        }
        u16 memory_width = instruction->opcode == ASSEMBLY_OPCODE_X86_ADDSS ? 32
                         : instruction->opcode == ASSEMBLY_OPCODE_X86_ADDSD ? 64
                                                                            : 128;
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(first, memory_width))
        {
            return false;
        }
        if (second->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(second, memory_width))
        {
            return false;
        }
        AssemblyOperand* rm = !move || first->kind == ASSEMBLY_OPERAND_REGISTER ? second : first;
        u32 address_size = 1;
        if (rm->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(rm->memory, &address_size))
        {
            return false;
        }
        instruction->width = 128;
        u8 mandatory_prefix = instruction->opcode == ASSEMBLY_OPCODE_X86_MOVAPD || instruction->opcode == ASSEMBLY_OPCODE_X86_MOVUPD ||
                                       instruction->opcode == ASSEMBLY_OPCODE_X86_MOVDQA || instruction->opcode == ASSEMBLY_OPCODE_X86_XORPD ||
                                       instruction->opcode == ASSEMBLY_OPCODE_X86_PXOR || instruction->opcode == ASSEMBLY_OPCODE_X86_ADDPD ||
                                       instruction->opcode == ASSEMBLY_OPCODE_X86_SUBPD || instruction->opcode == ASSEMBLY_OPCODE_X86_MULPD ||
                                       instruction->opcode == ASSEMBLY_OPCODE_X86_DIVPD
                                   ? 1
                                   : instruction->opcode == ASSEMBLY_OPCODE_X86_MOVDQU || instruction->opcode == ASSEMBLY_OPCODE_X86_ADDSS
                                       ? 1
                                       : instruction->opcode == ASSEMBLY_OPCODE_X86_ADDSD ? 1 : 0;
        instruction->size = (u32)mandatory_prefix + 2u + 1u + address_size;
        return true;
    }
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_IMUL)
    {
        if (instruction->operand_count != 1 && instruction->operand_count != 2 && instruction->operand_count != 3)
        {
            return false;
        }
        if (instruction->operand_count == 1 && first->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            instruction->width = first->memory.width;
            if (instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64)
            {
                return false;
            }
            u32 address_size = 1;
            if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
            {
                return false;
            }
            instruction->size = (u32)(instruction->width == 16) + 3u + address_size;
            return true;
        }
        if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte ||
            (first->reg.width != 8 && first->reg.width != 16 && first->reg.width != 32 && first->reg.width != 64))
        {
            return false;
        }
        instruction->width = first->reg.width;
        if (instruction->width == 8 && instruction->operand_count != 1)
        {
            return false;
        }
        if (instruction->operand_count == 1)
        {
            instruction->size = (u32)(instruction->width == 16) + 4u;
            return true;
        }
        AssemblyOperand* source = instruction->operands + 1;
        if (source->kind != ASSEMBLY_OPERAND_REGISTER && source->kind != ASSEMBLY_OPERAND_MEMORY)
        {
            return false;
        }
        if (source->kind == ASSEMBLY_OPERAND_REGISTER &&
            (source->reg.class != ASSEMBLY_REGISTER_GPR || source->reg.width != instruction->width || source->reg.high_byte))
        {
            return false;
        }
        if (source->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(source, instruction->width))
        {
            return false;
        }
        u32 address_size = 1;
        if (source->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source->memory, &address_size))
        {
            return false;
        }
        if (instruction->operand_count == 2)
        {
            instruction->rip_relocation_trailing = 0;
            instruction->size = (u32)(instruction->width == 16) + 3u + address_size;
            return true;
        }
        AssemblyOperand* immediate = instruction->operands + 2;
        u16 full_width = instruction->width == 64 ? 32 : instruction->width;
        if (immediate->kind != ASSEMBLY_OPERAND_EXPRESSION || immediate->expression.has_symbol ||
            !assembly_x86_immediate_fits(immediate->expression.addend, full_width, true))
        {
            return false;
        }
        u8 immediate_size = immediate->expression.addend >= INT8_MIN && immediate->expression.addend <= INT8_MAX
                                ? 1
                                : (u8)(full_width / 8);
        instruction->rip_relocation_trailing = source->kind == ASSEMBLY_OPERAND_MEMORY ? immediate_size : 0;
        instruction->size = (u32)(instruction->width == 16) + 3u + address_size + immediate_size;
        return true;
    }
    if (assembly_x86_opcode_is_shift(instruction->opcode))
    {
        if (instruction->operand_count != 2 ||
            (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY))
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_REGISTER &&
            (first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte))
        {
            return false;
        }
        instruction->width = assembly_operand_width(*first);
        if (instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64)
        {
            return false;
        }
        u8 immediate = instruction->operands[1].kind == ASSEMBLY_OPERAND_EXPRESSION;
        if (!immediate && !assembly_x86_count_is_cl(instruction->operands[1]))
        {
            return false;
        }
        if (immediate && (instruction->operands[1].expression.has_symbol || instruction->operands[1].expression.addend < 0 ||
                          instruction->operands[1].expression.addend > UINT8_MAX))
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(first, instruction->width))
        {
            return false;
        }
        u32 address_size = 1;
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        instruction->rip_relocation_trailing = 0;
        instruction->size = (u32)(instruction->width == 16) + 3u + address_size +
                            (u32)(immediate && instruction->operands[1].expression.addend != 1);
        return true;
    }
    if (instruction->opcode != ASSEMBLY_OPCODE_X86_MOV && instruction->opcode != ASSEMBLY_OPCODE_X86_ADD &&
        instruction->opcode != ASSEMBLY_OPCODE_X86_ADC && instruction->opcode != ASSEMBLY_OPCODE_X86_SUB &&
        instruction->opcode != ASSEMBLY_OPCODE_X86_SBB && instruction->opcode != ASSEMBLY_OPCODE_X86_AND &&
        instruction->opcode != ASSEMBLY_OPCODE_X86_OR && instruction->opcode != ASSEMBLY_OPCODE_X86_XOR &&
        instruction->opcode != ASSEMBLY_OPCODE_X86_CMP && instruction->opcode != ASSEMBLY_OPCODE_X86_TEST)
    {
        return false;
    }
    AssemblyOperand* second = instruction->operands + 1;
    if (instruction->operand_count == 2 && second->kind == ASSEMBLY_OPERAND_EXPRESSION)
    {
        if (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY)
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_REGISTER)
        {
            if (first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte)
            {
                return false;
            }
            instruction->width = first->reg.width;
        }
        else
        {
            instruction->width = first->memory.width;
        }
        if (instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64)
        {
            return false;
        }
        u8 immediate_opcode = 0;
        u8 immediate_size = 0;
        if (second->expression.has_symbol)
        {
            return false;
        }
        if (instruction->opcode == ASSEMBLY_OPCODE_X86_MOV)
        {
            u8 register_immediate_64 = (u8)(first->kind == ASSEMBLY_OPERAND_REGISTER && instruction->width == 64 &&
                                            !assembly_x86_immediate_fits(second->expression.addend, 32, true));
            u16 immediate_width = register_immediate_64 ? 64 : instruction->width == 64 ? 32 : instruction->width;
            if (!assembly_x86_immediate_fits(second->expression.addend, immediate_width,
                                             instruction->width == 64))
            {
                return false;
            }
            immediate_opcode = first->kind == ASSEMBLY_OPERAND_MEMORY ? (instruction->width == 8 ? 0xc6 : 0xc7)
                                                                       : instruction->width == 8 ? 0xb0
                                                                                                  : register_immediate_64 ? 0xb8
                                                                                                                          : instruction->width == 64 ? 0xc7 : 0xb8;
            immediate_size = (u8)(immediate_width / 8);
            if (first->kind == ASSEMBLY_OPERAND_REGISTER && instruction->width == 64 && register_immediate_64)
            {
                immediate_opcode = 0xb8;
            }
        }
        else if (!assembly_x86_apx_legacy_immediate_encoding(instruction->opcode, instruction->width,
                                                             second->expression.addend, &immediate_opcode, &immediate_size))
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(first, instruction->width))
        {
            return false;
        }
        u8 has_modrm = (u8)(instruction->opcode == ASSEMBLY_OPCODE_X86_MOV && first->kind == ASSEMBLY_OPERAND_REGISTER &&
                            instruction->width == 64 && immediate_size == 4);
        u32 address_size = first->kind == ASSEMBLY_OPERAND_MEMORY
                               ? 1
                               : instruction->opcode == ASSEMBLY_OPCODE_X86_MOV ? 0 : 1;
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        instruction->rip_relocation_trailing = first->kind == ASSEMBLY_OPERAND_MEMORY ? immediate_size : 0;
        instruction->size = (instruction->lock_prefix ? 1u : 0u) + (u32)(instruction->width == 16) + 2u + 1u + has_modrm +
                            address_size + immediate_size;
        return true;
    }
    if (instruction->operand_count != 2 ||
        (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY) ||
        (first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class != ASSEMBLY_REGISTER_GPR) ||
        (second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.class != ASSEMBLY_REGISTER_GPR))
    {
        return false;
    }
    instruction->width = first->kind == ASSEMBLY_OPERAND_REGISTER ? first->reg.width : second->reg.width;
    if (instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64)
    {
        return false;
    }
    if ((first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.width != instruction->width) ||
        (second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.width != instruction->width))
    {
        return false;
    }
    if (first->kind == ASSEMBLY_OPERAND_MEMORY)
    {
        if (first->memory.width && first->memory.width != instruction->width)
        {
            return false;
        }
        first->memory.width = instruction->width;
    }
    if (second->kind == ASSEMBLY_OPERAND_MEMORY)
    {
        if (second->memory.width && second->memory.width != instruction->width)
        {
            return false;
        }
        second->memory.width = instruction->width;
    }
    u32 address_size = 1;
    AssemblyOperand* memory = first->kind == ASSEMBLY_OPERAND_MEMORY ? first : second->kind == ASSEMBLY_OPERAND_MEMORY ? second : 0;
    if (memory && !assembly_x86_memory_encoding_size(memory->memory, &address_size))
    {
        return false;
    }
    u32 lock_size = instruction->lock_prefix ? 1 : 0;
    instruction->size = lock_size + 2u + (instruction->width == 16) + 1u + address_size;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_apx_imul_evex_instruction_size(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    if ((instruction->operand_count != 2 && instruction->operand_count != 3) || first->kind != ASSEMBLY_OPERAND_REGISTER ||
        first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte ||
        (first->reg.width != 16 && first->reg.width != 32 && first->reg.width != 64))
    {
        return false;
    }
    instruction->width = first->reg.width;
    AssemblyOperand* source = instruction->operands + 1;
    if (source->kind != ASSEMBLY_OPERAND_REGISTER && source->kind != ASSEMBLY_OPERAND_MEMORY)
    {
        return false;
    }
    if (source->kind == ASSEMBLY_OPERAND_REGISTER &&
        (source->reg.class != ASSEMBLY_REGISTER_GPR || source->reg.width != instruction->width || source->reg.high_byte))
    {
        return false;
    }
    if (source->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(source, instruction->width))
    {
        return false;
    }
    if (instruction->operand_count == 2)
    {
        if (!instruction->no_flags)
        {
            return false;
        }
        u32 address_size = 1;
        if (source->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source->memory, &address_size))
        {
            return false;
        }
        instruction->rip_relocation_trailing = 0;
        instruction->size = 5u + address_size;
        return true;
    }
    AssemblyOperand* third = instruction->operands + 2;
    if (third->kind == ASSEMBLY_OPERAND_EXPRESSION)
    {
        u16 full_width = instruction->width == 64 ? 32 : instruction->width;
        if (third->expression.has_symbol || !assembly_x86_immediate_fits(third->expression.addend, full_width, true))
        {
            return false;
        }
        u8 immediate_size = third->expression.addend >= INT8_MIN && third->expression.addend <= INT8_MAX
                                ? 1
                                : (u8)(full_width / 8);
        u32 address_size = 1;
        if (source->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source->memory, &address_size))
        {
            return false;
        }
        instruction->rip_relocation_trailing = source->kind == ASSEMBLY_OPERAND_MEMORY ? immediate_size : 0;
        instruction->size = 5u + address_size + immediate_size;
        return true;
    }
    if (source->kind != ASSEMBLY_OPERAND_REGISTER)
    {
        return false;
    }
    if (third->kind != ASSEMBLY_OPERAND_REGISTER && third->kind != ASSEMBLY_OPERAND_MEMORY)
    {
        return false;
    }
    if (third->kind == ASSEMBLY_OPERAND_REGISTER &&
        (third->reg.class != ASSEMBLY_REGISTER_GPR || third->reg.width != instruction->width || third->reg.high_byte))
    {
        return false;
    }
    u32 address_size = 1;
    if (third->kind == ASSEMBLY_OPERAND_MEMORY)
    {
        if (!assembly_x86_memory_set_width(third, instruction->width) ||
            !assembly_x86_memory_encoding_size(third->memory, &address_size))
        {
            return false;
        }
    }
    instruction->rip_relocation_trailing = 0;
    instruction->size = 5u + address_size;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_apx_shift_evex_instruction_size(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    if ((instruction->operand_count != 2 && instruction->operand_count != 3) ||
        (instruction->operand_count == 2 && !instruction->no_flags))
    {
        return false;
    }
    if (instruction->operand_count == 2)
    {
        if (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY)
        {
            return false;
        }
    }
    else if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte)
    {
        return false;
    }
    u16 width = assembly_operand_width(*first);
    if (width != 8 && width != 16 && width != 32 && width != 64)
    {
        return false;
    }
    if (first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class != ASSEMBLY_REGISTER_GPR)
    {
        return false;
    }
    instruction->width = width;
    AssemblyOperand* source = instruction->operand_count == 2 ? first : instruction->operands + 1;
    if (instruction->operand_count == 3 && source->kind != ASSEMBLY_OPERAND_REGISTER && source->kind != ASSEMBLY_OPERAND_MEMORY)
    {
        return false;
    }
    if (source->kind == ASSEMBLY_OPERAND_REGISTER &&
        (source->reg.class != ASSEMBLY_REGISTER_GPR || source->reg.width != width || source->reg.high_byte))
    {
        return false;
    }
    if (source->kind == ASSEMBLY_OPERAND_MEMORY &&
        !assembly_x86_memory_set_width(source, width))
    {
        return false;
    }
    AssemblyOperand* count = instruction->operands + (instruction->operand_count == 2 ? 1 : 2);
    u8 immediate = count->kind == ASSEMBLY_OPERAND_EXPRESSION;
    if (!immediate && !assembly_x86_count_is_cl(*count))
    {
        return false;
    }
    if (immediate && (count->expression.has_symbol || count->expression.addend < 0 || count->expression.addend > UINT8_MAX))
    {
        return false;
    }
    u32 address_size = 1;
    if (source->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(source->memory, &address_size))
    {
        return false;
    }
    u8 trailing = (u8)(immediate && count->expression.addend != 1);
    instruction->rip_relocation_trailing = (u8)(source->kind == ASSEMBLY_OPERAND_MEMORY && trailing);
    instruction->size = 5u + address_size + trailing;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_apx_ndd_instruction_size(AssemblyInstruction* instruction)
{
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_IMUL)
    {
        return assembly_x86_apx_imul_evex_instruction_size(instruction);
    }
    if (assembly_x86_opcode_is_shift(instruction->opcode))
    {
        return assembly_x86_apx_shift_evex_instruction_size(instruction);
    }
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_APX_PUSH2 || instruction->opcode == ASSEMBLY_OPCODE_X86_APX_POP2)
    {
        if (instruction->operand_count != 2 || instruction->operands[0].kind != ASSEMBLY_OPERAND_REGISTER ||
            instruction->operands[1].kind != ASSEMBLY_OPERAND_REGISTER || instruction->operands[0].reg.class != ASSEMBLY_REGISTER_GPR ||
            instruction->operands[1].reg.class != ASSEMBLY_REGISTER_GPR || instruction->operands[0].reg.width != 64 ||
            instruction->operands[1].reg.width != 64 || instruction->operands[0].reg.index == 4 || instruction->operands[1].reg.index == 4)
        {
            return false;
        }
        if (instruction->opcode == ASSEMBLY_OPCODE_X86_APX_POP2 &&
            instruction->operands[0].reg.index == instruction->operands[1].reg.index)
        {
            return false;
        }
        instruction->size = 6;
        return true;
    }
    if (!assembly_x86_opcode_is_apx_ndd(instruction->opcode) || instruction->operand_count != 3)
    {
        return false;
    }
    AssemblyOperand* destination = instruction->operands;
    AssemblyOperand* source_1 = instruction->operands + 1;
    AssemblyOperand* source_2 = instruction->operands + 2;
    if (destination->kind != ASSEMBLY_OPERAND_REGISTER || destination->reg.class != ASSEMBLY_REGISTER_GPR ||
        source_1->kind == ASSEMBLY_OPERAND_EXPRESSION ||
        (source_1->kind != ASSEMBLY_OPERAND_REGISTER && source_1->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (source_2->kind != ASSEMBLY_OPERAND_REGISTER && source_2->kind != ASSEMBLY_OPERAND_MEMORY &&
         source_2->kind != ASSEMBLY_OPERAND_EXPRESSION) || destination->reg.high_byte)
    {
        return false;
    }
    if (source_1->kind == ASSEMBLY_OPERAND_MEMORY && source_2->kind == ASSEMBLY_OPERAND_MEMORY)
    {
        return false;
    }
    u16 width = destination->reg.width;
    if (width != 8 && width != 16 && width != 32 && width != 64)
    {
        return false;
    }
    if (source_1->kind == ASSEMBLY_OPERAND_REGISTER &&
        (source_1->reg.class != ASSEMBLY_REGISTER_GPR || source_1->reg.width != width || source_1->reg.high_byte))
    {
        return false;
    }
    if (source_2->kind == ASSEMBLY_OPERAND_REGISTER &&
        (source_2->reg.class != ASSEMBLY_REGISTER_GPR || source_2->reg.width != width || source_2->reg.high_byte))
    {
        return false;
    }
    if (source_1->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(source_1, width))
    {
        return false;
    }
    if (source_2->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(source_2, width))
    {
        return false;
    }
    instruction->width = width;
    instruction->rip_relocation_trailing = 0;
    if (source_2->kind == ASSEMBLY_OPERAND_EXPRESSION)
    {
        u8 immediate_opcode = 0;
        u8 immediate_size = 0;
        if (source_2->expression.has_symbol ||
            !assembly_x86_apx_immediate_encoding(width, source_2->expression.addend, &immediate_opcode, &immediate_size))
        {
            return false;
        }
        if (source_1->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            u32 address_size = 1;
            if (!assembly_x86_memory_encoding_size(source_1->memory, &address_size))
            {
                return false;
            }
            instruction->rip_relocation_trailing = immediate_size;
            instruction->size = 5u + address_size + immediate_size;
        }
        else
        {
            instruction->rip_relocation_trailing = 0;
            instruction->size = 6u + immediate_size;
        }
        return true;
    }
    AssemblyOperand* memory = source_1->kind == ASSEMBLY_OPERAND_MEMORY ? source_1
                              : source_2->kind == ASSEMBLY_OPERAND_MEMORY ? source_2
                                                                          : 0;
    u32 address_size = 1;
    if (memory && !assembly_x86_memory_encoding_size(memory->memory, &address_size))
    {
        return false;
    }
    instruction->size = 5u + address_size;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_apx_nf_instruction_size(AssemblyInstruction* instruction)
{
    if (instruction->lock_prefix || !assembly_x86_opcode_is_apx_nf(instruction->opcode))
    {
        return false;
    }
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_IMUL)
    {
        return assembly_x86_apx_imul_evex_instruction_size(instruction);
    }
    if (assembly_x86_opcode_is_shift(instruction->opcode))
    {
        return assembly_x86_apx_shift_evex_instruction_size(instruction);
    }
    if (instruction->opcode == ASSEMBLY_OPCODE_X86_INC || instruction->opcode == ASSEMBLY_OPCODE_X86_DEC ||
        instruction->opcode == ASSEMBLY_OPCODE_X86_NEG)
    {
        if (instruction->operand_count != 1 ||
            (instruction->operands[0].kind != ASSEMBLY_OPERAND_REGISTER && instruction->operands[0].kind != ASSEMBLY_OPERAND_MEMORY))
        {
            return false;
        }
        AssemblyOperand* operand = instruction->operands;
        u16 width = assembly_operand_width(*operand);
        if (width != 8 && width != 16 && width != 32 && width != 64)
        {
            return false;
        }
        if (operand->kind == ASSEMBLY_OPERAND_REGISTER &&
            (operand->reg.class != ASSEMBLY_REGISTER_GPR || operand->reg.high_byte))
        {
            return false;
        }
        u32 address_size = 1;
        if (operand->kind == ASSEMBLY_OPERAND_MEMORY &&
            (!assembly_x86_memory_set_width(operand, width) || !assembly_x86_memory_encoding_size(operand->memory, &address_size)))
        {
            return false;
        }
        instruction->width = width;
        instruction->rip_relocation_trailing = 0;
        instruction->size = 5u + address_size;
        return true;
    }
    if (instruction->operand_count != 2)
    {
        return false;
    }
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY &&
         second->kind != ASSEMBLY_OPERAND_EXPRESSION) ||
        (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY))
    {
        return false;
    }
    if (second->kind == ASSEMBLY_OPERAND_EXPRESSION)
    {
        u16 width = assembly_operand_width(*first);
        if (first->kind == ASSEMBLY_OPERAND_REGISTER &&
            (first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte))
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !width)
        {
            return false;
        }
        if (width != 8 && width != 16 && width != 32 && width != 64)
        {
            return false;
        }
        u8 immediate_opcode = 0;
        u8 immediate_size = 0;
        if (second->expression.has_symbol ||
            !assembly_x86_apx_immediate_encoding(width, second->expression.addend, &immediate_opcode, &immediate_size))
        {
            return false;
        }
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_set_width(first, width))
        {
            return false;
        }
        u32 address_size = 1;
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        instruction->width = width;
        instruction->rip_relocation_trailing = immediate_size;
        instruction->size = 5u + address_size + immediate_size;
        return true;
    }
    u16 width = first->kind == ASSEMBLY_OPERAND_REGISTER ? first->reg.width
                : second->kind == ASSEMBLY_OPERAND_REGISTER ? second->reg.width
                                                             : first->memory.width;
    if (width != 8 && width != 16 && width != 32 && width != 64)
    {
        return false;
    }
    if (first->kind == ASSEMBLY_OPERAND_REGISTER && (first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.high_byte))
    {
        return false;
    }
    if (second->kind == ASSEMBLY_OPERAND_REGISTER &&
        (second->reg.class != ASSEMBLY_REGISTER_GPR || second->reg.width != width || second->reg.high_byte))
    {
        return false;
    }
    if (first->kind == ASSEMBLY_OPERAND_MEMORY)
    {
        if (first->memory.width && first->memory.width != width)
        {
            return false;
        }
        first->memory.width = width;
    }
    if (second->kind == ASSEMBLY_OPERAND_MEMORY)
    {
        if (second->memory.width && second->memory.width != width)
        {
            return false;
        }
        second->memory.width = width;
    }
    u32 address_size = 1;
    AssemblyOperand* memory = first->kind == ASSEMBLY_OPERAND_MEMORY ? first : second->kind == ASSEMBLY_OPERAND_MEMORY ? second : 0;
    if (memory && !assembly_x86_memory_encoding_size(memory->memory, &address_size))
    {
        return false;
    }
    instruction->width = width;
    instruction->size = (instruction->lock_prefix ? 1u : 0u) + 4u + 1u + address_size;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_lea(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    bool sized;
    if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR ||
        (first->reg.width != 16 && first->reg.width != 32 && first->reg.width != 64) || second->kind != ASSEMBLY_OPERAND_MEMORY)
    {
        sized = false;
    }
    else
    {
        u32 address_size = 0;
        if (!assembly_x86_memory_encoding_size(second->memory, &address_size))
        {
            sized = false;
        }
        else
        {
            instruction->width = first->reg.width;
            u8 rex = assembly_x86_memory_rex_needed(instruction->width, first->reg, second->memory);
            instruction->size = (u32)(instruction->width == 16) + (u32)rex + 1u + address_size;
            sized = true;
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_move_extend(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOpcode opcode = instruction->opcode;
    bool sized = first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class == ASSEMBLY_REGISTER_GPR &&
                 (first->reg.width == 16 || first->reg.width == 32 || first->reg.width == 64) &&
                 (second->kind == ASSEMBLY_OPERAND_REGISTER || second->kind == ASSEMBLY_OPERAND_MEMORY);
    u16 source_width = 0;
    if (sized)
    {
        source_width = second->kind == ASSEMBLY_OPERAND_REGISTER ? second->reg.width : second->memory.width;
        if (opcode == ASSEMBLY_OPCODE_X86_MOVSXD)
        {
            // MOVSXD is the one form whose source width the opcode fixes rather
            // than the operand reporting it.
            if (first->reg.width != 64)
            {
                sized = false;
            }
            else if (second->kind == ASSEMBLY_OPERAND_REGISTER)
            {
                sized = second->reg.class == ASSEMBLY_REGISTER_GPR && second->reg.width == 32;
            }
            else if (second->memory.width && second->memory.width != 32)
            {
                sized = false;
            }
            else
            {
                second->memory.width = 32;
            }
            source_width = 32;
        }
        else
        {
            sized = (source_width == 8 || source_width == 16) && !(source_width == 16 && first->reg.width == 16) &&
                    first->reg.width > source_width;
        }
    }
    if (sized)
    {
        if (second->kind == ASSEMBLY_OPERAND_REGISTER)
        {
            sized = second->reg.class == ASSEMBLY_REGISTER_GPR && second->reg.width == source_width;
        }
        else
        {
            if (!second->memory.width)
            {
                second->memory.width = source_width;
            }
            sized = second->memory.width == source_width;
        }
    }
    if (sized)
    {
        u8 rex = second->kind == ASSEMBLY_OPERAND_REGISTER
                       ? assembly_x86_extension_rex_needed(first->reg.width, first->reg, second->reg, source_width)
                       : assembly_x86_memory_rex_needed(first->reg.width, first->reg, second->memory);
        u32 address_size = 1;
        if ((second->kind == ASSEMBLY_OPERAND_REGISTER && rex && (first->reg.high_byte || second->reg.high_byte)) ||
            (second->kind == ASSEMBLY_OPERAND_MEMORY && assembly_x86_memory_rex_conflicts_high_byte(first->reg.width, first->reg, second->memory)))
        {
            sized = false;
        }
        else if (second->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(second->memory, &address_size))
        {
            sized = false;
        }
        else
        {
            instruction->width = first->reg.width;
            instruction->size = (u32)(instruction->width == 16) + (u32)rex + (opcode == ASSEMBLY_OPCODE_X86_MOVSXD ? 1u : 2u) + address_size;
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_rotate(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    bool sized;
    if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (first->kind == ASSEMBLY_OPERAND_REGISTER &&
         (first->reg.class != ASSEMBLY_REGISTER_GPR ||
          (first->reg.width != 8 && first->reg.width != 16 && first->reg.width != 32 && first->reg.width != 64))) ||
        (first->kind == ASSEMBLY_OPERAND_MEMORY &&
         (first->memory.width != 8 && first->memory.width != 16 && first->memory.width != 32 && first->memory.width != 64)) ||
        (!assembly_x86_count_is_cl(*second) && !assembly_x86_count_immediate_valid(*second)))
    {
        sized = false;
    }
    else
    {
        instruction->width = assembly_operand_width(*first);
        u32 address_size = 1;
        u8 rex = false;
        if (first->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
            {
                return false;
            }
            rex = assembly_x86_memory_rex_needed(instruction->width, (AssemblyRegister){0}, first->memory);
        }
        else
        {
            rex = assembly_x86_rex_needed(instruction->width, first->reg, (AssemblyRegister){0});
        }
        instruction->size = (u32)(instruction->width == 16) + (u32)rex + 1u + address_size +
                            (u32)(second->kind == ASSEMBLY_OPERAND_EXPRESSION && second->expression.addend != 1);
        instruction->rip_relocation_trailing = second->kind == ASSEMBLY_OPERAND_EXPRESSION && second->expression.addend != 1;
        sized = true;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_double_shift(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    bool sized;
    if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class != ASSEMBLY_REGISTER_GPR) ||
        (second->kind != ASSEMBLY_OPERAND_REGISTER || second->reg.class != ASSEMBLY_REGISTER_GPR) ||
        (!assembly_x86_count_is_cl(instruction->operands[2]) && !assembly_x86_count_immediate_valid(instruction->operands[2])))
    {
        sized = false;
    }
    else
    {
        instruction->width = assembly_operand_width(*first);
        if (!instruction->width)
        {
            instruction->width = second->reg.width;
        }
        if (instruction->width != 16 && instruction->width != 32 && instruction->width != 64)
        {
            sized = false;
        }
        else
        {
            if (first->kind == ASSEMBLY_OPERAND_MEMORY)
            {
                if (!assembly_x86_memory_set_width(first, instruction->width))
                {
                    return false;
                }
            }
            if (second->reg.width != instruction->width)
            {
                sized = false;
            }
            else
            {
                u32 address_size = 1;
                u8 rex = false;
                if (first->kind == ASSEMBLY_OPERAND_MEMORY)
                {
                    if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
                    {
                        return false;
                    }
                    rex = assembly_x86_memory_rex_needed(instruction->width, second->reg, first->memory);
                }
                else
                {
                    rex = assembly_x86_rex_needed(instruction->width, second->reg, first->reg);
                }
                instruction->size = (u32)(instruction->width == 16) + (u32)rex + 2u + address_size +
                                    (u32)(instruction->operands[2].kind == ASSEMBLY_OPERAND_EXPRESSION);
                instruction->rip_relocation_trailing = instruction->operands[2].kind == ASSEMBLY_OPERAND_EXPRESSION;
                sized = true;
            }
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_x87_data(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOpcode opcode = instruction->opcode;
    bool sized;
    if (first->kind == ASSEMBLY_OPERAND_REGISTER)
    {
        if ((opcode != ASSEMBLY_OPCODE_X86_FLD && opcode != ASSEMBLY_OPCODE_X86_FST && opcode != ASSEMBLY_OPCODE_X86_FSTP) ||
            first->reg.class != ASSEMBLY_REGISTER_X87)
        {
            return false;
        }
        instruction->width = 80;
        instruction->size = 2;
        sized = true;
    }
    else if (first->kind != ASSEMBLY_OPERAND_MEMORY)
    {
        sized = false;
    }
    else
    {
        u16 width = first->memory.width;
        u8 valid_width = opcode == ASSEMBLY_OPCODE_X86_FLD ? width == 32 || width == 64 || width == 80
                           : opcode == ASSEMBLY_OPCODE_X86_FST ? width == 32 || width == 64
                           : opcode == ASSEMBLY_OPCODE_X86_FSTP ? width == 32 || width == 64 || width == 80
                           : opcode == ASSEMBLY_OPCODE_X86_FILD ? width == 16 || width == 32 || width == 64
                           : opcode == ASSEMBLY_OPCODE_X86_FIST ? width == 16 || width == 32
                                                               : width == 16 || width == 32 || width == 64;
        u32 address_size = 0;
        if (!valid_width || !assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            sized = false;
        }
        else
        {
            instruction->width = width;
            instruction->size = (u32)assembly_x86_memory_rex_needed(0, (AssemblyRegister){0}, first->memory) + 1u + address_size;
            sized = true;
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_x87_arithmetic(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    bool sized;
    if (instruction->operand_count == 1 && first->kind == ASSEMBLY_OPERAND_MEMORY &&
        (first->memory.width == 32 || first->memory.width == 64))
    {
        u32 address_size = 0;
        if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        instruction->width = first->memory.width;
        instruction->size = (u32)assembly_x86_memory_rex_needed(0, (AssemblyRegister){0}, first->memory) + 1u + address_size;
        sized = true;
    }
    else if (instruction->operand_count != 2 || first->kind != ASSEMBLY_OPERAND_REGISTER || second->kind != ASSEMBLY_OPERAND_REGISTER ||
        first->reg.class != ASSEMBLY_REGISTER_X87 || second->reg.class != ASSEMBLY_REGISTER_X87 ||
        (first->reg.index != 0 && second->reg.index != 0))
    {
        sized = false;
    }
    else
    {
        instruction->width = 80;
        instruction->size = 2;
        sized = true;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_x87_pop_arithmetic(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    bool sized;
    if (first->kind != ASSEMBLY_OPERAND_REGISTER || second->kind != ASSEMBLY_OPERAND_REGISTER ||
        first->reg.class != ASSEMBLY_REGISTER_X87 || second->reg.class != ASSEMBLY_REGISTER_X87 || second->reg.index != 0)
    {
        sized = false;
    }
    else
    {
        instruction->width = 80;
        instruction->size = 2;
        sized = true;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_x87_compare(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOpcode opcode = instruction->opcode;
    bool sized;
    if (opcode == ASSEMBLY_OPCODE_X86_FCOMPP || opcode == ASSEMBLY_OPCODE_X86_FUCOMPP)
    {
        instruction->size = 2;
        sized = instruction->operand_count == 0;
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_FCOM || opcode == ASSEMBLY_OPCODE_X86_FCOMP)
    {
        if (first->kind == ASSEMBLY_OPERAND_REGISTER)
        {
            instruction->size = 2;
            return first->reg.class == ASSEMBLY_REGISTER_X87;
        }
        u32 address_size = 0;
        if (first->kind != ASSEMBLY_OPERAND_MEMORY || (first->memory.width != 32 && first->memory.width != 64) ||
            !assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        instruction->width = first->memory.width;
        instruction->size = (u32)assembly_x86_memory_rex_needed(0, (AssemblyRegister){0}, first->memory) + 1u + address_size;
        sized = true;
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_FUCOM || opcode == ASSEMBLY_OPCODE_X86_FUCOMP)
    {
        instruction->size = 2;
        sized = first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class == ASSEMBLY_REGISTER_X87;
    }
    else
    {
        instruction->size = 2;
        sized = first->kind == ASSEMBLY_OPERAND_REGISTER && second->kind == ASSEMBLY_OPERAND_REGISTER &&
               first->reg.class == ASSEMBLY_REGISTER_X87 && second->reg.class == ASSEMBLY_REGISTER_X87 && first->reg.index == 0;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_x87_integer_arithmetic(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    u32 address_size = 0;
    bool sized;
    if (first->kind != ASSEMBLY_OPERAND_MEMORY || (first->memory.width != 16 && first->memory.width != 32) ||
        !assembly_x86_memory_encoding_size(first->memory, &address_size))
    {
        sized = false;
    }
    else
    {
        instruction->width = first->memory.width;
        instruction->size = (u32)assembly_x86_memory_rex_needed(0, (AssemblyRegister){0}, first->memory) + 1u + address_size;
        sized = true;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_x87_state_memory(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOpcode opcode = instruction->opcode;
    u8 waited = opcode == ASSEMBLY_OPCODE_X86_FSTCW || opcode == ASSEMBLY_OPCODE_X86_FSTENV ||
                  opcode == ASSEMBLY_OPCODE_X86_FSAVE || opcode == ASSEMBLY_OPCODE_X86_FSTSW;
    bool sized;
    if ((opcode == ASSEMBLY_OPCODE_X86_FNSTSW || opcode == ASSEMBLY_OPCODE_X86_FSTSW) &&
        first->kind == ASSEMBLY_OPERAND_REGISTER)
    {
        instruction->width = 16;
        instruction->size = waited ? 3 : 2;
        sized = first->reg.class == ASSEMBLY_REGISTER_GPR && first->reg.width == 16 && first->reg.index == 0;
    }
    else if (first->kind != ASSEMBLY_OPERAND_MEMORY)
    {
        sized = false;
    }
    else
    {
        u16 expected_width = opcode == ASSEMBLY_OPCODE_X86_FBLD || opcode == ASSEMBLY_OPCODE_X86_FBSTP ? 80
                            : opcode == ASSEMBLY_OPCODE_X86_FLDCW || opcode == ASSEMBLY_OPCODE_X86_FNSTCW ||
                                      opcode == ASSEMBLY_OPCODE_X86_FSTCW || opcode == ASSEMBLY_OPCODE_X86_FNSTSW ||
                                      opcode == ASSEMBLY_OPCODE_X86_FSTSW
                                ? 16
                                : 0;
        if (first->memory.width && first->memory.width != expected_width)
        {
            sized = false;
        }
        else
        {
            u32 address_size = 0;
            if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
            {
                sized = false;
            }
            else
            {
                instruction->width = expected_width;
                instruction->size = (u32)waited + (u32)assembly_x86_memory_rex_needed(0, (AssemblyRegister){0}, first->memory) + 1u + address_size;
                sized = true;
            }
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_x87_stack_control(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOpcode opcode = instruction->opcode;
    instruction->width = 80;
    instruction->size = 2;
    bool sized;
    if (opcode == ASSEMBLY_OPCODE_X86_FINCSTP || opcode == ASSEMBLY_OPCODE_X86_FDECSTP)
    {
        sized = instruction->operand_count == 0;
    }
    else
    {
        sized = first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class == ASSEMBLY_REGISTER_X87;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_legacy_packed(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOpcode opcode = instruction->opcode;
    u8 move = opcode == ASSEMBLY_OPCODE_X86_MOVQ_MMX;
    bool sized;
    if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY) ||
        (!move && first->kind != ASSEMBLY_OPERAND_REGISTER))
    {
        sized = false;
    }
    else
    {
        AssemblyRegister packed_reg = first->kind == ASSEMBLY_OPERAND_REGISTER ? first->reg : second->reg;
        if ((packed_reg.class != ASSEMBLY_REGISTER_MMX && packed_reg.class != ASSEMBLY_REGISTER_XMM) ||
            (move && packed_reg.class != ASSEMBLY_REGISTER_MMX) ||
            (first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class != packed_reg.class) ||
            (second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.class != packed_reg.class))
        {
            sized = false;
        }
        else
        {
            AssemblyOperand* memory = first->kind == ASSEMBLY_OPERAND_MEMORY ? first : second->kind == ASSEMBLY_OPERAND_MEMORY ? second : 0;
            if (memory)
            {
                if (memory->memory.width && memory->memory.width != packed_reg.width)
                {
                    return false;
                }
                memory->memory.width = packed_reg.width;
            }
            u8 load = !move || first->kind == ASSEMBLY_OPERAND_REGISTER;
            AssemblyRegister reg = load ? packed_reg : second->reg;
            AssemblyOperand* rm = load ? second : first;
            u32 address_size = 1;
            u8 rex = rm->kind == ASSEMBLY_OPERAND_REGISTER
                           ? assembly_x86_rex_needed(0, reg, rm->reg)
                           : assembly_x86_memory_rex_needed(0, reg, rm->memory);
            if (rm->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(rm->memory, &address_size))
            {
                sized = false;
            }
            else
            {
                instruction->width = packed_reg.width;
                instruction->size = (u32)(packed_reg.class == ASSEMBLY_REGISTER_XMM) + (u32)rex + 2u + address_size;
                sized = true;
            }
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_setcc(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    bool sized;
    if (first->kind == ASSEMBLY_OPERAND_REGISTER)
    {
        if (first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.width != 8)
        {
            return false;
        }
        instruction->width = 8;
        instruction->size = (assembly_x86_rex_needed(8, (AssemblyRegister){0}, first->reg) ? 1 : 0) + 3;
        sized = true;
    }
    else if (first->kind == ASSEMBLY_OPERAND_MEMORY && (!first->memory.width || first->memory.width == 8))
    {
        u32 address_size = 0;
        if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        first->memory.width = 8;
        instruction->width = 8;
        instruction->size = (u32)assembly_x86_memory_rex_needed(8, (AssemblyRegister){0}, first->memory) + 2u + address_size;
        sized = true;
    }
    else
    {
        sized = false;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_cmovcc(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    bool sized;
    if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.width == 8 ||
        (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (second->kind == ASSEMBLY_OPERAND_REGISTER &&
         (second->reg.class != ASSEMBLY_REGISTER_GPR || second->reg.width != first->reg.width)))
    {
        sized = false;
    }
    else
    {
        instruction->width = first->reg.width;
        if (second->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            if (second->memory.width && second->memory.width != instruction->width)
            {
                return false;
            }
            second->memory.width = instruction->width;
        }
        u32 address_size = 1;
        u8 rex = second->kind == ASSEMBLY_OPERAND_REGISTER
                       ? assembly_x86_rex_needed(instruction->width, first->reg, second->reg)
                       : assembly_x86_memory_rex_needed(instruction->width, first->reg, second->memory);
        if (second->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(second->memory, &address_size))
        {
            sized = false;
        }
        else
        {
            instruction->size = (u32)(instruction->width == 16) + (u32)rex + 2u + address_size;
            sized = true;
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_sse2(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOpcode opcode = instruction->opcode;
    u8 move = opcode >= ASSEMBLY_OPCODE_X86_MOVAPS && opcode <= ASSEMBLY_OPCODE_X86_MOVDQU;
    bool sized;
    if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY) ||
        (!move && first->kind != ASSEMBLY_OPERAND_REGISTER) ||
        (first->kind == ASSEMBLY_OPERAND_REGISTER && (first->reg.class != ASSEMBLY_REGISTER_XMM || first->reg.index >= 16)) ||
        (second->kind == ASSEMBLY_OPERAND_REGISTER && (second->reg.class != ASSEMBLY_REGISTER_XMM || second->reg.index >= 16)))
    {
        sized = false;
    }
    else
    {
        if (first->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            if (first->memory.width && first->memory.width != 128)
            {
                return false;
            }
            first->memory.width = 128;
        }
        if (second->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            if (second->memory.width && second->memory.width != 128)
            {
                return false;
            }
            second->memory.width = 128;
        }
        u8 load = !move || first->kind == ASSEMBLY_OPERAND_REGISTER;
        AssemblyRegister reg = load ? first->reg : second->reg;
        AssemblyOperand* rm = load ? second : first;
        u32 address_size = 1;
        u8 rex = rm->kind == ASSEMBLY_OPERAND_REGISTER
                       ? assembly_x86_rex_needed(0, reg, rm->reg)
                       : assembly_x86_memory_rex_needed(0, reg, rm->memory);
        if (rm->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(rm->memory, &address_size))
        {
            sized = false;
        }
        else
        {
            u8 mandatory_prefix = opcode == ASSEMBLY_OPCODE_X86_MOVAPD || opcode == ASSEMBLY_OPCODE_X86_MOVUPD ||
                                    opcode == ASSEMBLY_OPCODE_X86_MOVDQA || opcode == ASSEMBLY_OPCODE_X86_MOVDQU ||
                                    opcode == ASSEMBLY_OPCODE_X86_XORPD || opcode == ASSEMBLY_OPCODE_X86_PXOR ||
                                    opcode == ASSEMBLY_OPCODE_X86_ADDPD || opcode == ASSEMBLY_OPCODE_X86_ADDSS ||
                                    opcode == ASSEMBLY_OPCODE_X86_ADDSD || opcode == ASSEMBLY_OPCODE_X86_SUBPD ||
                                    opcode == ASSEMBLY_OPCODE_X86_MULPD || opcode == ASSEMBLY_OPCODE_X86_DIVPD;
            instruction->width = 128;
            instruction->size = (u32)mandatory_prefix + (u32)rex + 2u + address_size;
            sized = true;
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_avx(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOpcode opcode = instruction->opcode;
    u8 move = assembly_x86_opcode_is_avx_move(opcode);
    u8 scalar = opcode == ASSEMBLY_OPCODE_X86_VADDSS || opcode == ASSEMBLY_OPCODE_X86_VADDSD;
    AssemblyOperand* source = move ? second : instruction->operands + 2;
    bool sized;
    if ((first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        source->kind == ASSEMBLY_OPERAND_EXPRESSION || source->kind == ASSEMBLY_OPERAND_NONE ||
        (first->kind == ASSEMBLY_OPERAND_MEMORY && source->kind == ASSEMBLY_OPERAND_MEMORY) ||
        (!move && (first->kind != ASSEMBLY_OPERAND_REGISTER || second->kind != ASSEMBLY_OPERAND_REGISTER)) ||
        (first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class != ASSEMBLY_REGISTER_XMM &&
         first->reg.class != ASSEMBLY_REGISTER_YMM) ||
        (second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.class != ASSEMBLY_REGISTER_XMM &&
         second->reg.class != ASSEMBLY_REGISTER_YMM) ||
        (source->kind == ASSEMBLY_OPERAND_REGISTER && source->reg.class != ASSEMBLY_REGISTER_XMM &&
         source->reg.class != ASSEMBLY_REGISTER_YMM))
    {
        sized = false;
    }
    else
    {
        AssemblyRegister vector_reg = first->kind == ASSEMBLY_OPERAND_REGISTER ? first->reg : second->reg;
        if ((scalar && vector_reg.class != ASSEMBLY_REGISTER_XMM) ||
            (second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.class != vector_reg.class) ||
            (source->kind == ASSEMBLY_OPERAND_REGISTER && source->reg.class != vector_reg.class))
        {
            sized = false;
        }
        else
        {
            u16 memory_width = scalar ? (opcode == ASSEMBLY_OPCODE_X86_VADDSS ? 32 : 64) : vector_reg.width;
            AssemblyOperand* memory = first->kind == ASSEMBLY_OPERAND_MEMORY ? first : source->kind == ASSEMBLY_OPERAND_MEMORY ? source : 0;
            if (memory)
            {
                if (memory->memory.width && memory->memory.width != memory_width)
                {
                    return false;
                }
                memory->memory.width = memory_width;
            }
            u8 load = !move || first->kind == ASSEMBLY_OPERAND_REGISTER;
            AssemblyOperand* rm = load ? source : first;
            u32 address_size = 1;
            if (rm->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(rm->memory, &address_size))
            {
                sized = false;
            }
            else
            {
                instruction->width = vector_reg.width;
                instruction->size = (assembly_x86_avx_map(opcode) != 1 || assembly_x86_vex_three_byte_needed(*rm) ? 3u : 2u) + 1u + address_size;
                sized = true;
            }
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_branch_target(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    bool sized;
    if (first->kind == ASSEMBLY_OPERAND_EXPRESSION)
    {
        instruction->size = 5;
        sized = true;
    }
    else if (first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.width == 64)
    {
        instruction->width = 64;
        instruction->size = first->reg.index >= 8 ? 3 : 2;
        sized = true;
    }
    else if (first->kind == ASSEMBLY_OPERAND_MEMORY && (!first->memory.width || first->memory.width == 64))
    {
        u32 address_size = 0;
        if (!assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            return false;
        }
        instruction->width = 64;
        first->memory.width = 64;
        instruction->size = (u32)assembly_x86_memory_rex_needed(0, (AssemblyRegister){0}, first->memory) + 1u + address_size;
        sized = true;
    }
    else
    {
        sized = false;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_push_pop(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    bool sized;
    if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.width != 64)
    {
        sized = false;
    }
    else
    {
        instruction->width = 64;
        instruction->size = first->reg.index >= 8 ? 2 : 1;
        sized = true;
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_unary_group(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    u32 lock_size = instruction->lock_prefix ? 1 : 0;
    instruction->width = assembly_operand_width(*first);
    bool sized;
    if (!instruction->width || (instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64) ||
        instruction->operand_count != 1 ||
        (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY))
    {
        sized = false;
    }
    else
    {
        u32 address_size = 1;
        u8 rex = first->kind == ASSEMBLY_OPERAND_REGISTER
                       ? assembly_x86_rex_needed(instruction->width, first->reg, (AssemblyRegister){0})
                       : assembly_x86_memory_rex_needed(instruction->width, (AssemblyRegister){0}, first->memory);
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            sized = false;
        }
        else
        {
            instruction->size = lock_size + (u32)(instruction->width == 16) + (u32)rex + 1u + address_size;
            sized = true;
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_imul_immediate(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOperand* third = instruction->operands + 2;
    bool sized;
    if (first->kind != ASSEMBLY_OPERAND_REGISTER || first->reg.class != ASSEMBLY_REGISTER_GPR || first->reg.width == 8 ||
        (second->kind != ASSEMBLY_OPERAND_REGISTER && second->kind != ASSEMBLY_OPERAND_MEMORY) ||
        (second->kind == ASSEMBLY_OPERAND_REGISTER &&
         (second->reg.class != ASSEMBLY_REGISTER_GPR || second->reg.width != first->reg.width)) ||
        third->kind != ASSEMBLY_OPERAND_EXPRESSION || third->expression.has_symbol)
    {
        sized = false;
    }
    else
    {
        instruction->width = first->reg.width;
        if (second->kind == ASSEMBLY_OPERAND_MEMORY)
        {
            if (second->memory.width && second->memory.width != instruction->width)
            {
                return false;
            }
            second->memory.width = instruction->width;
        }
        u16 full_immediate_width = instruction->width == 64 ? 32 : instruction->width;
        s64 immediate = third->expression.addend;
        if (!assembly_x86_immediate_fits(immediate, full_immediate_width, true))
        {
            sized = false;
        }
        else
        {
            u32 address_size = 1;
            u8 rex = second->kind == ASSEMBLY_OPERAND_REGISTER
                           ? assembly_x86_rex_needed(instruction->width, first->reg, second->reg)
                           : assembly_x86_memory_rex_needed(instruction->width, first->reg, second->memory);
            if (second->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(second->memory, &address_size))
            {
                sized = false;
            }
            else
            {
                u32 immediate_size = immediate >= INT8_MIN && immediate <= INT8_MAX ? 1 : full_immediate_width / 8;
                instruction->size = (u32)(instruction->width == 16) + (u32)rex + 1u + address_size + immediate_size;
                sized = true;
            }
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_size_shift(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    instruction->width = assembly_operand_width(*first);
    bool sized;
    if (!instruction->width || (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY) ||
        second->kind != ASSEMBLY_OPERAND_EXPRESSION || second->expression.has_symbol ||
        second->expression.addend < 0 || second->expression.addend > UINT8_MAX)
    {
        sized = false;
    }
    else
    {
        u32 address_size = 1;
        u8 rex = first->kind == ASSEMBLY_OPERAND_REGISTER
                       ? assembly_x86_rex_needed(instruction->width, first->reg, (AssemblyRegister){0})
                       : assembly_x86_memory_rex_needed(instruction->width, (AssemblyRegister){0}, first->memory);
        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
        {
            sized = false;
        }
        else
        {
            instruction->size = (u32)(instruction->width == 16) + (u32)rex + 1u + address_size +
                                (u32)(second->expression.addend != 1);
            sized = true;
        }
    }
    return sized;
}

// Everything the family ladder did not claim: a general-register operation
// whose size follows from its operand kinds and immediate width.
BUSTER_GLOBAL_LOCAL bool assembly_x86_general_instruction_size(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOperand* second = instruction->operands + 1;
    AssemblyOpcode opcode = instruction->opcode;
    u32 lock_size = instruction->lock_prefix ? 1 : 0;
    // A general-register operation is exactly that: any operand naming another
    // register class belongs to a family above, not here.
    bool sized = true;
    for (u32 operand_index = 0; operand_index < instruction->operand_count && sized; operand_index += 1)
    {
        sized = instruction->operands[operand_index].kind != ASSEMBLY_OPERAND_REGISTER ||
                instruction->operands[operand_index].reg.class == ASSEMBLY_REGISTER_GPR;
    }
    if (sized)
    {
        if (opcode == ASSEMBLY_OPCODE_X86_CALL || opcode == ASSEMBLY_OPCODE_X86_JMP)
        {
            sized = assembly_x86_size_branch_target(instruction);
        }
        else if (opcode == ASSEMBLY_OPCODE_X86_PUSH || opcode == ASSEMBLY_OPCODE_X86_POP)
        {
            sized = assembly_x86_size_push_pop(instruction);
        }
        else if (opcode == ASSEMBLY_OPCODE_X86_INC || opcode == ASSEMBLY_OPCODE_X86_DEC || opcode == ASSEMBLY_OPCODE_X86_NEG ||
            opcode == ASSEMBLY_OPCODE_X86_NOT || opcode == ASSEMBLY_OPCODE_X86_MUL || opcode == ASSEMBLY_OPCODE_X86_DIV ||
            opcode == ASSEMBLY_OPCODE_X86_IDIV || (opcode == ASSEMBLY_OPCODE_X86_IMUL && instruction->operand_count == 1))
        {
            sized = assembly_x86_size_unary_group(instruction);
        }
        else if (opcode == ASSEMBLY_OPCODE_X86_IMUL && instruction->operand_count == 3)
        {
            sized = assembly_x86_size_imul_immediate(instruction);
        }
        else if (opcode == ASSEMBLY_OPCODE_X86_SHL || opcode == ASSEMBLY_OPCODE_X86_SHR || opcode == ASSEMBLY_OPCODE_X86_SAR)
        {
            sized = assembly_x86_size_shift(instruction);
        }
        else if (first->kind != ASSEMBLY_OPERAND_REGISTER && first->kind != ASSEMBLY_OPERAND_MEMORY)
        {
            sized = false;
        }
        else
        {
            instruction->width = assembly_operand_width(*first);
            if (!instruction->width)
            {
                instruction->width = assembly_operand_width(*second);
            }
            if (!instruction->width ||
                (instruction->width != 8 && instruction->width != 16 && instruction->width != 32 && instruction->width != 64))
            {
                sized = false;
            }
            else
            {
                if (first->kind == ASSEMBLY_OPERAND_MEMORY)
                {
                    if (first->memory.width && first->memory.width != instruction->width)
                    {
                        return false;
                    }
                    first->memory.width = instruction->width;
                }
                if (second->kind == ASSEMBLY_OPERAND_MEMORY)
                {
                    if (second->memory.width && second->memory.width != instruction->width)
                    {
                        return false;
                    }
                    second->memory.width = instruction->width;
                }
                if (second->kind == ASSEMBLY_OPERAND_REGISTER || second->kind == ASSEMBLY_OPERAND_MEMORY)
                {
                    if ((second->kind == ASSEMBLY_OPERAND_REGISTER && second->reg.width != instruction->width) ||
                        (first->kind == ASSEMBLY_OPERAND_MEMORY && second->kind == ASSEMBLY_OPERAND_MEMORY) ||
                        (opcode == ASSEMBLY_OPCODE_X86_IMUL && first->kind != ASSEMBLY_OPERAND_REGISTER) ||
                        (opcode != ASSEMBLY_OPCODE_X86_MOV && opcode != ASSEMBLY_OPCODE_X86_ADD && opcode != ASSEMBLY_OPCODE_X86_ADC &&
                         opcode != ASSEMBLY_OPCODE_X86_SUB && opcode != ASSEMBLY_OPCODE_X86_SBB &&
                         opcode != ASSEMBLY_OPCODE_X86_AND && opcode != ASSEMBLY_OPCODE_X86_OR && opcode != ASSEMBLY_OPCODE_X86_XOR &&
                         opcode != ASSEMBLY_OPCODE_X86_CMP && opcode != ASSEMBLY_OPCODE_X86_TEST && opcode != ASSEMBLY_OPCODE_X86_IMUL))
                    {
                        return false;
                    }
                    if (opcode == ASSEMBLY_OPCODE_X86_IMUL && instruction->width == 8)
                    {
                        return false;
                    }
                    AssemblyRegister reg = opcode == ASSEMBLY_OPCODE_X86_IMUL || second->kind == ASSEMBLY_OPERAND_MEMORY ? first->reg : second->reg;
                    AssemblyOperand* rm = opcode == ASSEMBLY_OPCODE_X86_IMUL || second->kind == ASSEMBLY_OPERAND_MEMORY ? second : first;
                    u32 address_size = 1;
                    u8 rex = rm->kind == ASSEMBLY_OPERAND_REGISTER
                                   ? assembly_x86_rex_needed(instruction->width, reg, rm->reg)
                                   : assembly_x86_memory_rex_needed(instruction->width, reg, rm->memory);
                    if (rm->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(rm->memory, &address_size))
                    {
                        return false;
                    }
                    if ((rm->kind == ASSEMBLY_OPERAND_REGISTER && assembly_x86_rex_conflicts_high_byte(instruction->width, reg, rm->reg)) ||
                        (rm->kind == ASSEMBLY_OPERAND_MEMORY && assembly_x86_memory_rex_conflicts_high_byte(instruction->width, reg, rm->memory)))
                    {
                        return false;
                    }
                    instruction->size = lock_size + (u32)(instruction->width == 16) + (u32)rex +
                                        (opcode == ASSEMBLY_OPCODE_X86_IMUL ? 2u : 1u) + address_size;
                    sized = true;
                }
                else if (second->kind != ASSEMBLY_OPERAND_EXPRESSION || second->expression.has_symbol || opcode == ASSEMBLY_OPCODE_X86_IMUL)
                {
                    sized = false;
                }
                else
                {
                    s64 immediate = second->expression.addend;
                    if (opcode == ASSEMBLY_OPCODE_X86_MOV)
                    {
                        u16 immediate_width = first->kind == ASSEMBLY_OPERAND_MEMORY && instruction->width == 64 ? 32 : instruction->width;
                        if (!assembly_x86_immediate_fits(immediate, immediate_width, first->kind == ASSEMBLY_OPERAND_MEMORY && instruction->width == 64))
                        {
                            return false;
                        }
                        u32 address_size = 1;
                        u8 rex = first->kind == ASSEMBLY_OPERAND_REGISTER
                                       ? assembly_x86_rex_needed(instruction->width, first->reg, (AssemblyRegister){0})
                                       : assembly_x86_memory_rex_needed(instruction->width, (AssemblyRegister){0}, first->memory);
                        if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
                        {
                            return false;
                        }
                        instruction->size = (u32)(instruction->width == 16) + (u32)rex + 1u +
                                            (first->kind == ASSEMBLY_OPERAND_MEMORY ? address_size : 0u) + immediate_width / 8;
                        sized = true;
                    }
                    else if (opcode != ASSEMBLY_OPCODE_X86_ADD && opcode != ASSEMBLY_OPCODE_X86_ADC && opcode != ASSEMBLY_OPCODE_X86_SUB &&
                        opcode != ASSEMBLY_OPCODE_X86_SBB && opcode != ASSEMBLY_OPCODE_X86_AND && opcode != ASSEMBLY_OPCODE_X86_OR &&
                        opcode != ASSEMBLY_OPCODE_X86_XOR && opcode != ASSEMBLY_OPCODE_X86_CMP &&
                        opcode != ASSEMBLY_OPCODE_X86_TEST)
                    {
                        sized = false;
                    }
                    else
                    {
                        u8 signed_only = instruction->width == 64;
                        u16 full_immediate_width = instruction->width == 64 ? 32 : instruction->width;
                        if (!assembly_x86_immediate_fits(immediate, full_immediate_width, signed_only))
                        {
                            sized = false;
                        }
                        else
                        {
                            u32 immediate_size = opcode != ASSEMBLY_OPCODE_X86_TEST && immediate >= INT8_MIN && immediate <= INT8_MAX ? 1 : full_immediate_width / 8;
                            u32 address_size = 1;
                            u8 rex = first->kind == ASSEMBLY_OPERAND_REGISTER
                                           ? assembly_x86_rex_needed(instruction->width, first->reg, (AssemblyRegister){0})
                                           : assembly_x86_memory_rex_needed(instruction->width, (AssemblyRegister){0}, first->memory);
                            if (first->kind == ASSEMBLY_OPERAND_MEMORY && !assembly_x86_memory_encoding_size(first->memory, &address_size))
                            {
                                sized = false;
                            }
                            else
                            {
                                instruction->size = lock_size + (u32)(instruction->width == 16) + (u32)rex + 1u + address_size + immediate_size;
                                sized = true;
                            }
                        }
                    }
                }
            }
        }
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_size(AssemblyInstruction* instruction)
{
    AssemblyOperand* first = instruction->operands;
    AssemblyOpcode opcode = instruction->opcode;
    AssemblyVectorForm const* vector_form = assembly_x86_vector_form(opcode);
    bool sized;
    if (!assembly_x86_lock_prefix_legal(instruction))
    {
        sized = false;
    }
    else if (assembly_x86_instruction_has_high_byte(*instruction) &&
        (instruction->evex || assembly_x86_instruction_has_extended_gpr(*instruction) ||
         assembly_x86_instruction_operands_need_rex(*instruction)))
    {
        sized = false;
    }
    else if (!vector_form && assembly_x86_instruction_has_any_decorator(*instruction))
    {
        sized = false;
    }
    else if (instruction->no_flags && !assembly_x86_opcode_is_apx_nf(opcode))
    {
        sized = false;
    }
    else if (instruction->amd_form)
    {
        sized = assembly_x86_amd_instruction_size(instruction, instruction->amd_form);
    }
    else if (assembly_x86_opcode_is_amx(opcode))
    {
        sized = assembly_x86_amx_instruction_size(instruction);
    }
    else if (assembly_x86_opcode_is_mask(opcode))
    {
        sized = assembly_x86_mask_instruction_size(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_APX_PUSH2 || opcode == ASSEMBLY_OPCODE_X86_APX_POP2 ||
        (assembly_x86_opcode_is_apx_ndd(opcode) && instruction->operand_count == 3 &&
         !(opcode == ASSEMBLY_OPCODE_X86_IMUL && instruction->operands[2].kind == ASSEMBLY_OPERAND_EXPRESSION)))
    {
        sized = assembly_x86_apx_ndd_instruction_size(instruction);
    }
    else if (instruction->no_flags && assembly_x86_opcode_is_apx_nf(opcode) &&
        (instruction->operand_count == 1 || instruction->operand_count == 2 ||
         (opcode == ASSEMBLY_OPCODE_X86_IMUL && instruction->operand_count == 3 &&
          instruction->operands[2].kind == ASSEMBLY_OPERAND_EXPRESSION)))
    {
        sized = assembly_x86_apx_nf_instruction_size(instruction);
    }
    else if (instruction->evex && vector_form)
    {
        sized = assembly_x86_evex_instruction_size(instruction, vector_form);
    }
    else if (assembly_x86_instruction_has_extended_gpr(*instruction))
    {
        sized = assembly_x86_apx_legacy_instruction_size(instruction);
    }
    else if (assembly_x86_opcode_is_bit_atomic(opcode))
    {
        sized = assembly_x86_bit_atomic_instruction_size(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_LEA)
    {
        sized = assembly_x86_size_lea(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_MOVZX || opcode == ASSEMBLY_OPCODE_X86_MOVSX || opcode == ASSEMBLY_OPCODE_X86_MOVSXD)
    {
        sized = assembly_x86_size_move_extend(instruction);
    }
    else if (assembly_x86_opcode_is_rotate(opcode))
    {
        sized = assembly_x86_size_rotate(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_SHLD || opcode == ASSEMBLY_OPCODE_X86_SHRD)
    {
        sized = assembly_x86_size_double_shift(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_NOP || opcode == ASSEMBLY_OPCODE_X86_RET || opcode == ASSEMBLY_OPCODE_X86_INT3 ||
        opcode == ASSEMBLY_OPCODE_X86_CWDE || opcode == ASSEMBLY_OPCODE_X86_CDQ)
    {
        instruction->size = 1;
        sized = instruction->operand_count == 0;
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_CBW || opcode == ASSEMBLY_OPCODE_X86_CDQE || opcode == ASSEMBLY_OPCODE_X86_CWD ||
        opcode == ASSEMBLY_OPCODE_X86_CQO)
    {
        instruction->size = 2;
        sized = instruction->operand_count == 0;
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_EMMS)
    {
        instruction->size = 2;
        sized = instruction->operand_count == 0;
    }
    else if (assembly_x86_opcode_is_x87_zero_operand(opcode))
    {
        instruction->size = opcode == ASSEMBLY_OPCODE_X86_FWAIT ? 1
                            : opcode == ASSEMBLY_OPCODE_X86_FINIT || opcode == ASSEMBLY_OPCODE_X86_FCLEX ? 3
                                                                                                          : 2;
        sized = instruction->operand_count == 0;
    }
    else if (assembly_x86_opcode_is_x87_data(opcode))
    {
        sized = assembly_x86_size_x87_data(instruction);
    }
    else if (assembly_x86_opcode_is_x87_arithmetic(opcode))
    {
        sized = assembly_x86_size_x87_arithmetic(instruction);
    }
    else if (assembly_x86_opcode_is_x87_pop_arithmetic(opcode))
    {
        sized = assembly_x86_size_x87_pop_arithmetic(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_FXCH)
    {
        instruction->width = 80;
        instruction->size = 2;
        sized = first->kind == ASSEMBLY_OPERAND_REGISTER && first->reg.class == ASSEMBLY_REGISTER_X87;
    }
    else if (assembly_x86_opcode_is_x87_compare(opcode))
    {
        sized = assembly_x86_size_x87_compare(instruction);
    }
    else if (assembly_x86_opcode_is_x87_integer_arithmetic(opcode))
    {
        sized = assembly_x86_size_x87_integer_arithmetic(instruction);
    }
    else if (assembly_x86_opcode_is_x87_state_memory(opcode))
    {
        sized = assembly_x86_size_x87_state_memory(instruction);
    }
    else if (assembly_x86_opcode_is_x87_stack_control(opcode))
    {
        sized = assembly_x86_size_x87_stack_control(instruction);
    }
    else if (assembly_x86_opcode_is_legacy_packed(opcode))
    {
        sized = assembly_x86_size_legacy_packed(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_JCC)
    {
        instruction->size = 6;
        sized = first->kind == ASSEMBLY_OPERAND_EXPRESSION;
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_SETCC)
    {
        sized = assembly_x86_size_setcc(instruction);
    }
    else if (opcode == ASSEMBLY_OPCODE_X86_CMOVCC)
    {
        sized = assembly_x86_size_cmovcc(instruction);
    }
    else if (assembly_x86_opcode_is_sse2(opcode))
    {
        sized = assembly_x86_size_sse2(instruction);
    }
    else if (assembly_x86_opcode_is_avx(opcode))
    {
        sized = assembly_x86_size_avx(instruction);
    }
    else
    {
        sized = assembly_x86_general_instruction_size(instruction);
    }
    return sized;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_scalar_condition(String8 text, u64* value)
{
    static char const* names[] = {
        "eq", "ne", "cs", "hs", "cc", "lo", "mi", "pl", "vs", "vc", "hi", "ls", "ge", "lt", "gt", "le", "al", "nv",
    };
    static u8 values[] = {0, 1, 2, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    if (value)
    {
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(names); index += 1)
        {
            if (assembly_word_equal(text, string_from_pointer((char8*)names[index])))
            {
                *value = values[index];
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_scalar_constant(AssemblyBuilder* builder, String8 text, u64* value)
{
    text = assembly_trim(text);
    if (text.length && text.pointer[0] == '#') text = assembly_trim(string_slice(text, 1, text.length));
    if (!text.length || !value) return false;
    if (assembly_parse_u64(text, value)) return true;
    u32 symbol_count = builder ? builder->result.symbol_count : 0;
    AssemblyExpression expression = {0};
    bool parsed = builder && assembly_expression_parse(builder, text, &expression);
    if (builder) builder->result.symbol_count = symbol_count;
    if (!parsed || expression.has_symbol || expression.addend < 0) return false;
    *value = expression.has_unsigned_addend ? expression.unsigned_addend : (u64)expression.addend;
    return !expression.has_unsigned_addend || expression.unsigned_addend <= UINT64_MAX;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_scalar_memory_instruction_parse(AssemblyBuilder* builder, String8 mnemonic,
                                                                           String8 operands_text,
                                                                           AssemblyInstruction* instruction)
{
    u8 memory_size = 0;
    bool store = false;
    bool valid = builder && instruction && assembly_aarch64_scalar_memory_mnemonic(mnemonic, &memory_size, &store);
    String8 operands[2] = {0};
    u32 operand_count = 0;
    u64 cursor = 0;
    while (valid && cursor < operands_text.length)
    {
        valid = operand_count < BUSTER_ARRAY_LENGTH(operands) &&
                assembly_operand_split_next(operands_text, &cursor, operands + operand_count) == ASSEMBLY_OPERAND_SPLIT_SUCCESS;
        operand_count += valid;
    }
    valid = valid && operand_count == BUSTER_ARRAY_LENGTH(operands);

    AssemblyRegister data = {0};
    if (valid)
    {
        valid = assembly_aarch64_gpr_register_parse(operands[0], &data) && !data.stack_pointer;
        if (valid && !memory_size)
        {
            memory_size = data.width == 32 ? 4 : data.width == 64 ? 8 : 0;
            valid = memory_size != 0;
        }
        else if (valid)
        {
            valid = data.width == 32;
        }
    }

    String8 memory_text = valid ? assembly_trim(operands[1]) : (String8){0};
    valid = valid && memory_text.length >= 3 && memory_text.pointer[0] == '[' &&
            memory_text.pointer[memory_text.length - 1] == ']';
    String8 memory_operands[2] = {0};
    u32 memory_operand_count = 0;
    cursor = 0;
    String8 memory_contents = valid ? assembly_trim(string_slice(memory_text, 1, memory_text.length - 1)) : (String8){0};
    while (valid && cursor < memory_contents.length)
    {
        valid = memory_operand_count < BUSTER_ARRAY_LENGTH(memory_operands) &&
                assembly_operand_split_next(memory_contents, &cursor, memory_operands + memory_operand_count) ==
                    ASSEMBLY_OPERAND_SPLIT_SUCCESS;
        memory_operand_count += valid;
    }
    valid = valid && memory_operand_count >= 1 && memory_operand_count <= 2;

    AssemblyRegister base = {0};
    if (valid)
    {
        valid = assembly_aarch64_gpr_register_parse(memory_operands[0], &base) && base.width == 64 &&
                (base.index != 31 || base.stack_pointer);
    }
    u64 offset = 0;
    if (valid && memory_operand_count == 2)
    {
        String8 offset_text = assembly_trim(memory_operands[1]);
        valid = offset_text.length && offset_text.pointer[0] == '#' &&
                assembly_aarch64_scalar_constant(builder, offset_text, &offset) && !(offset % memory_size) &&
                offset / memory_size <= UINT32_C(0xfff);
    }
    if (valid)
    {
        instruction->aarch64_scalar_memory_form_id =
            store ? memory_size == 1   ? BUSTER_AARCH64_GENERATED_FORM_STRBBUI
                    : memory_size == 2 ? BUSTER_AARCH64_GENERATED_FORM_STRHHUI
                    : memory_size == 4 ? BUSTER_AARCH64_GENERATED_FORM_STRWUI
                                       : BUSTER_AARCH64_GENERATED_FORM_STRXUI
                  : memory_size == 1   ? BUSTER_AARCH64_GENERATED_FORM_LDRBBUI
                    : memory_size == 2 ? BUSTER_AARCH64_GENERATED_FORM_LDRHHUI
                    : memory_size == 4 ? BUSTER_AARCH64_GENERATED_FORM_LDRWUI
                                       : BUSTER_AARCH64_GENERATED_FORM_LDRXUI;
        instruction->operands[0] = (AssemblyOperand){.reg = data, .kind = ASSEMBLY_OPERAND_REGISTER};
        instruction->operands[1] = (AssemblyOperand){
            .memory = {.displacement = {.addend = (s64)offset, .unsigned_addend = offset, .has_unsigned_addend = true},
                       .base = base, .width = (u16)(memory_size * 8u), .has_base = true, .width_explicit = true},
            .kind = ASSEMBLY_OPERAND_MEMORY,
        };
        instruction->operand_count = 2;
        instruction->size = 4;
    }
    return valid;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_scalar_modifier(String8 text, A64ScalarIntModifier* result)
{
    text = assembly_trim(text);
    if (text.length && result)
    {
        u64 separator = 0;
        while (separator < text.length && !assembly_space(text.pointer[separator])) separator += 1;
        String8 name = string_slice(text, 0, separator);
        String8 amount_text = separator < text.length ? assembly_trim(string_slice(text, separator, text.length)) : (String8){0};
        u64 amount = 0;
        if (amount_text.length)
        {
            if (amount_text.pointer[0] != '#') return false;
            if (!assembly_aarch64_scalar_constant(0, amount_text, &amount)) return false;
        }
        static char const* shifts[] = {"lsl", "lsr", "asr", "ror"};
        for (u8 index = 0; index < BUSTER_ARRAY_LENGTH(shifts); index += 1)
        {
            if (assembly_word_equal(name, string_from_pointer((char8*)shifts[index])))
            {
                if (!amount_text.length) return false;
                *result = (A64ScalarIntModifier){.amount = amount, .kind = A64_SCALAR_INT_MODIFIER_SHIFT, .value = index, .present = true};
                return true;
            }
        }
        static char const* extends[] = {"uxtb", "uxth", "uxtw", "uxtx", "sxtb", "sxth", "sxtw", "sxtx"};
        for (u8 index = 0; index < BUSTER_ARRAY_LENGTH(extends); index += 1)
        {
            if (assembly_word_equal(name, string_from_pointer((char8*)extends[index])))
            {
                *result = (A64ScalarIntModifier){.amount = amount, .kind = A64_SCALAR_INT_MODIFIER_EXTEND, .value = index, .present = true};
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_scalar_instruction_parse(AssemblyBuilder* builder, String8 mnemonic, String8 operands_text,
                                                                    AssemblyInstruction* instruction, u32 line, u32 column)
{
    String8 tokens[ASSEMBLY_MAX_OPERANDS] = {0};
    u32 token_count = 0;
    u64 cursor = 0;
    while (cursor < operands_text.length)
    {
        if (token_count >= BUSTER_ARRAY_LENGTH(tokens)) return false;
        String8 token = {0};
        if (assembly_operand_split_next(operands_text, &cursor, &token) != ASSEMBLY_OPERAND_SPLIT_SUCCESS) return false;
        tokens[token_count++] = token;
    }
    A64ScalarIntOperand parsed_operands[4] = {0};
    A64ScalarIntModifier parsed_modifiers[1] = {0};
    u32 operand_count = 0;
    u32 modifier_count = 0;
    bool compare_alias = assembly_word_equal(mnemonic, S8("cmp"));
    bool compare_negative_alias = assembly_word_equal(mnemonic, S8("cmn"));
    bool is_condcmp = assembly_word_equal(mnemonic, S8("ccmn")) || assembly_word_equal(mnemonic, S8("ccmp"));
    for (u32 index = 0; index < token_count; index += 1)
    {
        String8 token = assembly_trim(tokens[index]);
        /* CCMP/CCMN's final field is a bare condition mnemonic, never a
           numeric immediate (e.g. '#0'). Handle it before register parsing
           so malformed final operands cannot be accepted as GPRs. */
        if (is_condcmp && index + 1 == token_count)
        {
            u64 condition = 0;
            if (!assembly_aarch64_scalar_condition(token, &condition) || operand_count >= BUSTER_ARRAY_LENGTH(parsed_operands)) return false;
            parsed_operands[operand_count++] = (A64ScalarIntOperand){.kind = A64_SCALAR_INT_OPERAND_IMMEDIATE, .value = condition};
            continue;
        }
        AssemblyRegister reg = {0};
        if (assembly_aarch64_gpr_register_parse(token, &reg))
        {
            if (operand_count >= BUSTER_ARRAY_LENGTH(parsed_operands)) return false;
            parsed_operands[operand_count++] = (A64ScalarIntOperand){
                .kind = A64_SCALAR_INT_OPERAND_REGISTER,
                .width = (u8)reg.width,
                .index = reg.index,
                .stack_pointer = reg.stack_pointer,
            };
            continue;
        }
        A64ScalarIntModifier modifier = {0};
        if (assembly_aarch64_scalar_modifier(token, &modifier))
        {
            if (index + 1 != token_count) return false;
            if (modifier_count) return false;
            parsed_modifiers[modifier_count++] = modifier;
            continue;
        }
        u64 value = 0;
        if (!token.length || token.pointer[0] != '#' || !assembly_aarch64_scalar_constant(builder, token, &value) ||
            operand_count >= BUSTER_ARRAY_LENGTH(parsed_operands))
        {
            return false;
        }
        parsed_operands[operand_count++] = (A64ScalarIntOperand){.kind = A64_SCALAR_INT_OPERAND_IMMEDIATE, .value = value};
    }
    String8 encoded_mnemonic = mnemonic;
    if (compare_alias || compare_negative_alias)
    {
        if (!operand_count || operand_count >= BUSTER_ARRAY_LENGTH(parsed_operands) ||
            parsed_operands[0].kind != A64_SCALAR_INT_OPERAND_REGISTER)
        {
            return false;
        }
        memmove(parsed_operands + 1, parsed_operands, sizeof(*parsed_operands) * operand_count);
        parsed_operands[0] = (A64ScalarIntOperand){
            .kind = A64_SCALAR_INT_OPERAND_REGISTER,
            .width = parsed_operands[1].width,
            .index = 31,
        };
        operand_count += 1;
        encoded_mnemonic = compare_alias ? S8("subs") : S8("adds");
    }
    u32 form_index = UINT32_MAX;
    if (!buster_aarch64_arm_m1_scalar_integer_find_form(encoded_mnemonic, parsed_operands, operand_count, parsed_modifiers, modifier_count,
                                                         &form_index))
    {
        return false;
    }
    BusterAarch64ArmM1ScalarIntegerForm form = {0};
    if (!buster_aarch64_arm_m1_scalar_integer_form(form_index, &form)) return false;
    if (form.required_feature != TARGET_CPU_FEATURE_NONE && !target_cpu_feature_has(builder->target, form.required_feature))
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                            S8("instruction requires an enabled AArch64 target feature"));
        return false;
    }
    instruction->aarch64_scalar_integer_form_index = form_index;
    instruction->aarch64_scalar_integer_operand_count = (u8)operand_count;
    instruction->aarch64_scalar_integer_modifier_count = (u8)modifier_count;
    memcpy(instruction->aarch64_scalar_integer_operands, parsed_operands,
           sizeof(*parsed_operands) * operand_count);
    memcpy(instruction->aarch64_scalar_integer_modifiers, parsed_modifiers,
           sizeof(*parsed_modifiers) * modifier_count);
    instruction->operand_count = (u8)operand_count;
    instruction->size = 4;
    return true;
}

/* Direct AdvSIMD spellings intentionally win mnemonic lookup so their vector
 * grammar can be selected without a second global dispatch table.  A handful
 * of those mnemonics are also present in the M1 scalar/GPR projections.  If
 * the direct candidate rejects the operands, retry the existing M1 parsers
 * transactionally: no direct-parser partial state or diagnostic may leak into
 * the fallback, and a direct unsupported-feature diagnostic remains the final
 * answer when neither M1 grammar matches. */
BUSTER_GLOBAL_LOCAL bool assembly_aarch64_m1_collision_parse(AssemblyBuilder* builder, String8 mnemonic, String8 operands_text,
                                                             AssemblyInstruction* instruction, u32 line, u32 column)
{
    if (builder && instruction && target_cpu_features_are_valid(builder->target))
    {
        u32 initial_diagnostic_count = builder->result.diagnostic_count;
        u32 saved_diagnostic_count = initial_diagnostic_count;

        bool scalar_known = false;
        u8 scalar_operand_count = 0;
        for (u32 form_index = 0; form_index < buster_aarch64_arm_m1_scalar_integer_form_count(); form_index += 1)
        {
            BusterAarch64ArmM1ScalarIntegerForm form = {0};
            if (!buster_aarch64_arm_m1_scalar_integer_form(form_index, &form) || !assembly_word_equal(mnemonic, form.mnemonic))
            {
                continue;
            }
            if (!scalar_known)
            {
                scalar_known = true;
                scalar_operand_count = form.operand_count;
            }
            else if (scalar_operand_count != form.operand_count)
            {
                scalar_known = false;
                break;
            }
        }
        (void)scalar_operand_count;
        if (scalar_known)
        {
            AssemblyInstruction candidate = *instruction;
            if (assembly_aarch64_scalar_instruction_parse(builder, mnemonic, operands_text, &candidate, line, column))
            {
                candidate.opcode = ASSEMBLY_OPCODE_COUNT;
                candidate.encoding_kind = ASSEMBLY_ENCODING_AARCH64_M1_SCALAR_INTEGER;
                *instruction = candidate;
                return true;
            }
            saved_diagnostic_count = builder->result.diagnostic_count > saved_diagnostic_count
                                        ? builder->result.diagnostic_count
                                        : saved_diagnostic_count;
            builder->result.diagnostic_count = initial_diagnostic_count;
        }

        bool gpr_known = false;
        u8 gpr_operand_count = 0;
        for (u32 form_index = 0; form_index < buster_aarch64_arm_m1_gpr_form_count(); form_index += 1)
        {
            BusterAarch64ArmM1GprForm form = {0};
            if (!buster_aarch64_arm_m1_gpr_form(form_index, &form) || !assembly_word_equal(mnemonic, form.mnemonic))
            {
                continue;
            }
            if (!gpr_known)
            {
                gpr_known = true;
                gpr_operand_count = form.operand_count;
            }
            else if (gpr_operand_count != form.operand_count)
            {
                gpr_known = false;
                break;
            }
        }
        if (gpr_known)
        {
            String8 tokens[ASSEMBLY_MAX_OPERANDS] = {0};
            u32 token_count = 0;
            bool token_stream_valid = true;
            u64 cursor = 0;
            while (cursor < operands_text.length)
            {
                if (token_count >= BUSTER_ARRAY_LENGTH(tokens))
                {
                    token_stream_valid = false;
                    break;
                }
                String8 token = {0};
                if (assembly_operand_split_next(operands_text, &cursor, &token) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
                {
                    token_stream_valid = false;
                    break;
                }
                tokens[token_count++] = assembly_trim(token);
            }
            if (token_stream_valid && token_count <= ASSEMBLY_MAX_OPERANDS)
            {
                A64GprOperand gpr_operands[4] = {0};
                AssemblyInstruction candidate = *instruction;
                bool parsed = token_count <= BUSTER_ARRAY_LENGTH(gpr_operands);
                for (u32 operand_index = 0; parsed && operand_index < token_count; operand_index += 1)
                {
                    AssemblyRegister reg = {0};
                    parsed = assembly_aarch64_gpr_register_parse(tokens[operand_index], &reg) &&
                             reg.class == ASSEMBLY_REGISTER_GPR;
                    if (parsed)
                    {
                        gpr_operands[operand_index] = (A64GprOperand){
                            .index = reg.index,
                            .width = (u8)reg.width,
                            .stack_pointer = reg.stack_pointer,
                        };
                        candidate.operands[operand_index] = (AssemblyOperand){
                            .reg = reg,
                            .kind = ASSEMBLY_OPERAND_REGISTER,
                        };
                    }
                }
                u32 form_index = UINT32_MAX;
                parsed = parsed && buster_aarch64_arm_m1_gpr_find_form(mnemonic, gpr_operands, token_count, &form_index);
                if (parsed)
                {
                    BusterAarch64ArmM1GprForm form = {0};
                    parsed = buster_aarch64_arm_m1_gpr_form(form_index, &form);
                    if (parsed && form.required_feature != TARGET_CPU_FEATURE_NONE &&
                        !target_cpu_feature_has(builder->target, form.required_feature))
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column,
                                            (u32)mnemonic.length,
                                            S8("instruction requires an enabled AArch64 target feature"));
                        parsed = false;
                    }
                }
                if (parsed)
                {
                    candidate.operand_count = (u8)token_count;
                    candidate.opcode = ASSEMBLY_OPCODE_COUNT;
                    candidate.encoding_kind = ASSEMBLY_ENCODING_AARCH64_M1_GPR;
                    candidate.aarch64_gpr_form_index = form_index;
                    candidate.size = 4;
                    *instruction = candidate;
                    return true;
                }
            }
            saved_diagnostic_count = builder->result.diagnostic_count > saved_diagnostic_count
                                        ? builder->result.diagnostic_count
                                        : saved_diagnostic_count;
            builder->result.diagnostic_count = initial_diagnostic_count;
        }
        builder->result.diagnostic_count = saved_diagnostic_count;
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_register_parse(String8 text, BusterA64DirectSIMDArrangement arrangement, u32* number)
{
    text = assembly_trim(text);
    if (!number || !text.length)
    {
        return false;
    }
    bool scalar = arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B || arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H ||
                  arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S || arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D;
    char8 expected_prefix = 'v';
    switch (arrangement)
    {
    case BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q:
        expected_prefix = 'q';
        break;
    case BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B:
        expected_prefix = 'b';
        break;
    case BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H:
        expected_prefix = 'h';
        break;
    case BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S:
        expected_prefix = 's';
        break;
    case BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D:
        expected_prefix = 'd';
        break;
    default:
        break;
    }
    if (assembly_ascii_lower(text.pointer[0]) != expected_prefix)
    {
        return false;
    }
    u64 dot = 1;
    while (dot < text.length && text.pointer[dot] >= '0' && text.pointer[dot] <= '9')
    {
        dot += 1;
    }
    if (dot == 1 || dot > 3 || (dot > 2 && text.pointer[1] == '0'))
    {
        return false;
    }
    u32 parsed_number = 0;
    for (u64 index = 1; index < dot; index += 1)
    {
        parsed_number = parsed_number * 10u + (u32)(text.pointer[index] - '0');
    }
    if (parsed_number > 31)
    {
        return false;
    }
    if (arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q || scalar)
    {
        if (dot != text.length)
        {
            return false;
        }
    }
    else if (dot >= text.length || text.pointer[dot] != '.' ||
             !assembly_word_equal(string_slice(text, dot + 1, text.length), buster_a64_direct_simd_arrangement_string(arrangement)))
    {
        return false;
    }
    *number = parsed_number;
    return true;
}

typedef struct AssemblyAarch64DirectSIMDParsedRegister AssemblyAarch64DirectSIMDParsedRegister;
struct AssemblyAarch64DirectSIMDParsedRegister
{
    u32 number;
    BusterA64DirectSIMDArrangement arrangement;
    char8 prefix;
};

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_arrangement_parse(String8 text,
                                                                         BusterA64DirectSIMDArrangement* result)
{
    if (result)
    {
        for (u32 index = 1; index < BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_COUNT; index += 1)
        {
            BusterA64DirectSIMDArrangement arrangement = (BusterA64DirectSIMDArrangement)index;
            if (assembly_word_equal(text, buster_a64_direct_simd_arrangement_string(arrangement)))
            {
                *result = arrangement;
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_register_parse_any(String8 text,
                                                                          AssemblyAarch64DirectSIMDParsedRegister* result)
{
    text = assembly_trim(text);
    if (!result || !text.length)
    {
        return false;
    }
    char8 prefix = assembly_ascii_lower(text.pointer[0]);
    BusterA64DirectSIMDArrangement arrangement = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID;
    if (prefix == 'q')
    {
        arrangement = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_Q;
    }
    else if (prefix == 'b')
    {
        arrangement = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B;
    }
    else if (prefix == 'h')
    {
        arrangement = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H;
    }
    else if (prefix == 's')
    {
        arrangement = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S;
    }
    else if (prefix == 'd')
    {
        arrangement = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D;
    }
    else if (prefix != 'v')
    {
        return false;
    }
    u64 dot = 1;
    while (dot < text.length && text.pointer[dot] >= '0' && text.pointer[dot] <= '9')
    {
        dot += 1;
    }
    if (dot == 1 || dot > 3 || (dot > 2 && text.pointer[1] == '0'))
    {
        return false;
    }
    u32 number = 0;
    for (u64 index = 1; index < dot; index += 1)
    {
        number = number * 10u + (u32)(text.pointer[index] - '0');
    }
    if (number > 31)
    {
        return false;
    }
    if (prefix == 'v')
    {
        if (dot >= text.length || text.pointer[dot] != '.' ||
            !assembly_aarch64_direct_simd_arrangement_parse(string_slice(text, dot + 1, text.length), &arrangement))
        {
            return false;
        }
        if (buster_a64_direct_simd_value_vector(number, arrangement).kind == BUSTER_A64_SEMANTIC_VM_VALUE_INVALID)
        {
            return false;
        }
    }
    else if (dot != text.length)
    {
        return false;
    }
    *result = (AssemblyAarch64DirectSIMDParsedRegister){.number = number, .arrangement = arrangement, .prefix = prefix};
    return true;
}

/* TBL/TBX expose one brace-delimited table list as a single public operand.
 * The generated semantic rows expand that operand into one list-member value
 * per table register, with register_add_mod relations for the following
 * members.  Keep this parser deliberately local to that shape: no generic
 * brace/list grammar is admitted through direct SIMD. */
BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_list_parse(String8 text, u32 expected_count, u32* first)
{
    text = assembly_trim(text);
    if (!first || expected_count == 0 || expected_count > 4 || text.length < 2 || text.pointer[0] != '{' ||
        text.pointer[text.length - 1] != '}')
    {
        return false;
    }
    String8 body = string_slice(text, 1, text.length - 1);
    u64 cursor = 0;
    u32 count = 0;
    u32 base = 0;
    while (cursor < body.length)
    {
        String8 member = {0};
        if (count >= expected_count || assembly_operand_split_next(body, &cursor, &member) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
        {
            return false;
        }
        AssemblyAarch64DirectSIMDParsedRegister parsed = {0};
        if (!assembly_aarch64_direct_simd_register_parse_any(member, &parsed) || parsed.prefix != 'v' ||
            parsed.arrangement != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B)
        {
            return false;
        }
        if (count == 0)
        {
            base = parsed.number;
        }
        else if (parsed.number != ((base + count) & 31u))
        {
            return false;
        }
        count += 1;
    }
    if (count != expected_count)
    {
        return false;
    }
    *first = base;
    return true;
}

typedef enum AssemblyAarch64DirectSIMDCandidateResult
{
    ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID,
    ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_FEATURE,
    ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_MATCH,
} AssemblyAarch64DirectSIMDCandidateResult;

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_semantic_values_build(
    u32 row_index, BusterA64SemanticForm form, u32 const* registers, BusterA64DirectSIMDArrangement const* arrangements,
    u32 const* conditions, u8 const* gpr_widths, BusterA64DirectSIMDInstruction* result)
{
    if (!registers || !arrangements || !conditions || !result || form.operand_count > BUSTER_A64_DIRECT_SIMD_MAX_OPERANDS)
    {
        return false;
    }
    u32 source_index[8] = {UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX};
    u32 source_count = 0;
    u32 list_source = UINT32_MAX;
    u32 index_vector_source = UINT32_MAX;
    for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
    {
        BusterA64SemanticOperand operand = {0};
        if (!buster_a64_semantic_operand(form.operand_first + operand_index, &operand))
        {
            return false;
        }
        bool list_member = operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LIST ||
                           (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LIST_MEMBER) != 0;
        bool index_vector = operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LANE &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_INDEX_REGISTER) != 0 &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LANE_INDEX) != 0 &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0;
        if (list_member)
        {
            if (list_source == UINT32_MAX)
            {
                if (source_count >= 4)
                {
                    return false;
                }
                list_source = source_count++;
            }
            source_index[operand_index] = list_source;
        }
        else if (index_vector)
        {
            if (index_vector_source == UINT32_MAX)
            {
                if (source_count >= 4)
                {
                    return false;
                }
                index_vector_source = source_count++;
            }
            source_index[operand_index] = index_vector_source;
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER)
        {
            if (source_count >= 4)
            {
                return false;
            }
            source_index[operand_index] = source_count;
            source_count += 1;
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER)
        {
            if (source_count >= 4)
            {
                return false;
            }
            source_index[operand_index] = source_count;
            source_count += 1;
        }
        else if (operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_ARRANGEMENT &&
                 operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_WIDTH_SELECTOR &&
                 operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_PREFIX_SELECTOR &&
                 operand.kind != BUSTER_A64_SEMANTIC_OPERAND_GPR_WIDTH_SELECTOR &&
                 operand.kind != BUSTER_A64_SEMANTIC_OPERAND_FIXED_CONSTANT)
        {
            if (operand.kind != BUSTER_A64_SEMANTIC_OPERAND_CONDITION ||
                (operand.flags & BUSTER_A64_SEMANTIC_FLAG_CONDITION_FIELD) == 0)
            {
                return false;
            }
        }
    }
    BusterA64DirectSIMDInstruction instruction = {.row_index = row_index, .operand_count = (u8)form.operand_count};
    for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
    {
        BusterA64SemanticOperand operand = {0};
        if (!buster_a64_semantic_operand(form.operand_first + operand_index, &operand))
        {
            return false;
        }
        bool list_member = operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LIST ||
                           (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LIST_MEMBER) != 0;
        bool index_vector = operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LANE &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_INDEX_REGISTER) != 0 &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LANE_INDEX) != 0 &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0;
        if (list_member)
        {
            u32 source = source_index[operand_index];
            if (source != list_source)
            {
                return false;
            }
            u32 count = 0;
            for (u32 list_index = 0; list_index < form.operand_count; list_index += 1)
            {
                BusterA64SemanticOperand candidate = {0};
                if (!buster_a64_semantic_operand(form.operand_first + list_index, &candidate))
                {
                    return false;
                }
                bool candidate_list = candidate.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LIST ||
                                      (candidate.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LIST_MEMBER) != 0;
                if (candidate_list)
                {
                    count += 1;
                }
            }
            instruction.operands[operand_index] =
                buster_a64_direct_simd_value_list(registers[source], count, arrangements[source]);
        }
        else if (index_vector)
        {
            u32 source = source_index[operand_index];
            if (source != index_vector_source)
            {
                return false;
            }
            instruction.operands[operand_index] = buster_a64_direct_simd_value_vector(registers[source], arrangements[source]);
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER)
        {
            u32 source = source_index[operand_index];
            if (source >= source_count)
            {
                return false;
            }
            bool scalar = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_SCALAR) != 0;
            bool vector = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0;
            if (!scalar && !vector)
            {
                BusterA64SemanticVMValue scalar_value =
                    buster_a64_direct_simd_value_scalar(registers[source], arrangements[source]);
                BusterA64SemanticVMValue vector_value =
                    buster_a64_direct_simd_value_vector(registers[source], arrangements[source]);
                scalar = scalar_value.kind != BUSTER_A64_SEMANTIC_VM_VALUE_INVALID;
                if (!scalar && vector_value.kind == BUSTER_A64_SEMANTIC_VM_VALUE_INVALID)
                {
                    return false;
                }
            }
            instruction.operands[operand_index] = scalar
                ? buster_a64_direct_simd_value_scalar(registers[source], arrangements[source])
                : buster_a64_direct_simd_value_vector(registers[source], arrangements[source]);
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER)
        {
            u32 source = source_index[operand_index];
            if (source >= source_count || !gpr_widths || (gpr_widths[source] != 32 && gpr_widths[source] != 64))
            {
                return false;
            }
            instruction.operands[operand_index] = buster_a64_direct_simd_value_gpr(
                registers[source], gpr_widths[source], registers[source] == 31);
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_WIDTH_SELECTOR)
        {
            u32 gpr_source = UINT32_MAX;
            for (u32 candidate_index = 0; candidate_index < form.operand_count; candidate_index += 1)
            {
                BusterA64SemanticOperand candidate = {0};
                if (!buster_a64_semantic_operand(form.operand_first + candidate_index, &candidate))
                {
                    return false;
                }
                if (candidate.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER)
                {
                    gpr_source = source_index[candidate_index];
                    break;
                }
            }
            if (gpr_source == UINT32_MAX || !gpr_widths ||
                (gpr_widths[gpr_source] != 32 && gpr_widths[gpr_source] != 64))
            {
                return false;
            }
            instruction.operands[operand_index] = buster_a64_direct_simd_value_gpr_width(gpr_widths[gpr_source]);
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_CONDITION)
        {
            if ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_CONDITION_FIELD) == 0 || conditions[operand_index] > 15)
            {
                return false;
            }
            instruction.operands[operand_index] = buster_a64_semantic_vm_value_condition(conditions[operand_index]);
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_FIXED_CONSTANT)
        {
            if ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_FIXED_LITERAL_2) == 0 || operand.symbol.length != 1 ||
                buster_a64_semantic_string_byte(operand.symbol, 0) != '2')
            {
                return false;
            }
            instruction.operands[operand_index] = buster_a64_semantic_vm_value_unsigned(2, 2);
        }
        else
        {
            u32 bound_register = UINT32_MAX;
            for (u32 register_index = 0; register_index < form.operand_count; register_index += 1)
            {
                BusterA64SemanticOperand candidate = {0};
                BusterA64DirectSIMDArrangementBinding binding = {0};
                if (!buster_a64_semantic_operand(form.operand_first + register_index, &candidate) ||
                    (candidate.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER &&
                     !(candidate.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LANE &&
                       (candidate.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_INDEX_REGISTER) != 0 &&
                       (candidate.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LANE_INDEX) != 0 &&
                       (candidate.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0)) ||
                    !buster_a64_direct_simd_arrangement_binding(row_index, register_index, &binding) ||
                    binding.selector_index != operand_index)
                {
                    continue;
                }
                bound_register = register_index;
                break;
            }
            if (bound_register == UINT32_MAX || source_index[bound_register] >= source_count)
            {
                return false;
            }
            instruction.operands[operand_index] = buster_a64_direct_simd_value_arrangement(
                arrangements[source_index[bound_register]]);
        }
        if (instruction.operands[operand_index].kind == BUSTER_A64_SEMANTIC_VM_VALUE_INVALID)
        {
            return false;
        }
    }
    *result = instruction;
    return source_count != 0;
}

BUSTER_GLOBAL_LOCAL AssemblyAarch64DirectSIMDCandidateResult assembly_aarch64_direct_simd_generated_candidate(
    Target target, String8 tokens[4], u32 token_count, AssemblyAarch64DirectSIMDSpelling spelling,
    u32 row_index, u32* registers, BusterA64DirectSIMDArrangement* arrangements, u32* conditions,
    u8* gpr_widths)
{
    BusterA64DirectSIMDRowInfo row = {0};
    if (!buster_a64_direct_simd_row(row_index, &row) || !registers || !arrangements || !conditions || !gpr_widths)
    {
        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
    }
    if (!row.transform_bearing)
    {
        if (token_count != spelling.operand_count || token_count > 4)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        BusterA64SemanticForm form = {0};
        if (!buster_a64_semantic_form(row.semantic_form_id, &form) ||
            form.operand_count > BUSTER_A64_DIRECT_SIMD_MAX_OPERANDS)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        bool has_gpr = false;
        for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
        {
            BusterA64SemanticOperand operand = {0};
            if (!buster_a64_semantic_operand(form.operand_first + operand_index, &operand))
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            has_gpr |= operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER;
        }
        if (!has_gpr)
        {
            for (u32 operand_index = 0; operand_index < token_count; operand_index += 1)
            {
                if (!assembly_aarch64_direct_simd_register_parse(tokens[operand_index], spelling.arrangements[operand_index],
                                                                  &registers[operand_index]))
                {
                    return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                }
                arrangements[operand_index] = spelling.arrangements[operand_index];
            }
        }
        else
        {
            /* Keep this fixed-row extension deliberately semantic-driven:
             * only the GPR and scalar SIMD register kinds are accepted.  No
             * immediate, memory, lane, list, or generic GPR grammar is
             * admitted through the direct-SIMD front door. */
            if (form.operand_count != token_count)
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            u32 token_index = 0;
            for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
            {
                BusterA64SemanticOperand operand = {0};
                if (!buster_a64_semantic_operand(form.operand_first + operand_index, &operand) || token_index >= token_count)
                {
                    return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                }
                if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER)
                {
                    AssemblyRegister register_value = {0};
                    if (!assembly_aarch64_gpr_register_parse(tokens[token_index], &register_value) ||
                        register_value.class != ASSEMBLY_REGISTER_GPR || register_value.stack_pointer)
                    {
                        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                    }
                    bool width_w32 = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_GPR_WIDTH_W32) != 0;
                    bool width_x64 = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_GPR_WIDTH_X64) != 0;
                    u8 expected_width = width_w32 == width_x64 ? 0 : width_w32 ? 32 : 64;
                    bool zr_allowed = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_ZR_ALLOWED) != 0;
                    if (expected_width == 0 || register_value.width != expected_width ||
                        (register_value.index == 31 && !zr_allowed))
                    {
                        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                    }
                    registers[operand_index] = register_value.index;
                    arrangements[operand_index] = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID;
                    gpr_widths[operand_index] = (u8)register_value.width;
                }
                else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER)
                {
                    BusterA64DirectSIMDArrangement arrangement = spelling.arrangements[token_index];
                    if (arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID ||
                        !assembly_aarch64_direct_simd_register_parse(tokens[token_index], arrangement,
                                                                      &registers[operand_index]))
                    {
                        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                    }
                    bool scalar = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_SCALAR) != 0;
                    bool vector = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0;
                    if (!scalar || vector)
                    {
                        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                    }
                    if (((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_B8) != 0 && arrangement != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B) ||
                        ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_H16) != 0 && arrangement != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H) ||
                        ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_S32) != 0 && arrangement != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S) ||
                        ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_D64) != 0 && arrangement != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D))
                    {
                        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                    }
                    arrangements[operand_index] = arrangement;
                }
                else
                {
                    return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                }
                token_index += 1;
            }
            if (token_index != token_count)
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
        }
        if (!buster_a64_direct_simd_requirement_supported(target, spelling.requirement))
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_FEATURE;
        }
        BusterA64DirectSIMDInstruction fixed_instruction = {.row_index = row_index,
                                                            .operand_count = (u8)token_count,
                                                            .fixed_field_kind = spelling.fixed_field_kind,
                                                            .fixed_field_value = spelling.fixed_field_value};
        for (u32 operand_index = 0; operand_index < token_count; operand_index += 1)
        {
            if (gpr_widths[operand_index] != 0)
            {
                fixed_instruction.operands[operand_index] =
                    buster_a64_direct_simd_value_gpr(registers[operand_index], gpr_widths[operand_index],
                                                     registers[operand_index] == 31);
            }
            else
            {
                BusterA64DirectSIMDArrangement arrangement = arrangements[operand_index];
                bool scalar = arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B ||
                              arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H ||
                              arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S ||
                              arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D;
                fixed_instruction.operands[operand_index] =
                    scalar ? buster_a64_direct_simd_value_scalar(registers[operand_index], arrangement)
                           : buster_a64_direct_simd_value_vector(registers[operand_index], arrangement);
            }
            if (fixed_instruction.operands[operand_index].kind == BUSTER_A64_SEMANTIC_VM_VALUE_INVALID)
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
        }
        u32 encoded_word = 0;
        if (buster_a64_direct_simd_encode(target, &fixed_instruction, &encoded_word) != BUSTER_A64_DIRECT_SIMD_STATUS_OK)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_MATCH;
    }
    BusterA64SemanticForm form = {0};
    if (!buster_a64_semantic_form(row.semantic_form_id, &form) || form.operand_count > BUSTER_A64_DIRECT_SIMD_MAX_OPERANDS)
    {
        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
    }
    bool has_list = false;
    u32 list_operand_count = 0;
    u32 index_vector_count = 0;
    u32 vector_register_count = 0;
    u32 arrangement_count = 0;
    bool list_shape_valid = true;
    for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
    {
        BusterA64SemanticOperand operand = {0};
        if (!buster_a64_semantic_operand(form.operand_first + operand_index, &operand))
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        bool list_member = operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LIST ||
                           (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LIST_MEMBER) != 0;
        bool index_vector = operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_LANE &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_INDEX_REGISTER) != 0 &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_LANE_INDEX) != 0 &&
                            (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0;
        if (list_member)
        {
            has_list = true;
            list_operand_count += 1;
        }
        else if (index_vector)
        {
            index_vector_count += 1;
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER &&
                 (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0)
        {
            vector_register_count += 1;
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_ARRANGEMENT)
        {
            arrangement_count += 1;
        }
        else
        {
            list_shape_valid = false;
        }
    }
    if (has_list)
    {
        /* The only currently admitted list-bearing direct rows are the
         * eight TBL/TBX forms.  Their public grammar is exactly
         * `<Vd>.<Ta>, { <Vn>.16B, ... }, <Vm>.<Ta>` while generated metadata
         * expands the brace list and records Vm as a lane-shaped vector. */
        if (!list_shape_valid || token_count != 3 || list_operand_count == 0 || list_operand_count > 4 || index_vector_count != 1 ||
            vector_register_count != 1 || arrangement_count != 2)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        AssemblyAarch64DirectSIMDParsedRegister destination = {0};
        AssemblyAarch64DirectSIMDParsedRegister index = {0};
        if (!assembly_aarch64_direct_simd_register_parse_any(tokens[0], &destination) || destination.prefix != 'v' ||
            (destination.arrangement != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_8B &&
             destination.arrangement != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B) ||
            !assembly_aarch64_direct_simd_list_parse(tokens[1], list_operand_count, &registers[1]) ||
            !assembly_aarch64_direct_simd_register_parse_any(tokens[2], &index) || index.prefix != 'v' ||
            index.arrangement != destination.arrangement)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        registers[0] = destination.number;
        registers[2] = index.number;
        arrangements[0] = destination.arrangement;
        arrangements[1] = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B;
        arrangements[2] = index.arrangement;
        BusterA64DirectSIMDInstruction instruction = {0};
        u8 zero_gpr_widths[4] = {0};
        if (!assembly_aarch64_direct_simd_semantic_values_build(row_index, form, registers, arrangements, conditions, zero_gpr_widths, &instruction))
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        instruction.fixed_field_kind = spelling.fixed_field_kind;
        instruction.fixed_field_value = spelling.fixed_field_value;
        if (!buster_a64_direct_simd_requirement_supported(target, spelling.requirement))
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_FEATURE;
        }
        u32 encoded_word = 0;
        if (buster_a64_direct_simd_encode(target, &instruction, &encoded_word) != BUSTER_A64_DIRECT_SIMD_STATUS_OK)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_MATCH;
    }
    u32 source_count = 0;
    u32 token_index = 0;
    u32 gpr_source_count = 0;
    u32 gpr_width_selector_count = 0;
    for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
    {
        BusterA64SemanticOperand operand = {0};
        if (!buster_a64_semantic_operand(form.operand_first + operand_index, &operand))
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        if (operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER &&
            operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_ARRANGEMENT &&
            operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_WIDTH_SELECTOR &&
            operand.kind != BUSTER_A64_SEMANTIC_OPERAND_SIMD_PREFIX_SELECTOR &&
            operand.kind != BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER &&
            operand.kind != BUSTER_A64_SEMANTIC_OPERAND_GPR_WIDTH_SELECTOR &&
            operand.kind != BUSTER_A64_SEMANTIC_OPERAND_FIXED_CONSTANT &&
            operand.kind != BUSTER_A64_SEMANTIC_OPERAND_CONDITION)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
        if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_CONDITION)
        {
            u64 parsed_condition = 0;
            if ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_CONDITION_FIELD) == 0 || token_count <= token_index ||
                !assembly_aarch64_control_condition_parse(tokens[token_index], &parsed_condition))
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            conditions[operand_index] = (u32)parsed_condition;
            token_index += 1;
            continue;
        }
        if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER)
        {
            if (source_count >= 4 || token_count <= token_index)
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            AssemblyAarch64DirectSIMDParsedRegister parsed = {0};
            if (!assembly_aarch64_direct_simd_register_parse_any(tokens[token_index], &parsed))
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            bool scalar = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_SCALAR) != 0;
            bool vector = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_VECTOR) != 0;
            bool q = (operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_Q128) != 0;
            if ((vector && parsed.prefix != 'v') || (scalar && parsed.prefix == 'v') || (q && parsed.prefix != 'q'))
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            if (scalar)
            {
                BusterA64DirectSIMDArrangement expected = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID;
                if ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_B8) != 0)
                    expected = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B;
                else if ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_H16) != 0)
                    expected = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H;
                else if ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_S32) != 0)
                    expected = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S;
                else if ((operand.flags & BUSTER_A64_SEMANTIC_FLAG_SIMD_WIDTH_D64) != 0)
                    expected = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D;
                if (expected != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID && parsed.arrangement != expected)
                {
                    return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
                }
            }
            registers[source_count] = parsed.number;
            arrangements[source_count] = parsed.arrangement;
            source_count += 1;
            token_index += 1;
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER)
        {
            if (source_count >= 4 || token_count <= token_index || gpr_source_count != 0)
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            AssemblyRegister parsed = {0};
            if (!assembly_aarch64_gpr_register_parse(tokens[token_index], &parsed) || parsed.class != ASSEMBLY_REGISTER_GPR ||
                parsed.stack_pointer)
            {
                return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
            }
            registers[source_count] = parsed.index;
            arrangements[source_count] = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID;
            gpr_widths[source_count] = (u8)parsed.width;
            source_count += 1;
            gpr_source_count += 1;
            token_index += 1;
        }
        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_WIDTH_SELECTOR)
        {
            gpr_width_selector_count += 1;
        }
    }
    if (token_index != token_count || gpr_source_count != gpr_width_selector_count)
    {
        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
    }
    if (gpr_source_count != 0)
    {
        /* The generated DUP transform links the vector arrangement to the
         * GPR width selector: every legal byte/halfword/single arrangement
         * uses W, while 2D uses X.  Keep this compatibility check semantic
         * and independent of mnemonic spelling; the generated encoder then
         * validates the actual imm5/Q field mapping. */
        BusterA64DirectSIMDArrangement vector_arrangement = BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID;
        for (u32 source_index = 0; source_index < source_count; source_index += 1)
        {
            if (arrangements[source_index] != BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_INVALID)
            {
                vector_arrangement = arrangements[source_index];
                break;
            }
        }
        bool vector_arrangement_valid = vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_8B ||
                                        vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_16B ||
                                        vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4H ||
                                        vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_8H ||
                                        vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2S ||
                                        vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_4S ||
                                        vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D;
        u8 expected_width = vector_arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_2D ? 64 : 32;
        u32 gpr_source_index = UINT32_MAX;
        for (u32 source_index = 0; source_index < source_count; source_index += 1)
        {
            if (gpr_widths[source_index] != 0)
            {
                gpr_source_index = source_index;
                break;
            }
        }
        if (!vector_arrangement_valid || gpr_source_index == UINT32_MAX || gpr_widths[gpr_source_index] != expected_width)
        {
            return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
        }
    }
    BusterA64DirectSIMDInstruction instruction = {0};
    if (!assembly_aarch64_direct_simd_semantic_values_build(row_index, form, registers, arrangements, conditions, gpr_widths, &instruction))
    {
        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
    }
    instruction.fixed_field_kind = spelling.fixed_field_kind;
    instruction.fixed_field_value = spelling.fixed_field_value;
    if (!buster_a64_direct_simd_requirement_supported(target, spelling.requirement))
    {
        return ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_FEATURE;
    }
    u32 encoded_word = 0;
    BusterA64DirectSIMDStatus status = buster_a64_direct_simd_encode(target, &instruction, &encoded_word);
    AssemblyAarch64DirectSIMDCandidateResult result;
    if (status != BUSTER_A64_DIRECT_SIMD_STATUS_OK)
    {
        result = ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_INVALID;
    }
    else
    {
        result = ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_MATCH;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_instruction_parse_generated(
    AssemblyBuilder* builder, String8 mnemonic, String8 operands_text, AssemblyInstruction* instruction,
    u32 spelling_first, u32 spelling_count, u32 line, u32 column)
{
    if (!builder || !instruction || spelling_count == 0 || spelling_count > BUSTER_ARRAY_LENGTH(assembly_aarch64_direct_simd_spellings))
    {
        return false;
    }
    String8 tokens[4] = {0};
    u32 token_count = 0;
    u64 cursor = 0;
    while (cursor < operands_text.length)
    {
        if (token_count >= BUSTER_ARRAY_LENGTH(tokens))
        {
            return false;
        }
        String8 token = {0};
        if (assembly_operand_split_next(operands_text, &cursor, &token) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
        {
            return false;
        }
        tokens[token_count++] = assembly_trim(token);
    }
    u32 match_count = 0;
    u32 match_row_index = UINT32_MAX;
    u32 match_registers[4] = {0};
    BusterA64DirectSIMDArrangement match_arrangements[4] = {0};
    u32 match_conditions[4] = {0};
    u8 match_gpr_widths[4] = {0};
    u8 match_fixed_field_kind = BUSTER_A64_DIRECT_SIMD_FIXED_FIELD_NONE;
    u8 match_fixed_field_value = 0;
    bool feature_missing = false;
    for (u32 offset = 0; offset < spelling_count; offset += 1)
    {
        u32 spelling_index = spelling_first + offset;
        if (spelling_index >= BUSTER_ARRAY_LENGTH(assembly_aarch64_direct_simd_spellings))
        {
            return false;
        }
        AssemblyAarch64DirectSIMDSpelling spelling = assembly_aarch64_direct_simd_spellings[spelling_index];
        if (!assembly_word_equal(mnemonic, spelling.mnemonic) || token_count != spelling.operand_count)
        {
            continue;
        }
        u32 row_index = UINT32_MAX;
        if (!buster_a64_direct_simd_find_source_digest(spelling.source_digest, &row_index))
        {
            continue;
        }
        u32 registers[4] = {0};
        BusterA64DirectSIMDArrangement arrangements[4] = {0};
        u32 conditions[4] = {0};
        u8 gpr_widths[4] = {0};
        AssemblyAarch64DirectSIMDCandidateResult candidate = assembly_aarch64_direct_simd_generated_candidate(
            builder->target, tokens, token_count, spelling, row_index, registers, arrangements, conditions, gpr_widths);
        if (candidate == ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_FEATURE)
        {
            feature_missing = true;
            continue;
        }
        if (candidate != ASSEMBLY_AARCH64_DIRECT_SIMD_CANDIDATE_MATCH)
        {
            continue;
        }
        match_count += 1;
        if (match_count == 1)
        {
            match_row_index = row_index;
            memcpy(match_registers, registers, sizeof(match_registers));
            memcpy(match_arrangements, arrangements, sizeof(match_arrangements));
            memcpy(match_conditions, conditions, sizeof(match_conditions));
            memcpy(match_gpr_widths, gpr_widths, sizeof(match_gpr_widths));
            match_fixed_field_kind = spelling.fixed_field_kind;
            match_fixed_field_value = spelling.fixed_field_value;
        }
    }
    if (match_count != 1)
    {
        if (feature_missing && match_count == 0)
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                S8("instruction requires an enabled AArch64 target feature"));
        }
        return false;
    }
    instruction->aarch64_direct_simd_row_index = match_row_index;
    instruction->operand_count = (u8)token_count;
    instruction->aarch64_direct_simd_fixed_field_kind = match_fixed_field_kind;
    instruction->aarch64_direct_simd_fixed_field_value = match_fixed_field_value;
    for (u32 index = 0; index < token_count; index += 1)
    {
        instruction->aarch64_direct_simd_registers[index] = (u8)match_registers[index];
        instruction->aarch64_direct_simd_arrangements[index] = (u8)match_arrangements[index];
        instruction->aarch64_direct_simd_conditions[index] = (u8)match_conditions[index];
        instruction->aarch64_direct_simd_gpr_widths[index] = match_gpr_widths[index];
    }
    instruction->size = 4;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_direct_simd_instruction_parse(AssemblyBuilder* builder, String8 mnemonic,
                                                                         String8 operands_text, AssemblyInstruction* instruction,
                                                                         u32 row_index, u8 operand_count, u8 requirement,
                                                                         BusterA64DirectSIMDArrangement const* arrangements,
                                                                         u32 line, u32 column)
{
    if (!builder || !instruction)
    {
        return false;
    }
    String8 tokens[4] = {0};
    u32 token_count = 0;
    u64 cursor = 0;
    while (cursor < operands_text.length)
    {
        if (token_count >= BUSTER_ARRAY_LENGTH(tokens))
        {
            return false;
        }
        String8 token = {0};
        if (assembly_operand_split_next(operands_text, &cursor, &token) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
        {
            return false;
        }
        tokens[token_count++] = assembly_trim(token);
    }
    if (token_count != operand_count || operand_count < 2 || operand_count > 4)
    {
        return false;
    }
    u32 registers[4] = {0};
    for (u32 index = 0; index < operand_count; index += 1)
    {
        if (!assembly_aarch64_direct_simd_register_parse(tokens[index], arrangements[index], &registers[index]))
        {
            return false;
        }
    }
    if (!buster_a64_direct_simd_requirement_supported(builder->target, requirement))
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                            S8("instruction requires an enabled AArch64 target feature"));
        return false;
    }
    instruction->aarch64_direct_simd_row_index = row_index;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        instruction->aarch64_direct_simd_registers[index] = (u8)registers[index];
        instruction->aarch64_direct_simd_arrangements[index] = (u8)arrangements[index];
    }
    instruction->operand_count = operand_count;
    instruction->size = 4;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_control_pc_operand(AssemblyBuilder* builder, String8 text,
                                                              BusterAarch64ControlOperandValue* value,
                                                              AssemblyExpression* expression)
{
    if (!builder || !value || !expression || !assembly_expression_parse(builder, assembly_trim(text), expression))
    {
        return false;
    }
    *value = (BusterAarch64ControlOperandValue){
        .kind = BUSTER_AARCH64_CONTROL_OPERAND_PC_RELATIVE,
        .width = 64,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_control_register_operand(String8 text, BusterAarch64ControlOperandValue* value)
{
    AssemblyRegister reg = {0};
    if (!value || !assembly_aarch64_gpr_register_parse(assembly_trim(text), &reg))
    {
        return false;
    }
    *value = (BusterAarch64ControlOperandValue){
        .value = reg.index,
        .kind = BUSTER_AARCH64_CONTROL_OPERAND_REGISTER,
        .width = (u8)reg.width,
        .register31_role = reg.index == 31 ? (reg.stack_pointer ? BUSTER_AARCH64_CONTROL_REGISTER31_SP
                                                                  : BUSTER_AARCH64_CONTROL_REGISTER31_ZR)
                                          : BUSTER_AARCH64_CONTROL_REGISTER31_NONE,
        .register_class = BUSTER_AARCH64_CONTROL_REGISTER_CLASS_GPR,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_control_immediate(AssemblyBuilder* builder, String8 text, u8 width,
                                                             BusterAarch64ControlOperandValue* value)
{
    u64 immediate = 0;
    text = assembly_trim(text);
    if (!text.length || text.pointer[0] != '#' || !assembly_aarch64_scalar_constant(builder, text, &immediate) ||
        immediate > (u64)INT64_MAX || !value)
    {
        return false;
    }
    *value = (BusterAarch64ControlOperandValue){
        .value = (s64)immediate,
        .kind = BUSTER_AARCH64_CONTROL_OPERAND_IMMEDIATE,
        .width = width,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_immediate(AssemblyBuilder* builder, String8 text, u32 maximum, u32* value)
{
    u64 parsed = 0;
    text = assembly_trim(text);
    if (!value || !text.length || text.pointer[0] != '#' || !assembly_aarch64_scalar_constant(builder, text, &parsed) || parsed > maximum)
    {
        return false;
    }
    *value = (u32)parsed;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_c_register(String8 text, u32* value)
{
    text = assembly_trim(text);
    if (!value || text.length < 2 || (text.pointer[0] != 'c' && text.pointer[0] != 'C'))
    {
        return false;
    }
    u32 parsed = 0;
    for (u64 index = 1; index < text.length; index += 1)
    {
        char8 digit = text.pointer[index];
        if (digit < '0' || digit > '9' || parsed > (UINT32_MAX - (u32)(digit - '0')) / 10u)
        {
            return false;
        }
        parsed = parsed * 10u + (u32)(digit - '0');
    }
    if (parsed > 15)
    {
        return false;
    }
    *value = parsed;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_option(String8 text, u32* value)
{
    static String8 const names[] = {
        S8_INITIALIZER("oshst"), S8_INITIALIZER("oshld"), S8_INITIALIZER("osh"), S8_INITIALIZER("nshst"),
        S8_INITIALIZER("nshld"), S8_INITIALIZER("nsh"), S8_INITIALIZER("ishst"), S8_INITIALIZER("ishld"),
        S8_INITIALIZER("ish"), S8_INITIALIZER("st"), S8_INITIALIZER("ld"), S8_INITIALIZER("sy"),
    };
    static u8 const values[] = {2, 1, 3, 6, 5, 7, 10, 9, 11, 14, 13, 15};
    if (value)
    {
        text = assembly_trim(text);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(names); index += 1)
        {
            if (assembly_word_equal(text, names[index]))
            {
                *value = values[index];
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_pstate(String8 text, u32* op2, u32* crm, u32* op1)
{
    typedef struct A64PStateName A64PStateName;
    struct A64PStateName { String8 name; u8 op2; u8 selector_crm; u8 op1; };
    static A64PStateName const names[] = {
        {S8_INITIALIZER("spsel"), 5, 0, 0}, {S8_INITIALIZER("daifset"), 6, 0, 3},
        {S8_INITIALIZER("daifclr"), 6, 1, 3}, {S8_INITIALIZER("pan"), 4, 4, 0},
        {S8_INITIALIZER("uao"), 4, 3, 0}, {S8_INITIALIZER("ssbs"), 6, 2, 3},
        {S8_INITIALIZER("dit"), 6, 3, 3}, {S8_INITIALIZER("tco"), 6, 4, 3},
    };
    if (op2 && crm && op1)
    {
        text = assembly_trim(text);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(names); index += 1)
        {
            if (assembly_word_equal(text, names[index].name))
            {
                *op2 = names[index].op2;
                *crm = names[index].selector_crm;
                *op1 = names[index].op1;
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_raw_decimal(String8 text, u64* cursor, u32 maximum, u32* value)
{
    if (!cursor || !value || *cursor >= text.length)
    {
        return false;
    }
    u64 start = *cursor;
    u32 parsed = 0;
    while (*cursor < text.length)
    {
        char8 digit = text.pointer[*cursor];
        if (digit < '0' || digit > '9')
        {
            break;
        }
        if (parsed > (UINT32_MAX - (u32)(digit - '0')) / 10u)
        {
            return false;
        }
        parsed = parsed * 10u + (u32)(digit - '0');
        *cursor += 1;
    }
    if (*cursor == start || parsed > maximum)
    {
        return false;
    }
    *value = parsed;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_raw_reg_encoding(String8 text, u16* packed)
{
    if (!packed || !text.pointer || !text.length)
    {
        return false;
    }
    text = assembly_trim(text);
    if (text.length < 4 || (text.pointer[0] != 's' && text.pointer[0] != 'S') ||
        (text.pointer[1] != '2' && text.pointer[1] != '3') || text.pointer[2] != '_')
    {
        return false;
    }
    u32 op0 = (u32)(text.pointer[1] - '0');
    u32 op1 = 0, crn = 0, crm = 0, op2 = 0;
    u64 cursor = 3;
    if (!assembly_aarch64_system_raw_decimal(text, &cursor, 7, &op1) || cursor >= text.length || text.pointer[cursor++] != '_' ||
        cursor >= text.length || (text.pointer[cursor] != 'c' && text.pointer[cursor] != 'C'))
    {
        return false;
    }
    cursor += 1;
    if (!assembly_aarch64_system_raw_decimal(text, &cursor, 15, &crn) || cursor >= text.length || text.pointer[cursor++] != '_' ||
        cursor >= text.length || (text.pointer[cursor] != 'c' && text.pointer[cursor] != 'C'))
    {
        return false;
    }
    cursor += 1;
    if (!assembly_aarch64_system_raw_decimal(text, &cursor, 15, &crm) || cursor >= text.length || text.pointer[cursor++] != '_')
    {
        return false;
    }
    if (!assembly_aarch64_system_raw_decimal(text, &cursor, 7, &op2) || cursor != text.length)
    {
        return false;
    }
    u16 value = (u16)((op0 << 14) | (op1 << 11) | (crn << 7) | (crm << 3) | op2);
    if (op0 < 2 || op0 > 3 || value == UINT16_C(0xffff))
    {
        return false;
    }
    *packed = value;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_reg_encoding(String8 text, bool read, u16* packed)
{
    if (!packed)
    {
        return false;
    }
    text = assembly_trim(text);
    if (!assembly_aarch64_system_raw_reg_encoding(text, packed))
    {
        Aarch64SystemRegisterLookup lookup = {0};
        if (!aarch64_system_register_lookup_name(text, &lookup) ||
            (read ? !(lookup.mode & AARCH64_SYSTEM_REGISTER_MODE_READ) : !(lookup.mode & AARCH64_SYSTEM_REGISTER_MODE_WRITE)))
        {
            return false;
        }
        *packed = lookup.packed_encoding;
    }

    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_set_field(BusterAarch64SystemInstruction* instruction, u32 row, u32 field,
                                                            s64 value, u8 kind, u8 width)
{
    BusterAarch64SystemFieldSchema schema = {0};
    if (!instruction || !buster_aarch64_system_semantic_field(row, field, &schema) || schema.kind != kind || schema.width != width)
    {
        return false;
    }
    instruction->fields[field] = (BusterAarch64SystemOperandValue){.value = value, .kind = kind, .width = width};
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_instruction_parse(AssemblyBuilder* builder, String8 mnemonic, String8 operands_text,
                                                                    AssemblyInstruction* instruction, u32 row)
{
    if (!builder || !instruction)
    {
        return false;
    }
    String8 tokens[ASSEMBLY_MAX_OPERANDS] = {0};
    u32 token_count = 0;
    u64 cursor = 0;
    while (cursor < operands_text.length)
    {
        if (token_count >= BUSTER_ARRAY_LENGTH(tokens))
        {
            return false;
        }
        String8 token = {0};
        if (assembly_operand_split_next(operands_text, &cursor, &token) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
        {
            return false;
        }
        tokens[token_count++] = assembly_trim(token);
    }
    if (row == UINT32_MAX && assembly_word_equal(mnemonic, S8("msr")))
    {
        if (!token_count)
        {
            return false;
        }
        u32 op2 = 0, selector_crm = 0, op1 = 0;
        row = assembly_aarch64_system_pstate(tokens[0], &op2, &selector_crm, &op1) ? BUSTER_AARCH64_SYSTEM_FORM_MSR_PSTATE
                                                                                     : BUSTER_AARCH64_SYSTEM_FORM_MSR;
    }
    if (row >= buster_aarch64_system_semantic_count())
    {
        return false;
    }
    BusterAarch64SystemSemanticRecord metadata = {0};
    if (!buster_aarch64_system_semantic_row(row, &metadata))
    {
        return false;
    }
    BusterAarch64SystemInstruction candidate = {.row = (u16)row, .field_count = metadata.field_count};
    for (u32 field = 0; field < metadata.field_count; field += 1)
    {
        BusterAarch64SystemFieldSchema schema = {0};
        if (!buster_aarch64_system_semantic_field(row, field, &schema))
        {
            return false;
        }
        candidate.fields[field] = (BusterAarch64SystemOperandValue){.kind = schema.kind, .width = schema.width};
    }
    u32 value = 0;
    AssemblyRegister reg = {0};
    if (row == BUSTER_AARCH64_SYSTEM_FORM_MRS || row == BUSTER_AARCH64_SYSTEM_FORM_MSR)
    {
        bool read = row == BUSTER_AARCH64_SYSTEM_FORM_MRS;
        u32 register_token = read ? 0u : 1u;
        u32 system_token = read ? 1u : 0u;
        if (token_count != 2 || !assembly_aarch64_gpr_register_parse(tokens[register_token], &reg) || reg.width != 64 ||
            !assembly_aarch64_system_reg_encoding(tokens[system_token], read, &instruction->aarch64_system_register_encoding))
        {
            return false;
        }
        u16 packed = instruction->aarch64_system_register_encoding;
        u32 op0 = (packed >> 14) & 3u, op1 = (packed >> 11) & 7u, crn = (packed >> 7) & 15u, crm = (packed >> 3) & 15u, op2 = packed & 7u;
        if (op0 < 2 || !assembly_aarch64_system_set_field(&candidate, row, 0, reg.index, BUSTER_AARCH64_SYSTEM_FIELD_REGISTER, 5) ||
            !assembly_aarch64_system_set_field(&candidate, row, 1, op2, BUSTER_AARCH64_SYSTEM_FIELD_OP2, 3) ||
            !assembly_aarch64_system_set_field(&candidate, row, 2, crm, BUSTER_AARCH64_SYSTEM_FIELD_CRM, 4) ||
            !assembly_aarch64_system_set_field(&candidate, row, 3, crn, BUSTER_AARCH64_SYSTEM_FIELD_CRN, 4) ||
            !assembly_aarch64_system_set_field(&candidate, row, 4, op1, BUSTER_AARCH64_SYSTEM_FIELD_OP1, 3) ||
            !assembly_aarch64_system_set_field(&candidate, row, 5, op0 - 2u, BUSTER_AARCH64_SYSTEM_FIELD_O0, 1))
        {
            return false;
        }
    }
    else if (row == BUSTER_AARCH64_SYSTEM_FORM_MSR_PSTATE)
    {
        u32 op2 = 0, selector_crm = 0, op1 = 0;
        if (token_count != 2 || !assembly_aarch64_system_pstate(tokens[0], &op2, &selector_crm, &op1) ||
            !assembly_aarch64_system_immediate(builder, tokens[1], 15, &value) ||
            !assembly_aarch64_system_set_field(&candidate, row, 0, op2, BUSTER_AARCH64_SYSTEM_FIELD_OP2, 3) ||
            !assembly_aarch64_system_set_field(&candidate, row, 1, value, BUSTER_AARCH64_SYSTEM_FIELD_CRM, 4) ||
            !assembly_aarch64_system_set_field(&candidate, row, 2, op1, BUSTER_AARCH64_SYSTEM_FIELD_OP1, 3))
        {
            return false;
        }
        candidate.fields[0].value = op2;
        candidate.fields[1].value = value;
        candidate.fields[2].value = op1;
        // The XML selector CRM is a representative field for the named pstate;
        // the source #imm is the architectural CRm value that must be encoded.
        BUSTER_UNUSED(selector_crm);
    }
    else if (row == BUSTER_AARCH64_SYSTEM_FORM_SYS)
    {
        u32 op1 = 0, op2 = 0, crn = 0, crm = 0;
        if ((token_count != 4 && token_count != 5) || !assembly_aarch64_system_immediate(builder, tokens[0], 7, &op1) ||
            !assembly_aarch64_system_c_register(tokens[1], &crn) || !assembly_aarch64_system_c_register(tokens[2], &crm) ||
            !assembly_aarch64_system_immediate(builder, tokens[3], 7, &op2))
        {
            return false;
        }
        candidate.fields[1].value = op2;
        candidate.fields[2].value = crm;
        candidate.fields[3].value = crn;
        candidate.fields[4].value = op1;
        if (token_count == 5)
        {
            if (!assembly_aarch64_gpr_register_parse(tokens[4], &reg) || reg.width != 64)
            {
                return false;
            }
            candidate.fields[0].value = reg.index;
        }
        else
        {
            candidate.fields[0].value = 31;
            candidate.defaulted_mask = 1;
        }
    }
    else if (row == BUSTER_AARCH64_SYSTEM_FORM_SYSL)
    {
        u32 op1 = 0, op2 = 0, crn = 0, crm = 0;
        if (token_count != 5 || !assembly_aarch64_gpr_register_parse(tokens[0], &reg) || reg.width != 64 ||
            !assembly_aarch64_system_immediate(builder, tokens[1], 7, &op1) || !assembly_aarch64_system_c_register(tokens[2], &crn) ||
            !assembly_aarch64_system_c_register(tokens[3], &crm) || !assembly_aarch64_system_immediate(builder, tokens[4], 7, &op2))
        {
            return false;
        }
        candidate.fields[0].value = reg.index;
        candidate.fields[1].value = op2;
        candidate.fields[2].value = crm;
        candidate.fields[3].value = crn;
        candidate.fields[4].value = op1;
    }
    else if (row == BUSTER_AARCH64_SYSTEM_FORM_DMB || row == BUSTER_AARCH64_SYSTEM_FORM_DSB || row == BUSTER_AARCH64_SYSTEM_FORM_ISB)
    {
        bool named_option = assembly_aarch64_system_option(tokens[0], &value);
        bool immediate_option = !named_option && assembly_aarch64_system_immediate(builder, tokens[0], 15, &value);
        if (token_count != 1 || (!named_option && !immediate_option) ||
            (row == BUSTER_AARCH64_SYSTEM_FORM_ISB && named_option && value != 15))
        {
            return false;
        }
        candidate.fields[0].value = value;
    }
    else if (row == BUSTER_AARCH64_SYSTEM_FORM_CLREX)
    {
        if (token_count > 1 || (token_count && (!assembly_aarch64_system_immediate(builder, tokens[0], 15, &value))))
        {
            return false;
        }
        candidate.fields[0].value = token_count ? value : 15;
        candidate.defaulted_mask = token_count ? 0 : 1;
    }
    else if (row == BUSTER_AARCH64_SYSTEM_FORM_HINT)
    {
        if (token_count != 1 || !assembly_aarch64_system_immediate(builder, tokens[0], 31, &value))
        {
            return false;
        }
        candidate.fields[0].value = value & 7u;
        candidate.fields[1].value = value >> 3;
    }
    else
    {
        if (token_count != 1 || !assembly_aarch64_system_immediate(builder, tokens[0], 65535, &value))
        {
            return false;
        }
        candidate.fields[0].value = value;
    }
    instruction->aarch64_system_instruction = candidate;
    instruction->aarch64_system_register_operation = row == BUSTER_AARCH64_SYSTEM_FORM_MRS ? ASSEMBLY_AARCH64_SYSTEM_REGISTER_MRS
                                                 : row == BUSTER_AARCH64_SYSTEM_FORM_MSR ? ASSEMBLY_AARCH64_SYSTEM_REGISTER_MSR
                                                                                          : ASSEMBLY_AARCH64_SYSTEM_REGISTER_MSR;
    instruction->aarch64_system_instruction.field_count = metadata.field_count;
    instruction->operand_count = metadata.field_count;
    instruction->size = 4;
    u32 ignored = 0;
    bool result;
    if (!buster_aarch64_system_semantic_encode(builder->target, &candidate, &ignored))
    {
        result = false;
    }
    else
    {
        result = true;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_system_register_instruction_parse(String8 mnemonic, String8 operands_text,
                                                                             AssemblyInstruction* instruction)
{
    String8 tokens[2] = {0};
    String8 trimmed_operands = assembly_trim(operands_text);
    u32 token_count = 0;
    u64 cursor = 0;
    bool valid = instruction &&
                 (assembly_word_equal(mnemonic, S8("mrs")) || assembly_word_equal(mnemonic, S8("msr"))) &&
                 trimmed_operands.length && trimmed_operands.pointer[trimmed_operands.length - 1] != ',';
    while (valid && cursor < operands_text.length)
    {
        String8 token = {0};
        valid = token_count < BUSTER_ARRAY_LENGTH(tokens) &&
                assembly_operand_split_next(operands_text, &cursor, &token) == ASSEMBLY_OPERAND_SPLIT_SUCCESS;
        if (valid)
        {
            tokens[token_count++] = assembly_trim(token);
        }
    }

    bool read = assembly_word_equal(mnemonic, S8("mrs"));
    u32 register_token = read ? 0u : 1u;
    u32 system_token = read ? 1u : 0u;
    AssemblyRegister reg = {0};
    Aarch64SystemRegisterLookup lookup = {0};
    valid = valid && token_count == BUSTER_ARRAY_LENGTH(tokens) &&
            assembly_aarch64_gpr_register_parse(tokens[register_token], &reg) && reg.width == 64 && !reg.stack_pointer &&
            (assembly_word_equal(tokens[system_token], S8("fpsr")) || assembly_word_equal(tokens[system_token], S8("fpcr"))) &&
            aarch64_system_register_lookup_name(tokens[system_token], &lookup) &&
            (read ? (lookup.mode & AARCH64_SYSTEM_REGISTER_MODE_READ) : (lookup.mode & AARCH64_SYSTEM_REGISTER_MODE_WRITE));
    if (valid)
    {
        instruction->aarch64_system_register_encoding = lookup.packed_encoding;
        instruction->aarch64_system_register_operation = read ? ASSEMBLY_AARCH64_SYSTEM_REGISTER_MRS
                                                               : ASSEMBLY_AARCH64_SYSTEM_REGISTER_MSR;
        instruction->aarch64_system_register_rt = reg.index;
        instruction->operand_count = 2;
        instruction->size = 4;
    }
    return valid;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_control_row_select(String8 mnemonic, BusterAarch64ControlInstruction candidate,
                                                              u32* row_index)
{
    if (row_index)
    {
        bool conditional = mnemonic.length > 2 && assembly_word_equal(string_slice(mnemonic, 0, 2), S8("b."));
        for (u32 index = 0; index < buster_aarch64_control_semantic_count(); index += 1)
        {
            BusterAarch64ControlSemanticRecord row = {0};
            String8 row_mnemonic = {0};
            if (!buster_aarch64_control_semantic_row(index, &row) ||
                !buster_aarch64_control_semantic_string(row.mnemonic, &row_mnemonic))
            {
                continue;
            }
            if (row.form == BUSTER_AARCH64_CONTROL_FORM_B || row.form == BUSTER_AARCH64_CONTROL_FORM_BL ||
                row.form == BUSTER_AARCH64_CONTROL_FORM_RET)
            {
                continue;
            }
            if ((conditional && row.form != BUSTER_AARCH64_CONTROL_FORM_B_COND) ||
                (!conditional && !assembly_word_equal(mnemonic, row_mnemonic)))
            {
                continue;
            }
            candidate.row = (u16)index;
            u32 ignored_word = 0;
            if (buster_aarch64_control_semantic_encode(&candidate, &ignored_word))
            {
                *row_index = index;
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_inline_private_label_name(String8 name)
{
    String8 prefix = S8(".Lbuster.inline.asm.");
    return name.length > prefix.length && !memcmp(name.pointer, prefix.pointer, prefix.length);
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_private_short_control(AssemblyBuilder* builder, u32 row_index, u8 expression_mask,
                                                                 AssemblyExpression const expressions[4], u8* operand_out)
{
    BusterAarch64ControlSemanticRecord row = {0};
    AssemblyRelocationKind kind = ASSEMBLY_RELOCATION_COUNT;
    bool private_label = false;
    if (builder && builder->private_inline_labels && expressions && buster_aarch64_control_semantic_row(row_index, &row))
    {
        if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_B_COND19) kind = ASSEMBLY_RELOCATION_AARCH64_CONDBR19;
        else if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_COMPARE19) kind = ASSEMBLY_RELOCATION_AARCH64_COMPAREBR19;
        else if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_TEST14) kind = ASSEMBLY_RELOCATION_AARCH64_TESTBR14;
        for (u32 operand_index = 0; !private_label && kind != ASSEMBLY_RELOCATION_COUNT && operand_index < 4; operand_index += 1)
        {
            AssemblyExpression expression = expressions[operand_index];
            bool valid_symbol = expression.has_symbol && expression.symbol < builder->result.symbol_count;
            String8 symbol_name = valid_symbol
                                      ? builder->result.symbols[expression.symbol].name
                                      : (String8){0};
            private_label = (expression_mask & (u8)(1u << operand_index)) &&
                            valid_symbol && !builder->result.symbols[expression.symbol].defined &&
                            assembly_inline_private_label_name(symbol_name);
            if (private_label && operand_out)
            {
                *operand_out = (u8)operand_index;
            }
        }
    }
    return private_label;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_expand_private_short_branch_word(AssemblyRelocationKind kind, u32 word, u32 words[2])
{
    bool valid = words && (kind == ASSEMBLY_RELOCATION_AARCH64_CONDBR19 ||
                           kind == ASSEMBLY_RELOCATION_AARCH64_COMPAREBR19 ||
                           kind == ASSEMBLY_RELOCATION_AARCH64_TESTBR14);
    if (valid && kind == ASSEMBLY_RELOCATION_AARCH64_CONDBR19)
    {
        valid = (word & UINT32_C(0xff000010)) == UINT32_C(0x54000000);
        if ((word & 0xfu) < 14u)
        {
            word = (word & ~UINT32_C(0x00ffffe0)) | (UINT32_C(2) << 5);
            word ^= 1u;
        }
        else
        {
            word = UINT32_C(0xd503201f);
        }
    }
    else if (valid && kind == ASSEMBLY_RELOCATION_AARCH64_COMPAREBR19)
    {
        valid = (word & UINT32_C(0x7e000000)) == UINT32_C(0x34000000);
        word = (word & ~UINT32_C(0x00ffffe0)) | (UINT32_C(2) << 5);
        word ^= UINT32_C(1) << 24;
    }
    else if (valid)
    {
        valid = (word & UINT32_C(0x7e000000)) == UINT32_C(0x36000000);
        word = (word & ~UINT32_C(0x0007ffe0)) | (UINT32_C(2) << 5);
        word ^= UINT32_C(1) << 24;
    }
    if (valid)
    {
        words[0] = word;
        words[1] = UINT32_C(0x14000000);
    }
    return valid;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_control_instruction_parse(AssemblyBuilder* builder, String8 mnemonic,
                                                                     String8 operands_text, AssemblyInstruction* instruction)
{
    if (!builder || !instruction)
    {
        return false;
    }
    String8 tokens[ASSEMBLY_MAX_OPERANDS] = {0};
    u32 token_count = 0;
    u64 cursor = 0;
    while (cursor < operands_text.length)
    {
        if (token_count >= BUSTER_ARRAY_LENGTH(tokens))
        {
            return false;
        }
        String8 token = {0};
        if (assembly_operand_split_next(operands_text, &cursor, &token) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
        {
            return false;
        }
        tokens[token_count++] = assembly_trim(token);
    }
    bool conditional = mnemonic.length > 2 && assembly_word_equal(string_slice(mnemonic, 0, 2), S8("b."));
    u64 condition = 0;
    BusterAarch64ControlInstruction candidate = {0};
    u8 expression_mask = 0;
    AssemblyExpression expressions[4] = {0};
    if (conditional)
    {
        if (token_count != 1 || !assembly_aarch64_control_condition_parse(string_slice(mnemonic, 2, mnemonic.length), &condition))
        {
            return false;
        }
        candidate.operand_count = 2;
        candidate.operands[0] = (BusterAarch64ControlOperandValue){
            .kind = BUSTER_AARCH64_CONTROL_OPERAND_PC_RELATIVE,
            .width = 64,
        };
        candidate.operands[1].kind = BUSTER_AARCH64_CONTROL_OPERAND_CONDITION;
        candidate.operands[1].width = 4;
        candidate.operands[1].value = (s64)condition;
        if (!assembly_aarch64_control_pc_operand(builder, tokens[0], &candidate.operands[0], &expressions[0]))
        {
            return false;
        }
        expression_mask = 1;
    }
    else if (assembly_word_equal(mnemonic, S8("adr")) || assembly_word_equal(mnemonic, S8("adrp")))
    {
        if (token_count != 2 || !assembly_aarch64_control_register_operand(tokens[0], &candidate.operands[0]) ||
            !assembly_aarch64_control_pc_operand(builder, tokens[1], &candidate.operands[1], &expressions[1]))
        {
            return false;
        }
        candidate.operand_count = 2;
        expression_mask = 2;
    }
    else if (assembly_word_equal(mnemonic, S8("cbz")) || assembly_word_equal(mnemonic, S8("cbnz")))
    {
        if (token_count != 2 || !assembly_aarch64_control_register_operand(tokens[0], &candidate.operands[0]) ||
            !assembly_aarch64_control_pc_operand(builder, tokens[1], &candidate.operands[1], &expressions[1]))
        {
            return false;
        }
        candidate.operand_count = 2;
        expression_mask = 2;
    }
    else if (assembly_word_equal(mnemonic, S8("tbz")) || assembly_word_equal(mnemonic, S8("tbnz")))
    {
        if (token_count != 3 || !assembly_aarch64_control_register_operand(tokens[0], &candidate.operands[0]) ||
            !assembly_aarch64_control_immediate(builder, tokens[1], 6, &candidate.operands[1]) ||
            !assembly_aarch64_control_pc_operand(builder, tokens[2], &candidate.operands[2], &expressions[2]))
        {
            return false;
        }
        candidate.operand_count = 3;
        expression_mask = 4;
    }
    else if (assembly_word_equal(mnemonic, S8("csel")) || assembly_word_equal(mnemonic, S8("csinc")) ||
             assembly_word_equal(mnemonic, S8("csinv")) || assembly_word_equal(mnemonic, S8("csneg")))
    {
        if (token_count != 4 || !assembly_aarch64_control_register_operand(tokens[0], &candidate.operands[0]) ||
            !assembly_aarch64_control_register_operand(tokens[1], &candidate.operands[1]) ||
            !assembly_aarch64_control_register_operand(tokens[2], &candidate.operands[2]) ||
            !assembly_aarch64_control_condition_parse(tokens[3], &condition))
        {
            return false;
        }
        candidate.operand_count = 4;
        candidate.operands[3].value = (s64)condition;
        candidate.operands[3].kind = BUSTER_AARCH64_CONTROL_OPERAND_CONDITION;
        candidate.operands[3].width = 4;
    }
    else if (assembly_word_equal(mnemonic, S8("ldr")) || assembly_word_equal(mnemonic, S8("ldrsw")))
    {
        if (token_count != 2 || !assembly_aarch64_control_register_operand(tokens[0], &candidate.operands[0]) ||
            !assembly_aarch64_control_pc_operand(builder, tokens[1], &candidate.operands[1], &expressions[1]))
        {
            return false;
        }
        candidate.operand_count = 2;
        expression_mask = 2;
    }
    else if (assembly_word_equal(mnemonic, S8("prfm")))
    {
        if (token_count != 2 || !assembly_aarch64_control_immediate(builder, tokens[0], 5, &candidate.operands[0]) ||
            !assembly_aarch64_control_pc_operand(builder, tokens[1], &candidate.operands[1], &expressions[1]))
        {
            return false;
        }
        candidate.operand_count = 2;
        expression_mask = 2;
    }
    else
    {
        return false;
    }
    u32 row_index = UINT32_MAX;
    if (!assembly_aarch64_control_row_select(mnemonic, candidate, &row_index))
    {
        return false;
    }
    candidate.row = (u16)row_index;
    instruction->aarch64_control_instruction = candidate;
    instruction->aarch64_control_row_index = row_index;
    instruction->aarch64_control_expression_mask = expression_mask;
    memcpy(instruction->aarch64_control_expressions, expressions, sizeof(expressions));
    instruction->operand_count = candidate.operand_count;
    instruction->aarch64_control_private_long =
        assembly_aarch64_private_short_control(builder, row_index, expression_mask, expressions,
                                               &instruction->aarch64_control_private_expression);
    instruction->size = instruction->aarch64_control_private_long ? 8 : 4;
    return true;
}

BUSTER_GLOBAL_LOCAL void assembly_instruction_parse_handwritten(AssemblyBuilder* builder, String8 statement, u32 line, u32 column,
                                                                 u64 offset, Target target, AssemblySyntax syntax)
{
    String8 full_statement = assembly_trim(statement);
    u8 lock_prefix = false;
    u64 lock_end = 0;
    while (lock_end < statement.length && !assembly_space(statement.pointer[lock_end]))
    {
        lock_end += 1;
    }
    if (target.cpu_arch == CPU_ARCH_X86_64 && lock_end < statement.length &&
        assembly_word_equal(string_slice(statement, 0, lock_end), S8("lock")))
    {
        lock_prefix = true;
        statement = assembly_trim(string_slice(statement, lock_end, statement.length));
        column += (u32)lock_end;
    }
    u8 pseudo_no_flags = false;
    if (target.cpu_arch == CPU_ARCH_X86_64 && statement.length && statement.pointer[0] == '{')
    {
        u64 pseudo_end = 1;
        while (pseudo_end < statement.length && statement.pointer[pseudo_end] != '}')
        {
            pseudo_end += 1;
        }
        if (pseudo_end < statement.length && assembly_word_equal(assembly_trim(string_slice(statement, 1, pseudo_end)), S8("nf")))
        {
            pseudo_no_flags = true;
            statement = assembly_trim(string_slice(statement, pseudo_end + 1, statement.length));
        }
    }
    u64 mnemonic_end = 0;
    while (mnemonic_end < statement.length && !assembly_space(statement.pointer[mnemonic_end]))
    {
        mnemonic_end += 1;
    }
    String8 mnemonic = {.pointer = statement.pointer, .length = mnemonic_end};
    String8 operands = assembly_trim((String8){.pointer = statement.pointer + mnemonic_end, .length = statement.length - mnemonic_end});
    u8 leading_rounding = 0;
    u8 leading_sae = false;
    if (target.cpu_arch == CPU_ARCH_X86_64 && operands.length && operands.pointer[0] == '{')
    {
        u64 leading_end = 1;
        while (leading_end < operands.length && operands.pointer[leading_end] != '}')
        {
            leading_end += 1;
        }
        if (leading_end < operands.length)
        {
            String8 decorator = assembly_trim(string_slice(operands, 1, leading_end));
            leading_rounding = assembly_word_equal(decorator, S8("rn-sae")) ? 1
                              : assembly_word_equal(decorator, S8("rd-sae")) ? 2
                              : assembly_word_equal(decorator, S8("ru-sae")) ? 3
                              : assembly_word_equal(decorator, S8("rz-sae")) ? 4
                              : 0;
            leading_sae = assembly_word_equal(decorator, S8("sae")) || leading_rounding != 0;
            u64 after_leading = leading_end + 1;
            while (after_leading < operands.length && assembly_space(operands.pointer[after_leading]))
            {
                after_leading += 1;
            }
            if (leading_sae && after_leading < operands.length && operands.pointer[after_leading] == ',')
            {
                operands = assembly_trim(string_slice(operands, after_leading + 1, operands.length));
            }
            else
            {
                leading_rounding = 0;
                leading_sae = false;
            }
        }
    }
    AssemblyInstructionInfo info = {.opcode = ASSEMBLY_OPCODE_COUNT};
    bool fixed_spelling = false;
    if (!assembly_instruction_lookup(target, syntax, mnemonic, &info))
    {
        fixed_spelling = assembly_aarch64_fixed_instruction_lookup(target, full_statement, &info);
        if (!fixed_spelling)
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNKNOWN_INSTRUCTION, line, column, (u32)mnemonic.length, S8("unknown instruction"));
            return;
        }
    }
    if (fixed_spelling)
    {
        // A fixed spelling is matched as one complete instruction, including
        // the sole internal separator in `TSB CSYNC`; it has no operands.
        mnemonic_end = statement.length;
        mnemonic = full_statement;
        operands = (String8){0};
    }
    if (info.amd_form && !target_cpu_feature_has(target, info.amd_form->feature))
    {
        String8 feature_message = info.amd_form->feature == TARGET_CPU_FEATURE_X86_FMA4  ? S8("instruction requires the fma4 target feature")
                              : info.amd_form->feature == TARGET_CPU_FEATURE_X86_TBM    ? S8("instruction requires the tbm target feature")
                              : info.amd_form->feature == TARGET_CPU_FEATURE_X86_3DNOWA ? S8("instruction requires the 3dnowa target feature")
                              : info.amd_form->feature == TARGET_CPU_FEATURE_X86_3DNOW  ? S8("instruction requires the 3dnow target feature")
                              : info.amd_form->feature == TARGET_CPU_FEATURE_X86_LWP    ? S8("instruction requires the lwp target feature")
                              : info.amd_form->feature == TARGET_CPU_FEATURE_X86_XOP    ? S8("instruction requires the xop target feature")
                                                                                       : S8("unsupported AMD instruction feature");
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length, feature_message);
        return;
    }
    u8 no_flags_source_count = (u8)pseudo_no_flags + (u8)info.no_flags;
    if (no_flags_source_count > 1)
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column, (u32)mnemonic.length,
                            S8("duplicate APX no-flags decorator"));
        return;
    }
    if (target.cpu_arch == CPU_ARCH_X86_64 && assembly_x86_opcode_is_sse2(info.opcode) &&
        !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_SSE2))
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                            S8("instruction requires the sse2 target feature"));
        return;
    }
    if (target.cpu_arch == CPU_ARCH_X86_64 && assembly_x86_opcode_is_avx(info.opcode) &&
        !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX) &&
        !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX512F) &&
        !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_512) &&
        !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_1) &&
        !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_2))
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                            S8("instruction requires the avx target feature"));
        return;
    }
    if (target.cpu_arch == CPU_ARCH_X86_64 && info.opcode == ASSEMBLY_OPCODE_X86_FISTTP &&
        !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_SSE3))
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                            S8("instruction requires the sse3 target feature"));
        return;
    }
    TargetCpuFeature required_bit_atomic_feature = TARGET_CPU_FEATURE_NONE;
    String8 required_bit_atomic_feature_message = {0};
    if (info.opcode == ASSEMBLY_OPCODE_X86_POPCNT)
    {
        required_bit_atomic_feature = TARGET_CPU_FEATURE_X86_POPCNT;
        required_bit_atomic_feature_message = S8("instruction requires the popcnt target feature");
    }
    else if (info.opcode == ASSEMBLY_OPCODE_X86_LZCNT)
    {
        required_bit_atomic_feature = TARGET_CPU_FEATURE_X86_LZCNT;
        required_bit_atomic_feature_message = S8("instruction requires the lzcnt target feature");
    }
    else if (info.opcode == ASSEMBLY_OPCODE_X86_TZCNT)
    {
        required_bit_atomic_feature = TARGET_CPU_FEATURE_X86_BMI1;
        required_bit_atomic_feature_message = S8("instruction requires the bmi1 target feature");
    }
    else if (info.opcode == ASSEMBLY_OPCODE_X86_CMPXCHG16B)
    {
        required_bit_atomic_feature = TARGET_CPU_FEATURE_X86_CX16;
        required_bit_atomic_feature_message = S8("instruction requires the cx16 target feature");
    }
    if (required_bit_atomic_feature != TARGET_CPU_FEATURE_NONE &&
        !assembly_x86_target_has_bit_atomic_feature(target, required_bit_atomic_feature))
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                            required_bit_atomic_feature_message);
        return;
    }
    if (builder->instruction_count >= builder->instruction_capacity)
    {
        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_STATEMENT, line, column, (u32)statement.length, S8("too many statements"));
        return;
    }
    AssemblyInstruction instruction = {
        .offset = offset,
        .line = line,
        .column = column,
        .opcode = info.opcode,
        .encoding_kind = info.encoding_kind,
        .operand_count = info.operand_count,
        .condition = info.condition,
        .lock_prefix = lock_prefix,
        .no_flags = pseudo_no_flags || info.no_flags,
        .amd_mnemonic = mnemonic,
        .amd_form = info.amd_form,
        .fixed_word = info.fixed_word,
        .aarch64_direct_simd_row_index = info.aarch64_direct_simd_row_index,
    };
    bool system_register_handled = false;
    if (instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_SYSTEM_REGISTER)
    {
        system_register_handled = true;
        if (!assembly_aarch64_system_register_instruction_parse(mnemonic, operands, &instruction))
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                (u32)operands.length, S8("invalid AArch64 system-register operands"));
        }
        else
        {
            builder->instructions[builder->instruction_count++] = instruction;
        }
    }
    if (!system_register_handled && instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_SYSTEM_SEMANTICS)
    {
        if (!assembly_aarch64_system_instruction_parse(builder, mnemonic, operands, &instruction, info.aarch64_system_row_index))
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                (u32)operands.length, S8("invalid AArch64 system instruction operands"));
            return;
        }
        builder->instructions[builder->instruction_count++] = instruction;
        return;
    }
    if (!system_register_handled && instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_SCALAR_MEMORY)
    {
        if (!assembly_aarch64_scalar_memory_instruction_parse(builder, mnemonic, operands, &instruction))
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                (u32)operands.length, S8("invalid AArch64 scalar memory operands"));
            return;
        }
        builder->instructions[builder->instruction_count++] = instruction;
        return;
    }
    if (!system_register_handled && instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_M1_SCALAR_INTEGER)
    {
        if (!assembly_aarch64_scalar_instruction_parse(builder, mnemonic, operands, &instruction, line, column))
        {
            if (!builder->result.diagnostic_count || builder->result.diagnostics[builder->result.diagnostic_count - 1].line != line ||
                builder->result.diagnostics[builder->result.diagnostic_count - 1].column != column)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("invalid instruction operands"));
            }
            return;
        }
        builder->instructions[builder->instruction_count++] = instruction;
        return;
    }
    if (!system_register_handled && instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_DIRECT_SIMD)
    {
        AssemblyInstruction direct_instruction = instruction;
        u32 diagnostic_count = builder->result.diagnostic_count;
        bool parsed_direct_simd = info.aarch64_direct_simd_generated || info.aarch64_direct_simd_spelling_count > 1
            ? assembly_aarch64_direct_simd_instruction_parse_generated(
                  builder, mnemonic, operands, &direct_instruction, info.aarch64_direct_simd_spelling_first,
                  info.aarch64_direct_simd_spelling_count, line, column)
            : assembly_aarch64_direct_simd_instruction_parse(
                  builder, mnemonic, operands, &direct_instruction, info.aarch64_direct_simd_row_index, info.operand_count,
                  info.aarch64_direct_simd_requirement, info.aarch64_direct_simd_arrangements, line, column);
        if (parsed_direct_simd)
        {
            instruction = direct_instruction;
            if (!info.aarch64_direct_simd_generated && info.aarch64_direct_simd_spelling_count <= 1)
            {
                instruction.aarch64_direct_simd_fixed_field_kind = info.aarch64_direct_simd_fixed_field_kind;
                instruction.aarch64_direct_simd_fixed_field_value = info.aarch64_direct_simd_fixed_field_value;
            }
            builder->instructions[builder->instruction_count++] = instruction;
            return;
        }
        u32 direct_diagnostic_count = builder->result.diagnostic_count;
        builder->result.diagnostic_count = diagnostic_count;
        AssemblyInstruction fallback_instruction = instruction;
        if (assembly_aarch64_m1_collision_parse(builder, mnemonic, operands, &fallback_instruction, line, column))
        {
            instruction = fallback_instruction;
            builder->instructions[builder->instruction_count++] = instruction;
            return;
        }
        u32 fallback_diagnostic_count = builder->result.diagnostic_count;
        if (direct_diagnostic_count > diagnostic_count)
        {
            builder->result.diagnostic_count = direct_diagnostic_count;
        }
        else if (fallback_diagnostic_count > diagnostic_count)
        {
            builder->result.diagnostic_count = fallback_diagnostic_count;
        }
        else
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                (u32)operands.length, S8("invalid AArch64 direct SIMD instruction operands"));
        }
        return;
    }
    if (!system_register_handled && instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_CONTROL)
    {
        if (!assembly_aarch64_control_instruction_parse(builder, mnemonic, operands, &instruction))
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                (u32)operands.length, S8("invalid AArch64 control instruction operands"));
            return;
        }
        builder->instructions[builder->instruction_count++] = instruction;
        return;
    }
    if (!system_register_handled)
    {
        u8 parsed_operand_count = 0;
        u64 operand_start = 0;
        while (operand_start < operands.length && parsed_operand_count < BUSTER_ARRAY_LENGTH(instruction.operands))
        {
            u64 next_operand_start = operand_start;
            String8 text = {0};
            if (assembly_operand_split_next(operands, &next_operand_start, &text) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
            {
                break;
            }
            if (text.length >= 3 && text.pointer[0] == '{' && text.pointer[text.length - 1] == '}')
            {
                String8 decorator = assembly_trim(string_slice(text, 1, text.length - 1));
                u8 pseudo_rounding = assembly_word_equal(decorator, S8("rn-sae")) ? 1
                                   : assembly_word_equal(decorator, S8("rd-sae")) ? 2
                                   : assembly_word_equal(decorator, S8("ru-sae")) ? 3
                                   : assembly_word_equal(decorator, S8("rz-sae")) ? 4
                                                                                  : 0;
                u8 pseudo_sae = assembly_word_equal(decorator, S8("sae")) || pseudo_rounding != 0;
                if (pseudo_sae)
                {
                    AssemblyVectorForm const* pseudo_form = assembly_x86_vector_form(info.opcode);
                    u8 immediate_form = pseudo_form && (pseudo_form->flags & ASSEMBLY_VECTOR_FORM_IMMEDIATE);
                    u8 canonical_position = syntax == ASSEMBLY_SYNTAX_INTEL
                                                 ? (immediate_form ? parsed_operand_count + 1 == info.operand_count
                                                                   : parsed_operand_count == info.operand_count)
                                                 : (immediate_form && parsed_operand_count == 1);
                    if (!canonical_position || leading_sae)
                    {
                        break;
                    }
                    leading_rounding = pseudo_rounding;
                    leading_sae = true;
                    operand_start = next_operand_start;
                    continue;
                }
            }
            AssemblyOperand* operand = instruction.operands + parsed_operand_count;
            u8 branch = info.opcode == ASSEMBLY_OPCODE_X86_CALL || info.opcode == ASSEMBLY_OPCODE_X86_JMP || info.opcode == ASSEMBLY_OPCODE_X86_JCC;
            u8 indirect = syntax == ASSEMBLY_SYNTAX_ATT && branch && text.length && text.pointer[0] == '*';
            if (indirect)
            {
                text.pointer += 1;
                text.length -= 1;
            }
            if (!assembly_x86_operand_decorators_parse(&text, syntax, operand, 0))
            {
                break;
            }
            bool att_immediate = syntax == ASSEMBLY_SYNTAX_ATT && text.length && text.pointer[0] == '$';
            if (att_immediate)
            {
                text.pointer += 1;
                text.length -= 1;
            }
            if (target.cpu_arch == CPU_ARCH_AARCH64 &&
                (instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_M1_GPR ||
                 instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_GPR_ALIAS))
            {
                if (!assembly_aarch64_gpr_register_parse(text, &operand->reg))
                {
                    break;
                }
                operand->kind = ASSEMBLY_OPERAND_REGISTER;
            }
            else if (target.cpu_arch == CPU_ARCH_X86_64 && !att_immediate && assembly_register_parse(text, syntax, &operand->reg))
            {
                if (syntax == ASSEMBLY_SYNTAX_ATT && branch && !indirect)
                {
                    break;
                }
                operand->kind = ASSEMBLY_OPERAND_REGISTER;
            }
            else if (target.cpu_arch == CPU_ARCH_X86_64 && !att_immediate && assembly_x86_memory_parse(builder, text, syntax, &operand->memory) &&
                     !(branch && syntax == ASSEMBLY_SYNTAX_ATT && !indirect && operand->memory.absolute))
            {
                if (branch && syntax == ASSEMBLY_SYNTAX_ATT && !indirect)
                {
                    break;
                }
                operand->kind = ASSEMBLY_OPERAND_MEMORY;
            }
            else if (att_immediate)
            {
                if (!text.length || !assembly_expression_parse(builder, text, &operand->expression))
                {
                    break;
                }
                operand->kind = ASSEMBLY_OPERAND_EXPRESSION;
            }
            else
            {
                if (syntax != ASSEMBLY_SYNTAX_ATT && text.length && text.pointer[0] == '$')
                {
                    break;
                }
                else if (syntax == ASSEMBLY_SYNTAX_ATT && target.cpu_arch == CPU_ARCH_X86_64 && !branch)
                {
                    break;
                }
                if (!assembly_expression_parse(builder, text, &operand->expression))
                {
                    break;
                }
                operand->kind = ASSEMBLY_OPERAND_EXPRESSION;
            }
            parsed_operand_count += 1;
            operand_start = next_operand_start;
        }
        u8 valid_operand_count = target.cpu_arch == CPU_ARCH_X86_64
                                       ? assembly_x86_operand_count_valid(info.opcode, parsed_operand_count, info.operand_count)
                                       : parsed_operand_count == info.operand_count;
        if (!valid_operand_count || operand_start < operands.length)
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                (u32)operands.length, S8("invalid instruction operands"));
            return;
        }
        instruction.operand_count = parsed_operand_count;
        if (target.cpu_arch == CPU_ARCH_AARCH64 && instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_GPR_ALIAS)
        {
            AssemblyRegister destination = instruction.operands[0].reg;
            AssemblyRegister source = instruction.operands[1].reg;
            if (parsed_operand_count != 2 || destination.class != ASSEMBLY_REGISTER_GPR || source.class != ASSEMBLY_REGISTER_GPR ||
                destination.width != source.width || (destination.width != 32 && destination.width != 64) ||
                destination.stack_pointer || source.stack_pointer)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("invalid instruction operands"));
                return;
            }
        }
        else if (target.cpu_arch == CPU_ARCH_AARCH64 && instruction.encoding_kind == ASSEMBLY_ENCODING_AARCH64_M1_GPR)
        {
            A64GprOperand gpr_operands[4] = {0};
            if (parsed_operand_count > BUSTER_ARRAY_LENGTH(gpr_operands))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("invalid instruction operands"));
                return;
            }
            for (u32 operand_index = 0; operand_index < parsed_operand_count; operand_index += 1)
            {
                AssemblyOperand operand = instruction.operands[operand_index];
                if (operand.kind != ASSEMBLY_OPERAND_REGISTER || operand.reg.class != ASSEMBLY_REGISTER_GPR)
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                        (u32)operands.length, S8("invalid instruction operands"));
                    return;
                }
                gpr_operands[operand_index] = (A64GprOperand){
                    .index = operand.reg.index,
                    .width = (u8)operand.reg.width,
                    .stack_pointer = operand.reg.stack_pointer,
                };
            }
            u32 form_index = UINT32_MAX;
            if (!buster_aarch64_arm_m1_gpr_find_form(mnemonic, gpr_operands, parsed_operand_count, &form_index))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("invalid instruction operands"));
                return;
            }
            BusterAarch64ArmM1GprForm form = {0};
            if (!buster_aarch64_arm_m1_gpr_form(form_index, &form))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("invalid instruction operands"));
                return;
            }
            if (form.required_feature != TARGET_CPU_FEATURE_NONE && !target_cpu_feature_has(target, form.required_feature))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                    S8("instruction requires an enabled AArch64 target feature"));
                return;
            }
            instruction.aarch64_gpr_form_index = form_index;
        }
        if (target.cpu_arch == CPU_ARCH_X86_64 && info.amd_form && syntax == ASSEMBLY_SYNTAX_ATT)
        {
            for (u32 left = 0; left < parsed_operand_count / 2; left += 1)
            {
                AssemblyOperand temporary = instruction.operands[left];
                u32 right = parsed_operand_count - 1 - left;
                instruction.operands[left] = instruction.operands[right];
                instruction.operands[right] = temporary;
            }
        }
        else if (target.cpu_arch == CPU_ARCH_X86_64 && syntax == ASSEMBLY_SYNTAX_ATT && parsed_operand_count == 2)
        {
            AssemblyOperand temporary = instruction.operands[0];
            instruction.operands[0] = instruction.operands[1];
            instruction.operands[1] = temporary;
        }
        else if (target.cpu_arch == CPU_ARCH_X86_64 && syntax == ASSEMBLY_SYNTAX_ATT && parsed_operand_count == 3)
        {
            AssemblyVectorForm const* vector_form = assembly_x86_vector_form(instruction.opcode);
            if (vector_form && (vector_form->flags & ASSEMBLY_VECTOR_FORM_SOURCE_RM) &&
                (vector_form->flags & ASSEMBLY_VECTOR_FORM_IMMEDIATE))
            {
                AssemblyOperand immediate = instruction.operands[0];
                AssemblyOperand source = instruction.operands[1];
                AssemblyOperand destination = instruction.operands[2];
                instruction.operands[0] = destination;
                instruction.operands[1] = source;
                instruction.operands[2] = immediate;
            }
            else
            {
                AssemblyOperand destination = instruction.operands[2];
                instruction.operands[2] = instruction.operands[0];
                instruction.operands[0] = destination;
            }
        }
        if (target.cpu_arch == CPU_ARCH_X86_64)
        {
            if (syntax == ASSEMBLY_SYNTAX_ATT && parsed_operand_count == 4 && !info.amd_form)
            {
                AssemblyVectorForm const* vector_form = assembly_x86_vector_form(instruction.opcode);
                if (vector_form && (vector_form->flags & ASSEMBLY_VECTOR_FORM_MASK_DESTINATION) &&
                    (vector_form->flags & ASSEMBLY_VECTOR_FORM_IMMEDIATE))
                {
                    AssemblyOperand immediate = instruction.operands[0];
                    AssemblyOperand source_2 = instruction.operands[1];
                    AssemblyOperand source_1 = instruction.operands[2];
                    AssemblyOperand destination = instruction.operands[3];
                    instruction.operands[0] = destination;
                    instruction.operands[1] = source_1;
                    instruction.operands[2] = source_2;
                    instruction.operands[3] = immediate;
                }
                else
                {
                    AssemblyOperand source_2 = instruction.operands[0];
                    AssemblyOperand source_1 = instruction.operands[1];
                    AssemblyOperand destination = instruction.operands[2];
                    AssemblyOperand immediate = instruction.operands[3];
                    instruction.operands[0] = destination;
                    instruction.operands[1] = source_1;
                    instruction.operands[2] = source_2;
                    instruction.operands[3] = immediate;
                }
            }
            assembly_x86_x87_normalize_omitted_operands(&instruction, syntax);
            if (instruction.opcode == ASSEMBLY_OPCODE_X86_IMUL && instruction.operand_count == 2 &&
                instruction.operands[1].kind == ASSEMBLY_OPERAND_EXPRESSION)
            {
                instruction.operands[2] = instruction.operands[1];
                instruction.operands[1] = instruction.operands[0];
                instruction.operand_count = 3;
            }
            if (leading_sae)
            {
                AssemblyVectorForm const* leading_form = assembly_x86_vector_form(instruction.opcode);
                u8 leading_mask_destination = leading_form && (leading_form->flags & ASSEMBLY_VECTOR_FORM_MASK_DESTINATION);
                u8 leading_register_valid = instruction.operand_count && instruction.operands[0].kind == ASSEMBLY_OPERAND_REGISTER &&
                                            ((leading_mask_destination && instruction.operands[0].reg.class == ASSEMBLY_REGISTER_OPMASK) ||
                                             (!leading_mask_destination && assembly_x86_vector_register(instruction.operands[0].reg)));
                if (!leading_register_valid || instruction.operands[0].rounding || instruction.operands[0].sae)
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                        (u32)operands.length, S8("invalid instruction decorators"));
                    return;
                }
                instruction.operands[0].rounding = leading_rounding;
                instruction.operands[0].sae = true;
            }
        }
        if (target.cpu_arch == CPU_ARCH_X86_64 && instruction.opcode == ASSEMBLY_OPCODE_X86_MOV &&
            ((instruction.operands[0].kind == ASSEMBLY_OPERAND_REGISTER &&
              instruction.operands[0].reg.class == ASSEMBLY_REGISTER_MMX) ||
             (instruction.operands[1].kind == ASSEMBLY_OPERAND_REGISTER &&
              instruction.operands[1].reg.class == ASSEMBLY_REGISTER_MMX)))
        {
            instruction.opcode = ASSEMBLY_OPCODE_X86_MOVQ_MMX;
        }
        if (info.suffix_width)
        {
            instruction.width = info.suffix_width;
            for (u32 operand_index = 0; operand_index < instruction.operand_count; operand_index += 1)
            {
                u8 suffix_applies = true;
                if (instruction.opcode == ASSEMBLY_OPCODE_X86_LEA || assembly_x86_opcode_is_rotate(instruction.opcode) ||
                    instruction.opcode == ASSEMBLY_OPCODE_X86_MOVZX || instruction.opcode == ASSEMBLY_OPCODE_X86_MOVSX ||
                    instruction.opcode == ASSEMBLY_OPCODE_X86_MOVSXD)
                {
                    suffix_applies = operand_index == 0;
                }
                else if (instruction.opcode == ASSEMBLY_OPCODE_X86_SHLD || instruction.opcode == ASSEMBLY_OPCODE_X86_SHRD)
                {
                    suffix_applies = operand_index < 2;
                }
                else if (assembly_x86_opcode_is_shift(instruction.opcode))
                {
                    suffix_applies = operand_index + 1 < instruction.operand_count;
                }
                if (!suffix_applies)
                {
                    continue;
                }
                if (instruction.operands[operand_index].kind == ASSEMBLY_OPERAND_REGISTER && instruction.operands[operand_index].reg.width != info.suffix_width)
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                        (u32)operands.length, S8("register width does not match mnemonic suffix"));
                    return;
                }
                if (instruction.operands[operand_index].kind == ASSEMBLY_OPERAND_MEMORY)
                {
                    if (instruction.operands[operand_index].memory.width && instruction.operands[operand_index].memory.width != info.suffix_width)
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                            (u32)operands.length, S8("memory width does not match mnemonic suffix"));
                        return;
                    }
                    instruction.operands[operand_index].memory.width = info.suffix_width;
                }
            }
        }
        if (info.source_width)
        {
            AssemblyOperand* source = instruction.operands + 1;
            if (source->kind == ASSEMBLY_OPERAND_REGISTER && source->reg.width != info.source_width)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("source width does not match mnemonic"));
                return;
            }
            if (source->kind == ASSEMBLY_OPERAND_MEMORY)
            {
                if (source->memory.width && source->memory.width != info.source_width)
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                        (u32)operands.length, S8("memory width does not match mnemonic"));
                    return;
                }
                source->memory.width = info.source_width;
            }
        }
        if (target.cpu_arch == CPU_ARCH_X86_64)
        {
            instruction.evex = assembly_x86_instruction_uses_evex(instruction, target);
            AssemblyVectorForm const* vector_form = assembly_x86_vector_form(instruction.opcode);
            if (vector_form && instruction.evex && (vector_form->flags & ASSEMBLY_VECTOR_FORM_VEX_ONLY))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("the mnemonic has no EVEX form"));
                return;
            }
            if (vector_form && instruction.evex)
            {
                u16 vector_width = assembly_x86_instruction_vector_width(instruction, vector_form);
                if (!assembly_x86_target_has_evex(target, vector_width, (u8)((vector_form->flags & ASSEMBLY_VECTOR_FORM_SCALAR) != 0)))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                        vector_width == 512 ? S8("512-bit EVEX instruction requires avx512f or avx10.512")
                                                            : S8("EVEX instruction requires avx512vl or avx10"));
                    return;
                }
                if ((vector_form->flags & ASSEMBLY_VECTOR_FORM_AVX512BW) &&
                    !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX512BW) &&
                    !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_1) &&
                    !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_2))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                        S8("instruction requires avx512bw or avx10"));
                    return;
                }
                if ((vector_form->flags & ASSEMBLY_VECTOR_FORM_AVX512DQ) &&
                    !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX512DQ) &&
                    !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_1) &&
                    !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_2))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                        S8("instruction requires avx512dq or avx10"));
                    return;
                }
            }
            if (assembly_x86_opcode_is_mask(instruction.opcode) &&
                !assembly_x86_target_has_mask_feature(target, instruction.opcode))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                    assembly_x86_mask_feature_name(instruction.opcode));
                return;
            }
            if (assembly_x86_opcode_is_amx(instruction.opcode) &&
                !assembly_x86_target_has_amx_feature(target, instruction.opcode))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                    assembly_x86_amx_feature_name(instruction.opcode));
                return;
            }
            if ((assembly_x86_instruction_has_extended_gpr(instruction) || instruction.no_flags ||
                 instruction.opcode == ASSEMBLY_OPCODE_X86_APX_PUSH2 || instruction.opcode == ASSEMBLY_OPCODE_X86_APX_POP2 ||
                 (assembly_x86_opcode_is_apx_ndd(instruction.opcode) && instruction.operand_count == 3 &&
                  !(instruction.opcode == ASSEMBLY_OPCODE_X86_IMUL && instruction.operands[2].kind == ASSEMBLY_OPERAND_EXPRESSION))) &&
                !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_APX))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                    S8("instruction requires the apx target feature"));
                return;
            }
        }
        if (target.cpu_arch == CPU_ARCH_X86_64 && assembly_x86_opcode_is_avx_integer(info.opcode) &&
            !instruction.evex && !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX2))
        {
            u8 requires_avx2 = false;
            for (u32 operand_index = 0; operand_index < instruction.operand_count; operand_index += 1)
            {
                requires_avx2 = requires_avx2 || (instruction.operands[operand_index].kind == ASSEMBLY_OPERAND_REGISTER &&
                                                   instruction.operands[operand_index].reg.class == ASSEMBLY_REGISTER_YMM);
            }
            if (requires_avx2)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                    S8("256-bit packed integer instruction requires the avx2 target feature"));
                return;
            }
        }
        if (target.cpu_arch == CPU_ARCH_X86_64 && assembly_x86_opcode_is_legacy_packed(info.opcode) &&
            !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_SSE2))
        {
            u8 requires_sse2 = false;
            for (u32 operand_index = 0; operand_index < instruction.operand_count; operand_index += 1)
            {
                requires_sse2 = requires_sse2 || (instruction.operands[operand_index].kind == ASSEMBLY_OPERAND_REGISTER &&
                                                   instruction.operands[operand_index].reg.class == ASSEMBLY_REGISTER_XMM);
            }
            if (requires_sse2)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE, line, column, (u32)mnemonic.length,
                                    S8("XMM packed integer instruction requires the sse2 target feature"));
                return;
            }
        }
        if (target.cpu_arch == CPU_ARCH_X86_64)
        {
            // These source layouts are selected with checked metadata forms
            // below; the parser only supplies operands and syntax aliases.
            bool metadata_layout = instruction.opcode == ASSEMBLY_OPCODE_X86_LEA ||
                                   instruction.opcode == ASSEMBLY_OPCODE_X86_MOVZX ||
                                   instruction.opcode == ASSEMBLY_OPCODE_X86_MOVSX ||
                                   instruction.opcode == ASSEMBLY_OPCODE_X86_MOVSXD;
            if ((!metadata_layout && !assembly_x86_instruction_size(&instruction)) ||
                (info.suffix_width && instruction.width && info.suffix_width != instruction.width))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("unsupported x86 operand form"));
                return;
            }
        }
        else
        {
            instruction.size = 4;
            if (instruction.encoding_kind != ASSEMBLY_ENCODING_AARCH64_M1_GPR &&
                instruction.encoding_kind != ASSEMBLY_ENCODING_AARCH64_GPR_ALIAS &&
                instruction.encoding_kind != ASSEMBLY_ENCODING_AARCH64_CONTROL && instruction.operand_count &&
                instruction.operands[0].kind != ASSEMBLY_OPERAND_EXPRESSION)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, line, column + (u32)mnemonic_end,
                                    (u32)operands.length, S8("invalid AArch64 operand form"));
                return;
            }
        }
        builder->instructions[builder->instruction_count++] = instruction;
    }
}

BUSTER_GLOBAL_LOCAL u32 assembly_x86_metadata_feature_names(Target target, String8* names, u32 capacity)
{
    static TargetCpuFeature const x86_feature_bits[] = {
        TARGET_CPU_FEATURE_X86_SSE2,
        TARGET_CPU_FEATURE_X86_AVX,
        TARGET_CPU_FEATURE_X86_AVX2,
        TARGET_CPU_FEATURE_X86_AVX512F,
        TARGET_CPU_FEATURE_X86_AVX512VL,
        TARGET_CPU_FEATURE_X86_AVX10_1,
        TARGET_CPU_FEATURE_X86_AVX10_2,
        TARGET_CPU_FEATURE_X86_AVX10_512,
        TARGET_CPU_FEATURE_X86_APX,
        TARGET_CPU_FEATURE_X86_AVX512BW,
        TARGET_CPU_FEATURE_X86_SSE3,
        TARGET_CPU_FEATURE_X86_SSSE3,
        TARGET_CPU_FEATURE_X86_SSE4_1,
        TARGET_CPU_FEATURE_X86_SSE4_2,
        TARGET_CPU_FEATURE_X86_SSE4A,
        TARGET_CPU_FEATURE_X86_F16C,
        TARGET_CPU_FEATURE_X86_FMA,
        TARGET_CPU_FEATURE_X86_POPCNT,
        TARGET_CPU_FEATURE_X86_LZCNT,
        TARGET_CPU_FEATURE_X86_BMI1,
        TARGET_CPU_FEATURE_X86_BMI2,
        TARGET_CPU_FEATURE_X86_ADX,
        TARGET_CPU_FEATURE_X86_MOVBE,
        TARGET_CPU_FEATURE_X86_RDRAND,
        TARGET_CPU_FEATURE_X86_RDSEED,
        TARGET_CPU_FEATURE_X86_WAITPKG,
        TARGET_CPU_FEATURE_X86_PKU,
        TARGET_CPU_FEATURE_X86_PTWRITE,
        TARGET_CPU_FEATURE_X86_SERIALIZE,
        TARGET_CPU_FEATURE_X86_CLFLUSHOPT,
        TARGET_CPU_FEATURE_X86_CLWB,
        TARGET_CPU_FEATURE_X86_FSGSBASE,
        TARGET_CPU_FEATURE_X86_RTM,
        TARGET_CPU_FEATURE_X86_TSXLDTRK,
        TARGET_CPU_FEATURE_X86_UINTR,
        TARGET_CPU_FEATURE_X86_PREFETCHWT1,
        TARGET_CPU_FEATURE_X86_CX16,
        TARGET_CPU_FEATURE_X86_AVX512CD,
        TARGET_CPU_FEATURE_X86_AVX512DQ,
        TARGET_CPU_FEATURE_X86_AVX512IFMA,
        TARGET_CPU_FEATURE_X86_AVX512PF,
        TARGET_CPU_FEATURE_X86_AVX512ER,
        TARGET_CPU_FEATURE_X86_AVX512VBMI,
        TARGET_CPU_FEATURE_X86_AVX512VBMI2,
        TARGET_CPU_FEATURE_X86_AVX512VNNI,
        TARGET_CPU_FEATURE_X86_AVX512BITALG,
        TARGET_CPU_FEATURE_X86_AVX512VPOPCNTDQ,
        TARGET_CPU_FEATURE_X86_AVX5124VNNIW,
        TARGET_CPU_FEATURE_X86_AVX5124FMAPS,
        TARGET_CPU_FEATURE_X86_AVX512VP2INTERSECT,
        TARGET_CPU_FEATURE_X86_AVX512BF16,
        TARGET_CPU_FEATURE_X86_AVX512FP16,
        TARGET_CPU_FEATURE_X86_GFNI,
        TARGET_CPU_FEATURE_X86_VAES,
        TARGET_CPU_FEATURE_X86_VPCLMULQDQ,
        TARGET_CPU_FEATURE_X86_AES,
        TARGET_CPU_FEATURE_X86_PCLMUL,
        TARGET_CPU_FEATURE_X86_AVX10_V1_AUX,
        TARGET_CPU_FEATURE_X86_APX_NCI_NDD_NF,
        TARGET_CPU_FEATURE_X86_AMX_TILE,
        TARGET_CPU_FEATURE_X86_AMX_INT8,
        TARGET_CPU_FEATURE_X86_AMX_BF16,
        TARGET_CPU_FEATURE_X86_AMX_FP16,
        TARGET_CPU_FEATURE_X86_AMX_COMPLEX,
        TARGET_CPU_FEATURE_X86_AMX_FP8,
        TARGET_CPU_FEATURE_X86_AMX_AVX512,
        TARGET_CPU_FEATURE_X86_AMX_MOVRS,
        TARGET_CPU_FEATURE_X86_AVX_VNNI,
        TARGET_CPU_FEATURE_X86_AVX_VNNI_INT8,
        TARGET_CPU_FEATURE_X86_AVX_VNNI_INT16,
        TARGET_CPU_FEATURE_X86_AVX_IFMA,
        TARGET_CPU_FEATURE_X86_AVX_NE_CONVERT,
        TARGET_CPU_FEATURE_X86_MOVRS,
        TARGET_CPU_FEATURE_X86_3DNOW,
        TARGET_CPU_FEATURE_X86_3DNOWA,
        TARGET_CPU_FEATURE_X86_FMA4,
        TARGET_CPU_FEATURE_X86_LWP,
        TARGET_CPU_FEATURE_X86_TBM,
        TARGET_CPU_FEATURE_X86_XOP,
        TARGET_CPU_FEATURE_X86_IBT,
        TARGET_CPU_FEATURE_X86_CLDEMOTE,
        TARGET_CPU_FEATURE_X86_PREFETCHI,
        TARGET_CPU_FEATURE_X86_SHSTK,
        TARGET_CPU_FEATURE_X86_VMX,
        TARGET_CPU_FEATURE_X86_SVM,
        TARGET_CPU_FEATURE_X86_ENQCMD,
        TARGET_CPU_FEATURE_X86_FRED,
        TARGET_CPU_FEATURE_X86_HRESET,
        TARGET_CPU_FEATURE_X86_INVLPGB,
        TARGET_CPU_FEATURE_X86_INVPCID,
        TARGET_CPU_FEATURE_X86_KEYLOCKER,
        TARGET_CPU_FEATURE_X86_LKGS,
        TARGET_CPU_FEATURE_X86_MSR_IMM,
        TARGET_CPU_FEATURE_X86_MSRLIST,
        TARGET_CPU_FEATURE_X86_MONITOR,
        TARGET_CPU_FEATURE_X86_MOVDIR64B,
        TARGET_CPU_FEATURE_X86_PBNDKB,
        TARGET_CPU_FEATURE_X86_PCONFIG,
        TARGET_CPU_FEATURE_X86_SMAP,
        TARGET_CPU_FEATURE_X86_SGX,
        TARGET_CPU_FEATURE_X86_SNP,
        TARGET_CPU_FEATURE_X86_TDX,
        TARGET_CPU_FEATURE_X86_WBNOINVD,
        TARGET_CPU_FEATURE_X86_WRMSRNS,
        TARGET_CPU_FEATURE_X86_XSAVE,
        TARGET_CPU_FEATURE_X86_XSAVES,
        TARGET_CPU_FEATURE_X86_ACE_1,
        TARGET_CPU_FEATURE_X86_SHA,
        TARGET_CPU_FEATURE_X86_SHA512,
        TARGET_CPU_FEATURE_X86_SM3,
        TARGET_CPU_FEATURE_X86_SM4,
    };
    static TargetCpuFeature const aarch64_feature_bits[] = {
        TARGET_CPU_FEATURE_AARCH64_NEON,
        TARGET_CPU_FEATURE_AARCH64_V8_4A,
        TARGET_CPU_FEATURE_AARCH64_AES,
        TARGET_CPU_FEATURE_AARCH64_ALTNZCV,
        TARGET_CPU_FEATURE_AARCH64_CCDP,
        TARGET_CPU_FEATURE_AARCH64_CCPP,
        TARGET_CPU_FEATURE_AARCH64_COMPLXNUM,
        TARGET_CPU_FEATURE_AARCH64_CRC,
        TARGET_CPU_FEATURE_AARCH64_DOTPROD,
        TARGET_CPU_FEATURE_AARCH64_FLAGM,
        TARGET_CPU_FEATURE_AARCH64_FP_ARMV8,
        TARGET_CPU_FEATURE_AARCH64_FP16FML,
        TARGET_CPU_FEATURE_AARCH64_FPTOINT,
        TARGET_CPU_FEATURE_AARCH64_FULLFP16,
        TARGET_CPU_FEATURE_AARCH64_JSCONV,
        TARGET_CPU_FEATURE_AARCH64_LSE,
        TARGET_CPU_FEATURE_AARCH64_LOR,
        TARGET_CPU_FEATURE_AARCH64_PAUTH,
        TARGET_CPU_FEATURE_AARCH64_PERFMON,
        TARGET_CPU_FEATURE_AARCH64_PREDRES,
        TARGET_CPU_FEATURE_AARCH64_RAS,
        TARGET_CPU_FEATURE_AARCH64_RCPC,
        TARGET_CPU_FEATURE_AARCH64_RCPC_IMMO,
        TARGET_CPU_FEATURE_AARCH64_RDM,
        TARGET_CPU_FEATURE_AARCH64_SB,
        TARGET_CPU_FEATURE_AARCH64_SHA2,
        TARGET_CPU_FEATURE_AARCH64_SHA3,
        TARGET_CPU_FEATURE_AARCH64_SPECRESTRICT,
        TARGET_CPU_FEATURE_AARCH64_SSBS,
        TARGET_CPU_FEATURE_AARCH64_TRACEV8_4,
        TARGET_CPU_FEATURE_AARCH64_SME,
    };
    BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(x86_feature_bits) + BUSTER_ARRAY_LENGTH(aarch64_feature_bits) ==
                    (u32)TARGET_CPU_FEATURE_COUNT - 2);
    TargetCpuFeature const* feature_bits = target.cpu_arch == CPU_ARCH_AARCH64 ? aarch64_feature_bits : x86_feature_bits;
    u32 feature_bit_count = target.cpu_arch == CPU_ARCH_AARCH64 ? BUSTER_ARRAY_LENGTH(aarch64_feature_bits)
                                                                : BUSTER_ARRAY_LENGTH(x86_feature_bits);
    if (!names || capacity < feature_bit_count)
    {
        return 0;
    }
    TargetCpuFeatures effective = target_cpu_features_effective(target);
    u32 count = 0;
    for (u32 index = 0; index < feature_bit_count; index += 1)
    {
        if (target_cpu_features_contains(effective, feature_bits[index]))
        {
            names[count++] = target_cpu_feature_to_string(feature_bits[index]);
        }
    }
    return count;
}

BUSTER_GLOBAL_LOCAL void assembly_x86_metadata_append_feature(String8* names, u32* count, u32 capacity, String8 feature)
{
    if (names && count && *count < capacity)
    {
        for (u32 index = 0; index < *count; index += 1)
        {
            if (assembly_word_equal(names[index], feature)) return;
        }
        names[(*count)++] = feature;
    }
}

BUSTER_GLOBAL_LOCAL void assembly_x86_metadata_append_avx10_aliases(Target target, String8* names, u32* count, u32 capacity,
                                                                      BusterX86MetadataPhysicalOperand const* operands,
                                                                      u32 operand_count)
{
    if (target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_1) || target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_AVX10_2))
    {
        u16 max_vector_width = 0;
        for (u32 index = 0; index < operand_count; index += 1)
        {
            BusterX86MetadataPhysicalOperand operand = operands[index];
            if (operand.kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER) continue;
            u16 width = 0;
            if (operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_XMM)
                width = 128;
            else if (operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_YMM)
                width = 256;
            else if (operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM)
                width = 512;
            if (width > max_vector_width) max_vector_width = width;
        }
        if (!max_vector_width) return;
        assembly_x86_metadata_append_feature(names, count, capacity, S8("avx512f"));
        if (max_vector_width >= 512)
            assembly_x86_metadata_append_feature(names, count, capacity, S8("avx512dq"));
        else
            assembly_x86_metadata_append_feature(names, count, capacity, S8("avx512vl"));
    }
}

BUSTER_GLOBAL_LOCAL u8 assembly_x86_metadata_physical_class(AssemblyRegisterClass class)
{
    return class == ASSEMBLY_REGISTER_GPR       ? BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR
           : class == ASSEMBLY_REGISTER_XMM     ? BUSTER_X86_METADATA_PHYSICAL_CLASS_XMM
           : class == ASSEMBLY_REGISTER_YMM     ? BUSTER_X86_METADATA_PHYSICAL_CLASS_YMM
           : class == ASSEMBLY_REGISTER_ZMM     ? BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM
           : class == ASSEMBLY_REGISTER_OPMASK  ? BUSTER_X86_METADATA_PHYSICAL_CLASS_MASK
           : class == ASSEMBLY_REGISTER_TILE    ? BUSTER_X86_METADATA_PHYSICAL_CLASS_TMM
           : class == ASSEMBLY_REGISTER_MMX     ? BUSTER_X86_METADATA_PHYSICAL_CLASS_MMX
           : class == ASSEMBLY_REGISTER_X87     ? BUSTER_X86_METADATA_PHYSICAL_CLASS_SPECIAL
           : class == ASSEMBLY_REGISTER_BND     ? BUSTER_X86_METADATA_PHYSICAL_CLASS_BND
           : class == ASSEMBLY_REGISTER_CONTROL ? BUSTER_X86_METADATA_PHYSICAL_CLASS_CONTROL
           : class == ASSEMBLY_REGISTER_DEBUG   ? BUSTER_X86_METADATA_PHYSICAL_CLASS_DEBUG
           : class == ASSEMBLY_REGISTER_SEGMENT ? BUSTER_X86_METADATA_PHYSICAL_CLASS_SEGMENT
           : class == ASSEMBLY_REGISTER_SPECIAL ? BUSTER_X86_METADATA_PHYSICAL_CLASS_SPECIAL
                                                : BUSTER_X86_METADATA_PHYSICAL_CLASS_UNKNOWN;
}

BUSTER_GLOBAL_LOCAL String8 assembly_x86_metadata_symbol_name(AssemblyBuilder* builder, u32 symbol)
{
    return symbol < builder->result.symbol_count ? builder->result.symbols[symbol].name : (String8){0};
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_physical_operand(AssemblyBuilder* builder, AssemblyOperand operand, bool relative,
                                                                 bool absolute, BusterX86MetadataPhysicalOperand* result)
{
    if (!result)
    {
        return false;
    }
    *result = (BusterX86MetadataPhysicalOperand){0};
    if (operand.kind == ASSEMBLY_OPERAND_REGISTER)
    {
        result->kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER;
        result->width = operand.reg.width;
        result->reg = (BusterX86MetadataPhysicalRegister){
            .index = operand.reg.index,
            .width = operand.reg.width,
            .physical_class = assembly_x86_metadata_physical_class(operand.reg.class),
            .high_byte = operand.reg.high_byte,
        };
        return result->reg.physical_class != BUSTER_X86_METADATA_PHYSICAL_CLASS_UNKNOWN;
    }
    if (operand.kind == ASSEMBLY_OPERAND_MEMORY)
    {
        AssemblyMemory memory = operand.memory;
        result->kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY;
        // Metadata memory widths describe the encoded scalar element for
        // vector forms, while the source qualifier records the aggregate
        // vector width (xmmword/ymmword/zmmword).  Leave aggregate widths
        // unresolved so the selected vector form supplies the element width;
        // scalar and branch memory widths retain their source value.
        result->width = (memory.width > 64 && memory.width != 80) ? 0 : memory.width ? memory.width : (relative ? 64 : 0);
        // Width 80 is an x87 scalar element, not an aggregate vector
        // qualifier.  Keep it in the physical width field only; the
        // metadata source-width side channel is reserved for vector
        // aggregate qualifiers and would reject the mem80real rows.
        result->memory.source_width = memory.width == 80 ? 0 : memory.width;
        result->memory.address_size = memory.address_size ? memory.address_size : 64;
        result->memory.scale = memory.scale ? memory.scale : 1;
        result->memory.segment = memory.has_segment ? memory.segment : BUSTER_X86_METADATA_SEGMENT_NONE;
        result->memory.has_segment = memory.has_segment;
        result->memory.has_base = memory.has_base;
        result->memory.has_index = memory.has_index;
        result->memory.rip_relative = memory.rip_relative;
        result->memory.vsib = memory.vsib;
        if (memory.has_base)
        {
            result->memory.base = (BusterX86MetadataPhysicalRegister){
                .index = memory.base.index,
                .width = memory.base.width,
                .physical_class = assembly_x86_metadata_physical_class(memory.base.class),
            };
        }
        if (memory.has_index)
        {
            result->memory.index = (BusterX86MetadataPhysicalRegister){
                .index = memory.index.index,
                .width = memory.index.width,
                .physical_class = assembly_x86_metadata_physical_class(memory.index.class),
            };
        }
        if (memory.displacement.has_symbol)
        {
            result->memory.symbol = assembly_x86_metadata_symbol_name(builder, memory.displacement.symbol);
            result->memory.has_symbol = result->memory.symbol.length != 0;
            result->memory.addend = memory.displacement.addend;
            if (!result->memory.has_symbol)
            {
                return false;
            }
        }
        else
        {
            if (memory.displacement.has_unsigned_addend)
            {
                return false;
            }
            result->memory.displacement = memory.displacement.addend;
            result->memory.has_displacement = memory.displacement.addend != 0;
        }
        if (memory.has_base && result->memory.base.physical_class != BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR)
        {
            return false;
        }
        if (memory.has_index && memory.vsib)
        {
            if (result->memory.index.physical_class != BUSTER_X86_METADATA_PHYSICAL_CLASS_XMM &&
                result->memory.index.physical_class != BUSTER_X86_METADATA_PHYSICAL_CLASS_YMM &&
                result->memory.index.physical_class != BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM)
            {
                return false;
            }
        }
        else if (memory.has_index && result->memory.index.physical_class != BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR)
        {
            return false;
        }
        return true;
    }
    if (operand.kind != ASSEMBLY_OPERAND_EXPRESSION)
    {
        return false;
    }
    result->kind = absolute       ? BUSTER_X86_METADATA_PHYSICAL_OPERAND_ABSOLUTE
                   : relative    ? BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE
                                 : BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE;
    result->width = 0;
    if (operand.expression.has_symbol)
    {
        result->symbol = assembly_x86_metadata_symbol_name(builder, operand.expression.symbol);
        result->has_symbol = result->symbol.length != 0;
        result->addend = operand.expression.addend;
        return result->has_symbol;
    }
    if (operand.expression.has_unsigned_addend)
    {
        result->unsigned_value = operand.expression.unsigned_addend;
        result->has_unsigned_value = true;
    }
    else
    {
        result->value = operand.expression.addend;
        result->has_value = true;
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_absolute_mnemonic(String8 mnemonic)
{
    return assembly_word_equal(mnemonic, S8("jmpabs"));
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_adjust_relative_literals(BusterX86MetadataPhysicalOperand* operands, u32 operand_count,
                                                                          u64 offset, u32 byte_count)
{
    if (!operands)
    {
        return false;
    }
    bool has_relative_literal = false;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        has_relative_literal |= operands[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE && !operands[index].has_symbol;
    }
    if (has_relative_literal)
    {
        if (offset > (u64)INT64_MAX || (u64)byte_count > (u64)INT64_MAX - offset)
        {
            return false;
        }
        s64 next = (s64)(offset + byte_count);
        for (u32 index = 0; index < operand_count; index += 1)
        {
            BusterX86MetadataPhysicalOperand* operand = operands + index;
            if (operand->kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE || operand->has_symbol)
            {
                continue;
            }
            if (operand->has_unsigned_value)
            {
                if (operand->unsigned_value > (u64)INT64_MAX)
                {
                    return false;
                }
                operand->value = (s64)operand->unsigned_value;
                operand->has_unsigned_value = false;
                operand->has_value = true;
            }
            if (!operand->has_value || operand->value < INT64_MIN + next)
            {
                return false;
            }
            operand->value -= next;
        }
    }

    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_relative_mnemonic(String8 mnemonic)
{
    if (!mnemonic.length)
    {
        return false;
    }
    if (assembly_word_equal(mnemonic, S8("jmpabs")))
    {
        return false;
    }
    if (mnemonic.pointer[0] == 'j' || mnemonic.pointer[0] == 'J')
    {
        return true;
    }
    return assembly_word_equal(mnemonic, S8("call")) || assembly_word_equal(mnemonic, S8("call_near")) ||
           assembly_word_equal(mnemonic, S8("loop")) ||
           assembly_word_equal(mnemonic, S8("loope")) || assembly_word_equal(mnemonic, S8("loopz")) ||
           assembly_word_equal(mnemonic, S8("loopne")) || assembly_word_equal(mnemonic, S8("loopnz")) ||
           assembly_word_equal(mnemonic, S8("xbegin"));
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_private_pc8_mnemonic(String8 mnemonic)
{
    return assembly_word_equal(mnemonic, S8("jcxz")) || assembly_word_equal(mnemonic, S8("jecxz")) ||
           assembly_word_equal(mnemonic, S8("jrcxz")) || assembly_word_equal(mnemonic, S8("loop")) ||
           assembly_word_equal(mnemonic, S8("loope")) || assembly_word_equal(mnemonic, S8("loopz")) ||
           assembly_word_equal(mnemonic, S8("loopne")) || assembly_word_equal(mnemonic, S8("loopnz"));
}

BUSTER_GLOBAL_LOCAL String8 assembly_x86_metadata_att_string_alias(AssemblySyntax syntax, String8 mnemonic)
{
    if (syntax == ASSEMBLY_SYNTAX_ATT)
    {
        if (assembly_word_equal(mnemonic, S8("movsl"))) return S8("movsd");
        if (assembly_word_equal(mnemonic, S8("cmpsl"))) return S8("cmpsd");
        if (assembly_word_equal(mnemonic, S8("stosl"))) return S8("stosd");
        if (assembly_word_equal(mnemonic, S8("lodsl"))) return S8("lodsd");
        if (assembly_word_equal(mnemonic, S8("scasl"))) return S8("scasd");
        if (assembly_word_equal(mnemonic, S8("insl"))) return S8("insd");
        if (assembly_word_equal(mnemonic, S8("outsl"))) return S8("outsd");
    }

    return mnemonic;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_string_has_token(BusterX86MetadataString string, String8 token)
{
    u32 offset = 0;
    while (offset < string.length)
    {
        while (offset < string.length && assembly_space(buster_x86_metadata_string_byte(string, offset))) offset += 1;
        u32 start = offset;
        while (offset < string.length && !assembly_space(buster_x86_metadata_string_byte(string, offset))) offset += 1;
        u32 length = offset - start;
        if (length != token.length) continue;
        bool equal = true;
        for (u32 index = 0; index < length; index += 1)
        {
            if (assembly_ascii_lower(buster_x86_metadata_string_byte(string, start + index)) !=
                assembly_ascii_lower(token.pointer[index]))
            {
                equal = false;
                break;
            }
        }
        if (equal) return true;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_mnemonic_has_att_operand_order_exception(String8 mnemonic)
{
    if (assembly_word_equal(mnemonic, S8("enter")))
    {
        BusterX86MetadataCandidateRange candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
        for (u32 position = 0; position < candidates.count; position += 1)
        {
            u32 form_id = 0;
            BusterX86MetadataForm form = {0};
            if (buster_x86_metadata_candidate_at(candidates, position, &form_id) && buster_x86_metadata_form(form_id, &form) &&
                assembly_x86_metadata_string_has_token(form.attributes, S8("ATT_OPERAND_ORDER_EXCEPTION")))
                return true;
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL String8 assembly_x86_metadata_mnemonic(String8 mnemonic)
{
    if (assembly_word_equal(mnemonic, S8("loopz"))) return S8("loope");
    if (assembly_word_equal(mnemonic, S8("loopnz"))) return S8("loopne");
    // GNU/AT&T spellings for the accumulator sign-extension family are
    // aliases of the Intel mnemonics represented by metadata.
    if (assembly_word_equal(mnemonic, S8("cbtw"))) return S8("cbw");
    if (assembly_word_equal(mnemonic, S8("cwtl"))) return S8("cwde");
    if (assembly_word_equal(mnemonic, S8("cltq"))) return S8("cdqe");
    if (assembly_word_equal(mnemonic, S8("cwtd"))) return S8("cwd");
    if (assembly_word_equal(mnemonic, S8("cltd"))) return S8("cdq");
    if (assembly_word_equal(mnemonic, S8("cqto"))) return S8("cqo");
    // XED's condition-family spellings use Z/NZ and the negative aliases
    // (NLE, etc.) as canonical keys.  The handwritten front end accepts the
    // shorter Intel aliases (JE, SETNE, SETG, CMOVE); normalize those keys
    // before metadata candidate selection.
    if (assembly_word_equal(mnemonic, S8("je"))) return S8("jz");
    if (assembly_word_equal(mnemonic, S8("setne"))) return S8("setnz");
    if (assembly_word_equal(mnemonic, S8("setg"))) return S8("setnle");
    if (assembly_word_equal(mnemonic, S8("cmove"))) return S8("cmovz");
    // GNU/AT&T scalar extension aliases carry both source and destination
    // widths in the mnemonic.  Metadata models the operation as MOVZX/MOVSX
    // (or MOVSXD for the dword-to-qword form); source memory width is restored
    // from the alias in the parser below.
    if (assembly_word_equal(mnemonic, S8("movzbw")) || assembly_word_equal(mnemonic, S8("movzbl")) ||
        assembly_word_equal(mnemonic, S8("movzbq")) || assembly_word_equal(mnemonic, S8("movzwl")) ||
        assembly_word_equal(mnemonic, S8("movzwq")))
        return S8("movzx");
    if (assembly_word_equal(mnemonic, S8("movsbw")) || assembly_word_equal(mnemonic, S8("movsbl")) ||
        assembly_word_equal(mnemonic, S8("movsbq")) || assembly_word_equal(mnemonic, S8("movswl")) ||
        assembly_word_equal(mnemonic, S8("movswq")))
        return S8("movsx");
    if (assembly_word_equal(mnemonic, S8("movslq"))) return S8("movsxd");
    if (assembly_word_equal(mnemonic, S8("xlatb"))) return S8("xlat");
    if (!buster_x86_metadata_lookup_mnemonic(mnemonic).count)
    {
        if (mnemonic.length > 5 && assembly_word_equal(string_slice(mnemonic, mnemonic.length - 5, mnemonic.length), S8("_near")))
        {
            String8 base = string_slice(mnemonic, 0, mnemonic.length - 5);
            if (buster_x86_metadata_lookup_mnemonic(base).count)
            {
                return base;
            }
        }
    }

    return mnemonic;
}

BUSTER_GLOBAL_LOCAL u16 assembly_x86_metadata_att_scalar_extend_source_width(String8 mnemonic)
{
    if (assembly_word_equal(mnemonic, S8("movzbw")) || assembly_word_equal(mnemonic, S8("movzbl")) ||
        assembly_word_equal(mnemonic, S8("movzbq")) || assembly_word_equal(mnemonic, S8("movsbw")) ||
        assembly_word_equal(mnemonic, S8("movsbl")) || assembly_word_equal(mnemonic, S8("movsbq")))
        return 8;
    if (assembly_word_equal(mnemonic, S8("movzwl")) || assembly_word_equal(mnemonic, S8("movzwq")) ||
        assembly_word_equal(mnemonic, S8("movswl")) || assembly_word_equal(mnemonic, S8("movswq")))
        return 16;
    if (assembly_word_equal(mnemonic, S8("movslq"))) return 32;
    return 0;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_apx_disasm_alias(
    String8 mnemonic, BusterX86MetadataPhysicalAttributes* attributes)
{
    if (!mnemonic.length || !attributes)
    {
        return false;
    }
    BusterX86MetadataCandidateRange candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
    bool found = false;
    bool ambiguous = false;
    for (u32 position = 0; position < candidates.count; position += 1)
    {
        u32 form_id = 0;
        BusterX86MetadataForm form = {0};
        if (!buster_x86_metadata_candidate_at(candidates, position, &form_id) || !buster_x86_metadata_form(form_id, &form))
        {
            continue;
        }
        String8 disasm = buster_x86_metadata_string_span(form.disasm);
        if (disasm.length == mnemonic.length && assembly_word_equal(disasm, mnemonic))
        {
            found = true;
            ambiguous |= !(form.apx_flags & BUSTER_X86_METADATA_APX_NDD);
        }
    }
    if (found && !ambiguous)
    {
        // The generated disassembly aliases (IMULZU and SET*ZU) select the
        // APX NDD family.  An explicit {nf} remains an independent source
        // attribute, so IMULZU can select either its NF=0 or NF=1 row.
        attributes->apx_flags |= BUSTER_X86_METADATA_APX_NDD;
    }
    return found && !ambiguous;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_mnemonic_requires_dfv(String8 mnemonic)
{
    BusterX86MetadataCandidateRange candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
    for (u32 position = 0; position < candidates.count; position += 1)
    {
        u32 form_id = 0;
        if (buster_x86_metadata_candidate_at(candidates, position, &form_id) &&
            buster_x86_metadata_form_requires_dfv(form_id))
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_parse_dfv(AssemblyOperand operand, u8* value)
{
    if (operand.kind != ASSEMBLY_OPERAND_EXPRESSION || operand.expression.has_symbol)
    {
        return false;
    }
    if (operand.expression.has_unsigned_addend)
    {
        if (operand.expression.unsigned_addend > 15) return false;
        if (value) *value = (u8)operand.expression.unsigned_addend;
        return true;
    }
    if (operand.expression.addend < 0 || operand.expression.addend > 15)
    {
        return false;
    }
    if (value) *value = (u8)operand.expression.addend;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_mnemonic_has_visible_operands(String8 mnemonic)
{
    BusterX86MetadataCandidateRange candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
    for (u32 position = 0; position < candidates.count; position += 1)
    {
        u32 form_id = 0;
        BusterX86MetadataForm form = {0};
        if (!buster_x86_metadata_candidate_at(candidates, position, &form_id) || !buster_x86_metadata_form(form_id, &form))
        {
            continue;
        }
        for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
        {
            BusterX86MetadataOperand operand = {0};
            if (buster_x86_metadata_operand(form_id, operand_index, &operand) && operand.visible)
            {
                return true;
            }
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_suffix_alias(Target target, AssemblySyntax syntax, String8 mnemonic,
                                                             String8* base, AssemblyInstructionInfo* base_info, u8* width)
{
    if (syntax != ASSEMBLY_SYNTAX_ATT || mnemonic.length <= 1 || !base || !width)
    {
        return false;
    }
    char8 suffix = assembly_ascii_lower(mnemonic.pointer[mnemonic.length - 1]);
    u8 suffix_width = suffix == 'b' ? 8 : suffix == 'w' ? 16 : suffix == 'l' ? 32 : suffix == 'q' ? 64 : 0;
    if (!suffix_width && suffix != 's' && suffix != 't')
    {
        return false;
    }
    // The full AT&T mnemonic is present in the x87 typed alias table (for
    // example `fiadds`), while the base candidate below is the unsuffixed
    // `fiadd` entry and therefore has no suffix_width metadata of its own.
    // The typed source alias is the sole width authority for `s` and `t`.
    AssemblyInstructionInfo suffixed_info = {.opcode = ASSEMBLY_OPCODE_COUNT};
    bool has_typed_suffix = assembly_instruction_lookup(target, syntax, mnemonic, &suffixed_info) && suffixed_info.suffix_width;
    if (has_typed_suffix)
    {
        suffix_width = suffixed_info.suffix_width;
    }
    // A complete literal mnemonic must retain its identity after operand
    // rejection. Typed aliases such as scalar `movq` may still select MOV
    // when the separate metadata MOVQ family does not match their operands.
    if (!suffix_width || (!has_typed_suffix && buster_x86_metadata_lookup_mnemonic(mnemonic).count))
    {
        return false;
    }
    // GNU spells the 64-bit x87 integer forms with a doubled `l` -- `fistpll`,
    // `fildll`, `fisttpll` -- which is one suffix character more than the
    // single-character strip below reads. Stripping one leaves `fistpl`, which
    // is the *32-bit* alias and is not a mnemonic the metadata tables know at
    // all, so the whole spelling was reported as an unknown instruction. The
    // typed alias table above already carries the doubled spelling and its
    // width, so a doubled suffix strips two characters and keeps that width
    // rather than rediscovering a narrower one from what one strip left behind.
    u64 suffix_length = 1;
    if (suffix == 'l' && mnemonic.length > 2 && assembly_ascii_lower(mnemonic.pointer[mnemonic.length - 2]) == 'l' && suffix_width == 64 &&
        (suffixed_info.opcode == ASSEMBLY_OPCODE_X86_FILD || suffixed_info.opcode == ASSEMBLY_OPCODE_X86_FIST ||
         suffixed_info.opcode == ASSEMBLY_OPCODE_X86_FISTP || suffixed_info.opcode == ASSEMBLY_OPCODE_X86_FISTTP))
    {
        suffix_length = 2;
    }
    String8 candidate = string_slice(mnemonic, 0, mnemonic.length - suffix_length);
    AssemblyInstructionInfo info = {.opcode = ASSEMBLY_OPCODE_COUNT};
    bool has_handwritten_base = assembly_instruction_lookup(target, syntax, candidate, &info);
    if (has_handwritten_base && suffix_length == 1)
    {
        // x87 AT&T suffix aliases carry their architectural element width in
        // the handwritten lookup table (`fiadds` is mem16int, while `fadds`
        // is mem32real).  Prefer that typed width over the generic character
        // suffix mapping, which treats every `-s` as 32 bits and would select
        // the DB opcode for 16-bit integer forms.
        if (info.suffix_width)
        {
            suffix_width = info.suffix_width;
        }
        if ((!info.operand_count && info.opcode != ASSEMBLY_OPCODE_X86_RET) || info.opcode == ASSEMBLY_OPCODE_X86_JCC ||
            info.opcode == ASSEMBLY_OPCODE_X86_SETCC)
        {
            return false;
        }
        if (suffix == 'l' &&
            (info.opcode == ASSEMBLY_OPCODE_X86_FLD || info.opcode == ASSEMBLY_OPCODE_X86_FST ||
             info.opcode == ASSEMBLY_OPCODE_X86_FSTP ||
             (info.opcode >= ASSEMBLY_OPCODE_X86_FADD && info.opcode <= ASSEMBLY_OPCODE_X86_FDIVR) ||
             (info.opcode >= ASSEMBLY_OPCODE_X86_FCOM && info.opcode <= ASSEMBLY_OPCODE_X86_FCMOVCC)))
        {
            suffix_width = 64;
        }
    }
    else if (!buster_x86_metadata_lookup_mnemonic(candidate).count ||
             !assembly_x86_metadata_mnemonic_has_visible_operands(candidate))
    {
        return false;
    }
    if (assembly_x86_metadata_relative_mnemonic(candidate) && !assembly_word_equal(candidate, S8("jmp")) &&
        !assembly_word_equal(candidate, S8("call")) && !assembly_word_equal(candidate, S8("call_near")))
    {
        return false;
    }
    *base = candidate;
    if (base_info)
    {
        *base_info = info;
    }
    *width = suffix_width;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_suffix_applies(AssemblyOpcode opcode, u32 operand_index, u32 operand_count)
{
    if (opcode == ASSEMBLY_OPCODE_X86_LEA || assembly_x86_opcode_is_rotate(opcode) ||
        opcode == ASSEMBLY_OPCODE_X86_MOVZX || opcode == ASSEMBLY_OPCODE_X86_MOVSX || opcode == ASSEMBLY_OPCODE_X86_MOVSXD)
    {
        return operand_index == 0;
    }
    if (opcode == ASSEMBLY_OPCODE_X86_SHLD || opcode == ASSEMBLY_OPCODE_X86_SHRD)
    {
        return operand_index < 2;
    }
    if (assembly_x86_opcode_is_shift(opcode))
    {
        // An explicit literal one is normalized away before metadata
        // selection.  In that ONE() topology the remaining data operand is
        // still the suffix-described operand.
        return operand_count == 1 ? operand_index == 0 : operand_index + 1 < operand_count;
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_suffix_width_matches(AssemblyInstructionInfo info, u8 suffix_width,
                                                                      AssemblyOperand const* operands,
                                                                      BusterX86MetadataPhysicalOperand* physical,
                                                                      u32 operand_count)
{
    bool saw_width_operand = false;
    for (u32 operand_index = 0; operand_index < operand_count; operand_index += 1)
    {
        if (!assembly_x86_metadata_suffix_applies(info.opcode, operand_index, operand_count))
        {
            continue;
        }
        AssemblyOperand operand = operands[operand_index];
        if (operand.kind == ASSEMBLY_OPERAND_REGISTER && operand.reg.width != suffix_width)
        {
            return false;
        }
        if (operand.kind == ASSEMBLY_OPERAND_REGISTER)
        {
            saw_width_operand = true;
        }
        if (operand.kind == ASSEMBLY_OPERAND_MEMORY)
        {
            if (operand.memory.width && operand.memory.width != suffix_width)
            {
                return false;
            }
            physical[operand_index].width = suffix_width;
            saw_width_operand = true;
        }
    }
    // A suffix must describe a data-width operand.  This excludes metadata
    // mnemonics whose visible operand is only an immediate or branch target
    // (for example intb), while retaining register and memory aliases such as
    // smswl and pushpq.  PUSH's stack width is implicit, so the immediate-only
    // pushq spelling is the one valid suffix alias in 64-bit mode.
    return saw_width_operand ||
           (info.opcode == ASSEMBLY_OPCODE_X86_PUSH && suffix_width == 64 && operand_count == 1 &&
            operands[0].kind == ASSEMBLY_OPERAND_EXPRESSION);
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataSelectResult assembly_x86_metadata_select_source_form(
    BusterX86MetadataPhysicalQuery query, String8 mnemonic, String8 suffix_base, AssemblyInstructionInfo suffix_info,
    u8 suffix_width, AssemblyOperand const* operands, BusterX86MetadataPhysicalOperand* physical, u32 operand_count,
    String8* selected_mnemonic)
{
    if (selected_mnemonic)
    {
        *selected_mnemonic = mnemonic;
    }
    BusterX86MetadataSelectResult selection = buster_x86_metadata_select_form(query);
    if (selection.status == BUSTER_X86_METADATA_ENCODE_SUCCESS || !suffix_base.length)
    {
        return selection;
    }
    if (!assembly_x86_metadata_suffix_width_matches(suffix_info, suffix_width, operands, physical, operand_count))
    {
        selection.status = BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
        return selection;
    }
    query.mnemonic = suffix_base;
    BusterX86MetadataSelectResult suffix_selection = buster_x86_metadata_select_form(query);
    if (suffix_selection.status == BUSTER_X86_METADATA_ENCODE_SUCCESS && selected_mnemonic)
    {
        *selected_mnemonic = suffix_base;
    }
    return suffix_selection;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_select_symbolic_push_imm32(BusterX86MetadataPhysicalQuery query,
                                                                            BusterX86MetadataSelectResult* selection)
{
    if (selection && selection->status == BUSTER_X86_METADATA_ENCODE_SUCCESS && selection->selected_byte_count < 5)
    {
        bool has_symbol = false;
        for (u32 index = 0; index < query.operand_count; index += 1)
        {
            has_symbol |= query.operands[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE &&
                          query.operands[index].has_symbol;
        }
        if (has_symbol)
        {
            BusterX86MetadataCandidateRange candidates = buster_x86_metadata_lookup_mnemonic(query.mnemonic);
            for (u32 position = 0; position < candidates.count; position += 1)
            {
                u32 form_id = 0;
                BusterX86MetadataForm form = {0};
                if (!buster_x86_metadata_candidate_at(candidates, position, &form_id) || !buster_x86_metadata_form(form_id, &form) ||
                    form.immediate_width != 4 || !form.immediate_signed)
                {
                    continue;
                }
                u8 bytes[64] = {0};
                BusterX86MetadataRelocation relocations[BUSTER_X86_METADATA_EMIT_RELOCATION_CAPACITY] = {0};
                BusterX86MetadataEmitResult emitted = buster_x86_metadata_emit_form(
                    (BusterX86MetadataEmitQuery){
                        .physical = query,
                        .form_id = form_id,
                        .output = bytes,
                        .output_capacity = BUSTER_ARRAY_LENGTH(bytes),
                        .relocations = relocations,
                        .relocation_capacity = BUSTER_ARRAY_LENGTH(relocations),
                    });
                if (emitted.status == BUSTER_X86_METADATA_ENCODE_SUCCESS && emitted.byte_count == 5)
                {
                    selection->form_id = form_id;
                    selection->stable_hash = emitted.stable_hash;
                    selection->selected_byte_count = emitted.byte_count;
                    return true;
                }
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_operand_decorators(BusterX86MetadataPhysicalAttributes* attributes,
                                                                    AssemblyOperand const* operands, u32 operand_count)
{
    for (u32 index = 0; index < operand_count; index += 1)
    {
        AssemblyOperand operand = operands[index];
        if ((operand.has_mask || operand.zeroing || operand.rounding || operand.sae) && index != 0)
        {
            return false;
        }
        if (operand.zeroing && (!operand.has_mask || operand.kind != ASSEMBLY_OPERAND_REGISTER))
        {
            return false;
        }
        if (operand.broadcast && operand.kind != ASSEMBLY_OPERAND_MEMORY)
        {
            return false;
        }
        if (operand.has_mask)
        {
            if (attributes->has_mask_register && attributes->mask_register != operand.mask)
            {
                return false;
            }
            attributes->decorator_flags |= BUSTER_X86_METADATA_DECORATOR_MASK;
            attributes->has_mask_register = true;
            attributes->mask_register = operand.mask;
        }
        if (operand.zeroing)
        {
            attributes->decorator_flags |= BUSTER_X86_METADATA_DECORATOR_ZEROING;
            attributes->zeroing = true;
        }
        if (operand.broadcast)
        {
            if (attributes->broadcast_elements && attributes->broadcast_elements != operand.broadcast)
            {
                return false;
            }
            attributes->decorator_flags |= BUSTER_X86_METADATA_DECORATOR_BROADCAST;
            attributes->broadcast_elements = operand.broadcast;
        }
        if (operand.rounding)
        {
            if (attributes->rounding_mode && attributes->rounding_mode != operand.rounding)
            {
                return false;
            }
            attributes->decorator_flags |= BUSTER_X86_METADATA_DECORATOR_ROUNDING;
            attributes->rounding_mode = operand.rounding;
            attributes->sae = true;
            attributes->decorator_flags |= BUSTER_X86_METADATA_DECORATOR_SAE;
        }
        else if (operand.sae)
        {
            attributes->decorator_flags |= BUSTER_X86_METADATA_DECORATOR_SAE;
            attributes->sae = true;
        }
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_physical_has_duplicate_registers(BusterX86MetadataPhysicalOperand const* operands,
                                                                                 u32 operand_count)
{
    for (u32 left = 0; left < operand_count; left += 1)
    {
        if (operands[left].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER)
        {
            continue;
        }
        for (u32 right = left + 1; right < operand_count; right += 1)
        {
            if (operands[right].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
                operands[left].reg.physical_class == operands[right].reg.physical_class &&
                operands[left].reg.index == operands[right].reg.index &&
                operands[left].reg.width == operands[right].reg.width)
            {
                return true;
            }
        }
    }
    return false;
}

// A typed EVEX decorator is source-level evidence that the metadata candidate
// is the intended instruction shape.  The handwritten parser can still report
// INVALID_OPERANDS for canonical census witnesses that deliberately reuse
// registers, and the feature-selection path historically downgraded a
// feature failure for the same reason.  Keep those legacy fallbacks for
// ordinary syntax, but let this metadata-proven semantic shape remain
// authoritative.  The predicate deliberately accepts maskless standalone SAE
// forms as well as MASKmskw forms; the form/attribute contract, not a mnemonic
// or census identity, determines eligibility.
BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_typed_decorator_authoritative(
    BusterX86MetadataForm form, BusterX86MetadataPhysicalQuery query)
{
    return buster_x86_metadata_typed_decorator_authoritative(form, query);
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_statement_has_extended_gpr(String8 statement);

BUSTER_GLOBAL_LOCAL BusterX86MetadataEncodeStatus assembly_x86_metadata_instruction_parse(
    AssemblyBuilder* builder, String8 statement, u32 line, u32 column, u64 offset, Target target, AssemblySyntax syntax)
{
    builder->metadata_failure_typed_decorator_authoritative = false;
    if (target.cpu_arch != CPU_ARCH_X86_64)
    {
        return BUSTER_X86_METADATA_ENCODE_UNKNOWN_MNEMONIC;
    }
    // FINIT/FCLEX and the FST* control-store aliases are the architectural
    // WAIT-prefixed aliases of metadata-native FN* forms.  Expand each source
    // instruction into two checked metadata instructions so the 0x9B wait
    // prefix remains metadata-produced rather than resurrecting a handwritten
    // opcode path.  The latter aliases retain their operands while replacing
    // only the mnemonic (for example `fstcw (%rax)` -> `fnstcw (%rax)`).
    String8 trimmed_statement = assembly_trim(statement);
    u64 first_space = 0;
    while (first_space < trimmed_statement.length && !assembly_space(trimmed_statement.pointer[first_space])) first_space += 1;
    String8 first_word = string_slice(trimmed_statement, 0, first_space);
    String8 wait_alias = {0};
    if (assembly_word_equal(first_word, S8("finit"))) wait_alias = S8("fninit");
    else if (assembly_word_equal(first_word, S8("fclex"))) wait_alias = S8("fnclex");
    else if (assembly_word_equal(first_word, S8("fstcw"))) wait_alias = S8("fnstcw");
    else if (assembly_word_equal(first_word, S8("fstenv"))) wait_alias = S8("fnstenv");
    else if (assembly_word_equal(first_word, S8("fsave"))) wait_alias = S8("fnsave");
    else if (assembly_word_equal(first_word, S8("fstsw"))) wait_alias = S8("fnstsw");
    if (wait_alias.length)
    {
        BusterX86MetadataEncodeStatus wait_status = assembly_x86_metadata_instruction_parse(
            builder, S8("fwait"), line, column, offset, target, syntax);
        if (wait_status != BUSTER_X86_METADATA_ENCODE_SUCCESS)
        {
            return wait_status;
        }
        if (first_space == trimmed_statement.length)
        {
            return assembly_x86_metadata_instruction_parse(builder, wait_alias, line, column, offset + 1, target, syntax);
        }
        String8 alias_operands = assembly_trim((String8){.pointer = trimmed_statement.pointer + first_space,
                                                          .length = trimmed_statement.length - first_space});
        String8 alias_statement = string_format(builder->arena, S8("{S8} {S8}"), wait_alias, alias_operands);
        return assembly_x86_metadata_instruction_parse(builder, alias_statement, line, column, offset + 1, target, syntax);
    }
    // The condition-code aliases the metadata mnemonic table does not spell.
    // `ja` and `jnbe` are one instruction, and hand-written assembly uses
    // whichever reads better at the site, so the alias is rewritten to the
    // canonical spelling the checked selector knows rather than reported as
    // an unknown instruction.
    static const struct
    {
        String8 alias;
        String8 canonical;
    } metadata_condition_aliases[] = {
        {S8_INITIALIZER("c"), S8_INITIALIZER("b")},     {S8_INITIALIZER("nae"), S8_INITIALIZER("b")},
        {S8_INITIALIZER("ae"), S8_INITIALIZER("nb")},   {S8_INITIALIZER("nc"), S8_INITIALIZER("nb")},
        {S8_INITIALIZER("e"), S8_INITIALIZER("z")},     {S8_INITIALIZER("ne"), S8_INITIALIZER("nz")},
        {S8_INITIALIZER("na"), S8_INITIALIZER("be")},
        {S8_INITIALIZER("a"), S8_INITIALIZER("nbe")},   {S8_INITIALIZER("pe"), S8_INITIALIZER("p")},
        {S8_INITIALIZER("po"), S8_INITIALIZER("np")},   {S8_INITIALIZER("nge"), S8_INITIALIZER("l")},
        {S8_INITIALIZER("ge"), S8_INITIALIZER("nl")},   {S8_INITIALIZER("ng"), S8_INITIALIZER("le")},
        {S8_INITIALIZER("g"), S8_INITIALIZER("nle")},
    };
    static String8 const metadata_condition_families[] = {S8_INITIALIZER("j"), S8_INITIALIZER("set"), S8_INITIALIZER("cmov")};
    for (u32 family_index = 0; family_index < BUSTER_ARRAY_LENGTH(metadata_condition_families); family_index += 1)
    {
        String8 family = metadata_condition_families[family_index];
        if (first_word.length <= family.length || !assembly_word_equal(string_slice(first_word, 0, family.length), family))
        {
            continue;
        }
        String8 condition = string_slice(first_word, family.length, first_word.length);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(metadata_condition_aliases); index += 1)
        {
            if (!assembly_word_equal(condition, metadata_condition_aliases[index].alias))
            {
                continue;
            }
            String8 canonical = string_format(builder->arena, S8("{S8}{S8}"), family, metadata_condition_aliases[index].canonical);
            String8 alias_statement =
                first_space == trimmed_statement.length
                    ? canonical
                    : string_format(builder->arena, S8("{S8} {S8}"), canonical,
                                    assembly_trim(string_slice(trimmed_statement, first_space, trimmed_statement.length)));
            return assembly_x86_metadata_instruction_parse(builder, alias_statement, line, column, offset, target, syntax);
        }
    }
    // The handwritten x87 front end accepts the traditional omitted-operand
    // spellings (for example `fadd` and `fadd st(2)`).  Metadata rows expose
    // the visible stack operand, so materialize the same canonical operands
    // before entering the checked selector.  This keeps the source dialect's
    // non-commutative AT&T direction rules identical to the handwritten
    // normalizer while ensuring the resulting bytes still come from metadata.
    String8 x87_alias_mnemonic = first_word;
    String8 x87_alias_operands = {0};
    bool x87_alias_rewrite = false;
    bool x87_alias_att = syntax == ASSEMBLY_SYNTAX_ATT;
    bool x87_arithmetic = assembly_word_equal(first_word, S8("fadd")) || assembly_word_equal(first_word, S8("fmul")) ||
                          assembly_word_equal(first_word, S8("fsub")) || assembly_word_equal(first_word, S8("fsubr")) ||
                          assembly_word_equal(first_word, S8("fdiv")) || assembly_word_equal(first_word, S8("fdivr"));
    bool x87_pop_arithmetic = assembly_word_equal(first_word, S8("faddp")) || assembly_word_equal(first_word, S8("fmulp")) ||
                              assembly_word_equal(first_word, S8("fsubp")) || assembly_word_equal(first_word, S8("fsubrp")) ||
                              assembly_word_equal(first_word, S8("fdivp")) || assembly_word_equal(first_word, S8("fdivrp"));
    bool x87_omitted_register = assembly_word_equal(first_word, S8("fxch")) || assembly_word_equal(first_word, S8("fcom")) ||
                                assembly_word_equal(first_word, S8("fcomp")) || assembly_word_equal(first_word, S8("fucom")) ||
                                assembly_word_equal(first_word, S8("fucomp"));
    String8 x87_one_operand = assembly_trim((String8){.pointer = trimmed_statement.pointer + first_space,
                                                       .length = trimmed_statement.length - first_space});
    AssemblyRegister x87_one_register = {0};
    bool x87_one_register_source = x87_one_operand.length && assembly_register_parse(x87_one_operand, syntax, &x87_one_register) &&
                                   x87_one_register.class == ASSEMBLY_REGISTER_X87;
    if (!x87_one_operand.length)
    {
        if (x87_arithmetic)
        {
            x87_alias_mnemonic = assembly_word_equal(first_word, S8("fadd"))   ? S8("faddp")
                                 : assembly_word_equal(first_word, S8("fmul")) ? S8("fmulp")
                                 : assembly_word_equal(first_word, S8("fsub")) ? S8("fsubp")
                                 : assembly_word_equal(first_word, S8("fsubr")) ? S8("fsubrp")
                                 : assembly_word_equal(first_word, S8("fdiv")) ? S8("fdivp")
                                                                                 : S8("fdivrp");
            x87_alias_rewrite = true;
        }
        else if (x87_pop_arithmetic)
        {
            x87_alias_mnemonic = first_word;
            x87_alias_rewrite = true;
        }
        else if (x87_omitted_register)
        {
            x87_alias_rewrite = true;
        }
        if (x87_alias_rewrite)
        {
            // Metadata rows for FXCH/FCOM-style aliases keep ST0 as the
            // fixed ModRM.reg operand.  Intel's source spelling is written
            // destination-first, so preserve that hidden ST0 position when
            // materializing an omitted operand; ATT is reversed by the
            // ordinary source parser and keeps its established order.
            x87_alias_operands = x87_alias_att ? (x87_arithmetic || x87_pop_arithmetic ? S8("%st, %st(1)") : S8("%st(1), %st"))
                                               : (x87_omitted_register ? S8("st(0), st(1)") : S8("st(1), st(0)"));
        }
    }
    else if (x87_one_register_source && (x87_arithmetic || x87_pop_arithmetic))
    {
        x87_alias_mnemonic = first_word;
        x87_alias_rewrite = true;
        x87_alias_operands = x87_alias_att ? string_format(builder->arena, S8("{S8}, %st"), x87_one_operand)
                                           : string_format(builder->arena, S8("st(0), {S8}"), x87_one_operand);
        if (x87_pop_arithmetic)
        {
            x87_alias_operands = x87_alias_att ? string_format(builder->arena, S8("%st, {S8}"), x87_one_operand)
                                               : string_format(builder->arena, S8("{S8}, st(0)"), x87_one_operand);
        }
    }
    if (x87_alias_rewrite)
    {
        String8 alias_statement = string_format(builder->arena, S8("{S8} {S8}"), x87_alias_mnemonic, x87_alias_operands);
        return assembly_x86_metadata_instruction_parse(builder, alias_statement, line, column, offset, target, syntax);
    }
    bool lock = false;
    bool rep = false;
    bool repne = false;
    bool notrack = false;
    u8 segment_override = BUSTER_X86_METADATA_SEGMENT_NONE;
    bool segment_override_seen = false;
    bool source_address_size_seen = false;
    u8 source_address_size = 64;
    String8 work = assembly_trim(statement);
    for (;;)
    {
        u64 prefix_end = 0;
        while (prefix_end < work.length && !assembly_space(work.pointer[prefix_end])) prefix_end += 1;
        String8 prefix = string_slice(work, 0, prefix_end);
        if (assembly_word_equal(prefix, S8("lock")))
        {
            if (lock)
            {
                return BUSTER_X86_METADATA_ENCODE_PREFIX_COMBINATION;
            }
            lock = true;
        }
        else if (assembly_word_equal(prefix, S8("rep")) || assembly_word_equal(prefix, S8("repe")) ||
                 assembly_word_equal(prefix, S8("repz")))
        {
            if (rep || repne)
            {
                return BUSTER_X86_METADATA_ENCODE_PREFIX_COMBINATION;
            }
            rep = true;
        }
        else if (assembly_word_equal(prefix, S8("repne")) || assembly_word_equal(prefix, S8("repnz")))
        {
            if (rep || repne)
            {
                return BUSTER_X86_METADATA_ENCODE_PREFIX_COMBINATION;
            }
            repne = true;
        }
        else if (assembly_word_equal(prefix, S8("notrack")))
        {
            if (notrack)
            {
                return BUSTER_X86_METADATA_ENCODE_PREFIX_COMBINATION;
            }
            notrack = true;
        }
        else if (assembly_word_equal(prefix, S8("addr32")))
        {
            if (source_address_size_seen)
            {
                // Address-size prefixes are source-level instruction
                // modifiers.  A duplicate or conflicting modifier must not
                // silently select a different EAMODE row.
                return BUSTER_X86_METADATA_ENCODE_ADDRESSING;
            }
            source_address_size = 32;
            source_address_size_seen = true;
        }
        else
        {
            u8 requested_segment = BUSTER_X86_METADATA_SEGMENT_NONE;
            if (!assembly_x86_segment_parse(prefix, ASSEMBLY_SYNTAX_INTEL, &requested_segment))
            {
                break;
            }
            if (segment_override_seen)
            {
                return BUSTER_X86_METADATA_ENCODE_PREFIX_COMBINATION;
            }
            segment_override = requested_segment;
            segment_override_seen = true;
        }
        work = assembly_trim(string_slice(work, prefix_end, work.length));
    }
    bool no_flags = false;
    if (work.length && work.pointer[0] == '{')
    {
        u64 end = 1;
        while (end < work.length && work.pointer[end] != '}') end += 1;
        if (end >= work.length || !assembly_word_equal(assembly_trim(string_slice(work, 1, end)), S8("nf")))
        {
            return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
        }
        no_flags = true;
        work = assembly_trim(string_slice(work, end + 1, work.length));
    }
    u64 mnemonic_end = 0;
    while (mnemonic_end < work.length && !assembly_space(work.pointer[mnemonic_end])) mnemonic_end += 1;
    String8 source_mnemonic = string_slice(work, 0, mnemonic_end);
    u16 att_scalar_extend_source_width = syntax == ASSEMBLY_SYNTAX_ATT
                                            ? assembly_x86_metadata_att_scalar_extend_source_width(source_mnemonic)
                                            : 0;
    String8 metadata_source_mnemonic = assembly_x86_metadata_att_string_alias(syntax, source_mnemonic);
    String8 mnemonic = assembly_x86_metadata_mnemonic(metadata_source_mnemonic);
    String8 mnemonic_suffix_base = {0};
    AssemblyInstructionInfo mnemonic_suffix_info = {.opcode = ASSEMBLY_OPCODE_COUNT};
    u8 mnemonic_suffix_width = 0;
    bool has_suffix_alias = assembly_x86_metadata_suffix_alias(target, syntax, source_mnemonic, &mnemonic_suffix_base,
                                                                &mnemonic_suffix_info, &mnemonic_suffix_width);
    bool has_mnemonic = mnemonic.length && buster_x86_metadata_lookup_mnemonic(mnemonic).count;
    if (!has_mnemonic)
    {
        if (!has_suffix_alias)
        {
            return BUSTER_X86_METADATA_ENCODE_UNKNOWN_MNEMONIC;
        }
        mnemonic = mnemonic_suffix_base;
        mnemonic = assembly_x86_metadata_mnemonic(mnemonic);
    }
    else if (!has_suffix_alias)
    {
        mnemonic_suffix_base = (String8){0};
    }
    bool suffix_alias_selected = !has_mnemonic && has_suffix_alias;
    String8 operands_text = assembly_trim(string_slice(work, mnemonic_end, work.length));
    u8 leading_rounding = 0;
    bool leading_sae = false;
    if (operands_text.length && operands_text.pointer[0] == '{')
    {
        u64 end = 1;
        while (end < operands_text.length && operands_text.pointer[end] != '}') end += 1;
        if (end >= operands_text.length)
        {
            return BUSTER_X86_METADATA_ENCODE_DECORATOR;
        }
        String8 decorator = assembly_trim(string_slice(operands_text, 1, end));
        leading_rounding = assembly_word_equal(decorator, S8("rn-sae")) ? BUSTER_X86_METADATA_ROUNDING_NEAREST
                          : assembly_word_equal(decorator, S8("rd-sae")) ? BUSTER_X86_METADATA_ROUNDING_DOWN
                          : assembly_word_equal(decorator, S8("ru-sae")) ? BUSTER_X86_METADATA_ROUNDING_UP
                          : assembly_word_equal(decorator, S8("rz-sae")) ? BUSTER_X86_METADATA_ROUNDING_ZERO
                                                                          : 0;
        leading_sae = assembly_word_equal(decorator, S8("sae")) || leading_rounding != 0;
        if (!leading_sae)
        {
            return BUSTER_X86_METADATA_ENCODE_DECORATOR;
        }
        operands_text = assembly_trim(string_slice(operands_text, end + 1, operands_text.length));
        if (operands_text.length && operands_text.pointer[0] == ',')
        {
            operands_text = assembly_trim(string_slice(operands_text, 1, operands_text.length));
        }
    }
    AssemblyOperand operands[ASSEMBLY_MAX_OPERANDS] = {0};
    u32 operand_count = 0;
    u64 operand_start = 0;
    bool relative = assembly_x86_metadata_relative_mnemonic(mnemonic);
    u8 branch_hint = BUSTER_X86_METADATA_BRANCH_HINT_NONE;
    u8 implicit_segment = segment_override;
    if (segment_override == BUSTER_X86_METADATA_SEGMENT_CS)
    {
        if (relative)
        {
            branch_hint = BUSTER_X86_METADATA_BRANCH_HINT_NOT_TAKEN;
            implicit_segment = BUSTER_X86_METADATA_SEGMENT_NONE;
        }
    }
    else if (segment_override == BUSTER_X86_METADATA_SEGMENT_DS)
    {
        if (relative)
        {
            branch_hint = BUSTER_X86_METADATA_BRANCH_HINT_TAKEN;
            implicit_segment = BUSTER_X86_METADATA_SEGMENT_NONE;
        }
    }
    bool mnemonic_requires_dfv = assembly_x86_metadata_mnemonic_requires_dfv(mnemonic);
    u32 symbol_count_before_dfv = builder->result.symbol_count;
    bool has_dfv = false;
    u8 dfv = 0;
    while (operand_start < operands_text.length)
    {
        if (operand_count >= BUSTER_ARRAY_LENGTH(operands))
        {
            return BUSTER_X86_METADATA_ENCODE_WRONG_OPERAND_COUNT;
        }
        String8 text = {0};
        if (assembly_operand_split_next(operands_text, &operand_start, &text) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
        {
            return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
        }
        // Metadata-only EVEX mnemonics do not pass through the handwritten
        // vector parser, but they use the same standalone SAE/rounding token
        // placement: Intel after the visible operands (or before an
        // immediate), and AT&T after the immediate.  Consume that token here
        // so it becomes the typed query attribute instead of being sent to
        // the expression parser.  Form selection remains the authority for
        // whether the selected metadata row actually permits the control.
        if (text.length >= 3 && text.pointer[0] == '{' && text.pointer[text.length - 1] == '}')
        {
            String8 decorator = assembly_trim(string_slice(text, 1, text.length - 1));
            u8 pseudo_rounding = assembly_word_equal(decorator, S8("rn-sae")) ? BUSTER_X86_METADATA_ROUNDING_NEAREST
                               : assembly_word_equal(decorator, S8("rd-sae")) ? BUSTER_X86_METADATA_ROUNDING_DOWN
                               : assembly_word_equal(decorator, S8("ru-sae")) ? BUSTER_X86_METADATA_ROUNDING_UP
                               : assembly_word_equal(decorator, S8("rz-sae")) ? BUSTER_X86_METADATA_ROUNDING_ZERO
                                                                                : 0;
            bool pseudo_sae = assembly_word_equal(decorator, S8("sae")) || pseudo_rounding != 0;
            if (pseudo_sae)
            {
                if (leading_sae || (syntax == ASSEMBLY_SYNTAX_ATT && operand_count == 0))
                    return BUSTER_X86_METADATA_ENCODE_DECORATOR;
                leading_rounding = pseudo_rounding;
                leading_sae = true;
                continue;
            }
        }
        bool indirect = syntax == ASSEMBLY_SYNTAX_ATT && relative && text.pointer[0] == '*';
        if (indirect)
        {
            text = assembly_trim(string_slice(text, 1, text.length));
            if (!text.length)
            {
                return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
            }
        }
        AssemblyOperand* operand = operands + operand_count;
        bool operand_no_flags = false;
        if (!assembly_x86_operand_decorators_parse(&text, syntax, operand, &operand_no_flags))
        {
            return BUSTER_X86_METADATA_ENCODE_DECORATOR;
        }
        if (operand_no_flags)
        {
            return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
        }
        bool att_immediate = syntax == ASSEMBLY_SYNTAX_ATT && text.length && text.pointer[0] == '$';
        if (att_immediate)
        {
            text = assembly_trim(string_slice(text, 1, text.length));
        }
        if (!att_immediate && assembly_register_parse(text, syntax, &operand->reg))
        {
            operand->kind = ASSEMBLY_OPERAND_REGISTER;
        }
        else if (!att_immediate && assembly_x86_memory_parse(builder, text, syntax, &operand->memory) &&
                 !(syntax == ASSEMBLY_SYNTAX_ATT && relative && !indirect && operand->memory.absolute))
        {
            operand->kind = ASSEMBLY_OPERAND_MEMORY;
        }
        else
        {
            bool immediate = att_immediate;
            if (!immediate && syntax == ASSEMBLY_SYNTAX_INTEL && text.length && text.pointer[0] == '$')
            {
                return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
            }
            else if (!immediate && syntax == ASSEMBLY_SYNTAX_ATT && !relative)
            {
                return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
            }
            if (!text.length || !assembly_expression_parse(builder, text, &operand->expression))
            {
                return BUSTER_X86_METADATA_ENCODE_INVALID_EXPRESSION;
            }
            operand->kind = ASSEMBLY_OPERAND_EXPRESSION;
        }
        operand_count += 1;
    }
    if (mnemonic_requires_dfv)
    {
        if (!operand_count || !assembly_x86_metadata_parse_dfv(operands[0], &dfv))
        {
            // A rejected symbolic DFV must not intern a source symbol as a
            // side effect of parsing the pseudo-operand.
            builder->result.symbol_count = symbol_count_before_dfv;
            return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
        }
        has_dfv = true;
        for (u32 index = 1; index < operand_count; index += 1)
        {
            operands[index - 1] = operands[index];
        }
        operand_count -= 1;
    }
    bool att_operand_order_exception = syntax == ASSEMBLY_SYNTAX_ATT &&
                                       assembly_x86_metadata_mnemonic_has_att_operand_order_exception(mnemonic);
    if (syntax == ASSEMBLY_SYNTAX_ATT && !att_operand_order_exception)
    {
        for (u32 left = 0; left < operand_count / 2; left += 1)
        {
            AssemblyOperand temporary = operands[left];
            u32 right = operand_count - left - 1;
            operands[left] = operands[right];
            operands[right] = temporary;
        }
    }
    if (syntax == ASSEMBLY_SYNTAX_ATT && operand_count == 2 &&
        operands[0].kind == ASSEMBLY_OPERAND_REGISTER && operands[0].reg.class == ASSEMBLY_REGISTER_X87 &&
        operands[0].reg.index != 0)
    {
        // Metadata rows retain the architectural x87 opcode direction after
        // AT&T's source/destination reversal.  Non-commutative mnemonics
        // therefore swap to their reverse spelling only when the reversed
        // destination is a non-top stack register.
        mnemonic = assembly_word_equal(mnemonic, S8("fsub")) ? S8("fsubr")
                 : assembly_word_equal(mnemonic, S8("fsubr")) ? S8("fsub")
                 : assembly_word_equal(mnemonic, S8("fdiv")) ? S8("fdivr")
                 : assembly_word_equal(mnemonic, S8("fdivr")) ? S8("fdiv")
                 : assembly_word_equal(mnemonic, S8("fsubp")) ? S8("fsubrp")
                 : assembly_word_equal(mnemonic, S8("fsubrp")) ? S8("fsubp")
                 : assembly_word_equal(mnemonic, S8("fdivp")) ? S8("fdivrp")
                 : assembly_word_equal(mnemonic, S8("fdivrp")) ? S8("fdivp")
                                                                  : mnemonic;
    }
    // AMD four-operand vector forms use Intel's source spelling for the
    // selector register and memory operand, while metadata rows expose the
    // ModRM operand before the fixed selector register.  Most mnemonics have
    // both W=0 (memory in slot 2) and W=1 (memory in slot 3) rows, so the
    // source order itself disambiguates them.  The MAC forms publish only a
    // slot-2 memory row; move that source operand ahead of the selector before
    // constructing the physical query.  AT&T has already been reversed into
    // this metadata order above.
    if (operand_count == 4 && operands[2].kind != ASSEMBLY_OPERAND_MEMORY &&
        operands[3].kind == ASSEMBLY_OPERAND_MEMORY)
    {
        BusterX86MetadataCandidateRange amd_candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
        bool has_memory_slot_2 = false;
        bool has_memory_slot_3 = false;
        for (u32 candidate_index = 0; candidate_index < amd_candidates.count; candidate_index += 1)
        {
            u32 form_id = 0;
            BusterX86MetadataForm form = {0};
            if (!buster_x86_metadata_candidate_at(amd_candidates, candidate_index, &form_id) ||
                !buster_x86_metadata_form(form_id, &form) || form.operand_count != operand_count)
            {
                continue;
            }
            BusterX86MetadataOperand slot_2 = {0};
            BusterX86MetadataOperand slot_3 = {0};
            if (!buster_x86_metadata_operand(form_id, 2, &slot_2) || !buster_x86_metadata_operand(form_id, 3, &slot_3))
            {
                continue;
            }
            has_memory_slot_2 |= slot_2.kind == BUSTER_X86_METADATA_OPERAND_MEMORY;
            has_memory_slot_3 |= slot_3.kind == BUSTER_X86_METADATA_OPERAND_MEMORY;
        }
        if (has_memory_slot_2 && !has_memory_slot_3)
        {
            AssemblyOperand temporary = operands[2];
            operands[2] = operands[3];
            operands[3] = temporary;
        }
    }
    // The metadata schema models implicit count-one shift/rotate forms as
    // ONE(), with no visible immediate operand.  Hide an explicit literal `1`
    // accepted by the handwritten syntax front end so both dialects select
    // the canonical one-byte opcode.
    if (!assembly_x86_statement_has_extended_gpr(statement) && operand_count >= 2 &&
        (assembly_word_equal(mnemonic, S8("rol")) || assembly_word_equal(mnemonic, S8("ror")) ||
         assembly_word_equal(mnemonic, S8("rcl")) || assembly_word_equal(mnemonic, S8("rcr")) ||
         assembly_word_equal(mnemonic, S8("shl")) || assembly_word_equal(mnemonic, S8("shr")) ||
         assembly_word_equal(mnemonic, S8("sar"))))
    {
        AssemblyOperand count_operand = operands[operand_count - 1];
        if (count_operand.kind == ASSEMBLY_OPERAND_EXPRESSION && !count_operand.expression.has_symbol &&
            ((count_operand.expression.has_unsigned_addend && count_operand.expression.unsigned_addend == 1) ||
             (!count_operand.expression.has_unsigned_addend && count_operand.expression.addend == 1)))
        {
            operand_count -= 1;
        }
    }
    BusterX86MetadataPhysicalOperand physical[ASSEMBLY_MAX_OPERANDS] = {0};
    bool absolute = assembly_x86_metadata_absolute_mnemonic(mnemonic);
    for (u32 index = 0; index < operand_count; index += 1)
    {
        if (!assembly_x86_metadata_physical_operand(builder, operands[index], relative, absolute,
                                                     physical + index))
        {
            return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
        }
    }
    bool mmx_instruction = false;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
            physical[index].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_MMX)
        {
            mmx_instruction = true;
        }
    }
    if (mmx_instruction)
    {
        // MMX memory operands use the generated row's element width.  Packed
        // byte/word operations (PUNPCKLBW, PACKSSWB, PCMPGTB, ...) differ
        // from qword rows such as PADDB/PADDQ, so a blanket 64-bit default
        // rejects otherwise valid unqualified Intel/AT&T memory spellings.
        // Infer the width from the MMX candidate's published memory shape;
        // explicit source qualifiers remain authoritative and are validated
        // by the selector.
        BusterX86MetadataCandidateRange mmx_candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY || physical[index].width ||
                operands[index].memory.width_explicit)
            {
                continue;
            }
            u16 inferred_width = 0;
            for (u32 candidate_index = 0; candidate_index < mmx_candidates.count; candidate_index += 1)
            {
                u32 form_id = 0;
                BusterX86MetadataForm form = {0};
                if (!buster_x86_metadata_candidate_at(mmx_candidates, candidate_index, &form_id) ||
                    !buster_x86_metadata_form(form_id, &form) || form.operand_count != operand_count)
                {
                    continue;
                }
                bool has_mmx_register = false;
                u16 candidate_memory_width = 0;
                for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
                {
                    BusterX86MetadataOperand metadata_operand = {0};
                    if (!buster_x86_metadata_operand(form_id, operand_index, &metadata_operand))
                    {
                        continue;
                    }
                    if (metadata_operand.kind == BUSTER_X86_METADATA_OPERAND_REGISTER &&
                        metadata_operand.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_MMX)
                    {
                        has_mmx_register = true;
                    }
                    if (metadata_operand.kind == BUSTER_X86_METADATA_OPERAND_MEMORY)
                    {
                        u16 width_flags = metadata_operand.physical_width_flags;
                        candidate_memory_width = width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_8
                                                    ? 8
                                                    : width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_16
                                                        ? 16
                                                        : width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_32
                                                            ? 32
                                                            : width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_64 ? 64 : 0;
                    }
                }
                if (!has_mmx_register || !candidate_memory_width)
                {
                    continue;
                }
                if (!inferred_width)
                {
                    inferred_width = candidate_memory_width;
                }
                else if (inferred_width != candidate_memory_width)
                {
                    inferred_width = UINT16_MAX;
                    break;
                }
            }
            if (inferred_width && inferred_width != UINT16_MAX)
            {
                physical[index].width = inferred_width;
            }
        }
    }
    u16 vector_memory_width = 0;
    // LWPINS/LWPVAL carry a fixed dword memory element but AT&T source has
    // no ptr qualifier.  Keep this scalar width available even though these
    // forms have a GPR destination rather than an XMM/YMM/ZMM vector.
    u16 scalar_memory_width = (assembly_word_equal(mnemonic, S8("lwpins")) ||
                               assembly_word_equal(mnemonic, S8("lwpval")))
                                  ? 32
                                  : 0;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
            (physical[index].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_XMM ||
             physical[index].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_YMM ||
             physical[index].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM))
        {
            vector_memory_width = physical[index].reg.width;
            break;
        }
    }
    if (vector_memory_width || scalar_memory_width)
    {
        if (!scalar_memory_width && (assembly_word_equal(mnemonic, S8("vpslld")) || assembly_word_equal(mnemonic, S8("vpsrld"))))
            scalar_memory_width = 32;
        else if (!scalar_memory_width && mnemonic.length >= 2 && mnemonic.pointer[mnemonic.length - 2] == 's' && mnemonic.pointer[mnemonic.length - 1] == 's')
            scalar_memory_width = 32;
        else if (!scalar_memory_width && mnemonic.length >= 2 && mnemonic.pointer[mnemonic.length - 2] == 's' && mnemonic.pointer[mnemonic.length - 1] == 'd')
            scalar_memory_width = 64;
        else if (!scalar_memory_width && ((mnemonic.length >= 2 && mnemonic.pointer[mnemonic.length - 2] == 'p' && mnemonic.pointer[mnemonic.length - 1] == 'd') ||
                 assembly_word_equal(mnemonic, S8("vmovapd")) || assembly_word_equal(mnemonic, S8("vmovupd"))))
            scalar_memory_width = 64;
        else if (!scalar_memory_width && ((mnemonic.length >= 2 && mnemonic.pointer[mnemonic.length - 2] == 'p' && mnemonic.pointer[mnemonic.length - 1] == 's') ||
                 assembly_word_equal(mnemonic, S8("vmovaps")) || assembly_word_equal(mnemonic, S8("vmovups"))))
            scalar_memory_width = 32;
        else if (!scalar_memory_width && (assembly_word_equal(mnemonic, S8("vmovdqa32")) || assembly_word_equal(mnemonic, S8("vmovdqu32"))))
            scalar_memory_width = 32;
        else if (!scalar_memory_width && (assembly_word_equal(mnemonic, S8("vmovdqa64")) || assembly_word_equal(mnemonic, S8("vmovdqu64"))))
            scalar_memory_width = 64;
        else if (!scalar_memory_width && assembly_word_equal(mnemonic, S8("vmovdqu8")))
            scalar_memory_width = 8;
        else if (!scalar_memory_width && assembly_word_equal(mnemonic, S8("vmovdqu16")))
            scalar_memory_width = 16;
        else if (!scalar_memory_width && assembly_word_equal(mnemonic, S8("vcvtbf42hf8")))
            scalar_memory_width = vector_memory_width / 2;
        if (!scalar_memory_width)
        {
            // AMD/XOP and FMA4 rows publish the scalar memory element on the
            // generated operand (for example i16 for VPMACSSWW and f32 for
            // VFMADDPS) even though the legacy parser records the aggregate
            // vector qualifier.  Infer a width only when every memory form
            // for this mnemonic agrees; unknown/ambiguous rows remain
            // unresolved for the metadata selector.
            BusterX86MetadataCandidateRange vector_candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
            u16 candidate_memory_width = 0;
            bool candidate_memory_width_ambiguous = false;
            for (u32 candidate_index = 0; candidate_index < vector_candidates.count; candidate_index += 1)
            {
                u32 form_id = 0;
                BusterX86MetadataForm form = {0};
                if (!buster_x86_metadata_candidate_at(vector_candidates, candidate_index, &form_id) ||
                    !buster_x86_metadata_form(form_id, &form) || form.operand_count != operand_count)
                {
                    continue;
                }
                for (u32 form_operand_index = 0; form_operand_index < form.operand_count; form_operand_index += 1)
                {
                    BusterX86MetadataOperand metadata_operand = {0};
                    if (!buster_x86_metadata_operand(form_id, form_operand_index, &metadata_operand) ||
                        metadata_operand.kind != BUSTER_X86_METADATA_OPERAND_MEMORY)
                    {
                        continue;
                    }
                    u16 width_flags = metadata_operand.physical_width_flags;
                    u16 width = width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_8
                                     ? 8
                                     : width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_16
                                         ? 16
                                         : width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_32
                                             ? 32
                                             : width_flags == BUSTER_X86_METADATA_PHYSICAL_WIDTH_64 ? 64 : 0;
                    if (!width)
                    {
                        continue;
                    }
                    if (!candidate_memory_width)
                    {
                        candidate_memory_width = width;
                    }
                    else if (candidate_memory_width != width)
                    {
                        candidate_memory_width_ambiguous = true;
                    }
                }
            }
            if (!candidate_memory_width_ambiguous)
            {
                scalar_memory_width = candidate_memory_width;
            }
        }
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY)
            {
                continue;
            }
            bool explicit_width = operands[index].memory.width_explicit;
            if (explicit_width && physical[index].memory.source_width > 64)
            {
                bool conversion_source_width = false;
                BusterX86MetadataCandidateRange conversion_candidates = buster_x86_metadata_lookup_mnemonic(mnemonic);
                for (u32 candidate_index = 0; candidate_index < conversion_candidates.count; candidate_index += 1)
                {
                    u32 form_id = 0;
                    BusterX86MetadataForm form = {0};
                    if (buster_x86_metadata_candidate_at(conversion_candidates, candidate_index, &form_id) &&
                        buster_x86_metadata_form(form_id, &form) &&
                        assembly_word_equal(buster_x86_metadata_string_span(form.category), S8("CONVERT")))
                    {
                        conversion_source_width = true;
                        break;
                    }
                }
                if (conversion_source_width)
                {
                    // The selector projects and validates this qualifier from
                    // each compatible conversion row. Do not compare it with
                    // the destination vector width in the syntax adapter.
                    continue;
                }
                // A two-operand EVEX vector load may read a half tuple (or a
                // full tuple wider than its destination). Keep the source
                // qualifier for candidate-specific tuple validation instead of
                // equating it with the first vector register's width.
                bool evex_vector_load = operand_count == 2 && index == 1 &&
                                        physical[0].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
                                        (physical[0].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_XMM ||
                                         physical[0].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_YMM ||
                                         physical[0].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM) &&
                                        (operands[0].has_mask || operands[0].zeroing || operands[1].broadcast ||
                                         physical[0].reg.width == 512 || physical[0].reg.index >= 16);
                if (evex_vector_load)
                {
                    continue;
                }
                // Intel legacy XMM source spells the aggregate memory width
                // directly.  VEX/EVEX/XOP rows and AT&T suffix projection
                // publish a scalar element width while carrying the aggregate
                // width in their vector/register topology.
                if (syntax == ASSEMBLY_SYNTAX_INTEL &&
                    (!mnemonic.length || assembly_ascii_lower(mnemonic.pointer[0]) != 'v'))
                {
                    continue;
                }
                if (assembly_word_equal(mnemonic, S8("vcvtbf42hf8")) &&
                    physical[index].memory.source_width != vector_memory_width / 2)
                {
                    return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
                }
                if (assembly_word_equal(mnemonic, S8("vcvtbf42hf8")) &&
                    physical[index].memory.source_width == vector_memory_width / 2)
                {
                    physical[index].memory.source_width = 0;
                    physical[index].width = vector_memory_width / 2;
                    continue;
                }
                if ((assembly_word_equal(mnemonic, S8("vpslld")) || assembly_word_equal(mnemonic, S8("vpsrld"))) &&
                    physical[index].memory.source_width == 128 && vector_memory_width >= 256)
                {
                    physical[index].memory.source_width = 0;
                    physical[index].width = 32;
                    continue;
                }
                if (physical[index].memory.source_width != vector_memory_width)
                {
                    return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
                }
                // The handwritten parser already validated the aggregate
                // qualifier against the vector register.  VEX metadata rows
                // carry that width in VL and expose only the scalar element
                // atom to the encoder; retain the validation while removing
                // the aggregate token from the physical query.
                physical[index].memory.source_width = 0;
                physical[index].width = scalar_memory_width;
            }
            else if (!physical[index].width && !explicit_width)
            {
                physical[index].width = scalar_memory_width;
            }
        }
    }
    if (att_scalar_extend_source_width)
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY && !physical[index].width)
            {
                physical[index].width = att_scalar_extend_source_width;
            }
        }
    }
    if (mnemonic.length >= 3 && (mnemonic.pointer[0] == 's' || mnemonic.pointer[0] == 'S') &&
        (mnemonic.pointer[1] == 'e' || mnemonic.pointer[1] == 'E') && (mnemonic.pointer[2] == 't' || mnemonic.pointer[2] == 'T'))
    {
        // SETcc always stores one byte.  AT&T leaves that width implicit on
        // memory operands, so make the source element explicit for metadata.
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY && !physical[index].width)
                physical[index].width = 8;
        }
    }
    // An AT&T mnemonic with no suffix leaves the memory element implicit, and
    // the byte rows need it stated: `mov %al,(%rdi)` is a byte store exactly
    // because its only data register is a byte. Wider widths already resolve
    // through the operand-size attribute, so only the byte case is filled in
    // here, and never for a shift or rotate whose count register is not the
    // data operand.
    bool byte_data_register = false;
    bool wide_data_register = false;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        if (physical[index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER ||
            physical[index].reg.physical_class != BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR)
        {
            continue;
        }
        byte_data_register = byte_data_register || physical[index].reg.width == 8;
        wide_data_register = wide_data_register || physical[index].reg.width != 8;
    }
    if (syntax == ASSEMBLY_SYNTAX_ATT && byte_data_register && !wide_data_register &&
        !assembly_x86_opcode_is_shift(mnemonic_suffix_info.opcode) && !assembly_x86_opcode_is_rotate(mnemonic_suffix_info.opcode))
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY && !physical[index].width)
            {
                physical[index].width = 8;
            }
        }
    }
    if (assembly_word_equal(mnemonic, S8("imul")) && operand_count == 2 &&
        physical[0].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
        physical[1].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE)
    {
        // Intel/AT&T two-operand IMUL is the three-operand form with the
        // destination implicitly repeated as its source.  The metadata schema
        // keeps that source binding visible to the physical query.
        physical[2] = physical[1];
        physical[1] = physical[0];
        operands[2] = operands[1];
        operands[1] = operands[0];
        operand_count = 3;
    }
    bool rotate_mnemonic = assembly_x86_opcode_is_rotate(mnemonic_suffix_info.opcode) ||
                           assembly_word_equal(mnemonic, S8("rol")) || assembly_word_equal(mnemonic, S8("ror")) ||
                           assembly_word_equal(mnemonic, S8("rcl")) || assembly_word_equal(mnemonic, S8("rcr"));
    if (rotate_mnemonic)
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            BusterX86MetadataPhysicalOperand* count = physical + index;
            if (count->kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE && count->has_value && count->value < 0)
            {
                count->unsigned_value = (u64)count->value & UINT64_C(0xff);
                count->has_unsigned_value = true;
                count->has_value = false;
            }
        }
    }
    // Direct symbol-relative calls/jumps/conditions have no link-time range
    // information. Preserve the legacy near form (disp32) and relocation
    // width instead of allowing metadata to choose a short disp8 candidate.
    bool near_symbol_relative = assembly_word_equal(mnemonic, S8("call")) || assembly_word_equal(mnemonic, S8("jmp")) ||
                                assembly_word_equal(mnemonic, S8("xbegin")) ||
                                (mnemonic.length && (mnemonic.pointer[0] == 'j' || mnemonic.pointer[0] == 'J') &&
                                 !assembly_word_equal(mnemonic, S8("jcxz")) && !assembly_word_equal(mnemonic, S8("jecxz")) &&
                                 !assembly_word_equal(mnemonic, S8("jrcxz")));
    if (near_symbol_relative)
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE && physical[index].has_symbol)
            {
                // A label already defined in this source stream can use the
                // canonical short form when the resolved displacement fits.
                // Keep forward/unknown symbols at the near width so an
                // external linker relocation never depends on an 8-bit range.
                u32 symbol_index = assembly_symbol_find(builder, physical[index].symbol);
                bool symbol_defined = symbol_index != UINT32_MAX && builder->result.symbols[symbol_index].defined;
                if (!symbol_defined)
                {
                    physical[index].width = 32;
                }
            }
        }
    }
    // These metadata forms have a fixed memory element width.  Intel permits
    // unsized CLRSSBSY/RSTORSSP memory operands, while AT&T leaves the width
    // implicit for the WRSS/WRUSS rows too.  Normalize the cohort before form
    // selection so both dialects select the same rows, including APX-F CET.
    u16 implicit_memory_width = 0;
    bool cet_unsized_intel = syntax == ASSEMBLY_SYNTAX_INTEL &&
                             (assembly_word_equal(mnemonic, S8("rstorssp")) || assembly_word_equal(mnemonic, S8("clrssbsy")));
    bool implicit_att_memory = syntax == ASSEMBLY_SYNTAX_ATT;
    if (implicit_att_memory && assembly_word_equal(mnemonic, S8("cldemote"))) implicit_memory_width = 8;
    else if (implicit_att_memory && (assembly_word_equal(mnemonic, S8("stmxcsr")) || assembly_word_equal(mnemonic, S8("ldmxcsr"))))
        // MXCSR is one 32-bit control word and AT&T carries no size suffix on
        // the spelling a libc's <fenv.h> uses.
        implicit_memory_width = 32;
    else if (implicit_att_memory &&
             (assembly_word_equal(mnemonic, S8("wrssd")) || assembly_word_equal(mnemonic, S8("wrussd"))))
        implicit_memory_width = 32;
    else if (implicit_att_memory &&
             (assembly_word_equal(mnemonic, S8("wrssq")) || assembly_word_equal(mnemonic, S8("wrussq")) ||
              assembly_word_equal(mnemonic, S8("rstorssp")) || assembly_word_equal(mnemonic, S8("clrssbsy"))))
        implicit_memory_width = 64;
    else if (implicit_att_memory &&
             (assembly_word_equal(mnemonic, S8("bsrmovh")) || assembly_word_equal(mnemonic, S8("bsrmovl"))))
        // BSRMOVH/L's only memory schema is a fixed u64 element.  AT&T has
        // no ptr qualifier, so resolve an unsized memory operand here; an
        // explicit q suffix remains accepted by the generic alias path.
        implicit_memory_width = 64;
    else if (assembly_word_equal(mnemonic, S8("tileloadd")) || assembly_word_equal(mnemonic, S8("tileloaddt1")) ||
             assembly_word_equal(mnemonic, S8("tilestored")))
        // AMX tile rows use one u32 address element even when Intel syntax
        // omits a ptr qualifier.  Resolve the unsized memory before metadata
        // form selection so standard AMX_TILE rows remain distinct from the
        // feature-gated APX siblings.
        implicit_memory_width = 32;
    else if (implicit_att_memory &&
             (assembly_word_equal(mnemonic, S8("tileloaddrs")) || assembly_word_equal(mnemonic, S8("tileloaddrst1"))))
        // AMX MOVRS has one fixed u32 memory schema. AT&T carries no `ptr`
        // qualifier, so resolve the unsized address before metadata selection.
        implicit_memory_width = 32;
    else if (cet_unsized_intel) implicit_memory_width = 64;
    if (implicit_memory_width)
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY && !physical[index].width)
            {
                physical[index].width = implicit_memory_width;
            }
        }
    }
    if (suffix_alias_selected && !assembly_x86_metadata_suffix_width_matches(mnemonic_suffix_info, mnemonic_suffix_width, operands,
                                                                               physical, operand_count))
    {
        return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
    }
    AssemblyInstructionInfo mnemonic_info = {.opcode = ASSEMBLY_OPCODE_COUNT};
    bool is_push_mnemonic = assembly_instruction_lookup(target, syntax, mnemonic, &mnemonic_info) &&
                            mnemonic_info.opcode == ASSEMBLY_OPCODE_X86_PUSH;
    // An unresolved PUSH immediate cannot be proven to fit the short form.
    // Reserve the architectural sign-extended imm32 relocation so linking a
    // normal symbol address does not depend on it happening to fit in 8 bits.
    if (is_push_mnemonic)
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE && physical[index].has_symbol)
            {
                physical[index].width = 32;
            }
        }
    }
    for (u32 immediate_index = 0; immediate_index < operand_count; immediate_index += 1)
    {
        if (physical[immediate_index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE || physical[immediate_index].width)
        {
            continue;
        }
        // IMUL's immediate is a variable signed 8/32-bit field independent
        // of the destination width; SHLD/SHRD and rotate/shift counts are
        // fixed imm8 fields.  Leave those widths unconstrained so metadata
        // can select the canonical short form instead of rejecting a query
        // merely because the data operand is 16/32/64 bits wide.
        if (assembly_word_equal(mnemonic, S8("imul")) || assembly_word_equal(mnemonic, S8("shld")) ||
            assembly_word_equal(mnemonic, S8("shrd")) || assembly_x86_opcode_is_rotate(mnemonic_suffix_info.opcode) ||
            assembly_x86_opcode_is_shift(mnemonic_suffix_info.opcode))
        {
            continue;
        }
        for (u32 source_index = 0; source_index < operand_count; source_index += 1)
        {
            if (source_index == immediate_index)
            {
                continue;
            }
            BusterX86MetadataPhysicalOperand source = physical[source_index];
            u16 width = 0;
            if (source.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
                source.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR && source.reg.width <= 64)
            {
                width = source.reg.width;
            }
            else if (source.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY && source.width && source.width <= 64)
            {
                width = source.width;
            }
            if (width)
            {
                physical[immediate_index].width = width;
                break;
            }
        }
    }
    // GNU as writes an immediate's bit pattern, not its arithmetic value:
    // `movl $0xc2820000,-4(%rsp)` and `or $0x8000,%ax` each name a field whose
    // top bit is set. Re-express such a literal as the signed value that field
    // holds, so form selection sees a width it can encode instead of a
    // magnitude past the signed maximum. Only the 16- and 32-bit widths need
    // it: those are the IMMz fields whose literal is range-checked as signed,
    // while a byte operand's immediate is the operand's own width and the
    // unsigned spelling already fits it.
    for (u32 index = 0; index < operand_count; index += 1)
    {
        BusterX86MetadataPhysicalOperand* immediate = physical + index;
        if (immediate->kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE || !immediate->has_value || immediate->value <= 0 ||
            (immediate->width != 16 && immediate->width != 32))
        {
            continue;
        }
        u64 limit = (u64)1 << immediate->width;
        u64 magnitude = (u64)immediate->value;
        if (magnitude >= limit >> 1 && magnitude < limit)
        {
            immediate->value = (s64)magnitude - (s64)limit;
        }
    }
    BusterX86MetadataPhysicalAttributes attributes = {
        .lock = lock,
        .rep = rep,
        .repne = repne,
        .implicit_segment = implicit_segment,
        .branch_hint = branch_hint,
        .notrack = notrack,
        .no_flags = no_flags,
        .dfv = dfv,
        .has_dfv = has_dfv,
    };
    if (no_flags)
    {
        attributes.apx_flags |= BUSTER_X86_METADATA_APX_NF;
    }
    assembly_x86_metadata_apx_disasm_alias(metadata_source_mnemonic, &attributes);
    bool has_immediate_operand = false;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        has_immediate_operand |= physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE;
    }
    // The three-operand APX spelling is NDD for arithmetic/logical forms.
    // IMUL's three-operand immediate form is the NF-capable legacy/APX row,
    // not NDD; leave it to the immediate-form selector below.
    if (operand_count == 3 &&
        (assembly_word_equal(mnemonic, S8("add")) || assembly_word_equal(mnemonic, S8("adc")) ||
         assembly_word_equal(mnemonic, S8("sub")) || assembly_word_equal(mnemonic, S8("sbb")) ||
         assembly_word_equal(mnemonic, S8("and")) || assembly_word_equal(mnemonic, S8("or")) ||
         assembly_word_equal(mnemonic, S8("xor")) ||
         (assembly_word_equal(mnemonic, S8("imul")) && !has_immediate_operand)))
    {
        attributes.apx_flags |= BUSTER_X86_METADATA_APX_NDD;
    }
    if (assembly_word_equal(mnemonic, S8("imul")) && attributes.apx_flags)
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE || !physical[index].has_value)
                continue;
            if (physical[index].value >= INT8_MIN && physical[index].value <= INT8_MAX) physical[index].width = 8;
        }
    }
    // APX immediate rows interpret the byte as a signed field.  Preserve
    // source literals 0x80..0xff as their architectural low-byte values.
    if (attributes.apx_flags != 0 &&
        (assembly_word_equal(mnemonic, S8("add")) || assembly_word_equal(mnemonic, S8("adc")) ||
         assembly_word_equal(mnemonic, S8("sub")) || assembly_word_equal(mnemonic, S8("sbb")) ||
         assembly_word_equal(mnemonic, S8("and")) || assembly_word_equal(mnemonic, S8("or")) ||
         assembly_word_equal(mnemonic, S8("xor")) || assembly_word_equal(mnemonic, S8("imul")) ||
         assembly_word_equal(mnemonic, S8("shl")) || assembly_word_equal(mnemonic, S8("shr")) ||
         assembly_word_equal(mnemonic, S8("sar"))))
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE || !physical[index].has_value ||
                physical[index].value < 0 || physical[index].value > UINT8_MAX)
                continue;
            physical[index].value = (s64)(s8)(u8)physical[index].value;
            physical[index].width = 8;
        }
    }
    if (assembly_word_equal(mnemonic, S8("vrndscaleps")) || assembly_word_equal(mnemonic, S8("vrndscalepd")))
    {
        for (u32 index = 0; index < operand_count; index += 1)
        {
            if (physical[index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE || !physical[index].has_value ||
                physical[index].value < INT8_MIN || physical[index].value > UINT8_MAX)
                continue;
            physical[index].width = 8;
            if (physical[index].value < 0)
            {
                physical[index].unsigned_value = (u64)(u8)physical[index].value;
                physical[index].has_unsigned_value = true;
                physical[index].has_value = false;
            }
        }
    }
    if (leading_sae)
    {
        attributes.sae = true;
        attributes.decorator_flags |= BUSTER_X86_METADATA_DECORATOR_SAE;
    }
    if (!assembly_x86_metadata_operand_decorators(&attributes, operands, operand_count))
    {
        return BUSTER_X86_METADATA_ENCODE_DECORATOR;
    }
    if (leading_rounding)
    {
        attributes.rounding_mode = leading_rounding;
        attributes.sae = true;
        attributes.decorator_flags |= BUSTER_X86_METADATA_DECORATOR_ROUNDING | BUSTER_X86_METADATA_DECORATOR_SAE;
    }
    String8 feature_names[TARGET_CPU_FEATURE_COUNT] = {0};
    u32 feature_count = assembly_x86_metadata_feature_names(target, feature_names, BUSTER_ARRAY_LENGTH(feature_names));
    assembly_x86_metadata_append_avx10_aliases(target, feature_names, &feature_count, BUSTER_ARRAY_LENGTH(feature_names), physical,
                                                operand_count);
    // XED classifies a subset of legacy MMX rows under SSE2MMX even though
    // the assembler's baseline MMX contract accepts them without SSE2.  The
    // physical query is already restricted to MMX rows above, so supplying
    // the feature token here cannot make an XMM form pass the selector.
    if (mmx_instruction && !target_cpu_feature_has(target, TARGET_CPU_FEATURE_X86_SSE2) &&
        feature_count < BUSTER_ARRAY_LENGTH(feature_names))
    {
        feature_names[feature_count++] = S8("sse2");
    }
    u8 address_size = source_address_size;
    bool memory_address_size_seen = false;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        if (physical[index].kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY)
        {
            continue;
        }
        u8 memory_address_size = physical[index].memory.address_size ? physical[index].memory.address_size : 64;
        if (source_address_size_seen && address_size != memory_address_size)
        {
            return BUSTER_X86_METADATA_ENCODE_ADDRESSING;
        }
        if (memory_address_size_seen && address_size != memory_address_size)
        {
            return BUSTER_X86_METADATA_ENCODE_ADDRESSING;
        }
        address_size = memory_address_size;
        memory_address_size_seen = true;
    }
    BusterX86MetadataPhysicalQuery query = {
        .mnemonic = mnemonic,
        .operands = physical,
        .operand_count = operand_count,
        .features = {.names = feature_names, .count = feature_count},
        .attributes = attributes,
        .address_size = address_size,
        .execution_mode = BUSTER_X86_METADATA_EXECUTION_MODE_64,
        .include_privileged = true,
        .include_not64 = false,
        .include_implicit = operand_count && physical[operand_count - 1].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
                            physical[operand_count - 1].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR &&
                            physical[operand_count - 1].reg.index == 1 && physical[operand_count - 1].reg.width == 8 &&
                            (assembly_word_equal(mnemonic, S8("rol")) || assembly_word_equal(mnemonic, S8("ror")) ||
                             assembly_word_equal(mnemonic, S8("rcl")) || assembly_word_equal(mnemonic, S8("rcr")) ||
                             assembly_word_equal(mnemonic, S8("shld")) || assembly_word_equal(mnemonic, S8("shrd"))),
        .source_semantics = true,
    };
    bool relative_literal = false;
    for (u32 index = 0; index < operand_count; index += 1)
    {
        relative_literal |= physical[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE && !physical[index].has_symbol;
    }
    BusterX86MetadataSelectResult selection = {
        .status = BUSTER_X86_METADATA_ENCODE_INVALID_INPUT,
        .form_id = UINT32_MAX,
        .failure_form_id = UINT32_MAX,
    };
    bool selected = false;
    u32 trial_count = relative_literal ? 15 : 1;
    for (u32 trial_byte_count = 1; trial_byte_count <= trial_count; trial_byte_count += 1)
    {
        BusterX86MetadataPhysicalOperand trial_physical[ASSEMBLY_MAX_OPERANDS] = {0};
        memcpy(trial_physical, physical, operand_count * sizeof(*physical));
        if (relative_literal && !assembly_x86_metadata_adjust_relative_literals(trial_physical, operand_count, offset, trial_byte_count))
        {
            continue;
        }
        query.operands = trial_physical;
        String8 trial_mnemonic = mnemonic;
        BusterX86MetadataSelectResult trial_selection = assembly_x86_metadata_select_source_form(
            query, mnemonic, mnemonic_suffix_base, mnemonic_suffix_info, mnemonic_suffix_width, operands, trial_physical, operand_count,
            &trial_mnemonic);
        if (trial_selection.status == BUSTER_X86_METADATA_ENCODE_SUCCESS &&
            (!relative_literal || trial_selection.selected_byte_count == trial_byte_count))
        {
            if (trial_selection.selected_memory_width && trial_selection.selected_memory_operand < operand_count)
                trial_physical[trial_selection.selected_memory_operand].width = trial_selection.selected_memory_width;
            memcpy(physical, trial_physical, operand_count * sizeof(*physical));
            mnemonic = trial_mnemonic;
            selection = trial_selection;
            selected = true;
            break;
        }
        if (!relative_literal)
        {
            selection = trial_selection;
            break;
        }
    }
    if (!selected && relative_literal)
    {
        query.operands = physical;
        String8 original_mnemonic = mnemonic;
        selection = assembly_x86_metadata_select_source_form(query, mnemonic, mnemonic_suffix_base, mnemonic_suffix_info,
                                                              mnemonic_suffix_width, operands, physical, operand_count, &original_mnemonic);
        if (selection.status == BUSTER_X86_METADATA_ENCODE_SUCCESS)
        {
            selection.status = BUSTER_X86_METADATA_ENCODE_RELATIVE_RANGE;
        }
    }
    if (selection.status != BUSTER_X86_METADATA_ENCODE_SUCCESS)
    {
        BusterX86MetadataForm failure_form = {0};
        bool typed_decorator_authoritative = selection.failure_form_id != UINT32_MAX &&
                                             buster_x86_metadata_form(selection.failure_form_id, &failure_form) &&
                                             assembly_x86_metadata_typed_decorator_authoritative(
                                                 failure_form,
                                                 (BusterX86MetadataPhysicalQuery){
                                                     .operands = physical,
                                                     .operand_count = operand_count,
                                                     .attributes = attributes,
                                                     .address_size = address_size,
                                                     .execution_mode = BUSTER_X86_METADATA_EXECUTION_MODE_64,
                                                    .source_semantics = true,
                                                });
        builder->metadata_failure_typed_decorator_authoritative = typed_decorator_authoritative &&
                                                                   selection.status == BUSTER_X86_METADATA_ENCODE_FEATURE_MODE_PRIVILEGE &&
                                                                   selection.required_feature.length != 0;
        if (selection.status == BUSTER_X86_METADATA_ENCODE_FEATURE_MODE_PRIVILEGE &&
            (!selection.required_feature.length ||
             (assembly_x86_metadata_physical_has_duplicate_registers(physical, operand_count) && query.source_semantics &&
              !typed_decorator_authoritative)))
        {
            return BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH;
        }
        return selection.status;
    }
    if (is_push_mnemonic)
    {
        query.operands = physical;
        assembly_x86_metadata_select_symbolic_push_imm32(query, &selection);
    }
    if (builder->instruction_count >= builder->instruction_capacity)
    {
        return BUSTER_X86_METADATA_ENCODE_OUTPUT_CAPACITY;
    }
    bool private_pc8_long = false;
    if (builder->private_inline_labels && assembly_x86_metadata_private_pc8_mnemonic(mnemonic))
    {
        for (u32 operand_index = 0; !private_pc8_long && operand_index < operand_count; operand_index += 1)
        {
            BusterX86MetadataPhysicalOperand operand = physical[operand_index];
            u32 symbol_index = operand.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE && operand.has_symbol
                                   ? assembly_symbol_find(builder, operand.symbol)
                                   : UINT32_MAX;
            private_pc8_long = symbol_index < builder->result.symbol_count &&
                               !builder->result.symbols[symbol_index].defined &&
                               assembly_inline_private_label_name(builder->result.symbols[symbol_index].name);
        }
    }
    if (private_pc8_long && selection.selected_byte_count > UINT32_MAX - 7u)
    {
        return BUSTER_X86_METADATA_ENCODE_OUTPUT_CAPACITY;
    }
    AssemblyInstruction instruction = {
        .offset = offset,
        .line = line,
        .column = column,
        .size = selection.selected_byte_count + (private_pc8_long ? 7u : 0u),
        .metadata = true,
        .metadata_private_pc8_long = private_pc8_long,
        .metadata_operand_count = (u8)operand_count,
        .metadata_include_implicit = query.include_implicit,
        .metadata_form_id = selection.form_id,
        .metadata_mnemonic = mnemonic,
        .metadata_address_size = address_size,
        .metadata_attributes = attributes,
    };
    if (operand_count)
    {
        memcpy(instruction.metadata_operands, physical, operand_count * sizeof(*physical));
    }
    builder->instructions[builder->instruction_count++] = instruction;
    return BUSTER_X86_METADATA_ENCODE_SUCCESS;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_has_unsigned_expression(AssemblyInstruction instruction)
{
    for (u32 index = 0; index < instruction.operand_count; index += 1)
    {
        AssemblyOperand operand = instruction.operands[index];
        if (operand.kind == ASSEMBLY_OPERAND_EXPRESSION && operand.expression.has_unsigned_addend)
        {
            return true;
        }
        if (operand.kind == ASSEMBLY_OPERAND_MEMORY && operand.memory.displacement.has_unsigned_addend)
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_instruction_is_novel(AssemblyInstruction instruction)
{
    if (assembly_word_equal(instruction.metadata_mnemonic, S8("vcvtbf42hf8")) ||
        assembly_word_equal(instruction.metadata_mnemonic, S8("vpslld")) ||
        assembly_word_equal(instruction.metadata_mnemonic, S8("vpsrld")))
    {
        return true;
    }
    // PUSH immediate is a classic encoding that has no handwritten form yet.
    // Preserve its metadata result instead of restoring the handwritten
    // invalid-operand diagnostic just because the encoding is not an ISA
    // extension.  Metadata selects the signed-imm8 or sign-extended imm32
    // form and carries symbol relocations through to emission.
    if (assembly_word_equal(instruction.metadata_mnemonic, S8("PUSH")) && instruction.metadata_operand_count == 1 &&
        instruction.metadata_operands[0].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE)
    {
        return true;
    }
    // PUSH and POP of a memory operand are classic encodings with no
    // handwritten form. A sigsetjmp that moves a return address in and out of
    // the jump buffer is written with both, so keep the metadata result rather
    // than restoring the handwritten operand-form diagnostic.
    if ((assembly_word_equal(instruction.metadata_mnemonic, S8("PUSH")) || assembly_word_equal(instruction.metadata_mnemonic, S8("POP"))) &&
        instruction.metadata_operand_count == 1 &&
        instruction.metadata_operands[0].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY)
    {
        return true;
    }
    for (u32 index = 0; index < instruction.metadata_operand_count; index += 1)
    {
        BusterX86MetadataPhysicalOperand operand = instruction.metadata_operands[index];
        if (operand.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER)
        {
            if ((operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR && operand.reg.index >= 16) ||
                operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_BND ||
                operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_CONTROL ||
                operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_DEBUG ||
                operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_SEGMENT ||
                operand.reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_SPECIAL)
            {
                return true;
            }
        }
        else if (operand.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY &&
                 (operand.memory.address_size != 64 || operand.memory.has_segment || operand.memory.vsib ||
                  (operand.memory.has_base && operand.memory.base.index >= 16) ||
                  (operand.memory.has_index && operand.memory.index.index >= 16)))
        {
            return true;
        }
    }
    BusterX86MetadataForm form = {0};
    if (buster_x86_metadata_form_is_moffs(instruction.metadata_form_id))
    {
        // A bare AT&T absolute address may need metadata solely to select the
        // accumulator-only MOV moffs encoding when its displacement exceeds
        // the ModRM disp32 range.  Treat that form as a genuine metadata
        // extension, rather than restoring the handwritten invalid-operand
        // diagnostic below.
        return true;
    }
    if (buster_x86_metadata_form(instruction.metadata_form_id, &form) &&
        (form.prefix_kind == BUSTER_X86_METADATA_PREFIX_REX2 || form.encoder_family == BUSTER_X86_METADATA_ENCODER_XOP))
    {
        return true;
    }
    return instruction.metadata_attributes.apx_flags != 0 || instruction.metadata_attributes.amx_flags != 0;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_requires_metadata(AssemblyInstruction instruction)
{
    for (u32 index = 0; index < instruction.operand_count; index += 1)
    {
        AssemblyOperand operand = instruction.operands[index];
        if (operand.kind == ASSEMBLY_OPERAND_REGISTER &&
            (operand.reg.class == ASSEMBLY_REGISTER_BND || operand.reg.class == ASSEMBLY_REGISTER_CONTROL ||
             operand.reg.class == ASSEMBLY_REGISTER_DEBUG || operand.reg.class == ASSEMBLY_REGISTER_SEGMENT ||
             operand.reg.class == ASSEMBLY_REGISTER_SPECIAL))
        {
            return true;
        }
        if (operand.kind == ASSEMBLY_OPERAND_MEMORY &&
            ((operand.memory.address_size && operand.memory.address_size != 64) || operand.memory.has_segment || operand.memory.vsib))
        {
            return true;
        }
    }
    return false;
}

// The legacy integer/branch family is now encoded by the x86 metadata
// producer.  Keep the handwritten parser as the source-level syntax and alias
// front end, but route these normalized instructions through metadata before
// the byte-emitting fallback is reached.  Other x86 families remain on their
// existing handwritten paths until their own migration tranche is complete.
BUSTER_GLOBAL_LOCAL bool assembly_x86_instruction_uses_metadata_authority(AssemblyInstruction instruction)
{
    // APX legacy, NDD, NF, and PUSH2/POP2 forms use the checked metadata
    // producer.  Malformed forms fail closed at metadata selection rather than
    // reaching a handwritten byte emitter.
    bool x87_instruction = instruction.opcode >= ASSEMBLY_OPCODE_X86_FLD && instruction.opcode <= ASSEMBLY_OPCODE_X86_FWAIT;
    if (x87_instruction)
    {
        // Keep malformed x87 extended-GPR forms under the checked metadata
        // authority so they fail closed instead of reaching handwritten
        // ModRM bytes.  Valid x87 memory forms have ordinary GPR bases.
        return true;
    }
    // The handwritten AMD/XOP table is retained only for source aliases and
    // operand-shape normalization; its selected instruction forms are now
    // emitted by the checked metadata producer.
    if (instruction.amd_form)
    {
        return true;
    }
    // AMX tile/register/memory forms use the checked metadata producer; raw
    // prefix, forced-SIB, and opcode construction is not an emission path.
    if (assembly_x86_opcode_is_amx(instruction.opcode))
    {
        return true;
    }
    // Opmask instructions are emitted by the metadata producer.  Keep the
    // handwritten parser's mask-feature and operand-shape validation, but do
    // not allow its legacy VEX byte emitter to become a second authority.
    if (assembly_x86_opcode_is_mask(instruction.opcode))
    {
        return true;
    }
    if (instruction.no_flags || instruction.opcode == ASSEMBLY_OPCODE_X86_APX_PUSH2 ||
        instruction.opcode == ASSEMBLY_OPCODE_X86_APX_POP2 || assembly_x86_opcode_is_apx_nf(instruction.opcode) ||
        assembly_x86_opcode_is_apx_ndd(instruction.opcode) || assembly_x86_instruction_has_extended_gpr(instruction))
    {
        return true;
    }
    switch (instruction.opcode)
    {
    case ASSEMBLY_OPCODE_X86_NOP:
    case ASSEMBLY_OPCODE_X86_RET:
    case ASSEMBLY_OPCODE_X86_INT3:
    case ASSEMBLY_OPCODE_X86_CALL:
    case ASSEMBLY_OPCODE_X86_JMP:
    case ASSEMBLY_OPCODE_X86_MOV:
    case ASSEMBLY_OPCODE_X86_ADD:
    case ASSEMBLY_OPCODE_X86_ADC:
    case ASSEMBLY_OPCODE_X86_SUB:
    case ASSEMBLY_OPCODE_X86_SBB:
    case ASSEMBLY_OPCODE_X86_AND:
    case ASSEMBLY_OPCODE_X86_OR:
    case ASSEMBLY_OPCODE_X86_XOR:
    case ASSEMBLY_OPCODE_X86_CMP:
    case ASSEMBLY_OPCODE_X86_TEST:
    case ASSEMBLY_OPCODE_X86_IMUL:
    case ASSEMBLY_OPCODE_X86_MUL:
    case ASSEMBLY_OPCODE_X86_DIV:
    case ASSEMBLY_OPCODE_X86_IDIV:
    case ASSEMBLY_OPCODE_X86_PUSH:
    case ASSEMBLY_OPCODE_X86_POP:
    case ASSEMBLY_OPCODE_X86_INC:
    case ASSEMBLY_OPCODE_X86_DEC:
    case ASSEMBLY_OPCODE_X86_NEG:
    case ASSEMBLY_OPCODE_X86_NOT:
    case ASSEMBLY_OPCODE_X86_SHL:
    case ASSEMBLY_OPCODE_X86_SHR:
    case ASSEMBLY_OPCODE_X86_SAR:
    case ASSEMBLY_OPCODE_X86_LEA:
    case ASSEMBLY_OPCODE_X86_MOVZX:
    case ASSEMBLY_OPCODE_X86_MOVSX:
    case ASSEMBLY_OPCODE_X86_MOVSXD:
    case ASSEMBLY_OPCODE_X86_ROL:
    case ASSEMBLY_OPCODE_X86_ROR:
    case ASSEMBLY_OPCODE_X86_RCL:
    case ASSEMBLY_OPCODE_X86_RCR:
    case ASSEMBLY_OPCODE_X86_SHLD:
    case ASSEMBLY_OPCODE_X86_SHRD:
    case ASSEMBLY_OPCODE_X86_CBW:
    case ASSEMBLY_OPCODE_X86_CWDE:
    case ASSEMBLY_OPCODE_X86_CDQE:
    case ASSEMBLY_OPCODE_X86_CWD:
    case ASSEMBLY_OPCODE_X86_CDQ:
    case ASSEMBLY_OPCODE_X86_CQO:
    case ASSEMBLY_OPCODE_X86_BSF:
    case ASSEMBLY_OPCODE_X86_BSR:
    case ASSEMBLY_OPCODE_X86_POPCNT:
    case ASSEMBLY_OPCODE_X86_LZCNT:
    case ASSEMBLY_OPCODE_X86_TZCNT:
    case ASSEMBLY_OPCODE_X86_BSWAP:
    case ASSEMBLY_OPCODE_X86_BT:
    case ASSEMBLY_OPCODE_X86_BTC:
    case ASSEMBLY_OPCODE_X86_BTR:
    case ASSEMBLY_OPCODE_X86_BTS:
    case ASSEMBLY_OPCODE_X86_XCHG:
    case ASSEMBLY_OPCODE_X86_XADD:
    case ASSEMBLY_OPCODE_X86_CMPXCHG:
    case ASSEMBLY_OPCODE_X86_CMPXCHG8B:
    case ASSEMBLY_OPCODE_X86_CMPXCHG16B:
    case ASSEMBLY_OPCODE_X86_JCC:
    case ASSEMBLY_OPCODE_X86_SETCC:
    case ASSEMBLY_OPCODE_X86_CMOVCC:
    case ASSEMBLY_OPCODE_X86_MOVAPS:
    case ASSEMBLY_OPCODE_X86_MOVUPS:
    case ASSEMBLY_OPCODE_X86_MOVAPD:
    case ASSEMBLY_OPCODE_X86_MOVUPD:
    case ASSEMBLY_OPCODE_X86_MOVDQA:
    case ASSEMBLY_OPCODE_X86_MOVDQU:
    case ASSEMBLY_OPCODE_X86_XORPS:
    case ASSEMBLY_OPCODE_X86_XORPD:
    case ASSEMBLY_OPCODE_X86_PXOR:
    case ASSEMBLY_OPCODE_X86_ADDPS:
    case ASSEMBLY_OPCODE_X86_ADDPD:
    case ASSEMBLY_OPCODE_X86_ADDSS:
    case ASSEMBLY_OPCODE_X86_ADDSD:
    case ASSEMBLY_OPCODE_X86_SUBPS:
    case ASSEMBLY_OPCODE_X86_SUBPD:
    case ASSEMBLY_OPCODE_X86_MULPS:
    case ASSEMBLY_OPCODE_X86_MULPD:
    case ASSEMBLY_OPCODE_X86_DIVPS:
    case ASSEMBLY_OPCODE_X86_DIVPD:
    case ASSEMBLY_OPCODE_X86_EMMS:
    case ASSEMBLY_OPCODE_X86_MOVQ_MMX:
    case ASSEMBLY_OPCODE_X86_PADDB_MMX:
    case ASSEMBLY_OPCODE_X86_PADDW_MMX:
    case ASSEMBLY_OPCODE_X86_PADDD_MMX:
    case ASSEMBLY_OPCODE_X86_PADDQ_MMX:
    case ASSEMBLY_OPCODE_X86_PSUBB_MMX:
    case ASSEMBLY_OPCODE_X86_PSUBW_MMX:
    case ASSEMBLY_OPCODE_X86_PSUBD_MMX:
    case ASSEMBLY_OPCODE_X86_PSUBQ_MMX:
    case ASSEMBLY_OPCODE_X86_PAND_MMX:
    case ASSEMBLY_OPCODE_X86_POR_MMX:
    case ASSEMBLY_OPCODE_X86_PXOR_MMX:
    case ASSEMBLY_OPCODE_X86_PCMPEQB_MMX:
    case ASSEMBLY_OPCODE_X86_PCMPEQW_MMX:
    case ASSEMBLY_OPCODE_X86_PCMPEQD_MMX:
    case ASSEMBLY_OPCODE_X86_PCMPGTB_MMX:
    case ASSEMBLY_OPCODE_X86_PCMPGTW_MMX:
    case ASSEMBLY_OPCODE_X86_PCMPGTD_MMX:
    case ASSEMBLY_OPCODE_X86_PMULLW_MMX:
    case ASSEMBLY_OPCODE_X86_VMOVAPS:
    case ASSEMBLY_OPCODE_X86_VMOVUPS:
    case ASSEMBLY_OPCODE_X86_VMOVAPD:
    case ASSEMBLY_OPCODE_X86_VMOVUPD:
    case ASSEMBLY_OPCODE_X86_VXORPS:
    case ASSEMBLY_OPCODE_X86_VXORPD:
    case ASSEMBLY_OPCODE_X86_VADDPS:
    case ASSEMBLY_OPCODE_X86_VADDPD:
    case ASSEMBLY_OPCODE_X86_VADDSS:
    case ASSEMBLY_OPCODE_X86_VADDSD:
    case ASSEMBLY_OPCODE_X86_VSUBPS:
    case ASSEMBLY_OPCODE_X86_VSUBPD:
    case ASSEMBLY_OPCODE_X86_VMULPS:
    case ASSEMBLY_OPCODE_X86_VMULPD:
    case ASSEMBLY_OPCODE_X86_VDIVPS:
    case ASSEMBLY_OPCODE_X86_VDIVPD:
    case ASSEMBLY_OPCODE_X86_VMOVDQA:
    case ASSEMBLY_OPCODE_X86_VMOVDQU:
    case ASSEMBLY_OPCODE_X86_VPADDB:
    case ASSEMBLY_OPCODE_X86_VPADDW:
    case ASSEMBLY_OPCODE_X86_VPADDD:
    case ASSEMBLY_OPCODE_X86_VPADDQ:
    case ASSEMBLY_OPCODE_X86_VPSUBB:
    case ASSEMBLY_OPCODE_X86_VPSUBW:
    case ASSEMBLY_OPCODE_X86_VPSUBD:
    case ASSEMBLY_OPCODE_X86_VPSUBQ:
    case ASSEMBLY_OPCODE_X86_VPAND:
    case ASSEMBLY_OPCODE_X86_VPOR:
    case ASSEMBLY_OPCODE_X86_VPXOR:
    case ASSEMBLY_OPCODE_X86_VPCMPEQB:
    case ASSEMBLY_OPCODE_X86_VPCMPEQW:
    case ASSEMBLY_OPCODE_X86_VPCMPEQD:
    case ASSEMBLY_OPCODE_X86_VPCMPEQQ:
    case ASSEMBLY_OPCODE_X86_VPCMPGTB:
    case ASSEMBLY_OPCODE_X86_VPCMPGTW:
    case ASSEMBLY_OPCODE_X86_VPCMPGTD:
    case ASSEMBLY_OPCODE_X86_VPCMPGTQ:
    case ASSEMBLY_OPCODE_X86_VPMULLW:
    case ASSEMBLY_OPCODE_X86_VPMULLD:
    case ASSEMBLY_OPCODE_X86_VMOVDQA32:
    case ASSEMBLY_OPCODE_X86_VMOVDQU32:
    case ASSEMBLY_OPCODE_X86_VMOVDQA64:
    case ASSEMBLY_OPCODE_X86_VMOVDQU64:
    case ASSEMBLY_OPCODE_X86_VMOVDQU8:
    case ASSEMBLY_OPCODE_X86_VMOVDQU16:
    case ASSEMBLY_OPCODE_X86_VCMPPS:
    case ASSEMBLY_OPCODE_X86_VCMPPD:
    case ASSEMBLY_OPCODE_X86_VPCMPD:
    case ASSEMBLY_OPCODE_X86_VPCMPQ:
    case ASSEMBLY_OPCODE_X86_VPCMPB:
    case ASSEMBLY_OPCODE_X86_VPCMPW:
    case ASSEMBLY_OPCODE_X86_VPCMPUD:
    case ASSEMBLY_OPCODE_X86_VPCMPUQ:
    case ASSEMBLY_OPCODE_X86_VRNDSCALEPS:
    case ASSEMBLY_OPCODE_X86_VRNDSCALEPD:
        return true;
    default:
        return false;
    }
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_instruction_has_duplicate_registers(AssemblyInstruction instruction)
{
    for (u32 left = 0; left < instruction.metadata_operand_count; left += 1)
    {
        BusterX86MetadataPhysicalOperand left_operand = instruction.metadata_operands[left];
        if (left_operand.kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER)
        {
            continue;
        }
        for (u32 right = left + 1; right < instruction.metadata_operand_count; right += 1)
        {
            BusterX86MetadataPhysicalOperand right_operand = instruction.metadata_operands[right];
            if (right_operand.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
                left_operand.reg.physical_class == right_operand.reg.physical_class &&
                left_operand.reg.index == right_operand.reg.index && left_operand.reg.width == right_operand.reg.width)
            {
                return true;
            }
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_statement_has_extended_gpr(String8 statement)
{
    for (u64 index = 0; index < statement.length; index += 1)
    {
        if (assembly_ascii_lower(statement.pointer[index]) != 'r')
        {
            continue;
        }
        u64 end = index + 1;
        while (end < statement.length &&
               ((statement.pointer[end] >= '0' && statement.pointer[end] <= '9') ||
                assembly_ascii_lower(statement.pointer[end]) == 'b' ||
                assembly_ascii_lower(statement.pointer[end]) == 'd' ||
                assembly_ascii_lower(statement.pointer[end]) == 'w'))
        {
            end += 1;
        }
        AssemblyRegister register_value = {0};
        if (assembly_extended_gpr_parse(string_slice(statement, index, end), &register_value))
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_statement_has_no_flags_decorator(String8 statement)
{
    for (u64 index = 0; index < statement.length; index += 1)
    {
        if (statement.pointer[index] != '{')
        {
            continue;
        }
        u64 end = index + 1;
        while (end < statement.length && statement.pointer[end] != '}')
        {
            end += 1;
        }
        if (end < statement.length && assembly_word_equal(assembly_trim(string_slice(statement, index + 1, end)), S8("nf")))
        {
            return true;
        }
        index = end;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL void assembly_x86_metadata_diagnostic(AssemblyBuilder* builder, BusterX86MetadataEncodeStatus status,
                                                           u32 line, u32 column, u32 length)
{
    AssemblyDiagnosticKind kind = ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS;
    String8 message = S8("metadata instruction form is not encodable");
    if (status == BUSTER_X86_METADATA_ENCODE_UNKNOWN_MNEMONIC)
    {
        kind = ASSEMBLY_DIAGNOSTIC_UNKNOWN_INSTRUCTION;
        message = S8("unknown instruction");
    }
    else if (status == BUSTER_X86_METADATA_ENCODE_INVALID_EXPRESSION)
    {
        kind = ASSEMBLY_DIAGNOSTIC_INVALID_EXPRESSION;
        message = S8("invalid instruction expression");
    }
    else if (status == BUSTER_X86_METADATA_ENCODE_FEATURE_MODE_PRIVILEGE)
    {
        kind = ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE;
        message = S8("instruction requires an enabled target feature");
    }
    else if (status == BUSTER_X86_METADATA_ENCODE_RELATIVE_RANGE)
    {
        kind = ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE;
        message = S8("x86 branch target is out of range");
    }
    else if (status == BUSTER_X86_METADATA_ENCODE_DISPLACEMENT_RANGE)
    {
        kind = ASSEMBLY_DIAGNOSTIC_INVALID_EXPRESSION;
        message = S8("x86 memory displacement is out of range");
    }
    else if (status == BUSTER_X86_METADATA_ENCODE_IMMEDIATE_RANGE)
    {
        kind = ASSEMBLY_DIAGNOSTIC_INVALID_EXPRESSION;
        message = S8("x86 immediate is out of range");
    }
    else if (status == BUSTER_X86_METADATA_ENCODE_OUTPUT_CAPACITY ||
             status == BUSTER_X86_METADATA_ENCODE_RELOCATION_CAPACITY)
    {
        kind = ASSEMBLY_DIAGNOSTIC_INVALID_STATEMENT;
        message = S8("metadata instruction output capacity exceeded");
    }
    assembly_diagnostic(builder, kind, line, column, length, message);
}

BUSTER_GLOBAL_LOCAL void assembly_instruction_parse(AssemblyBuilder* builder, String8 statement, u32 line, u32 column, u64 offset,
                                                     Target target, AssemblySyntax syntax)
{
    u32 instruction_count = builder->instruction_count;
    u32 symbol_count = builder->result.symbol_count;
    u32 relocation_count = builder->result.relocation_count;
    u32 diagnostic_count = builder->result.diagnostic_count;
    u64 output_count = builder->output_count;
    assembly_instruction_parse_handwritten(builder, statement, line, column, offset, target, syntax);
    bool handwritten_succeeded = builder->instruction_count != instruction_count;
    bool metadata_authoritative = handwritten_succeeded && target.cpu_arch == CPU_ARCH_X86_64 &&
                                  assembly_x86_instruction_uses_metadata_authority(builder->instructions[instruction_count]);
    bool unsigned_expression = handwritten_succeeded &&
                               assembly_x86_instruction_has_unsigned_expression(builder->instructions[instruction_count]);
    bool handwritten_requires_metadata = handwritten_succeeded &&
                                         assembly_x86_instruction_requires_metadata(builder->instructions[instruction_count]);
    if (!handwritten_succeeded || metadata_authoritative || unsigned_expression || handwritten_requires_metadata)
    {
        AssemblyDiagnosticKind handwritten_kind = ASSEMBLY_DIAGNOSTIC_INVALID_STATEMENT;
        AssemblyDiagnostic handwritten_diagnostic = {0};
        bool has_handwritten_diagnostic = false;
        if (builder->result.diagnostic_count > diagnostic_count)
        {
            handwritten_kind = builder->result.diagnostics[builder->result.diagnostic_count - 1].kind;
            handwritten_diagnostic = builder->result.diagnostics[builder->result.diagnostic_count - 1];
            has_handwritten_diagnostic = true;
        }
        bool fallback_allowed = target.cpu_arch == CPU_ARCH_X86_64 &&
                                 (!handwritten_succeeded || metadata_authoritative || unsigned_expression || handwritten_requires_metadata);
        if (fallback_allowed)
        {
            builder->instruction_count = instruction_count;
            builder->result.symbol_count = symbol_count;
            builder->result.relocation_count = relocation_count;
            builder->result.diagnostic_count = diagnostic_count;
            builder->output_count = output_count;
            BusterX86MetadataEncodeStatus status = assembly_x86_metadata_instruction_parse(builder, statement, line, column, offset, target, syntax);
            if (status == BUSTER_X86_METADATA_ENCODE_SUCCESS)
            {
                if (metadata_authoritative)
                {
                    return;
                }
                bool metadata_novel = builder->instruction_count > instruction_count &&
                                      assembly_x86_metadata_instruction_is_novel(builder->instructions[instruction_count]);
                bool metadata_source_authoritative = false;
                if (builder->instruction_count > instruction_count)
                {
                    AssemblyInstruction metadata_instruction = builder->instructions[instruction_count];
                    BusterX86MetadataForm metadata_form = {0};
                    if (buster_x86_metadata_form(metadata_instruction.metadata_form_id, &metadata_form))
                    {
                        BusterX86MetadataPhysicalQuery metadata_query = {
                            .operands = metadata_instruction.metadata_operands,
                            .operand_count = metadata_instruction.metadata_operand_count,
                            .attributes = metadata_instruction.metadata_attributes,
                            .address_size = metadata_instruction.metadata_address_size,
                            .execution_mode = BUSTER_X86_METADATA_EXECUTION_MODE_64,
                            .source_semantics = true,
                        };
                        metadata_source_authoritative = assembly_x86_metadata_typed_decorator_authoritative(metadata_form, metadata_query) ||
                                                        buster_x86_metadata_legacy_xmm_memory_authoritative(metadata_form, metadata_query) ||
                                                        buster_x86_metadata_block_memory_source_authoritative(metadata_form, metadata_query);
                    }
                }
                if ((handwritten_kind == ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE && !metadata_source_authoritative) ||
                    (handwritten_kind == ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS &&
                     (!metadata_source_authoritative &&
                      (!metadata_novel || assembly_x86_metadata_instruction_has_duplicate_registers(builder->instructions[instruction_count])))))
                {
                    builder->instruction_count = instruction_count;
                    builder->result.symbol_count = symbol_count;
                    builder->result.relocation_count = relocation_count;
                    builder->result.diagnostic_count = diagnostic_count;
                    builder->output_count = output_count;
                    if (has_handwritten_diagnostic)
                    {
                        assembly_diagnostic(builder, handwritten_diagnostic.kind, handwritten_diagnostic.line, handwritten_diagnostic.column,
                                            handwritten_diagnostic.length, handwritten_diagnostic.message);
                    }
                }
                return;
            }
            if (metadata_authoritative)
            {
                // Once a migrated instruction has entered metadata selection, do not
                // silently resurrect handwritten bytes on a metadata failure.  Restore
                // the pre-parse state and surface the checked producer's diagnostic.
                builder->instruction_count = instruction_count;
                builder->result.symbol_count = symbol_count;
                builder->result.relocation_count = relocation_count;
                builder->result.diagnostic_count = diagnostic_count;
                builder->output_count = output_count;
                u32 length = statement.length > UINT32_MAX ? UINT32_MAX : (u32)statement.length;
                assembly_x86_metadata_diagnostic(builder, status, line, column, length);
                return;
            }
            builder->instruction_count = instruction_count;
            builder->result.symbol_count = symbol_count;
            builder->result.relocation_count = relocation_count;
            builder->result.diagnostic_count = diagnostic_count;
            builder->output_count = output_count;
            bool metadata_precise = handwritten_requires_metadata || (!handwritten_succeeded &&
                                    (handwritten_kind != ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS ||
                                     (status == BUSTER_X86_METADATA_ENCODE_FEATURE_MODE_PRIVILEGE &&
                                      (builder->metadata_failure_typed_decorator_authoritative ||
                                       (assembly_x86_statement_has_extended_gpr(statement) &&
                                        !assembly_x86_statement_has_no_flags_decorator(statement)))) ||
                                     (handwritten_kind == ASSEMBLY_DIAGNOSTIC_UNKNOWN_INSTRUCTION &&
                                      (status == BUSTER_X86_METADATA_ENCODE_WRONG_OPERAND_COUNT ||
                                       status == BUSTER_X86_METADATA_ENCODE_OPERAND_MISMATCH))) &&
                                    status != BUSTER_X86_METADATA_ENCODE_UNKNOWN_MNEMONIC &&
                                    status != BUSTER_X86_METADATA_ENCODE_INVALID_INPUT &&
                                    (handwritten_kind != ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE ||
                                     builder->metadata_failure_typed_decorator_authoritative));
            if (metadata_precise)
            {
                u32 length = statement.length > UINT32_MAX ? UINT32_MAX : (u32)statement.length;
                assembly_x86_metadata_diagnostic(builder, status, line, column, length);
            }
            else if (handwritten_succeeded)
            {
                assembly_instruction_parse_handwritten(builder, statement, line, column, offset, target, syntax);
            }
            else if (has_handwritten_diagnostic)
            {
                assembly_diagnostic(builder, handwritten_diagnostic.kind, handwritten_diagnostic.line, handwritten_diagnostic.column,
                                    handwritten_diagnostic.length, handwritten_diagnostic.message);
            }
        }
    }
}

BUSTER_GLOBAL_LOCAL void assembly_source_parse(AssemblyBuilder* builder, String8 source, Target target, AssemblySyntax syntax)
{
    u64 source_cursor = 0;
    u64 output_offset = 0;
    u32 line = 1;
    while (source_cursor < source.length)
    {
        u64 line_end = source_cursor;
        while (line_end < source.length && source.pointer[line_end] != '\n')
        {
            line_end += 1;
        }
        String8 original = {.pointer = source.pointer + source_cursor, .length = line_end - source_cursor};
        u64 comment = original.length;
        for (u64 index = 0; index < original.length; index += 1)
        {
            if (original.pointer[index] == ';' || (syntax == ASSEMBLY_SYNTAX_ATT && original.pointer[index] == '#') ||
                (original.pointer[index] == '/' && index + 1 < original.length && original.pointer[index + 1] == '/'))
            {
                comment = index;
                break;
            }
        }
        String8 statement = assembly_trim((String8){.pointer = original.pointer, .length = comment});
        u32 column = statement.length ? (u32)(statement.pointer - original.pointer) + 1 : 1;
        if (statement.length)
        {
            u64 colon = assembly_leading_label_colon(statement);
            bool segment_override = false;
            bool segment_colon_error = false;
            if (colon < statement.length)
            {
                u64 segment_start = colon;
                while (segment_start && !assembly_space(statement.pointer[segment_start - 1]))
                {
                    segment_start -= 1;
                }
                String8 segment = string_slice(statement, segment_start, colon);
                u64 following_index = colon + 1;
                while (following_index < statement.length && assembly_space(statement.pointer[following_index]))
                {
                    following_index += 1;
                }
                char8 following = following_index < statement.length ? statement.pointer[following_index] : 0;
                u8 segment_index = 0;
                bool memory_after_segment = following == '[' || following == '(';
                if (syntax == ASSEMBLY_SYNTAX_ATT && !memory_after_segment && following_index < statement.length)
                {
                    String8 after_segment = string_slice(statement, following_index, statement.length);
                    memory_after_segment = string_first_code_unit(after_segment, '(') < after_segment.length;
                }
                segment_override = memory_after_segment && assembly_x86_segment_parse(segment, syntax, &segment_index);
                if (!segment_override)
                {
                    // A bare segment word followed by ':' is only a memory
                    // operand spelling.  Keep a label-only line such as
                    // `fs:` usable, but reject `fs: movsb` instead of
                    // silently turning the prefix-looking token into a
                    // label and encoding the instruction without it.
                    u8 segment_label_index = 0;
                    bool segment_label = assembly_x86_segment_parse(segment, syntax, &segment_label_index) ||
                                         assembly_x86_segment_parse(segment, ASSEMBLY_SYNTAX_INTEL, &segment_label_index);
                    if (segment_label &&
                        following_index < statement.length)
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_STATEMENT, line, column,
                                            (u32)(colon + 1), S8("segment prefix requires a memory operand"));
                        segment_colon_error = true;
                    }
                }
            }
            if (colon < statement.length && !segment_override && !segment_colon_error)
            {
                String8 label = assembly_trim((String8){.pointer = statement.pointer, .length = colon});
                if (!assembly_identifier(label))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_STATEMENT, line, column, (u32)label.length, S8("invalid label"));
                }
                else
                {
                    u32 symbol = assembly_symbol_intern(builder, label);
                    if (symbol == UINT32_MAX)
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_STATEMENT, line, column, (u32)label.length,
                                            S8("too many symbols"));
                    }
                    else if (builder->result.symbols[symbol].defined)
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_DUPLICATE_SYMBOL, line, column, (u32)label.length,
                                            S8("duplicate label"));
                    }
                    else
                    {
                        builder->result.symbols[symbol].defined = true;
                        builder->result.symbols[symbol].offset = output_offset;
                    }
                }
                statement = assembly_trim((String8){.pointer = statement.pointer + colon + 1, .length = statement.length - colon - 1});
                column = statement.length ? (u32)(statement.pointer - original.pointer) + 1 : column;
            }
            if (statement.length && !segment_colon_error)
            {
                u64 directive_end = 0;
                while (directive_end < statement.length && !assembly_space(statement.pointer[directive_end]))
                {
                    directive_end += 1;
                }
                String8 directive = string_slice(statement, 0, directive_end);
                String8 qualifier = assembly_trim(string_slice(statement, directive_end, statement.length));
                if (assembly_word_equal(directive, S8(".intel_syntax")))
                {
                    if (target.cpu_arch != CPU_ARCH_X86_64 || !assembly_word_equal(qualifier, S8("noprefix")))
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_SYNTAX, line, column, (u32)statement.length,
                                            S8(".intel_syntax requires the x86 'noprefix' qualifier"));
                    }
                    else
                    {
                        syntax = ASSEMBLY_SYNTAX_INTEL;
                    }
                }
                else if (assembly_word_equal(directive, S8(".att_syntax")))
                {
                    if (target.cpu_arch != CPU_ARCH_X86_64 || !assembly_word_equal(qualifier, S8("prefix")))
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_SYNTAX, line, column, (u32)statement.length,
                                            S8(".att_syntax requires the x86 'prefix' qualifier"));
                    }
                    else
                    {
                        syntax = ASSEMBLY_SYNTAX_ATT;
                    }
                }
                else
                {
                    u32 instruction_count = builder->instruction_count;
                    assembly_instruction_parse(builder, statement, line, column, output_offset, target, syntax);
                    if (builder->instruction_count != instruction_count)
                    {
                        // A source alias may expand into multiple checked
                        // metadata instructions (for example WAIT-prefixed
                        // x87 FINIT/FCLEX).  Account for every appended
                        // instruction so subsequent offsets and relocations
                        // remain aligned with emitted bytes.
                        for (u32 index = instruction_count; index < builder->instruction_count; index += 1)
                        {
                            output_offset += builder->instructions[index].size;
                        }
                    }
                }
            }
        }
        source_cursor = line_end + (line_end < source.length);
        line += 1;
    }
    builder->output_capacity = output_offset;
}

BUSTER_GLOBAL_LOCAL void assembly_emit_u32(AssemblyBuilder* builder, u32 value)
{
    if (builder->output_count > builder->output_capacity || 4 > builder->output_capacity - builder->output_count)
    {
        return;
    }
    memcpy(builder->result.bytes.pointer + builder->output_count, &value, sizeof(value));
    builder->output_count += 4;
}

BUSTER_GLOBAL_LOCAL bool assembly_expression_target(AssemblyBuilder* builder, AssemblyExpression expression, s64* target)
{
    if (!expression.has_symbol)
    {
        *target = expression.has_unsigned_addend && expression.unsigned_addend > (u64)INT64_MAX
                      ? INT64_MAX
                      : expression.has_unsigned_addend ? (s64)expression.unsigned_addend : expression.addend;
        return true;
    }
    AssemblySymbol* symbol = builder->result.symbols + expression.symbol;
    if (!symbol->defined)
    {
        return false;
    }
    if (symbol->offset > (u64)INT64_MAX ||
        (expression.addend > 0 && symbol->offset > (u64)(INT64_MAX - expression.addend)))
    {
        *target = INT64_MAX;
        return true;
    }
    s64 value = (s64)symbol->offset;
    if (expression.addend < 0 && value < INT64_MIN - expression.addend)
    {
        *target = INT64_MIN;
        return true;
    }
    *target = value + expression.addend;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_relocation_append(AssemblyBuilder* builder, u64 offset, AssemblyExpression expression,
                                                     AssemblyRelocationKind kind, s64 implicit_addend)
{
    if (!expression.has_symbol || builder->result.relocation_count >= builder->relocation_capacity)
    {
        return false;
    }
    if ((implicit_addend > 0 && expression.addend > INT64_MAX - implicit_addend) ||
        (implicit_addend < 0 && expression.addend < INT64_MIN - implicit_addend))
    {
        return false;
    }
    builder->result.relocations[builder->result.relocation_count++] = (AssemblyRelocation){
        .addend = expression.addend + implicit_addend,
        .offset = offset,
        .symbol = expression.symbol,
        .kind = kind,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_pc_value(AssemblyInstruction* instruction, u64 relocation_offset, u64 target,
                                                         s64 addend, s64* value)
{
    if (!instruction || !value || instruction->offset > (u64)INT64_MAX || relocation_offset > (u64)INT64_MAX ||
        instruction->offset > (u64)INT64_MAX - relocation_offset)
    {
        return false;
    }
    u64 place_unsigned = instruction->offset + relocation_offset;
    if (place_unsigned > (u64)INT64_MAX || target > (u64)INT64_MAX)
    {
        return false;
    }
    s64 target_value = (s64)target;
    s64 place_value = (s64)place_unsigned;
    if ((addend > 0 && target_value > INT64_MAX - addend) || (addend < 0 && target_value < INT64_MIN - addend))
    {
        return false;
    }
    target_value += addend;
    if ((place_value > 0 && target_value < INT64_MIN + place_value) ||
        (place_value < 0 && target_value > INT64_MAX + place_value))
    {
        return false;
    }
    *value = target_value - place_value;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_relocation_kind(u8 metadata_kind, AssemblyRelocationKind* kind)
{
    if (kind)
    {
        switch ((BusterX86MetadataRelocationKind)metadata_kind)
        {
        case BUSTER_X86_METADATA_RELOCATION_ABSOLUTE8:
            *kind = ASSEMBLY_RELOCATION_X86_ABSOLUTE8;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_ABSOLUTE16:
            *kind = ASSEMBLY_RELOCATION_X86_ABSOLUTE16;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_ABSOLUTE32:
            *kind = ASSEMBLY_RELOCATION_X86_ABSOLUTE32;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_ABSOLUTE64:
            *kind = ASSEMBLY_RELOCATION_X86_ABSOLUTE64;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_ABSOLUTE32_SIGN_EXTENDED:
            *kind = ASSEMBLY_RELOCATION_X86_ABSOLUTE32_SIGN_EXTENDED;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_ABSOLUTE32_ZERO_EXTENDED:
            *kind = ASSEMBLY_RELOCATION_X86_ABSOLUTE32_ZERO_EXTENDED;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_PC8:
            *kind = ASSEMBLY_RELOCATION_X86_PC8;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_PC16:
            *kind = ASSEMBLY_RELOCATION_X86_PC16;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_PC32:
            *kind = ASSEMBLY_RELOCATION_X86_PC32;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_PC64:
            *kind = ASSEMBLY_RELOCATION_X86_PC64;
            return true;
        case BUSTER_X86_METADATA_RELOCATION_KIND_COUNT:
            break;
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_local_relocation(AssemblyBuilder* builder, AssemblyInstruction* instruction,
                                                                 BusterX86MetadataRelocation relocation, u8* bytes)
{
    if (!builder || !instruction || !bytes || relocation.width == 0 || relocation.width > 8 ||
        relocation.offset > UINT32_MAX - relocation.width || relocation.offset + relocation.width > instruction->size)
    {
        return false;
    }
    u32 symbol_index = assembly_symbol_find(builder, relocation.symbol);
    if (symbol_index == UINT32_MAX)
    {
        return false;
    }
    AssemblySymbol symbol = builder->result.symbols[symbol_index];
    AssemblyRelocationKind kind = ASSEMBLY_RELOCATION_COUNT;
    if (!assembly_x86_metadata_relocation_kind(relocation.kind, &kind))
    {
        return false;
    }
    if (symbol.defined)
    {
        u64 value = 0;
        if (kind == ASSEMBLY_RELOCATION_X86_PC8 || kind == ASSEMBLY_RELOCATION_X86_PC16 ||
            kind == ASSEMBLY_RELOCATION_X86_PC32 || kind == ASSEMBLY_RELOCATION_X86_PC64)
        {
            s64 relative = 0;
            if (!assembly_x86_metadata_pc_value(instruction, relocation.offset, symbol.offset, relocation.addend, &relative))
            {
                return false;
            }
            if ((kind == ASSEMBLY_RELOCATION_X86_PC8 && (relative < INT8_MIN || relative > INT8_MAX)) ||
                (kind == ASSEMBLY_RELOCATION_X86_PC16 && (relative < INT16_MIN || relative > INT16_MAX)) ||
                (kind == ASSEMBLY_RELOCATION_X86_PC32 && (relative < INT32_MIN || relative > INT32_MAX)))
            {
                return false;
            }
            value = (u64)relative;
        }
        else
        {
            u64 magnitude = 0;
            if (relocation.addend >= 0)
            {
                u64 unsigned_addend = (u64)relocation.addend;
                if (symbol.offset > UINT64_MAX - unsigned_addend)
                {
                    return false;
                }
                value = symbol.offset + unsigned_addend;
            }
            else
            {
                magnitude = (u64)(-(relocation.addend + 1)) + 1;
                if (symbol.offset < magnitude)
                {
                    if (kind == ASSEMBLY_RELOCATION_X86_ABSOLUTE64)
                    {
                        value = 0 - (magnitude - symbol.offset);
                    }
                    else if (kind != ASSEMBLY_RELOCATION_X86_ABSOLUTE32_SIGN_EXTENDED)
                    {
                        return false;
                    }
                    else if (magnitude > (u64)INT64_MAX)
                    {
                        s64 signed_value = INT64_MIN + (s64)symbol.offset;
                        if (signed_value < INT32_MIN || signed_value > INT32_MAX)
                        {
                            return false;
                        }
                        value = (u64)signed_value;
                    }
                    else
                    {
                        s64 signed_value = (s64)symbol.offset - (s64)magnitude;
                        if (signed_value < INT32_MIN || signed_value > INT32_MAX)
                        {
                            return false;
                        }
                        value = (u64)signed_value;
                    }
                }
                else
                {
                    value = symbol.offset - magnitude;
                }
            }
            if ((kind == ASSEMBLY_RELOCATION_X86_ABSOLUTE8 && value > UINT8_MAX) ||
                (kind == ASSEMBLY_RELOCATION_X86_ABSOLUTE16 && value > UINT16_MAX) ||
                (kind == ASSEMBLY_RELOCATION_X86_ABSOLUTE32 && value > UINT32_MAX) ||
                (kind == ASSEMBLY_RELOCATION_X86_ABSOLUTE32_ZERO_EXTENDED && value > UINT32_MAX) ||
                (kind == ASSEMBLY_RELOCATION_X86_ABSOLUTE32_SIGN_EXTENDED &&
                 (relocation.addend >= 0 || symbol.offset >= magnitude) && value > (u64)INT32_MAX))
            {
                return false;
            }
        }
        for (u32 byte_index = 0; byte_index < relocation.width; byte_index += 1)
        {
            bytes[relocation.offset + byte_index] = (u8)(value >> (byte_index * 8));
        }
    }

    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_x86_metadata_emit(AssemblyBuilder* builder, AssemblyInstruction* instruction)
{
    String8 feature_names[TARGET_CPU_FEATURE_COUNT] = {0};
    u32 feature_count = assembly_x86_metadata_feature_names(builder->target, feature_names, BUSTER_ARRAY_LENGTH(feature_names));
    BusterX86MetadataPhysicalOperand operands[ASSEMBLY_MAX_OPERANDS] = {0};
    if (instruction->metadata_operand_count > BUSTER_ARRAY_LENGTH(operands))
    {
        return false;
    }
    if (instruction->metadata_operand_count)
    {
        memcpy(operands, instruction->metadata_operands, instruction->metadata_operand_count * sizeof(*operands));
    }
    assembly_x86_metadata_append_avx10_aliases(builder->target, feature_names, &feature_count, BUSTER_ARRAY_LENGTH(feature_names),
                                                operands, instruction->metadata_operand_count);
    bool mmx_instruction = false;
    for (u32 operand_index = 0; operand_index < instruction->metadata_operand_count; operand_index += 1)
    {
        if (operands[operand_index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER &&
            operands[operand_index].reg.physical_class == BUSTER_X86_METADATA_PHYSICAL_CLASS_MMX)
        {
            mmx_instruction = true;
            break;
        }
    }
    if (mmx_instruction && !target_cpu_feature_has(builder->target, TARGET_CPU_FEATURE_X86_SSE2) &&
        feature_count < BUSTER_ARRAY_LENGTH(feature_names))
    {
        // Keep the legacy MMX baseline accepted even though normalized XED
        // rows are tagged SSE2MMX.  The physical operands have already
        // excluded XMM forms, so this compatibility token cannot authorize
        // an SSE2-only instruction.
        feature_names[feature_count++] = S8("sse2");
    }
    BusterX86MetadataPhysicalQuery physical = {
        .mnemonic = instruction->metadata_mnemonic,
        .operands = operands,
        .operand_count = instruction->metadata_operand_count,
        .features = {.names = feature_names, .count = feature_count},
        .attributes = instruction->metadata_attributes,
        .address_size = instruction->metadata_address_size ? instruction->metadata_address_size : 64,
        .execution_mode = BUSTER_X86_METADATA_EXECUTION_MODE_64,
        .include_privileged = true,
        .include_not64 = false,
        .include_implicit = instruction->metadata_include_implicit,
        .source_semantics = true,
    };
    u8 bytes[64] = {0};
    BusterX86MetadataRelocation metadata_relocations[BUSTER_X86_METADATA_EMIT_RELOCATION_CAPACITY] = {0};
    BusterX86MetadataEmitResult emitted = buster_x86_metadata_encode((BusterX86MetadataEncodeQuery){
        .physical = physical,
        .output = bytes,
        .output_capacity = BUSTER_ARRAY_LENGTH(bytes),
        .relocations = metadata_relocations,
        .relocation_capacity = BUSTER_X86_METADATA_EMIT_RELOCATION_CAPACITY,
    });
    u32 metadata_size = instruction->size - (instruction->metadata_private_pc8_long ? 7u : 0u);
    if (emitted.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || emitted.byte_count != metadata_size ||
        builder->result.relocation_count > builder->relocation_capacity ||
        emitted.relocation_count > builder->relocation_capacity - builder->result.relocation_count)
    {
        BusterX86MetadataEncodeStatus status = emitted.status;
        if (status == BUSTER_X86_METADATA_ENCODE_SUCCESS)
        {
            status = BUSTER_X86_METADATA_ENCODE_RELOCATION_CAPACITY;
        }
        assembly_x86_metadata_diagnostic(builder, status, instruction->line, instruction->column, 1);
        return false;
    }
    for (u32 relocation_index = 0; relocation_index < emitted.relocation_count; relocation_index += 1)
    {
        BusterX86MetadataRelocation relocation = metadata_relocations[relocation_index];
        if (!assembly_x86_metadata_local_relocation(builder, instruction, relocation, bytes))
        {
            assembly_x86_metadata_diagnostic(builder, BUSTER_X86_METADATA_ENCODE_IMMEDIATE_RANGE, instruction->line, instruction->column, 1);
            return false;
        }
    }
    if (builder->output_count > builder->output_capacity || instruction->size > builder->output_capacity - builder->output_count)
    {
        assembly_x86_metadata_diagnostic(builder, BUSTER_X86_METADATA_ENCODE_OUTPUT_CAPACITY, instruction->line, instruction->column, 1);
        return false;
    }
    u32 relocation_symbols[BUSTER_X86_METADATA_EMIT_RELOCATION_CAPACITY] = {0};
    AssemblyRelocationKind relocation_kinds[BUSTER_X86_METADATA_EMIT_RELOCATION_CAPACITY] = {0};
    u32 unresolved_relocation_count = 0;
    u32 private_relocation = UINT32_MAX;
    for (u32 relocation_index = 0; relocation_index < emitted.relocation_count; relocation_index += 1)
    {
        BusterX86MetadataRelocation relocation = metadata_relocations[relocation_index];
        u32 symbol = assembly_symbol_find(builder, relocation.symbol);
        AssemblyRelocationKind kind = ASSEMBLY_RELOCATION_COUNT;
        if (symbol == UINT32_MAX || !assembly_x86_metadata_relocation_kind(relocation.kind, &kind))
        {
            assembly_x86_metadata_diagnostic(builder, BUSTER_X86_METADATA_ENCODE_INVALID_EXPRESSION, instruction->line, instruction->column, 1);
            return false;
        }
        if (!builder->result.symbols[symbol].defined)
        {
            bool private_pc8 = instruction->metadata_private_pc8_long && kind == ASSEMBLY_RELOCATION_X86_PC8 &&
                               assembly_inline_private_label_name(builder->result.symbols[symbol].name);
            if (instruction->offset > UINT64_MAX - relocation.offset ||
                (private_pc8 && (private_relocation != UINT32_MAX || relocation.width != 1 ||
                                 relocation.offset >= emitted.byte_count || relocation.addend < INT64_MIN + 3)))
            {
                assembly_x86_metadata_diagnostic(builder, BUSTER_X86_METADATA_ENCODE_INVALID_EXPRESSION, instruction->line, instruction->column, 1);
                return false;
            }
            if (private_pc8)
            {
                private_relocation = relocation_index;
            }
            relocation_symbols[unresolved_relocation_count] = symbol;
            relocation_kinds[unresolved_relocation_count] = kind;
            unresolved_relocation_count += 1;
        }
    }
    if (unresolved_relocation_count > builder->relocation_capacity - builder->result.relocation_count ||
        (instruction->metadata_private_pc8_long && private_relocation == UINT32_MAX))
    {
        assembly_x86_metadata_diagnostic(builder, BUSTER_X86_METADATA_ENCODE_RELOCATION_CAPACITY, instruction->line, instruction->column, 1);
        return false;
    }
    u32 unresolved_index = 0;
    for (u32 relocation_index = 0; relocation_index < emitted.relocation_count; relocation_index += 1)
    {
        BusterX86MetadataRelocation relocation = metadata_relocations[relocation_index];
        u32 symbol = assembly_symbol_find(builder, relocation.symbol);
        if (builder->result.symbols[symbol].defined)
        {
            continue;
        }
        bool private_pc8 = relocation_index == private_relocation;
        u64 relocation_offset = private_pc8 ? (u64)emitted.byte_count + 3u : relocation.offset;
        if (instruction->offset > UINT64_MAX - relocation_offset)
        {
            assembly_x86_metadata_diagnostic(builder, BUSTER_X86_METADATA_ENCODE_INVALID_EXPRESSION, instruction->line, instruction->column, 1);
            return false;
        }
        builder->result.relocations[builder->result.relocation_count++] = (AssemblyRelocation){
            .addend = private_pc8 ? relocation.addend - 3 : relocation.addend,
            .offset = instruction->offset + relocation_offset,
            .symbol = relocation_symbols[unresolved_index],
            .kind = private_pc8 ? ASSEMBLY_RELOCATION_X86_PC32 : relocation_kinds[unresolved_index],
        };
        unresolved_index += 1;
    }
    memcpy(builder->result.bytes.pointer + builder->output_count, bytes, emitted.byte_count);
    if (instruction->metadata_private_pc8_long)
    {
        u64 output = builder->output_count;
        BusterX86MetadataRelocation relocation = metadata_relocations[private_relocation];
        builder->result.bytes.pointer[output + relocation.offset] = 2;
        builder->result.bytes.pointer[output + emitted.byte_count] = 0xebu;
        builder->result.bytes.pointer[output + emitted.byte_count + 1u] = 5;
        builder->result.bytes.pointer[output + emitted.byte_count + 2u] = 0xe9u;
        memset(builder->result.bytes.pointer + output + emitted.byte_count + 3u, 0, sizeof(u32));
    }
    builder->output_count += instruction->size;
    return true;
}

BUSTER_GLOBAL_LOCAL bool assembly_aarch64_target_difference(s64 target, u64 place, s64* difference)
{
    if (!difference)
    {
        return false;
    }
    if (target >= 0)
    {
        u64 target_unsigned = (u64)target;
        if (target_unsigned >= place)
        {
            u64 magnitude = target_unsigned - place;
            if (magnitude > (u64)INT64_MAX)
            {
                return false;
            }
            *difference = (s64)magnitude;
            return true;
        }
        u64 magnitude = place - target_unsigned;
        if (magnitude > (u64)INT64_MAX + 1)
        {
            return false;
        }
        *difference = magnitude == (u64)INT64_MAX + 1 ? INT64_MIN : -(s64)magnitude;
        return true;
    }
    u64 target_magnitude = (u64)(-(target + 1)) + 1;
    if (place > (u64)INT64_MAX + 1 - target_magnitude)
    {
        return false;
    }
    u64 magnitude = place + target_magnitude;
    *difference = magnitude == (u64)INT64_MAX + 1 ? INT64_MIN : -(s64)magnitude;
    return true;
}

BUSTER_GLOBAL_LOCAL void assembly_instructions_emit(AssemblyBuilder* builder)
{
    bool emission_failed = false;
    for (u32 instruction_index = 0; instruction_index < builder->instruction_count && !emission_failed; instruction_index += 1)
    {
        AssemblyInstruction* instruction = builder->instructions + instruction_index;
        if (builder->output_count != instruction->offset)
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_STATEMENT, instruction->line, instruction->column, 1,
                                S8("internal instruction offset mismatch"));
            return;
        }
        if (instruction->metadata)
        {
            if (!assembly_x86_metadata_emit(builder, instruction))
            {
                return;
            }
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_FIXED_WORD)
        {
            assembly_emit_u32(builder, instruction->fixed_word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_SCALAR_MEMORY)
        {
            AssemblyRegister data = instruction->operands[0].reg;
            AssemblyMemory memory = instruction->operands[1].memory;
            u32 field_values[3] = {data.index, memory.base.index,
                                   (u32)(memory.displacement.unsigned_addend / (memory.width / 8u))};
            u32 word = 0;
            if (!a64_generated_production_raw_encode(instruction->aarch64_scalar_memory_form_id, field_values,
                                                      BUSTER_ARRAY_LENGTH(field_values), &word))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                    S8("AArch64 scalar memory instruction could not be encoded"));
                return;
            }
            assembly_emit_u32(builder, word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_GPR_ALIAS)
        {
            AssemblyRegister destination = instruction->operands[0].reg;
            AssemblyRegister source = instruction->operands[1].reg;
            u32 word = (destination.width == 64 ? UINT32_C(0xaa0003e0) : UINT32_C(0x2a0003e0)) |
                       ((u32)source.index << 16) | destination.index;
            assembly_emit_u32(builder, word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_M1_GPR)
        {
            A64GprOperand gpr_operands[4] = {0};
            for (u32 operand_index = 0; operand_index < instruction->operand_count; operand_index += 1)
            {
                AssemblyOperand operand = instruction->operands[operand_index];
                gpr_operands[operand_index] = (A64GprOperand){
                    .index = operand.reg.index,
                    .width = (u8)operand.reg.width,
                    .stack_pointer = operand.reg.stack_pointer,
                };
            }
            u32 word = 0;
            if (!buster_aarch64_gpr_encode_for_target(builder->target, instruction->aarch64_gpr_form_index, gpr_operands,
                                                       instruction->operand_count, &word))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                    S8("AArch64 instruction could not be encoded"));
                return;
            }
            assembly_emit_u32(builder, word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_DIRECT_SIMD)
        {
            u32 word = 0;
            BusterA64DirectSIMDInstruction direct_simd_instruction = {0};
            BusterA64DirectSIMDRowInfo row_info = {0};
            bool values_built = false;
            if (buster_a64_direct_simd_row(instruction->aarch64_direct_simd_row_index, &row_info) && row_info.transform_bearing)
            {
                BusterA64SemanticForm form = {0};
                u32 registers[4] = {0};
                BusterA64DirectSIMDArrangement arrangements[4] = {0};
                u32 conditions[4] = {0};
                u8 gpr_widths[4] = {0};
                for (u32 operand_index = 0; operand_index < instruction->operand_count && operand_index < 4; operand_index += 1)
                {
                    registers[operand_index] = instruction->aarch64_direct_simd_registers[operand_index];
                    arrangements[operand_index] =
                        (BusterA64DirectSIMDArrangement)instruction->aarch64_direct_simd_arrangements[operand_index];
                    conditions[operand_index] = instruction->aarch64_direct_simd_conditions[operand_index];
                    gpr_widths[operand_index] = instruction->aarch64_direct_simd_gpr_widths[operand_index];
                }
                values_built = buster_a64_semantic_form(row_info.semantic_form_id, &form) &&
                               assembly_aarch64_direct_simd_semantic_values_build(
                                   instruction->aarch64_direct_simd_row_index, form, registers, arrangements, conditions,
                                   gpr_widths, &direct_simd_instruction);
            }
            else
            {
                direct_simd_instruction = (BusterA64DirectSIMDInstruction){
                    .row_index = instruction->aarch64_direct_simd_row_index,
                    .operand_count = instruction->operand_count,
                };
                bool has_gpr = false;
                for (u32 operand_index = 0; operand_index < instruction->operand_count; operand_index += 1)
                {
                    has_gpr |= instruction->aarch64_direct_simd_gpr_widths[operand_index] != 0;
                }
                if (has_gpr)
                {
                    BusterA64SemanticForm form = {0};
                    values_built = buster_a64_semantic_form(row_info.semantic_form_id, &form) &&
                                   form.operand_count == instruction->operand_count;
                    for (u32 operand_index = 0; values_built && operand_index < instruction->operand_count; operand_index += 1)
                    {
                        BusterA64SemanticOperand operand = {0};
                        values_built = buster_a64_semantic_operand(form.operand_first + operand_index, &operand);
                        if (!values_built)
                        {
                            break;
                        }
                        if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_GPR_REGISTER)
                        {
                            direct_simd_instruction.operands[operand_index] = buster_a64_direct_simd_value_gpr(
                                instruction->aarch64_direct_simd_registers[operand_index],
                                instruction->aarch64_direct_simd_gpr_widths[operand_index],
                                instruction->aarch64_direct_simd_registers[operand_index] == 31);
                        }
                        else if (operand.kind == BUSTER_A64_SEMANTIC_OPERAND_SIMD_REGISTER)
                        {
                            BusterA64DirectSIMDArrangement arrangement =
                                (BusterA64DirectSIMDArrangement)instruction->aarch64_direct_simd_arrangements[operand_index];
                            bool scalar = arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B ||
                                          arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H ||
                                          arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S ||
                                          arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D;
                            direct_simd_instruction.operands[operand_index] =
                                scalar ? buster_a64_direct_simd_value_scalar(instruction->aarch64_direct_simd_registers[operand_index], arrangement)
                                       : buster_a64_direct_simd_value_vector(instruction->aarch64_direct_simd_registers[operand_index], arrangement);
                        }
                        else
                        {
                            values_built = false;
                        }
                        values_built = values_built &&
                                       direct_simd_instruction.operands[operand_index].kind != BUSTER_A64_SEMANTIC_VM_VALUE_INVALID;
                    }
                }
                else
                {
                    for (u32 operand_index = 0; operand_index < instruction->operand_count; operand_index += 1)
                    {
                        BusterA64DirectSIMDArrangement arrangement =
                            (BusterA64DirectSIMDArrangement)instruction->aarch64_direct_simd_arrangements[operand_index];
                        bool scalar = arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_B ||
                                      arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_H ||
                                      arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_S ||
                                      arrangement == BUSTER_A64_DIRECT_SIMD_ARRANGEMENT_D;
                        direct_simd_instruction.operands[operand_index] =
                            scalar ? buster_a64_direct_simd_value_scalar(instruction->aarch64_direct_simd_registers[operand_index], arrangement)
                                   : buster_a64_direct_simd_value_vector(instruction->aarch64_direct_simd_registers[operand_index], arrangement);
                    }
                    values_built = true;
                }
            }
            if (!values_built)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                    S8("AArch64 direct SIMD instruction could not be encoded"));
                return;
            }
            direct_simd_instruction.fixed_field_kind = instruction->aarch64_direct_simd_fixed_field_kind;
            direct_simd_instruction.fixed_field_value = instruction->aarch64_direct_simd_fixed_field_value;
            BusterA64DirectSIMDStatus status = buster_a64_direct_simd_encode(
                builder->target, &direct_simd_instruction, &word);
            if (status != BUSTER_A64_DIRECT_SIMD_STATUS_OK)
            {
                assembly_diagnostic(builder,
                                    status == BUSTER_A64_DIRECT_SIMD_STATUS_TARGET_MISMATCH
                                        ? ASSEMBLY_DIAGNOSTIC_UNSUPPORTED_FEATURE
                                        : ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS,
                                    instruction->line, instruction->column, 1,
                                    status == BUSTER_A64_DIRECT_SIMD_STATUS_TARGET_MISMATCH
                                        ? S8("instruction requires an enabled AArch64 target feature")
                                        : S8("AArch64 direct SIMD instruction could not be encoded"));
                return;
            }
            assembly_emit_u32(builder, word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_CONTROL)
        {
            u32 word = 0;
            if (!buster_aarch64_control_semantic_encode(&instruction->aarch64_control_instruction, &word))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                    S8("AArch64 control instruction could not be encoded"));
                return;
            }
            if (instruction->aarch64_control_private_long)
            {
                BusterAarch64ControlSemanticRecord row = {0};
                AssemblyRelocationKind kind = ASSEMBLY_RELOCATION_COUNT;
                AssemblyExpression expression = {0};
                if (buster_aarch64_control_semantic_row(instruction->aarch64_control_row_index, &row))
                {
                    if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_B_COND19) kind = ASSEMBLY_RELOCATION_AARCH64_CONDBR19;
                    else if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_COMPARE19) kind = ASSEMBLY_RELOCATION_AARCH64_COMPAREBR19;
                    else if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_TEST14) kind = ASSEMBLY_RELOCATION_AARCH64_TESTBR14;
                }
                u8 expression_index = instruction->aarch64_control_private_expression;
                bool expression_found = expression_index < 4 &&
                                        (instruction->aarch64_control_expression_mask & (u8)(1u << expression_index));
                expression = expression_found ? instruction->aarch64_control_expressions[expression_index] : (AssemblyExpression){0};
                u32 words[2] = {0};
                if (!expression_found || !assembly_aarch64_expand_private_short_branch_word(kind, word, words))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                        S8("AArch64 private branch instruction could not be expanded"));
                    return;
                }
                s64 target = 0;
                if (assembly_expression_target(builder, expression, &target))
                {
                    s64 displacement = 0;
                    if (!assembly_aarch64_target_difference(target, instruction->offset + sizeof(u32), &displacement) ||
                        !a64_pc_relative_patch(A64_OPCODE_B, words[1], displacement, &words[1]))
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE, instruction->line, instruction->column, 1,
                                            S8("AArch64 private branch target is out of range or unaligned"));
                        return;
                    }
                }
                else if (!assembly_relocation_append(builder, instruction->offset + sizeof(u32), expression,
                                                     ASSEMBLY_RELOCATION_AARCH64_BRANCH26, 0))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE, instruction->line, instruction->column, 1,
                                        S8("AArch64 private branch relocation addend is out of range"));
                    return;
                }
                assembly_emit_u32(builder, words[0]);
                assembly_emit_u32(builder, words[1]);
                continue;
            }
            for (u32 operand_index = 0; operand_index < 4; operand_index += 1)
            {
                if (!(instruction->aarch64_control_expression_mask & (u8)(1u << operand_index)))
                {
                    continue;
                }
                AssemblyExpression expression = instruction->aarch64_control_expressions[operand_index];
                s64 target = 0;
                if (!assembly_expression_target(builder, expression, &target))
                {
                    BusterAarch64ControlSemanticRecord row = {0};
                    AssemblyRelocationKind kind = ASSEMBLY_RELOCATION_COUNT;
                    String8 symbol_name = expression.has_symbol && expression.symbol < builder->result.symbol_count
                                              ? builder->result.symbols[expression.symbol].name
                                              : (String8){0};
                    bool private_label = builder->private_inline_labels && assembly_inline_private_label_name(symbol_name);
                    if (private_label && buster_aarch64_control_semantic_row(instruction->aarch64_control_row_index, &row))
                    {
                        if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_B_COND19) kind = ASSEMBLY_RELOCATION_AARCH64_CONDBR19;
                        else if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_COMPARE19) kind = ASSEMBLY_RELOCATION_AARCH64_COMPAREBR19;
                        else if (row.fixup_kind == BUSTER_AARCH64_CONTROL_FIXUP_TEST14) kind = ASSEMBLY_RELOCATION_AARCH64_TESTBR14;
                    }
                    if (kind == ASSEMBLY_RELOCATION_COUNT ||
                        !assembly_relocation_append(builder, instruction->offset, expression, kind, 0))
                    {
                        assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE, instruction->line, instruction->column, 1,
                                            S8("AArch64 control relocation requires a local branch label"));
                        return;
                    }
                    continue;
                }
                if (target < 0 || (u64)target > UINT64_MAX)
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE, instruction->line, instruction->column, 1,
                                        S8("AArch64 control target is out of range"));
                    return;
                }
                u32 patched = 0;
                BusterAarch64ControlFixupResult fixup = {0};
                if (!buster_aarch64_control_semantic_fixup(
                        instruction->aarch64_control_row_index, word,
                        (BusterAarch64ControlFixupRequest){
                            .target = builder->target,
                            .place_address = instruction->offset,
                            .target_address = (u64)target,
                            .symbol_defined = true,
                        },
                        &patched, &fixup))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE, instruction->line, instruction->column, 1,
                                        S8("AArch64 control target is out of range or unaligned"));
                    return;
                }
                word = patched;
            }
            assembly_emit_u32(builder, word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_SYSTEM_REGISTER)
        {
            u32 word = 0;
            bool encoded = instruction->aarch64_system_register_operation == ASSEMBLY_AARCH64_SYSTEM_REGISTER_MRS
                               ? aarch64_system_register_encode_mrs(instruction->aarch64_system_register_encoding,
                                                                    instruction->aarch64_system_register_rt, &word)
                               : instruction->aarch64_system_register_operation == ASSEMBLY_AARCH64_SYSTEM_REGISTER_MSR
                                     ? aarch64_system_register_encode_msr(instruction->aarch64_system_register_encoding,
                                                                          instruction->aarch64_system_register_rt, &word)
                                     : false;
            if (!encoded)
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                    S8("AArch64 system-register instruction could not be encoded"));
                emission_failed = true;
                continue;
            }
            assembly_emit_u32(builder, word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_SYSTEM_SEMANTICS)
        {
            u32 word = 0;
            if (!buster_aarch64_system_semantic_encode(builder->target, &instruction->aarch64_system_instruction, &word))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                    S8("AArch64 system instruction could not be encoded"));
                return;
            }
            assembly_emit_u32(builder, word);
            continue;
        }
        if (instruction->encoding_kind == ASSEMBLY_ENCODING_AARCH64_M1_SCALAR_INTEGER)
        {
            u32 word = 0;
            if (!buster_aarch64_scalar_integer_encode_for_target(builder->target, instruction->aarch64_scalar_integer_form_index,
                                                                  instruction->aarch64_scalar_integer_operands,
                                                                  instruction->aarch64_scalar_integer_operand_count,
                                                                  instruction->aarch64_scalar_integer_modifiers,
                                                                  instruction->aarch64_scalar_integer_modifier_count, &word))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                    S8("AArch64 instruction could not be encoded"));
                return;
            }
            assembly_emit_u32(builder, word);
            continue;
        }
        A64Opcode opcode = instruction->opcode == ASSEMBLY_OPCODE_AARCH64_NOP   ? A64_OPCODE_NOP
                           : instruction->opcode == ASSEMBLY_OPCODE_AARCH64_RET ? A64_OPCODE_RET
                           : instruction->opcode == ASSEMBLY_OPCODE_AARCH64_BL  ? A64_OPCODE_BL
                                                                                : A64_OPCODE_B;
        A64MCInst exact = {
            .opcode = opcode,
            .operand_count = opcode == A64_OPCODE_NOP ? 0 : 1,
        };
        if (opcode == A64_OPCODE_RET)
        {
            exact.operands[0] = (A64MCOperand){.value = 30, .kind = A64_MC_OPERAND_REGISTER};
        }
        else if (opcode == A64_OPCODE_B || opcode == A64_OPCODE_BL)
        {
            exact.operands[0] = (A64MCOperand){.kind = A64_MC_OPERAND_PC_RELATIVE};
        }
        u32 word = 0;
        if (!a64_mc_encode(&exact, &word))
        {
            assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_INVALID_OPERANDS, instruction->line, instruction->column, 1,
                                S8("AArch64 instruction could not be encoded"));
            return;
        }
        if (instruction->opcode == ASSEMBLY_OPCODE_AARCH64_B || instruction->opcode == ASSEMBLY_OPCODE_AARCH64_BL)
        {
            s64 target = 0;
            if (assembly_expression_target(builder, instruction->operands[0].expression, &target))
            {
                s64 displacement = 0;
                if (!assembly_aarch64_target_difference(target, instruction->offset, &displacement) ||
                    !a64_pc_relative_patch(opcode, word, displacement, &word))
                {
                    assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE, instruction->line, instruction->column, 1,
                                        S8("AArch64 branch target is out of range or unaligned"));
                }
            }
            else if (!assembly_relocation_append(builder, instruction->offset, instruction->operands[0].expression,
                                                 opcode == A64_OPCODE_BL ? ASSEMBLY_RELOCATION_AARCH64_CALL26
                                                                         : ASSEMBLY_RELOCATION_AARCH64_JUMP26,
                                                 0))
            {
                assembly_diagnostic(builder, ASSEMBLY_DIAGNOSTIC_BRANCH_OUT_OF_RANGE, instruction->line, instruction->column, 1,
                                    S8("AArch64 relocation addend is out of range"));
            }
        }
        assembly_emit_u32(builder, word);
    }
    if (!emission_failed)
    {
        builder->result.bytes.length = builder->output_count;
    }
}

AssemblyEncodeResult assembly_encode(Arena* arena, String8 source, AssemblyEncodeOptions options)
{
    AssemblyEncodeResult empty = {0};
    if (!arena || (source.length && !source.pointer))
    {
        return empty;
    }
    u32 line_count = 1;
    for (u64 index = 0; index < source.length; index += 1)
    {
        if (source.pointer[index] == '\n' && line_count != UINT32_MAX)
        {
            line_count += 1;
        }
    }
    if (line_count > UINT32_MAX / 2 ||
        line_count > UINT32_MAX / BUSTER_X86_METADATA_EMIT_RELOCATION_CAPACITY ||
        line_count > UINT32_MAX / ASSEMBLY_SOURCE_SYMBOLS_PER_LINE)
    {
        return empty;
    }
    AssemblyBuilder builder = {
        .arena = arena,
        .target = options.target,
        .private_inline_labels = options.private_inline_labels,
        // A small set of source aliases (currently WAIT-prefixed x87 FINIT
        // and FCLEX) expands into multiple metadata instructions.
        .instruction_capacity = line_count * 2,
        .symbol_capacity = line_count * ASSEMBLY_SOURCE_SYMBOLS_PER_LINE,
        .relocation_capacity = line_count * BUSTER_X86_METADATA_EMIT_RELOCATION_CAPACITY,
        .diagnostic_capacity = line_count * 4,
    };
    builder.result.symbols = arena_allocate(arena, AssemblySymbol, builder.symbol_capacity);
    builder.result.relocations = arena_allocate(arena, AssemblyRelocation, builder.relocation_capacity);
    builder.result.diagnostics = arena_allocate(arena, AssemblyDiagnostic, builder.diagnostic_capacity);
    memset(builder.result.symbols, 0, sizeof(*builder.result.symbols) * builder.symbol_capacity);
    bool valid_target = options.target.cpu_arch == CPU_ARCH_X86_64 || options.target.cpu_arch == CPU_ARCH_AARCH64;
    bool valid_syntax = options.syntax >= ASSEMBLY_SYNTAX_DEFAULT && options.syntax < ASSEMBLY_SYNTAX_COUNT &&
                        (options.target.cpu_arch == CPU_ARCH_X86_64 || options.syntax == ASSEMBLY_SYNTAX_DEFAULT);
    if (!valid_target)
    {
        assembly_diagnostic(&builder, ASSEMBLY_DIAGNOSTIC_INVALID_TARGET, 1, 1, 0, S8("assembly target must be x86-64 or AArch64"));
        return builder.result;
    }
    if (!valid_syntax)
    {
        assembly_diagnostic(&builder, ASSEMBLY_DIAGNOSTIC_INVALID_SYNTAX, 1, 1, 0, S8("syntax dialect is incompatible with the target"));
        return builder.result;
    }
    TemporalArena temporary = scratch_begin(&arena, 1);
    builder.instructions = arena_allocate(temporary.arena, AssemblyInstruction, builder.instruction_capacity);
    AssemblySyntax syntax = options.syntax == ASSEMBLY_SYNTAX_DEFAULT ? ASSEMBLY_SYNTAX_INTEL : options.syntax;
    assembly_source_parse(&builder, source, options.target, syntax);
    builder.result.bytes.pointer = arena_allocate(arena, u8, builder.output_capacity);
    assembly_instructions_emit(&builder);
    scratch_end(temporary);
    return builder.result;
}

#if BUSTER_INCLUDE_TESTS
bool assembly_test_aarch64_expand_private_short_branch(AssemblyRelocationKind kind, u32 word, u32 words[2])
{
    return assembly_aarch64_expand_private_short_branch_word(kind, word, words);
}

bool assembly_test_split_operands(String8 source, String8* operands, u32 operand_capacity, u32* operand_count)
{
    if (!operand_count || (source.length && !source.pointer) || (operand_capacity && !operands))
    {
        return false;
    }
    *operand_count = 0;
    u64 cursor = 0;
    while (cursor < source.length)
    {
        if (*operand_count >= operand_capacity || *operand_count >= ASSEMBLY_MAX_OPERANDS ||
            assembly_operand_split_next(source, &cursor, operands + *operand_count) != ASSEMBLY_OPERAND_SPLIT_SUCCESS)
        {
            return false;
        }
        *operand_count += 1;
    }
    return true;
}
#endif
