#include <buster/lib/compiler/codegen/machine.h>
#include <buster/lib/compiler/codegen/machine_schedule_internal.h>
#include <buster/lib/compiler/codegen/register_allocator_fast_internal.h>
#include <buster/lib/os.h>

// FRA stage 4: local fast register allocation over the compact machine IR.
// Included by machine.c in the backend-implementation-file pattern. A
// forward scan keeps values in registers between their uses inside one
// block, spills lazily on eviction, calls, and block boundaries, and forces
// the fixed-register operand layout for the constrained opcodes whose
// encoder sequences pin specific registers. The output is the same
// placement contract the MIR_STACK builder produces, so the encoder is
// untouched: per-slot operand registers plus a point-sorted reload/spill
// edit stream. Liveness is derived from the complete textual use/definition
// stream rather than MachineVirtualRegister.definition_point, so explicit
// mutable virtual registers are handled conservatively without an SSA
// assumption. `machine_fast_placement_build_pinned` then lays the frame out
// for both scan modes: `machine_fast_close_live_ranges` widens selector slots
// and proven direct-chain allocator homes to every row where their contents
// may still be read, and `machine_fast_color_homes` and
// `machine_fast_color_slots` give one storage per simultaneously live object
// instead of one per object.

// A physical register index is a bit lane, and every per-register predicate
// the pass carries is a mask: the scan's occupancy and dirtiness, the
// contract each block promises its predecessors, and the state each edge
// delivers. Nothing walks the register file to its fixed maximum — the walks
// iterate the lanes that can matter, which a stage-1 census puts at 2,75 of
// sixteen held at a block's exit and 0,60 promised by its contract. The
// per-block owner rows carry no free sentinel at all: a row is readable only
// where its block's held mask says so. `machine_fast_owner_match_mask` compares
// fully held sixteen-lane tiles with SIMD and walks other held lanes scalarly.

#define MACHINE_FAST_OPERAND_PHYSICAL_SHIFT 0u
#define MACHINE_FAST_OPERAND_VIRTUAL_SHIFT 4u
#define MACHINE_FAST_OPERAND_BLOCK_SHIFT 8u
#define MACHINE_FAST_OPERAND_USE_SHIFT 12u
#define MACHINE_FAST_OPERAND_DEFINE_SHIFT 16u
#define MACHINE_FAST_OPERAND_USE_DEFINE_SHIFT 20u
#define MACHINE_FAST_OPERAND_SIMPLE_ROW (1u << 24)
// The one opcode attribute the prepass's own second walk asks about. Recording
// it here while the row's descriptor is already in hand turns the next-call
// walk into a sequential read of this array: no opcode reload, no strided
// probe into the ninety-six-byte descriptor table.
#define MACHINE_FAST_OPERAND_CALL_ROW (1u << 25)
#define MACHINE_FAST_OPERAND_LANE_MASK 0x0fu
// The published opcode row keeps the three role nibbles contiguous from bit
// zero, and this word keeps them contiguous from bit twelve, so the whole
// role half of a row's classification is one shift of the table's field.
#define MACHINE_FAST_OPERAND_ROW_ROLE_SHIFT 12u
BUSTER_CT_CHECK(MACHINE_FAST_OPERAND_USE_SHIFT == MACHINE_FAST_OPERAND_ROW_ROLE_SHIFT + MACHINE_OPCODE_ROW_USE_SHIFT);
BUSTER_CT_CHECK(MACHINE_FAST_OPERAND_DEFINE_SHIFT == MACHINE_FAST_OPERAND_ROW_ROLE_SHIFT + MACHINE_OPCODE_ROW_DEFINE_SHIFT);
BUSTER_CT_CHECK(MACHINE_FAST_OPERAND_USE_DEFINE_SHIFT == MACHINE_FAST_OPERAND_ROW_ROLE_SHIFT + MACHINE_OPCODE_ROW_USE_DEFINE_SHIFT);
// Contract-held, contract-dirty, out-held and out-dirty: the four per-block
// register-file masks, allocated and cleared as one block.
#define MACHINE_FAST_BLOCK_MASK_COUNT 4u

BUSTER_GLOBAL_LOCAL u32 machine_fast_operand_mask(u32 operand_masks, u32 shift)
{
    return (operand_masks >> shift) & MACHINE_FAST_OPERAND_LANE_MASK;
}

// The register-file bit vocabulary. A physical register index is a lane, so
// every per-register predicate the scan carries — occupancy, dirtiness, the
// contract's promises — is one bit and every walk over it is a
// `remaining &= remaining - 1` loop over the set lanes instead of a scan to
// the file's fixed maximum.
BUSTER_GLOBAL_LOCAL u64 machine_fast_lane(u32 index)
{
    return 1ull << index;
}

BUSTER_GLOBAL_LOCAL bool machine_fast_lane_held(u64 mask, u32 index)
{
    return ((mask >> index) & 1u) != 0;
}

typedef struct MachineFastState MachineFastState;
struct MachineFastState
{
    Arena* arena;
    MachineFunction* function;
    // The target's register file and special-opcode identities; every
    // machine-specific decision below reads from here.
    MachineTargetDescription const* description;
    MachineStackPlacement* placement;
    MachineBuilderStream* edits;
    // Register file: owning vreg per physical register, age for LRU
    // eviction, and whether the register is newer than the vreg's slot.
    u32 owner[MACHINE_TARGET_REGISTER_LIMIT];
    u32 age[MACHINE_TARGET_REGISTER_LIMIT];
    // Occupancy and dirtiness are one bit per physical register, not byte
    // arrays: every consumer either tests a single lane or walks the held (or
    // held-and-dirty) lanes, and a mask does both without a fixed-maximum
    // scan. `held_mask` is exactly the lanes whose `owner` is not the free
    // sentinel, maintained by every site that binds or releases a register,
    // and `dirty_mask` is a subset of it.
    u64 held_mask;
    u64 dirty_mask;
    // Current register per vreg, or UINT32_MAX when the slot is the home.
    u32* virtual_register_locations;
    // Stage-5 liveness: the instruction index of each vreg's last textual
    // use, and whether any use sits outside the defining block. Escaping
    // values always reach their slots (loop-carried and layout-order
    // hazards live only across blocks); a non-escaping value strictly past
    // its last use is dead and its spill store is dropped.
    u32* last_use;
    u8* escapes;
    // Index of the next call at or after each instruction within its own
    // block, or UINT32_MAX: a value whose last use lies past it crosses
    // the call and is worth a callee-saved binding.
    u32* next_call;
    // Immediate index per vreg whose entire definition is one constant
    // materialization, or UINT32_MAX. Such a value is never stored and
    // never occupies a slot: any reload of it re-materializes instead.
    u32* rematerialize_immediates;
    // Pinned registers, owned by the QUALITY pass and invisible to the
    // local scan. `pin_active_masks` holds one register mask per
    // instruction scoping each reservation to its value's live span; null
    // means `pinned_mask` holds everywhere. The span arrays give each
    // pinned value its own inclusive instruction range, and the split
    // plans carry the boundary work for spans covering only part of a
    // value's life: contract installs at each span's head block and
    // landing-pad write-backs where a value lives past its span.
    u32 const* pinned_registers;
    u64 pinned_mask;
    u64 const* pin_active_masks;
    u32 const* pin_span_starts;
    u32 const* pin_span_ends;
    MachinePinSplitEntry const* split_entries;
    u32 split_entry_count;
    MachinePinSplitStore const* split_stores;
    u32 split_store_count;
    u32 split_store_cursor;
    // The register indices the scan's loops walk. The unified file puts
    // the vector registers past the general ones, and a function with no
    // vector virtual registers can never own one, so its loops stop at
    // the general file's end — the full-width `owner` state stays
    // initialized either way, which keeps the mask-driven clobber spills
    // (the float rows scribble low vector registers) safe no-ops.
    u32 active_register_count;
    u32 clock;
    u32 current_point;
    // Set once the current instruction's uses and defines are placed: from
    // there a value whose last use is this instruction has been read for
    // the final time, so the flush and write-back can drop its store.
    bool uses_consumed;
};

BUSTER_GLOBAL_LOCAL u64 machine_fast_class_mask(MachineFastState* state, u32 virtual_register);
BUSTER_GLOBAL_LOCAL bool machine_fast_source_dies_here(MachineFastState* state, u32 virtual_register);
BUSTER_GLOBAL_LOCAL void machine_fast_spill(MachineFastState* state, u32 physical_register);
BUSTER_GLOBAL_LOCAL u32 machine_fast_first_set(u64 mask);
BUSTER_GLOBAL_LOCAL u64 machine_fast_occupied(MachineFastState* state);

// The registers pinned values own at this instruction, which the local
// scan must stand clear of. Outside every pinned span the register is an
// ordinary member of the pool.
BUSTER_GLOBAL_LOCAL u64 machine_fast_pin_active(MachineFastState* state, u32 instruction_index)
{
    return state->pin_active_masks ? state->pin_active_masks[instruction_index] : state->pinned_mask;
}

// True when the virtual register is pinned and its span covers the
// instruction. A stage-8 span covers every occurrence of its value, so
// each one resolves to the pinned register; a split span opens later or
// closes earlier, and the value is an ordinary scan citizen at the
// occurrences outside.
BUSTER_GLOBAL_LOCAL bool machine_fast_pin_covers(MachineFastState* state, u32 virtual_register, u32 instruction_index)
{
    if (!state->pinned_registers || state->pinned_registers[virtual_register] == UINT32_MAX)
    {
        return false;
    }
    return !state->pin_span_starts ||
           (state->pin_span_starts[virtual_register] <= instruction_index && instruction_index <= state->pin_span_ends[virtual_register]);
}

BUSTER_GLOBAL_LOCAL u32 machine_fast_operand_class(MachineOpcodeInfo const* info, u32 slot)
{
    return (info->operand_info[slot] >> MACHINE_OPERAND_CLASS_SHIFT) & 0x7u;
}

BUSTER_GLOBAL_LOCAL u32 machine_fast_tied_destination(MachineOpcodeInfo const* info)
{
    u32 encoded = info ? (u32)(info->tied_pair & 0x0fu) : 0;
    return encoded ? encoded - 1u : UINT32_MAX;
}

BUSTER_GLOBAL_LOCAL u32 machine_fast_tied_source(MachineOpcodeInfo const* info)
{
    u32 encoded = info ? (u32)((info->tied_pair >> 4) & 0x0fu) : 0;
    return encoded ? encoded - 1u : UINT32_MAX;
}

BUSTER_GLOBAL_LOCAL u32 machine_fast_slot_scratch(MachineFastState* state, MachineOpcodeInfo const* info, u32 slot)
{
    return machine_fast_operand_class(info, slot) == MACHINE_REGISTER_CLASS_VECTOR ? state->description->vector_slot_scratch[slot]
                                                                                    : state->description->slot_scratch[slot];
}

// Materialize a tied source in the destination's register without stealing a
// live source binding.  A normal ensure is deliberately not used here: it
// moves the source's ownership, which is only sound when the source dies at
// this row.  If the source remains live, the old register stays owned by it
// and the destination receives a transient copy.  A source with no register
// is already current in its home slot, so a reload/rematerialization supplies
// the transient copy directly.
BUSTER_GLOBAL_LOCAL void machine_fast_materialize_tied(MachineFastState* state, u32 source, u32 target, bool source_dies)
{
    u32 current = state->virtual_register_locations[source];
    if (current == target && !source_dies)
    {
        // The fixed target is also the source's only register. Preserve SSA
        // by writing the source home. The register contents remain valid for
        // this row; the destination transfer below takes ownership after it.
        machine_fast_spill(state, target);
        MachineEdit* edit = (MachineEdit*)machine_stream_append(state->arena, state->edits);
        if (state->rematerialize_immediates[source] != UINT32_MAX)
        {
            *edit = (MachineEdit){
                .point = state->current_point,
                .kind = MACHINE_EDIT_REMATERIALIZE,
                .subject = state->rematerialize_immediates[source],
                .location = target,
            };
            state->placement->rematerialize_count += 1;
        }
        else
        {
            *edit = (MachineEdit){
                .point = state->current_point,
                .kind = MACHINE_EDIT_RELOAD,
                .subject = source,
                .location = target,
            };
            state->placement->reload_count += 1;
        }
        state->held_mask &= ~machine_fast_lane(target);
        state->dirty_mask &= ~machine_fast_lane(target);
        return;
    }
    if (current != UINT32_MAX)
    {
        machine_fast_spill(state, target);
        MachineEdit* copy = (MachineEdit*)machine_stream_append(state->arena, state->edits);
        *copy = (MachineEdit){
            .point = state->current_point,
            .kind = MACHINE_EDIT_COPY,
            .subject = current,
            .location = target,
        };
        state->placement->copy_count += 1;
        if (source_dies)
        {
            state->owner[current] = UINT32_MAX;
            state->held_mask &= ~machine_fast_lane(current);
            state->dirty_mask &= ~machine_fast_lane(current);
            state->virtual_register_locations[source] = UINT32_MAX;
        }
        state->owner[target] = UINT32_MAX;
        state->held_mask &= ~machine_fast_lane(target);
        state->dirty_mask &= ~machine_fast_lane(target);
        return;
    }
    machine_fast_spill(state, target);
    MachineEdit* edit = (MachineEdit*)machine_stream_append(state->arena, state->edits);
    if (state->rematerialize_immediates[source] != UINT32_MAX)
    {
        *edit = (MachineEdit){
            .point = state->current_point,
            .kind = MACHINE_EDIT_REMATERIALIZE,
            .subject = state->rematerialize_immediates[source],
            .location = target,
        };
        state->placement->rematerialize_count += 1;
    }
    else
    {
        *edit = (MachineEdit){
            .point = state->current_point,
            .kind = MACHINE_EDIT_RELOAD,
            .subject = source,
            .location = target,
        };
        state->placement->reload_count += 1;
    }
    state->owner[target] = UINT32_MAX;
    state->held_mask &= ~machine_fast_lane(target);
    state->dirty_mask &= ~machine_fast_lane(target);
}

BUSTER_GLOBAL_LOCAL bool machine_fast_owner_is_dead(MachineFastState* state, u32 physical_register)
{
    u32 owner = state->owner[physical_register];
    bool result;
    if (owner == UINT32_MAX)
    {
        result = false;
    }
    else
    {
        u32 current_index = state->current_point >> 2;
        u32 last = state->last_use[owner];
        // A value confined to its defining block is redefined before every
        // repeat of that block, so passing its last use retires it. Escaping
        // values always reach their slots.
        result = !state->escapes[owner] && (state->uses_consumed ? current_index >= last : current_index > last);
    }

    return result;
}

BUSTER_GLOBAL_LOCAL void machine_fast_spill(MachineFastState* state, u32 physical_register)
{
    u32 owner = state->owner[physical_register];
    if (owner == UINT32_MAX)
    {
        return;
    }
    if (machine_fast_lane_held(state->dirty_mask, physical_register) && state->rematerialize_immediates[owner] == UINT32_MAX &&
        !machine_fast_owner_is_dead(state, physical_register))
    {
        MachineEdit* edit = (MachineEdit*)machine_stream_append(state->arena, state->edits);
        *edit = (MachineEdit){
            .point = state->current_point,
            .kind = MACHINE_EDIT_SPILL,
            .subject = owner,
            .location = physical_register,
        };
        state->placement->spill_count += 1;
    }
    state->owner[physical_register] = UINT32_MAX;
    state->held_mask &= ~machine_fast_lane(physical_register);
    state->dirty_mask &= ~machine_fast_lane(physical_register);
    state->virtual_register_locations[owner] = UINT32_MAX;
}

// Spills every held register outside `keep_mask`, ascending. The occupancy
// mask visits only the held lanes; the whole-file walk it replaces let the
// spill's own empty-owner test reject the rest, one call per lane.
BUSTER_GLOBAL_LOCAL void machine_fast_flush(MachineFastState* state, u64 keep_mask)
{
    for (u64 remaining = machine_fast_occupied(state) & ~keep_mask; remaining; remaining &= remaining - 1u)
    {
        machine_fast_spill(state, machine_fast_first_set(remaining));
    }
}

// Stage-5 edge contracts. A block's contract is the register file it may
// assume at entry: an owning virtual register and a dirtiness per physical
// register, agreed once when the block is scanned and then satisfied by
// every edge into it. An edge whose delivered state differs conforms — the
// difference becomes edits at the source terminator's BEFORE point, so a
// value stays in its register across the boundary instead of round-tripping
// through its slot the way the old unconditional write-back forced.
BUSTER_GLOBAL_LOCAL u32 const machine_fast_empty_contract_owner[MACHINE_TARGET_REGISTER_LIMIT] = {
    UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX,
    UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX,
    UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX,
    UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX,
    UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX,
    UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX,
};
BUSTER_GLOBAL_LOCAL void machine_fast_conform_append(MachineFastState* state, MachineBuilderStream* stream, MachinePoint point, u16 kind, u32 subject,
                                                     u32 location)
{
    MachineEdit* edit = (MachineEdit*)machine_stream_append(state->arena, stream);
    *edit = (MachineEdit){
        .point = point,
        .kind = kind,
        .subject = subject,
        .location = location,
    };
}

// Only held lanes have initialized owner rows. Full sixteen-lane tiles can
// use one AVX-512 dword compare; sparse tiles keep the existing set-bit walk.
// The active mask also bounds partial target files, including lane 63, so no
// padded owner storage or inactive-row reads are required.
BUSTER_GLOBAL_LOCAL u64 machine_fast_owner_match_mask(u32 const* owner, u64 active, u32 value)
{
    u64 matches = 0;
#if BUSTER_SIMD_512
    if (mask64_count(active) >= 16)
    {
        u64 dense = active & (active >> 1);
        dense &= dense >> 2;
        dense &= dense >> 4;
        dense &= dense >> 8;
        dense &= UINT64_C(0x0001000100010001);
        if (dense)
        {
            Simd512 needle = simd512_splat_word(value);
            for (; dense; dense &= dense - 1u)
            {
                u32 base = machine_fast_first_set(dense);
                Simd512 owners = simd512_load(owner + base);
                matches |= (u64)simd512_equal_word(owners, needle) << base;
                active &= ~(UINT64_C(0xffff) << base);
            }
        }
    }
#endif
    for (; active; active &= active - 1u)
    {
        u32 physical_register = machine_fast_first_set(active);
        matches |= owner[physical_register] == value ? machine_fast_lane(physical_register) : 0;
    }
    return matches;
}

// Existence-only consumers need not finish a sparse walk after finding an
// owner. Dense populations keep the full-mask helper's guarded SIMD tiles;
// duplicate removal still requests every match through that helper directly.
BUSTER_GLOBAL_LOCAL bool machine_fast_owner_contains(u32 const* owner, u64 active, u32 value)
{
    bool result = false;
#if BUSTER_SIMD_512
    if (mask64_count(active) >= 16)
    {
        result = machine_fast_owner_match_mask(owner, active, value) != 0;
    }
    else
#endif
    {
        for (; active && !result; active &= active - 1u)
        {
            result = owner[machine_fast_first_set(active)] == value;
        }
    }
    return result;
}

#if BUSTER_INCLUDE_TESTS
bool machine_fast_owner_contains_test(u32 const* owner, u64 active, u32 value)
{
    return machine_fast_owner_contains(owner, active, value);
}

u64 machine_fast_owner_match_mask_test(u32 const* owner, u64 active, u32 value)
{
    return machine_fast_owner_match_mask(owner, active, value);
}
#endif

// Rewrites one edge's delivered register file into the shape a successor's
// contract promises. Values the contract leaves in memory write back (the
// boundary spills the old write-back emitted for every boundary), and the
// values it keeps in registers resolve as a parallel move set: a copy when
// the value is already in a register, a rematerialization or reload when it
// is not, and a spill through memory as the cycle breaker when every
// remaining contract register still holds another pending value's only
// dirty copy. `owner`/`held`/`dirty` are either the live scan state at a
// terminator whose successor contract is already fixed (`locations`
// alongside) or a recorded edge snapshot (locations null, conforming
// retroactively while a later block chooses its contract); the two masks
// travel by pointer because a snapshot's mutations must persist for the
// source's other successors. `contract_held` names the registers the
// contract promises and is the only thing that makes `contract_owner`
// readable. `allow_moves` is false for a snapshot edge whose source has
// other successors: a copy or reload there would also execute on paths
// that already consumed the snapshot state, so such an edge is only ever
// asked for the universally safe spills — the contract construction drops
// any entry the edge does not already satisfy.
//
// Every walk here is over a mask of the lanes that can matter, not over the
// register file: a stage-1 census put the three fixed-maximum scans this
// replaced at 9,4 M iterations of which 0,4 M did work, and the quadratic
// retention probe at 4,5 M more.
BUSTER_GLOBAL_LOCAL void machine_fast_conform_edge(MachineFastState* state, MachineBuilderStream* stream, MachinePoint point, u32* owner, u64* held,
                                                   u64* dirty, u32* locations, u32 const* contract_owner, u64 contract_held, u64 contract_dirty,
                                                   bool allow_moves)
{
    // Pass 1: write back what the contract sends home. Mappings survive —
    // the successor ignores them, a layout successor that designates this
    // edge still reuses the clean copies, and any register a contract value
    // needs is reclaimed by the placement pass below. Values that never
    // escape their block are dead at a boundary and rematerializable
    // constants never store, exactly as the eviction path treats them. Only
    // the dirty lanes can owe a store, and dirty implies held.
    for (u64 remaining = *dirty; remaining; remaining &= remaining - 1u)
    {
        u32 physical_register = machine_fast_first_set(remaining);
        u32 resident = owner[physical_register];
        if (machine_fast_owner_contains(contract_owner, contract_held, resident))
        {
            continue;
        }
        if (state->escapes[resident] && state->rematerialize_immediates[resident] == UINT32_MAX)
        {
            machine_fast_conform_append(state, stream, point, MACHINE_EDIT_SPILL, resident, physical_register);
            state->placement->spill_count += 1;
            state->placement->boundary_spill_count += 1;
        }
        *dirty &= ~machine_fast_lane(physical_register);
    }
    // Pass 2: place every contract value not already in its register. An
    // entry whose value's own pinned span covers this edge's source is
    // already satisfied by the span invariant — the register carries the
    // value there even though the scan's file does not track it — and
    // installing it again would run once per iteration on a backward
    // edge, which is exactly the traffic a split span exists to remove.
    u32 source_instruction = machine_point_instruction(point);
    u64 pending = 0;
    for (u64 remaining = contract_held; remaining; remaining &= remaining - 1u)
    {
        u32 contract_register = machine_fast_first_set(remaining);
        u32 contract_value = contract_owner[contract_register];
        if (machine_fast_lane_held(*held, contract_register) && owner[contract_register] == contract_value)
        {
            continue;
        }
        if (state->pinned_registers && state->pinned_registers[contract_value] == contract_register &&
            machine_fast_pin_covers(state, contract_value, source_instruction))
        {
            continue;
        }
        pending |= machine_fast_lane(contract_register);
    }
    while (pending)
    {
        BUSTER_CHECK(allow_moves);
        bool progressed = false;
        for (u64 remaining = pending; remaining; remaining &= remaining - 1u)
        {
            u32 contract_register = machine_fast_first_set(remaining);
            u32 value = contract_owner[contract_register];
            u32 resident = machine_fast_lane_held(*held, contract_register) ? owner[contract_register] : UINT32_MAX;
            if (resident != UINT32_MAX && resident != value && machine_fast_lane_held(*dirty, contract_register))
            {
                // The occupant blocks the claim only while it is another
                // pending value's single dirty copy; a clean occupant
                // reloads at its own turn, its slot current by the
                // clean-implies-stored invariant.
                if (machine_fast_owner_contains(contract_owner, pending, resident))
                {
                    continue;
                }
            }
            if (resident != UINT32_MAX && resident != value)
            {
                owner[contract_register] = UINT32_MAX;
                if (locations)
                {
                    locations[resident] = UINT32_MAX;
                }
                *held &= ~machine_fast_lane(contract_register);
                *dirty &= ~machine_fast_lane(contract_register);
            }
            u32 source = UINT32_MAX;
            if (locations)
            {
                source = locations[value];
            }
            else
            {
                for (u64 other_remaining = *held; other_remaining; other_remaining &= other_remaining - 1u)
                {
                    u32 other = machine_fast_first_set(other_remaining);
                    source = owner[other] == value ? other : source;
                }
            }
            if (source != UINT32_MAX)
            {
                machine_fast_conform_append(state, stream, point, MACHINE_EDIT_COPY, source, contract_register);
                state->placement->copy_count += 1;
                state->placement->boundary_copy_count += 1;
                *dirty = machine_fast_lane_held(*dirty, source) ? *dirty | machine_fast_lane(contract_register)
                                                                : *dirty & ~machine_fast_lane(contract_register);
                owner[source] = UINT32_MAX;
                *held &= ~machine_fast_lane(source);
                *dirty &= ~machine_fast_lane(source);
            }
            else if (state->rematerialize_immediates[value] != UINT32_MAX)
            {
                machine_fast_conform_append(state, stream, point, MACHINE_EDIT_REMATERIALIZE, state->rematerialize_immediates[value], contract_register);
                state->placement->rematerialize_count += 1;
                *dirty &= ~machine_fast_lane(contract_register);
            }
            else
            {
                machine_fast_conform_append(state, stream, point, MACHINE_EDIT_RELOAD, value, contract_register);
                state->placement->reload_count += 1;
                state->placement->boundary_reload_count += 1;
                *dirty &= ~machine_fast_lane(contract_register);
            }
            owner[contract_register] = value;
            *held |= machine_fast_lane(contract_register);
            if (locations)
            {
                locations[value] = contract_register;
            }
            pending &= ~machine_fast_lane(contract_register);
            progressed = true;
        }
        if (!progressed)
        {
            // Every remaining target holds another pending value's only
            // dirty copy: a cycle. Break it through memory — write one
            // occupant back and release it, and its own claim reloads it.
            u32 broken = machine_fast_first_set(pending);
            u32 resident = owner[broken];
            machine_fast_conform_append(state, stream, point, MACHINE_EDIT_SPILL, resident, broken);
            state->placement->spill_count += 1;
            state->placement->boundary_spill_count += 1;
            *dirty &= ~machine_fast_lane(broken);
            owner[broken] = UINT32_MAX;
            *held &= ~machine_fast_lane(broken);
            if (locations)
            {
                locations[resident] = UINT32_MAX;
            }
        }
    }
    // Pass 3: a delivery dirtier than the contract admits stores now — the
    // successor believes the slot is current and would evict silently. A
    // cleaner delivery than promised is free, so only the lanes the contract
    // promises clean and this edge leaves dirty can owe anything.
    for (u64 remaining = contract_held & *dirty & ~contract_dirty; remaining; remaining &= remaining - 1u)
    {
        u32 contract_register = machine_fast_first_set(remaining);
        u32 value = contract_owner[contract_register];
        if (machine_fast_lane_held(*held, contract_register) && owner[contract_register] == value)
        {
            machine_fast_conform_append(state, stream, point, MACHINE_EDIT_SPILL, value, contract_register);
            state->placement->spill_count += 1;
            state->placement->boundary_spill_count += 1;
            *dirty &= ~machine_fast_lane(contract_register);
        }
    }
}

// Edge copies are SSA block-parameter assignments. The predecessor contract
// names source values, while the successor contract names the parameters.
// Capture every source into the edge-copy tile before publishing any
// destination so cycles and repeated sources retain parallel-copy semantics.
BUSTER_GLOBAL_LOCAL bool machine_fast_edge_can_move(MachineFunction* function, MachineEdge const* edge)
{
    if (!function || !edge || edge->source_block >= function->block_count || !function->blocks[edge->source_block].instruction_count)
    {
        return false;
    }
    MachineBlock const* source_block = function->blocks + edge->source_block;
    MachineInstruction const* terminator = function->instructions + source_block->first_instruction + source_block->instruction_count - 1u;
    MachineOpcodeInfo const* info = machine_opcode_info(terminator->opcode);
    if (!info || (function->target && (terminator->opcode == function->target->switch_opcode || terminator->opcode == MACHINE_X64_INDIRECT_BRANCH ||
                                       terminator->opcode == MACHINE_A64_INDIRECT_BRANCH)))
    {
        return false;
    }
    u32 target_count = 0;
    for (u32 slot = 0; slot < info->operand_count; slot += 1)
    {
        target_count += machine_ref_kind(terminator->operands[slot]) == MACHINE_REF_BLOCK;
    }
    return target_count == 1;
}

BUSTER_GLOBAL_LOCAL void machine_fast_conform_edge_parameters(MachineFastState* state, MachineBuilderStream* stream, MachinePoint point,
                                                              MachineEdge const* edge, u32* owner, u64* held, u64* dirty, u32* locations,
                                                              u32 const* contract_owner, u64 contract_held, u64 contract_dirty, bool allow_moves)
{
    if (!edge || !edge->copy_count || !state->function->edge_copy_sources || !state->function->block_parameters ||
        !machine_fast_edge_can_move(state->function, edge))
    {
        machine_fast_conform_edge(state, stream, point, owner, held, dirty, locations, contract_owner, contract_held, contract_dirty, allow_moves);
        return;
    }
    MachineBlock const* destination = state->function->blocks + edge->destination_block;
    u32 copy_count = BUSTER_MIN(edge->copy_count, destination->parameter_count);
    // Capture resident and pinned sources before flushing the predecessor.
    // A source with no direct location may still have a dirty predecessor
    // alias, so its home is safe to reload only after that flush.
    TemporalArena temporary = scratch_begin(&state->arena, 1);
    u8* captured = arena_allocate(temporary.arena, u8, copy_count);
    memset(captured, 0, copy_count);
    u32 temporary_offset = 0;
    for (u32 copy_index = 0; copy_index < copy_count; copy_index += 1)
    {
        MachineRef source = state->function->edge_copy_sources[edge->copy_offset + copy_index];
        u32 destination_value = state->function->block_parameters[destination->parameter_offset + copy_index].virtual_register;
        bool vector = state->function->virtual_registers[destination_value].register_class == MACHINE_REGISTER_CLASS_VECTOR;
        temporary_offset = vector ? (temporary_offset + 15u) & ~15u : temporary_offset;
        temporary_offset += vector ? 64u : 8u;
        u32 source_value = machine_ref_kind(source) == MACHINE_REF_VIRTUAL_REGISTER ? machine_ref_payload(source) : UINT32_MAX;
        u32 source_register = machine_ref_kind(source) == MACHINE_REF_PHYSICAL_REGISTER ? machine_ref_payload(source) : UINT32_MAX;
        if (source_value != UINT32_MAX)
        {
            if (locations)
            {
                source_register = locations[source_value];
            }
            else
            {
                for (u64 remaining = *held; remaining && source_register == UINT32_MAX; remaining &= remaining - 1u)
                {
                    u32 physical = machine_fast_first_set(remaining);
                    source_register = owner[physical] == source_value ? physical : source_register;
                }
            }
            if (state->pinned_registers && state->pinned_registers[source_value] != UINT32_MAX &&
                machine_fast_pin_covers(state, source_value, machine_point_instruction(point)))
            {
                source_register = state->pinned_registers[source_value];
            }
        }
        if (source_register != UINT32_MAX)
        {
            machine_fast_conform_append(state, stream, point, MACHINE_EDIT_TEMP_SPILL, temporary_offset, source_register);
            captured[copy_index] = 1;
        }
    }
    machine_fast_conform_edge(state, stream, point, owner, held, dirty, locations, machine_fast_empty_contract_owner, 0, 0, true);
    // The physical values still present after an empty conformance carry the
    // predecessor's SSA names. An edge assignment ends those names even when
    // a clean register happens to contain identical bits, so the successor
    // must rebuild its contract from the newly published parameter homes.
    for (u64 remaining = *held; remaining; remaining &= remaining - 1u)
    {
        u32 physical = machine_fast_first_set(remaining);
        u32 previous = owner[physical];
        if (locations && previous != UINT32_MAX && locations[previous] == physical)
        {
            locations[previous] = UINT32_MAX;
        }
        owner[physical] = UINT32_MAX;
    }
    *held = 0;
    *dirty = 0;
    temporary_offset = 0;
    for (u32 copy_index = 0; copy_index < copy_count; copy_index += 1)
    {
        MachineRef source = state->function->edge_copy_sources[edge->copy_offset + copy_index];
        u32 destination_value = state->function->block_parameters[destination->parameter_offset + copy_index].virtual_register;
        bool vector = state->function->virtual_registers[destination_value].register_class == MACHINE_REGISTER_CLASS_VECTOR;
        temporary_offset = vector ? (temporary_offset + 15u) & ~15u : temporary_offset;
        temporary_offset += vector ? 64u : 8u;
        if (!captured[copy_index])
        {
            BUSTER_CHECK(machine_ref_kind(source) == MACHINE_REF_VIRTUAL_REGISTER);
            u32 source_value = machine_ref_payload(source);
            u32 scratch = vector ? state->description->vector_slot_scratch[0] : state->description->slot_scratch[0];
            if (state->rematerialize_immediates[source_value] != UINT32_MAX)
            {
                machine_fast_conform_append(state, stream, point, MACHINE_EDIT_REMATERIALIZE,
                                            state->rematerialize_immediates[source_value], scratch);
                state->placement->rematerialize_count += 1;
            }
            else
            {
                machine_fast_conform_append(state, stream, point, MACHINE_EDIT_RELOAD, source_value, scratch);
                state->placement->reload_count += 1;
                state->placement->boundary_reload_count += 1;
            }
            machine_fast_conform_append(state, stream, point, MACHINE_EDIT_TEMP_SPILL, temporary_offset, scratch);
        }
    }
    temporary_offset = 0;
    for (u32 copy_index = 0; copy_index < copy_count; copy_index += 1)
    {
        u32 destination_value = state->function->block_parameters[destination->parameter_offset + copy_index].virtual_register;
        bool vector = state->function->virtual_registers[destination_value].register_class == MACHINE_REGISTER_CLASS_VECTOR;
        temporary_offset = vector ? (temporary_offset + 15u) & ~15u : temporary_offset;
        temporary_offset += vector ? 64u : 8u;
        u8 scratch = vector ? state->description->vector_slot_scratch[0] : state->description->slot_scratch[0];
        if (state->pinned_registers && state->pinned_registers[destination_value] != UINT32_MAX && destination->instruction_count &&
            machine_fast_pin_covers(state, destination_value, destination->first_instruction))
        {
            scratch = (u8)state->pinned_registers[destination_value];
        }
        machine_fast_conform_append(state, stream, point, MACHINE_EDIT_TEMP_RELOAD, temporary_offset, scratch);
        machine_fast_conform_append(state, stream, point, MACHINE_EDIT_SPILL, destination_value, scratch);
        state->placement->spill_count += 1;
        state->placement->boundary_spill_count += 1;
    }
    machine_fast_conform_edge(state, stream, point, owner, held, dirty, locations, contract_owner, contract_held, contract_dirty, allow_moves);
    scratch_end(temporary);
}

BUSTER_GLOBAL_LOCAL u32 machine_fast_edge_mapped_owner(MachineFunction* function, MachineEdge const* edge, u32 value, u32 const* owner,
                                                       u32 register_count)
{
    BUSTER_UNUSED(owner);
    BUSTER_UNUSED(register_count);
    if (function && edge && value != UINT32_MAX && function->edge_copy_sources && function->block_parameters)
    {
        MachineBlock const* destination = function->blocks + edge->destination_block;
        u32 copy_count = BUSTER_MIN(edge->copy_count, destination->parameter_count);
        for (u32 copy_index = 0; copy_index < copy_count; copy_index += 1)
        {
            u32 source_index = edge->copy_offset + copy_index;
            if (source_index >= function->edge_copy_source_count)
            {
                break;
            }
            MachineRef source = function->edge_copy_sources[source_index];
            if (machine_ref_kind(source) != MACHINE_REF_VIRTUAL_REGISTER || machine_ref_payload(source) != value)
            {
                continue;
            }
            // Name the parameter even when the source is currently spilled. The
            // conform resolver then emits a reload into the parameter's contract
            // register; retaining the source name would lose the SSA assignment.
            return function->block_parameters[destination->parameter_offset + copy_index].virtual_register;
        }
    }

    return value;
}

// Retroactive edits target points the main stream has already passed, in
// whatever order later contract constructions reached them; the encoder
// walks one sorted cursor. Bottom-up stable merge sort — a single-successor
// edge's repair sequence is a little program whose internal order is
// meaning.
BUSTER_GLOBAL_LOCAL void machine_fast_sort_edits(MachineEdit* edits, MachineEdit* scratch, u32 count)
{
    for (u32 width = 1; width < count; width *= 2)
    {
        for (u32 start = 0; start < count; start += 2 * width)
        {
            u32 middle = BUSTER_MIN(start + width, count);
            u32 limit = BUSTER_MIN(start + 2 * width, count);
            u32 left = start;
            u32 right = middle;
            u32 out = start;
            while (left < middle && right < limit)
            {
                scratch[out++] = edits[right].point < edits[left].point ? edits[right++] : edits[left++];
            }
            while (left < middle)
            {
                scratch[out++] = edits[left++];
            }
            while (right < limit)
            {
                scratch[out++] = edits[right++];
            }
        }
        for (u32 index = 0; index < count; index += 1)
        {
            edits[index] = scratch[index];
        }
    }
}

// True when the virtual register has no use after the instruction being
// scanned: its uses are all in the defining block and the last of them is
// this instruction, which the use pass has already consumed.
BUSTER_GLOBAL_LOCAL bool machine_fast_source_dies_here(MachineFastState* state, u32 virtual_register)
{
    return !state->escapes[virtual_register] && state->last_use[virtual_register] == (state->current_point >> 2);
}

// True when the virtual register stays live past the next call in the
// current block, making a callee-saved binding worth its push/pop pair.
BUSTER_GLOBAL_LOCAL bool machine_fast_crosses_call(MachineFastState* state, u32 virtual_register)
{
    u32 upcoming_call = state->next_call[state->current_point >> 2];
    return upcoming_call != UINT32_MAX && state->last_use[virtual_register] > upcoming_call;
}

// The register file a virtual register may draw from: its class's
// allocatable mask. The vector file shares the scan, the contracts, and
// the edit stream with the general one — only the candidate set differs.
BUSTER_GLOBAL_LOCAL u64 machine_fast_class_mask(MachineFastState* state, u32 virtual_register)
{
    return state->function->virtual_registers[virtual_register].register_class == MACHINE_REGISTER_CLASS_VECTOR
               ? state->description->vector_allocatable_mask
               : state->description->allocatable_mask;
}

BUSTER_GLOBAL_LOCAL u32 machine_fast_first_set(u64 mask)
{
#if BUSTER_COMPILER_CLANG || BUSTER_COMPILER_GCC
    return (u32)__builtin_ctzll(mask);
#else
    u32 result = 0;
    while (!(mask & 1u))
    {
        mask >>= 1;
        result += 1;
    }
    return result;
#endif
}

// The free members of a candidate set, and the held lanes of the file. Both
// are one bit-mask operation against `held_mask`, which the scan maintains at
// every site that binds or releases a register: the picker asks this question
// about a million times in a stage-1 compile and the file it would otherwise
// re-derive is 192 bytes of owner rows.
//
// This replaces a `vpcmpeqd` kernel that compared the whole owner file against
// the all-ones free sentinel in three fixed 512-bit chunks. The kernel was the
// right shape while occupancy had no other keeper; once the block snapshots
// became masks the scan already had to carry one, and re-deriving it was pure
// duplication. `machine_fast_occupied` still clamps to the active count so a
// fixed-register owner past the file a function uses cannot widen the walks
// the reduced count exists to shorten.
BUSTER_GLOBAL_LOCAL u64 machine_fast_free_candidates(MachineFastState* state, u64 candidates)
{
    return candidates & ~state->held_mask;
}

BUSTER_GLOBAL_LOCAL u64 machine_fast_occupied(MachineFastState* state)
{
    BUSTER_CT_CHECK(MACHINE_TARGET_REGISTER_LIMIT < 64u);
    return state->held_mask & ((1ull << state->active_register_count) - 1u);
}

// Picks a free allocatable register, else evicts the least recently used
// owner — a probe bounded by the register-file size. Call-crossing values
// reach for the callee-saved members; everything else only touches them
// once another binding has already paid their push.
BUSTER_GLOBAL_LOCAL u32 machine_fast_pick(MachineFastState* state, u64 class_mask, u64 forbidden_mask, bool prefers_callee_saved)
{
    u64 candidates = class_mask & ~forbidden_mask & ~machine_fast_pin_active(state, state->current_point >> 2);
    if (!prefers_callee_saved)
    {
        // Avoid paying a new callee-saved push for a value that does not
        // cross a call — unless the unpaid members are all that remain,
        // which caller-saved span pins can arrange.
        u64 without_unpaid = candidates & ~(state->description->callee_saved_mask & ~state->placement->callee_saved_mask);
        candidates = without_unpaid ? without_unpaid : candidates;
    }
    u64 preferred_class = prefers_callee_saved ? state->description->callee_saved_mask : ~state->description->callee_saved_mask;
    u64 free = machine_fast_free_candidates(state, candidates);
    u64 preferred_free = free & preferred_class;
    if (preferred_free)
    {
        return machine_fast_first_set(preferred_free);
    }
    if (free)
    {
        return machine_fast_first_set(free);
    }

    u32 best = UINT32_MAX;
    u32 best_age = UINT32_MAX;
    u32 dead = UINT32_MAX;
    // Every candidate is held once no free one exists; walk the candidate
    // bits, ascending as the file walk was, rather than the whole file.
    for (u64 remaining = candidates; remaining; remaining &= remaining - 1u)
    {
        u32 physical_register = machine_fast_first_set(remaining);
        // A dead owner costs nothing to displace: its spill is dropped.
        if (dead == UINT32_MAX && machine_fast_owner_is_dead(state, physical_register))
        {
            dead = physical_register;
        }
        if (state->age[physical_register] < best_age)
        {
            best_age = state->age[physical_register];
            best = physical_register;
        }
    }
    if (dead != UINT32_MAX)
    {
        best = dead;
    }
    BUSTER_CHECK(best < state->active_register_count); // The caller must leave an allocatable candidate.
    machine_fast_spill(state, best);
    return best;
}

// Materializes `virtual_register` in `target` (UINT32_MAX picks freely) and
// returns the register used.
BUSTER_GLOBAL_LOCAL u32 machine_fast_ensure(MachineFastState* state, u32 virtual_register, u32 target, u64 forbidden_mask)
{
    u32 current = state->virtual_register_locations[virtual_register];
    if (target == UINT32_MAX)
    {
        if (current != UINT32_MAX)
        {
            state->age[current] = ++state->clock;
            return current;
        }
        target = machine_fast_pick(state, machine_fast_class_mask(state, virtual_register), forbidden_mask,
                                   machine_fast_crosses_call(state, virtual_register));
    }
    if (current == target)
    {
        state->age[target] = ++state->clock;
        return target;
    }
    // Evict the target's stale owner first; then the value either copies
    // register-to-register when it already lives in one, carrying its
    // dirtiness, or reloads from its slot.
    machine_fast_spill(state, target);
    MachineEdit* edit = (MachineEdit*)machine_stream_append(state->arena, state->edits);
    if (current != UINT32_MAX)
    {
        *edit = (MachineEdit){
            .point = state->current_point,
            .kind = MACHINE_EDIT_COPY,
            .subject = current,
            .location = target,
        };
        state->placement->copy_count += 1;
        state->dirty_mask = (state->dirty_mask & ~machine_fast_lane(target)) |
                            ((state->dirty_mask >> current) & 1u ? machine_fast_lane(target) : 0u);
        state->owner[current] = UINT32_MAX;
        state->held_mask &= ~machine_fast_lane(current);
        state->dirty_mask &= ~machine_fast_lane(current);
    }
    else if (state->rematerialize_immediates[virtual_register] != UINT32_MAX)
    {
        *edit = (MachineEdit){
            .point = state->current_point,
            .kind = MACHINE_EDIT_REMATERIALIZE,
            .subject = state->rematerialize_immediates[virtual_register],
            .location = target,
        };
        state->placement->rematerialize_count += 1;
        state->dirty_mask &= ~machine_fast_lane(target);
    }
    else
    {
        *edit = (MachineEdit){
            .point = state->current_point,
            .kind = MACHINE_EDIT_RELOAD,
            .subject = virtual_register,
            .location = target,
        };
        state->placement->reload_count += 1;
        state->dirty_mask &= ~machine_fast_lane(target);
    }
    state->owner[target] = virtual_register;
    state->held_mask |= machine_fast_lane(target);
    state->virtual_register_locations[virtual_register] = target;
    state->age[target] = ++state->clock;
    state->placement->callee_saved_mask |= (1ull << target) & state->description->callee_saved_mask;
    return target;
}

BUSTER_GLOBAL_LOCAL void machine_fast_bind(MachineFastState* state, u32 virtual_register, u32 target)
{
    machine_fast_spill(state, target);
    u32 current = state->virtual_register_locations[virtual_register];
    if (current != UINT32_MAX && current != target)
    {
        state->owner[current] = UINT32_MAX;
        state->held_mask &= ~machine_fast_lane(current);
        state->dirty_mask &= ~machine_fast_lane(current);
    }
    state->owner[target] = virtual_register;
    state->held_mask |= machine_fast_lane(target);
    state->dirty_mask |= machine_fast_lane(target);
    state->virtual_register_locations[virtual_register] = target;
    state->age[target] = ++state->clock;
    state->placement->callee_saved_mask |= (1ull << target) & state->description->callee_saved_mask;
}

// Resolve source/destination pairs once, without changing predecessor order or
// the first-match rule of the former whole-edge-table searches. Group raw edge
// IDs by destination, then publish one dense source -> edge map for that group.
// Both the predecessor walk and the sparse map reset visit only actual entries:
// O(blocks + edges + predecessor references), even for a switch with many targets.
// The CSR and dense map are temporary; only u32 query results survive the prepass.
BUSTER_GLOBAL_LOCAL bool machine_fast_index_edges(Arena* arena, MachineFunction* function, MachineFastPrepass* prepass)
{
    bool valid = true;
    if (function->edge_count)
    {
        u32 block_count = function->block_count;
        u32 predecessor_count = prepass->predecessor_offsets[block_count];
        prepass->predecessor_edges = arena_allocate(arena, u32, predecessor_count);
        prepass->terminator_edges = arena_allocate(arena, u32, (u64)block_count * MACHINE_INSTRUCTION_OPERAND_COUNT);
        memset(prepass->terminator_edges, 0xff, (u64)block_count * MACHINE_INSTRUCTION_OPERAND_COUNT * sizeof(u32));
        u64 scratch_position = arena->position;
        u32* incoming_offsets = arena_allocate(arena, u32, (u64)block_count + 1u);
        u32* incoming_edges = arena_allocate(arena, u32, function->edge_count);
        // First used as CSR scatter cursors, then as the source -> first edge
        // map. No per-block full clear and no function-sized per-edge snapshot.
        u32* source_edges = arena_allocate(arena, u32, block_count);
        memset(incoming_offsets, 0, ((u64)block_count + 1u) * sizeof(u32));
        for (u32 edge_index = 0; edge_index < function->edge_count; edge_index += 1)
        {
            MachineEdge const* edge = function->edges + edge_index;
            if (edge->source_block >= block_count || edge->destination_block >= block_count)
            {
                valid = false;
            }
            else
            {
                incoming_offsets[edge->destination_block + 1u] += 1;
            }
        }
        if (valid)
        {
            for (u32 block_index = 0; block_index < block_count; block_index += 1)
            {
                incoming_offsets[block_index + 1u] += incoming_offsets[block_index];
            }
            memcpy(source_edges, incoming_offsets, (u64)block_count * sizeof(u32));
            for (u32 edge_index = 0; edge_index < function->edge_count; edge_index += 1)
            {
                u32 destination = function->edges[edge_index].destination_block;
                incoming_edges[source_edges[destination]++] = edge_index;
            }
            memset(source_edges, 0xff, (u64)block_count * sizeof(u32));
            for (u32 block_index = 0; block_index < block_count; block_index += 1)
            {
                u32 first = incoming_offsets[block_index];
                u32 limit = incoming_offsets[block_index + 1u];
                for (u32 cursor = first; cursor < limit; cursor += 1)
                {
                    u32 edge_index = incoming_edges[cursor];
                    u32 source = function->edges[edge_index].source_block;
                    if (source_edges[source] == UINT32_MAX)
                    {
                        source_edges[source] = edge_index;
                    }
                }
                MachineRef destination_ref = machine_ref_make(MACHINE_REF_BLOCK, block_index);
                for (u32 predecessor_index = prepass->predecessor_offsets[block_index];
                     predecessor_index < prepass->predecessor_offsets[block_index + 1u]; predecessor_index += 1)
                {
                    u32 source = prepass->predecessor_list[predecessor_index];
                    u32 edge_index = source_edges[source];
                    prepass->predecessor_edges[predecessor_index] = edge_index;
                    MachineBlock const* block = function->blocks + source;
                    if (block->instruction_count)
                    {
                        MachineInstruction const* terminator = function->instructions + block->first_instruction + block->instruction_count - 1u;
                        for (u32 slot = 0; slot < MACHINE_INSTRUCTION_OPERAND_COUNT; slot += 1)
                        {
                            if (terminator->operands[slot] == destination_ref)
                            {
                                prepass->terminator_edges[(u64)source * MACHINE_INSTRUCTION_OPERAND_COUNT + slot] = edge_index;
                            }
                        }
                    }
                }
                // Duplicate raw edges reset the same cell harmlessly. Visiting
                // them again is linear and avoids another touched-index buffer.
                for (u32 cursor = first; cursor < limit; cursor += 1)
                {
                    source_edges[function->edges[incoming_edges[cursor]].source_block] = UINT32_MAX;
                }
            }
        }
        arena_set_position(arena, scratch_position);
    }
    return valid;
}

// A function with no explicit edge table keeps both index arrays null. Missing
// pairs keep the old null-edge behavior; zero is a valid raw edge ID.
BUSTER_GLOBAL_LOCAL MachineEdge const* machine_fast_indexed_edge(MachineFunction* function, u32 const* edge_ids, u64 index)
{
    u32 edge_index = edge_ids ? edge_ids[index] : UINT32_MAX;
    return edge_index != UINT32_MAX ? function->edges + edge_index : 0;
}

// General asm-goto keeps its successors in the compact side descriptor: the
// inline row has no spare block operands, and each control reference also owns
// a distinct landing continuation so output capture runs on precisely the path
// that took it. Expose that contiguous successor range to the generic allocator
// without teaching its hot row classification about either target's encoder.
BUSTER_GLOBAL_LOCAL bool machine_fast_inline_assembly_successors(MachineFunction const* function,
                                                                  MachineInstruction const* instruction,
                                                                  u32* first_out, u32* count_out)
{
    bool valid = function && instruction && first_out && count_out &&
                 (instruction->opcode == MACHINE_X64_INLINE_ASSEMBLY ||
                  instruction->opcode == MACHINE_A64_INLINE_ASSEMBLY) &&
                 instruction->payload < function->inline_assembly_count;
    MachineInlineAssembly const* assembly = valid ? function->inline_assemblies + instruction->payload : 0;
    valid = valid && (assembly->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR) &&
            assembly->successor_count && assembly->fallthrough_block < function->block_count &&
            assembly->successor_count <= function->block_count - assembly->fallthrough_block;
    if (valid)
    {
        *first_out = assembly->fallthrough_block;
        *count_out = assembly->successor_count;
    }
    return valid;
}

// The pin-independent half of the scan, computed once per function and read
// by every scan of it. Two merged walks replace the former one-walk-per-fact
// shape: the first collects everything a single forward pass can —
// rematerialization recipes, predecessor counts, defining blocks, last
// textual uses, whole-function touch intervals with their constrained
// disqualifications, and the backward-edge tally — and the second, once
// defining blocks and predecessor offsets are complete, fills the adjacency
// list, marks cold entries, decides escapes, and records the backward-edge
// spans, which it leaves sorted by start and merged into disjoint regions.
// QUALITY reads the intervals and the spans for its global layer and hands
// the same prepass to both of its scan runs; FAST asks for neither, and
// `wants_quality_facts` keeps their per-operand updates off its walk.
MachineFastPrepass machine_fast_prepass_build(Arena* arena, MachineFunction* function, bool wants_quality_facts)
{
    MachineFastPrepass prepass = {0};
    MachineTargetDescription const* description = function->target;
    u32 register_count = function->virtual_register_count;
    // The two all-ones per-value arrays share one allocation so a single fill
    // covers both, and the zero arrays fill by region beside them. A scalar
    // loop over five side arrays wrote 1,17 M values five ways per stage-1
    // compile; two regions and a memset each do the same work.
    u32 value_count = register_count ? register_count : 1;
    u32* sentinel_values = arena_allocate(arena, u32, (u64)value_count * 2u);
    prepass.rematerialize_immediates = sentinel_values;
    prepass.definition_blocks = sentinel_values + value_count;
    prepass.last_use = arena_allocate(arena, u32, value_count);
    prepass.escapes = arena_allocate(arena, u8, value_count);
    prepass.next_call = arena_allocate(arena, u32, function->instruction_count ? function->instruction_count : 1);
    prepass.operand_masks = arena_allocate(arena, u32, function->instruction_count ? function->instruction_count : 1);
    if (wants_quality_facts)
    {
        prepass.interval_starts = arena_allocate(arena, u32, register_count ? register_count : 1);
        prepass.interval_ends = arena_allocate(arena, u32, register_count ? register_count : 1);
        prepass.disqualified = arena_allocate(arena, u8, register_count ? register_count : 1);
    }
    prepass.predecessor_offsets = arena_allocate(arena, u32, function->block_count + 1);
    prepass.cold_blocks = arena_allocate(arena, u8, function->block_count ? function->block_count : 1);
    if (description)
    {
        u8* definition_seen = arena_allocate(arena, u8, value_count);
        // Most functions fit a defining/use block identity in sixteen bits. Keep
        // that transient classification dense; pathological block counts retain
        // the original all-row escape scan instead of widening every common row.
        u16* use_blocks = function->block_count < UINT16_MAX - 1u ? arena_allocate(arena, u16, register_count ? register_count : 1) : 0;
        if (use_blocks && register_count)
        {
            memset(use_blocks, 0xff, (u64)register_count * sizeof(*use_blocks));
        }
        memset(sentinel_values, 0xff, (u64)value_count * 2u * sizeof(*sentinel_values));
        memset(prepass.last_use, 0, (u64)value_count * sizeof(*prepass.last_use));
        memset(prepass.escapes, 0, value_count);
        memset(definition_seen, 0, value_count);
        for (u32 register_index = 0; wants_quality_facts && register_index < register_count; register_index += 1)
        {
            prepass.interval_starts[register_index] = UINT32_MAX;
            prepass.interval_ends[register_index] = 0;
            prepass.disqualified[register_index] = 0;
        }
        // Block parameters are SSA definitions at block entry. Edge sources are
        // SSA uses on their corresponding incoming edge; account for both before
        // scanning instruction rows so liveness and escape decisions include
        // loop-carried values even when the edge has no terminator operand.
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            MachineBlock const* block = function->blocks + block_index;
            for (u32 parameter_index = 0; parameter_index < block->parameter_count; parameter_index += 1)
            {
                u32 virtual_register = function->block_parameters[block->parameter_offset + parameter_index].virtual_register;
                if (virtual_register >= register_count)
                {
                    continue;
                }
                prepass.definition_blocks[virtual_register] = block_index;
                if (wants_quality_facts)
                {
                    u32 definition = block->first_instruction;
                    prepass.interval_starts[virtual_register] = BUSTER_MIN(prepass.interval_starts[virtual_register], definition);
                    prepass.interval_ends[virtual_register] = BUSTER_MAX(prepass.interval_ends[virtual_register], definition);
                }
            }
        }
        for (u32 edge_index = 0; edge_index < function->edge_count; edge_index += 1)
        {
            MachineEdge const* edge = function->edges + edge_index;
            for (u32 copy_index = 0; copy_index < edge->copy_count; copy_index += 1)
            {
                u32 source_index = edge->copy_offset + copy_index;
                if (source_index >= function->edge_copy_source_count)
                {
                    continue;
                }
                MachineRef source = function->edge_copy_sources[source_index];
                if (machine_ref_kind(source) != MACHINE_REF_VIRTUAL_REGISTER)
                {
                    continue;
                }
                u32 virtual_register = machine_ref_payload(source);
                if (virtual_register >= register_count)
                {
                    continue;
                }
                prepass.last_use[virtual_register] = BUSTER_MAX(prepass.last_use[virtual_register], function->blocks[edge->source_block].first_instruction + function->blocks[edge->source_block].instruction_count - 1u);
                prepass.escapes[virtual_register] = 1;
                if (wants_quality_facts)
                {
                    prepass.interval_starts[virtual_register] = BUSTER_MIN(prepass.interval_starts[virtual_register], function->blocks[edge->source_block].first_instruction);
                    prepass.interval_ends[virtual_register] = BUSTER_MAX(prepass.interval_ends[virtual_register], function->blocks[edge->destination_block].first_instruction);
                }
            }
        }
        memset(prepass.predecessor_offsets, 0, ((u64)function->block_count + 1u) * sizeof(*prepass.predecessor_offsets));
        u32 backward_edge_count = 0;
        bool block_references_only_in_terminators = true;
        // The callee-saved question is asked of the union, once, instead of of
        // every row: the mask is a reduction and the row walk only needs to
        // add to it.
        u64 clobber_union = 0;
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            MachineBlock* block = function->blocks + block_index;
            for (u32 offset = 0; offset < block->instruction_count; offset += 1)
            {
                u32 instruction_index = block->first_instruction + offset;
                MachineInstruction* instruction = function->instructions + instruction_index;
                u32 opcode = instruction->opcode;
                if (opcode >= MACHINE_OPCODE_COUNT)
                {
                    return prepass;
                }
                // One sixteen-byte row answers every question this walk used
                // to ask of the 88-byte descriptor: the operand roles, the
                // constraint predicate, the call/terminator attributes, the
                // clobber set and the indirect-branch identity.
                MachineOpcodeRow opcode_row = machine_instruction_opcode_row(function, instruction);
                clobber_union |= opcode_row.clobber_mask;
                bool constrained = (opcode_row.flags & MACHINE_OPCODE_ROW_CONSTRAINED) != 0;
                // The operand kinds are three compares of the four inline
                // refs, not a per-slot ladder: the kind is the top three bits
                // of a ref, the four slots are one sixteen-byte row, and each
                // question's answer is a nibble the lane loops below consume
                // with a trailing-zero count. Lanes past operand_count are
                // trimmed once, so no test inside the loops repeats it.
                u32 lanes_active = (1u << opcode_row.operand_count) - 1u;
                u32 virtual_lanes = 0;
                u32 physical_lanes = 0;
                u32 block_lanes = 0;
                for (u32 slot = 0; slot < BUSTER_ARRAY_LENGTH(instruction->operands); slot += 1)
                {
                    u32 kind = instruction->operands[slot] >> MACHINE_REF_PAYLOAD_BITS;
                    virtual_lanes |= (u32)(kind == MACHINE_REF_VIRTUAL_REGISTER) << slot;
                    physical_lanes |= (u32)(kind == MACHINE_REF_PHYSICAL_REGISTER) << slot;
                    block_lanes |= (u32)(kind == MACHINE_REF_BLOCK) << slot;
                }
                virtual_lanes &= lanes_active;
                physical_lanes &= lanes_active;
                block_lanes &= lanes_active;
                u32 role_lanes = opcode_row.role_lanes;
                u32 operand_masks = (u32)(role_lanes << MACHINE_FAST_OPERAND_ROW_ROLE_SHIFT) |
                                    (physical_lanes << MACHINE_FAST_OPERAND_PHYSICAL_SHIFT) |
                                    (virtual_lanes << MACHINE_FAST_OPERAND_VIRTUAL_SHIFT) |
                                    (block_lanes << MACHINE_FAST_OPERAND_BLOCK_SHIFT);
                // Block references: only terminators carry them, so the lane
                // word is empty on all but 83.434 rows of the compile and the
                // loop below runs zero times without a branch of its own.
                for (u32 pending = block_lanes; pending; pending &= pending - 1u)
                {
                    u32 slot = machine_fast_first_set(pending);
                    block_references_only_in_terminators &= (opcode_row.flags & MACHINE_OPCODE_ROW_TERMINATOR) != 0;
                    u32 successor = machine_ref_payload(instruction->operands[slot]);
                    prepass.predecessor_offsets[successor + 1] += 1;
                    backward_edge_count += successor <= block_index;
                }
                u32 inline_successor = 0;
                u32 inline_successor_count = 0;
                if (machine_fast_inline_assembly_successors(function, instruction, &inline_successor, &inline_successor_count))
                {
                    for (u32 successor = inline_successor; successor - inline_successor < inline_successor_count; successor += 1)
                    {
                        prepass.predecessor_offsets[successor + 1u] += 1;
                        backward_edge_count += successor <= block_index;
                    }
                }
                for (u32 pending = virtual_lanes; pending; pending &= pending - 1u)
                {
                    u32 slot = machine_fast_first_set(pending);
                    MachineRef ref = instruction->operands[slot];
                    u32 virtual_register = machine_ref_payload(ref);
                    if (wants_quality_facts)
                    {
                        prepass.interval_starts[virtual_register] = BUSTER_MIN(prepass.interval_starts[virtual_register], instruction_index);
                        prepass.interval_ends[virtual_register] = BUSTER_MAX(prepass.interval_ends[virtual_register], instruction_index);
                        // QUALITY reserves whole-life pins for unconstrained values.
                        // A tied operand still has a legal coalescing path in FAST,
                        // but pinning it globally would hide the source/destination
                        // register relation from QUALITY's split probes.
                        prepass.disqualified[virtual_register] |= constrained ? 1u : 0u;
                    }
                    if ((role_lanes >> (MACHINE_OPCODE_ROW_DEFINE_SHIFT + slot)) & 1u ||
                        (role_lanes >> (MACHINE_OPCODE_ROW_USE_DEFINE_SHIFT + slot)) & 1u)
                    {
                        if (prepass.definition_blocks[virtual_register] == UINT32_MAX)
                        {
                            prepass.definition_blocks[virtual_register] = block_index;
                        }
                        // Constant definitions are recreatable anywhere, so they
                        // never pay for a store or a slot. A second definition of
                        // the same value disables the recipe: which constant is
                        // current would then depend on the path.
                        bool constant_definition = opcode == description->constant_opcode && slot == 0 &&
                                                   machine_ref_kind(instruction->operands[1]) == MACHINE_REF_IMMEDIATE;
                        prepass.rematerialize_immediates[virtual_register] =
                            constant_definition && !definition_seen[virtual_register] ? machine_ref_payload(instruction->operands[1]) : UINT32_MAX;
                        definition_seen[virtual_register] = 1;
                    }
                    if ((role_lanes >> (MACHINE_OPCODE_ROW_USE_SHIFT + slot)) & 1u)
                    {
                        prepass.last_use[virtual_register] = BUSTER_MAX(prepass.last_use[virtual_register], instruction_index);
                        if (use_blocks)
                        {
                            u16 use_block = use_blocks[virtual_register];
                            use_blocks[virtual_register] = use_block == UINT16_MAX || use_block == block_index ? (u16)block_index : UINT16_MAX - 1u;
                        }
                    }
                }
                bool has_case_successors = instruction->opcode == description->switch_opcode ||
                                           (opcode_row.flags & MACHINE_OPCODE_ROW_INDIRECT_BRANCH);
                if (has_case_successors)
                {
                    if (instruction->payload > function->switch_case_count ||
                        instruction->flags > function->switch_case_count - instruction->payload)
                    {
                        return prepass;
                    }
                    for (u32 target_index = 0; target_index < instruction->flags; target_index += 1)
                    {
                        u32 successor = function->switch_cases[instruction->payload + target_index].target_block;
                        if (successor >= function->block_count)
                        {
                            return prepass;
                        }
                        prepass.predecessor_offsets[successor + 1] += 1;
                        backward_edge_count += successor <= block_index;
                    }
                }
                operand_masks |= !(opcode_row.flags & (MACHINE_OPCODE_ROW_CONSTRAINED | MACHINE_OPCODE_ROW_CALL | MACHINE_OPCODE_ROW_TERMINATOR |
                                                       MACHINE_OPCODE_ROW_CLOBBERS)) &&
                                         !(physical_lanes | block_lanes)
                                     ? MACHINE_FAST_OPERAND_SIMPLE_ROW
                                     : 0u;
                operand_masks |= (opcode_row.flags & MACHINE_OPCODE_ROW_CALL) ? MACHINE_FAST_OPERAND_CALL_ROW : 0u;
                prepass.operand_masks[instruction_index] = operand_masks;
            }
        }
        prepass.callee_saved_clobber_mask |= clobber_union & description->callee_saved_mask;
        for (u32 register_index = 0; use_blocks && register_index < register_count; register_index += 1)
        {
            u16 use_block = use_blocks[register_index];
            prepass.escapes[register_index] |= use_block != UINT16_MAX && use_block != prepass.definition_blocks[register_index];
        }
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            prepass.predecessor_offsets[block_index + 1] += prepass.predecessor_offsets[block_index];
        }
        u32 predecessor_total = prepass.predecessor_offsets[function->block_count];
        prepass.predecessor_list = arena_allocate(arena, u32, predecessor_total ? predecessor_total : 1);
        u32* predecessor_cursors = arena_allocate(arena, u32, function->block_count ? function->block_count : 1);
        // The cursors start as the offsets themselves, so the prefix sum above
        // is the whole of their initialization.
        memcpy(predecessor_cursors, prepass.predecessor_offsets, (u64)function->block_count * sizeof(*predecessor_cursors));
        memset(prepass.cold_blocks, 0, function->block_count);
        for (u32 case_index = 0; case_index < function->switch_case_count; case_index += 1)
        {
            prepass.cold_blocks[function->switch_cases[case_index].target_block] = 1;
        }
        if (wants_quality_facts)
        {
            prepass.loop_spans = arena_allocate(arena, u64, backward_edge_count ? backward_edge_count : 1);
        }
        // A block must start cold — the empty contract — when some future edge
        // into it could not conform: a switch dispatch cannot host per-target
        // repairs, and a two-target conditional whose successors both precede
        // it has no later successor left to absorb repairs made for the other.
        // Terminator shapes classify structurally by block-ref operand count,
        // so the rules hold on any target; only the table dispatch needs its
        // identity from the description. Escapes decide here too, now that the
        // defining blocks are complete: layout order does not prove a def
        // precedes its uses, so the first walk alone could not tell.
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            MachineBlock* block = function->blocks + block_index;
            u32 first_offset = use_blocks && block_references_only_in_terminators && block->instruction_count ? block->instruction_count - 1u : 0;
            for (u32 offset = first_offset; offset < block->instruction_count; offset += 1)
            {
                MachineInstruction* instruction = function->instructions + block->first_instruction + offset;
                MachineOpcodeInfo const* info = machine_opcode_info(instruction->opcode);
                u32 target_references[BUSTER_ARRAY_LENGTH(instruction->operands)];
                u32 target_reference_count = 0;
                for (u32 slot = 0; slot < info->operand_count; slot += 1)
                {
                    MachineRef ref = instruction->operands[slot];
                    MachineRefKind kind = machine_ref_kind(ref);
                    if (kind == MACHINE_REF_BLOCK)
                    {
                        u32 successor = machine_ref_payload(ref);
                        prepass.predecessor_list[predecessor_cursors[successor]++] = block_index;
                        target_references[target_reference_count++] = successor;
                        if (instruction->opcode == description->switch_opcode)
                        {
                            prepass.cold_blocks[successor] = 1;
                        }
                        if (wants_quality_facts && successor <= block_index)
                        {
                            u32 loop_start = function->blocks[successor].first_instruction;
                            u32 loop_end = block->first_instruction + block->instruction_count - 1;
                            prepass.loop_spans[prepass.loop_span_count] = ((u64)loop_start << 32) | loop_end;
                            prepass.loop_span_count += 1;
                        }
                    }
                    else if (!use_blocks && kind == MACHINE_REF_VIRTUAL_REGISTER)
                    {
                        u32 role = info->operand_info[slot] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u);
                        if ((role == MACHINE_OPERAND_ROLE_USE || role == MACHINE_OPERAND_ROLE_USE_DEFINE) &&
                            prepass.definition_blocks[machine_ref_payload(ref)] != block_index)
                        {
                            prepass.escapes[machine_ref_payload(ref)] = 1;
                        }
                    }
                }
                if (instruction->opcode == description->switch_opcode ||
                    instruction->opcode == MACHINE_X64_INDIRECT_BRANCH || instruction->opcode == MACHINE_A64_INDIRECT_BRANCH)
                {
                    for (u32 target_index = 0; target_index < instruction->flags; target_index += 1)
                    {
                        u32 successor = function->switch_cases[instruction->payload + target_index].target_block;
                        prepass.predecessor_list[predecessor_cursors[successor]++] = block_index;
                        prepass.cold_blocks[successor] = 1;
                        if (wants_quality_facts && successor <= block_index)
                        {
                            u32 loop_start = function->blocks[successor].first_instruction;
                            u32 loop_end = block->first_instruction + block->instruction_count - 1;
                            prepass.loop_spans[prepass.loop_span_count] = ((u64)loop_start << 32) | loop_end;
                            prepass.loop_span_count += 1;
                        }
                    }
                }
                u32 inline_successor = 0;
                u32 inline_successor_count = 0;
                if (machine_fast_inline_assembly_successors(function, instruction, &inline_successor, &inline_successor_count))
                {
                    for (u32 successor = inline_successor; successor - inline_successor < inline_successor_count; successor += 1)
                    {
                        prepass.predecessor_list[predecessor_cursors[successor]++] = block_index;
                        // A branch inside the byte template selects the landing
                        // after the allocator has emitted its boundary edits.
                        // No path-specific register repair can run there, so all
                        // of these landing contracts deliberately start empty.
                        prepass.cold_blocks[successor] = 1;
                        if (wants_quality_facts && successor <= block_index)
                        {
                            u32 loop_start = function->blocks[successor].first_instruction;
                            u32 loop_end = block->first_instruction + block->instruction_count - 1u;
                            prepass.loop_spans[prepass.loop_span_count++] = ((u64)loop_start << 32) | loop_end;
                        }
                    }
                }
                if (target_reference_count == 2 && target_references[0] <= block_index && target_references[1] <= block_index)
                {
                    prepass.cold_blocks[target_references[0]] = 1;
                    prepass.cold_blocks[target_references[1]] = 1;
                }
            }
        }
        if (wants_quality_facts)
        {
            // Backward-edge spans, sorted by start and merged into disjoint
            // regions. Closure asks only which rows a loop can re-execute
            // around a range and never which loop, so nested and overlapping
            // spans fuse and the table stays small. Touching spans merge too,
            // since a range ending exactly where the next one starts meets
            // both.
            u64* span_scratch = arena_allocate(arena, u64, prepass.loop_span_count ? prepass.loop_span_count : 1);
            for (u32 width = 1; width < prepass.loop_span_count; width *= 2)
            {
                for (u32 sort_start = 0; sort_start < prepass.loop_span_count; sort_start += 2 * width)
                {
                    u32 middle = BUSTER_MIN(sort_start + width, prepass.loop_span_count);
                    u32 limit = BUSTER_MIN(sort_start + 2 * width, prepass.loop_span_count);
                    u32 left = sort_start;
                    u32 right = middle;
                    u32 out = sort_start;
                    while (left < middle && right < limit)
                    {
                        span_scratch[out++] = prepass.loop_spans[right] < prepass.loop_spans[left] ? prepass.loop_spans[right++] : prepass.loop_spans[left++];
                    }
                    while (left < middle)
                    {
                        span_scratch[out++] = prepass.loop_spans[left++];
                    }
                    while (right < limit)
                    {
                        span_scratch[out++] = prepass.loop_spans[right++];
                    }
                }
                memcpy(prepass.loop_spans, span_scratch, (u64)prepass.loop_span_count * sizeof(*prepass.loop_spans));
            }
            u32 merged_span_count = 0;
            for (u32 span_index = 0; span_index < prepass.loop_span_count; span_index += 1)
            {
                u32 span_start = (u32)(prepass.loop_spans[span_index] >> 32);
                u32 span_end = (u32)prepass.loop_spans[span_index];
                bool merges = merged_span_count && span_start <= (u32)prepass.loop_spans[merged_span_count - 1];
                u32 merged_end = merges ? BUSTER_MAX((u32)prepass.loop_spans[merged_span_count - 1], span_end) : span_end;
                u32 slot = merges ? merged_span_count - 1u : merged_span_count;
                u32 merged_start = merges ? (u32)(prepass.loop_spans[slot] >> 32) : span_start;
                prepass.loop_spans[slot] = ((u64)merged_start << 32) | merged_end;
                merged_span_count += !merges;
            }
            prepass.loop_span_count = merged_span_count;
        }
        // Every row above published a classification word and a valid
        // descriptor — the walk returns early otherwise — so the backward
        // next-call pass reads the call bit out of that word instead of
        // reloading the opcode and probing the descriptor table again. The
        // test is a select on a sequentially streamed u32, which leaves the
        // loop with no data-dependent branch of its own.
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            MachineBlock* block = function->blocks + block_index;
            u32 upcoming_call = UINT32_MAX;
            for (u32 offset = block->instruction_count; offset > 0; offset -= 1)
            {
                u32 instruction_index = block->first_instruction + offset - 1;
                upcoming_call = (prepass.operand_masks[instruction_index] & MACHINE_FAST_OPERAND_CALL_ROW) ? instruction_index : upcoming_call;
                prepass.next_call[instruction_index] = upcoming_call;
            }
        }
        // A function with no vector virtual registers can never own a vector
        // register, so its loops stop at the general file's end; the widened
        // unified file would otherwise double every scan pass for the common
        // all-scalar function.
        prepass.active_register_count = description->register_count;
        if (description->vector_allocatable_mask)
        {
            bool scan_has_vector = false;
            for (u32 register_index = 0; register_index < register_count; register_index += 1)
            {
                scan_has_vector |= function->virtual_registers[register_index].register_class == MACHINE_REGISTER_CLASS_VECTOR;
            }
            if (!scan_has_vector)
            {
                u64 general_mask = description->allocatable_mask | description->callee_saved_mask;
                u32 general_top = 0;
                for (u32 bit_index = 0; bit_index < MACHINE_TARGET_REGISTER_LIMIT; bit_index += 1)
                {
                    general_top = ((general_mask >> bit_index) & 1u) ? bit_index + 1 : general_top;
                }
                prepass.active_register_count = general_top;
            }
        }
        prepass.valid = machine_fast_index_edges(arena, function, &prepass);
    }

    return prepass;
}

// Loop closure asks only whether a range meets a backward edge, so in a
// function that is one enormous loop — an interpreter dispatch loop, say —
// every range inside it widens to the whole loop and nothing shares anything.
// What a frame object actually occupies are the rows where a write of it may
// still be read, and that is a liveness question the block graph answers: a
// write covering the object ends the previous contents, every other touch
// reads them, and an object live out of a block is live through it. One
// carried around a loop is live in every block of that loop and closes over
// it exactly as before; one written and read inside a single iteration is not
// live at the header and keeps its own rows. Live-in and live-out are the
// usual backward fixed point over object bitsets, and the range handed to the
// color scan is the row span of the blocks holding the object live, which
// covers every row of every path between them.
//
// Callers build the per-block read and covering-write sets — the frame
// objects the selector named and the homes the allocator's own memory edits
// name are found in different places — and own the row ranges of the touches
// themselves; this only widens them.
BUSTER_GLOBAL_LOCAL void machine_fast_close_live_ranges(Arena* arena, MachineFunction const* function, MachineFastPrepass const* prepass, u64 const* reads,
                                                        u64 const* writes, u32 words, u32* starts, u32* ends)
{
    u32 block_count = function->block_count;
    u64 plane = (u64)block_count * words;
    u64* live_in = arena_allocate(arena, u64, plane ? plane : 1);
    u64* live_out = arena_allocate(arena, u64, plane ? plane : 1);
    memset(live_in, 0, (plane ? plane : 1) * sizeof(*live_in));
    memset(live_out, 0, (plane ? plane : 1) * sizeof(*live_out));
    // Seed an explicit LIFO in ascending order so its first pulls preserve
    // the old reverse-index sweep. After that, only a block whose
    // live-out gained a bit is pending; converged regions are never
    // re-swept. `queued` bounds the stack to one entry per block.
    u32 work_axis = block_count ? block_count : 1u;
    u32* worklist = arena_allocate(arena, u32, work_axis);
    u8* queued = arena_allocate(arena, u8, work_axis);
    memset(queued, 0, work_axis);
    u32 work_count = 0;
    for (u32 block_index = 0; block_index < block_count; block_index += 1)
    {
        worklist[work_count++] = block_index;
        queued[block_index] = 1;
    }
    while (work_count)
    {
        u32 block_index = worklist[--work_count];
        queued[block_index] = 0;
        u64 const* block_reads = reads + (u64)block_index * words;
        u64 const* block_writes = writes + (u64)block_index * words;
        u64* block_in = live_in + (u64)block_index * words;
        u64 const* block_out = live_out + (u64)block_index * words;
        for (u32 word = 0; word < words; word += 1)
        {
            block_in[word] = block_reads[word] | (block_out[word] & ~block_writes[word]);
        }
        u32 first = prepass->predecessor_offsets[block_index];
        u32 limit = prepass->predecessor_offsets[block_index + 1u];
        for (u32 entry = first; entry < limit; entry += 1)
        {
            u32 predecessor = prepass->predecessor_list[entry];
            u64* predecessor_out = live_out + (u64)predecessor * words;
            bool predecessor_changed = false;
            for (u32 word = 0; word < words; word += 1)
            {
                u64 previous = predecessor_out[word];
                u64 merged = previous | block_in[word];
                if (merged != previous)
                {
                    predecessor_out[word] = merged;
                    predecessor_changed = true;
                }
            }
            if (predecessor_changed && !queued[predecessor])
            {
                worklist[work_count++] = predecessor;
                queued[predecessor] = 1;
            }
        }
    }
    for (u32 block_index = 0; block_index < block_count; block_index += 1)
    {
        MachineBlock const* block = function->blocks + block_index;
        u64 const* block_in = live_in + (u64)block_index * words;
        u64 const* block_out = live_out + (u64)block_index * words;
        u32 last = block->instruction_count ? block->first_instruction + block->instruction_count - 1u : block->first_instruction;
        // An object arriving live occupies the block from its first row, and
        // one leaving live occupies it through its last; an object born and
        // consumed inside the block keeps only the rows its touches gave it.
        for (u32 word = 0; word < words; word += 1)
        {
            u64 entering = block_in[word];
            while (entering)
            {
                u32 object = 64u * word + trailing_zeroes_u64(entering);
                entering &= entering - 1u;
                starts[object] = BUSTER_MIN(starts[object], block->first_instruction);
            }
            u64 leaving = block_out[word];
            while (leaving)
            {
                u32 object = 64u * word + trailing_zeroes_u64(leaving);
                leaving &= leaving - 1u;
                ends[object] = BUSTER_MAX(ends[object], last);
            }
        }
    }
}

#if BUSTER_INCLUDE_TESTS
// The removed whole-sweep solver is retained only as an exact oracle
// for the worklist regression below. It receives the same dense planes
// and materializes the same start/end contract as production.
BUSTER_GLOBAL_LOCAL void machine_fast_close_live_ranges_sweep_reference(Arena* arena, MachineFunction const* function,
                                                                         MachineFastPrepass const* prepass, u64 const* reads,
                                                                         u64 const* writes, u32 words, u32* starts, u32* ends)
{
    u32 block_count = function->block_count;
    u64 plane = (u64)block_count * words;
    u64* live_in = arena_allocate(arena, u64, plane ? plane : 1);
    u64* live_out = arena_allocate(arena, u64, plane ? plane : 1);
    memset(live_in, 0, (plane ? plane : 1) * sizeof(*live_in));
    memset(live_out, 0, (plane ? plane : 1) * sizeof(*live_out));
    bool changed = true;
    while (changed)
    {
        changed = false;
        for (u32 index = block_count; index; index -= 1)
        {
            u32 block_index = index - 1u;
            u64 const* block_reads = reads + (u64)block_index * words;
            u64 const* block_writes = writes + (u64)block_index * words;
            u64* block_in = live_in + (u64)block_index * words;
            u64 const* block_out = live_out + (u64)block_index * words;
            for (u32 word = 0; word < words; word += 1)
            {
                block_in[word] = block_reads[word] | (block_out[word] & ~block_writes[word]);
            }
            u32 first = prepass->predecessor_offsets[block_index];
            u32 limit = prepass->predecessor_offsets[block_index + 1u];
            for (u32 entry = first; entry < limit; entry += 1)
            {
                u64* predecessor_out = live_out + (u64)prepass->predecessor_list[entry] * words;
                for (u32 word = 0; word < words; word += 1)
                {
                    u64 merged = predecessor_out[word] | block_in[word];
                    changed = changed || merged != predecessor_out[word];
                    predecessor_out[word] = merged;
                }
            }
        }
    }
    for (u32 block_index = 0; block_index < block_count; block_index += 1)
    {
        MachineBlock const* block = function->blocks + block_index;
        u64 const* block_in = live_in + (u64)block_index * words;
        u64 const* block_out = live_out + (u64)block_index * words;
        u32 last = block->instruction_count ? block->first_instruction + block->instruction_count - 1u : block->first_instruction;
        for (u32 word = 0; word < words; word += 1)
        {
            u64 entering = block_in[word];
            while (entering)
            {
                u32 object = 64u * word + trailing_zeroes_u64(entering);
                entering &= entering - 1u;
                starts[object] = BUSTER_MIN(starts[object], block->first_instruction);
            }
            u64 leaving = block_out[word];
            while (leaving)
            {
                u32 object = 64u * word + trailing_zeroes_u64(leaving);
                leaving &= leaving - 1u;
                ends[object] = BUSTER_MAX(ends[object], last);
            }
        }
    }
}

bool machine_fast_close_live_ranges_test(Arena* arena)
{
    enum
    {
        MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT = 9,
        MACHINE_FAST_CLOSE_TEST_SLOT_COUNT = 1025,
        MACHINE_FAST_CLOSE_TEST_WORD_COUNT = (MACHINE_FAST_CLOSE_TEST_SLOT_COUNT + 63) / 64,
    };
    MachineBlock blocks[MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT] = {
        {.first_instruction = 0, .instruction_count = 2},
        {.first_instruction = 2, .instruction_count = 3},
        {.first_instruction = 5, .instruction_count = 1},
        {.first_instruction = 6, .instruction_count = 4},
        {.first_instruction = 10, .instruction_count = 2},
        {.first_instruction = 12, .instruction_count = 3},
        {.first_instruction = 15, .instruction_count = 2},
        {.first_instruction = 17, .instruction_count = 1},
        {.first_instruction = 18, .instruction_count = 2},
    };
    // 0 -> 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8, with 5 -> 4
    // as the inner back edge and 6 -> 2 as the outer back edge.
    u32 predecessor_offsets[MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT + 1] = {0, 0, 1, 3, 4, 6, 7, 8, 10, 11};
    u32 predecessor_list[] = {0, 1, 6, 2, 3, 5, 4, 5, 2, 6, 7};
    MachineFunction function = {
        .blocks = blocks,
        .block_count = MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT,
    };
    MachineFastPrepass prepass = {
        .predecessor_offsets = predecessor_offsets,
        .predecessor_list = predecessor_list,
    };
    u64 reads[MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT * MACHINE_FAST_CLOSE_TEST_WORD_COUNT] = {0};
    u64 writes[MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT * MACHINE_FAST_CLOSE_TEST_WORD_COUNT] = {0};
    u32 reference_starts[MACHINE_FAST_CLOSE_TEST_SLOT_COUNT];
    u32 reference_ends[MACHINE_FAST_CLOSE_TEST_SLOT_COUNT];
    u32 actual_starts[MACHINE_FAST_CLOSE_TEST_SLOT_COUNT];
    u32 actual_ends[MACHINE_FAST_CLOSE_TEST_SLOT_COUNT];
    for (u32 slot = 0; slot < MACHINE_FAST_CLOSE_TEST_SLOT_COUNT; slot += 1)
    {
        u32 write_block = (slot * 7u + slot / 64u + 1u) % MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT;
        u32 read_block = (slot * 5u + slot / 32u + 3u) % MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT;
        u64 bit = UINT64_C(1) << (slot & 63u);
        writes[(u64)write_block * MACHINE_FAST_CLOSE_TEST_WORD_COUNT + slot / 64u] |= bit;
        reads[(u64)read_block * MACHINE_FAST_CLOSE_TEST_WORD_COUNT + slot / 64u] |= bit;
        reference_starts[slot] =
            BUSTER_MIN(blocks[write_block].first_instruction, blocks[read_block].first_instruction);
        reference_ends[slot] =
            BUSTER_MAX(blocks[write_block].first_instruction + blocks[write_block].instruction_count - 1u,
                       blocks[read_block].first_instruction + blocks[read_block].instruction_count - 1u);
        if ((slot & 7u) == 0)
        {
            u32 second_read = (read_block + 4u) % MACHINE_FAST_CLOSE_TEST_BLOCK_COUNT;
            reads[(u64)second_read * MACHINE_FAST_CLOSE_TEST_WORD_COUNT + slot / 64u] |= bit;
            reference_starts[slot] = BUSTER_MIN(reference_starts[slot], blocks[second_read].first_instruction);
            reference_ends[slot] =
                BUSTER_MAX(reference_ends[slot],
                           blocks[second_read].first_instruction + blocks[second_read].instruction_count - 1u);
        }
        actual_starts[slot] = reference_starts[slot];
        actual_ends[slot] = reference_ends[slot];
    }

    u64 arena_position = arena->position;
    machine_fast_close_live_ranges_sweep_reference(arena, &function, &prepass, reads, writes,
                                                   MACHINE_FAST_CLOSE_TEST_WORD_COUNT, reference_starts, reference_ends);
    arena_set_position(arena, arena_position);
    machine_fast_close_live_ranges(arena, &function, &prepass, reads, writes, MACHINE_FAST_CLOSE_TEST_WORD_COUNT,
                                   actual_starts, actual_ends);
    arena_set_position(arena, arena_position);
    bool result = true;
    for (u32 slot = 0; slot < MACHINE_FAST_CLOSE_TEST_SLOT_COUNT; slot += 1)
    {
        result = result && actual_starts[slot] == reference_starts[slot] && actual_ends[slot] == reference_ends[slot];
    }
    return result;
}
#endif
// The edit stream is a compact memory program for virtual-register homes. A
// reload before the first spill in a block reads the value that arrived from a
// predecessor; a spill covers that incoming value for every later point in the
// block. Edits at one point can come from several retroactively conformed
// successors, and their merge order is not a path order, so all reloads at the
// point are conservatively observed before any spill there. The ordinary CFG
// fixed point then closes each home over exactly the blocks in which its stored
// contents can be live. A dense home index keeps the block bitsets proportional
// to spilled values rather than to every virtual register in a large function.
BUSTER_GLOBAL_LOCAL void machine_fast_close_home_ranges(Arena* arena, MachineFunction const* function, MachineFastPrepass const* prepass,
                                                        MachineStackPlacement const* placement, u32 const* row_blocks, u8 const* slot_needed,
                                                        u8 const* home_opaque, u32* home_starts, u32* home_ends)
{
    u32 value_count = function->virtual_register_count;
    u32 value_axis = value_count ? value_count : 1u;
    u32 home_count = 0;
    for (u32 value = 0; value < value_count; value += 1)
    {
        home_count += slot_needed[value] && !home_opaque[value];
    }
    if (home_count)
    {
        u32* home_objects = arena_allocate(arena, u32, value_axis);
        u32* home_values = arena_allocate(arena, u32, home_count);
        u32* starts = arena_allocate(arena, u32, home_count);
        u32* ends = arena_allocate(arena, u32, home_count);
        memset(home_objects, 0xff, (u64)value_axis * sizeof(*home_objects));
        u32 object = 0;
        for (u32 value = 0; value < value_count; value += 1)
        {
            if (slot_needed[value] && !home_opaque[value])
            {
                home_objects[value] = object;
                home_values[object] = value;
                starts[object] = home_starts[value];
                ends[object] = home_ends[value];
                object += 1;
            }
        }
        u32 words = (home_count + 63u) / 64u;
        u64 plane = (u64)function->block_count * words;
        u64* reads = arena_allocate(arena, u64, plane ? plane : 1);
        u64* writes = arena_allocate(arena, u64, plane ? plane : 1);
        memset(reads, 0, (plane ? plane : 1) * sizeof(*reads));
        memset(writes, 0, (plane ? plane : 1) * sizeof(*writes));
        for (u32 first = 0; first < placement->edit_count;)
        {
            MachinePoint point = placement->edits[first].point;
            u32 limit = first + 1u;
            while (limit < placement->edit_count && placement->edits[limit].point == point)
            {
                limit += 1;
            }
            u32 row = machine_point_instruction(point);
            if (row < function->instruction_count)
            {
                u32 block_index = row_blocks[row];
                u64* block_reads = reads + (u64)block_index * words;
                u64* block_writes = writes + (u64)block_index * words;
                // Equal-point repairs have no edge execution order. Assuming
                // every reload can precede every spill only lengthens a range.
                for (u32 edit_index = first; edit_index < limit; edit_index += 1)
                {
                    MachineEdit const* edit = placement->edits + edit_index;
                    if (edit->kind == MACHINE_EDIT_RELOAD && edit->subject < value_count)
                    {
                        u32 home = home_objects[edit->subject];
                        if (home != UINT32_MAX)
                        {
                            u32 word = home / 64u;
                            u64 bit = UINT64_C(1) << (home & 63u);
                            if (!(block_writes[word] & bit))
                            {
                                block_reads[word] |= bit;
                            }
                        }
                    }
                }
                for (u32 edit_index = first; edit_index < limit; edit_index += 1)
                {
                    MachineEdit const* edit = placement->edits + edit_index;
                    if (edit->kind == MACHINE_EDIT_SPILL && edit->subject < value_count)
                    {
                        u32 home = home_objects[edit->subject];
                        if (home != UINT32_MAX)
                        {
                            block_writes[home / 64u] |= UINT64_C(1) << (home & 63u);
                        }
                    }
                }
            }
            first = limit;
        }
        machine_fast_close_live_ranges(arena, function, prepass, reads, writes, words, starts, ends);
        for (u32 home = 0; home < home_count; home += 1)
        {
            u32 value = home_values[home];
            home_starts[value] = starts[home];
            home_ends[value] = ends[home];
        }
    }
}

// One frame slot per simultaneously live home instead of one per spilled
// value. The caller hands each home the rows over which it may hold anything
// a later row reads, and two homes whose ranges miss each other never hold a
// live value at once. The assignment is a
// linear scan in start order over the homes of one pool: a binary heap of live
// homes keyed by end row retires the ones that ended, their colors return to a
// free stack, and the next home takes a returned color or opens a new one. No
// interference graph is built and no pair of homes is ever compared.
// `colors` receives a pool index per selected value and UINT32_MAX elsewhere;
// the return value is the pool's width.
BUSTER_GLOBAL_LOCAL u32 machine_fast_color_homes(Arena* arena, MachineFunction const* function, u8 const* slot_needed, u32 const* home_starts,
                                                 u32 const* home_ends, bool vector_pool, u32* colors)
{
    u32 value_count = function->virtual_register_count;
    u32 row_count = function->instruction_count + 2u;
    u32* row_offsets = arena_allocate(arena, u32, (u64)row_count + 1u);
    u32 selected_count = 0;
    memset(row_offsets, 0, ((u64)row_count + 1u) * sizeof(*row_offsets));
    for (u32 register_index = 0; register_index < value_count; register_index += 1)
    {
        bool is_vector = function->virtual_registers[register_index].register_class == MACHINE_REGISTER_CLASS_VECTOR;
        bool selected = slot_needed[register_index] && home_starts[register_index] != UINT32_MAX && is_vector == vector_pool;
        u32 start_row = selected ? home_starts[register_index] : 0;
        row_offsets[start_row + 1u] += selected;
        selected_count += selected;
    }
    // Counting sort by start row: the scan needs ascending starts and the
    // rows are already a dense index, so no comparison sort is needed.
    for (u32 row = 0; row < row_count; row += 1)
    {
        row_offsets[row + 1u] += row_offsets[row];
    }
    u32* order = arena_allocate(arena, u32, selected_count ? selected_count : 1);
    u64* active = arena_allocate(arena, u64, selected_count ? selected_count : 1);
    u32* free_colors = arena_allocate(arena, u32, selected_count ? selected_count : 1);
    u32 active_count = 0;
    u32 free_count = 0;
    u32 color_count = 0;
    for (u32 register_index = 0; register_index < value_count; register_index += 1)
    {
        bool is_vector = function->virtual_registers[register_index].register_class == MACHINE_REGISTER_CLASS_VECTOR;
        if (slot_needed[register_index] && home_starts[register_index] != UINT32_MAX && is_vector == vector_pool)
        {
            order[row_offsets[home_starts[register_index]]++] = register_index;
        }
    }
    for (u32 index = 0; index < selected_count; index += 1)
    {
        u32 register_index = order[index];
        u32 start = home_starts[register_index];
        u32 color;
        while (active_count && (u32)(active[0] >> 32) < start)
        {
            u32 parent = 0;
            free_colors[free_count] = (u32)active[0];
            free_count += 1;
            active_count -= 1;
            active[0] = active[active_count];
            while (true)
            {
                u32 left = 2 * parent + 1;
                u32 smallest = left < active_count && active[left] < active[parent] ? left : parent;
                smallest = left + 1 < active_count && active[left + 1] < active[smallest] ? left + 1 : smallest;
                if (smallest == parent)
                {
                    break;
                }
                u64 swapped = active[parent];
                active[parent] = active[smallest];
                active[smallest] = swapped;
                parent = smallest;
            }
        }
        if (free_count)
        {
            free_count -= 1;
            color = free_colors[free_count];
        }
        else
        {
            color = color_count;
            color_count += 1;
        }
        colors[register_index] = color;
        active[active_count] = ((u64)home_ends[register_index] << 32) | color;
        u32 child = active_count;
        active_count += 1;
        while (child && active[(child - 1u) / 2u] > active[child])
        {
            u64 swapped = active[(child - 1u) / 2u];
            active[(child - 1u) / 2u] = active[child];
            active[child] = swapped;
            child = (child - 1u) / 2u;
        }
    }
    return color_count;
}

// The same linear scan for the selector's frame objects, whose widths differ:
// a group's storage is its widest member and its start alignment the strictest
// one, so reusing a group that already fits costs nothing and reusing a
// narrower one costs only the difference. Which free group to take is
// therefore a fit question, and the newest free groups are the ones a scan in
// start order keeps finding sized for the slots around them, so the search
// stays inside a fixed window of the free stack rather than walking all of it.
#define MACHINE_FAST_SLOT_FIT_WINDOW 16u

// `colors` receives a group per coalesced slot and UINT32_MAX elsewhere;
// `group_sizes` and `group_alignments` receive the storage each group needs.
// The return value is the group count.
BUSTER_GLOBAL_LOCAL u32 machine_fast_color_slots(Arena* arena, MachineFunction const* function, u8 const* slot_fixed, u32 const* slot_starts,
                                                 u32 const* slot_ends, u32* colors, u32* group_sizes, u32* group_alignments)
{
    u32 slot_count = function->stack_slot_count;
    u32 row_count = function->instruction_count + 2u;
    u32* row_offsets = arena_allocate(arena, u32, (u64)row_count + 1u);
    u32 selected_count = 0;
    memset(row_offsets, 0, ((u64)row_count + 1u) * sizeof(*row_offsets));
    for (u32 slot_index = 0; slot_index < slot_count; slot_index += 1)
    {
        bool selected = !slot_fixed[slot_index] && slot_starts[slot_index] != UINT32_MAX;
        row_offsets[(selected ? slot_starts[slot_index] : 0) + 1u] += selected;
        selected_count += selected;
    }
    for (u32 row = 0; row < row_count; row += 1)
    {
        row_offsets[row + 1u] += row_offsets[row];
    }
    u32* order = arena_allocate(arena, u32, selected_count ? selected_count : 1);
    u64* active = arena_allocate(arena, u64, selected_count ? selected_count : 1);
    u32* free_groups = arena_allocate(arena, u32, selected_count ? selected_count : 1);
    u32 active_count = 0;
    u32 free_count = 0;
    u32 group_count = 0;
    for (u32 slot_index = 0; slot_index < slot_count; slot_index += 1)
    {
        if (!slot_fixed[slot_index] && slot_starts[slot_index] != UINT32_MAX)
        {
            order[row_offsets[slot_starts[slot_index]]++] = slot_index;
        }
    }
    for (u32 index = 0; index < selected_count; index += 1)
    {
        u32 slot_index = order[index];
        u32 start = slot_starts[slot_index];
        u32 size = function->stack_slot_sizes[slot_index];
        u32 alignment = function->stack_slot_alignments ? function->stack_slot_alignments[slot_index] : 8u;
        while (active_count && (u32)(active[0] >> 32) < start)
        {
            u32 parent = 0;
            free_groups[free_count] = (u32)active[0];
            free_count += 1;
            active_count -= 1;
            active[0] = active[active_count];
            while (true)
            {
                u32 left = 2 * parent + 1;
                u32 smallest = left < active_count && active[left] < active[parent] ? left : parent;
                smallest = left + 1 < active_count && active[left + 1] < active[smallest] ? left + 1 : smallest;
                if (smallest == parent)
                {
                    break;
                }
                u64 swapped = active[parent];
                active[parent] = active[smallest];
                active[smallest] = swapped;
                parent = smallest;
            }
        }
        u32 window = BUSTER_MIN(free_count, MACHINE_FAST_SLOT_FIT_WINDOW);
        u32 position = UINT32_MAX;
        for (u32 probe = free_count - window; probe < free_count; probe += 1)
        {
            u32 candidate = group_sizes[free_groups[probe]];
            u32 incumbent = position == UINT32_MAX ? 0 : group_sizes[free_groups[position]];
            bool fits = candidate >= size;
            bool incumbent_fits = position != UINT32_MAX && incumbent >= size;
            // A group that already holds the slot wins over one that has to
            // grow; between two of a kind the tighter fit and the smaller
            // growth are the same preference read from opposite ends.
            bool better = position == UINT32_MAX || (fits && !incumbent_fits) ||
                          (fits == incumbent_fits && (fits ? candidate < incumbent : candidate > incumbent));
            position = better ? probe : position;
        }
        u32 group = position == UINT32_MAX ? group_count : free_groups[position];
        group_sizes[group] = position == UINT32_MAX ? size : BUSTER_MAX(group_sizes[group], size);
        group_alignments[group] = position == UINT32_MAX ? alignment : BUSTER_MAX(group_alignments[group], alignment);
        group_count += position == UINT32_MAX;
        if (position != UINT32_MAX)
        {
            free_count -= 1;
            free_groups[position] = free_groups[free_count];
        }
        colors[slot_index] = group;
        active[active_count] = ((u64)slot_ends[slot_index] << 32) | group;
        u32 child = active_count;
        active_count += 1;
        while (child && active[(child - 1u) / 2u] > active[child])
        {
            u64 swapped = active[(child - 1u) / 2u];
            active[(child - 1u) / 2u] = active[child];
            active[child] = swapped;
            child = (child - 1u) / 2u;
        }
    }
    return group_count;
}

// `pinned_registers` holds a physical register per virtual register that
// owns it, or UINT32_MAX; `pinned_mask` collects them; `pin_active_masks`
// scopes each reservation to its value's span, or reserves `pinned_mask`
// whole-function when null. Within its span the local scan never picks,
// binds, spills, or reloads a pinned value: its operands simply name the
// register, and the register rejoins the pool wherever no span covers the
// instruction. The span arrays make that boundary per-value; a split
// span's handoff arrives pre-validated in `split_entries` (the head-block
// contract installs the value, so every entering edge conforms it into
// the register while the backward edges the span covers are satisfied by
// the span invariant) and `split_stores` (row-sorted landing-pad
// write-backs for values living past their span). FAST passes none of
// them.
MachineStackPlacement machine_fast_placement_build_pinned(Arena* arena, MachineFunction* function, u32 const* pinned_registers, u64 pinned_mask,
                                                          u64 const* pin_active_masks, u32 const* pin_span_starts, u32 const* pin_span_ends,
                                                          MachinePinSplitEntry const* split_entries, u32 split_entry_count,
                                                          MachinePinSplitStore const* split_stores, u32 split_store_count)
{
    MachineFastPrepass prepass = machine_fast_prepass_build(arena, function, false);
    return machine_fast_placement_build_prepassed(arena, function, &prepass, pinned_registers, pinned_mask, pin_active_masks, pin_span_starts,
                                                  pin_span_ends, split_entries, split_entry_count, split_stores, split_store_count);
}

MachineStackPlacement machine_fast_placement_build_prepassed(Arena* arena, MachineFunction* function, MachineFastPrepass const* prepass,
                                                             u32 const* pinned_registers, u64 pinned_mask, u64 const* pin_active_masks,
                                                             u32 const* pin_span_starts, u32 const* pin_span_ends,
                                                             MachinePinSplitEntry const* split_entries, u32 split_entry_count,
                                                             MachinePinSplitStore const* split_stores, u32 split_store_count)
{
    // Frame layout is shared with the stack placement for now; slot
    // elimination is the stage-6 optimization.
    MachineStackPlacement placement = {
        .virtual_register_offsets = arena_allocate(arena, u32, function->virtual_register_count),
        .stack_slot_offsets = arena_allocate(arena, u32, function->stack_slot_count),
        .operand_registers = arena_allocate(arena, u8, (u64)function->instruction_count * 4),
    };
    MachineTargetDescription const* description = function->target;
    if (description)
    {
        if (!prepass->valid)
        {
            return placement;
        }
        MachineBuilderStream edits;
        machine_stream_initialize(&edits, sizeof(MachineEdit));
        // Only the callee-saved pins cost a prologue save; a caller-saved pin
        // is exactly why QUALITY hands them out where a span crosses no call.
        placement.callee_saved_mask |= pinned_mask & description->callee_saved_mask;
        // Metadata-only clobbers (for example CMPXCHG16B's implicit RBX write)
        // still require an ABI save even when no virtual value owns that
        // physical register during the scan.
        placement.callee_saved_mask |= prepass->callee_saved_clobber_mask;
        MachineFastState state = {
            .arena = arena,
            .function = function,
            .description = description,
            .placement = &placement,
            .edits = &edits,
            .virtual_register_locations = arena_allocate(arena, u32, function->virtual_register_count),
            .last_use = prepass->last_use,
            .escapes = prepass->escapes,
            .next_call = prepass->next_call,
            .rematerialize_immediates = prepass->rematerialize_immediates,
            .pinned_registers = pinned_registers,
            .pinned_mask = pinned_mask,
            .pin_active_masks = pin_active_masks,
            .pin_span_starts = pin_span_starts,
            .pin_span_ends = pin_span_ends,
            .split_entries = split_entries,
            .split_entry_count = split_entry_count,
            .split_stores = split_stores,
            .split_store_count = split_store_count,
            .active_register_count = prepass->active_register_count,
        };
        u32 const* predecessor_offsets = prepass->predecessor_offsets;
        u32 const* predecessor_list = prepass->predecessor_list;
        u8 const* cold_blocks = prepass->cold_blocks;
        // Contracts and per-edge snapshots, one register file per block. A
        // block's out state is recorded at its terminator after any inline
        // conforms, which is exactly what every one of its edges delivers; a
        // later contract construction conforms the snapshot retroactively and
        // its mutations persist, so two successors of one conditional never
        // write the same value back twice.
        // Occupancy and dirtiness are one mask per block, not a byte per
        // register: a stage-1 census found 2,75 of sixteen lanes held at a
        // block's exit and 0,6 promised by its contract, so the per-register
        // walks read masks and the owner rows are touched only on the held
        // lanes. The mask arrays are also the whole of the per-function
        // commit that still has to be cleared.
        // The masks are the whole of the per-function commit that has to be
        // cleared. The owner rows carry no sentinel and are never filled: a
        // row is readable only where its block's held mask says so, which is
        // 2,75 lanes of sixteen at a block's exit and 0,60 in its contract, so
        // the fill was writing sixteen megabytes of a stage-1 compile that
        // nothing reads. Four masks per block in one allocation is one clear.
        u32 register_count = state.active_register_count;
        u32 mask_count = function->block_count ? function->block_count : 1u;
        u32* contract_owner = arena_allocate(arena, u32, (u64)function->block_count * register_count);
        u32* out_owner = arena_allocate(arena, u32, (u64)function->block_count * register_count);
        u64* block_masks = arena_allocate(arena, u64, (u64)mask_count * MACHINE_FAST_BLOCK_MASK_COUNT);
        u64* contract_held = block_masks;
        u64* contract_dirty = block_masks + mask_count;
        u64* out_held = block_masks + (u64)mask_count * 2u;
        u64* out_dirty = block_masks + (u64)mask_count * 3u;
        memset(block_masks, 0, (u64)mask_count * MACHINE_FAST_BLOCK_MASK_COUNT * sizeof(*block_masks));
        MachineBuilderStream retro_edits;
        machine_stream_initialize(&retro_edits, sizeof(MachineEdit));
        memset(state.virtual_register_locations, 0xff, (u64)function->virtual_register_count * sizeof(*state.virtual_register_locations));
        memset(state.owner, 0xff, (u64)description->register_count * sizeof(*state.owner));
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            MachineBlock* block = function->blocks + block_index;
            u32* entry_owner = contract_owner + (u64)block_index * register_count;
            u64 entry_held = 0;
            u64 entry_dirty = 0;
            // Contract construction. The designated predecessor — the layout
            // neighbor when it is a real edge, else the first already-scanned
            // one — donates its out state, filtered to values worth carrying: a
            // value must escape its block (anything else is dead at a
            // boundary), still be live here, and not be a rematerializable
            // constant, which recreates anywhere for less than a register.
            // Parameterized entries start from memory. Their incoming edges
            // first publish the parallel assignment into the parameter homes;
            // carrying the predecessor's register contract would require an
            // edge-specific SSA rename and can otherwise make the block assume
            // a parameter is resident while the predecessor still names its
            // source value in that register.
            if (block_index > 0 && !cold_blocks[block_index] && !block->parameter_count)
            {
                u32 first_predecessor = predecessor_offsets[block_index];
                u32 predecessor_limit = predecessor_offsets[block_index + 1];
                u32 designated = UINT32_MAX;
                u32 designated_index = UINT32_MAX;
                bool has_unscanned_predecessor = false;
                for (u32 predecessor_index = first_predecessor; predecessor_index < predecessor_limit; predecessor_index += 1)
                {
                    u32 predecessor = predecessor_list[predecessor_index];
                    if (predecessor >= block_index)
                    {
                        has_unscanned_predecessor = true;
                    }
                    else if (predecessor == block_index - 1 || designated == UINT32_MAX)
                    {
                        designated = predecessor;
                        designated_index = predecessor_index;
                    }
                }
                if (designated != UINT32_MAX)
                {
                    u32 const* donor_owner = out_owner + (u64)designated * register_count;
                    u64 donor_held = out_held[designated];
                    u64 donor_dirty = out_dirty[designated];
                    MachineEdge const* designated_edge = machine_fast_indexed_edge(function, prepass->predecessor_edges, designated_index);
                    // A register a pinned span holds at this block's entry
                    // belongs to the pinned value here, whatever any edge
                    // delivers, so the contract cannot promise it.
                    u64 entry_pin_active = block->instruction_count ? machine_fast_pin_active(&state, block->first_instruction) : 0;
                    for (u64 remaining = donor_held; remaining; remaining &= remaining - 1u)
                    {
                        u32 contract_register = machine_fast_first_set(remaining);
                        u32 value = donor_owner[contract_register];
                        if (((entry_pin_active >> contract_register) & 1u) || !state.escapes[value] ||
                            state.rematerialize_immediates[value] != UINT32_MAX || state.last_use[value] < block->first_instruction)
                        {
                            continue;
                        }
                        // A clean value is carried through single-predecessor
                        // and join blocks, where retention costs nothing on
                        // any edge that still holds it — but not into a block
                        // a back edge reaches, where the loop would reload it
                        // every iteration whether or not the body wants it.
                        // Measured on the pair's final shape: -20 M against
                        // carrying clean values everywhere. Dirty values are
                        // always worth carrying: the entry is the write-back
                        // its edge would otherwise pay.
                        if (has_unscanned_predecessor && !machine_fast_lane_held(donor_dirty, contract_register) &&
                            predecessor_limit - first_predecessor > 1)
                        {
                            continue;
                        }
                        entry_owner[contract_register] = machine_fast_edge_mapped_owner(function, designated_edge, value, donor_owner, register_count);
                        entry_held |= machine_fast_lane(contract_register);
                        entry_dirty |= donor_dirty & machine_fast_lane(contract_register);
                    }
                    // Intersection with the other scanned predecessors. An
                    // edge from a single-successor jump repairs retroactively,
                    // so a mismatch there keeps the entry and the conform
                    // below moves or reloads the value; any other source has
                    // successors that already consumed its state, so only its
                    // exact matches survive. Dirtiness is the OR over what the
                    // keeping edges actually deliver.
                    for (u32 predecessor_index = first_predecessor; predecessor_index < predecessor_limit; predecessor_index += 1)
                    {
                        u32 predecessor = predecessor_list[predecessor_index];
                        if (predecessor >= block_index || predecessor == designated)
                        {
                            continue;
                        }
                        u32 const* edge_owner = out_owner + (u64)predecessor * register_count;
                        u64 edge_held = out_held[predecessor];
                        u64 edge_dirty = out_dirty[predecessor];
                        MachineEdge const* predecessor_edge = machine_fast_indexed_edge(function, prepass->predecessor_edges, predecessor_index);
                        MachineBlock* predecessor_block = function->blocks + predecessor;
                        bool repairs_fully = false;
                        u64 repair_pin_active = 0;
                        if (predecessor_block->instruction_count)
                        {
                            u32 terminator_index = predecessor_block->first_instruction + predecessor_block->instruction_count - 1;
                            MachineInstruction* predecessor_terminator = function->instructions + terminator_index;
                            MachineOpcodeInfo const* terminator_info = machine_opcode_info(predecessor_terminator->opcode);
                            u32 terminator_targets = 0;
                            for (u32 slot = 0; slot < terminator_info->operand_count; slot += 1)
                            {
                                terminator_targets += machine_ref_kind(predecessor_terminator->operands[slot]) == MACHINE_REF_BLOCK;
                            }
                            repairs_fully = terminator_targets == 1 && predecessor_terminator->opcode != description->switch_opcode;
                            // A repair on this edge writes at the terminator,
                            // so it may not target a register a pinned span
                            // holds there; a matching delivery is proof the
                            // register was free, since a span's register is
                            // never in the scan's own file while it is held.
                            repair_pin_active = machine_fast_pin_active(&state, terminator_index);
                        }
                        for (u64 remaining = entry_held; remaining; remaining &= remaining - 1u)
                        {
                            u32 contract_register = machine_fast_first_set(remaining);
                            u32 value = entry_owner[contract_register];
                            u32 delivered = machine_fast_lane_held(edge_held, contract_register) ? edge_owner[contract_register] : UINT32_MAX;
                            u32 delivered_value = machine_fast_edge_mapped_owner(function, predecessor_edge, delivered, edge_owner, register_count);
                            if (delivered_value == value)
                            {
                                entry_dirty |= edge_dirty & machine_fast_lane(contract_register);
                            }
                            else if (repairs_fully && !((repair_pin_active >> contract_register) & 1u))
                            {
                                entry_dirty |= machine_fast_owner_contains(edge_owner, edge_dirty, value) ? machine_fast_lane(contract_register) : 0u;
                            }
                            else
                            {
                                entry_owner[contract_register] = UINT32_MAX;
                                entry_held &= ~machine_fast_lane(contract_register);
                                entry_dirty &= ~machine_fast_lane(contract_register);
                            }
                        }
                    }
                }
            }
            // Split spans opening at this block force their value into the
            // contract: every entering edge then installs it into the pinned
            // register through the ordinary conform below, and the backward
            // edges the span covers satisfy the entry through the conform's
            // span-invariant skip. Any other contract entry carrying the
            // value goes — a second register holding a copy the span's writes
            // would silently stale is exactly the hazard the pin verifier
            // exists for. The entry promises dirty: the value's slot is
            // refreshed by its landing-pad stores when it lives past the
            // span, and nothing reads it when it does not, so a dirty
            // delivery pays no entry store.
            for (u32 split_index = 0; split_index < state.split_entry_count; split_index += 1)
            {
                if (state.split_entries[split_index].block != block_index)
                {
                    continue;
                }
                u32 split_value = state.split_entries[split_index].virtual_register;
                u32 split_register = state.pinned_registers[split_value];
                for (u64 remaining = machine_fast_owner_match_mask(entry_owner, entry_held, split_value); remaining; remaining &= remaining - 1u)
                {
                    u32 contract_register = machine_fast_first_set(remaining);
                    entry_owner[contract_register] = UINT32_MAX;
                    entry_held &= ~machine_fast_lane(contract_register);
                    entry_dirty &= ~machine_fast_lane(contract_register);
                }
                entry_owner[split_register] = split_value;
                entry_held |= machine_fast_lane(split_register);
                entry_dirty |= machine_fast_lane(split_register);
            }
            contract_held[block_index] = entry_held;
            contract_dirty[block_index] = entry_dirty;
            // Conform every scanned predecessor edge to the contract just
            // fixed (the empty one for cold blocks and for blocks no scanned
            // edge reaches). The edits land retroactively at each source
            // terminator's point — the merge below re-sorts the stream — and
            // the snapshot mutations persist so a second successor of the
            // same source sees what its edge now actually delivers.
            if (block_index > 0)
            {
                for (u32 predecessor_index = predecessor_offsets[block_index]; predecessor_index < predecessor_offsets[block_index + 1]; predecessor_index += 1)
                {
                    u32 predecessor = predecessor_list[predecessor_index];
                    MachineBlock* predecessor_block = function->blocks + predecessor;
                    if (predecessor >= block_index || !predecessor_block->instruction_count)
                    {
                        continue;
                    }
                    u32 terminator_index = predecessor_block->first_instruction + predecessor_block->instruction_count - 1;
                    MachineInstruction* predecessor_terminator = function->instructions + terminator_index;
                    MachineOpcodeInfo const* terminator_info = machine_opcode_info(predecessor_terminator->opcode);
                    u32 terminator_targets = 0;
                    for (u32 slot = 0; slot < terminator_info->operand_count; slot += 1)
                    {
                        terminator_targets += machine_ref_kind(predecessor_terminator->operands[slot]) == MACHINE_REF_BLOCK;
                    }
                    MachineEdge const* predecessor_edge = machine_fast_indexed_edge(function, prepass->predecessor_edges, predecessor_index);
                    machine_fast_conform_edge_parameters(&state, &retro_edits, machine_point_make(terminator_index, MACHINE_POINT_BEFORE), predecessor_edge,
                                                         out_owner + (u64)predecessor * register_count, out_held + predecessor, out_dirty + predecessor, 0,
                                                         entry_owner, entry_held, entry_dirty,
                                                         terminator_targets == 1 && predecessor_terminator->opcode != description->switch_opcode);
                }
            }
            // The scan state becomes exactly the contract: the register file of
            // the block ahead is an interface every edge satisfies, not
            // whatever the layout neighbor happened to leave behind.
            for (u64 remaining = machine_fast_occupied(&state); remaining; remaining &= remaining - 1u)
            {
                u32 physical_register = machine_fast_first_set(remaining);
                state.virtual_register_locations[state.owner[physical_register]] = UINT32_MAX;
                state.owner[physical_register] = UINT32_MAX;
                state.held_mask &= ~machine_fast_lane(physical_register);
                state.dirty_mask &= ~machine_fast_lane(physical_register);
            }
            // Carried values enter fresh: in a loop the contract is the
            // working set, and making it the preferred eviction victim would
            // have the body displace exactly what the back edge must then
            // restore, every iteration. Dead expression temporaries are still
            // free victims through the eviction's dead-owner preference. An
            // entry naming a register a pinned span holds at this block's
            // head is the span's own installed value: it lives outside the
            // scan's file — the span invariant owns it — and loading it as a
            // local owner would have the opening eviction store it back
            // spuriously at a point every iteration passes.
            u64 head_pin_active = state.pinned_registers && block->instruction_count ? machine_fast_pin_active(&state, block->first_instruction) : 0;
            for (u64 remaining = entry_held & ~head_pin_active; remaining; remaining &= remaining - 1u)
            {
                u32 contract_register = machine_fast_first_set(remaining);
                u32 value = entry_owner[contract_register];
                state.owner[contract_register] = value;
                state.held_mask |= machine_fast_lane(contract_register);
                state.dirty_mask |= entry_dirty & machine_fast_lane(contract_register);
                state.virtual_register_locations[value] = contract_register;
                state.age[contract_register] = ++state.clock;
            }
            for (u32 offset = 0; offset < block->instruction_count; offset += 1)
            {
                u32 instruction_index = block->first_instruction + offset;
                MachineInstruction* instruction = function->instructions + instruction_index;
                u32 operand_masks = prepass->operand_masks[instruction_index];
                u32 virtual_slots = machine_fast_operand_mask(operand_masks, MACHINE_FAST_OPERAND_VIRTUAL_SHIFT);
                u32 use_slots = machine_fast_operand_mask(operand_masks, MACHINE_FAST_OPERAND_USE_SHIFT);
                u32 define_slots = machine_fast_operand_mask(operand_masks, MACHINE_FAST_OPERAND_DEFINE_SHIFT);
                u32 use_define_slots = machine_fast_operand_mask(operand_masks, MACHINE_FAST_OPERAND_USE_DEFINE_SHIFT);
                state.current_point = machine_point_make(instruction_index, MACHINE_POINT_BEFORE);
                state.uses_consumed = false;
                // Split write-backs land at this row's head: the landing pad
                // every path out of the split span passes, where the value's
                // register still holds it. Emitted ahead of the row's own
                // edits, so nothing at this point can have touched the
                // register first, and the slot is current before any reload
                // of the value the row itself places.
                while (state.split_store_cursor < state.split_store_count && state.split_stores[state.split_store_cursor].row == instruction_index)
                {
                    u32 stored_value = state.split_stores[state.split_store_cursor].virtual_register;
                    MachineEdit* store_edit = (MachineEdit*)machine_stream_append(state.arena, state.edits);
                    *store_edit = (MachineEdit){
                        .point = state.current_point,
                        .kind = MACHINE_EDIT_SPILL,
                        .subject = stored_value,
                        .location = state.pinned_registers[stored_value],
                    };
                    placement.spill_count += 1;
                    placement.boundary_spill_count += 1;
                    state.split_store_cursor += 1;
                }
                // A register entering a pinned span belongs to its value from
                // here, so any local owner leaves first. At a block head the
                // contract construction already refused these registers, so
                // the eviction only fires where a span opens mid-block — at a
                // pinned value's definition — which is a point that cannot
                // re-execute without passing the block head again.
                u64 pins_opening = state.pinned_registers ? machine_fast_pin_active(&state, instruction_index) : 0;
                for (u32 physical_register = 0; pins_opening; physical_register += 1)
                {
                    if (pins_opening & (1ull << physical_register))
                    {
                        pins_opening &= ~(1ull << physical_register);
                        if (state.owner[physical_register] != UINT32_MAX)
                        {
                            machine_fast_spill(&state, physical_register);
                        }
                    }
                }
                u8* operand_registers = placement.operand_registers + (u64)instruction_index * 4;
                memset(operand_registers, 0xff, 4);
                // Most selected rows are virtual-only, unconstrained dataflow.
                // Keep that homogeneous population on a compact mask kernel;
                // fixed registers, clobbers and control flow stay in the general
                // path below instead of taxing every common row with their state.
                if (operand_masks & MACHINE_FAST_OPERAND_SIMPLE_ROW)
                {
                    for (u32 remaining = virtual_slots & use_slots; remaining; remaining &= remaining - 1u)
                    {
                        u32 slot = machine_fast_first_set(remaining);
                        MachineRef ref = instruction->operands[slot];
                        u32 virtual_register = machine_ref_payload(ref);
                        if (state.pinned_registers && machine_fast_pin_covers(&state, virtual_register, instruction_index))
                        {
                            operand_registers[slot] = (u8)state.pinned_registers[virtual_register];
                            continue;
                        }
                        u32 used = machine_fast_ensure(&state, virtual_register, UINT32_MAX, 0);
                        operand_registers[slot] = (u8)used;
                        state.dirty_mask |= (use_define_slots & (1u << slot)) ? machine_fast_lane(used) : 0u;
                    }
                    for (u32 remaining = virtual_slots & define_slots; remaining; remaining &= remaining - 1u)
                    {
                        u32 slot = machine_fast_first_set(remaining);
                        MachineRef ref = instruction->operands[slot];
                        u32 virtual_register = machine_ref_payload(ref);
                        if (state.pinned_registers && machine_fast_pin_covers(&state, virtual_register, instruction_index))
                        {
                            operand_registers[slot] = (u8)state.pinned_registers[virtual_register];
                            continue;
                        }
                        u32 target;
                        if ((instruction->opcode == description->copy_opcode || instruction->opcode == description->vector_copy_opcode) && slot == 0 &&
                            (virtual_slots & (1u << 1)) && machine_ref_payload(instruction->operands[1]) != virtual_register &&
                            operand_registers[1] != UINT8_MAX &&
                            (!state.pinned_registers || !((machine_fast_pin_active(&state, instruction_index) >> operand_registers[1]) & 1u)) &&
                            machine_fast_source_dies_here(&state, machine_ref_payload(instruction->operands[1])))
                        {
                            target = operand_registers[1];
                            u32 dying = machine_ref_payload(instruction->operands[1]);
                            state.owner[target] = UINT32_MAX;
                            state.held_mask &= ~machine_fast_lane(target);
                            state.dirty_mask &= ~machine_fast_lane(target);
                            state.virtual_register_locations[dying] = UINT32_MAX;
                        }
                        else
                        {
                            target = machine_fast_pick(&state, machine_fast_class_mask(&state, virtual_register), 0,
                                                       machine_fast_crosses_call(&state, virtual_register));
                        }
                        machine_fast_bind(&state, virtual_register, target);
                        operand_registers[slot] = (u8)target;
                    }
                    state.uses_consumed = true;
                    continue;
                }
                // The prepass validated every opcode before publishing a simple
                // row. Only the irregular population needs its full descriptor
                // again during placement.
                MachineOpcodeInfo const* info = machine_opcode_info(instruction->opcode);
                if (!info)
                {
                    return placement;
                }
                u32 physical_slots = machine_fast_operand_mask(operand_masks, MACHINE_FAST_OPERAND_PHYSICAL_SHIFT);
                u32 block_slots = machine_fast_operand_mask(operand_masks, MACHINE_FAST_OPERAND_BLOCK_SHIFT);
                // The three predicates and the clobber set come from the
                // published row, one line, instead of six fields of the
                // descriptor spread over two.
                MachineOpcodeRow opcode_row = machine_instruction_opcode_row(function, instruction);
                bool constrained = (opcode_row.flags & MACHINE_OPCODE_ROW_CONSTRAINED) != 0;
                bool is_call = (opcode_row.flags & MACHINE_OPCODE_ROW_CALL) != 0;
                bool is_terminator = (opcode_row.flags & MACHINE_OPCODE_ROW_TERMINATOR) != 0;
                u32 tied_destination = machine_fast_tied_destination(info);
                u32 tied_source = machine_fast_tied_source(info);
                u32 tied_target = UINT32_MAX;
                bool tied_source_dies = false;
                // Fixed physical operands and the constrained layout vacate
                // their registers first so uses cannot land on them.
                u64 reserved_mask = opcode_row.clobber_mask;
                u32 reservation_slots =
                    (physical_slots | info->fixed_register_mask | (constrained ? virtual_slots : 0u)) & MACHINE_FAST_OPERAND_LANE_MASK;
                for (u32 remaining = reservation_slots; remaining; remaining &= remaining - 1u)
                {
                    u32 slot = machine_fast_first_set(remaining);
                    MachineRef ref = instruction->operands[slot];
                    u32 lane = 1u << slot;
                    if (physical_slots & lane)
                    {
                        reserved_mask |= 1ull << machine_ref_payload(ref);
                        operand_registers[slot] = (u8)machine_ref_payload(ref);
                    }
                    u32 fixed = machine_opcode_fixed_register(info, slot);
                    if (fixed != UINT32_MAX && fixed < MACHINE_TARGET_REGISTER_LIMIT)
                    {
                        reserved_mask |= 1ull << fixed;
                    }
                    else if (constrained && (virtual_slots & lane))
                    {
                        reserved_mask |= 1ull << machine_fast_slot_scratch(&state, info, slot);
                    }
                }
                // Establish the tied register before placing uses.  A dying
                // source may transfer its existing register; a live source must
                // be copied to another register so true SSA remains intact.
                if (tied_destination < info->operand_count && tied_source < info->operand_count && tied_destination != tied_source)
                {
                    MachineRef destination_ref = instruction->operands[tied_destination];
                    MachineRef source_ref = instruction->operands[tied_source];
                    u32 fixed_destination = machine_opcode_fixed_register(info, tied_destination);
                    if (physical_slots & (1u << tied_destination))
                    {
                        tied_target = machine_ref_payload(destination_ref);
                    }
                    else if (fixed_destination != UINT32_MAX)
                    {
                        tied_target = fixed_destination;
                    }
                    else if (constrained)
                    {
                        tied_target = machine_fast_slot_scratch(&state, info, tied_destination);
                    }
                    if (virtual_slots & (1u << tied_source))
                    {
                        u32 source_virtual = machine_ref_payload(source_ref);
                        tied_source_dies = machine_fast_source_dies_here(&state, source_virtual);
                        // Dying at this row is not dead for the transfer when
                        // another use slot of the same row reads the same
                        // vreg: releasing the register would send that read
                        // to a home slot nothing ever stored.  CPython's
                        // insert_to_usedpool indexes `usedpools[size + size]`
                        // -- both add operands are one promoted local -- and
                        // the reload of the discarded value walked the
                        // allocator into unmapped memory.
                        for (u32 other_slot = 0; tied_source_dies && other_slot < info->operand_count; other_slot += 1)
                        {
                            if (other_slot != tied_source && (virtual_slots & (1u << other_slot)) && (use_slots & (1u << other_slot)) &&
                                machine_ref_payload(instruction->operands[other_slot]) == source_virtual)
                            {
                                tied_source_dies = false;
                            }
                        }
                        u32 source_location = state.virtual_register_locations[source_virtual];
                        if (tied_target == UINT32_MAX && source_location != UINT32_MAX && tied_source_dies)
                        {
                            tied_target = source_location;
                        }
                        if (tied_target == UINT32_MAX)
                        {
                            u64 forbidden = reserved_mask;
                            if (source_location != UINT32_MAX && !tied_source_dies)
                            {
                                forbidden |= 1ull << source_location;
                            }
                            u32 destination_virtual = (virtual_slots & (1u << tied_destination))
                                                           ? machine_ref_payload(destination_ref)
                                                           : source_virtual;
                            tied_target = machine_fast_pick(&state, machine_fast_class_mask(&state, destination_virtual), forbidden,
                                                            machine_fast_crosses_call(&state, destination_virtual));
                        }
                    }
                    else if ((physical_slots & (1u << tied_source)) && tied_target == UINT32_MAX)
                    {
                        tied_target = machine_ref_payload(source_ref);
                    }
                }
                // Uses first: constrained slots force their scratch register,
                // free slots keep or pick any register.
                for (u32 remaining = virtual_slots & use_slots; remaining; remaining &= remaining - 1u)
                {
                    u32 slot = machine_fast_first_set(remaining);
                    MachineRef ref = instruction->operands[slot];
                    u32 fixed = machine_opcode_fixed_register(info, slot);
                    if (slot == tied_source && tied_target != UINT32_MAX)
                    {
                        machine_fast_materialize_tied(&state, machine_ref_payload(ref), tied_target, tied_source_dies);
                        operand_registers[slot] = (u8)tied_target;
                        continue;
                    }
                    if (fixed == UINT32_MAX && machine_fast_pin_covers(&state, machine_ref_payload(ref), instruction_index))
                    {
                        operand_registers[slot] = (u8)state.pinned_registers[machine_ref_payload(ref)];
                        continue;
                    }
                    u32 target = fixed != UINT32_MAX                  ? fixed
                                 : constrained                         ? machine_fast_slot_scratch(&state, info, slot)
                                 : instruction->opcode == description->indirect_call_opcode ? (u32)description->indirect_call_register
                                                                                            : UINT32_MAX;
                    // A copy into a fixed physical register stages its source in
                    // that same register, so an argument sequence can never
                    // clobber an already-placed argument through a free pick;
                    // the float-argument bridge stages through RAX, which is
                    // never an argument register. The vector copy stages the
                    // same way: a reload landing on an already-staged ZMM
                    // argument register would destroy it.
                    if ((instruction->opcode == description->copy_opcode || instruction->opcode == description->vector_copy_opcode) && slot == 1 &&
                        (physical_slots & 1u))
                    {
                        target = machine_ref_payload(instruction->operands[0]);
                    }
                    if (instruction->opcode == description->float_bridge_opcode)
                    {
                        target = description->float_bridge_register;
                    }
                    u32 used = machine_fast_ensure(&state, machine_ref_payload(ref), target,
                                                   target == UINT32_MAX ? reserved_mask : 0);
                    operand_registers[slot] = (u8)used;
                    state.dirty_mask |= (use_define_slots & (1u << slot)) ? machine_fast_lane(used) : 0u;
                }
                // Fixed physical destinations and encoder-internal clobbers
                // evict their owners before the instruction writes them.
                for (u32 remaining = physical_slots & define_slots; remaining; remaining &= remaining - 1u)
                {
                    u32 slot = machine_fast_first_set(remaining);
                    MachineRef ref = instruction->operands[slot];
                    u32 physical_register = machine_ref_payload(ref);
                    if (state.owner[physical_register] != UINT32_MAX)
                    {
                        // Overwriting a live owner: the spill store lands before
                        // this instruction writes the register, and any
                        // same-instruction use was already consumed.
                        machine_fast_spill(&state, physical_register);
                    }
                }
                // Early-clobber definitions cannot share a register with any
                // live input, even when the input's textual use was placed first.
                // Rebind the definition to a free register (or spill the input)
                // before its write executes.
                u32 early_clobber_slots = info->early_clobber_mask & (~use_slots | use_define_slots) & MACHINE_FAST_OPERAND_LANE_MASK;
                for (u32 remaining = early_clobber_slots; remaining; remaining &= remaining - 1u)
                {
                    u32 slot = machine_fast_first_set(remaining);
                    u32 destination = operand_registers[slot];
                    if (destination == UINT8_MAX)
                    {
                        continue;
                    }
                    for (u32 other = 0; other < info->operand_count; other += 1)
                    {
                        if (other == slot || operand_registers[other] == UINT8_MAX || operand_registers[other] != destination)
                        {
                            continue;
                        }
                        // A tied use is allowed to share the destination by
                        // definition; early-clobber only disqualifies the other
                        // inputs.  For an ordinary input, move the virtual
                        // destination instead of rebinding the input: the input
                        // register still contains the value for the instruction,
                        // while the destination's write lands in a disjoint file.
                        if (other == tied_source)
                        {
                            continue;
                        }
                        MachineRef destination_ref = instruction->operands[slot];
                        if (virtual_slots & (1u << slot))
                        {
                            machine_fast_spill(&state, destination);
                            u32 destination_virtual = machine_ref_payload(destination_ref);
                            u64 forbidden = reserved_mask | (1ull << destination);
                            for (u32 input_slot = 0; input_slot < info->operand_count; input_slot += 1)
                            {
                                if (input_slot != slot && operand_registers[input_slot] != UINT8_MAX)
                                {
                                    forbidden |= 1ull << operand_registers[input_slot];
                                }
                            }
                            u32 replacement = machine_fast_pick(&state, machine_fast_class_mask(&state, destination_virtual), forbidden,
                                                                machine_fast_crosses_call(&state, destination_virtual));
                            operand_registers[slot] = (u8)replacement;
                            break;
                        }
                    }
                }
                u64 clobber_mask = opcode_row.clobber_mask;
                for (u32 physical_register = 0; clobber_mask; physical_register += 1)
                {
                    if (clobber_mask & (1ull << physical_register))
                    {
                        clobber_mask &= ~(1ull << physical_register);
                        machine_fast_spill(&state, physical_register);
                    }
                }
                // Vreg definitions bind their register lazily dirty.
                for (u32 remaining = virtual_slots & define_slots; remaining; remaining &= remaining - 1u)
                {
                    u32 slot = machine_fast_first_set(remaining);
                    MachineRef ref = instruction->operands[slot];
                    if (machine_fast_pin_covers(&state, machine_ref_payload(ref), instruction_index))
                    {
                        operand_registers[slot] = (u8)state.pinned_registers[machine_ref_payload(ref)];
                        continue;
                    }
                    u32 target;
                    u32 fixed = machine_opcode_fixed_register(info, slot);
                    if (fixed != UINT32_MAX)
                    {
                        target = fixed;
                    }
                    else if (slot == tied_destination && tied_target != UINT32_MAX)
                    {
                        target = tied_target;
                    }
                    else if (constrained)
                    {
                        target = machine_fast_slot_scratch(&state, info, slot);
                    }
                    else if ((instruction->opcode == description->copy_opcode || instruction->opcode == description->vector_copy_opcode) && slot == 0 &&
                             (physical_slots & (1u << 1)) &&
                             ((description->allocatable_mask | description->vector_allocatable_mask) >> machine_ref_payload(instruction->operands[1])) & 1u)
                    {
                        // A capture of a fixed physical register (incoming
                        // argument, call result) binds in place: a free pick here
                        // could land on an argument register whose own capture
                        // has not executed yet and destroy it. Vector captures —
                        // incoming ZMM arguments, the ZMM0 call result — bind the
                        // same way in the vector file.
                        target = machine_ref_payload(instruction->operands[1]);
                    }
                    else if ((instruction->opcode == description->copy_opcode || instruction->opcode == description->vector_copy_opcode) && slot == 0 &&
                             (virtual_slots & (1u << 1)) &&
                             machine_ref_payload(instruction->operands[1]) != machine_ref_payload(ref) &&
                             operand_registers[1] != UINT8_MAX && !((machine_fast_pin_active(&state, instruction_index) >> operand_registers[1]) & 1u) &&
                             machine_fast_source_dies_here(&state, machine_ref_payload(instruction->operands[1])))
                    {
                        // Coalesce: the source's last use is this copy, so the
                        // destination takes its register and the row encodes to
                        // nothing. Ownership transfers directly — routing it
                        // through an eviction would write the dying source back
                        // to a slot nobody reads.
                        target = operand_registers[1];
                        u32 dying = machine_ref_payload(instruction->operands[1]);
                        state.owner[target] = UINT32_MAX;
                        state.held_mask &= ~machine_fast_lane(target);
                        state.dirty_mask &= ~machine_fast_lane(target);
                        state.virtual_register_locations[dying] = UINT32_MAX;
                    }
                    else
                    {
                        target = machine_fast_pick(&state, machine_fast_class_mask(&state, machine_ref_payload(ref)), reserved_mask,
                                                   machine_fast_crosses_call(&state, machine_ref_payload(ref)));
                    }
                    machine_fast_bind(&state, machine_ref_payload(ref), target);
                    operand_registers[slot] = (u8)target;
                }
                state.uses_consumed = true;
                if (is_call)
                {
                    // Callee-saved members survive the call by definition;
                    // everything else is caller-saved and flushes.
                    machine_fast_flush(&state, description->callee_saved_mask);
                }
                if (is_terminator)
                {
                    // Successors whose contract is already fixed — every
                    // backward edge, the self loop, and any statically cold
                    // target — get the state rewritten to their contract here.
                    // The edits stay at this terminator's BEFORE point, which
                    // the encoder emits ahead of the branch, and none of them
                    // can disturb the flags a conditional terminator just
                    // consumed. A forward, not-yet-cold successor takes the
                    // state as it stands: the snapshot recorded below is what
                    // its own contract construction conforms retroactively.
                    u32 inline_successor = 0;
                    u32 inline_successor_count = 0;
                    bool inline_assembly = machine_fast_inline_assembly_successors(function, instruction,
                                                                                    &inline_successor, &inline_successor_count);
                    if (inline_assembly || instruction->opcode == description->switch_opcode ||
                        instruction->opcode == MACHINE_X64_INDIRECT_BRANCH || instruction->opcode == MACHINE_A64_INDIRECT_BRANCH)
                    {
                        // Case targets, the default, and asm-goto landing
                        // continuations are all cold, so one conform to the
                        // empty contract serves every edge the dispatch or byte
                        // template can select.
                        machine_fast_conform_edge(&state, &edits, state.current_point, state.owner, &state.held_mask, &state.dirty_mask,
                                                  state.virtual_register_locations, machine_fast_empty_contract_owner, 0, 0, true);
                    }
                    else
                    {
                        for (u32 remaining = block_slots; remaining; remaining &= remaining - 1u)
                        {
                            u32 slot = machine_fast_first_set(remaining);
                            u32 successor = machine_ref_payload(instruction->operands[slot]);
                            MachineEdge const* successor_edge = machine_fast_indexed_edge(function, prepass->terminator_edges, (u64)block_index * MACHINE_INSTRUCTION_OPERAND_COUNT + slot);
                            if (successor <= block_index)
                            {
                                machine_fast_conform_edge_parameters(&state, &edits, state.current_point, successor_edge, state.owner, &state.held_mask,
                                                                     &state.dirty_mask, state.virtual_register_locations,
                                                                     contract_owner + (u64)successor * register_count, contract_held[successor],
                                                                     contract_dirty[successor], true);
                            }
                            else if (cold_blocks[successor])
                            {
                                machine_fast_conform_edge(&state, &edits, state.current_point, state.owner, &state.held_mask, &state.dirty_mask,
                                                          state.virtual_register_locations, machine_fast_empty_contract_owner, 0, 0, true);
                            }
                        }
                    }
                    // A return keeps its dirty values: the frame dies with it
                    // and there is no successor to see the slots.
                    u64 recorded = machine_fast_occupied(&state);
                    u32* recorded_owner = out_owner + (u64)block_index * register_count;
                    for (u64 remaining = recorded; remaining; remaining &= remaining - 1u)
                    {
                        u32 physical_register = machine_fast_first_set(remaining);
                        recorded_owner[physical_register] = state.owner[physical_register];
                    }
                    out_held[block_index] = recorded;
                    // Clamped to the recorded lanes, which is what the
                    // byte-array snapshot copied when it ran to the active
                    // count: a fixed-register owner past that count — the
                    // float bridge in an all-scalar function — must not put a
                    // dirty bit on a lane the snapshot never recorded.
                    out_dirty[block_index] = state.dirty_mask & recorded;
                }
            }
        }
        // The scan's own stream is point-sorted by construction; retroactive
        // conforms are not, so they sort and merge behind it — after the
        // terminator's own edits at the same point, which is the state every
        // retroactive repair was computed against.
        placement.edit_count = edits.total_count + retro_edits.total_count;
        placement.edits = arena_allocate(arena, MachineEdit, placement.edit_count ? placement.edit_count : 1);
        if (!retro_edits.total_count)
        {
            machine_stream_flatten(&edits, placement.edits);
        }
        else
        {
            MachineEdit* main_edits = arena_allocate(arena, MachineEdit, edits.total_count ? edits.total_count : 1);
            MachineEdit* retro_flat = arena_allocate(arena, MachineEdit, retro_edits.total_count);
            MachineEdit* retro_scratch = arena_allocate(arena, MachineEdit, retro_edits.total_count);
            machine_stream_flatten(&edits, main_edits);
            machine_stream_flatten(&retro_edits, retro_flat);
            machine_fast_sort_edits(retro_flat, retro_scratch, retro_edits.total_count);
            u32 main_cursor = 0;
            u32 retro_cursor = 0;
            for (u32 edit_index = 0; edit_index < placement.edit_count; edit_index += 1)
            {
                bool take_main = main_cursor < edits.total_count &&
                                 (retro_cursor >= retro_edits.total_count || main_edits[main_cursor].point <= retro_flat[retro_cursor].point);
                placement.edits[edit_index] = take_main ? main_edits[main_cursor++] : retro_flat[retro_cursor++];
            }
        }
        // Frame layout runs after the scan: every touch of a vreg slot flows
        // through the edit stream, so only edit subjects get backing slots.
        // Values that never left their registers cost no frame bytes.
        u32 value_count = function->virtual_register_count ? function->virtual_register_count : 1u;
        u8* slot_needed = arena_allocate(arena, u8, function->virtual_register_count);
        u32* home_starts = arena_allocate(arena, u32, value_count);
        u32* home_ends = arena_allocate(arena, u32, value_count);
        // A spill fills a home and a reload reads it, which is all the
        // liveness walk below needs; an edit whose point lies outside the
        // rows the blocks tile belongs to no block, and the home it names
        // keeps storage of its own.
        u8* home_opaque = arena_allocate(arena, u8, value_count);
        // A home read before anything in the stream fills it holds a value
        // that crossed into these rows from somewhere the stream does not
        // order, so its range is not the rows between its edits.
        u8* home_read_first = arena_allocate(arena, u8, value_count);
        u32* row_blocks = arena_allocate(arena, u32, function->instruction_count ? function->instruction_count : 1u);
        memset(slot_needed, 0, function->virtual_register_count);
        memset(home_starts, 0xff, (u64)value_count * sizeof(*home_starts));
        memset(home_ends, 0, (u64)value_count * sizeof(*home_ends));
        memset(home_opaque, 0, value_count);
        memset(home_read_first, 0, value_count);
        // Sharing storage is an argument in row space: a range between two
        // rows must cover every row that can execute between them, and the
        // block a row belongs to has to be the one whose index the graph
        // names. Both hold exactly when the blocks tile the rows in index
        // order, which the selector's output does; anything else keeps one
        // object per storage.
        bool layout_linear = true;
        u32 tiled_rows = 0;
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            MachineBlock const* block = function->blocks + block_index;
            layout_linear = layout_linear && block->first_instruction == tiled_rows &&
                            block->instruction_count <= function->instruction_count - tiled_rows;
            tiled_rows = layout_linear ? tiled_rows + block->instruction_count : tiled_rows;
            for (u32 offset = 0; layout_linear && offset < block->instruction_count; offset += 1)
            {
                row_blocks[block->first_instruction + offset] = block_index;
            }
        }
        for (u32 edit_index = 0; edit_index < placement.edit_count; edit_index += 1)
        {
            // Only the memory edits name a virtual register: a copy's subject
            // is a physical register and a rematerialization's is an immediate
            // index, and neither indexes this array.
            MachineEdit* edit = placement.edits + edit_index;
            if (edit->kind == MACHINE_EDIT_SPILL || edit->kind == MACHINE_EDIT_RELOAD)
            {
                u32 row = machine_point_instruction(edit->point);
                u32 block_index = row < function->instruction_count ? row_blocks[row] : UINT32_MAX;
                home_read_first[edit->subject] |= (u8)(!slot_needed[edit->subject] && edit->kind == MACHINE_EDIT_RELOAD);
                slot_needed[edit->subject] = 1;
                home_opaque[edit->subject] |= (u8)(block_index == UINT32_MAX || !layout_linear);
                home_starts[edit->subject] = BUSTER_MIN(home_starts[edit->subject], row);
                home_ends[edit->subject] = BUSTER_MAX(home_ends[edit->subject], row);
            }
        }
        // Storage may only be handed to a second object when the rows a range
        // covers are the only rows that can read it. A `longjmp` back into
        // this frame resumes at a row no machine edge reaches, past whatever
        // the second object wrote, so a function that is not certified free of
        // returns-twice calls keeps one object per storage.
        bool reuse_frame_storage = layout_linear && function->returns_twice_absence_certified;
        // A withdrawn home is one the colorer never selects, so each of them
        // gets storage of its own below. Every remaining home is closed over
        // the machine CFG from the allocator's own reload/spill memory program;
        // this includes values that enter before their first lexical spill and
        // values whose home lifetime crosses the block where they were defined.
        // The closure is enabled only for a direct acyclic block chain. A
        // branch, join, loop, indirect edge, or inline-assembly landing has
        // path-specific edge repairs whose equal-point edits cannot be
        // represented by one linear range without a dedicated proof. Keep the
        // older per-home guard for those shapes until that proof exists.
        bool linear_cfg = true;
        u32* outgoing_counts = arena_allocate(arena, u32, function->block_count ? function->block_count : 1u);
        memset(outgoing_counts, 0, (u64)(function->block_count ? function->block_count : 1u) * sizeof(*outgoing_counts));
        for (u32 destination = 0; destination < function->block_count; destination += 1)
        {
            u32 first = prepass->predecessor_offsets ? prepass->predecessor_offsets[destination] : 0;
            u32 limit = prepass->predecessor_offsets ? prepass->predecessor_offsets[destination + 1u] : 0;
            linear_cfg &= limit - first <= 1u;
            for (u32 entry = first; entry < limit; entry += 1)
            {
                u32 source = prepass->predecessor_list[entry];
                bool direct = source < function->block_count && source + 1u == destination;
                linear_cfg &= direct;
                if (source < function->block_count)
                {
                    outgoing_counts[source] += 1;
                    linear_cfg &= outgoing_counts[source] <= 1u;
                }
            }
        }
        for (u32 register_index = 0; register_index < function->virtual_register_count; register_index += 1)
        {
            // A home the edit rows bound is one this function both fills and
            // empties: its value stays inside its defining block, the stream
            // fills the home before it reads it, and every edit that names it
            // sits in that block's rows. Then a read of the home is an edit
            // between those rows, an iteration of a loop around the block
            // refills it before reading it, and the range needs no closure
            // over the loops around it.
            u32 definition_block = prepass->definition_blocks[register_index];
            MachineBlock const* home_block = definition_block < function->block_count ? function->blocks + definition_block : 0;
            bool inside_block = home_block && home_starts[register_index] >= home_block->first_instruction &&
                                home_ends[register_index] < home_block->first_instruction + home_block->instruction_count;
            bool cross_block_colorable = reuse_frame_storage && linear_cfg && slot_needed[register_index] && !home_opaque[register_index];
            bool local_colorable = reuse_frame_storage && !linear_cfg && slot_needed[register_index] && !home_opaque[register_index] &&
                                   !home_read_first[register_index] && !prepass->escapes[register_index] && inside_block;
            bool colorable = cross_block_colorable || local_colorable;
            home_starts[register_index] = colorable ? home_starts[register_index] : UINT32_MAX;
        }
        if (reuse_frame_storage && linear_cfg)
        {
            machine_fast_close_home_ranges(arena, function, prepass, &placement, row_blocks, slot_needed, home_opaque, home_starts, home_ends);
        }
        // The selector's frame objects share the homes' argument, over wider
        // ranges: a slot's storage has to hold from its first touched row
        // through every row where what was written to it may still be read,
        // and two slots whose ranges miss each other never hold a live object
        // at once. What the rows cannot see keeps its own storage: a slot
        // whose address the frame address row hands to a register, one an
        // inline-assembly transaction or a variadic fetch owns, a
        // volatile-tainted one, and the fixed outgoing argument area. Debug
        // records name slots too, but what they name may not decide layout:
        // the code a build emits with debug information has to be the code it
        // emits without.
        u32 slot_axis = function->stack_slot_count ? function->stack_slot_count : 1u;
        u32* slot_starts = arena_allocate(arena, u32, slot_axis);
        u32* slot_ends = arena_allocate(arena, u32, slot_axis);
        u8* slot_fixed = arena_allocate(arena, u8, slot_axis);
        u32* slot_groups = arena_allocate(arena, u32, slot_axis);
        u32* group_sizes = arena_allocate(arena, u32, slot_axis);
        u32* group_alignments = arena_allocate(arena, u32, slot_axis);
        u32* group_offsets = arena_allocate(arena, u32, slot_axis);
        bool coalesce_slots = reuse_frame_storage && description->frame_address_opcode != 0;
        memset(slot_starts, 0xff, (u64)slot_axis * sizeof(*slot_starts));
        memset(slot_ends, 0, (u64)slot_axis * sizeof(*slot_ends));
        memset(slot_fixed, coalesce_slots ? 0 : 1, slot_axis);
        memset(slot_groups, 0xff, (u64)slot_axis * sizeof(*slot_groups));
        for (u32 row = 0; coalesce_slots && row < function->instruction_count; row += 1)
        {
            MachineInstruction const* instruction = function->instructions + row;
            bool addresses = instruction->opcode == description->frame_address_opcode;
            MachineScheduleMemoryAccess access = machine_schedule_frame_access(function, instruction);
            for (u32 operand_index = 0; operand_index < MACHINE_INSTRUCTION_OPERAND_COUNT; operand_index += 1)
            {
                MachineRef operand = instruction->operands[operand_index];
                u32 named = machine_ref_payload(operand);
                if (machine_ref_kind(operand) == MACHINE_REF_STACK_SLOT && named < function->stack_slot_count)
                {
                    // Liveness reads the frame forms whose slot, extent and
                    // direction are proven. A row naming a slot any other way
                    // is a touch it cannot account for, so that slot keeps its
                    // own storage.
                    bool proven = access.kind == MACHINE_SCHEDULE_MEMORY_STACK_RANGE && access.stack_slot == named;
                    slot_starts[named] = BUSTER_MIN(slot_starts[named], row);
                    slot_ends[named] = BUSTER_MAX(slot_ends[named], row);
                    slot_fixed[named] |= (u8)(addresses || !proven);
                }
            }
        }
        for (u32 operand_index = 0; coalesce_slots && operand_index < function->inline_assembly_operand_count; operand_index += 1)
        {
            u32 named = function->inline_assembly_operands[operand_index].stack_slot;
            bool inside = named < function->stack_slot_count;
            slot_fixed[inside ? named : 0] |= (u8)inside;
        }
        for (u32 va_index = 0; coalesce_slots && va_index < function->va_arg_count; va_index += 1)
        {
            MachineVaArg const* va_arg = function->va_args + va_index;
            bool inside = va_arg->result_is_frame && va_arg->result_slot < function->stack_slot_count;
            slot_fixed[inside ? va_arg->result_slot : 0] |= (u8)inside;
        }
        for (u32 slot_index = 0; coalesce_slots && slot_index < function->stack_slot_count; slot_index += 1)
        {
            slot_fixed[slot_index] |= (u8)(function->stack_slot_memory_flags && function->stack_slot_memory_flags[slot_index] != 0);
            slot_fixed[slot_index] |= (u8)(function->outgoing_bytes && slot_index == function->outgoing_slot);
        }
        if (coalesce_slots)
        {
            u32 words = (function->stack_slot_count + 63u) / 64u;
            u64 plane = (u64)function->block_count * words;
            u64* reads = arena_allocate(arena, u64, plane ? plane : 1);
            u64* writes = arena_allocate(arena, u64, plane ? plane : 1);
            memset(reads, 0, (plane ? plane : 1) * sizeof(*reads));
            memset(writes, 0, (plane ? plane : 1) * sizeof(*writes));
            for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
            {
                MachineBlock const* block = function->blocks + block_index;
                u64* block_reads = reads + (u64)block_index * words;
                u64* block_writes = writes + (u64)block_index * words;
                // Backward through the block: the last touch of a slot
                // decides, and a read below a covering store is what keeps
                // the slot live into the block.
                for (u32 offset = block->instruction_count; offset; offset -= 1)
                {
                    MachineInstruction const* instruction = function->instructions + block->first_instruction + offset - 1u;
                    MachineScheduleMemoryAccess access = machine_schedule_frame_access(function, instruction);
                    bool bounded = access.kind == MACHINE_SCHEDULE_MEMORY_STACK_RANGE;
                    u32 slot_index = bounded ? access.stack_slot : 0;
                    bool stores = machine_ref_kind(instruction->operands[0]) == MACHINE_REF_STACK_SLOT;
                    bool covers = bounded && stores && access.offset == 0 && access.size >= function->stack_slot_sizes[slot_index];
                    u64 bit = (u64)bounded << (slot_index & 63u);
                    u64 covering = covers ? bit : 0;
                    u64 reading = bit & ~covering;
                    block_reads[slot_index / 64u] = (block_reads[slot_index / 64u] | reading) & ~covering;
                    block_writes[slot_index / 64u] = (block_writes[slot_index / 64u] | covering) & ~reading;
                }
            }
            machine_fast_close_live_ranges(arena, function, prepass, reads, writes, words, slot_starts, slot_ends);
        }
        u32 group_count =
            machine_fast_color_slots(arena, function, slot_fixed, slot_starts, slot_ends, slot_groups, group_sizes, group_alignments);
        // Two pools, one per home width: the eight-byte scalar homes and the
        // sixty-four-byte vector ones, so a rarely spilled vector never widens
        // the slots the scalar homes share.
        u32* pool_indices = arena_allocate(arena, u32, value_count);
        memset(pool_indices, 0xff, (u64)value_count * sizeof(*pool_indices));
        u32 pool_size = machine_fast_color_homes(arena, function, slot_needed, home_starts, home_ends, false, pool_indices);
        u32 vector_pool_size = machine_fast_color_homes(arena, function, slot_needed, home_starts, home_ends, true, pool_indices);
        // The pushed callee-saved registers sit between the frame base and the
        // slots, so every offset starts past them, and the stack allocation
        // keeps sixteen-alignment across an odd push count.
        u32 push_count = 0;
        for (u32 physical_register = 0; physical_register < description->register_count; physical_register += 1)
        {
            push_count += (u32)((placement.callee_saved_mask >> physical_register) & 1u);
        }
        // Zero where the callee-saved pushes precede the frame pointer (Win64):
        // the saves then live at the frame pointer's positive offsets, so no
        // frame byte below it is reserved for them. See the frame-size note
        // below — subtracting a save area that is not there sizes the allocation
        // short and buries the deepest slots under the stack pointer.
        u32 pool_base = description->saves_precede_frame_pointer ? 0u : 8 * push_count;
        u32 running = pool_base + 8 * pool_size;
        // Sixty-four-byte vector homes on a sixteen-byte offset boundary,
        // mirroring the canonical frame layout's vector clamp; every access is
        // the unaligned vmovdqu8 either way.
        u32 vector_base = (running + 15u) & ~15u;
        running = vector_pool_size ? vector_base + 64u * vector_pool_size : running;
        for (u32 register_index = 0; register_index < function->virtual_register_count; register_index += 1)
        {
            bool is_vector = function->virtual_registers[register_index].register_class == MACHINE_REGISTER_CLASS_VECTOR;
            placement.virtual_register_offsets[register_index] = 0;
            if (!slot_needed[register_index])
            {
                continue;
            }
            if (pool_indices[register_index] != UINT32_MAX)
            {
                placement.virtual_register_offsets[register_index] = is_vector ? vector_base + 64u * (pool_indices[register_index] + 1u)
                                                                               : pool_base + 8u * (pool_indices[register_index] + 1u);
                continue;
            }
            // A home the colorer never saw — no memory edit gave it a range —
            // still gets a slot of its own so the layout stays sound.
            running = is_vector ? ((running + 15u) & ~15u) + 64u : running + 8u;
            placement.virtual_register_offsets[register_index] = running;
        }
        for (u32 group = 0; group < group_count; group += 1)
        {
            running = (running + group_sizes[group] + group_alignments[group] - 1) & ~(group_alignments[group] - 1);
            group_offsets[group] = running;
        }
        for (u32 slot_index = 0; slot_index < function->stack_slot_count; slot_index += 1)
        {
            // The outgoing argument area is placed at the bottom of the frame
            // below, where a call's stack pointer lands on its base.
            if (function->outgoing_bytes && slot_index == function->outgoing_slot)
            {
                continue;
            }
            // A coalesced slot's storage is its group's, which is already
            // placed and wide and aligned enough for every member.
            if (slot_groups[slot_index] != UINT32_MAX)
            {
                placement.stack_slot_offsets[slot_index] = group_offsets[slot_groups[slot_index]];
                continue;
            }
            u32 slot_alignment = function->stack_slot_alignments ? function->stack_slot_alignments[slot_index] : 8;
            running = (running + function->stack_slot_sizes[slot_index] + slot_alignment - 1) & ~(slot_alignment - 1);
            placement.stack_slot_offsets[slot_index] = running;
        }
        u64 edge_copy_temporary_size = machine_function_edge_copy_temporary_size(function);
        if (edge_copy_temporary_size > UINT32_MAX - running)
        {
            return placement;
        }
        placement.edge_copy_temporary_offset = running;
        running += (u32)edge_copy_temporary_size;
        placement.frame_size = ((running - pool_base + 15u) & ~15u) + ((push_count & 1u) ? 8u : 0u) + function->outgoing_bytes;
        if (function->outgoing_bytes)
        {
            placement.stack_slot_offsets[function->outgoing_slot] = placement.frame_size;
        }
        // The deepest offset handed out must sit inside the allocation plus the
        // save area that really lies below the frame pointer; see the same guard
        // in machine_stack_placement_build. An invalid placement falls back to the
        // canonical emitter, which is always sound.
        if (running <= placement.frame_size + pool_base)
        {
            // See machine_stack_placement_build: the saves the Win64 prologue pushes
            // before the frame pointer lie between it and the incoming arguments.
            placement.incoming_base = description->saves_precede_frame_pointer ? 8u * push_count : 0u;
            placement.valid = true;
        }
    }

    return placement;
}

BUSTER_GLOBAL_LOCAL MachineStackPlacement machine_fast_placement_build_core(Arena* arena, MachineFunction* function)
{
    return machine_fast_placement_build_pinned(arena, function, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}
