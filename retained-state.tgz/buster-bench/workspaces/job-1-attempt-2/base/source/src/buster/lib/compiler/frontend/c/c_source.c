// Source loading, lexing, and preprocessing — the first stage of the
// frontend, entered through c_preprocess near the bottom of the file. It
// turns a root file into the flat CToken stream every later stage walks:
// translation (line splices and carriage returns folded out), lexing,
// directive handling, include resolution (real files and the builtin
// resource headers), macro expansion, and the source metrics behind the
// SOURCE table. c_prewarm at the bottom fills the lazily built tables on
// one thread before any parallel phase reads them (AGENTS.md).
//
// Layout, in file order; each anchor is a definition to search for:
//   c_space_local .. c_space_retoken           spelling spaces: append-only
//                                              storage token spellings point
//                                              into
//   c_source_map_append, c_source_map_sort,    location checkpoints (see
//   c_lex_token_location                       CTranslatedSource below)
//   c_identifier_start ..                      character classes and the
//   c_literal_plain_run_end                    prewarmed run tables
//   c_translate_source                         phase-1/2 translation with
//                                              SWAR/AVX-512/scalar variants
//                                              kept in differential agreement
//   c_source_metrics_add,                      the SOURCE table counters and
//   c_source_metrics_file_row                  the per-file attribution rows
//   c_lex_validate_word_utf8                   bounded word encoding checks
//   c_lex_scan_one, c_lex_scalar               the scalar lexer
//   c_lex_compact_tables_build,                the SIMD lexer (Validark
//   c_lex_compact                              method, AGENTS.md): one
//                                              window-wide class lookup
//                                              (c_lex_byte_classes, authored
//                                              from the scalar predicates
//                                              above), the punctuator NFA and
//                                              spelling tables, then the
//                                              interleaved 16-row emitter;
//                                              c_lex dispatches and
//                                              c_lex_reference is the
//                                              differential baseline
//   CTokenStream, c_token_stream_reserve       final token rows plus the
//                                              one-byte kind|punctuator
//                                              sidecar consumed by parser
//                                              shape walks
//   c_macro_name_hash .. c_symbol_intern       macro and symbol tables
//   c_macro_expansion_tasks_reserve ..         shared LIFO task batches,
//   c_preprocess_expand                        arguments, stringify, paste,
//                                              direct plain production
//                                              (c_macro_produce_plain_tasks),
//                                              rescan and context floors
//   CPpClassMasks, c_pp_class_masks_build,     the per-64-token class
//   c_pp_line_end_masked,                      projection of a lexed run's
//   c_pp_parenthesis_depth                     shape sidecar, and what the
//                                              driver's per-line scans read
//                                              instead of walking token rows
//   c_conditional_* ,                          #if evaluation including
//   c_integer_expression_evaluate              __has_* feature tests
//   c_preprocess_pragma_*                      pragmas: once, pack, push/pop
//   c_include_read .. c_include_name           include resolution and the
//                                              builtin resource headers
//   CIncludeGuardState, CIncludeFileTable      shared #import, #pragma once,
//                                              and #ifndef guard identity
//   c_preprocess_command_operations,           ordered command-line macro
//   c_preprocess_define_directive              operations and shared #define
//                                              parsing
//   c_preprocess                               the stage driver
//   c_prewarm                                  serial table prewarm

#include "c_internal.h"
#include <buster/lib/compiler/frontend/c/c_source_internal.h>
#include <buster/lib/compiler/frontend/c/c_source_metrics_internal.h>

// Locations are recorded as checkpoints instead of one entry per translated
// byte: within a run the original offset and the column both advance one per
// output byte and the line is constant, so a checkpoint is needed only where
// that linearity breaks — the byte after a newline and the byte after a line
// splice. This is what keeps the lexer from writing a location for every
// byte of every include it translates, and what lets tokens drop their eager
// location entirely: a token's line/column recover on demand from its offset
// through these checkpoints.
typedef struct CTranslatedSource CTranslatedSource;
struct CTranslatedSource
{
    String8 source;
    IrSourceCheckpoint* checkpoints;
    u32* checkpoint_offsets;
    u32* checkpoint_pages;
    u32 checkpoint_page_count;
    u32 checkpoint_count;
    // Spelling-space offset of source.pointer (0 without a space).
    u32 translated_offset;
    // Physical lines of the untranslated file, spliced ones included. The
    // line counter the checkpoints already need makes this free.
    u32 raw_lines;
};

// The single contiguous byte space every token offset of one preprocess run
// points into. All spelling bytes — the prelude, every translated include,
// and every synthesized spelling (stringify, paste, builtins, expansion
// copies) — are bump-allocated here so a spelling is always
// `base + token.offset`, one add on the hot paths. The block is carved from
// the caller's arena once; untouched tail pages never commit, so oversizing
// costs address space only.
BUSTER_C_INTERNAL char8* c_space_allocate(CSpellingSpace* space, u64 size)
{
    if (space->arena)
    {
        char8* result = (char8*)arena_allocate_bytes(space->arena, size, 1);
        space->used = (u64)(result - space->base) + size;
        BUSTER_VALIDATE(space->used <= UINT32_MAX);
        return result;
    }
    BUSTER_VALIDATE(space->used + size <= space->capacity);
    char8* result = space->base + space->used;
    space->used += size;
    return result;
}
// Hand back the tail of the space's most recent allocation.
BUSTER_C_INTERNAL void c_space_shrink(CSpellingSpace* space, u64 size)
{
    space->used -= size;
    if (space->arena)
    {
        arena_set_position(space->arena, space->arena->position - size);
    }
}

BUSTER_C_INTERNAL u32 c_space_offset(CSpellingSpace const* space, char8 const* pointer)
{
    return (u32)(pointer - space->base);
}

// Exact byte length of the literal spelling starting at `spelling`:
// optional encoding prefix, opening delimiter, escape-aware body, closing
// delimiter. The body loop mirrors the lexer's literal scan byte for byte —
// escape pairs skip two — so a spelling the lexer closed re-measures to the
// same length. `limit` bounds the scan for creation-time validation of a
// possibly unterminated spelling; a validated spelling passes UINT64_MAX
// because its closing delimiter, the spelling's own last byte, stops the
// scan. Returns 0 when no delimiter opens at the start.
BUSTER_C_INTERNAL u64 c_token_literal_scan_length(char8 const* spelling, u64 limit)
{
    u64 cursor = 0;
    char8 delimiter = 0;
    if (limit && (spelling[0] == '"' || spelling[0] == '\''))
    {
        delimiter = spelling[0];
        cursor = 1;
    }
    else if (limit >= 3 && spelling[0] == 'u' && spelling[1] == '8' && (spelling[2] == '"' || spelling[2] == '\''))
    {
        delimiter = spelling[2];
        cursor = 3;
    }
    else if (limit >= 2 && (spelling[0] == 'u' || spelling[0] == 'U' || spelling[0] == 'L') && (spelling[1] == '"' || spelling[1] == '\''))
    {
        delimiter = spelling[1];
        cursor = 2;
    }
    else
    {
        return 0;
    }
    while (cursor < limit)
    {
        char8 character = spelling[cursor];
        if (character == delimiter)
        {
            return cursor + 1;
        }
        cursor += character == '\\' && cursor + 1 < limit ? 2 : 1;
    }
    return 0;
}

// The cold half of c_token_length: the field carries the sentinel, so the
// exact length is re-derived from the spelling. Creation only ever stores
// the sentinel for terminated string and character literals (see CToken).
u64 c_token_length_oversized(char8 const* spelling_base, CToken token)
{
    BUSTER_CHECK(token.kind == C_TOKEN_STRING_LITERAL || token.kind == C_TOKEN_CHARACTER_LITERAL);
    u64 length = c_token_literal_scan_length(spelling_base + token.offset, UINT64_MAX);
    BUSTER_CHECK(length >= C_TOKEN_LENGTH_OVERSIZED);
    return length;
}

// The u16 the length field stores for a spelling of `length` bytes. The
// caller owns the sentinel invariant: a spelling at or past the sentinel
// must be a terminated literal, or must be diagnosed and clamped instead.
BUSTER_C_SHARED u16 c_token_length_field(u64 length)
{
    return length < C_TOKEN_LENGTH_OVERSIZED ? (u16)length : C_TOKEN_LENGTH_OVERSIZED;
}

// A token whose spelling is a fresh copy of `text` in the space; used for
// the preprocessor's built-in macro definitions, whose replacement spellings
// must resolve through the shared base like any lexed token.
BUSTER_C_SHARED CToken c_space_token(CSpellingSpace* space, String8 text, CTokenKind kind, CPunctuator punctuator)
{
    // The sentinel is only valid on terminated literals; no other caller
    // synthesizes a spelling anywhere near it.
    BUSTER_CHECK(text.length < C_TOKEN_LENGTH_OVERSIZED || kind == C_TOKEN_STRING_LITERAL || kind == C_TOKEN_CHARACTER_LITERAL);
    char8* copy = c_space_allocate(space, text.length);
    if (text.length)
    {
        memcpy(copy, text.pointer, text.length);
    }
    return (CToken){
        .offset = c_space_offset(space, copy),
        .length = c_token_length_field(text.length),
        .kind = (u8)kind,
        .punctuator = (u8)punctuator,
    };
}

// Copy a token's spelling from another base into this space, keeping every
// other field; parse-side evaluators that mix real tokens with synthesized
// ones rebase everything into one local space this way.
BUSTER_C_SHARED CToken c_space_retoken(CSpellingSpace* space, char8 const* from_base, CToken token)
{
    String8 spelling = c_token_spelling(from_base, token);
    char8* copy = c_space_allocate(space, spelling.length);
    if (spelling.length)
    {
        memcpy(copy, spelling.pointer, spelling.length);
    }
    token.offset = c_space_offset(space, copy);
    return token;
}

// A transient prelude-seeded spelling space for parse-side expression
// evaluation over synthesized tokens.
BUSTER_C_SHARED CSpellingSpace c_space_local(Arena* arena, u64 capacity)
{
    CSpellingSpace space = {
        .capacity = capacity + C_SPELLING_PRELUDE_LENGTH,
    };
    space.base = arena_allocate(arena, char8, space.capacity);
    memcpy(c_space_allocate(&space, C_SPELLING_PRELUDE_LENGTH), C_SPELLING_PRELUDE_TEXT, C_SPELLING_PRELUDE_LENGTH);
    return space;
}

// The source map under construction: append-only while preprocessing runs
// (nothing queries it until the result is assembled), sorted once at the
// end. #line splits may append below any number of previously emitted
// regions; finalization must preserve ties without depending on displacement.
typedef struct CSourceMap CSourceMap;
typedef struct CSourceRegionNames CSourceRegionNames;
struct CSourceRegionNames
{
    String8 physical;
    String8 logical;
};

struct CSourceMap
{
    Arena* arena;
    IrSourceRegion* regions;
    u32 count;
    u32 capacity;
    CSourceRegionNames* names;
    u32 name_count;
    u32 name_capacity;
};

BUSTER_C_INTERNAL void c_source_map_append(CSourceMap* map, IrSourceRegion region)
{
    if (map->count == map->capacity)
    {
        u32 capacity = map->capacity ? map->capacity * 2 : 256;
        IrSourceRegion* regions = arena_allocate(map->arena, IrSourceRegion, capacity);
        if (map->count)
        {
            memcpy(regions, map->regions, sizeof(*regions) * map->count);
        }
        map->regions = regions;
        map->capacity = capacity;
    }
    map->regions[map->count++] = region;
}

// Stable LSD radix sorting bounds finalization independently of append order.
// The ordered path only reads keys. Unordered maps use one temporary row
// buffer; four byte passes finish in the original array before scratch rewind.
BUSTER_C_INTERNAL void c_source_map_sort(Arena* arena, IrSourceRegion* regions, u32 count)
{
    u32 ordered = 1;
    while (ordered < count && regions[ordered - 1].start <= regions[ordered].start)
    {
        ordered += 1;
    }
    if (ordered < count)
    {
        TemporalArena temporary = arena_begin_temporal(arena);
        IrSourceRegion* source = regions;
        IrSourceRegion* destination = arena_allocate(arena, IrSourceRegion, count);
        enum { C_SOURCE_MAP_RADIX_BITS = 8, C_SOURCE_MAP_RADIX_BUCKETS = 1 << C_SOURCE_MAP_RADIX_BITS };
        for (u32 byte_index = 0; byte_index < sizeof(regions->start); byte_index += 1)
        {
            u32 offsets[C_SOURCE_MAP_RADIX_BUCKETS] = {0};
            u32 shift = byte_index * C_SOURCE_MAP_RADIX_BITS;
            for (u32 index = 0; index < count; index += 1)
            {
                u32 bucket = (source[index].start >> shift) & (C_SOURCE_MAP_RADIX_BUCKETS - 1);
                offsets[bucket] += 1;
            }
            u32 offset = 0;
            for (u32 bucket = 0; bucket < C_SOURCE_MAP_RADIX_BUCKETS; bucket += 1)
            {
                u32 population = offsets[bucket];
                offsets[bucket] = offset;
                offset += population;
            }
            // Forward scatter retains append order among equal start keys.
            for (u32 index = 0; index < count; index += 1)
            {
                u32 bucket = (source[index].start >> shift) & (C_SOURCE_MAP_RADIX_BUCKETS - 1);
                destination[offsets[bucket]++] = source[index];
            }
            IrSourceRegion* swap = source;
            source = destination;
            destination = swap;
        }
        scratch_end(temporary);
    }
}

#if BUSTER_INCLUDE_TESTS
void c_test_source_map_sort(Arena* arena, IrSourceRegion* regions, u32 count)
{
    c_source_map_sort(arena, regions, count);
}
#endif

// TEXT origins temporarily index these names. Finalization registers physical
// source IDs only for token-bearing or diagnosed regions, preserving the
// self-host rule that unused host-resource headers never enter the file table.
BUSTER_C_INTERNAL void c_source_map_name(CSourceMap* map, String8 physical, String8 logical)
{
    if (map->name_count == map->name_capacity)
    {
        u32 capacity = map->name_capacity ? map->name_capacity * 2 : 8;
        CSourceRegionNames* names = arena_allocate(map->arena, CSourceRegionNames, capacity);
        if (map->name_count)
        {
            memcpy(names, map->names, sizeof(*names) * map->name_count);
        }
        map->names = names;
        map->name_capacity = capacity;
    }
    map->names[map->name_count++] = (CSourceRegionNames){.physical = physical, .logical = logical};
    map->regions[map->count - 1].origin_plus_one = map->name_count;
}

// Hand the finished regions to the map every lookup reads, deriving the key
// array the region search and the source query run on. A trailing sentinel
// key ends the space, so a containment check needs no bounds test.
BUSTER_C_INTERNAL void c_source_map_publish(Arena* arena, CSourceMapRecovery* recovery, CSourceMap const* map)
{
    if (!map->count)
    {
        // A published key array always has a region to answer with, so the
        // lookups test the array alone and never a count as well.
        return;
    }
    IrSourceRegionKey* keys = arena_allocate(arena, IrSourceRegionKey, map->count + 1);
    for (u32 index = 0; index < map->count; index += 1)
    {
        keys[index] = (IrSourceRegionKey){
            .start = map->regions[index].start,
            .source = map->regions[index].source,
        };
    }
    keys[map->count] = (IrSourceRegionKey){.start = UINT32_MAX};
    recovery->map.keys = keys;
    recovery->map.regions = map->regions;
    recovery->map.count = map->count;
    recovery->capacity = map->capacity;
}

// Only the append-only C23 respell phase may use this boundary: equal counts
// there mean every existing key and its sentinel are still final. This is not
// a general mutation cache. Keep published storage alive in the TU arena;
// canonical lowering copies its pointers for later diagnostics and debug info.
BUSTER_C_INTERNAL void c_source_map_publish_appended(Arena* arena, CSourceMapRecovery* recovery, CSourceMap const* map)
{
    if (map->count != recovery->map.count)
    {
        c_source_map_publish(arena, recovery, map);
    }
}

#if BUSTER_INCLUDE_TESTS
void c_test_source_map_publish_appended(Arena* arena, CSourceMapRecovery* recovery, IrSourceRegion* regions, u32 count, u32 capacity)
{
    CSourceMap map = {.arena = arena, .regions = regions, .count = count, .capacity = capacity};
    c_source_map_publish_appended(arena, recovery, &map);
}
#endif

BUSTER_C_SHARED bool c_ir_decode_character_value(Arena* arena, char8 const* spelling_base, CToken token, Target target, u64* value_out, CTypeKind* kind_out);

BUSTER_C_SHARED bool c_preprocess_dialect_is_c23(CPreprocessDialect dialect);

BUSTER_C_INTERNAL bool c_ascii_alpha(char8 character)
{
    return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z');
}

BUSTER_C_INTERNAL bool c_ascii_digit(char8 character)
{
    return character >= '0' && character <= '9';
}

BUSTER_C_INTERNAL bool c_identifier_start(char8 character)
{
    return c_ascii_alpha(character) || character == '_' || character == '$' || character >= 0x80;
}

BUSTER_C_INTERNAL bool c_identifier_continue(char8 character)
{
    return c_identifier_start(character) || c_ascii_digit(character);
}

// One byte per character value: nonzero for an ASCII identifier continuation.
// High bytes stop the fast run for bounded UTF-8 validation in the lexer;
// the identifier run scan ANDs eight entries per step
// instead of branching per byte. c_prewarm() fills it ahead of any gang.
BUSTER_C_INTERNAL u8 c_identifier_continue_table[256];
BUSTER_C_INTERNAL bool c_identifier_continue_table_built;

BUSTER_C_INTERNAL void c_identifier_continue_table_build(void)
{
    BUSTER_CHECK_SERIAL_INITIALIZATION();
    for (u32 character = 0; character < 256; character += 1)
    {
        c_identifier_continue_table[character] = character < 0x80 && c_identifier_continue((char8)character) ? 1 : 0;
    }
    c_identifier_continue_table_built = true;
}

BUSTER_C_INTERNAL u64 c_identifier_run_end(String8 source, u64 offset)
{
    if (!c_identifier_continue_table_built)
    {
        c_identifier_continue_table_build();
    }
    const u8* bytes = (const u8*)source.pointer;
    while (offset + 8 <= source.length)
    {
        u8 all = c_identifier_continue_table[bytes[offset]] & c_identifier_continue_table[bytes[offset + 1]] &
                 c_identifier_continue_table[bytes[offset + 2]] & c_identifier_continue_table[bytes[offset + 3]] &
                 c_identifier_continue_table[bytes[offset + 4]] & c_identifier_continue_table[bytes[offset + 5]] &
                 c_identifier_continue_table[bytes[offset + 6]] & c_identifier_continue_table[bytes[offset + 7]];
        if (!all)
        {
            break;
        }
        offset += 8;
    }
    while (offset < source.length && c_identifier_continue_table[bytes[offset]])
    {
        offset += 1;
    }
    return offset;
}

// One byte per character value: 1 when the byte cannot end or escape a
// character/string literal (either quote kind, backslash, newline), so the
// literal scan ANDs eight entries per step like the identifier run.
BUSTER_C_INTERNAL u8 c_literal_plain_table[256];
BUSTER_C_INTERNAL bool c_literal_plain_table_built;

BUSTER_C_INTERNAL void c_literal_plain_table_build(void)
{
    BUSTER_CHECK_SERIAL_INITIALIZATION();
    for (u32 character = 0; character < 256; character += 1)
    {
        bool special = character == '"' || character == '\'' || character == '\\' || character == '\n';
        c_literal_plain_table[character] = special ? 0 : 1;
    }
    c_literal_plain_table_built = true;
}

BUSTER_C_INTERNAL u64 c_literal_plain_run_end(String8 source, u64 offset)
{
    if (!c_literal_plain_table_built)
    {
        c_literal_plain_table_build();
    }
    const u8* bytes = (const u8*)source.pointer;
    while (offset + 8 <= source.length)
    {
        u8 all = c_literal_plain_table[bytes[offset]] & c_literal_plain_table[bytes[offset + 1]] &
                 c_literal_plain_table[bytes[offset + 2]] & c_literal_plain_table[bytes[offset + 3]] &
                 c_literal_plain_table[bytes[offset + 4]] & c_literal_plain_table[bytes[offset + 5]] &
                 c_literal_plain_table[bytes[offset + 6]] & c_literal_plain_table[bytes[offset + 7]];
        if (!all)
        {
            break;
        }
        offset += 8;
    }
    while (offset < source.length && c_literal_plain_table[bytes[offset]])
    {
        offset += 1;
    }
    return offset;
}

BUSTER_C_INTERNAL bool c_horizontal_whitespace(char8 character)
{
    switch (character)
    {
    case ' ':
    case '\t':
    case '\v':
    case '\f':
    {
        return true;
    }
    default:
    {
        return false;
    }
    }
}

BUSTER_C_INLINE BUSTER_ALWAYS_INLINE u64 c_translate_plain_run_end_swar(String8 source, u64 offset)
{
    while (offset + 8 <= source.length)
    {
        u64 word;
        memcpy(&word, source.pointer + offset, sizeof(word));
        u64 carriage = word ^ UINT64_C(0x0D0D0D0D0D0D0D0D);
        u64 newline = word ^ UINT64_C(0x0A0A0A0A0A0A0A0A);
        u64 backslash = word ^ UINT64_C(0x5C5C5C5C5C5C5C5C);
        u64 low = UINT64_C(0x0101010101010101);
        u64 high = UINT64_C(0x8080808080808080);
        u64 found = (((carriage - low) & ~carriage) | ((newline - low) & ~newline) | ((backslash - low) & ~backslash)) & high;
        if (found)
        {
            break;
        }
        offset += 8;
    }
    while (offset < source.length)
    {
        char8 probe = source.pointer[offset];
        if (probe == '\r' || probe == '\n' || probe == '\\')
        {
            break;
        }
        offset += 1;
    }
    return offset;
}

#if BUSTER_C_TRANSLATE_AVX512
BUSTER_C_INTERNAL u64 c_translate_plain_run_end_avx512(String8 source, u64 offset)
{
    Simd512 carriage_return = simd512_splat('\r');
    Simd512 line_feed = simd512_splat('\n');
    Simd512 backslash = simd512_splat('\\');
    bool stopped = false;
    while (!stopped && source.length - offset >= 64)
    {
        Simd512 chunk = simd512_load(source.pointer + offset);
        Mask64 stop_mask = simd512_equal_byte(chunk, carriage_return) | simd512_equal_byte(chunk, line_feed) |
                           simd512_equal_byte(chunk, backslash);
        if (stop_mask)
        {
            offset += mask64_first_set(stop_mask);
            stopped = true;
        }
        else
        {
            offset += 64;
        }
    }
    if (!stopped)
    {
        offset = c_translate_plain_run_end_swar(source, offset);
    }
    return offset;
}
#endif

#if BUSTER_INCLUDE_TESTS
bool c_test_space_null_empty_tokens(Arena* arena)
{
    CSpellingSpace space = c_space_local(arena, 1);
    CToken token = c_space_token(&space, (String8){0}, C_TOKEN_END_OF_FILE, (CPunctuator)0);
    CToken copied = c_space_retoken(&space, space.base, token);
    return !token.length && !copied.length && token.offset == copied.offset;
}

BUSTER_C_INTERNAL u64 c_translate_plain_run_end_scalar(String8 source, u64 offset)
{
    while (offset < source.length)
    {
        char8 probe = source.pointer[offset];
        if (probe == '\r' || probe == '\n' || probe == '\\')
        {
            break;
        }
        offset += 1;
    }
    return offset;
}

bool c_test_translate_plain_run_paths_agree(String8 source)
{
    if (source.length && !source.pointer)
    {
        return false;
    }
    u64 offset = 0;
    for (;;)
    {
        u64 scalar_end = c_translate_plain_run_end_scalar(source, offset);
        if (c_translate_plain_run_end_swar(source, offset) != scalar_end)
        {
            return false;
        }
#if BUSTER_C_TRANSLATE_AVX512
        if (c_translate_plain_run_end_avx512(source, offset) != scalar_end)
        {
            return false;
        }
#endif
        if (offset == source.length)
        {
            break;
        }
        offset += 1;
    }
    return true;
}
#endif

// force_scalar keeps the byte-at-a-time run loop as the whole implementation,
// which is what c_lex_reference lexes through so the differential gate
// compares the chunk fast path against it.
BUSTER_C_INTERNAL CTranslatedSource c_translate_source(Arena* arena, CSpellingSpace* space, String8 source, bool force_scalar)
{
    CTranslatedSource result = {0};
    if (source.length <= UINT32_MAX - 2)
    {
        char8* translated = space ? c_space_allocate(space, source.length + 1) : arena_allocate(arena, char8, source.length + 1);
        result.translated_offset = space ? c_space_offset(space, translated) : 0;
        IrSourceCheckpoint* checkpoints = arena_allocate(arena, IrSourceCheckpoint, source.length + 2);
        u32* checkpoint_offsets = arena_allocate(arena, u32, source.length + 2);
        u32 checkpoint_count = 0;
        u64 input = 0;
        u64 output = 0;
        u32 line = 1;
        u32 column = 1;
        // The next output byte starts a new linear run; initially true so the
        // first byte records the first checkpoint.
        bool run_broken = true;
        while (input < source.length)
        {
#if BUSTER_C_TRANSLATE_AVX512
            // Chunk fast path: a plain newline copies through unchanged, so a
            // 64-byte chunk whose only stop bytes are newlines needs no
            // per-run rescan -- the chunk stores whole, the newline mask
            // yields one checkpoint per line start, and line/column advance
            // by popcount and top-bit arithmetic.  Only the bytes that edit
            // the stream fall to the exact scalar handling below, at their
            // own position: every '\r' (folds to '\n'), a backslash whose
            // next byte opens a splice, and a backslash on the last lane,
            // whose next byte the chunk cannot see.
            if (!force_scalar)
            {
                while (source.length - input >= 64)
                {
                    Simd512 chunk = simd512_load(source.pointer + input);
                    Mask64 carriage = simd512_equal_byte(chunk, simd512_splat('\r'));
                    Mask64 line_feed = simd512_equal_byte(chunk, simd512_splat('\n'));
                    Mask64 backslash = simd512_equal_byte(chunk, simd512_splat('\\'));
                    u64 stops = carriage | (backslash & ((line_feed | carriage) >> 1)) | (backslash & (UINT64_C(1) << 63));
                    u64 limit = stops ? (u64)__builtin_ctzll(stops) : 64;
                    if (!limit)
                    {
                        break;
                    }
                    u64 newlines = line_feed & (limit >= 64 ? ~UINT64_C(0) : ((UINT64_C(1) << limit) - 1));
                    simd512_store(translated + output, chunk);
                    if (run_broken)
                    {
                        checkpoints[checkpoint_count] = (IrSourceCheckpoint){
                            .offset = (u32)input,
                            .line = line,
                            .column = column,
                        };
                        checkpoint_offsets[checkpoint_count] = (u32)output;
                        checkpoint_count += 1;
                        run_broken = false;
                    }
                    if (newlines)
                    {
                        column = (u32)(limit - (u64)(63 - __builtin_clzll(newlines)));
                        for (u64 rest = newlines; rest; rest &= rest - 1)
                        {
                            u64 position = (u64)__builtin_ctzll(rest);
                            line += 1;
                            // The byte after this newline starts a line; when
                            // it sits past the limit, the next iteration or
                            // the stop byte's own handling records it, which
                            // is what keeps a splice's skipped backslash from
                            // acquiring a checkpoint here.
                            if (position + 1 < limit)
                            {
                                checkpoints[checkpoint_count] = (IrSourceCheckpoint){
                                    .offset = (u32)(input + position + 1),
                                    .line = line,
                                    .column = 1,
                                };
                                checkpoint_offsets[checkpoint_count] = (u32)(output + position + 1);
                                checkpoint_count += 1;
                            }
                            else
                            {
                                run_broken = true;
                            }
                        }
                    }
                    else
                    {
                        column += (u32)limit;
                    }
                    input += limit;
                    output += limit;
                    if (limit < 64)
                    {
                        break;
                    }
                }
                if (input >= source.length)
                {
                    break;
                }
            }
#endif
            // A run containing no '\r', '\n', or '\\' keeps line/column linear,
            // so it copies through whole and only those three bytes reach the exact
            // scalar handling below. Native AVX-512 hosts classify 64 bytes at a
            // time; every fallback retains the previous eight-byte SWAR scan.
            u64 plain_end = input;
            if (force_scalar)
            {
                // The reference must not share the vector plain-run scanner with
                // the dispatched path: disabling only the fused loop was weaker.
                while (plain_end < source.length)
                {
                    char8 character = source.pointer[plain_end];
                    if (character == '\r' || character == '\n' || character == '\\')
                    {
                        break;
                    }
                    plain_end += 1;
                }
            }
            else
            {
#if BUSTER_C_TRANSLATE_AVX512
                plain_end = c_translate_plain_run_end_avx512(source, input);
#else
                plain_end = c_translate_plain_run_end_swar(source, input);
#endif
            }
            if (plain_end > input)
            {
                if (run_broken)
                {
                    checkpoints[checkpoint_count] = (IrSourceCheckpoint){
                        .offset = (u32)input,
                        .line = line,
                        .column = column,
                    };
                    checkpoint_offsets[checkpoint_count] = (u32)output;
                    checkpoint_count += 1;
                    run_broken = false;
                }
                u64 plain_length = plain_end - input;
                memcpy(translated + output, source.pointer + input, plain_length);
                output += plain_length;
                column += (u32)plain_length;
                input = plain_end;
                continue;
            }
            char8 character = source.pointer[input];
            u64 newline_length = 0;
            if (character == '\r')
            {
                newline_length = input + 1 < source.length && source.pointer[input + 1] == '\n' ? 2 : 1;
            }
            else if (character == '\n')
            {
                newline_length = 1;
            }
            if (character == '\\' && input + 1 < source.length)
            {
                u64 splice_length = 0;
                if (source.pointer[input + 1] == '\n')
                {
                    splice_length = 2;
                }
                else if (source.pointer[input + 1] == '\r')
                {
                    splice_length = input + 2 < source.length && source.pointer[input + 2] == '\n' ? 3 : 2;
                }
                if (splice_length)
                {
                    input += splice_length;
                    line += 1;
                    column = 1;
                    run_broken = true;
                    continue;
                }
            }
            if (run_broken)
            {
                checkpoints[checkpoint_count] = (IrSourceCheckpoint){
                    .offset = (u32)input,
                    .line = line,
                    .column = column,
                };
                checkpoint_offsets[checkpoint_count] = (u32)output;
                checkpoint_count += 1;
                run_broken = false;
            }
            if (newline_length)
            {
                translated[output++] = '\n';
                input += newline_length;
                line += 1;
                column = 1;
                run_broken = true;
            }
            else
            {
                translated[output++] = character;
                input += 1;
                column += 1;
            }
        }
        translated[output] = 0;
        checkpoints[checkpoint_count] = (IrSourceCheckpoint){
            .offset = (u32)source.length,
            .line = line,
            .column = column,
        };
        checkpoint_offsets[checkpoint_count] = (u32)output;
        checkpoint_count += 1;
        if (space)
        {
            // The translated copy only shrinks (splices delete bytes); hand the
            // unused tail back so the next spelling packs against it.
            c_space_shrink(space, source.length - output);
        }
        result.source = (String8){
            .pointer = translated,
            .length = output,
        };
        result.checkpoints = checkpoints;
        result.checkpoint_offsets = checkpoint_offsets;
        result.checkpoint_count = checkpoint_count;
        // The page bracket for the checkpoints, built in the one linear pass the
        // finished offsets allow. It is what keeps a line-table consumer's
        // per-line lookup from binary-searching the whole file.
        result.checkpoint_page_count = (u32)(output >> IR_SOURCE_CHECKPOINT_PAGE_SHIFT) + 1;
        result.checkpoint_pages = arena_allocate(arena, u32, result.checkpoint_page_count);
        u32 fill_checkpoint = 0;
        for (u32 page = 0; page < result.checkpoint_page_count; page += 1)
        {
            u32 page_start = page << IR_SOURCE_CHECKPOINT_PAGE_SHIFT;
            while (fill_checkpoint + 1 < checkpoint_count && checkpoint_offsets[fill_checkpoint + 1] <= page_start)
            {
                fill_checkpoint += 1;
            }
            result.checkpoint_pages[page] = fill_checkpoint;
        }
        // `line` counts breaks, so it is one past the lines that ended; a column
        // past the first means bytes followed the last break and opened one more.
        result.raw_lines = line - 1 + (column > 1);
    }

    return result;
}

// Line/column recovery for a translated-source-local offset through the
// retained checkpoints, amortized by the result's cursor: queries at
// non-decreasing offsets advance instead of searching.
BUSTER_C_INTERNAL CSourceLocation c_lex_local_location(CLexResult* result, u64 offset)
{
    if (!result->checkpoint_count)
    {
        return (CSourceLocation){0};
    }
    u32 cursor = result->location_cursor;
    while (cursor + 1 < result->checkpoint_count && result->checkpoint_offsets[cursor + 1] <= offset)
    {
        cursor += 1;
    }
    while (cursor && result->checkpoint_offsets[cursor] > offset)
    {
        cursor -= 1;
    }
    result->location_cursor = cursor;
    IrSourceCheckpoint checkpoint = result->checkpoints[cursor];
    u32 delta = (u32)offset - result->checkpoint_offsets[cursor];
    return (CSourceLocation){
        .offset = checkpoint.offset + delta,
        .line = checkpoint.line,
        .column = checkpoint.column + delta,
        .map_offset = (u32)offset + result->translated_offset,
    };
}

CSourceLocation c_lex_token_location(CLexResult* lex, CToken token)
{
    return c_lex_local_location(lex, token.offset - lex->translated_offset);
}

// The stamp a macro invocation's output carries: one position every offset
// in the copied run resolves to.
BUSTER_C_INTERNAL IrSourcePosition c_position_from_source_location(CSourceLocation location)
{
    return (IrSourcePosition){
        .source = location.file,
        .offset = location.offset,
        .line = location.line,
        .column = location.column,
    };
}

// A position, in the shape this frontend's diagnostics take.
BUSTER_C_INTERNAL CSourceLocation c_source_location_from_position(u32 map_offset, IrSourcePosition position)
{
    return (CSourceLocation){
        .offset = position.offset,
        .line = position.line,
        .column = position.column,
        .file = position.source,
        .map_offset = map_offset,
    };
}

CSourceLocation c_preprocess_token_location(CPreprocessResult const* preprocess, CToken token)
{
    CSourceMapRecovery const* recovery = preprocess->recovery;
    return c_source_location_from_position(token.offset, recovery ? ir_source_map_position(&recovery->map, token.offset, 0) : (IrSourcePosition){0});
}

// The amortized variant for consumers whose queries mostly ascend (parsing
// walks tokens roughly in stream order).
BUSTER_C_SHARED CSourceLocation c_preprocess_token_location_cursor(CPreprocessResult const* preprocess, CToken token, IrSourceMapCursor* cursor)
{
    CSourceMapRecovery const* recovery = preprocess->recovery;
    return c_source_location_from_position(token.offset,
                                           recovery ? ir_source_map_position(&recovery->map, token.offset, cursor) : (IrSourcePosition){0});
}

// Which source a token belongs to, without recovering its line and column:
// what lowering wants, since an IR source range is a source plus the offset
// the token already carries.
BUSTER_C_SHARED u32 c_preprocess_token_source(CPreprocessResult const* preprocess, CToken token, IrSourceMapCursor* cursor)
{
    CSourceMapRecovery const* recovery = preprocess->recovery;
    return recovery ? ir_source_map_source(&recovery->map, token.offset, cursor) : 0;
}

// One finished line, classified by what the lexer saw on it. Branchless: the
// flags are 0/1 and every bucket is an unconditional add, so a line of code,
// a line of comment and a blank line all cost the same four adds.
BUSTER_C_INTERNAL void c_source_metrics_line(CSourceMetrics* metrics, u32 has_code, u32 has_comment)
{
    metrics->translated_lines += 1;
    metrics->code_lines += has_code;
    metrics->comment_lines += has_comment;
    metrics->mixed_lines += has_code & has_comment;
    metrics->blank_lines += (has_code | has_comment) ^ 1;
}

void c_source_metrics_add(CSourceMetrics* total, CSourceMetrics const* part)
{
    total->files += part->files;
    total->bytes += part->bytes;
    total->translated_bytes += part->translated_bytes;
    total->lines += part->lines;
    total->translated_lines += part->translated_lines;
    total->spliced_lines += part->spliced_lines;
    total->code_lines += part->code_lines;
    total->comment_lines += part->comment_lines;
    total->mixed_lines += part->mixed_lines;
    total->blank_lines += part->blank_lines;
    total->comment_bytes += part->comment_bytes;
    total->blank_bytes += part->blank_bytes;
    total->literal_bytes += part->literal_bytes;
    total->comments += part->comments;
    total->tokens += part->tokens;
}

u64 c_source_metrics_code_bytes(CSourceMetrics metrics)
{
    return metrics.translated_bytes - metrics.comment_bytes - metrics.blank_bytes;
}

// The row index for `path`, appending a fresh zero-count row the first time
// the path is seen; a first sight is `rows[result].lex_count == 0`.
BUSTER_C_INTERNAL u32 c_source_metrics_file_row_hashed(Arena* arena, CSourceMetricsFileSet* set, String8 path, u64 hash)
{
    if (set->count * 2 >= set->capacity)
    {
        u32 capacity = set->capacity ? set->capacity * 2 : 256;
        u64* hashes = arena_allocate(arena, u64, capacity);
        u32* slot_rows = arena_allocate(arena, u32, capacity);
        memset(hashes, 0, capacity * sizeof(*hashes));
        for (u32 index = 0; index < set->capacity; index += 1)
        {
            u64 moved = set->hashes[index];
            if (moved)
            {
                u32 slot = (u32)moved & (capacity - 1);
                while (hashes[slot])
                {
                    slot = (slot + 1) & (capacity - 1);
                }
                hashes[slot] = moved;
                slot_rows[slot] = set->slot_rows[index];
            }
        }
        set->hashes = hashes;
        set->slot_rows = slot_rows;
        set->capacity = capacity;
    }
    // Zero marks an empty slot, so no path may hash to it.
    hash |= 1;
    u32 slot = (u32)hash & (set->capacity - 1);
    bool found = false;
    while (set->hashes[slot] && !found)
    {
        found = set->hashes[slot] == hash;
        if (found)
        {
            String8 stored_path = set->rows[set->slot_rows[slot]].path;
            found = stored_path.length == path.length &&
                    (!path.length || memcmp(stored_path.pointer, path.pointer, path.length) == 0);
        }
        slot = found ? slot : (slot + 1) & (set->capacity - 1);
    }
    u32 result;
    if (found)
    {
        result = set->slot_rows[slot];
    }
    else
    {
        if (set->count == set->row_capacity)
        {
            u32 row_capacity = set->row_capacity ? set->row_capacity * 2 : 128;
            CSourceFileMetrics* rows = arena_allocate(arena, CSourceFileMetrics, row_capacity);
            if (set->count)
            {
                memcpy(rows, set->rows, set->count * sizeof(*rows));
            }
            set->rows = rows;
            set->row_capacity = row_capacity;
        }
        result = set->count;
        set->rows[result] = (CSourceFileMetrics){.path = path};
        set->hashes[slot] = hash;
        set->slot_rows[slot] = result;
        set->count += 1;
    }

    return result;
}

BUSTER_C_INTERNAL u32 c_source_metrics_file_row(Arena* arena, CSourceMetricsFileSet* set, String8 path)
{
    return c_source_metrics_file_row_hashed(arena, set, path, buster_hash_64((u8*)path.pointer, path.length));
}

#if BUSTER_INCLUDE_TESTS
u32 c_test_source_metrics_file_row(Arena* arena, CSourceMetricsFileSet* set, String8 path, u64 hash)
{
    return c_source_metrics_file_row_hashed(arena, set, path, hash);
}
#endif

// The cold tail of c_token_push: the item is 0xFFFF bytes or longer. A
// terminated literal — the scan bounded by the item's extent reproduces the
// exact length, which certifies both termination and escape parity — stores
// the sentinel c_token_length re-derives from. Everything else (an
// unterminated literal, an identifier or number the call site diagnoses)
// clamps to the largest direct length; the stream already carries an error
// diagnostic in every clamping case, so the lie never reaches a compile
// that succeeds, and a clamped read stays inside the real spelling.
BUSTER_C_INTERNAL u16 c_token_push_long_length(CTranslatedSource translated, u64 start, u64 end, CTokenKind kind)
{
    u64 length = end - start;
    bool literal = kind == C_TOKEN_STRING_LITERAL || kind == C_TOKEN_CHARACTER_LITERAL;
    bool exact = literal && c_token_literal_scan_length(translated.source.pointer + start, length) == length;
    return exact ? C_TOKEN_LENGTH_OVERSIZED : C_TOKEN_LENGTH_OVERSIZED - 1;
}

BUSTER_C_INTERNAL void c_token_push(CLexResult* result, CTranslatedSource translated, u64 start, u64 end, CTokenKind kind, CPunctuator punctuator)
{
    u64 length = end - start;
    u16 stored = length < C_TOKEN_LENGTH_OVERSIZED ? (u16)length : c_token_push_long_length(translated, start, end, kind);
    u64 token_index = result->token_count;
    CToken token = {
        .offset = translated.translated_offset + (u32)start,
        .length = stored,
        .kind = (u8)kind,
        .punctuator = (u8)punctuator,
    };
    result->tokens[token_index] = token;
    if (result->token_shapes)
    {
        result->token_shapes[token_index] = c_token_shape_from_token(token);
    }
    result->token_count = token_index + 1;
}

BUSTER_C_INTERNAL void c_diagnostic_push(CLexResult* result, Arena* diagnostic_arena, u64* diagnostic_capacity, u64 maximum_diagnostic_count,
                                           u64 offset, CDiagnosticKind kind, String8 message)
{
    BUSTER_VALIDATE(result->diagnostic_count < maximum_diagnostic_count);
    if (result->diagnostic_count == *diagnostic_capacity)
    {
        u64 capacity = *diagnostic_capacity > maximum_diagnostic_count / 2 ? maximum_diagnostic_count : *diagnostic_capacity * 2;
        CDiagnostic* diagnostics = arena_allocate(diagnostic_arena, CDiagnostic, capacity);
        memcpy(diagnostics, result->diagnostics, sizeof(*diagnostics) * result->diagnostic_count);
        result->diagnostics = diagnostics;
        *diagnostic_capacity = capacity;
    }
    result->diagnostics[result->diagnostic_count++] = (CDiagnostic){
        .message = message,
        .location = c_lex_local_location(result, offset),
        .kind = kind,
        .severity = C_DIAGNOSTIC_ERROR,
    };
}

// Indexed by CPunctuator, so the id and the spelling cannot drift apart.  The
// scan walks the table in enum order, which CPunctuator declares longest-first
// for maximal munch.
BUSTER_C_INTERNAL String8 const c_punctuator_spellings[C_PUNCTUATOR_COUNT] = {
    [C_PUNCTUATOR_HASH_HASH_DIGRAPH] = S8_INITIALIZER("%:%:"),
    [C_PUNCTUATOR_SHIFT_LEFT_ASSIGN] = S8_INITIALIZER("<<="),
    [C_PUNCTUATOR_SHIFT_RIGHT_ASSIGN] = S8_INITIALIZER(">>="),
    [C_PUNCTUATOR_ELLIPSIS] = S8_INITIALIZER("..."),
    [C_PUNCTUATOR_ARROW] = S8_INITIALIZER("->"),
    [C_PUNCTUATOR_PLUS_PLUS] = S8_INITIALIZER("++"),
    [C_PUNCTUATOR_MINUS_MINUS] = S8_INITIALIZER("--"),
    [C_PUNCTUATOR_SHIFT_LEFT] = S8_INITIALIZER("<<"),
    [C_PUNCTUATOR_SHIFT_RIGHT] = S8_INITIALIZER(">>"),
    [C_PUNCTUATOR_LESS_EQUAL] = S8_INITIALIZER("<="),
    [C_PUNCTUATOR_GREATER_EQUAL] = S8_INITIALIZER(">="),
    [C_PUNCTUATOR_EQUAL] = S8_INITIALIZER("=="),
    [C_PUNCTUATOR_NOT_EQUAL] = S8_INITIALIZER("!="),
    [C_PUNCTUATOR_AMPERSAND_AMPERSAND] = S8_INITIALIZER("&&"),
    [C_PUNCTUATOR_PIPE_PIPE] = S8_INITIALIZER("||"),
    [C_PUNCTUATOR_STAR_ASSIGN] = S8_INITIALIZER("*="),
    [C_PUNCTUATOR_SLASH_ASSIGN] = S8_INITIALIZER("/="),
    [C_PUNCTUATOR_PERCENT_ASSIGN] = S8_INITIALIZER("%="),
    [C_PUNCTUATOR_PLUS_ASSIGN] = S8_INITIALIZER("+="),
    [C_PUNCTUATOR_MINUS_ASSIGN] = S8_INITIALIZER("-="),
    [C_PUNCTUATOR_AMPERSAND_ASSIGN] = S8_INITIALIZER("&="),
    [C_PUNCTUATOR_CARET_ASSIGN] = S8_INITIALIZER("^="),
    [C_PUNCTUATOR_PIPE_ASSIGN] = S8_INITIALIZER("|="),
    [C_PUNCTUATOR_HASH_HASH] = S8_INITIALIZER("##"),
    [C_PUNCTUATOR_LEFT_BRACKET_DIGRAPH] = S8_INITIALIZER("<:"),
    [C_PUNCTUATOR_RIGHT_BRACKET_DIGRAPH] = S8_INITIALIZER(":>"),
    [C_PUNCTUATOR_LEFT_BRACE_DIGRAPH] = S8_INITIALIZER("<%"),
    [C_PUNCTUATOR_RIGHT_BRACE_DIGRAPH] = S8_INITIALIZER("%>"),
    [C_PUNCTUATOR_HASH_DIGRAPH] = S8_INITIALIZER("%:"),
    [C_PUNCTUATOR_LEFT_BRACKET] = S8_INITIALIZER("["),
    [C_PUNCTUATOR_RIGHT_BRACKET] = S8_INITIALIZER("]"),
    [C_PUNCTUATOR_LEFT_PARENTHESIS] = S8_INITIALIZER("("),
    [C_PUNCTUATOR_RIGHT_PARENTHESIS] = S8_INITIALIZER(")"),
    [C_PUNCTUATOR_LEFT_BRACE] = S8_INITIALIZER("{"),
    [C_PUNCTUATOR_RIGHT_BRACE] = S8_INITIALIZER("}"),
    [C_PUNCTUATOR_DOT] = S8_INITIALIZER("."),
    [C_PUNCTUATOR_AMPERSAND] = S8_INITIALIZER("&"),
    [C_PUNCTUATOR_STAR] = S8_INITIALIZER("*"),
    [C_PUNCTUATOR_PLUS] = S8_INITIALIZER("+"),
    [C_PUNCTUATOR_MINUS] = S8_INITIALIZER("-"),
    [C_PUNCTUATOR_TILDE] = S8_INITIALIZER("~"),
    [C_PUNCTUATOR_EXCLAMATION] = S8_INITIALIZER("!"),
    [C_PUNCTUATOR_SLASH] = S8_INITIALIZER("/"),
    [C_PUNCTUATOR_PERCENT] = S8_INITIALIZER("%"),
    [C_PUNCTUATOR_LESS] = S8_INITIALIZER("<"),
    [C_PUNCTUATOR_GREATER] = S8_INITIALIZER(">"),
    [C_PUNCTUATOR_CARET] = S8_INITIALIZER("^"),
    [C_PUNCTUATOR_PIPE] = S8_INITIALIZER("|"),
    [C_PUNCTUATOR_QUESTION] = S8_INITIALIZER("?"),
    [C_PUNCTUATOR_COLON] = S8_INITIALIZER(":"),
    [C_PUNCTUATOR_SEMICOLON] = S8_INITIALIZER(";"),
    [C_PUNCTUATOR_ASSIGN] = S8_INITIALIZER("="),
    [C_PUNCTUATOR_COMMA] = S8_INITIALIZER(","),
    [C_PUNCTUATOR_HASH] = S8_INITIALIZER("#"),
    [C_PUNCTUATOR_AT] = S8_INITIALIZER("@"),
    [C_PUNCTUATOR_BACKSLASH] = S8_INITIALIZER("\\"),
};

// First-byte dispatch over c_punctuator_spellings, derived from the table at
// first use so the spellings stay the single source of truth. Enum order is
// longest-first, so each per-byte group inherits maximal munch. Without it,
// every lexed punctuator paid a linear scan of the whole table — a `;` sat
// behind ~52 failed memcmp probes.
typedef struct CPunctuatorDispatch CPunctuatorDispatch;
struct CPunctuatorDispatch
{
    u8 start;
    u8 count;
};

BUSTER_C_INTERNAL u8 c_punctuator_dispatch_order[C_PUNCTUATOR_COUNT];
BUSTER_C_INTERNAL CPunctuatorDispatch c_punctuator_dispatch[256];
BUSTER_C_INTERNAL bool c_punctuator_dispatch_built;

BUSTER_C_INTERNAL void c_punctuator_dispatch_build(void)
{
    BUSTER_CHECK_SERIAL_INITIALIZATION();
    u32 cursor = 0;
    for (u32 first = 0; first < 256; first += 1)
    {
        u32 start = cursor;
        for (u32 punctuator_index = C_PUNCTUATOR_NONE + 1; punctuator_index < C_PUNCTUATOR_COUNT; punctuator_index += 1)
        {
            String8 spelling = c_punctuator_spellings[punctuator_index];
            if (spelling.length && (u8)spelling.pointer[0] == first)
            {
                c_punctuator_dispatch_order[cursor++] = (u8)punctuator_index;
            }
        }
        c_punctuator_dispatch[first] = (CPunctuatorDispatch){
            .start = (u8)start,
            .count = (u8)(cursor - start),
        };
    }
    c_punctuator_dispatch_built = true;
}

BUSTER_C_INTERNAL u64 c_punctuator_length(String8 source, u64 offset, CPunctuator* punctuator_out)
{
    if (!c_punctuator_dispatch_built)
    {
        c_punctuator_dispatch_build();
    }
    if (offset < source.length)
    {
        CPunctuatorDispatch dispatch = c_punctuator_dispatch[(u8)source.pointer[offset]];
        for (u32 order_index = 0; order_index < dispatch.count; order_index += 1)
        {
            u32 punctuator_index = c_punctuator_dispatch_order[dispatch.start + order_index];
            String8 punctuator = c_punctuator_spellings[punctuator_index];
            if (punctuator.length > source.length - offset)
            {
                continue;
            }
            bool match = true;
            for (u64 byte_index = 1; byte_index < punctuator.length; byte_index += 1)
            {
                if (source.pointer[offset + byte_index] != punctuator.pointer[byte_index])
                {
                    match = false;
                    break;
                }
            }
            if (match)
            {
                *punctuator_out = (CPunctuator)punctuator_index;
                return punctuator.length;
            }
        }
    }
    *punctuator_out = C_PUNCTUATOR_NONE;
    return 0;
}

BUSTER_C_INTERNAL bool c_literal_prefix(String8 source, u64 offset, u64* prefix_length, char8* delimiter)
{
    *prefix_length = 0;
    *delimiter = 0;
    if (offset < source.length)
    {
        char8 character = source.pointer[offset];
        if (character == '\'' || character == '"')
        {
            *delimiter = character;
            return true;
        }
        if (character == 'u' && offset + 2 < source.length && source.pointer[offset + 1] == '8' &&
            (source.pointer[offset + 2] == '\'' || source.pointer[offset + 2] == '"'))
        {
            *prefix_length = 2;
            *delimiter = source.pointer[offset + 2];
            return true;
        }
        if ((character == 'u' || character == 'U' || character == 'L') && offset + 1 < source.length &&
            (source.pointer[offset + 1] == '\'' || source.pointer[offset + 1] == '"'))
        {
            *prefix_length = 1;
            *delimiter = source.pointer[offset + 1];
            return true;
        }
    }

    return false;
}

// Everything one lex mutates, so the scalar reference loop and the compaction
// emitter below drive tokens, diagnostics and measurement through exactly the
// same code.  The three line fields are the only state that crosses a
// compaction window: they describe the line under construction, never the
// tokenizer, so the window pipeline still starts every window from scratch.
typedef struct CLexState CLexState;
struct CLexState
{
    CLexResult* result;
    CTranslatedSource translated;
    Arena* diagnostic_arena;
    u64 diagnostic_capacity;
    u64 maximum_diagnostic_count;
    // Offset just past the newline that ended the last line, so a file whose
    // last line has no terminating newline still ends a line.
    u64 line_start;
    u64 newline_tokens;
    u32 line_has_code;
    u32 line_has_comment;
    // Nonzero on the compaction path only: c_lex_scan_one then fast-forwards
    // its comment and literal scans in 64-byte strides.  The reference path
    // keeps the byte loops, so the differential gate compares the two.
    u32 simd_scan;
};

#if BUSTER_C_LEX_COMPACT

// The reference spelling of "the lanes below `bit_index`", saturating at the
// window width: one compare, one shift and one conditional move.
BUSTER_C_INLINE BUSTER_UNUSED_DECL BUSTER_INLINE u64 c_lex_mask_below_reference(u64 bit_index)
{
    return bit_index >= 64 ? ~(u64)0 : (((u64)1 << bit_index) - 1);
}

// The same mask in one instruction.  BMI2's BZHI reads its lane count from the
// low eight bits of the index operand and clears nothing when that count is 64
// or more, which is exactly the reference's saturation, so the whole helper is
// `bzhi $-1, index` for every index this lexer forms.  The bound is what makes
// the low-eight-bits reading safe, so it is stated: every index here is a
// window position (0..64) or a window position plus a punctuator spelling
// (at most 67), and the check compiles to an optimizer assumption under
// BUSTER_OPTIMIZE rather than to code.  c_lex_lane_mask keeps the reference
// form because its callers pass whole-file byte counts.
#define C_LEX_MASK_BELOW_LIMIT 68

BUSTER_C_INLINE BUSTER_INLINE u64 c_lex_mask_below(u64 bit_index)
{
    BUSTER_CHECK(bit_index < C_LEX_MASK_BELOW_LIMIT);
#if defined(__BMI2__)
    u64 result = _bzhi_u64(~(u64)0, (u32)bit_index);
#else
    u64 result = c_lex_mask_below_reference(bit_index);
#endif
    return result;
}

BUSTER_C_INLINE BUSTER_INLINE __mmask64 c_lex_lane_mask(u64 count)
{
    return (__mmask64)c_lex_mask_below_reference(count);
}

// The bytes one window of the compact emitter reads: its own 64 lanes plus the
// two the punctuator NFA's second and third lookups and the comment delimiters
// see past the last of them.  A window with that many bytes left needs no lane
// mask on any of its three loads.
#define C_LEX_WINDOW_LOADED_BYTES 66

// Lanes of a lookahead load that hold a real byte.  The window bounds do not
// serve: a punctuator or comment delimiter near the window's end is classified
// from bytes the next window owns, and reading them as zero would mis-spell it.
BUSTER_C_INLINE BUSTER_INLINE __mmask64 c_lex_lookahead_mask(u64 remaining, u64 ahead)
{
    return c_lex_lane_mask(remaining > ahead ? remaining - ahead : 0);
}

// 64-byte-stride forward scans for the escape items the window masks do not
// model — comments and literals longer than a window (2026-08-10b's largest
// remaining slice: on this tree half of all lexed bytes are such items, most
// of them the generated string tables).  Each returns the offset of the first
// byte c_lex_scan_one's byte loop would have stopped at, or source.length, so
// the loops keep their exact stop-byte handling and only the plain runs
// between stops vectorize.  Invalid lanes load as zero, and no scanned-for
// byte is NUL, so the compares need no separate bounds mask.

BUSTER_C_INLINE BUSTER_INLINE u64 c_lex_byte_find(String8 source, u64 offset, char8 target)
{
    const __m512i needle = _mm512_set1_epi8((char)target);
    u64 result = source.length;
    while (offset < source.length)
    {
        __m512i chunk = _mm512_maskz_loadu_epi8(c_lex_lane_mask(source.length - offset), source.pointer + offset);
        u64 hits = (u64)_mm512_cmpeq_epi8_mask(chunk, needle);
        if (hits)
        {
            result = offset + (u64)__builtin_ctzll(hits);
            break;
        }
        offset += 64;
    }
    return result;
}

BUSTER_C_INLINE BUSTER_INLINE u64 c_lex_literal_special_find(String8 source, u64 offset, char8 delimiter)
{
    const __m512i delimiter_vector = _mm512_set1_epi8((char)delimiter);
    const __m512i backslash_vector = _mm512_set1_epi8('\\');
    const __m512i newline_vector = _mm512_set1_epi8('\n');
    u64 result = source.length;
    while (offset < source.length)
    {
        __m512i chunk = _mm512_maskz_loadu_epi8(c_lex_lane_mask(source.length - offset), source.pointer + offset);
        u64 hits = (u64)_mm512_cmpeq_epi8_mask(chunk, delimiter_vector) | (u64)_mm512_cmpeq_epi8_mask(chunk, backslash_vector) |
                   (u64)_mm512_cmpeq_epi8_mask(chunk, newline_vector);
        if (hits)
        {
            result = offset + (u64)__builtin_ctzll(hits);
            break;
        }
        offset += 64;
    }
    return result;
}

BUSTER_C_INLINE BUSTER_INLINE u64 c_lex_block_comment_stop_find(String8 source, u64 offset)
{
    const __m512i star_vector = _mm512_set1_epi8('*');
    const __m512i slash_vector = _mm512_set1_epi8('/');
    const __m512i newline_vector = _mm512_set1_epi8('\n');
    u64 result = source.length;
    while (offset < source.length)
    {
        u64 remaining = source.length - offset;
        __m512i chunk = _mm512_maskz_loadu_epi8(c_lex_lane_mask(remaining), source.pointer + offset);
        // A star in the last lane pairs with the next chunk's first byte, so
        // the lookahead load is masked by the file bounds, not the chunk's.
        __m512i next = _mm512_maskz_loadu_epi8(c_lex_lookahead_mask(remaining, 1), source.pointer + offset + 1);
        u64 close = (u64)_mm512_cmpeq_epi8_mask(chunk, star_vector) & (u64)_mm512_cmpeq_epi8_mask(next, slash_vector);
        u64 hits = close | (u64)_mm512_cmpeq_epi8_mask(chunk, newline_vector);
        if (hits)
        {
            result = offset + (u64)__builtin_ctzll(hits);
            break;
        }
        offset += 64;
    }
    return result;
}

#endif

// Only identifier/pp-number spellings use this source-input contract. Comments
// and literal payloads retain their byte policy; OS utf8_decode is unrelated.
// Report the first byte of the first ill-formed sequence, including a truncated
// leader at the end of this bounded token. Translation checkpoints recover its
// physical position even when a CRLF splice occurs inside the sequence.
BUSTER_C_INTERNAL void c_lex_validate_word_utf8(CLexState* state, u64 offset, u64 end)
{
    const u8* bytes = (const u8*)state->translated.source.pointer;
    while (offset < end)
    {
        u8 leader = bytes[offset];
        u32 length = leader < 0x80 ? 1 : leader >= 0xC2 && leader <= 0xDF ? 2 :
                     leader >= 0xE0 && leader <= 0xEF ? 3 : leader >= 0xF0 && leader <= 0xF4 ? 4 : 0;
        bool valid = length && length <= end - offset;
        for (u32 index = 1; valid && index < length; index += 1)
        {
            valid = (bytes[offset + index] & 0xC0) == 0x80;
        }
        if (valid && length >= 3)
        {
            u8 second = bytes[offset + 1];
            valid = (leader != 0xE0 || second >= 0xA0) && (leader != 0xED || second < 0xA0) &&
                    (leader != 0xF0 || second >= 0x90) && (leader != 0xF4 || second < 0x90);
        }
        if (!valid)
        {
            c_diagnostic_push(state->result, state->diagnostic_arena, &state->diagnostic_capacity, state->maximum_diagnostic_count,
                              offset, C_DIAGNOSTIC_INVALID_UTF8, S8("invalid UTF-8 sequence in C source token"));
            break;
        }
        offset += length;
    }
}

// One item of the scalar lexer: a whitespace byte, a newline, a comment, or a
// token, starting at `offset` and returning the offset just past it. The
// compaction emitter escapes here for shapes its masks do not model. Long
// comment/literal bodies fast-forward in 64-byte strides for state->simd_scan;
// the reference keeps byte loops so the differential gate compares the two.
BUSTER_C_INTERNAL u64 c_lex_scan_one(CLexState* state, u64 offset)
{
    CLexResult* result = state->result;
    CTranslatedSource translated = state->translated;
    char8 character = translated.source.pointer[offset];
    if (c_horizontal_whitespace(character))
    {
        result->metrics.blank_bytes += 1;
        return offset + 1;
    }
    if (character == '\n')
    {
        c_token_push(result, translated, offset, offset + 1, C_TOKEN_NEWLINE, C_PUNCTUATOR_NONE);
        c_source_metrics_line(&result->metrics, state->line_has_code, state->line_has_comment);
        result->metrics.blank_bytes += 1;
        state->newline_tokens += 1;
        state->line_has_code = 0;
        state->line_has_comment = 0;
        state->line_start = offset + 1;
        return offset + 1;
    }
    if (character == '/' && offset + 1 < translated.source.length && translated.source.pointer[offset + 1] == '/')
    {
        u64 comment_start = offset;
        offset += 2;
#if BUSTER_C_LEX_COMPACT
        if (state->simd_scan)
        {
            offset = c_lex_byte_find(translated.source, offset, '\n');
        }
#endif
        while (offset < translated.source.length && translated.source.pointer[offset] != '\n')
        {
            offset += 1;
        }
        result->metrics.comment_bytes += offset - comment_start;
        result->metrics.comments += 1;
        state->line_has_comment = 1;
        return offset;
    }
    if (character == '/' && offset + 1 < translated.source.length && translated.source.pointer[offset + 1] == '*')
    {
        u64 comment_start = offset;
        offset += 2;
        bool terminated = false;
        // Set before the scan so the lines a multi-line comment crosses are
        // all attributed to it as they end.
        state->line_has_comment = 1;
        while (offset < translated.source.length)
        {
#if BUSTER_C_LEX_COMPACT
            // Fast-forward to the next stop byte; the checks below then
            // consume it exactly as the byte loop would have.
            if (state->simd_scan)
            {
                offset = c_lex_block_comment_stop_find(translated.source, offset);
                if (offset >= translated.source.length)
                {
                    break;
                }
            }
#endif
            if (translated.source.pointer[offset] == '*' && offset + 1 < translated.source.length && translated.source.pointer[offset + 1] == '/')
            {
                offset += 2;
                terminated = true;
                break;
            }
            if (translated.source.pointer[offset] == '\n')
            {
                c_token_push(result, translated, offset, offset + 1, C_TOKEN_NEWLINE, C_PUNCTUATOR_NONE);
                c_source_metrics_line(&result->metrics, state->line_has_code, 1);
                state->newline_tokens += 1;
                state->line_has_code = 0;
                state->line_start = offset + 1;
            }
            offset += 1;
        }
        result->metrics.comment_bytes += offset - comment_start;
        result->metrics.comments += 1;
        if (!terminated)
        {
            c_diagnostic_push(result, state->diagnostic_arena, &state->diagnostic_capacity, state->maximum_diagnostic_count, comment_start,
                              C_DIAGNOSTIC_UNTERMINATED_BLOCK_COMMENT, S8("unterminated block comment"));
        }
        return offset;
    }
    // Everything past this point produces a token, so one store here covers
    // every kind instead of one per lexing branch.
    state->line_has_code = 1;
    u64 literal_prefix_length = 0;
    char8 literal_delimiter = 0;
    if (c_literal_prefix(translated.source, offset, &literal_prefix_length, &literal_delimiter))
    {
        u64 start = offset;
        offset += literal_prefix_length + 1;
        bool terminated = false;
        while (offset < translated.source.length)
        {
            // The stride scan seeks only this literal's own delimiter where
            // the shared table also stops at the other quote kind; the loop
            // treats that byte as plain either way.
#if BUSTER_C_LEX_COMPACT
            offset = state->simd_scan ? c_lex_literal_special_find(translated.source, offset, literal_delimiter)
                                      : c_literal_plain_run_end(translated.source, offset);
#else
            offset = c_literal_plain_run_end(translated.source, offset);
#endif
            if (offset >= translated.source.length)
            {
                break;
            }
            character = translated.source.pointer[offset];
            if (character == literal_delimiter)
            {
                offset += 1;
                terminated = true;
                break;
            }
            if (character == '\n')
            {
                break;
            }
            if (character == '\\' && offset + 1 < translated.source.length)
            {
                offset += 2;
            }
            else
            {
                offset += 1;
            }
        }
        CTokenKind kind = literal_delimiter == '\'' ? C_TOKEN_CHARACTER_LITERAL : C_TOKEN_STRING_LITERAL;
        c_token_push(result, translated, start, offset, kind, C_PUNCTUATOR_NONE);
        result->metrics.literal_bytes += offset - start;
        if (!terminated)
        {
            c_diagnostic_push(result, state->diagnostic_arena, &state->diagnostic_capacity, state->maximum_diagnostic_count, start,
                              literal_delimiter == '\'' ? C_DIAGNOSTIC_UNTERMINATED_CHARACTER_LITERAL : C_DIAGNOSTIC_UNTERMINATED_STRING_LITERAL,
                              literal_delimiter == '\'' ? S8("unterminated character literal") : S8("unterminated string literal"));
        }
        return offset;
    }
    if (c_identifier_start(character))
    {
        u64 start = offset;
        offset = c_identifier_run_end(translated.source, offset + (character < 0x80));
        if (BUSTER_UNLIKELY(offset < translated.source.length && translated.source.pointer[offset] >= 0x80))
        {
            u64 first_high = offset;
            while (offset < translated.source.length && c_identifier_continue(translated.source.pointer[offset]))
            {
                offset += 1;
            }
            c_lex_validate_word_utf8(state, first_high, offset);
        }
        c_token_push(result, translated, start, offset, C_TOKEN_IDENTIFIER, C_PUNCTUATOR_NONE);
        if (BUSTER_UNLIKELY(offset - start >= C_TOKEN_LENGTH_OVERSIZED))
        {
            c_diagnostic_push(result, state->diagnostic_arena, &state->diagnostic_capacity, state->maximum_diagnostic_count, start,
                              C_DIAGNOSTIC_TOKEN_TOO_LONG, S8("identifier exceeds 65534 bytes"));
        }
        return offset;
    }
    if (c_ascii_digit(character) || (character == '.' && offset + 1 < translated.source.length && c_ascii_digit(translated.source.pointer[offset + 1])))
    {
        u64 start = offset++;
        u8 high_bytes = 0;
        while (offset < translated.source.length)
        {
            character = translated.source.pointer[offset];
            bool exponent_sign = (character == '+' || character == '-') && offset > start &&
                                 (translated.source.pointer[offset - 1] == 'e' || translated.source.pointer[offset - 1] == 'E' ||
                                  translated.source.pointer[offset - 1] == 'p' || translated.source.pointer[offset - 1] == 'P');
            if (!c_identifier_continue(character) && character != '.' && character != '\'' && !exponent_sign)
            {
                break;
            }
            high_bytes |= (u8)character;
            offset += 1;
        }
        if (BUSTER_UNLIKELY(high_bytes & 0x80))
        {
            c_lex_validate_word_utf8(state, start, offset);
        }
        c_token_push(result, translated, start, offset, C_TOKEN_PREPROCESSING_NUMBER, C_PUNCTUATOR_NONE);
        if (BUSTER_UNLIKELY(offset - start >= C_TOKEN_LENGTH_OVERSIZED))
        {
            c_diagnostic_push(result, state->diagnostic_arena, &state->diagnostic_capacity, state->maximum_diagnostic_count, start,
                              C_DIAGNOSTIC_TOKEN_TOO_LONG, S8("preprocessing number exceeds 65534 bytes"));
        }
        return offset;
    }
    CPunctuator punctuator = C_PUNCTUATOR_NONE;
    u64 punctuator_length = c_punctuator_length(translated.source, offset, &punctuator);
    if (punctuator_length)
    {
        c_token_push(result, translated, offset, offset + punctuator_length, C_TOKEN_PUNCTUATOR, punctuator);
        return offset + punctuator_length;
    }
    c_token_push(result, translated, offset, offset + 1, C_TOKEN_INVALID, C_PUNCTUATOR_NONE);
    c_diagnostic_push(result, state->diagnostic_arena, &state->diagnostic_capacity, state->maximum_diagnostic_count, offset, C_DIAGNOSTIC_INVALID_CHARACTER,
                      string_format(state->diagnostic_arena, S8("invalid character byte {u32} in C source"), (u32)character));
    return offset + 1;
}

BUSTER_C_INTERNAL void c_lex_scalar(CLexState* state)
{
    u64 length = state->translated.source.length;
    u64 offset = 0;
    while (offset < length)
    {
        offset = c_lex_scan_one(state, offset);
    }
}

#if BUSTER_C_LEX_COMPACT

// Deus-Lex-Machina compaction emitter for the C lexer (see the AGENTS.md SIMD
// lexing/parsing method notes and validark.dev/posts/deus-lex-machina), the
// same architecture the buster tokenizer runs: the translated source is walked
// in token-aligned 64-byte windows; each window classifies once into per-class
// bitmasks; quote, comment and escape spans resolve by mask arithmetic with a
// forward-seeking cursor (escape parity per the simdjson backslash algorithm);
// multi-character punctuators legalize through a bit-channel vpermi2b NFA
// (three per-position tables AND-ed, one channel per punctuator family);
// preprocessing-number extents resolve by carry propagation over a
// continuation mask — all of a window's numbers at once when numbers are its
// only extent class, a count-trailing-ones cursor query otherwise; and every
// complete token then materializes at once — vpcompressb pulls start and end
// positions of an iota vector through the token-boundary masks, a byte
// subtract yields all lengths, and the kind and punctuator vectors compress
// by the same starts mask before masked widening interleaved stores write
// the 12-byte CToken rows sixteen at a time.
//
// Windows always begin at an item boundary, so no lexer state crosses a
// window: the item touching a window's last byte is deferred and rescanned by
// the next window.  The shapes the masks do not model — invalid bytes,
// unterminated literals, unterminated block comments, and any single item
// longer than a window (long comments, long identifiers, long literals) —
// escape to c_lex_scan_one, which is the code the scalar loop runs, so both
// paths agree on every hard case by construction.

BUSTER_CT_CHECK(C_PUNCTUATOR_NONE == 0);
BUSTER_CT_CHECK(C_TOKEN_INVALID == 0);

// Bit channels of the punctuator NFA.  A byte pair (or triple) spells a
// punctuator when the AND of the per-position table lookups is nonzero in some
// channel; the two channels marked "equal-byte" additionally require the first
// two bytes to be identical, which one vpcmpeqb supplies and which is what
// keeps the seven doubled spellings from needing a channel each.
enum
{
    C_LEX_NFA_ASSIGN = 1 << 0,
    C_LEX_NFA_DOUBLE = 1 << 1,
    C_LEX_NFA_ARROW = 1 << 2,
    C_LEX_NFA_LESS_PAIR = 1 << 3,
    C_LEX_NFA_PERCENT_PAIR = 1 << 4,
    C_LEX_NFA_SHIFT_ASSIGN = 1 << 5,
    C_LEX_NFA_ELLIPSIS = 1 << 6,
    C_LEX_NFA_PAIR_CHANNELS = C_LEX_NFA_ASSIGN | C_LEX_NFA_ARROW | C_LEX_NFA_LESS_PAIR | C_LEX_NFA_PERCENT_PAIR,
};

enum
{
    C_LEX_PAIR_TABLE_SIZE = 16,
};

// The four byte classes the window loop used to assemble out of thirteen
// compares and seven ors.  One vpermi2b over the table below answers all of
// them at once, and each falls out as a vptestmb against its own bit; the
// table is authored from the very predicates the scalar lexer calls, so the
// two spellings of "identifier byte" and "horizontal white space" cannot
// drift apart.  It covers 0..127 only: every byte above ASCII is an
// identifier byte by c_identifier_start and joins the word class through the
// sign mask the permute already needs, and no byte above ASCII is in any of
// the other three.
enum
{
    C_LEX_CLASS_WORD = 1 << 0,
    C_LEX_CLASS_WHITE = 1 << 1,
    C_LEX_CLASS_DIGIT = 1 << 2,
    C_LEX_CLASS_EXPONENT = 1 << 3,
};

BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_byte_classes[128];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_single_punctuators[128];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_nfa_first[128];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_nfa_second[128];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_nfa_third[128];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_iota[64];
// Two-character spellings, keyed by densely numbered first and second bytes so
// the whole cross product fits one cache line instead of a 64 KB table.  The
// emitter reads the keys and the cross product as vpermi2b tables, so all
// four arrays are vector-aligned.
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_pair_row[128];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_pair_column[128];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_pair_punctuators[C_LEX_PAIR_TABLE_SIZE][C_LEX_PAIR_TABLE_SIZE];
BUSTER_C_INTERNAL _Alignas(64) u8 c_lex_triple_punctuators[128];
BUSTER_C_INTERNAL bool c_lex_compact_tables_built;

// Every spelling table below is derived from c_punctuator_spellings, so a new
// punctuator cannot drift out of the emitter's tables.  The NFA channels
// themselves are hand-assigned; c_test_frontend_lex_punctuator_nfa validates
// them exhaustively against c_punctuator_length.
BUSTER_C_INTERNAL void c_lex_compact_tables_build(void)
{
    BUSTER_CHECK_SERIAL_INITIALIZATION();
    for (u32 index = 0; index < 64; index += 1)
    {
        c_lex_iota[index] = (u8)index;
    }
    for (u32 value = 0; value < 128; value += 1)
    {
        char8 character = (char8)value;
        u8 classes = 0;
        if (c_identifier_continue(character))
        {
            classes |= (u8)C_LEX_CLASS_WORD;
        }
        if (c_horizontal_whitespace(character))
        {
            classes |= (u8)C_LEX_CLASS_WHITE;
        }
        if (c_ascii_digit(character))
        {
            classes |= (u8)C_LEX_CLASS_DIGIT;
        }
        // The letters that open a preprocessing number's exponent, in both
        // cases: the emitter used to fold case by oring 0x20 into the whole
        // window for this test and the alphabetic one alone.
        if (character == 'e' || character == 'E' || character == 'p' || character == 'P')
        {
            classes |= (u8)C_LEX_CLASS_EXPONENT;
        }
        c_lex_byte_classes[value] = classes;
    }
    memset(c_lex_pair_row, 0xFF, sizeof(c_lex_pair_row));
    memset(c_lex_pair_column, 0xFF, sizeof(c_lex_pair_column));
    u32 row_count = 0;
    u32 column_count = 0;
    for (u32 index = C_PUNCTUATOR_NONE + 1; index < C_PUNCTUATOR_COUNT; index += 1)
    {
        String8 spelling = c_punctuator_spellings[index];
        BUSTER_CHECK(spelling.length && (u8)spelling.pointer[0] < 128);
        u8 first = (u8)spelling.pointer[0];
        if (spelling.length == 1)
        {
            c_lex_single_punctuators[first] = (u8)index;
        }
        else if (spelling.length == 2)
        {
            u8 second = (u8)spelling.pointer[1];
            BUSTER_CHECK(second < 128);
            if (c_lex_pair_row[first] == 0xFF)
            {
                c_lex_pair_row[first] = (u8)row_count++;
            }
            if (c_lex_pair_column[second] == 0xFF)
            {
                c_lex_pair_column[second] = (u8)column_count++;
            }
            BUSTER_CHECK(row_count <= C_LEX_PAIR_TABLE_SIZE && column_count <= C_LEX_PAIR_TABLE_SIZE);
            c_lex_pair_punctuators[c_lex_pair_row[first]][c_lex_pair_column[second]] = (u8)index;
        }
        else if (spelling.length == 3)
        {
            BUSTER_CHECK(!c_lex_triple_punctuators[first]);
            c_lex_triple_punctuators[first] = (u8)index;
        }
        else
        {
            // The one four-character spelling, %:%:, which the emitter finds
            // as two adjacent %: pairs rather than through a fourth table.
            BUSTER_CHECK(spelling.length == 4 && index == C_PUNCTUATOR_HASH_HASH_DIGRAPH);
        }
    }

    for (const char8* it = "!%&*+-/<=>^|"; *it; it += 1)
    {
        c_lex_nfa_first[(u8)*it] |= C_LEX_NFA_ASSIGN;
    }
    c_lex_nfa_second['='] |= C_LEX_NFA_ASSIGN;

    for (const char8* it = "#&+-<>|"; *it; it += 1)
    {
        c_lex_nfa_first[(u8)*it] |= C_LEX_NFA_DOUBLE;
        c_lex_nfa_second[(u8)*it] |= C_LEX_NFA_DOUBLE;
    }

    c_lex_nfa_first['-'] |= C_LEX_NFA_ARROW;
    c_lex_nfa_first[':'] |= C_LEX_NFA_ARROW;
    c_lex_nfa_second['>'] |= C_LEX_NFA_ARROW;

    c_lex_nfa_first['<'] |= C_LEX_NFA_LESS_PAIR;
    c_lex_nfa_second[':'] |= C_LEX_NFA_LESS_PAIR;
    c_lex_nfa_second['%'] |= C_LEX_NFA_LESS_PAIR;

    c_lex_nfa_first['%'] |= C_LEX_NFA_PERCENT_PAIR;
    c_lex_nfa_second[':'] |= C_LEX_NFA_PERCENT_PAIR;
    c_lex_nfa_second['>'] |= C_LEX_NFA_PERCENT_PAIR;

    c_lex_nfa_first['<'] |= C_LEX_NFA_SHIFT_ASSIGN;
    c_lex_nfa_first['>'] |= C_LEX_NFA_SHIFT_ASSIGN;
    c_lex_nfa_second['<'] |= C_LEX_NFA_SHIFT_ASSIGN;
    c_lex_nfa_second['>'] |= C_LEX_NFA_SHIFT_ASSIGN;
    c_lex_nfa_third['='] |= C_LEX_NFA_SHIFT_ASSIGN;

    c_lex_nfa_first['.'] |= C_LEX_NFA_ELLIPSIS;
    c_lex_nfa_second['.'] |= C_LEX_NFA_ELLIPSIS;
    c_lex_nfa_third['.'] |= C_LEX_NFA_ELLIPSIS;

    c_lex_compact_tables_built = true;
}

BUSTER_C_INLINE BUSTER_INLINE u64 c_lex_mask_range(u64 low, u64 high)
{
    return c_lex_mask_below(high) & ~c_lex_mask_below(low);
}

// Sixteen finished rows: the compressed start, length, kind and punctuator
// bytes widen to 32-bit lanes, the metadata dword assembles as
// length | kind<<16 | punctuator<<24, and three masked vpermi2d interleave
// offsets and metadata into the 48 dwords of sixteen 12-byte CToken rows —
// 192 stored bytes.  The zero symbol dwords come from the permutes' own
// zeroing masks rather than from sacrificial zero lanes, which is what
// lets one pass cover sixteen rows where the earlier eight-row form spent
// the offset vector's masked-off upper lanes as its zero source.
BUSTER_C_INLINE BUSTER_INLINE void c_lex_store_rows(CToken* out, CTokenShape* shapes_out, u64 shape_mask, __m512i starts, __m512i lengths,
                                                        __m512i kinds, __m512i punctuators, __m512i shapes, __m512i base, __m512i index_0,
                                                        __m512i index_1, __m512i index_2)
{
    __m512i start_wide = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(starts));
    __m512i length_wide = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(lengths));
    __m512i kind_wide = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(kinds));
    __m512i punctuator_wide = _mm512_cvtepu8_epi32(_mm512_castsi512_si128(punctuators));
    __m512i offsets = _mm512_add_epi32(start_wide, base);
    __m512i metadata = _mm512_or_si512(length_wide, _mm512_or_si512(_mm512_slli_epi32(kind_wide, 16), _mm512_slli_epi32(punctuator_wide, 24)));
    u32* dwords = (u32*)out;
    _mm512_storeu_si512((__m512i*)dwords, _mm512_maskz_permutex2var_epi32(0xDB6D, offsets, index_0, metadata));
    _mm512_storeu_si512((__m512i*)(dwords + 16), _mm512_maskz_permutex2var_epi32(0x6DB6, offsets, index_1, metadata));
    _mm512_storeu_si512((__m512i*)(dwords + 32), _mm512_maskz_permutex2var_epi32(0xB6DB, offsets, index_2, metadata));
    _mm512_mask_storeu_epi8(shapes_out, (__mmask64)shape_mask, shapes);
}

BUSTER_C_INTERNAL void c_lex_compact(CLexState* state)
{
    CLexResult* result = state->result;
    String8 source = state->translated.source;
    u32 translated_offset = state->translated.translated_offset;

    if (!c_lex_compact_tables_built)
    {
        c_lex_compact_tables_build();
    }

    const __m512i class_low = _mm512_load_si512((const __m512i*)c_lex_byte_classes);
    const __m512i class_high = _mm512_load_si512((const __m512i*)(c_lex_byte_classes + 64));
    const __m512i single_low = _mm512_load_si512((const __m512i*)c_lex_single_punctuators);
    const __m512i single_high = _mm512_load_si512((const __m512i*)(c_lex_single_punctuators + 64));
    const __m512i nfa_first_low = _mm512_load_si512((const __m512i*)c_lex_nfa_first);
    const __m512i nfa_first_high = _mm512_load_si512((const __m512i*)(c_lex_nfa_first + 64));
    const __m512i nfa_second_low = _mm512_load_si512((const __m512i*)c_lex_nfa_second);
    const __m512i nfa_second_high = _mm512_load_si512((const __m512i*)(c_lex_nfa_second + 64));
    const __m512i nfa_third_low = _mm512_load_si512((const __m512i*)c_lex_nfa_third);
    const __m512i nfa_third_high = _mm512_load_si512((const __m512i*)(c_lex_nfa_third + 64));
    const __m512i iota = _mm512_load_si512((const __m512i*)c_lex_iota);
    // The 16-row interleave: dword d of the 48 stored holds row d/3's offset
    // (d%3 == 0), zeroed symbol (1) or metadata (2); offsets sit in the
    // permute's first source, metadata in lanes 16..31 of its second, and
    // the symbol dwords take any index because the store masks zero them.
    const __m512i row_index_0 = _mm512_setr_epi32(0, 0, 16, 1, 0, 17, 2, 0, 18, 3, 0, 19, 4, 0, 20, 5);
    const __m512i row_index_1 = _mm512_setr_epi32(0, 21, 6, 0, 22, 7, 0, 23, 8, 0, 24, 9, 0, 25, 10, 0);
    const __m512i row_index_2 = _mm512_setr_epi32(26, 11, 0, 27, 12, 0, 28, 13, 0, 29, 14, 0, 30, 15, 0, 31);

    u64 offset = 0;
    while (offset < source.length)
    {
        const char8* it = source.pointer + offset;
        u64 remaining = source.length - offset;
        u64 window_length = remaining < 64 ? remaining : 64;
        bool at_end_of_file = window_length == remaining;
        u64 valid;
        __m512i chunk0;
        __m512i chunk1;
        __m512i chunk2;
        if (remaining >= C_LEX_WINDOW_LOADED_BYTES)
        {
            // Every lane of the window and of both lookaheads holds a byte the
            // file owns, so the three loads need no mask and the three lane
            // masks no arithmetic at all — nine instructions of shift and
            // conditional move that 92% of windows were paying to reconstruct
            // an all-ones mask.  The bound is the window plus the two bytes
            // the punctuator NFA and the comment delimiters look ahead by.
            valid = ~(u64)0;
            chunk0 = _mm512_loadu_si512((const void*)it);
            chunk1 = _mm512_loadu_si512((const void*)(it + 1));
            chunk2 = _mm512_loadu_si512((const void*)(it + 2));
        }
        else
        {
            __mmask64 valid_lanes = c_lex_lane_mask(window_length);
            valid = (u64)valid_lanes;
            chunk0 = _mm512_maskz_loadu_epi8(valid_lanes, it);
            chunk1 = _mm512_maskz_loadu_epi8(c_lex_lookahead_mask(remaining, 1), it + 1);
            chunk2 = _mm512_maskz_loadu_epi8(c_lex_lookahead_mask(remaining, 2), it + 2);
        }

        // One masked load, every byte class in lockstep.  The word, white,
        // digit and exponent classes come out of one table lookup and four
        // bit tests; the rest are single bytes, which a compare already
        // answers in one instruction.
        u64 high_byte = (u64)_mm512_movepi8_mask(chunk0);
        __m512i class_vector = _mm512_maskz_permutex2var_epi8((__mmask64)~high_byte, class_low, chunk0, class_high);
        u64 digit = (u64)_mm512_test_epi8_mask(class_vector, _mm512_set1_epi8((char)C_LEX_CLASS_DIGIT));
        u64 line_feed = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('\n'));
        u64 quote = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('"'));
        u64 apostrophe = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('\''));
        u64 backslash = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('\\'));
        u64 slash = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('/'));
        u64 star = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('*'));
        u64 dot = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('.'));
        u64 plus = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('+'));
        u64 minus = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('-'));
        u64 percent = (u64)_mm512_cmpeq_epi8_mask(chunk0, _mm512_set1_epi8('%'));
        u64 exponent_letter = (u64)_mm512_test_epi8_mask(class_vector, _mm512_set1_epi8((char)C_LEX_CLASS_EXPONENT));
        u64 slash_next = (u64)_mm512_cmpeq_epi8_mask(chunk1, _mm512_set1_epi8('/'));
        u64 star_next = (u64)_mm512_cmpeq_epi8_mask(chunk1, _mm512_set1_epi8('*'));
        u64 colon_next = (u64)_mm512_cmpeq_epi8_mask(chunk1, _mm512_set1_epi8(':'));
        u64 repeated = (u64)_mm512_cmpeq_epi8_mask(chunk0, chunk1);
        // High bytes still join word extents, but their whole token escapes
        // below for UTF-8 validation before it can reach the batch emitter.
        u64 word = high_byte | (u64)_mm512_test_epi8_mask(class_vector, _mm512_set1_epi8((char)C_LEX_CLASS_WORD));
        u64 white = (u64)_mm512_test_epi8_mask(class_vector, _mm512_set1_epi8((char)C_LEX_CLASS_WHITE));

        // Single-character punctuator ids double as the "byte can start a
        // punctuator" class, since C_PUNCTUATOR_NONE is zero.
        __m512i single_vector = _mm512_maskz_permutex2var_epi8((__mmask64)~high_byte, single_low, chunk0, single_high);
        u64 punctuator_byte = (u64)_mm512_test_epi8_mask(single_vector, single_vector);

        // Bit-channel NFA: three per-position lookups AND together, one
        // channel per punctuator family, plus the equal-byte refinement.
        u64 high_next = (u64)_mm512_movepi8_mask(chunk1);
        u64 high_third = (u64)_mm512_movepi8_mask(chunk2);
        __m512i first_vector = _mm512_maskz_permutex2var_epi8((__mmask64)~high_byte, nfa_first_low, chunk0, nfa_first_high);
        __m512i second_vector = _mm512_maskz_permutex2var_epi8((__mmask64)~high_next, nfa_second_low, chunk1, nfa_second_high);
        __m512i third_vector = _mm512_maskz_permutex2var_epi8((__mmask64)~high_third, nfa_third_low, chunk2, nfa_third_high);
        __m512i pair_vector = _mm512_and_si512(first_vector, second_vector);
        __m512i triple_vector = _mm512_and_si512(pair_vector, third_vector);
        u64 punctuator2 = (u64)_mm512_test_epi8_mask(pair_vector, _mm512_set1_epi8((char)C_LEX_NFA_PAIR_CHANNELS)) |
                          ((u64)_mm512_test_epi8_mask(pair_vector, _mm512_set1_epi8((char)C_LEX_NFA_DOUBLE)) & repeated);
        u64 ellipsis = (u64)_mm512_test_epi8_mask(triple_vector, _mm512_set1_epi8((char)C_LEX_NFA_ELLIPSIS));
        u64 punctuator3 = ellipsis | ((u64)_mm512_test_epi8_mask(triple_vector, _mm512_set1_epi8((char)C_LEX_NFA_SHIFT_ASSIGN)) & repeated);
        u64 percent_colon = percent & colon_next;
        u64 punctuator4 = percent_colon & (percent_colon >> 2);

        // A preprocessing number swallows identifier bytes, dots, digit
        // separators, and the sign of an exponent — the one context-sensitive
        // rule, and one mask shift models it exactly.
        u64 exponent_sign = (plus | minus) & (exponent_letter << 1);
        u64 number_continue = word | dot | apostrophe | exponent_sign;
        u64 number_seed = (digit & ~(word << 1)) | (dot & (digit >> 1));
        u64 line_comment_open = slash & slash_next;
        u64 block_comment_open = slash & star_next;
        u64 block_comment_close = star & slash_next;
        // `...` is the one punctuator that can swallow another item's start:
        // its last dot would otherwise seed the number in `...5`.  Every other
        // spelling is built from bytes no item can begin with, so the cursor
        // below needs no other punctuator.
        u64 other_candidates = (line_comment_open | block_comment_open | quote | apostrophe | ellipsis) & valid;

        // Numbers, comments, literals and ellipses are the only items that can
        // swallow another item's bytes.  A window whose candidates are all
        // number seeds — the dominant class, 93% of cursor iterations in the
        // 2026-08-22T140940Z census — resolves every extent at once by carry
        // propagation: adding each continuation run's first seed to the
        // continuation mask carries through the run, and the flipped bits are
        // exactly that number's span.  The first seed of a run is itself one
        // addition — run starts ripple through the continuation bytes below
        // the first seed and land on it, while later seeds (the digit after
        // `5.` or `1e+`) sit on cleared sum bits.  Mixed windows keep the
        // left-to-right cursor, whose order is what resolves the precedence
        // among the four classes; identifiers, punctuators and whitespace
        // fall out of pure mask arithmetic below either way.
        u64 comment_span = 0;
        u64 comment_starts = 0;
        u64 literal_span = 0;
        u64 number_span = 0;
        u64 number_starts = 0;
        u64 string_starts = 0;
        u64 character_starts = 0;
        u64 defer_at = 64;
        u64 trigger_at = 64;
        u64 extent_candidates = 0;
        if (!other_candidates)
        {
            u64 seeds = number_seed & valid;
            u64 run_starts = number_continue & ~(number_continue << 1);
            number_starts = ((number_continue & ~seeds) + run_starts) & seeds;
            number_span = ((number_continue + number_starts) ^ number_continue) & number_continue;
            // A number reaching the window's last byte may continue into the
            // next window; defer it exactly as the cursor would have.
            if (!at_end_of_file && (number_span >> 63))
            {
                defer_at = (u64)(63 - __builtin_clzll(number_starts));
                number_starts &= ~((u64)1 << defer_at);
                number_span &= c_lex_mask_below(defer_at);
            }
        }
        else
        {
            extent_candidates = (number_seed & valid) | other_candidates;
        }
        u64 cursor = 0;
        for (u64 rest = extent_candidates; rest; rest = extent_candidates & ~c_lex_mask_below(cursor))
        {
            u64 start = (u64)__builtin_ctzll(rest);
            u64 end;
            if ((number_seed >> start) & 1)
            {
                u64 tail = ~(number_continue >> start);
                end = tail ? start + (u64)__builtin_ctzll(tail) : 64;
                if (end >= window_length)
                {
                    if (!at_end_of_file)
                    {
                        defer_at = start;
                        break;
                    }
                    end = window_length;
                }
                number_span |= c_lex_mask_range(start, end);
                number_starts |= (u64)1 << start;
            }
            else if (((line_comment_open | block_comment_open) >> start) & 1)
            {
                if ((line_comment_open >> start) & 1)
                {
                    u64 stop = line_feed & ~c_lex_mask_below(start);
                    if (stop)
                    {
                        // The newline that ends a line comment is its own
                        // token and is not part of the comment.
                        end = (u64)__builtin_ctzll(stop);
                    }
                    else if (at_end_of_file)
                    {
                        end = window_length;
                    }
                    else
                    {
                        defer_at = start;
                        break;
                    }
                }
                else
                {
                    u64 stop = block_comment_close & ~c_lex_mask_below(start + 2);
                    if (!stop)
                    {
                        // Unterminated at the end of the file is a diagnostic;
                        // otherwise the comment continues past this window.
                        if (at_end_of_file)
                        {
                            trigger_at = start;
                        }
                        else
                        {
                            defer_at = start;
                        }
                        break;
                    }
                    end = (u64)__builtin_ctzll(stop) + 2;
                    if (end >= window_length && !at_end_of_file)
                    {
                        defer_at = start;
                        break;
                    }
                }
                comment_span |= c_lex_mask_range(start, end);
                comment_starts |= (u64)1 << start;
            }
            else if ((ellipsis >> start) & 1)
            {
                // Nothing to record: the punctuator scan below finds it in
                // `available` like any other operator.  The cursor is the
                // whole point, so its third dot cannot also seed a number.
                end = start + 3;
            }
            else
            {
                // c_literal_prefix reads u8/u/U/L only at an item start, so a
                // quote preceded by word bytes is prefixed exactly when those
                // bytes are a one- or two-byte run of their own.
                u64 opener = start;
                if (start > cursor && ((word >> (start - 1)) & 1))
                {
                    u64 gaps = ~word & c_lex_mask_range(cursor, start);
                    u64 run_start = gaps ? (u64)(63 - __builtin_clzll(gaps)) + 1 : cursor;
                    u64 run_length = start - run_start;
                    u8 run_first = (u8)it[run_start];
                    if ((run_length == 1 && (run_first == 'u' || run_first == 'U' || run_first == 'L')) ||
                        (run_length == 2 && run_first == 'u' && (u8)it[run_start + 1] == '8'))
                    {
                        opener = run_start;
                    }
                }
                bool is_string = ((quote >> start) & 1) != 0;
                // The body begins after the delimiter, wherever the token did.
                u64 content = start + 1;
                // Escape-run parity, simdjson's backslash algorithm, scoped to
                // the literal body so a backslash before the opener cannot
                // escape the opening delimiter.
                u64 escaped = 0;
                u64 run = backslash & ~c_lex_mask_below(content);
                if (run)
                {
                    u64 run_starts = run & ~(run << 1);
                    u64 even_starts = run_starts & UINT64_C(0x5555555555555555);
                    u64 odd_starts = run_starts & UINT64_C(0xAAAAAAAAAAAAAAAA);
                    u64 even_ends = (run + even_starts) & ~run;
                    u64 odd_ends = (run + odd_starts) & ~run;
                    escaped = (even_ends & UINT64_C(0xAAAAAAAAAAAAAAAA)) | (odd_ends & UINT64_C(0x5555555555555555));
                }
                u64 terminator = (is_string ? quote : apostrophe) & ~escaped;
                u64 stop = (terminator | line_feed) & ~c_lex_mask_below(content);
                if (!stop)
                {
                    if (at_end_of_file)
                    {
                        trigger_at = opener;
                    }
                    else
                    {
                        defer_at = opener;
                    }
                    break;
                }
                u64 stop_at = (u64)__builtin_ctzll(stop);
                if (!((terminator >> stop_at) & 1))
                {
                    // A newline before the closing delimiter: unterminated,
                    // which the scalar path reports.
                    trigger_at = opener;
                    break;
                }
                end = stop_at + 1;
                if (end >= window_length && !at_end_of_file)
                {
                    defer_at = opener;
                    break;
                }
                literal_span |= c_lex_mask_range(opener, end);
                if (is_string)
                {
                    string_starts |= (u64)1 << opener;
                }
                else
                {
                    character_starts |= (u64)1 << opener;
                }
            }
            cursor = end;
        }

        u64 available = valid & ~comment_span & ~literal_span & ~number_span;
        u64 word_available = word & available;
        u64 identifier_starts = word_available & ~(word_available << 1);
        // Newlines are tokens wherever they appear, block comments included.
        u64 newline_starts = line_feed & valid;

        // Maximal munch over the punctuator runs.  A run holding no pair,
        // triple or quad candidate is nothing but single-byte tokens, so the
        // left-greedy walk runs only when a longer spelling opens somewhere
        // in the operator set — and it resolves starts alone: the ids blend
        // in registers below rather than patching an in-memory copy of the
        // singles vector and reloading it through the store queue.
        u64 operators = punctuator_byte & available;
        u64 multi = (punctuator2 | punctuator3 | punctuator4) & operators;
        u64 operator_starts = operators;
        __m512i punctuator_vector = single_vector;
        if (multi)
        {
            operator_starts = operators & ~(operators << 1) & ~(operators >> 1);
            for (u64 clustered = operators & ~operator_starts; clustered;)
            {
                u64 start = (u64)__builtin_ctzll(clustered);
                u64 bit = (u64)1 << start;
                u64 spelling_length = (punctuator4 & bit) ? 4 : (punctuator3 & bit) ? 3 : (punctuator2 & bit) ? 2 : 1;
                operator_starts |= bit;
                clustered &= ~c_lex_mask_below(start + spelling_length);
            }
            // The five blends (2026-08-10b's lead): pair ids come from the
            // same 16x16 cross-product table the scalar walk indexed,
            // addressed by the dense row and column keys of a spelling's two
            // bytes; triples index their first-byte table; the quad is the
            // one %:%: spelling.  Ids land on every candidate lane, start or
            // not, and the starts mask below selects the real ones, so the
            // rest may hold any table byte.  Every pair-candidate lane has
            // assigned keys — the NFA only legalizes spellings the tables
            // hold, which c_test_frontend_lex_differential proves
            // exhaustively — and the keys are at most 15, so the 16-bit
            // shift cannot carry a lane's row into its neighbour.
            const __m512i pair_row_low = _mm512_load_si512((const __m512i*)c_lex_pair_row);
            const __m512i pair_row_high = _mm512_load_si512((const __m512i*)(c_lex_pair_row + 64));
            const __m512i pair_column_low = _mm512_load_si512((const __m512i*)c_lex_pair_column);
            const __m512i pair_column_high = _mm512_load_si512((const __m512i*)(c_lex_pair_column + 64));
            __m512i pair_rows = _mm512_maskz_permutex2var_epi8((__mmask64)punctuator2, pair_row_low, chunk0, pair_row_high);
            __m512i pair_columns = _mm512_maskz_permutex2var_epi8((__mmask64)punctuator2, pair_column_low, chunk1, pair_column_high);
            __m512i pair_index = _mm512_or_si512(_mm512_slli_epi16(pair_rows, 4), pair_columns);
            const __m512i pair_table_0 = _mm512_load_si512((const __m512i*)&c_lex_pair_punctuators[0][0]);
            const __m512i pair_table_1 = _mm512_load_si512((const __m512i*)&c_lex_pair_punctuators[4][0]);
            const __m512i pair_table_2 = _mm512_load_si512((const __m512i*)&c_lex_pair_punctuators[8][0]);
            const __m512i pair_table_3 = _mm512_load_si512((const __m512i*)&c_lex_pair_punctuators[12][0]);
            __m512i pair_ids = _mm512_mask_mov_epi8(_mm512_permutex2var_epi8(pair_table_0, pair_index, pair_table_1),
                                                    _mm512_movepi8_mask(pair_index),
                                                    _mm512_permutex2var_epi8(pair_table_2, pair_index, pair_table_3));
            const __m512i triple_low = _mm512_load_si512((const __m512i*)c_lex_triple_punctuators);
            const __m512i triple_high = _mm512_load_si512((const __m512i*)(c_lex_triple_punctuators + 64));
            __m512i triple_ids = _mm512_maskz_permutex2var_epi8((__mmask64)punctuator3, triple_low, chunk0, triple_high);
            punctuator_vector = _mm512_mask_mov_epi8(punctuator_vector, (__mmask64)punctuator2, pair_ids);
            punctuator_vector = _mm512_mask_mov_epi8(punctuator_vector, (__mmask64)punctuator3, triple_ids);
            punctuator_vector = _mm512_mask_set1_epi8(punctuator_vector, (__mmask64)punctuator4, (char)C_PUNCTUATOR_HASH_HASH_DIGRAPH);
        }

        // Nothing left over may reach the emitter: a byte that is neither a
        // resolved span, an identifier byte, whitespace, a newline nor a
        // punctuator byte is C_TOKEN_INVALID, whose diagnostic the scalar path
        // formats.
        u64 unclassified = available & ~word & ~white & ~line_feed & ~punctuator_byte;
        // ASCII windows retain the existing uncommon-byte branch. High bytes
        // reuse the sign mask and escape at their whole word's start; only
        // resolved words before a deferred item matter. Comments and literals
        // keep their byte semantics.
        if (BUSTER_UNLIKELY(unclassified | high_byte))
        {
            if (unclassified)
            {
                u64 candidate = (u64)__builtin_ctzll(unclassified);
                trigger_at = BUSTER_MIN(trigger_at, candidate);
            }
            u64 word_high = high_byte & ~comment_span & ~literal_span & c_lex_mask_below(defer_at);
            if (word_high)
            {
                u64 first_high = (u64)__builtin_ctzll(word_high);
                u64 owners = (identifier_starts | number_starts) & c_lex_mask_below(first_high + 1);
                BUSTER_CHECK(owners);
                u64 candidate = (u64)(63 - __builtin_clzll(owners));
                trigger_at = BUSTER_MIN(trigger_at, candidate);
            }
        }

        u64 token_starts = identifier_starts | number_starts | string_starts | character_starts | operator_starts | newline_starts;
        // Bytes owned by no token: whitespace outside a literal, and comment
        // text other than the newlines a block comment contains.
        u64 comment_body = comment_span & ~line_feed;
        u64 non_token = (white & valid & ~literal_span) | comment_body;
        u64 token_span = valid & ~non_token;
        // Every position that begins something, so the byte before each one
        // ends the item in front of it.  Whitespace contributes per byte, as
        // the scalar loop consumes it, so a window of pure whitespace still
        // advances a whole window instead of one byte.
        u64 boundary = token_starts | (non_token & ~(non_token << 1)) | (white & valid & ~literal_span);

        u64 bound;
        bool escape_after = false;
        if (trigger_at < 64 && trigger_at <= defer_at)
        {
            bound = trigger_at;
            escape_after = true;
        }
        else if (defer_at < 64)
        {
            bound = defer_at;
        }
        else if (at_end_of_file)
        {
            bound = window_length;
        }
        else
        {
            BUSTER_CHECK(boundary);
            bound = (u64)(63 - __builtin_clzll(boundary));
        }

        u64 emitted = c_lex_mask_below(bound);
        // No span ever straddles the bound: a span's start is an item start,
        // and an incomplete one sets defer_at, so these popcounts are exact.
        result->metrics.blank_bytes += (u64)__builtin_popcountll((white | line_feed) & emitted & ~comment_span & ~literal_span);
        result->metrics.comment_bytes += (u64)__builtin_popcountll(comment_span & emitted);
        result->metrics.literal_bytes += (u64)__builtin_popcountll(literal_span & emitted);
        result->metrics.comments += (u64)__builtin_popcountll(comment_starts & emitted);

        // One finished line per newline in the window, classified by whether
        // any code or comment byte falls in the range since the last one.
        // All lines resolve at once: subtracting a segment's marks from the
        // newline mask borrows through exactly that segment -- marks between
        // two newlines sum below the higher newline's bit, so the borrow
        // clears it and stops -- and the cleared newlines are the lines
        // holding a mark.  Marks above the last newline are the next window's
        // carry and stay out of the subtraction.
        u64 code_bytes = token_span & ~line_feed & emitted;
        u64 comment_bytes = comment_span & emitted;
        u64 newlines = newline_starts & emitted;
        if (newlines)
        {
            u64 last = (u64)(63 - __builtin_clzll(newlines));
            u64 below_last = c_lex_mask_below(last);
            u64 first_line = newlines & (~newlines + 1);
            u64 lines_with_code = newlines & ~(newlines - (code_bytes & below_last));
            u64 lines_with_comment = newlines & ~(newlines - (comment_bytes & below_last & ~newlines));
            // A newline inside a block comment leaves the comment open, so
            // the next line is a comment line too; the carried state does the
            // same for the first line.
            u64 open_comment_newlines = comment_span & newlines & below_last;
            lines_with_comment |= newlines & ~(newlines - (open_comment_newlines << 1));
            if (state->line_has_code)
            {
                lines_with_code |= first_line;
            }
            if (state->line_has_comment)
            {
                lines_with_comment |= first_line;
            }
            u64 line_count = (u64)__builtin_popcountll(newlines);
            result->metrics.translated_lines += line_count;
            result->metrics.code_lines += (u64)__builtin_popcountll(lines_with_code);
            result->metrics.comment_lines += (u64)__builtin_popcountll(lines_with_comment);
            result->metrics.mixed_lines += (u64)__builtin_popcountll(lines_with_code & lines_with_comment);
            result->metrics.blank_lines += line_count - (u64)__builtin_popcountll(lines_with_code | lines_with_comment);
            u64 above_last = ~c_lex_mask_below(last + 1);
            state->line_has_code = (code_bytes & above_last) != 0;
            state->line_has_comment = (u32)((comment_span >> last) & 1) | ((comment_bytes & above_last) != 0);
            state->line_start = offset + last + 1;
        }
        else
        {
            state->line_has_code |= code_bytes != 0;
            state->line_has_comment |= comment_bytes != 0;
        }
        state->newline_tokens += (u64)__builtin_popcountll(newlines);

        if (bound)
        {
            // Each emission bound is a window position or its length (64 max).
            BUSTER_CHECK(bound <= 64);
            // Starts and ends compress through the token-boundary masks, one
            // byte subtract yields every length in the window, and the kind
            // and punctuator vectors ride the same starts mask.
            u64 start_mask = token_starts & emitted;
            // `emitted` is a contiguous low-bit mask. Its highest bit marks
            // the final lane without a variable shift at the 64-byte edge.
            u64 final_lane = emitted & ~(emitted >> 1);
            u64 end_mask = ((boundary >> 1) | final_lane) & token_span & emitted;
            u32 count = (u32)__builtin_popcountll(start_mask);
            BUSTER_CHECK(count == (u32)__builtin_popcountll(end_mask));

            __m512i kind_vector = _mm512_maskz_set1_epi8((__mmask64)newline_starts, (char)C_TOKEN_NEWLINE);
            kind_vector = _mm512_mask_set1_epi8(kind_vector, (__mmask64)identifier_starts, (char)C_TOKEN_IDENTIFIER);
            kind_vector = _mm512_mask_set1_epi8(kind_vector, (__mmask64)number_starts, (char)C_TOKEN_PREPROCESSING_NUMBER);
            kind_vector = _mm512_mask_set1_epi8(kind_vector, (__mmask64)operator_starts, (char)C_TOKEN_PUNCTUATOR);
            kind_vector = _mm512_mask_set1_epi8(kind_vector, (__mmask64)string_starts, (char)C_TOKEN_STRING_LITERAL);
            kind_vector = _mm512_mask_set1_epi8(kind_vector, (__mmask64)character_starts, (char)C_TOKEN_CHARACTER_LITERAL);

            __m512i start_positions = _mm512_maskz_compress_epi8((__mmask64)start_mask, iota);
            __m512i end_positions = _mm512_maskz_compress_epi8((__mmask64)end_mask, iota);
            __m512i lengths = _mm512_add_epi8(_mm512_sub_epi8(end_positions, start_positions), _mm512_set1_epi8(1));
            __m512i kinds = _mm512_maskz_compress_epi8((__mmask64)start_mask, kind_vector);
            // A non-punctuator start keeps whatever its first byte spells —
            // `.` opening a number, say — so the field is cleared first.
            __m512i punctuator_ids =
                _mm512_maskz_compress_epi8((__mmask64)start_mask, _mm512_maskz_mov_epi8((__mmask64)operator_starts, punctuator_vector));
            __m512i punctuator_shapes = _mm512_or_si512(punctuator_vector, _mm512_set1_epi8((char)C_TOKEN_SHAPE_PUNCTUATOR));
            __m512i shape_vector = _mm512_mask_mov_epi8(kind_vector, (__mmask64)operator_starts, punctuator_shapes);
            __m512i shapes = _mm512_maskz_compress_epi8((__mmask64)start_mask, shape_vector);

            CToken* out = result->tokens + result->token_count;
            CTokenShape* shapes_out = result->token_shapes + result->token_count;
            __m512i base = _mm512_set1_epi32((s32)(u32)((u64)translated_offset + offset));
            // Sixteen rows per pass, tail rows included: the token array
            // carries sixteen slots of slack and the next window overwrites
            // them.  76% of emitting windows carry 15 or fewer tokens (the
            // 2026-08-22T140940Z census), so the mean window is one pass
            // where the 8-row store was two plus a lane rotation.  The first
            // pass is unconditional on purpose — guarding it on a non-empty
            // window measured +2.0 M stage-1 instructions, because a window
            // with no token at all needs 64 bytes of whitespace or comment,
            // which escapes to the scalar scanner long before it reaches
            // here.
            for (u32 written = 0;;)
            {
                u32 shape_count = BUSTER_MIN(count - written, UINT32_C(16));
                c_lex_store_rows(out + written, shapes_out + written, c_lex_mask_below(shape_count), start_positions, lengths, kinds, punctuator_ids,
                                 shapes, base, row_index_0, row_index_1, row_index_2);
                written += 16;
                if (written >= count)
                {
                    break;
                }
                start_positions = _mm512_alignr_epi32(start_positions, start_positions, 4);
                lengths = _mm512_alignr_epi32(lengths, lengths, 4);
                kinds = _mm512_alignr_epi32(kinds, kinds, 4);
                punctuator_ids = _mm512_alignr_epi32(punctuator_ids, punctuator_ids, 4);
                shapes = _mm512_alignr_epi32(shapes, shapes, 4);
            }
            result->token_count += count;
            offset += bound;
            if (!escape_after)
            {
                continue;
            }
        }

        // Either the window holds one unfinished item or a scalar-escape
        // trigger sits at the emission bound: scan exactly that item with the
        // reference scanner and re-enter the window loop after it.
        offset = c_lex_scan_one(state, offset);
    }
}

#endif

#if BUSTER_INCLUDE_TESTS
bool c_test_lex_compact_tables_ready(void)
{
#if BUSTER_C_LEX_COMPACT
    return c_lex_compact_tables_built;
#else
    return true;
#endif
}

// Test seam: the one-instruction lane-prefix mask against its portable
// reference, over the whole domain the emitter forms indices in — every window
// position and every position a punctuator spelling carries past the last of
// them. Counting mismatches keeps the sweep to one test assertion.
u64 c_test_lex_mask_below_mismatches(void)
{
    u64 result = 0;
#if BUSTER_C_LEX_COMPACT
    for (u64 bit_index = 0; bit_index < C_LEX_MASK_BELOW_LIMIT; bit_index += 1)
    {
        result += c_lex_mask_below(bit_index) != c_lex_mask_below_reference(bit_index);
    }
#endif
    return result;
}

// Test seam: reconcile the emitter's hand-assigned NFA channels with the
// spelling table the scalar path scans. For every byte sequence the window
// pipeline can classify, the channels must legalize exactly the spellings
// c_punctuator_length finds, at exactly its length. Counting mismatches keeps
// the exhaustive sweep to one test assertion.
u64 c_test_lex_punctuator_nfa_mismatches(void)
{
#if BUSTER_C_LEX_COMPACT
    if (!c_lex_compact_tables_built)
    {
        c_lex_compact_tables_build();
    }
    if (!c_punctuator_dispatch_built)
    {
        c_punctuator_dispatch_build();
    }
    u64 mismatches = 0;
    char8 probe[4];
    for (u32 first = 0; first < 128; first += 1)
    {
        if (!c_lex_single_punctuators[first])
        {
            continue;
        }
        for (u32 second = 0; second < 256; second += 1)
        {
            for (u32 third = 0; third < 256; third += 1)
            {
                // The fourth byte only ever matters to %:%:, so it sweeps just
                // that prefix instead of multiplying the whole cross product.
                u32 fourth_low = 0;
                u32 fourth_high = 1;
                if (first == '%' && second == ':' && third == '%')
                {
                    fourth_high = 256;
                }
                for (u32 fourth = fourth_low; fourth < fourth_high; fourth += 1)
                {
                    probe[0] = (char8)first;
                    probe[1] = (char8)second;
                    probe[2] = (char8)third;
                    probe[3] = (char8)fourth;
                    // What the emitter's channels decide. Bytes above ASCII
                    // zero their lookups, exactly as the maskz permutes do.
                    u8 first_bits = c_lex_nfa_first[first];
                    u8 second_bits = second < 128 ? c_lex_nfa_second[second] : 0;
                    u8 third_bits = third < 128 ? c_lex_nfa_third[third] : 0;
                    u8 pair = first_bits & second_bits;
                    u8 triple = pair & third_bits;
                    bool repeated = first == second;
                    bool is_four = first == '%' && second == ':' && third == '%' && fourth == ':';
                    bool is_three = (triple & C_LEX_NFA_ELLIPSIS) != 0 || ((triple & C_LEX_NFA_SHIFT_ASSIGN) != 0 && repeated);
                    bool is_two = (pair & C_LEX_NFA_PAIR_CHANNELS) != 0 || ((pair & C_LEX_NFA_DOUBLE) != 0 && repeated);
                    u64 emitted_length = is_four ? 4 : is_three ? 3 : is_two ? 2 : 1;
                    u8 emitted_punctuator = (u8)C_PUNCTUATOR_HASH_HASH_DIGRAPH;
                    if (emitted_length == 3)
                    {
                        emitted_punctuator = c_lex_triple_punctuators[first];
                    }
                    else if (emitted_length == 2)
                    {
                        u8 row = c_lex_pair_row[first];
                        u8 column = second < 128 ? c_lex_pair_column[second] : 0xFF;
                        emitted_punctuator = row == 0xFF || column == 0xFF ? 0 : c_lex_pair_punctuators[row][column];
                    }
                    else if (emitted_length == 1)
                    {
                        emitted_punctuator = c_lex_single_punctuators[first];
                    }
                    CPunctuator reference = C_PUNCTUATOR_NONE;
                    u64 reference_length = c_punctuator_length((String8){probe, BUSTER_ARRAY_LENGTH(probe)}, 0, &reference);
                    mismatches += emitted_length != reference_length || emitted_punctuator != (u8)reference;
                }
            }
        }
    }
    return mismatches;
#else
    return 0;
#endif
}
#endif

BUSTER_C_INTERNAL CLexResult c_lex_dispatch(Arena* arena, CSpellingSpace* space, String8 source, bool force_scalar)
{
    CLexResult result = {0};
    if (arena && (!source.length || source.pointer))
    {
        CTranslatedSource translated = c_translate_source(arena, space, source, force_scalar);
        result.translated_source = translated.source;
        result.spelling_base = space ? space->base : translated.source.pointer;
        result.checkpoints = translated.checkpoints;
        result.checkpoint_offsets = translated.checkpoint_offsets;
        result.checkpoint_pages = translated.checkpoint_pages;
        result.checkpoint_page_count = translated.checkpoint_page_count;
        result.checkpoint_count = translated.checkpoint_count;
        result.translated_offset = translated.translated_offset;
        // One token per byte bounds the stream including the end marker exactly as
        // the scalar loop needs; sixteen more absorb the tail rows of the emitter's
        // full-width interleaved stores, which the next window overwrites.
        u64 token_capacity = translated.source.length + 1 + 16;
        result.tokens = arena_allocate(arena, CToken, token_capacity);
        result.token_shapes = arena_allocate(arena, CTokenShape, token_capacity);
        if (translated.source.length <= UINT64_MAX / sizeof(CDiagnostic) - 1)
        {
            u64 diagnostic_bytes = (translated.source.length + 1) * sizeof(CDiagnostic);
            if (diagnostic_bytes <= (UINT64_MAX - BUSTER_MB(1)) / 2)
            {
                u64 diagnostic_reserve_size = diagnostic_bytes * 2 + BUSTER_MB(1);
                Arena* conflicts[] = {
                    arena,
                };
                TemporalArena diagnostic_temporary = scratch_begin(conflicts, BUSTER_ARRAY_LENGTH(conflicts));
                Arena* diagnostic_arena = diagnostic_temporary.arena;
                bool diagnostic_arena_is_scratch = diagnostic_reserve_size <= diagnostic_arena->reserved_size - diagnostic_arena->position;
                if (!diagnostic_arena_is_scratch)
                {
                    scratch_end(diagnostic_temporary);
                    diagnostic_arena = arena_create((ArenaCreation){
                        .reserved_size = BUSTER_MAX(BUSTER_MB(64), diagnostic_reserve_size),
                    });
                }
                if (diagnostic_arena)
                {
                    CLexState state = {
                        .result = &result,
                        .translated = translated,
                        .diagnostic_arena = diagnostic_arena,
                        .maximum_diagnostic_count = translated.source.length + 1,
                    };
                    state.diagnostic_capacity = BUSTER_MIN(state.maximum_diagnostic_count, UINT64_C(64));
                    result.diagnostics = arena_allocate(diagnostic_arena, CDiagnostic, state.diagnostic_capacity);
                    // Source measurement rides the branches the lexer already takes; see
                    // CSourceMetrics.
                    result.metrics.files = 1;
                    result.metrics.bytes = source.length;
                    result.metrics.translated_bytes = translated.source.length;
                    result.metrics.lines = translated.raw_lines;
#if BUSTER_C_LEX_COMPACT
                    if (force_scalar)
                    {
                        c_lex_scalar(&state);
                    }
                    else
                    {
                        state.simd_scan = 1;
                        c_lex_compact(&state);
                    }
#else
                    BUSTER_UNUSED(force_scalar);
                    c_lex_scalar(&state);
#endif
                    // A file whose last line has no terminating newline still ends a line.
                    if (translated.source.length > state.line_start)
                    {
                        c_source_metrics_line(&result.metrics, state.line_has_code, state.line_has_comment);
                    }
                    result.metrics.spliced_lines = result.metrics.lines - result.metrics.translated_lines;
                    result.metrics.tokens = result.token_count - state.newline_tokens;
                    c_token_push(&result, translated, translated.source.length, translated.source.length, C_TOKEN_END_OF_FILE, C_PUNCTUATOR_NONE);
                    CDiagnostic* diagnostics = arena_allocate(arena, CDiagnostic, result.diagnostic_count);
                    if (result.diagnostic_count)
                    {
                        memcpy(diagnostics, result.diagnostics, sizeof(*diagnostics) * result.diagnostic_count);
                    }
                    result.diagnostics = diagnostics;
                    if (diagnostic_arena_is_scratch)
                    {
                        scratch_end(diagnostic_temporary);
                    }
                    else
                    {
                        arena_destroy(diagnostic_arena, 1);
                    }
                }
            }
        }
    }

    return result;
}

BUSTER_C_INTERNAL CLexResult c_lex_space(Arena* arena, CSpellingSpace* space, String8 source)
{
    return c_lex_dispatch(arena, space, source, false);
}

CLexResult c_lex(Arena* arena, String8 source)
{
    return c_lex_dispatch(arena, 0, source, false);
}

// The scalar reference loop, whatever the host: the differential gate asserts
// the dispatched lexer agrees with it byte for byte.
CLexResult c_lex_reference(Arena* arena, String8 source)
{
    return c_lex_dispatch(arena, 0, source, true);
}

typedef struct CMacro CMacro;
typedef struct CMacroDefinition CMacroDefinition;
struct CMacroDefinition
{
    CToken* replacement;
    // One byte per replacement token: was it written after white space? A
    // macro is expanded far more often than it is defined, and `#` needs
    // this for every argument substituted into the list, so it is derived
    // once here (c_macro_replacement_spaces) instead of on every expansion.
    // Null on the builtin marker definitions, whose spellings are
    // synthesized one at a time and read as spaced; index 0 is unused,
    // because the first replacement token takes the invocation's spacing.
    u8* replacement_space;
    String8* parameters;
    // One word per replacement token: the index of the parameter it names,
    // or C_MACRO_PARAMETER_NONE. Computed once at definition (c_macro_define)
    // so substitution reads a word per token instead of comparing the
    // token's spelling against every parameter name on every expansion.
    // Null when the replacement list is empty.
    u32* parameter_index;
    // Ordinary substitution uses per parameter, excluding stringization and
    // either side of a paste. Zero means argument prescan is unnecessary;
    // raw tokens remain available to # and ##. In a paste/stringize-free
    // definition every use is ordinary, so this also retains the exact
    // replacement-capacity dot product. Null when there are no parameters.
    u32* parameter_expand_count;
    u32 replacement_count;
    // The replacement tokens that name no parameter: the fixed half of that
    // capacity.
    u32 plain_count;
    u32 parameter_count;
    bool defined;
    bool function_like;
    bool variadic;
    bool pragma_like;
    // Does the list hold a `##`, and a `#` that stringifies a parameter?
    // 78,3% of the expansions of a unity build have neither and 99,97% have
    // no `#` at all, and that is the whole difference between substituting
    // the list in one pass into its final array and staging it in a wider
    // row for a paste pass with nothing to do.
    bool has_paste;
    bool has_stringify;
};

#define C_MACRO_PARAMETER_NONE UINT32_MAX

typedef enum CMacroBuiltin
{
    C_MACRO_BUILTIN_NONE,
    C_MACRO_BUILTIN_LINE,
    C_MACRO_BUILTIN_FILE,
} CMacroBuiltin;

struct CMacro
{
    CMacro* next;
    // Head-of-list state: the macro named by each interned symbol id, or
    // null. A symbol id is a dense small integer the identifier token
    // already carries, so the hot question of the line loop and the
    // expansion rescan — does this identifier name a macro at all? — is one
    // indexed load with no hashing and no chain, and the ~95% of identifiers
    // that name nothing never touch a CMacro record. Sized to the symbol
    // table's id capacity when built and regrown from the list on the rare
    // definition whose id lies past it (c_macro_index_rebuild).
    CMacro** by_symbol;
    String8 name;
    u32 symbol;
    CMacroDefinition definition;
    u32 by_symbol_capacity;
    bool disabled;
    u8 builtin;
    // Head-of-list state for the lazy builtin macros: the main preprocess
    // loop stores the current frame and token offset here each iteration
    // (two stores, no location recovery), and __LINE__/__FILE__ recover the
    // logical line from them only when actually expanded.
    u32 builtin_line;
    struct CPreprocessSourceFrame* builtin_frame;
    u32 builtin_token_offset;
    String8 builtin_path;
};

typedef struct CMacroPushMacro CMacroPushMacro;
struct CMacroPushMacro
{
    CMacroPushMacro* previous;
    CMacro* macro;
    String8 name;
    CMacroDefinition definition;
};

BUSTER_C_SHARED u64 c_macro_name_hash(String8 name)
{
    u64 hash = 1469598103934665603ull;
    for (u64 index = 0; index < name.length; index += 1)
    {
        hash ^= name.pointer[index];
        hash *= 1099511628211ull;
    }
    return hash;
}

// Rebuild the symbol index over every macro in the list at `capacity`
// entries; the caller guarantees every defined symbol id lies below it.
BUSTER_C_INTERNAL void c_macro_index_rebuild(Arena* arena, CMacro* first, u32 capacity)
{
    BUSTER_VALIDATE(first && capacity);
    CMacro** by_symbol = arena_allocate(arena, CMacro*, capacity);
    memset(by_symbol, 0, sizeof(*by_symbol) * capacity);
    for (CMacro* macro = first; macro; macro = macro->next)
    {
        BUSTER_VALIDATE(macro->symbol < capacity);
        by_symbol[macro->symbol] = macro;
    }
    first->by_symbol = by_symbol;
    first->by_symbol_capacity = capacity;
}

// Identifier interning: the preprocessor assigns every identifier token a
// u32 symbol id (stored in token.symbol) so downstream consumers compare
// integers instead of re-hashing and re-comparing spellings. The well-known
// names take the ids below C_SYMBOL_WELL_KNOWN_COUNT, and the names in the
// table below are interned next, in array order, so their ids are the
// compile-time-known range [C_SYMBOL_WELL_KNOWN_COUNT,
// C_SYMBOL_WELL_KNOWN_COUNT + C_SYMBOL_PREDEFINED_COUNT) and one dense byte
// table classifies them. Tokens that never pass through the intern pass
// (pasted, synthesized, or test-built tokens) keep symbol 0 and every
// consumer falls back to the spelling ladder, so a missed path costs speed,
// never correctness.
typedef struct CSymbolPredefined CSymbolPredefined;
struct CSymbolPredefined
{
    String8 name;
    u8 builtin;
};

BUSTER_C_INTERNAL CSymbolPredefined const c_symbol_predefined[] = {
    { S8_INITIALIZER("__builtin_expect"), C_SYMBOL_BUILTIN_EXPECT },
    { S8_INITIALIZER("__builtin_expect_with_probability"), C_SYMBOL_BUILTIN_EXPECT },
    { S8_INITIALIZER("__builtin_constant_p"), C_SYMBOL_BUILTIN_CONSTANT_P },
    { S8_INITIALIZER("__builtin_choose_expr"), C_SYMBOL_BUILTIN_CHOOSE_EXPR },
    { S8_INITIALIZER("__builtin_types_compatible_p"), C_SYMBOL_BUILTIN_TYPES_COMPATIBLE_P },
    { S8_INITIALIZER("__builtin_object_size"), C_SYMBOL_BUILTIN_OBJECT_SIZE },
    { S8_INITIALIZER("__builtin_assume_aligned"), C_SYMBOL_BUILTIN_ASSUME_ALIGNED },
    { S8_INITIALIZER("__builtin_debugtrap"), C_SYMBOL_BUILTIN_DEBUGTRAP },
    { S8_INITIALIZER("__builtin_trap"), C_SYMBOL_BUILTIN_DEBUGTRAP },
    // Clang's emmintrin.h carries only `void _mm_pause(void);` -- the
    // definition lives in the compiler -- so a dialect that consumes clang
    // headers must know the name or every SSE2 spin loop leaves an
    // unresolved symbol behind.
    { S8_INITIALIZER("_mm_pause"), C_SYMBOL_BUILTIN_SPIN_PAUSE },
    { S8_INITIALIZER("__builtin_ia32_pause"), C_SYMBOL_BUILTIN_SPIN_PAUSE },
    // Clang's SSE2 headers lower immediate vector shifts through these
    // compiler-owned spellings. Their implementation is canonical vector
    // IR and is therefore independent of the selected native backend.
    { S8_INITIALIZER("__builtin_ia32_pslldi128"), C_SYMBOL_BUILTIN_SSE2_IMMEDIATE_SHIFT },
    { S8_INITIALIZER("__builtin_ia32_psllqi128"), C_SYMBOL_BUILTIN_SSE2_IMMEDIATE_SHIFT },
    { S8_INITIALIZER("__builtin_ia32_psradi128"), C_SYMBOL_BUILTIN_SSE2_IMMEDIATE_SHIFT },
    { S8_INITIALIZER("__builtin_ia32_psrldi128"), C_SYMBOL_BUILTIN_SSE2_IMMEDIATE_SHIFT },
    { S8_INITIALIZER("__builtin_ia32_psrlqi128"), C_SYMBOL_BUILTIN_SSE2_IMMEDIATE_SHIFT },
    { S8_INITIALIZER("__builtin_unreachable"), C_SYMBOL_BUILTIN_UNREACHABLE },
    { S8_INITIALIZER("__builtin_frame_address"), C_SYMBOL_BUILTIN_FRAME_ADDRESS },
    { S8_INITIALIZER("__builtin_alloca"), C_SYMBOL_BUILTIN_ALLOCA },
    { S8_INITIALIZER("__builtin_complex"), C_SYMBOL_BUILTIN_COMPLEX },
    { S8_INITIALIZER("__builtin_strlen"), C_SYMBOL_BUILTIN_STRLEN },
    { S8_INITIALIZER("__builtin___clear_cache"), C_SYMBOL_BUILTIN_CLEAR_CACHE },
    { S8_INITIALIZER("__builtin_prefetch"), C_SYMBOL_BUILTIN_PREFETCH },
    { S8_INITIALIZER("__builtin_va_arg"), C_SYMBOL_BUILTIN_VA_ARG },
    { S8_INITIALIZER("__builtin_va_start"), C_SYMBOL_BUILTIN_VA_START },
    { S8_INITIALIZER("__va_start"), C_SYMBOL_BUILTIN_VA_START },
    { S8_INITIALIZER("__builtin_c23_va_start"), C_SYMBOL_BUILTIN_VA_START_C23 },
    { S8_INITIALIZER("__builtin_va_copy"), C_SYMBOL_BUILTIN_VA_COPY },
    { S8_INITIALIZER("__builtin_va_end"), C_SYMBOL_BUILTIN_VA_END },
    { S8_INITIALIZER("_Generic"), C_SYMBOL_BUILTIN_GENERIC },
    { S8_INITIALIZER("__c11_atomic_load"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_store"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_init"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_fetch_add"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_fetch_sub"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_fetch_and"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_fetch_or"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_fetch_xor"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_exchange"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_compare_exchange_strong"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_compare_exchange_weak"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_is_lock_free"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_thread_fence"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__c11_atomic_signal_fence"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__sync_synchronize"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__sync_fetch_and_nand"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__sync_nand_and_fetch"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_load"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_store"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_exchange"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_compare_exchange"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_load_n"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_store_n"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_exchange_n"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_fetch_add"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_fetch_sub"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_fetch_and"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_fetch_or"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_fetch_xor"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_fetch_nand"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_add_fetch"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_sub_fetch"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_and_fetch"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_or_fetch"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_xor_fetch"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_nand_fetch"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_compare_exchange_n"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_thread_fence"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_signal_fence"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_is_lock_free"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_always_lock_free"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_test_and_set"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__atomic_clear"), C_SYMBOL_BUILTIN_ATOMIC },
    { S8_INITIALIZER("__builtin_floorf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_floor"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_ceilf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_ceil"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_sqrtf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_sqrt"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_powf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_pow"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_fmodf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_fmod"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_cosf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_cos"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_acosf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_acos"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_fabsf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_fabs"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_roundf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_round"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_inff"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_nanf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_nan"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_huge_val"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_isnanf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_isnan"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_isinf_sign"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_isinf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_isinff"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_isfinite"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_signbit"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_signbitf"), C_SYMBOL_BUILTIN_MATH },
    { S8_INITIALIZER("__builtin_signbitl"), C_SYMBOL_BUILTIN_MATH },
    // The block-memory family. Clang declares these without <string.h>, so
    // freestanding sources spell their copies this way once __clang__ is
    // defined; lowering routes them to the ordinary library call.
    { S8_INITIALIZER("__builtin_memcpy"), C_SYMBOL_BUILTIN_MEMORY },
    { S8_INITIALIZER("__builtin_memmove"), C_SYMBOL_BUILTIN_MEMORY },
    { S8_INITIALIZER("__builtin_memset"), C_SYMBOL_BUILTIN_MEMORY },
    { S8_INITIALIZER("__builtin_memcmp"), C_SYMBOL_BUILTIN_MEMORY },
    { S8_INITIALIZER("__builtin___memcpy_chk"), C_SYMBOL_BUILTIN_MEMORY },
    { S8_INITIALIZER("__builtin___memmove_chk"), C_SYMBOL_BUILTIN_MEMORY },
    { S8_INITIALIZER("__builtin___memset_chk"), C_SYMBOL_BUILTIN_MEMORY },
    { S8_INITIALIZER("__builtin_clz"), C_SYMBOL_BUILTIN_COUNT_LEADING_ZEROS },
    // The `l` spellings take unsigned long, which is target-dependent (LP64
    // versus LLP64). The shared signature policy below selects their operand
    // width before the count operation; all these spellings return int.
    { S8_INITIALIZER("__builtin_clzl"), C_SYMBOL_BUILTIN_COUNT_LEADING_ZEROS },
    { S8_INITIALIZER("__builtin_clzll"), C_SYMBOL_BUILTIN_COUNT_LEADING_ZEROS },
    { S8_INITIALIZER("__builtin_ctz"), C_SYMBOL_BUILTIN_COUNT_TRAILING_ZEROS },
    { S8_INITIALIZER("__builtin_ctzl"), C_SYMBOL_BUILTIN_COUNT_TRAILING_ZEROS },
    { S8_INITIALIZER("__builtin_ctzll"), C_SYMBOL_BUILTIN_COUNT_TRAILING_ZEROS },
    { S8_INITIALIZER("__builtin_ffs"), C_SYMBOL_BUILTIN_FIND_FIRST_SET },
    { S8_INITIALIZER("__builtin_ffsl"), C_SYMBOL_BUILTIN_FIND_FIRST_SET },
    { S8_INITIALIZER("__builtin_ffsll"), C_SYMBOL_BUILTIN_FIND_FIRST_SET },
    { S8_INITIALIZER("__builtin_popcount"), C_SYMBOL_BUILTIN_POPULATION_COUNT },
    { S8_INITIALIZER("__builtin_popcountl"), C_SYMBOL_BUILTIN_POPULATION_COUNT },
    { S8_INITIALIZER("__builtin_popcountll"), C_SYMBOL_BUILTIN_POPULATION_COUNT },
    // The target-fixed 512-bit vocabulary. These names are a buster extension
    // and exist so `<buster/lib/simd.h>` can write one kernel that the host
    // compilers and the self-hosted stages both compile; see the SIMD section
    // of AGENTS.md before adding to the list.
    { S8_INITIALIZER("__builtin_buster_simd_load"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_load_masked"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_store"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_store_masked"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_splat_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_equal_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_less_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_sign_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_test_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_permute2_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_compress_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_compress_store_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_widen_byte"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_shift_left_word"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_ternary_word"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_equal_word"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_splat_word"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_less_word"), C_SYMBOL_BUILTIN_SIMD },
    { S8_INITIALIZER("__builtin_buster_simd_compress_word"), C_SYMBOL_BUILTIN_SIMD },
};

#define C_SYMBOL_PREDEFINED_COUNT BUSTER_ARRAY_LENGTH(c_symbol_predefined)

// Dense kind classification for interned symbols; every id at or below
// predefined_limit indexes it, and the ids that are not builtins — 0, the
// well-known names, the keywords and the classified extras — stay
// C_SYMBOL_BUILTIN_NONE.
// The cold path for symbol-less identifier tokens: the same classification
// by spelling, scanning the single source-of-truth table above.
BUSTER_C_SHARED CSymbolBuiltin c_symbol_builtin_from_spelling(String8 spelling)
{
    if (spelling.length && spelling.pointer[0] == '_')
    {
        for (u64 index = 0; index < C_SYMBOL_PREDEFINED_COUNT; index += 1)
        {
            if (string_equal(spelling, c_symbol_predefined[index].name))
            {
                return (CSymbolBuiltin)c_symbol_predefined[index].builtin;
            }
        }
    }

    return C_SYMBOL_BUILTIN_NONE;
}

// Fixed GNU signatures for clz/ctz/popcount. The operation kind is shared by
// three spellings; the suffix determines the parameter width, while the C
// result type is always int. CTypeKind retains the target's long data model.
CTypeKind c_semantic_integer_count_parameter_kind(CSymbolBuiltin builtin, String8 spelling)
{
    CTypeKind result = C_TYPE_INVALID;
    if (builtin == C_SYMBOL_BUILTIN_COUNT_LEADING_ZEROS || builtin == C_SYMBOL_BUILTIN_COUNT_TRAILING_ZEROS ||
        builtin == C_SYMBOL_BUILTIN_POPULATION_COUNT)
    {
        result = string_ends_with_sequence(spelling, S8("ll")) ? C_TYPE_UNSIGNED_LONG_LONG :
                 string_ends_with_sequence(spelling, S8("l")) ? C_TYPE_UNSIGNED_LONG : C_TYPE_UNSIGNED_INT;
    }
    return result;
}

// One probe entry of the intern table. The identity of a name is its first
// and last 8 bytes plus its length: for names up to 16 bytes the two
// overlapped words cover every byte, so matching (low, high, length) is byte
// equality with no further loads; longer names use the triple as a 17-byte
// filter and verify only the middle bytes against the stored spelling.
// length_and_id packs (length << 32) | id, and 0 marks an empty slot (id 0
// is never assigned).
struct CSymbolSlot
{
    u64 low;
    u64 high;
    u64 length_and_id;
};

typedef struct CSymbolKey
{
    u64 low;
    u64 high;
} CSymbolKey;

BUSTER_C_INTERNAL CSymbolKey c_symbol_key(String8 name)
{
    CSymbolKey key = {0};
    if (name.length >= 8)
    {
        memcpy(&key.low, name.pointer, sizeof(key.low));
        memcpy(&key.high, name.pointer + name.length - 8, sizeof(key.high));
    }
    else
    {
        // The bytes of a name shorter than the low word, gathered by the set
        // bits of its own length. Every read stays inside [pointer, pointer +
        // length), so no padding is assumed of the spelling space or of the
        // string literals the table is seeded from, and the byte loop's
        // one-to-seven trip count — half of every intern on a unity build is
        // a name this short — becomes three tests whose outcomes the length
        // already decides.
        u64 offset = 0;
        if (name.length & 4)
        {
            u32 quarter;
            memcpy(&quarter, name.pointer, sizeof(quarter));
            key.low = quarter;
            offset = 4;
        }
        if (name.length & 2)
        {
            u16 half;
            memcpy(&half, name.pointer + offset, sizeof(half));
            key.low |= (u64)half << (8 * offset);
            offset += 2;
        }
        if (name.length & 1)
        {
            key.low |= (u64)(u8)name.pointer[offset] << (8 * offset);
        }
    }
    return key;
}

// Differences in the top bytes of a key word only propagate upward through a
// multiply, so the slot bits must come from a folded value: fold the first
// product's high word down, remultiply, and take the high half.
BUSTER_C_INTERNAL u32 c_symbol_slot_hash(CSymbolKey key, u64 length)
{
    u64 hash = key.low * UINT64_C(0x9E3779B97F4A7C15) ^ key.high * UINT64_C(0xC2B2AE3D27D4EB4F) ^ length;
    hash ^= hash >> 32;
    hash *= UINT64_C(0xD6E8FEB86659FD93);
    return (u32)(hash >> 32);
}

// Both spellings already match on their first 8 bytes, last 8 bytes, and
// length (> 16); confirm the middle [8, length - 8) in overlapped words.
BUSTER_C_INTERNAL bool c_symbol_middle_equal(String8 stored, String8 name)
{
    u64 end = name.length - 8;
    u64 offset = 8;
    for (; offset + 8 <= end; offset += 8)
    {
        u64 stored_word;
        u64 name_word;
        memcpy(&stored_word, stored.pointer + offset, sizeof(stored_word));
        memcpy(&name_word, name.pointer + offset, sizeof(name_word));
        if (stored_word != name_word)
        {
            return false;
        }
    }
    u64 stored_word;
    u64 name_word;
    memcpy(&stored_word, stored.pointer + end - 8, sizeof(stored_word));
    memcpy(&name_word, name.pointer + end - 8, sizeof(name_word));
    return stored_word == name_word;
}

BUSTER_C_SHARED u32 c_symbol_intern(CSymbolTable* table, String8 name)
{
    CSymbolKey key = c_symbol_key(name);
    u64 length_word = (u64)name.length << 32;
    u32 mask = table->slot_capacity - 1;
    u32 slot = c_symbol_slot_hash(key, name.length) & mask;
    for (;;)
    {
        CSymbolSlot* entry = &table->slots[slot];
        u64 length_and_id = entry->length_and_id;
        if (!length_and_id)
        {
            break;
        }
        if (entry->low == key.low && entry->high == key.high && (length_and_id & UINT64_C(0xFFFFFFFF00000000)) == length_word)
        {
            u32 id = (u32)length_and_id;
            if (name.length <= 16 || c_symbol_middle_equal(table->names[id], name))
            {
                return id;
            }
        }
        slot = (slot + 1) & mask;
    }
    if (table->count + 1 == table->name_capacity)
    {
        u32 name_capacity = table->name_capacity * 2;
        String8* names = arena_allocate(table->arena, String8, name_capacity);
        memcpy(names, table->names, sizeof(*names) * (table->count + 1));
        table->names = names;
        table->name_capacity = name_capacity;
    }
    // Keep the probe table at most half full so lookups stay short; the
    // rebuild re-places every entry at the doubled capacity from the key
    // words the entries already carry.
    if (table->count + 1 > table->slot_capacity / 2)
    {
        u32 slot_capacity = table->slot_capacity * 2;
        CSymbolSlot* slots = arena_allocate(table->arena, CSymbolSlot, slot_capacity);
        memset(slots, 0, sizeof(*slots) * slot_capacity);
        for (u32 old_slot = 0; old_slot < table->slot_capacity; old_slot += 1)
        {
            CSymbolSlot entry = table->slots[old_slot];
            if (!entry.length_and_id)
            {
                continue;
            }
            u32 rebuilt_slot = c_symbol_slot_hash((CSymbolKey){.low = entry.low, .high = entry.high}, entry.length_and_id >> 32) & (slot_capacity - 1);
            while (slots[rebuilt_slot].length_and_id)
            {
                rebuilt_slot = (rebuilt_slot + 1) & (slot_capacity - 1);
            }
            slots[rebuilt_slot] = entry;
        }
        table->slots = slots;
        table->slot_capacity = slot_capacity;
        slot = c_symbol_slot_hash(key, name.length) & (slot_capacity - 1);
        while (table->slots[slot].length_and_id)
        {
            slot = (slot + 1) & (slot_capacity - 1);
        }
    }
    u32 id = table->count + 1;
    table->count = id;
    table->names[id] = name;
    table->slots[slot] = (CSymbolSlot){
        .low = key.low,
        .high = key.high,
        .length_and_id = length_word | id,
    };
    return id;
}

BUSTER_C_SHARED String8 const c_declaration_keyword_spellings[] = {
    S8_INITIALIZER("auto"),          S8_INITIALIZER("break"),     S8_INITIALIZER("case"),           S8_INITIALIZER("char"),
    S8_INITIALIZER("const"),         S8_INITIALIZER("continue"),  S8_INITIALIZER("default"),        S8_INITIALIZER("do"),
    S8_INITIALIZER("double"),        S8_INITIALIZER("else"),      S8_INITIALIZER("enum"),           S8_INITIALIZER("extern"),
    S8_INITIALIZER("float"),         S8_INITIALIZER("for"),       S8_INITIALIZER("goto"),           S8_INITIALIZER("if"),
    S8_INITIALIZER("inline"),        S8_INITIALIZER("int"),       S8_INITIALIZER("long"),           S8_INITIALIZER("register"),
    S8_INITIALIZER("restrict"),      S8_INITIALIZER("return"),    S8_INITIALIZER("short"),          S8_INITIALIZER("signed"),
    S8_INITIALIZER("sizeof"),        S8_INITIALIZER("static"),    S8_INITIALIZER("struct"),         S8_INITIALIZER("switch"),
    S8_INITIALIZER("typedef"),       S8_INITIALIZER("union"),     S8_INITIALIZER("unsigned"),       S8_INITIALIZER("void"),
    S8_INITIALIZER("volatile"),      S8_INITIALIZER("while"),     S8_INITIALIZER("_Alignas"),       S8_INITIALIZER("_Alignof"),
    S8_INITIALIZER("_Atomic"),       S8_INITIALIZER("_Bool"),     S8_INITIALIZER("_Complex"),       S8_INITIALIZER("_Generic"),
    S8_INITIALIZER("_Imaginary"),    S8_INITIALIZER("_Noreturn"), S8_INITIALIZER("_Static_assert"), S8_INITIALIZER("_Thread_local"),
    S8_INITIALIZER("__attribute__"), S8_INITIALIZER("__attribute"), S8_INITIALIZER("__declspec"),    S8_INITIALIZER("__auto_type"),
    S8_INITIALIZER("__thread"),      S8_INITIALIZER("__typeof__"), S8_INITIALIZER("__typeof"),       S8_INITIALIZER("__extension__"),
    S8_INITIALIZER("__inline"),
    S8_INITIALIZER("__inline__"),
    S8_INITIALIZER("__const"),       S8_INITIALIZER("__const__"), S8_INITIALIZER("__volatile"),     S8_INITIALIZER("__volatile__"),
    S8_INITIALIZER("__restrict"),    S8_INITIALIZER("__restrict__"), S8_INITIALIZER("__signed"),    S8_INITIALIZER("__signed__"),
    S8_INITIALIZER("__asm"),         S8_INITIALIZER("__asm__"),   S8_INITIALIZER("__alignof"),      S8_INITIALIZER("__alignof__"),
    S8_INITIALIZER("_Nonnull"),      S8_INITIALIZER("_Nullable"), S8_INITIALIZER("_Null_unspecified"), S8_INITIALIZER("__int128"),
    S8_INITIALIZER("__complex"),     S8_INITIALIZER("__complex__"), S8_INITIALIZER("__builtin_va_list"),
    S8_INITIALIZER("_Float16"),
    S8_INITIALIZER("__bf16"),
};

BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(c_declaration_keyword_spellings) < C_DECLARATION_KEYWORD_SLOT_COUNT / 2);

// Names whose parse-side token class is nonzero but that are not part of the
// builtin ladder; interned at create time so every classifiable name has a
// predefined id and `symbol > c_symbol_predefined_limit` is a constant-time
// "ordinary identifier" answer.
BUSTER_C_INTERNAL String8 const c_symbol_classified_extras[] = {
    S8_INITIALIZER("true"),          S8_INITIALIZER("false"),  S8_INITIALIZER("nullptr"),
    S8_INITIALIZER("alignof"),       S8_INITIALIZER("constexpr"), S8_INITIALIZER("typeof_unqual"),
    S8_INITIALIZER("typeof"),        S8_INITIALIZER("vector_size"), S8_INITIALIZER("__vector_size"),
    S8_INITIALIZER("__vector_size__"),
};

// The spellings behind CSymbolWellKnown: entry N is interned N-th and
// therefore receives id N, which is what lets a call site write the
// enumerator where the id belongs. Designated by enumerator so the pairing
// survives any reordering of the enum, and c_symbol_table_create asserts
// both halves of the contract — every entry present, every id as promised.
// C_SYMBOL_WELL_KNOWN_NONE keeps the empty spelling and is never interned.
BUSTER_C_SHARED String8 const c_symbol_well_known_spellings[C_SYMBOL_WELL_KNOWN_COUNT] = {
    [C_SYMBOL_WELL_KNOWN_NONE] = S8_INITIALIZER(""),
    [C_SYMBOL_WELL_KNOWN_CASE] = S8_INITIALIZER("case"),
    [C_SYMBOL_WELL_KNOWN_DEFAULT] = S8_INITIALIZER("default"),
    [C_SYMBOL_WELL_KNOWN_IF] = S8_INITIALIZER("if"),
    [C_SYMBOL_WELL_KNOWN_FOR] = S8_INITIALIZER("for"),
    [C_SYMBOL_WELL_KNOWN_WHILE] = S8_INITIALIZER("while"),
    [C_SYMBOL_WELL_KNOWN_SWITCH] = S8_INITIALIZER("switch"),
    [C_SYMBOL_WELL_KNOWN_DO] = S8_INITIALIZER("do"),
    [C_SYMBOL_WELL_KNOWN_ELSE] = S8_INITIALIZER("else"),
    [C_SYMBOL_WELL_KNOWN_OVERLOADABLE] = S8_INITIALIZER("__overloadable__"),
    [C_SYMBOL_WELL_KNOWN_STATIC_ASSERT] = S8_INITIALIZER("_Static_assert"),
    [C_SYMBOL_WELL_KNOWN_BREAK] = S8_INITIALIZER("break"),
    [C_SYMBOL_WELL_KNOWN_CONTINUE] = S8_INITIALIZER("continue"),
    [C_SYMBOL_WELL_KNOWN_GOTO] = S8_INITIALIZER("goto"),
    [C_SYMBOL_WELL_KNOWN_RETURN] = S8_INITIALIZER("return"),
    [C_SYMBOL_WELL_KNOWN_TYPEDEF] = S8_INITIALIZER("typedef"),
    [C_SYMBOL_WELL_KNOWN_STRUCT] = S8_INITIALIZER("struct"),
    [C_SYMBOL_WELL_KNOWN_UNION] = S8_INITIALIZER("union"),
    [C_SYMBOL_WELL_KNOWN_ENUM] = S8_INITIALIZER("enum"),
    [C_SYMBOL_WELL_KNOWN_STATIC] = S8_INITIALIZER("static"),
    [C_SYMBOL_WELL_KNOWN_EXTERN] = S8_INITIALIZER("extern"),
    [C_SYMBOL_WELL_KNOWN_THREAD_LOCAL] = S8_INITIALIZER("_Thread_local"),
    [C_SYMBOL_WELL_KNOWN_THREAD_GNU] = S8_INITIALIZER("__thread"),
    [C_SYMBOL_WELL_KNOWN_ASM] = S8_INITIALIZER("asm"),
    [C_SYMBOL_WELL_KNOWN_ASM_GNU] = S8_INITIALIZER("__asm"),
    [C_SYMBOL_WELL_KNOWN_ASM_GNU_ALT] = S8_INITIALIZER("__asm__"),
    [C_SYMBOL_WELL_KNOWN_ATTRIBUTE] = S8_INITIALIZER("__attribute__"),
    [C_SYMBOL_WELL_KNOWN_ATTRIBUTE_SHORT] = S8_INITIALIZER("__attribute"),
    [C_SYMBOL_WELL_KNOWN_SIZEOF] = S8_INITIALIZER("sizeof"),
    [C_SYMBOL_WELL_KNOWN_ALIGNOF] = S8_INITIALIZER("_Alignof"),
    [C_SYMBOL_WELL_KNOWN_ALIGNOF_GNU] = S8_INITIALIZER("__alignof"),
    [C_SYMBOL_WELL_KNOWN_ALIGNOF_GNU_ALT] = S8_INITIALIZER("__alignof__"),
    [C_SYMBOL_WELL_KNOWN_THREAD_LOCAL_C23] = S8_INITIALIZER("thread_local"),
    [C_SYMBOL_WELL_KNOWN_INLINE] = S8_INITIALIZER("inline"),
    [C_SYMBOL_WELL_KNOWN_INLINE_GNU] = S8_INITIALIZER("__inline"),
    [C_SYMBOL_WELL_KNOWN_INLINE_GNU_ALT] = S8_INITIALIZER("__inline__"),
    [C_SYMBOL_WELL_KNOWN_SECTION] = S8_INITIALIZER("section"),
    [C_SYMBOL_WELL_KNOWN_SECTION_GNU] = S8_INITIALIZER("__section__"),
    [C_SYMBOL_WELL_KNOWN_WEAK] = S8_INITIALIZER("weak"),
    [C_SYMBOL_WELL_KNOWN_WEAK_GNU] = S8_INITIALIZER("__weak__"),
    [C_SYMBOL_WELL_KNOWN_ALIAS] = S8_INITIALIZER("alias"),
    [C_SYMBOL_WELL_KNOWN_ALIAS_GNU] = S8_INITIALIZER("__alias__"),
    [C_SYMBOL_WELL_KNOWN_CONSTRUCTOR] = S8_INITIALIZER("constructor"),
    [C_SYMBOL_WELL_KNOWN_CONSTRUCTOR_GNU] = S8_INITIALIZER("__constructor__"),
    [C_SYMBOL_WELL_KNOWN_DESTRUCTOR] = S8_INITIALIZER("destructor"),
    [C_SYMBOL_WELL_KNOWN_DESTRUCTOR_GNU] = S8_INITIALIZER("__destructor__"),
    [C_SYMBOL_WELL_KNOWN_EXTENSION] = S8_INITIALIZER("__extension__"),
    [C_SYMBOL_WELL_KNOWN_DECLSPEC] = S8_INITIALIZER("__declspec"),
    [C_SYMBOL_WELL_KNOWN_REGISTER] = S8_INITIALIZER("register"),
    [C_SYMBOL_WELL_KNOWN_BUILTIN_OFFSETOF] = S8_INITIALIZER("__builtin_offsetof"),
    [C_SYMBOL_WELL_KNOWN_VOLATILE] = S8_INITIALIZER("volatile"),
    [C_SYMBOL_WELL_KNOWN_VOLATILE_GNU_ALT] = S8_INITIALIZER("__volatile__"),
    [C_SYMBOL_WELL_KNOWN_CONSTEXPR] = S8_INITIALIZER("constexpr"),
    [C_SYMBOL_WELL_KNOWN_CONST] = S8_INITIALIZER("const"),
    [C_SYMBOL_WELL_KNOWN_ATOMIC] = S8_INITIALIZER("_Atomic"),
};

enum
{
    C_SYMBOL_PREDEFINED_LIMIT_CAPACITY = 256,
};

BUSTER_C_SHARED u8 c_parse_token_class_compute(String8 spelling);
BUSTER_C_SHARED u16 c_parse_word_bits_compute(String8 spelling);

BUSTER_C_INTERNAL CSymbolTable c_symbol_table_create(Arena* arena)
{
    CSymbolTable table = {
        .arena = arena,
        .slot_capacity = 1u << 14,
        .name_capacity = 1u << 12,
    };
    table.names = arena_allocate(arena, String8, table.name_capacity);
    table.slots = arena_allocate(arena, CSymbolSlot, table.slot_capacity);
    memset(table.slots, 0, sizeof(*table.slots) * table.slot_capacity);
    table.builtin_kinds = arena_allocate(arena, u8, C_SYMBOL_PREDEFINED_LIMIT_CAPACITY);
    table.class_bits = arena_allocate(arena, u8, C_SYMBOL_PREDEFINED_LIMIT_CAPACITY);
    table.word_bits = arena_allocate(arena, u16, C_SYMBOL_PREDEFINED_LIMIT_CAPACITY);
    memset(table.builtin_kinds, 0, C_SYMBOL_PREDEFINED_LIMIT_CAPACITY);
    memset(table.class_bits, 0, C_SYMBOL_PREDEFINED_LIMIT_CAPACITY);
    memset(table.word_bits, 0, sizeof(*table.word_bits) * C_SYMBOL_PREDEFINED_LIMIT_CAPACITY);
    // The well-known names go in first and in enumerator order, because the
    // passes that compare against them spell the id as the enumerator itself
    // rather than reading it back out of the table.
    for (u32 well_known = 1; well_known < C_SYMBOL_WELL_KNOWN_COUNT; well_known += 1)
    {
        // An enumerator with no spelling would intern the empty name and
        // match nothing, so the gap is caught here rather than as a pass
        // that silently stops recognizing its keyword.
        BUSTER_CHECK(c_symbol_well_known_spellings[well_known].length);
        u32 id = c_symbol_intern(&table, c_symbol_well_known_spellings[well_known]);
        BUSTER_CHECK(id == well_known);
    }
    for (u64 index = 0; index < C_SYMBOL_PREDEFINED_COUNT; index += 1)
    {
        u32 id = c_symbol_intern(&table, c_symbol_predefined[index].name);
        BUSTER_CHECK(id == C_SYMBOL_WELL_KNOWN_COUNT + index);
        // Routed through the spelling scan instead of reading
        // c_symbol_predefined[index].builtin directly, so the two
        // classification paths cannot drift.
        table.builtin_kinds[id] = (u8)c_symbol_builtin_from_spelling(c_symbol_predefined[index].name);
    }
    // The declaration keywords and the classified extras join the predefined
    // range; their class bits come from the same compute the spelling
    // fallback uses, so the two classification paths cannot drift.
    for (u64 index = 0; index < BUSTER_ARRAY_LENGTH(c_declaration_keyword_spellings); index += 1)
    {
        c_symbol_intern(&table, c_declaration_keyword_spellings[index]);
    }
    for (u64 index = 0; index < BUSTER_ARRAY_LENGTH(c_symbol_classified_extras); index += 1)
    {
        c_symbol_intern(&table, c_symbol_classified_extras[index]);
    }
    BUSTER_VALIDATE(table.count < C_SYMBOL_PREDEFINED_LIMIT_CAPACITY);
    table.predefined_limit = table.count;
    for (u32 id = 1; id <= table.count; id += 1)
    {
        table.class_bits[id] = c_parse_token_class_compute(table.names[id]);
        table.word_bits[id] = c_parse_word_bits_compute(table.names[id]);
    }
    return table;
}

// The intern pass over a lexed run. Identifiers are one token in five, and
// the one-byte shape sidecar says which: a 64-token window is one masked
// load and one compare, and only the identifier lanes are visited, where the
// row loop tested the kind of every 12-byte row. A run without a sidecar
// takes the row loop, which is also the definition the c frontend test
// module holds the mask path to (c_test_intern_scan_by_shape).
BUSTER_C_INTERNAL void c_symbols_intern_tokens(CSymbolTable* table, char8 const* spelling_base, CToken* tokens, CTokenShape const* shapes, u64 token_count)
{
    if (shapes)
    {
        Simd512 identifier_shape = simd512_splat((u8)C_TOKEN_IDENTIFIER);
        for (u64 window_base = 0; window_base < token_count; window_base += 64)
        {
            Mask64 window_mask = mask64_prefix(token_count - window_base);
            Mask64 identifiers = simd512_equal_byte(simd512_load_masked(shapes + window_base, window_mask), identifier_shape);
            while (identifiers)
            {
                u64 index = window_base + mask64_first_set(identifiers);
                tokens[index].symbol = c_symbol_intern(table, c_token_spelling(spelling_base, tokens[index]));
                identifiers = mask64_and(identifiers, identifiers - 1);
            }
        }
    }
    else
    {
        for (u64 index = 0; index < token_count; index += 1)
        {
            if (tokens[index].kind == C_TOKEN_IDENTIFIER)
            {
                tokens[index].symbol = c_symbol_intern(table, c_token_spelling(spelling_base, tokens[index]));
            }
        }
    }
}

// A token in flight through the preprocessor's expansion machinery, carrying
// the source location the final stream and diagnostics must preserve.
// `foreign` marks tokens whose location no longer derives from their
// spelling offset (macro replacement stamps the invocation location onto
// every replacement token); output materialization copies their spellings
// into the spelling space under an expansion source-map entry so on-demand
// recovery reproduces the stamped location exactly.
// `preceded_by_space` answers what only `#` asks: did white space stand
// before this token where it was written? C11 6.10.3.2p2 makes a
// stringified argument reproduce its own spacing — every run of white space
// becomes one space and tokens that were adjacent stay adjacent. It is
// meaningful on a `foreign` token only: a token still spelled where it was
// written has its answer in its spelling offset, and recovering it at the
// two places that ask (argument collection and replacement materialization)
// keeps the per-token cost off the line staging path, which every token of
// every expanded line passes through. Substitution is what makes the offset
// stop answering — a replacement token stands where the invocation was, not
// where it was spelled — so from there the flag carries it. The flag is one
// bit of the word beside the token, so it costs no memory.
// `no_expand` is C11 6.10.3.4p2's blue paint. The expansion machinery keeps
// one `disabled` bit per macro rather than a hide set per token, which is
// enough while a replacement is being rescanned in place: the bit is set
// across the rescan and cleared after it. It is not enough for a token that
// leaves that rescan alive. A macro argument is fully expanded in a nested
// context and the resulting tokens are then substituted and rescanned again
// in the parent, by which time the bit has been cleared, so a self-naming
// macro reached through an argument expanded once more per nesting level
// (`si_pid` -> `a.b.si_pid` -> `a.b.a.b.si_pid`). Painting the name where the
// disabled bit stopped it makes the refusal permanent, which is what the
// standard requires and what the disabled bit alone cannot express. It is
// one bit of the same word, so it too costs no memory.
#define C_PP_STAMP_BITS 29
#define C_PP_STAMP_MASK ((1u << C_PP_STAMP_BITS) - 1)

typedef struct CPpToken CPpToken;
struct CPpToken
{
    CToken token;
    // 1 + the index of the token's location in the line's CPpStampTable, or
    // 0 for a text-line token that has needed none: only the token that
    // becomes a macro invocation ever needs a location (as the stamp its
    // replacement inherits and for its own diagnostics), and one invocation
    // is far rarer than one wrapped token, so c_preprocess_expand recovers it
    // from the offset at that moment through the line's frame and stamps the
    // table. A foreign token is stamped by construction and a directive-line
    // token is wrapped with its line head. An index instead of the 20-byte
    // location itself is what holds the record to one 16-byte row: a token
    // is copied eight to ten times on its way through the expansion
    // machinery, and the location is the same for a whole replacement.
    u32 stamp : C_PP_STAMP_BITS;
    u32 foreign : 1;
    u32 preceded_by_space : 1;
    u32 no_expand : 1;
};

BUSTER_CT_CHECK(sizeof(CPpToken) == 16);

// The distinct locations one line's expansion carries: one entry per
// invocation resolved on a text line, or the line head of a directive line.
// The wrap sites reset it per line, so it stays a handful of entries.
typedef struct CPpStampTable CPpStampTable;
struct CPpStampTable
{
    Arena* arena;
    CSourceLocation* entries;
    u32 count;
    u32 capacity;
};

// The stamp of `location`: 1 + its index.
BUSTER_C_INTERNAL u32 c_pp_stamp_push(CPpStampTable* stamps, CSourceLocation location)
{
    if (stamps->count == stamps->capacity)
    {
        u32 capacity = stamps->capacity ? stamps->capacity * 2 : 64;
        CSourceLocation* entries = arena_allocate(stamps->arena, CSourceLocation, capacity);
        if (stamps->count)
        {
            memcpy(entries, stamps->entries, sizeof(*entries) * stamps->count);
        }
        stamps->entries = entries;
        stamps->capacity = capacity;
    }
    BUSTER_VALIDATE(stamps->count < C_PP_STAMP_MASK);
    stamps->entries[stamps->count] = location;
    stamps->count += 1;
    return stamps->count;
}

// The location a stamped token carries; the zero location for an unstamped
// token, or when there is no table (the parse-side evaluator, which has no
// macros to invoke).
BUSTER_C_INTERNAL CSourceLocation c_pp_stamp_location(CPpStampTable const* stamps, u32 stamp)
{
    CSourceLocation result = {0};
    if (stamps && stamp)
    {
        result = stamps->entries[stamp - 1];
    }
    return result;
}

// White space between two tokens of one lexed run. The lexer keeps no white
// space, and does not have to: spellings are contiguous in translated
// source, so a gap between one token's end and the next token's offset is
// exactly where white space or a comment stood. The one gap that is not
// visible that way is a newline token, whose single byte abuts a token that
// starts in column one. Two tokens from different runs — one spelled in a
// `#define` line and one in the file that invokes it, say — are never
// contiguous, so they read as separated, which is what they are.
BUSTER_C_INTERNAL bool c_token_preceded_by_space(char8 const* spelling_base, CToken previous, CToken token)
{
    return previous.kind == C_TOKEN_NEWLINE || previous.offset + c_token_length(spelling_base, previous) != token.offset;
}

typedef struct CPreprocessTokenNode CPreprocessTokenNode;
struct CPreprocessTokenNode
{
    CPreprocessTokenNode* next;
    CPpToken token;
};

// The preprocessed output stream. Tokens land in their final slots as lines
// resolve: the stream is the tail of a dedicated commit-on-demand arena
// (created beside the spelling arena in c_preprocess) that nothing else
// allocates from, so successive reservations are contiguous and `base` is
// the finished token array the moment the last line lands. A line reserves
// its upper bound — its lexed token count, or an expansion's node count —
// writes the tokens that survive the newline or pragma strip, and hands the
// surplus slots back. This replaces a staging array per line plus a range
// list copied into a final array at the end: the range after a line's
// staging array never coalesced with the next line's, because the range
// node itself was allocated between them, so the final copy was one
// line-sized memcpy per line (269 K on the unity compile) walking a node
// per line besides.
typedef struct CTokenStream CTokenStream;
struct CTokenStream
{
    Arena* arena;
    Arena* shape_arena;
    CToken* base;
    CTokenShape* shape_base;
};

BUSTER_C_INTERNAL CToken* c_token_stream_reserve(CTokenStream* stream, u64 token_count, CTokenShape** shapes_out)
{
    CToken* result = arena_allocate(stream->arena, CToken, token_count);
    *shapes_out = arena_allocate(stream->shape_arena, CTokenShape, token_count);
    return result;
}

BUSTER_C_INTERNAL void c_token_stream_shrink(CTokenStream* stream, u64 surplus_token_count)
{
    arena_set_position(stream->arena, stream->arena->position - surplus_token_count * sizeof(CToken));
    arena_set_position(stream->shape_arena, stream->shape_arena->position - surplus_token_count * sizeof(CTokenShape));
}

typedef enum CMacroExpansionTaskKind
{
    C_MACRO_EXPANSION_TOKEN,
    C_MACRO_EXPANSION_ENABLE,
} CMacroExpansionTaskKind;

typedef struct CMacroExpansionTask CMacroExpansionTask;
struct CMacroExpansionTask
{
    CMacro* macro;
    CPpToken token;
    CMacroExpansionTaskKind kind;
};

// Contexts suspend strictly LIFO. Pending parent tasks remain below a child's
// task_base; indices, unlike pointers into this array, survive growth.
enum
{
    C_MACRO_EXPANSION_LOCAL_TASK_CAPACITY = 64,
};

typedef struct CMacroExpansionTaskStack CMacroExpansionTaskStack;
struct CMacroExpansionTaskStack
{
    CMacroExpansionTask* data;
    u64 count;
    u64 capacity;
};

typedef struct CMacroArgument CMacroArgument;
struct CMacroArgument
{
    CPreprocessTokenNode* first;
    CPreprocessTokenNode* last;
    CPpToken* tokens;
    CPpToken* expanded_tokens;
    u64 token_count;
    u64 expanded_token_count;
};

typedef struct CMacroExpansionContinuation CMacroExpansionContinuation;

typedef struct CMacroExpansionContext CMacroExpansionContext;
struct CMacroExpansionContext
{
    CMacroExpansionContext* parent;
    CMacroExpansionContinuation* continuation;
    u64 task_base;
    CPreprocessTokenNode* first_output;
    CPreprocessTokenNode* last_output;
    u64 output_count;
};

struct CMacroExpansionContinuation
{
    CMacroExpansionContext* parent;
    CMacro* macro;
    CMacroArgument* arguments;
    CPpToken invocation;
    u32 argument_count;
    u32 argument_index;
};

typedef struct CMacroReplacementToken CMacroReplacementToken;
struct CMacroReplacementToken
{
    CPpToken token;
    bool placemarker;
    // This item is the `##` of GNU's `, ## __VA_ARGS__` comma-deletion
    // idiom: a paste written between a literal comma and the variadic
    // parameter.  With empty varargs the placemarker path deletes the comma;
    // with tokens present GNU performs no paste at all -- the comma stays
    // and the arguments follow -- where a real paste of `,` against the
    // first argument token cannot form one preprocessing token and would
    // refuse every non-empty call.
    bool comma_paste;
};

BUSTER_C_EXTERN bool c_token_spelling_equal(char8 const* spelling_base, CToken token, String8 spelling)
{
    return string_equal(c_token_spelling(spelling_base, token), spelling);
}

// Macros are found by interned symbol id: one indexed load. Symbol 0 (an
// uninterned token) matches nothing because every definition interns its
// name, so entry 0 is never written; an id past the index's capacity was
// interned after the last definition and so names no macro either.
BUSTER_C_INTERNAL CMacro* c_macro_find(CMacro* first, u32 symbol)
{
    CMacro* result = 0;
    if (first && symbol < first->by_symbol_capacity)
    {
        result = first->by_symbol[symbol];
    }
    return result;
}

// The lookup for tokens that may not have passed the intern pass (pasted or
// synthesized): intern on demand when a table is available so the fast
// symbol lookup stays authoritative.
BUSTER_C_INTERNAL CMacro* c_macro_find_token(CMacro* first, CSymbolTable* symbols, char8 const* spelling_base, CToken const* token)
{
    u32 symbol = token->symbol;
    if (!symbol && symbols)
    {
        symbol = c_symbol_intern(symbols, c_token_spelling(spelling_base, *token));
    }
    return c_macro_find(first, symbol);
}

// The white space a `#define` line was written with, recorded for the
// definition it produced. Only a list of two or more tokens has any interior
// spacing to record.
BUSTER_C_INTERNAL u8* c_macro_replacement_spaces(Arena* arena, char8 const* spelling_base, CToken* replacement, u32 replacement_count)
{
    u8* result = 0;
    if (replacement_count > 1)
    {
        result = arena_allocate(arena, u8, replacement_count);
        for (u32 index = 1; index < replacement_count; index += 1)
        {
            result[index] = c_token_preceded_by_space(spelling_base, replacement[index - 1], replacement[index]) ? 1 : 0;
        }
    }
    return result;
}

BUSTER_C_INTERNAL bool c_macro_is_paste(CToken token)
{
    return c_token_is_punctuator(&token, C_PUNCTUATOR_HASH_HASH);
}

// The spelling ladder behind the definition-time parameter index: which
// parameter, if any, `name` spells.
BUSTER_C_INTERNAL s32 c_macro_parameter_index(CMacro* macro, String8 name)
{
    s32 result = -1;
    for (u32 parameter_index = 0; parameter_index < macro->definition.parameter_count && result < 0; parameter_index += 1)
    {
        if (string_equal(macro->definition.parameters[parameter_index], name))
        {
            result = (s32)parameter_index;
        }
    }
    return result;
}

// `spelling_base` resolves the replacement tokens' spellings for the
// parameter index and may be null when the replacement list is empty.
BUSTER_C_INTERNAL CMacro* c_macro_define(Arena* arena, char8 const* spelling_base, CSymbolTable* symbols, CMacro** first, CMacro** last, String8 name,
                                           CToken* replacement, u32 replacement_count, String8* parameters, u32 parameter_count, bool function_like,
                                           bool variadic)
{
    u32 symbol = c_symbol_intern(symbols, name);
    CMacro* macro = c_macro_find(*first, symbol);
    if (!macro)
    {
        macro = arena_allocate(arena, CMacro, 1);
        *macro = (CMacro){
            .name = name,
            .symbol = symbol,
        };
        if (*last)
        {
            (*last)->next = macro;
        }
        else
        {
            *first = macro;
        }
        *last = macro;
        // Every id the table has handed out lies below its name capacity,
        // so an index of that size covers this symbol and every earlier one;
        // the first definition builds it, and a definition whose id lies
        // past it (the table doubled since) regrows it from the list.
        BUSTER_CHECK(*first); // The first/last list endpoints are published together.
        if (symbol >= (*first)->by_symbol_capacity)
        {
            c_macro_index_rebuild(arena, *first, symbols->name_capacity);
        }
        else
        {
            (*first)->by_symbol[symbol] = macro;
        }
    }
    macro->definition = (CMacroDefinition){
        .replacement = replacement,
        .replacement_count = replacement_count,
        .parameters = parameters,
        .parameter_count = parameter_count,
        .function_like = function_like,
        .variadic = variadic,
        .defined = true,
    };
    // A later ordinary or command-line definition replaces a dynamic builtin
    // as a macro, not merely its replacement tokens.
    macro->builtin = C_MACRO_BUILTIN_NONE;
    macro->definition.plain_count = replacement_count;
    // Allocated for every parameter list, empty replacement included: a
    // `#define F(x)` with no replacement tokens still reaches the capacity
    // walk below over its parameters.
    u32* parameter_expand_count = parameter_count ? arena_allocate(arena, u32, parameter_count) : 0;
    for (u32 index = 0; index < parameter_count; index += 1)
    {
        parameter_expand_count[index] = 0;
    }
    macro->definition.parameter_expand_count = parameter_expand_count;
    if (replacement_count)
    {
        u32* parameter_index = arena_allocate(arena, u32, replacement_count);
        for (u32 index = 0; index < replacement_count; index += 1)
        {
            CToken token = replacement[index];
            s32 found = token.kind == C_TOKEN_IDENTIFIER && function_like ? c_macro_parameter_index(macro, c_token_spelling(spelling_base, token)) : -1;
            parameter_index[index] = found >= 0 ? (u32)found : C_MACRO_PARAMETER_NONE;
            if (found >= 0)
            {
                bool stringized = index && c_token_is_punctuator(&replacement[index - 1], C_PUNCTUATOR_HASH);
                bool pasted = (index && c_macro_is_paste(replacement[index - 1])) ||
                              (index + 1 < replacement_count && c_macro_is_paste(replacement[index + 1]));
                parameter_expand_count[found] += !stringized && !pasted;
                macro->definition.plain_count -= 1;
            }
        }
        macro->definition.parameter_index = parameter_index;
        // Recorded here for the same reason the parameter index is: which
        // operators a definition uses cannot change after it is written, and
        // every expansion of it would otherwise re-derive the answer.
        for (u32 index = 0; index < replacement_count; index += 1)
        {
            if (c_macro_is_paste(replacement[index]))
            {
                macro->definition.has_paste = true;
            }
            if (function_like && c_token_is_punctuator(&replacement[index], C_PUNCTUATOR_HASH) && index + 1 < replacement_count &&
                parameter_index[index + 1] != C_MACRO_PARAMETER_NONE)
            {
                macro->definition.has_stringify = true;
            }
        }
    }
    return macro;
}

BUSTER_C_INTERNAL void c_macro_define_object_text(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols, CMacro** first, CMacro** last, String8 name,
                                                    String8 replacement_text)
{
    CLexResult lex = c_lex_space(arena, space, replacement_text);
    c_symbols_intern_tokens(symbols, lex.spelling_base, lex.tokens, lex.token_shapes, lex.token_count);
    u32 replacement_count = 0;
    while (replacement_count < lex.token_count && lex.tokens[replacement_count].kind != C_TOKEN_NEWLINE &&
           lex.tokens[replacement_count].kind != C_TOKEN_END_OF_FILE)
    {
        replacement_count += 1;
    }
    CMacro* macro = c_macro_define(arena, lex.spelling_base, symbols, first, last, name, lex.tokens, replacement_count, 0, 0, false, false);
    macro->definition.replacement_space = c_macro_replacement_spaces(arena, lex.spelling_base, lex.tokens, replacement_count);
}

BUSTER_C_INTERNAL void c_preprocess_diagnostic_reserve(Arena* arena, CPreprocessResult* result)
{
    if (result->diagnostic_count < result->diagnostic_capacity)
    {
        return;
    }
    u64 capacity = result->diagnostic_capacity ? result->diagnostic_capacity * 2 : 1;
    if (capacity <= result->diagnostic_count)
    {
        capacity = result->diagnostic_count + 1;
    }
    CDiagnostic* diagnostics = arena_allocate(arena, CDiagnostic, capacity);
    if (result->diagnostic_count)
    {
        memcpy(diagnostics, result->diagnostics, sizeof(*diagnostics) * result->diagnostic_count);
    }
    result->diagnostics = diagnostics;
    result->diagnostic_capacity = capacity;
}

BUSTER_C_INTERNAL void c_preprocess_diagnostic_push_severity(Arena* arena, CPreprocessResult* result, CSourceLocation location, CDiagnosticKind kind,
                                                               CDiagnosticSeverity severity, String8 message)
{
    c_preprocess_diagnostic_reserve(arena, result);
    result->diagnostics[result->diagnostic_count++] = (CDiagnostic){
        .message = message,
        .location = location,
        .kind = kind,
        .severity = severity,
    };
    if (severity == C_DIAGNOSTIC_WARNING)
    {
        result->warning_count += 1;
    }
    else
    {
        result->error_count += 1;
    }
}

BUSTER_C_INTERNAL void c_preprocess_diagnostic_push(Arena* arena, CPreprocessResult* result, CSourceLocation location, CDiagnosticKind kind, String8 message)
{
    c_preprocess_diagnostic_push_severity(arena, result, location, kind, C_DIAGNOSTIC_ERROR, message);
}

BUSTER_C_INTERNAL void c_preprocess_diagnostic_copy(Arena* arena, CPreprocessResult* result, CDiagnostic diagnostic)
{
    c_preprocess_diagnostic_reserve(arena, result);
    result->diagnostics[result->diagnostic_count++] = diagnostic;
    if (diagnostic.severity == C_DIAGNOSTIC_WARNING)
    {
        result->warning_count += 1;
    }
    else
    {
        result->error_count += 1;
    }
}

BUSTER_C_INTERNAL void c_preprocess_output_push(Arena* arena, CPreprocessTokenNode** first, CPreprocessTokenNode** last, CPpToken token, u64* count)
{
    CPreprocessTokenNode* node = arena_allocate(arena, CPreprocessTokenNode, 1);
    node->next = 0;
    node->token = token;
    if (*last)
    {
        (*last)->next = node;
    }
    else
    {
        *first = node;
    }
    *last = node;
    *count += 1;
}

// Room for `token_count` tokens plus an optional ENABLE marker above the
// current top. Growth copies the stack, so `tasks->data` is re-read after
// this call and never retained across it; every context floor is a stable
// `task_base` index for the same reason.
BUSTER_C_INTERNAL void c_macro_expansion_tasks_reserve(Arena* arena, CMacroExpansionTaskStack* tasks, u64 token_count, bool enable)
{
    u64 maximum_count = UINT64_MAX / sizeof(CMacroExpansionTask);
    BUSTER_VALIDATE(tasks->count < maximum_count && token_count <= maximum_count - tasks->count - enable);
    u64 required = tasks->count + token_count + enable;
    if (required > tasks->capacity)
    {
        u64 doubled = tasks->capacity > maximum_count / 2 ? maximum_count : tasks->capacity * 2;
        u64 capacity = BUSTER_MAX(required, doubled);
        CMacroExpansionTask* data = arena_allocate(arena, CMacroExpansionTask, capacity);
        if (tasks->count)
        {
            memcpy(data, tasks->data, tasks->count * sizeof(*data));
        }
        tasks->data = data;
        tasks->capacity = capacity;
    }
}

// One capacity check for the whole batch. Reversing the stored tokens keeps
// the next token at the top; an optional ENABLE marker sits below the batch.
// No pointer into task storage escapes this helper or survives another push.
BUSTER_C_INTERNAL void c_macro_expansion_tasks_push(Arena* arena, CMacroExpansionTaskStack* tasks, CPpToken const* tokens, u64 token_count, CMacro* macro)
{
    c_macro_expansion_tasks_reserve(arena, tasks, token_count, macro != 0);
    u64 output = tasks->count;
    if (macro)
    {
        tasks->data[output++] = (CMacroExpansionTask){.macro = macro, .kind = C_MACRO_EXPANSION_ENABLE};
    }
    for (u64 index = token_count; index; index -= 1)
    {
        tasks->data[output++] = (CMacroExpansionTask){.token = tokens[index - 1], .kind = C_MACRO_EXPANSION_TOKEN};
    }
    tasks->count = output;
}

// Collecting an invocation's arguments is also where an argument recovers the
// white space `#` has to reproduce: its tokens are the contiguous run the
// invocation was written with, so the answer is in their spelling offsets and
// nothing earlier has to carry it. Only tokens the expansion machinery
// synthesized or substituted arrive with an answer of their own, and those
// are already marked foreign.
BUSTER_C_INTERNAL bool c_macro_invocation_arguments(Arena* arena, char8 const* spelling_base, CMacroExpansionTaskStack* tasks, u64 task_base, CMacro* macro,
                                                      CSourceLocation location, CMacroArgument** arguments_out, u32* argument_count_out,
                                                      CPreprocessResult* result)
{
    while (tasks->count > task_base && tasks->data[tasks->count - 1].kind == C_MACRO_EXPANSION_ENABLE)
    {
        tasks->data[--tasks->count].macro->disabled = false;
    }
    bool invoked = tasks->count > task_base && tasks->data[tasks->count - 1].kind == C_MACRO_EXPANSION_TOKEN &&
                   c_token_is_punctuator(&tasks->data[tasks->count - 1].token.token, C_PUNCTUATOR_LEFT_PARENTHESIS);
    if (invoked)
    {
        tasks->count -= 1;
        u32 capacity = macro->definition.parameter_count + 1;
        CMacroArgument* arguments = arena_allocate(arena, CMacroArgument, capacity);
        for (u32 argument_index = 0; argument_index < capacity; argument_index += 1)
        {
            arguments[argument_index] = (CMacroArgument){0};
        }
        u32 argument_count = macro->definition.parameter_count ? 1 : 0;
        u32 current = 0;
        u32 depth = 0;
        bool closed = false;
        bool valid = true;
        while (tasks->count > task_base && valid)
        {
            CMacroExpansionTask task = tasks->data[--tasks->count];
            if (task.kind == C_MACRO_EXPANSION_ENABLE)
            {
                task.macro->disabled = false;
            }
            else
            {
                CPpToken token = task.token;
                bool separator = false;
                if (c_token_is_punctuator(&token.token, C_PUNCTUATOR_LEFT_PARENTHESIS))
                {
                    depth += 1;
                }
                else if (c_token_is_punctuator(&token.token, C_PUNCTUATOR_RIGHT_PARENTHESIS))
                {
                    if (!depth)
                    {
                        closed = true;
                        break;
                    }
                    depth -= 1;
                }
                else if (c_token_is_punctuator(&token.token, C_PUNCTUATOR_COMMA) && !depth)
                {
                    bool collect_variadic = macro->definition.variadic && current + 1 >= macro->definition.parameter_count;
                    if (!collect_variadic)
                    {
                        current += 1;
                        if (current >= capacity)
                        {
                            c_preprocess_diagnostic_push(arena, result, location, C_DIAGNOSTIC_INVALID_MACRO_INVOCATION, S8("too many arguments in macro invocation"));
                            valid = false;
                        }
                        else
                        {
                            argument_count = BUSTER_MAX(argument_count, current + 1);
                        }
                        separator = true;
                    }
                }
                if (valid && !separator)
                {
                    if (!argument_count)
                    {
                        argument_count = 1;
                    }
                    c_preprocess_output_push(arena, &arguments[current].first, &arguments[current].last, token, &arguments[current].token_count);
                }
            }
        }
        if (valid && !closed)
        {
            c_preprocess_diagnostic_push(arena, result, location, C_DIAGNOSTIC_INVALID_MACRO_INVOCATION,
                                         string_format(arena, S8("unterminated invocation of macro '{S8}'"), macro->name));
            valid = false;
        }
        if (valid)
        {
            if (macro->definition.variadic && argument_count + 1 == macro->definition.parameter_count)
            {
                argument_count += 1;
            }
            if (argument_count != macro->definition.parameter_count)
            {
                c_preprocess_diagnostic_push(arena, result, location, C_DIAGNOSTIC_INVALID_MACRO_INVOCATION, S8("macro argument count does not match its definition"));
                valid = false;
            }
        }
        if (valid)
        {
            for (u32 argument_index = 0; argument_index < argument_count; argument_index += 1)
            {
                CMacroArgument* argument = arguments + argument_index;
                argument->tokens = arena_allocate(arena, CPpToken, argument->token_count);
                u64 token_index = 0;
                for (CPreprocessTokenNode* node = argument->first; node; node = node->next)
                {
                    argument->tokens[token_index] = node->token;
                    if (token_index && !node->token.foreign)
                    {
                        argument->tokens[token_index].preceded_by_space =
                            c_token_preceded_by_space(spelling_base, argument->tokens[token_index - 1].token, node->token.token);
                    }
                    token_index += 1;
                }
            }
            *arguments_out = arguments;
            *argument_count_out = argument_count;
        }
    }
    return invoked;
}

BUSTER_C_INTERNAL CPpToken c_macro_stringify(CSpellingSpace* space, CMacroArgument argument, u32 stamp)
{
    char8 const* base = space->base;
    u64 length = 2;
    for (u64 token_index = 0; token_index < argument.token_count; token_index += 1)
    {
        String8 spelling = c_token_spelling(base, argument.tokens[token_index].token);
        length += spelling.length;
        length += token_index != 0 && argument.tokens[token_index].preceded_by_space;
        for (u64 character_index = 0; character_index < spelling.length; character_index += 1)
        {
            char8 character = spelling.pointer[character_index];
            length += character == '\\' || character == '"';
        }
    }
    char8* spelling = c_space_allocate(space, length + 1);
    u64 output = 0;
    spelling[output++] = '"';
    for (u64 token_index = 0; token_index < argument.token_count; token_index += 1)
    {
        String8 token_spelling = c_token_spelling(base, argument.tokens[token_index].token);
        // One space for every run of white space the argument was written
        // with, and none at all between tokens that were written adjacent:
        // `#V` on `A.B.C` is "A.B.C", not "A . B . C".
        if (token_index && argument.tokens[token_index].preceded_by_space)
        {
            spelling[output++] = ' ';
        }
        for (u64 character_index = 0; character_index < token_spelling.length; character_index += 1)
        {
            char8 character = token_spelling.pointer[character_index];
            if (character == '\\' || character == '"')
            {
                spelling[output++] = '\\';
            }
            spelling[output++] = character;
        }
    }
    spelling[output++] = '"';
    spelling[output] = 0;
    return (CPpToken){
        .token =
            {
                .offset = c_space_offset(space, spelling),
                // Every interior quote and backslash was escaped above, so
                // the closing quote terminates the literal exactly and an
                // oversized result satisfies the sentinel's contract.
                .length = c_token_length_field(output),
                .kind = C_TOKEN_STRING_LITERAL,
            },
        .stamp = stamp & C_PP_STAMP_MASK,
        .foreign = true,
    };
}

BUSTER_C_INTERNAL u32 c_preprocess_builtin_line(CMacro* first);
BUSTER_C_INTERNAL CSourceLocation c_preprocess_recover_location(struct CPreprocessSourceFrame* frame, u32 file, CToken token);

BUSTER_C_INTERNAL CPpToken c_macro_builtin_token(CSpellingSpace* space, CMacro* first, u8 builtin, u32 stamp)
{
    if (builtin == C_MACRO_BUILTIN_LINE)
    {
        char8* digits = c_space_allocate(space, 11);
        u32 value = c_preprocess_builtin_line(first);
        u32 length = 0;
        do
        {
            digits[9 - length] = (char8)('0' + value % 10);
            value /= 10;
            length += 1;
        } while (value);
        digits[10] = 0;
        return (CPpToken){
            .token =
                {
                    .offset = c_space_offset(space, digits + 10 - length),
                    .length = (u16)length,
                    .kind = C_TOKEN_PREPROCESSING_NUMBER,
                },
            .stamp = stamp & C_PP_STAMP_MASK,
            .foreign = true,
        };
    }
    String8 path = first->builtin_path;
    u64 capacity = path.length * 2 + 3;
    char8* quoted = c_space_allocate(space, capacity);
    u64 output = 0;
    quoted[output++] = '"';
    for (u64 index = 0; index < path.length; index += 1)
    {
        char8 character = path.pointer[index];
        if (character == '\\' || character == '"')
        {
            quoted[output++] = '\\';
        }
        quoted[output++] = character;
    }
    quoted[output++] = '"';
    quoted[output] = 0;
    c_space_shrink(space, capacity - (output + 1));
    return (CPpToken){
        .token =
            {
                .offset = c_space_offset(space, quoted),
                .length = c_token_length_field(output),
                .kind = C_TOKEN_STRING_LITERAL,
            },
        .stamp = stamp & C_PP_STAMP_MASK,
        .foreign = true,
    };
}

// The invocation token is what a replacement token replaces, so it is what
// the replacement list's first token inherits its spacing from: `A+B` where
// `A` expands to `1` must stringify as "1+10", not "1 + 10". Every later
// replacement token was written in the `#define` line, whose tokens are
// contiguous in source like any other lexed run. The exception is the
// builtin `__has_*` marker lists below, whose spellings are synthesized one
// allocation at a time and so read as spaced — which is what stringifying
// one has always produced.
// Only builtins and definitions writing `#` or `##` stage a list here; a
// paste-free, stringify-free definition is produced into its task batch by
// c_macro_produce_plain_tasks without one.
BUSTER_C_INTERNAL bool c_macro_replacement_tokens(Arena* arena, CSpellingSpace* space, CMacro* first, CMacro* macro, CMacroArgument* arguments,
                                                    CPpToken invocation, CPpStampTable const* stamps, CPreprocessResult* result, CPpToken** tokens_out,
                                                    u32* token_count_out)
{
    char8 const* base = space->base;
    u32 stamp = invocation.stamp;
    CSourceLocation location = c_pp_stamp_location(stamps, stamp);
    u8 const* definition_spaces = macro->definition.replacement_space;
    u32 const* parameter_indices = macro->definition.parameter_index;
    bool ok = true;
    if (macro->builtin)
    {
        CPpToken* builtin_token = arena_allocate(arena, CPpToken, 1);
        builtin_token[0] = c_macro_builtin_token(space, first, macro->builtin, stamp);
        builtin_token[0].preceded_by_space = invocation.preceded_by_space;
        *tokens_out = builtin_token;
        *token_count_out = 1;
    }
    else
    {
        u64 capacity = macro->definition.replacement_count + 1;
        for (u32 replacement_index = 0; replacement_index < macro->definition.replacement_count; replacement_index += 1)
        {
            u32 parameter_index = parameter_indices[replacement_index];
            if (parameter_index != C_MACRO_PARAMETER_NONE && arguments)
            {
                CMacroArgument argument = arguments[parameter_index];
                capacity += BUSTER_MAX(argument.token_count, argument.expanded_token_count);
            }
        }
        CMacroReplacementToken* materialized = arena_allocate(arena, CMacroReplacementToken, capacity);
        u32 materialized_count = 0;
        for (u32 replacement_index = 0; replacement_index < macro->definition.replacement_count; replacement_index += 1)
        {
            CToken replacement = macro->definition.replacement[replacement_index];
            bool replacement_space = replacement_index ? !definition_spaces || definition_spaces[replacement_index] != 0 : invocation.preceded_by_space;
            if (macro->definition.function_like && c_token_is_punctuator(&replacement, C_PUNCTUATOR_HASH) &&
                replacement_index + 1 < macro->definition.replacement_count)
            {
                u32 parameter_index = parameter_indices[replacement_index + 1];
                if (parameter_index != C_MACRO_PARAMETER_NONE)
                {
                    CPpToken stringified = c_macro_stringify(space, arguments[parameter_index], stamp);
                    stringified.preceded_by_space = replacement_space;
                    materialized[materialized_count++] = (CMacroReplacementToken){
                        .token = stringified,
                    };
                    replacement_index += 1;
                    continue;
                }
            }
            u32 parameter_index = parameter_indices[replacement_index];
            if (parameter_index == C_MACRO_PARAMETER_NONE || !arguments)
            {
                // GNU's comma-deletion idiom, recognized on the definition's own
                // spelling: a `##` written between a literal comma and the
                // variadic parameter.  The paste loop below reads the mark.
                bool comma_paste = false;
                if (macro->definition.variadic && c_macro_is_paste(replacement) && replacement_index &&
                    replacement_index + 1 < macro->definition.replacement_count &&
                    c_token_is_punctuator(&macro->definition.replacement[replacement_index - 1], C_PUNCTUATOR_COMMA))
                {
                    u32 next_parameter = parameter_indices[replacement_index + 1];
                    comma_paste = next_parameter != C_MACRO_PARAMETER_NONE && next_parameter + 1 == macro->definition.parameter_count;
                }
                materialized[materialized_count++] = (CMacroReplacementToken){
                    .token = {.token = replacement, .stamp = stamp & C_PP_STAMP_MASK, .foreign = true, .preceded_by_space = replacement_space},
                    .comma_paste = comma_paste,
                };
                continue;
            }
            CMacroArgument argument = arguments[parameter_index];
            bool raw_argument = (replacement_index && c_macro_is_paste(macro->definition.replacement[replacement_index - 1])) ||
                                (replacement_index + 1 < macro->definition.replacement_count && c_macro_is_paste(macro->definition.replacement[replacement_index + 1]));
            CPpToken* argument_tokens = raw_argument ? argument.tokens : argument.expanded_tokens;
            u64 argument_token_count = raw_argument ? argument.token_count : argument.expanded_token_count;
            if (!argument_token_count)
            {
                materialized[materialized_count++] = (CMacroReplacementToken){
                    .token = {.token = replacement, .stamp = stamp & C_PP_STAMP_MASK, .foreign = true, .preceded_by_space = replacement_space},
                    .placemarker = true,
                };
                continue;
            }
            for (u64 argument_index = 0; argument_index < argument_token_count; argument_index += 1)
            {
                CPpToken argument_token = argument_tokens[argument_index];
                argument_token.stamp = stamp & C_PP_STAMP_MASK;
                argument_token.foreign = true;
                // The argument stands where the parameter was written, so its
                // first token takes the parameter's spacing; the rest keep the
                // spacing they were written or expanded with.
                if (!argument_index)
                {
                    argument_token.preceded_by_space = replacement_space;
                }
                materialized[materialized_count++] = (CMacroReplacementToken){
                    .token = argument_token,
                };
            }
        }
        // Compact into the materialized buffer so placemarkers survive every
        // paste in a chain. Removing an empty left operand early lets `##`
        // consume an unrelated preceding token or appear to be at an edge.
        u32 pasted_count = 0;
        for (u32 index = 0; index < materialized_count && ok; index += 1)
        {
            CMacroReplacementToken item = materialized[index];
            if (!c_macro_is_paste(item.token.token))
            {
                materialized[pasted_count++] = item;
                continue;
            }
            if (!pasted_count || index + 1 >= materialized_count)
            {
                c_preprocess_diagnostic_push(arena, result, location, C_DIAGNOSTIC_INVALID_TOKEN_PASTE,
                                             string_format(arena, S8("'##' appears at the edge of macro '{S8}'"), macro->name));
                ok = false;
                continue;
            }
            CMacroReplacementToken right = materialized[++index];
            CMacroReplacementToken* left = &materialized[pasted_count - 1];
            if (right.placemarker)
            {
                if (item.comma_paste)
                {
                    left->placemarker = true;
                }
                continue;
            }
            if (left->placemarker)
            {
                right.token.preceded_by_space = left->token.preceded_by_space;
                *left = right;
                continue;
            }
            if (item.comma_paste)
            {
                // Varargs present: GNU performs no paste here at all.  The comma
                // already stands in the buffer; the argument's first token
                // follows it as itself, and the rest of the argument flows
                // through the loop as ordinary tokens.
                materialized[pasted_count++] = right;
                continue;
            }
            String8 left_spelling = c_token_spelling(base, left->token.token);
            String8 right_spelling = c_token_spelling(base, right.token.token);
            u64 joined_length = left_spelling.length + right_spelling.length;
            // The joined text lives in the spelling space so the pasted token's
            // offset resolves like any other; pasting never crosses a newline or
            // splice, so relexing it cannot change its bytes and the relex is
            // validation plus kind classification only.
            char8* joined = c_space_allocate(space, joined_length + 1);
            if (left_spelling.length)
            {
                memcpy(joined, left_spelling.pointer, left_spelling.length);
            }
            if (right_spelling.length)
            {
                memcpy(joined + left_spelling.length, right_spelling.pointer, right_spelling.length);
            }
            joined[joined_length] = 0;
            TemporalArena paste_temporary = scratch_begin(&arena, 1);
            CLexResult lex = c_lex(paste_temporary.arena, (String8){
                                                              .pointer = joined,
                                                              .length = joined_length,
                                                          });
            // The oversized-token diagnostics count here: a pasted identifier or
            // number past the length field's reach fails as an invalid paste
            // instead of storing a sentinel only literals may carry.
            bool paste_valid = !lex.diagnostic_count && lex.token_count == 2 && lex.tokens[0].kind != C_TOKEN_END_OF_FILE &&
                               c_token_length(lex.spelling_base, lex.tokens[0]) == joined_length;
            CToken pasted_shape = paste_valid ? lex.tokens[0] : (CToken){0};
            scratch_end(paste_temporary);
            if (!paste_valid)
            {
                c_preprocess_diagnostic_push(arena, result, location, C_DIAGNOSTIC_INVALID_TOKEN_PASTE,
                                             string_format(arena, S8("token paste '{S8}##{S8}' in macro '{S8}' does not form one preprocessing token"),
                                                           left_spelling, right_spelling, macro->name));
                ok = false;
                continue;
            }
            left->token = (CPpToken){
                .token =
                    {
                        .offset = c_space_offset(space, joined),
                        .length = c_token_length_field(joined_length),
                        .kind = pasted_shape.kind,
                        .punctuator = pasted_shape.punctuator,
                    },
                .stamp = stamp & C_PP_STAMP_MASK,
                .foreign = true,
                // The joined token starts where its left operand started, so it
                // inherits that operand's spacing; the pasted spelling itself
                // carries none.
                .preceded_by_space = left->token.preceded_by_space,
            };
        }
        if (ok)
        {
            CPpToken* output = arena_allocate(arena, CPpToken, pasted_count);
            u32 output_count = 0;
            for (u32 index = 0; index < pasted_count; index += 1)
            {
                if (!materialized[index].placemarker)
                {
                    output[output_count++] = materialized[index].token;
                }
            }
            *tokens_out = output;
            *token_count_out = output_count;
        }
    }
    return ok;
}

BUSTER_C_INTERNAL CPpToken c_macro_pragma_token(CSpellingSpace* space, CMacro* macro, CMacroArgument argument, CPpToken invocation)
{
    char8 const* base = space->base;
    CPpToken result = invocation;
    result.token.kind = C_TOKEN_PRAGMA;
    result.token.punctuator = C_PUNCTUATOR_NONE;
    result.token.offset = 0;
    result.token.length = 0;
    result.token.symbol = 0;
    result.foreign = true;
    CPpToken* tokens = argument.expanded_tokens;
    u64 token_count = argument.expanded_token_count;
    if (string_equal(macro->name, S8("_Pragma")))
    {
        String8 first_spelling = token_count == 1 ? c_token_spelling(base, tokens[0].token) : (String8){0};
        // Text past the length field's reach stays length 0 like any other
        // malformed operand: the marker is dropped, and no real pragma body
        // approaches 64 KB.
        if (token_count == 1 && tokens[0].token.kind == C_TOKEN_STRING_LITERAL && first_spelling.length >= 2 &&
            first_spelling.length - 2 < C_TOKEN_LENGTH_OVERSIZED)
        {
            String8 inner = {
                .pointer = first_spelling.pointer + 1,
                .length = first_spelling.length - 2,
            };
            char8* spelling = c_space_allocate(space, inner.length + 1);
            u64 output = 0;
            for (u64 index = 0; index < inner.length; index += 1)
            {
                if (inner.pointer[index] == '\\' && index + 1 < inner.length)
                {
                    index += 1;
                }
                spelling[output++] = inner.pointer[index];
            }
            spelling[output] = 0;
            result.token.offset = c_space_offset(space, spelling);
            result.token.length = (u16)output;
        }
        return result;
    }
    u64 length = 0;
    for (u64 token_index = 0; token_index < token_count; token_index += 1)
    {
        length += c_token_length(base, tokens[token_index].token) + (token_index != 0);
    }
    if (length && length < C_TOKEN_LENGTH_OVERSIZED)
    {
        char8* spelling = c_space_allocate(space, length + 1);
        u64 output = 0;
        for (u64 token_index = 0; token_index < token_count; token_index += 1)
        {
            String8 token_spelling = c_token_spelling(base, tokens[token_index].token);
            if (token_index)
            {
                spelling[output++] = ' ';
            }
            if (token_spelling.length)
            {
                memcpy(spelling + output, token_spelling.pointer, token_spelling.length);
            }
            output += token_spelling.length;
        }
        spelling[output] = 0;
        result.token.offset = c_space_offset(space, spelling);
        result.token.length = (u16)output;
    }
    return result;
}

// The next argument that needs an expansion context of its own, or null
// once every remaining argument is resolved and the invocation is ready to
// materialize. Definition-owned demand is reused before inspecting any raw
// argument: unused, stringized-only and pasted-only parameters must not be
// prescanned. A mixed-use parameter still needs one expansion, shared by all
// ordinary uses. Pragma operands are expanded despite their empty replacement.
// An argument none of whose identifiers names a defined macro
// — disabled ones included, since a name the disabled bit refuses must
// still be painted no_expand — rescans to exactly itself, so its expansion
// aliases its tokens instead of paying a child context, a task node and an
// output node per token to copy them unchanged, which is most arguments.
// The prescan looks up each identifier in the order the child would have,
// so a symbol-0 token (pasted or synthesized) interns at the same point
// either way.
BUSTER_C_INTERNAL CMacroExpansionContext* c_macro_continuation_advance(Arena* arena, CMacro* first_macro, CSymbolTable* symbols, char8 const* base,
                                                                        CMacroExpansionContinuation* continuation, CMacroExpansionTaskStack* tasks)
{
    CMacroExpansionContext* child = 0;
    while (!child && continuation->argument_index < continuation->argument_count)
    {
        CMacroArgument* argument = continuation->arguments + continuation->argument_index;
        bool used_expanded = continuation->macro->definition.pragma_like ||
                             continuation->macro->definition.parameter_expand_count[continuation->argument_index] != 0;
        bool needs_expansion = false;
        for (u64 token_index = 0; used_expanded && token_index < argument->token_count && !needs_expansion; token_index += 1)
        {
            CPpToken token = argument->tokens[token_index];
            if (token.token.kind == C_TOKEN_IDENTIFIER && !token.no_expand)
            {
                CMacro* macro = c_macro_find_token(first_macro, symbols, base, &token.token);
                needs_expansion = macro && macro->definition.defined;
            }
        }
        if (needs_expansion)
        {
            child = arena_allocate(arena, CMacroExpansionContext, 1);
            *child = (CMacroExpansionContext){
                .parent = continuation->parent,
                .continuation = continuation,
                .task_base = tasks->count,
            };
            c_macro_expansion_tasks_push(arena, tasks, argument->tokens, argument->token_count, 0);
        }
        else
        {
            argument->expanded_tokens = argument->tokens;
            argument->expanded_token_count = argument->token_count;
            continuation->argument_index += 1;
        }
    }
    return child;
}

// The paste-free, stringify-free replacement of a non-builtin macro written
// straight into its task batch: the same rows the plain branch of
// c_macro_replacement_tokens stages, minus the staging array and its copy.
// The batch size is exact (plain_count plus each parameter's ordinary-use count
// times its expanded count), so one reservation precedes every write; the ENABLE
// marker takes the batch base and the substituted list is written downward
// from the batch end, the reverse order c_macro_expansion_tasks_push stores.
// Sources are the definition and argument arrays, never task storage, so
// nothing here reads rows the reservation may have moved.
BUSTER_C_INTERNAL void c_macro_produce_plain_tasks(Arena* arena, CMacroExpansionTaskStack* tasks, CMacro* macro, CMacroArgument const* arguments,
                                                    CPpToken invocation)
{
    u32 stamp = invocation.stamp;
    u8 const* definition_spaces = macro->definition.replacement_space;
    u32 const* parameter_indices = macro->definition.parameter_index;
    u32 parameter_count = arguments ? macro->definition.parameter_count : 0;
    u64 token_count = macro->definition.plain_count;
    for (u32 parameter_index = 0; parameter_index < parameter_count; parameter_index += 1)
    {
        token_count += (u64)macro->definition.parameter_expand_count[parameter_index] * arguments[parameter_index].expanded_token_count;
    }
    c_macro_expansion_tasks_reserve(arena, tasks, token_count, true);
    CMacroExpansionTask* batch = tasks->data + tasks->count;
    batch[0] = (CMacroExpansionTask){.macro = macro, .kind = C_MACRO_EXPANSION_ENABLE};
    CMacroExpansionTask* cursor = batch + 1 + token_count;
    for (u32 replacement_index = 0; replacement_index < macro->definition.replacement_count; replacement_index += 1)
    {
        bool replacement_space = replacement_index ? !definition_spaces || definition_spaces[replacement_index] != 0 : invocation.preceded_by_space;
        u32 parameter_index = parameter_indices[replacement_index];
        if (parameter_index == C_MACRO_PARAMETER_NONE || !arguments)
        {
            cursor -= 1;
            *cursor = (CMacroExpansionTask){
                .token = {
                    .token = macro->definition.replacement[replacement_index],
                    .stamp = stamp & C_PP_STAMP_MASK,
                    .foreign = true,
                    .preceded_by_space = replacement_space,
                },
                .kind = C_MACRO_EXPANSION_TOKEN,
            };
        }
        else
        {
            CMacroArgument argument = arguments[parameter_index];
            for (u64 argument_index = 0; argument_index < argument.expanded_token_count; argument_index += 1)
            {
                CPpToken argument_token = argument.expanded_tokens[argument_index];
                argument_token.stamp = stamp & C_PP_STAMP_MASK;
                argument_token.foreign = true;
                if (!argument_index)
                {
                    argument_token.preceded_by_space = replacement_space;
                }
                cursor -= 1;
                *cursor = (CMacroExpansionTask){.token = argument_token, .kind = C_MACRO_EXPANSION_TOKEN};
            }
        }
    }
    BUSTER_ASSERT(cursor == batch + 1);
    tasks->count += 1 + token_count;
}

// Materialize a resolved invocation into `target`, the context its
// replacement rescans in: the replacement tokens are pushed under the
// macro's disabled bit, or, for a pragma-like macro, the operand becomes one
// pragma marker token in the output. False when the replacement list itself
// is invalid (an edge `##`, a paste that forms no token), diagnosed there.
// A pragma-like definition has no replacement list to build; a plain one is
// produced into its batch directly; builtins, `#` and `##` stage first.
BUSTER_C_INTERNAL bool c_macro_materialize(Arena* arena, CSpellingSpace* space, CMacro* first_macro, CMacro* macro, CMacroArgument* arguments,
                                            u32 argument_count, CPpToken invocation, CPpStampTable const* stamps, CPreprocessResult* result,
                                            CMacroExpansionContext* target, CMacroExpansionTaskStack* tasks)
{
    bool ok = true;
    if (macro->definition.pragma_like)
    {
        if (argument_count == 1)
        {
            CPpToken pragma = c_macro_pragma_token(space, macro, arguments[0], invocation);
            c_preprocess_output_push(arena, &target->first_output, &target->last_output, pragma, &target->output_count);
        }
    }
    else if (!macro->builtin && !macro->definition.has_paste && !macro->definition.has_stringify)
    {
        macro->disabled = true;
        c_macro_produce_plain_tasks(arena, tasks, macro, arguments, invocation);
    }
    else
    {
        CPpToken* replacement_tokens = 0;
        u32 replacement_count = 0;
        ok = c_macro_replacement_tokens(arena, space, first_macro, macro, arguments, invocation, stamps, result, &replacement_tokens, &replacement_count);
        if (ok)
        {
            macro->disabled = true;
            c_macro_expansion_tasks_push(arena, tasks, replacement_tokens, replacement_count, macro);
        }
    }
    return ok;
}

// `frame` and `file` locate the input's unstamped tokens on demand into
// `stamps` (see CPpToken.stamp); null when every input token is stamped
// already.
BUSTER_C_INTERNAL bool c_preprocess_expand(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols, CMacro* first_macro,
                                             struct CPreprocessSourceFrame* frame, u32 file, CPpStampTable* stamps, CPpToken* input, u32 input_count,
                                             CPreprocessTokenNode** first_output, CPreprocessTokenNode** last_output, u64* output_count, u32 expansion_limit,
                                             CPreprocessResult* result)
{
    CMacroExpansionContext* context = arena_allocate(arena, CMacroExpansionContext, 1);
    *context = (CMacroExpansionContext){
        .first_output = *first_output,
        .last_output = *last_output,
        .output_count = *output_count,
    };
    CMacroExpansionTask local_tasks[C_MACRO_EXPANSION_LOCAL_TASK_CAPACITY];
    CMacroExpansionTaskStack tasks = {.data = local_tasks, .capacity = BUSTER_ARRAY_LENGTH(local_tasks)};
    c_macro_expansion_tasks_push(arena, &tasks, input, input_count, 0);
    u32 expansion_count = 0;
    bool ok = true;
    bool done = false;
    while (!done)
    {
        if (tasks.count == context->task_base)
        {
            CMacroExpansionContinuation* continuation = context->continuation;
            if (!continuation)
            {
                *first_output = context->first_output;
                *last_output = context->last_output;
                *output_count = context->output_count;
                done = true;
            }
            else
            {
                CMacroArgument* argument = continuation->arguments + continuation->argument_index;
                argument->expanded_tokens = arena_allocate(arena, CPpToken, context->output_count);
                argument->expanded_token_count = context->output_count;
                u64 expanded_index = 0;
                for (CPreprocessTokenNode* node = context->first_output; node; node = node->next)
                {
                    argument->expanded_tokens[expanded_index++] = node->token;
                }
                continuation->argument_index += 1;
                CMacroExpansionContext* child = c_macro_continuation_advance(arena, first_macro, symbols, space->base, continuation, &tasks);
                if (child)
                {
                    context = child;
                }
                else
                {
                    context = continuation->parent;
                    ok = c_macro_materialize(arena, space, first_macro, continuation->macro, continuation->arguments, continuation->argument_count,
                                             continuation->invocation, stamps, result, context, &tasks);
                    done = !ok;
                }
            }
        }
        else
        {
            CMacroExpansionTask task = tasks.data[--tasks.count];
            if (task.kind == C_MACRO_EXPANSION_ENABLE)
            {
                task.macro->disabled = false;
            }
            else
            {
                CPpToken token = task.token;
                CMacro* macro = token.token.kind == C_TOKEN_IDENTIFIER && !token.no_expand
                                    ? c_macro_find_token(first_macro, symbols, space->base, &token.token)
                                    : 0;
                if (!macro || !macro->definition.defined || macro->disabled)
                {
                    // The disabled bit is cleared as soon as this rescan
                    // ends, so a name it refused here would expand on any
                    // later rescan the token survives into -- the one an
                    // argument's expanded tokens get in the parent context.
                    // Paint the refusal onto the token instead.
                    token.no_expand = token.no_expand || (macro && macro->definition.defined && macro->disabled);
                    c_preprocess_output_push(arena, &context->first_output, &context->last_output, token, &context->output_count);
                }
                else
                {
                    // The invocation's location: the stamp its replacement
                    // carries, and what its diagnostics point at.
                    if (!token.foreign && !token.stamp)
                    {
                        token.stamp = c_pp_stamp_push(stamps, c_preprocess_recover_location(frame, file, token.token)) & C_PP_STAMP_MASK;
                    }
                    CMacroArgument* arguments = 0;
                    u32 argument_count = 0;
                    bool invoked = true;
                    if (macro->definition.function_like)
                    {
                        invoked = c_macro_invocation_arguments(arena, space->base, &tasks, context->task_base, macro, c_pp_stamp_location(stamps, token.stamp), &arguments,
                                                               &argument_count, result);
                        if (!invoked)
                        {
                            c_preprocess_output_push(arena, &context->first_output, &context->last_output, token, &context->output_count);
                        }
                        else if (argument_count != macro->definition.parameter_count)
                        {
                            // Diagnosed by the collection; the invocation is dropped.
                            invoked = false;
                        }
                    }
                    if (invoked)
                    {
                        expansion_count += 1;
                        result->detail->preprocessed.expansions += 1;
                        if (expansion_count > expansion_limit)
                        {
                            c_preprocess_diagnostic_push(arena, result, c_pp_stamp_location(stamps, token.stamp), C_DIAGNOSTIC_MACRO_EXPANSION_LIMIT,
                                                         S8("macro expansion limit exceeded"));
                            ok = false;
                            done = true;
                        }
                        else if (macro->definition.function_like && argument_count)
                        {
                            CMacroExpansionContinuation* continuation = arena_allocate(arena, CMacroExpansionContinuation, 1);
                            *continuation = (CMacroExpansionContinuation){
                                .parent = context,
                                .macro = macro,
                                .arguments = arguments,
                                .invocation = token,
                                .argument_count = argument_count,
                            };
                            CMacroExpansionContext* child = c_macro_continuation_advance(arena, first_macro, symbols, space->base, continuation, &tasks);
                            if (child)
                            {
                                context = child;
                            }
                            else
                            {
                                ok = c_macro_materialize(arena, space, first_macro, macro, arguments, argument_count, token, stamps, result, context, &tasks);
                                done = !ok;
                            }
                        }
                        else
                        {
                            ok = c_macro_materialize(arena, space, first_macro, macro, arguments, argument_count, token, stamps, result, context, &tasks);
                            done = !ok;
                        }
                    }
                }
            }
        }
    }
    return ok;
}

BUSTER_C_SHARED u32 c_conditional_precedence(CConditionalOperator operation)
{
    switch (operation)
    {
    case C_CONDITIONAL_COMMA:
        return 0;
    case C_CONDITIONAL_QUESTION:
    case C_CONDITIONAL_SELECT:
        return 1;
    case C_CONDITIONAL_LOGICAL_OR:
        return 2;
    case C_CONDITIONAL_LOGICAL_AND:
        return 3;
    case C_CONDITIONAL_BITWISE_OR:
        return 4;
    case C_CONDITIONAL_BITWISE_XOR:
        return 5;
    case C_CONDITIONAL_BITWISE_AND:
        return 6;
    case C_CONDITIONAL_EQUAL:
    case C_CONDITIONAL_NOT_EQUAL:
        return 7;
    case C_CONDITIONAL_LESS:
    case C_CONDITIONAL_LESS_EQUAL:
    case C_CONDITIONAL_GREATER:
    case C_CONDITIONAL_GREATER_EQUAL:
        return 8;
    case C_CONDITIONAL_SHIFT_LEFT:
    case C_CONDITIONAL_SHIFT_RIGHT:
        return 9;
    case C_CONDITIONAL_ADD:
    case C_CONDITIONAL_SUBTRACT:
        return 10;
    case C_CONDITIONAL_MULTIPLY:
    case C_CONDITIONAL_DIVIDE:
    case C_CONDITIONAL_REMAINDER:
        return 11;
    case C_CONDITIONAL_UNARY_PLUS:
    case C_CONDITIONAL_UNARY_MINUS:
    case C_CONDITIONAL_LOGICAL_NOT:
    case C_CONDITIONAL_BITWISE_NOT:
    case C_CONDITIONAL_REAL_PART:
    case C_CONDITIONAL_IMAGINARY_PART:
    case C_CONDITIONAL_ADDRESS_OF:
    case C_CONDITIONAL_DEREFERENCE:
    case C_CONDITIONAL_CAST:
        return 12;
    case C_CONDITIONAL_OPEN:
    case C_CONDITIONAL_INDEX_OPEN:
    case C_CONDITIONAL_OPERATOR_COUNT:
        return 0;
    }
    return 0;
}

BUSTER_C_SHARED bool c_conditional_is_unary(CConditionalOperator operation)
{
    return operation >= C_CONDITIONAL_UNARY_PLUS && operation <= C_CONDITIONAL_CAST;
}

BUSTER_C_SHARED bool c_conditional_operator(CToken token, bool unary, CConditionalOperator* operation)
{
    if (token.kind != C_TOKEN_PUNCTUATOR)
    {
        return false;
    }
    // Punctuator ids and spellings are one-to-one, so matching the id is the
    // spelling compare the previous ladder spelled out.
#define C_CONDITIONAL_MATCH(punctuator, binary_operation, unary_operation)                                                                                     \
    case punctuator:                                                                                                                                           \
    {                                                                                                                                                          \
        *operation = unary ? (unary_operation) : (binary_operation);                                                                                           \
        return *operation != C_CONDITIONAL_OPERATOR_COUNT;                                                                                                     \
    }
    switch (token.punctuator)
    {
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_PLUS, C_CONDITIONAL_ADD, C_CONDITIONAL_UNARY_PLUS)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_MINUS, C_CONDITIONAL_SUBTRACT, C_CONDITIONAL_UNARY_MINUS)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_EXCLAMATION, C_CONDITIONAL_OPERATOR_COUNT, C_CONDITIONAL_LOGICAL_NOT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_TILDE, C_CONDITIONAL_OPERATOR_COUNT, C_CONDITIONAL_BITWISE_NOT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_STAR, C_CONDITIONAL_MULTIPLY, C_CONDITIONAL_DEREFERENCE)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_SLASH, C_CONDITIONAL_DIVIDE, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_PERCENT, C_CONDITIONAL_REMAINDER, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_SHIFT_LEFT, C_CONDITIONAL_SHIFT_LEFT, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_SHIFT_RIGHT, C_CONDITIONAL_SHIFT_RIGHT, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_LESS, C_CONDITIONAL_LESS, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_LESS_EQUAL, C_CONDITIONAL_LESS_EQUAL, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_GREATER, C_CONDITIONAL_GREATER, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_GREATER_EQUAL, C_CONDITIONAL_GREATER_EQUAL, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_EQUAL, C_CONDITIONAL_EQUAL, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_NOT_EQUAL, C_CONDITIONAL_NOT_EQUAL, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_AMPERSAND, C_CONDITIONAL_BITWISE_AND, C_CONDITIONAL_ADDRESS_OF)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_CARET, C_CONDITIONAL_BITWISE_XOR, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_PIPE, C_CONDITIONAL_BITWISE_OR, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_COMMA, C_CONDITIONAL_COMMA, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_AMPERSAND_AMPERSAND, C_CONDITIONAL_LOGICAL_AND, C_CONDITIONAL_OPERATOR_COUNT)
        C_CONDITIONAL_MATCH(C_PUNCTUATOR_PIPE_PIPE, C_CONDITIONAL_LOGICAL_OR, C_CONDITIONAL_OPERATOR_COUNT)
    default:
    {
        break;
    }
    }
#undef C_CONDITIONAL_MATCH
    return false;
}

// Keep integer admission independent of expression evaluation. Preprocessing,
// syntax validation, ordinary lowering and wide-float initialization share this
// bounded reader; type selection and dialect policy remain with their callers.
BUSTER_C_SHARED bool c_number_is_float(String8 spelling)
{
    bool floating = false;
    bool hexadecimal = spelling.length >= 2 && spelling.pointer[0] == '0' && (spelling.pointer[1] == 'x' || spelling.pointer[1] == 'X');
    for (u64 index = 0; !floating && index < spelling.length; index += 1)
    {
        u8 byte = spelling.pointer[index];
        floating = byte == '.' || byte == 'p' || byte == 'P' || (!hexadecimal && (byte == 'e' || byte == 'E'));
    }
    return floating;
}

// Microsoft SDK limits use i8/i16/i32 as well as i64. Keep admission and
// the lowerer's fixed-width type choice on one bounded suffix decoder.
BUSTER_C_SHARED u32 c_integer_msvc_suffix_width(String8 suffix)
{
    u32 width = 0;
    u64 index = suffix.length && (suffix.pointer[0] == 'u' || suffix.pointer[0] == 'U');
    if (index < suffix.length && (suffix.pointer[index] == 'i' || suffix.pointer[index] == 'I'))
    {
        index += 1;
        u64 digits = suffix.length - index;
        if (digits == 1 && suffix.pointer[index] == '8')
        {
            width = 8;
        }
        else if (digits == 2)
        {
            u8 first = suffix.pointer[index];
            u8 second = suffix.pointer[index + 1];
            if (first == '1' && second == '6')
            {
                width = 16;
            }
            else if (first == '3' && second == '2')
            {
                width = 32;
            }
            else if (first == '6' && second == '4')
            {
                width = 64;
            }
        }
    }
    return width;
}

BUSTER_C_SHARED u32 c_integer_msvc_literal_width(String8 spelling, bool* is_unsigned)
{
    u32 width = 0;
    for (u32 length = 2; !width && length <= 3 && length <= spelling.length; length += 1)
    {
        u64 start = spelling.length - length;
        width = c_integer_msvc_suffix_width((String8){.pointer = spelling.pointer + start, .length = length});
        if (width)
        {
            *is_unsigned = start && (spelling.pointer[start - 1] == 'u' || spelling.pointer[start - 1] == 'U');
        }
    }
    return width;
}

BUSTER_C_INTERNAL bool c_integer_suffix_valid(String8 suffix)
{
    bool valid = !suffix.length;
    if (suffix.length)
    {
        bool first_unsigned = suffix.pointer[0] == 'u' || suffix.pointer[0] == 'U';
        bool first_long = suffix.pointer[0] == 'l' || suffix.pointer[0] == 'L';
        if (c_integer_msvc_suffix_width(suffix))
        {
            valid = true;
        }
        else if (suffix.length == 1)
        {
            valid = first_unsigned || first_long;
        }
        else if (suffix.length == 2 || suffix.length == 3)
        {
            bool second_unsigned = suffix.pointer[1] == 'u' || suffix.pointer[1] == 'U';
            bool second_long = suffix.pointer[1] == 'l' || suffix.pointer[1] == 'L';
            bool long_pair = first_long && second_long && suffix.pointer[0] == suffix.pointer[1];
            if (suffix.length == 2)
            {
                valid = long_pair || (first_unsigned && second_long) || (first_long && second_unsigned);
            }
            else
            {
                bool third_unsigned = suffix.pointer[2] == 'u' || suffix.pointer[2] == 'U';
                bool third_long = suffix.pointer[2] == 'l' || suffix.pointer[2] == 'L';
                valid = (first_unsigned && second_long && third_long && suffix.pointer[1] == suffix.pointer[2]) ||
                        (long_pair && third_unsigned);
            }
        }
    }
    return valid;
}

BUSTER_C_INTERNAL u32 c_integer_digit(u8 byte)
{
    u32 digit = UINT32_MAX;
    if (byte >= '0' && byte <= '9')
    {
        digit = (u32)(byte - '0');
    }
    else if (byte >= 'a' && byte <= 'f')
    {
        digit = (u32)(byte - 'a') + 10;
    }
    else if (byte >= 'A' && byte <= 'F')
    {
        digit = (u32)(byte - 'A') + 10;
    }
    return digit;
}

BUSTER_C_SHARED bool c_conditional_number(String8 spelling, u64* value)
{
    u32 base = 10;
    u64 index = 0;
    if (spelling.length >= 2 && spelling.pointer[0] == '0')
    {
        if (spelling.pointer[1] == 'x' || spelling.pointer[1] == 'X')
        {
            base = 16;
            index = 2;
        }
        else if (spelling.pointer[1] == 'b' || spelling.pointer[1] == 'B')
        {
            base = 2;
            index = 2;
        }
        else
        {
            base = 8;
        }
    }
    u64 parsed = 0;
    u64 cutoff = UINT64_MAX / base;
    u32 last_digit = (u32)(UINT64_MAX % base);
    bool any = false;
    bool valid = true;
    while (valid && index < spelling.length)
    {
        u8 byte = spelling.pointer[index];
        if (byte == '\'')
        {
            // A separator joins two digits of this base, never a prefix or
            // suffix. Checking the next byte also rejects consecutive quotes.
            valid = any && index + 1 < spelling.length && c_integer_digit(spelling.pointer[index + 1]) < base;
            index += 1;
        }
        else
        {
            u32 digit = c_integer_digit(byte);
            if (digit >= base)
            {
                break;
            }
            valid = parsed < cutoff || (parsed == cutoff && digit <= last_digit);
            if (valid)
            {
                parsed = parsed * base + digit;
                any = true;
                index += 1;
            }
        }
    }
    valid = valid && any && c_integer_suffix_valid((String8){.pointer = spelling.pointer + index, .length = spelling.length - index});
    if (valid)
    {
        *value = parsed;
    }
    return valid;
}

// C11 6.10.1p4: conditional-inclusion arithmetic uses intmax_t or
// uintmax_t. Keep signedness and deferred arithmetic faults in the existing
// one-byte-per-value sidecar. Reductions still validate every operand's syntax,
// but &&, || and ?: discard faults from operands they do not evaluate.
// A fault always follows an evaluated condition/left operand, even when its
// placeholder value makes a later logical expression appear to succeed.
enum
{
    C_CONDITIONAL_VALUE_UNSIGNED = 1,
    C_CONDITIONAL_VALUE_FAULT = 2,
};

BUSTER_C_INTERNAL bool c_conditional_apply(CConditionalOperator operation, u64* values, u8* value_flags, u32* value_count)
{
    bool valid = true;
    if (c_conditional_is_unary(operation))
    {
        if (!*value_count)
        {
            valid = false;
        }
        else
        {
            u32 index = *value_count - 1;
            u64* value = values + index;
            switch (operation)
            {
            case C_CONDITIONAL_UNARY_PLUS:
                break;
            case C_CONDITIONAL_UNARY_MINUS:
                *value = 0 - *value;
                break;
            case C_CONDITIONAL_LOGICAL_NOT:
                *value = !*value;
                value_flags[index] &= C_CONDITIONAL_VALUE_FAULT;
                break;
            case C_CONDITIONAL_BITWISE_NOT:
                *value = ~*value;
                break;
            default:
                valid = false;
                break;
            }
        }
    }
    else if (operation == C_CONDITIONAL_SELECT)
    {
        if (*value_count < 3)
        {
            valid = false;
        }
        else
        {
            u64 false_value = values[--*value_count];
            u8 false_flags = value_flags[*value_count];
            u64 true_value = values[--*value_count];
            u8 true_flags = value_flags[*value_count];
            u32 index = *value_count - 1;
            u64* condition = values + index;
            u8 selected_flags = *condition ? true_flags : false_flags;
            // Both arms determine the common type, but only the selected
            // arm and the always-evaluated condition contribute faults.
            value_flags[index] = (u8)(((true_flags | false_flags) & C_CONDITIONAL_VALUE_UNSIGNED) |
                                     ((value_flags[index] | selected_flags) & C_CONDITIONAL_VALUE_FAULT));
            *condition = *condition ? true_value : false_value;
        }
    }
    else if (*value_count < 2)
    {
        valid = false;
    }
    else
    {
        u64 right = values[--*value_count];
        u8 right_flags = value_flags[*value_count];
        u32 index = *value_count - 1;
        u64* left = values + index;
        u8 left_flags = value_flags[index];
        u8 flags = (u8)(left_flags | right_flags);
        bool mixed_unsigned = (flags & C_CONDITIONAL_VALUE_UNSIGNED) != 0;
        switch (operation)
        {
        case C_CONDITIONAL_MULTIPLY:
            *left *= right;
            break;
        case C_CONDITIONAL_DIVIDE:
        case C_CONDITIONAL_REMAINDER:
            // Never execute an invalid host division, even in a subtree
            // whose fault will be discarded by an enclosing short circuit.
            if ((flags & C_CONDITIONAL_VALUE_FAULT) || !right ||
                (!mixed_unsigned && (s64)*left == INT64_MIN && (s64)right == -1))
            {
                flags |= C_CONDITIONAL_VALUE_FAULT;
                *left = 0;
            }
            else if (mixed_unsigned)
            {
                *left = operation == C_CONDITIONAL_DIVIDE ? *left / right : *left % right;
            }
            else
            {
                *left = operation == C_CONDITIONAL_DIVIDE ? (u64)((s64)*left / (s64)right) : (u64)((s64)*left % (s64)right);
            }
            break;
        case C_CONDITIONAL_ADD:
            *left += right;
            break;
        case C_CONDITIONAL_SUBTRACT:
            *left -= right;
            break;
        case C_CONDITIONAL_SHIFT_LEFT:
            *left = right < 64 ? *left << right : 0;
            flags = (u8)((flags & C_CONDITIONAL_VALUE_FAULT) | (left_flags & C_CONDITIONAL_VALUE_UNSIGNED));
            break;
        case C_CONDITIONAL_SHIFT_RIGHT:
            if (left_flags & C_CONDITIONAL_VALUE_UNSIGNED)
            {
                *left = right < 64 ? *left >> right : 0;
            }
            else
            {
                *left = right < 64 ? (u64)((s64)*left >> right) : (u64)((s64)*left >> 63);
            }
            flags = (u8)((flags & C_CONDITIONAL_VALUE_FAULT) | (left_flags & C_CONDITIONAL_VALUE_UNSIGNED));
            break;
        case C_CONDITIONAL_LESS:
            *left = mixed_unsigned ? *left < right : (s64)*left < (s64)right;
            flags &= C_CONDITIONAL_VALUE_FAULT;
            break;
        case C_CONDITIONAL_LESS_EQUAL:
            *left = mixed_unsigned ? *left <= right : (s64)*left <= (s64)right;
            flags &= C_CONDITIONAL_VALUE_FAULT;
            break;
        case C_CONDITIONAL_GREATER:
            *left = mixed_unsigned ? *left > right : (s64)*left > (s64)right;
            flags &= C_CONDITIONAL_VALUE_FAULT;
            break;
        case C_CONDITIONAL_GREATER_EQUAL:
            *left = mixed_unsigned ? *left >= right : (s64)*left >= (s64)right;
            flags &= C_CONDITIONAL_VALUE_FAULT;
            break;
        case C_CONDITIONAL_EQUAL:
            *left = *left == right;
            flags &= C_CONDITIONAL_VALUE_FAULT;
            break;
        case C_CONDITIONAL_NOT_EQUAL:
            *left = *left != right;
            flags &= C_CONDITIONAL_VALUE_FAULT;
            break;
        case C_CONDITIONAL_BITWISE_AND:
            *left &= right;
            break;
        case C_CONDITIONAL_BITWISE_XOR:
            *left ^= right;
            break;
        case C_CONDITIONAL_BITWISE_OR:
            *left |= right;
            break;
        case C_CONDITIONAL_LOGICAL_AND:
            flags = (u8)((left_flags | (*left ? right_flags : 0)) & C_CONDITIONAL_VALUE_FAULT);
            *left = *left && right;
            break;
        case C_CONDITIONAL_LOGICAL_OR:
            flags = (u8)((left_flags | (*left ? 0 : right_flags)) & C_CONDITIONAL_VALUE_FAULT);
            *left = *left || right;
            break;
        default:
            valid = false;
            break;
        }
        value_flags[index] = flags;
    }
    return valid;
}

typedef enum CIncludeSearchKind
{
    C_INCLUDE_SEARCH_NONE,
    C_INCLUDE_SEARCH_QUOTED,
    C_INCLUDE_SEARCH_INCLUDE_PATH,
    C_INCLUDE_SEARCH_BUILTIN,
    C_INCLUDE_SEARCH_SYSTEM_PATH,
} CIncludeSearchKind;

typedef struct CIncludeSearchOrigin CIncludeSearchOrigin;
struct CIncludeSearchOrigin
{
    CIncludeSearchKind kind;
    u32 index;
};

BUSTER_C_INTERNAL bool c_include_resolve(Arena* arena, CPreprocessOptions options, String8 including_path, String8 name, bool quoted, String8* path_out,
                                           String8* source_out, FileMapRead* map_out, CIncludeSearchOrigin* origin_out);

BUSTER_C_INTERNAL bool c_include_resolve_next(Arena* arena, CPreprocessOptions options, String8 name, String8* path_out,
                                                String8* source_out, FileMapRead* map_out, CIncludeSearchOrigin origin,
                                                CIncludeSearchOrigin* origin_out);

BUSTER_C_INTERNAL bool c_include_name(Arena* arena, char8 const* base, CToken* tokens, u32 token_count, String8* name_out, bool* quoted_out);

BUSTER_C_INTERNAL bool c_conditional_builtin_supported(String8 name, CpuArch cpu_arch)
{
    static char const* supported[] = {
        "__builtin___clear_cache", "__builtin_acos",
        "__builtin_acosf",         "__builtin_ceil",
        "__builtin_ceilf",         "__builtin_clz",
        "__builtin_clzl",          "__builtin_clzll",
        "__builtin_cos",           "__builtin_cosf",
        "__builtin_ctz",           "__builtin_ctzl",
        "__builtin_ctzll",         "__builtin_debugtrap",
        "__builtin_ffs",
        "__builtin_ffsl",
        "__builtin_ffsll",
        "__builtin_popcount",      "__builtin_popcountl",
        "__builtin_popcountll",
        "__builtin_assume_aligned", "__builtin_choose_expr",
        "__builtin_constant_p",    "__builtin_object_size",
        "__builtin_expect",        "__builtin_expect_with_probability",
        "__builtin_fabs",          "__builtin_fabsf",
        "__builtin_floor",         "__builtin_floorf",
        "__builtin_fmod",          "__builtin_fmodf",
        "__builtin_pow",           "__builtin_powf",
        "__builtin_prefetch",
        "__builtin_round",         "__builtin_roundf",
        "__builtin_inff",          "__builtin_nan", "__builtin_nanf", "__builtin_huge_val", "__builtin_isnan", "__builtin_isnanf",
        "__builtin_isinf_sign",
        "__builtin_isinf",         "__builtin_isinff", "__builtin_isfinite",
        "__builtin_signbit",       "__builtin_signbitf", "__builtin_signbitl",
        "__builtin_memcpy",        "__builtin_memmove",
        "__builtin_memset",        "__builtin_memcmp",
        "__builtin___memcpy_chk", "__builtin___memmove_chk", "__builtin___memset_chk",
        "__builtin_sqrt",          "__builtin_sqrtf",
        "__builtin_strlen",        "__builtin_trap",
        "__builtin_ia32_pause",
        "__builtin_ia32_pslldi128", "__builtin_ia32_psllqi128",
        "__builtin_ia32_psradi128", "__builtin_ia32_psrldi128",
        "__builtin_ia32_psrlqi128",
        "__builtin_types_compatible_p", "__builtin_offsetof",
        "__builtin_unreachable",   "__builtin_frame_address",
        "__builtin_alloca",
        "__builtin_c23_va_start",
        "__builtin_va_arg",        "__builtin_va_copy",
        "__builtin_va_end",        "__builtin_va_start",
        "__is_target_arch",        "__is_target_environment",
        "__is_target_os",          "__is_target_vendor",
    };
    bool result = false;
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(supported) && !result; index += 1)
    {
        u64 length = strlen(supported[index]);
        result = name.length == length && memcmp(name.pointer, supported[index], length) == 0;
    }

    if (!result)
    {
        // These exact-name classes match the implemented complex constructor
        // and c_ir_atomic_builtin_spelling, not arbitrary __atomic_* prefixes.
        // Do not advertise every recognized builtin: other classes include
        // aliases and target intrinsics outside this query's support contract.
        // Native backends implement atomic IR; Wasm64 and eBPF reject it, and
        // eBPF also rejects floating-point operations. Operand type/width
        // restrictions remain the responsibility of semantic lowering.
        CSymbolBuiltin builtin = c_symbol_builtin_from_spelling(name);
        bool native = cpu_arch == CPU_ARCH_X86_64 || cpu_arch == CPU_ARCH_AARCH64;
        result = (builtin == C_SYMBOL_BUILTIN_ATOMIC && native) ||
                 (builtin == C_SYMBOL_BUILTIN_COMPLEX && (native || cpu_arch == CPU_ARCH_WASM64));
    }

    return result;
}

// GNU queries use the same spelling predicates/sets as layout and semantic
// lowering, not a list of attributes the parser merely skips (#639, #666).
// The selected target matters: the COFF writer cannot preserve weak
// definitions, and UEFI images refuse lifecycle registrations even though a
// UEFI relocatable object can carry their arrays. Keep those answers false.
BUSTER_C_INTERNAL bool c_conditional_attribute_supported(char8 const* base, CToken token, Target target)
{
    String8 name = c_token_spelling(base, token);
    u64 binding_words = 0;
    if (c_attribute_native_binding_target(target))
    {
        binding_words = C_ATTRIBUTE_WORDS_ALIAS;
        if (target.os != OPERATING_SYSTEM_WINDOWS && target.os != OPERATING_SYSTEM_UEFI)
        {
            binding_words |= C_ATTRIBUTE_WORDS_WEAK;
        }
        if (target.os != OPERATING_SYSTEM_UEFI)
        {
            binding_words |= C_ATTRIBUTE_WORDS_CONSTRUCTOR | C_ATTRIBUTE_WORDS_DESTRUCTOR;
        }
    }
    return c_parse_packed_word(name) || c_parse_aligned_attribute_word(name) || c_parse_vector_size_word(name) ||
           c_attribute_noreturn_word(name) || c_token_in_well_known_set(base, token, binding_words);
}

// `__has_c_attribute` is a different operator over a different namespace, and
// is deliberately not the query above. It asks about C's bracketed attributes,
// answering the standard attribute's version number -- clang 18 answers
// 202003L for `nodiscard` and 201910L for `fallthrough` -- 1 for a supported
// vendor attribute written with its namespace (`gnu::packed`), and 0
// otherwise, including for every GNU attribute named without one: clang
// answers 0 for a bare `packed`, `aligned` and `vector_size`.
//
// This frontend recognizes `[[ ... ]]` in c_parse_c23_attribute_at and steps
// over it; no bracketed attribute changes layout, diagnostics or code
// generation here, and c_parse_layout_attributes only ever reads
// `__attribute__` groups. Nothing is implemented, so the truthful answer is 0
// for every spelling, and a bare GNU name answers 0 here even though the GNU
// query above answers 1 for it. Implementing one of these attributes means
// returning its version number from here, not 1.
BUSTER_C_INTERNAL bool c_conditional_c_attribute_supported(void)
{
    return false;
}

// `__is_target_os` asks about the selected compilation target, and answers the
// spellings clang accepts for it rather than this compiler's internal enum
// names. The alias sets were read back out of clang 18 with `-target` and
// `-E`, which parses the spelling as a triple's OS component and compares it
// with the target's own: a Windows target answers `windows` and `win32`; a
// Darwin target answers `darwin` as well as its own `macos`/`macosx` or `ios`;
// UEFI answers `uefi`.
//
// Android is the case that cannot be answered from the enum name. Its triple
// carries Linux as the OS and Android as the environment, so clang answers
// `linux` for an Android target and never answers `android` at all -- the
// spelling is not an OS. A freestanding target has no triple OS and answers
// nothing (#640).
BUSTER_C_INTERNAL bool c_conditional_target_os_supported(OperatingSystem os, String8 spelling)
{
    bool result;
    switch (os)
    {
    case OPERATING_SYSTEM_LINUX:
    case OPERATING_SYSTEM_ANDROID:
        result = string_equal(spelling, S8("linux"));
        break;
    case OPERATING_SYSTEM_MACOS:
        result = string_equal(spelling, S8("macos")) || string_equal(spelling, S8("macosx")) || string_equal(spelling, S8("darwin"));
        break;
    case OPERATING_SYSTEM_IOS:
        result = string_equal(spelling, S8("ios")) || string_equal(spelling, S8("darwin"));
        break;
    case OPERATING_SYSTEM_WINDOWS:
        result = string_equal(spelling, S8("windows")) || string_equal(spelling, S8("win32"));
        break;
    case OPERATING_SYSTEM_UEFI:
        result = string_equal(spelling, S8("uefi"));
        break;
    case OPERATING_SYSTEM_WASI:
        result = string_equal(spelling, S8("wasip1")) || string_equal(spelling, S8("wasi"));
        break;
    case OPERATING_SYSTEM_FREESTANDING:
    case OPERATING_SYSTEM_COUNT:
    default:
        result = false;
        break;
    }
    return result;
}

BUSTER_C_INTERNAL bool c_conditional_feature_operators(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols, CMacro* first_macro,
                                                         CPreprocessTokenNode* first, CPreprocessOptions* options, String8 including_path,
                                                         CIncludeSearchOrigin including_origin)
{
    char8 const* base = space->base;
    for (CPreprocessTokenNode* node = first; node; node = node->next)
    {
        CToken token = node->token.token;
        if (token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("defined")))
        {
            CPreprocessTokenNode* name = node->next;
            bool parenthesized = name && c_token_is_punctuator(&name->token.token, C_PUNCTUATOR_LEFT_PARENTHESIS);
            name = parenthesized ? name->next : name;
            if (!name || name->token.token.kind != C_TOKEN_IDENTIFIER)
            {
                return false;
            }
            CPreprocessTokenNode* after = name->next;
            if (parenthesized)
            {
                if (!after || !c_token_is_punctuator(&after->token.token, C_PUNCTUATOR_RIGHT_PARENTHESIS))
                {
                    return false;
                }
                after = after->next;
            }
            CMacro* macro = c_macro_find_token(first_macro, symbols, base, &name->token.token);
            node->token.token.kind = C_TOKEN_PREPROCESSING_NUMBER;
            node->token.token.punctuator = C_PUNCTUATOR_NONE;
            node->token.token.offset = macro && macro->definition.defined ? C_SPELLING_ONE : C_SPELLING_ZERO;
            node->token.token.length = 1;
            node->token.token.symbol = 0;
            node->next = after;
            continue;
        }
        bool has_include = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__has_include"));
        bool has_include_next = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__has_include_next"));
        bool has_builtin = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__has_builtin"));
        bool has_attribute = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__has_attribute"));
        bool has_c_attribute = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__has_c_attribute"));
        bool has_feature =
            token.kind == C_TOKEN_IDENTIFIER && (c_token_spelling_equal(base, token, S8("__has_feature")) || c_token_spelling_equal(base, token, S8("__has_extension")) ||
                                                 c_token_spelling_equal(base, token, S8("__building_module")));
        bool is_target_arch = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__is_target_arch"));
        bool is_target_environment = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__is_target_environment"));
        bool is_target_os = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__is_target_os"));
        bool is_target_vendor = token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token, S8("__is_target_vendor"));
        if (!has_include && !has_include_next && !has_builtin && !has_attribute && !has_c_attribute && !has_feature && !is_target_arch &&
            !is_target_environment && !is_target_os && !is_target_vendor)
        {
            continue;
        }
        CPreprocessTokenNode* open = node->next;
        if (!open || !c_token_is_punctuator(&open->token.token, C_PUNCTUATOR_LEFT_PARENTHESIS))
        {
            return false;
        }
        CPreprocessTokenNode* close = 0;
        CPreprocessTokenNode* scan = open->next;
        u32 depth = 0;
        u32 argument_count = 0;
        for (; scan; scan = scan->next)
        {
            if (c_token_is_punctuator(&scan->token.token, C_PUNCTUATOR_LEFT_PARENTHESIS))
            {
                depth += 1;
            }
            else if (c_token_is_punctuator(&scan->token.token, C_PUNCTUATOR_RIGHT_PARENTHESIS))
            {
                if (!depth)
                {
                    close = scan;
                    break;
                }
                depth -= 1;
            }
            argument_count += 1;
        }
        if (!close)
        {
            return false;
        }
        CToken* arguments = arena_allocate(arena, CToken, argument_count);
        u32 argument_index = 0;
        for (scan = open->next; scan != close; scan = scan->next)
        {
            arguments[argument_index++] = scan->token.token;
        }
        bool supported = false;
        if (has_include || has_include_next)
        {
            String8 include_name = {0};
            bool quoted = false;
            String8 resolved_path = {0};
            String8 resolved_source = {0};
            supported = c_include_name(arena, base, arguments, argument_count, &include_name, &quoted) &&
                        options &&
                        (has_include_next ? c_include_resolve_next(arena, *options, include_name, &resolved_path, &resolved_source, 0, including_origin, 0)
                                          : c_include_resolve(arena, *options, including_path, include_name, quoted, &resolved_path, &resolved_source, 0, 0));
        }
        else if ((has_builtin || has_attribute) && argument_count == 1 && arguments[0].kind == C_TOKEN_IDENTIFIER)
        {
            supported = has_builtin ? c_conditional_builtin_supported(c_token_spelling(base, arguments[0]),
                                                                    options ? options->target.cpu_arch : CPU_ARCH_COUNT)
                                    : c_conditional_attribute_supported(base, arguments[0],
                                                                        options ? options->target : target_native);
        }
        else if (has_c_attribute && argument_count)
        {
            // Any non-empty argument shape the balanced scan above accepted,
            // so that the namespaced spelling this operator's own contract
            // admits -- `__has_c_attribute(gnu::packed)` -- answers 0 instead
            // of failing the directive, however the `::` is tokenized. An
            // empty argument list is still malformed and still fails below.
            supported = c_conditional_c_attribute_supported();
        }
        else if ((is_target_arch || is_target_environment || is_target_os || is_target_vendor) && argument_count == 1 &&
                 arguments[0].kind == C_TOKEN_IDENTIFIER && options)
        {
            String8 argument = c_token_spelling(base, arguments[0]);
            supported = is_target_arch        ? (options->target.cpu_arch == CPU_ARCH_AARCH64
                                                      ? string_equal(argument, S8("arm64")) || string_equal(argument, S8("aarch64"))
                                                  : options->target.cpu_arch == CPU_ARCH_WASM32 ? string_equal(argument, S8("wasm32"))
                                                  : options->target.cpu_arch == CPU_ARCH_WASM64 ? string_equal(argument, S8("wasm64"))
                                                  : options->target.cpu_arch == CPU_ARCH_BPFEL
                                                      ? string_equal(argument, S8("bpfel")) || string_equal(argument, S8("bpf")) ||
                                                            string_equal(argument, S8("ebpf"))
                                                      : string_equal(argument, S8("x86_64")))
                        : is_target_os          ? c_conditional_target_os_supported(options->target.os, argument)
                        : is_target_vendor      ? (options->target.os == OPERATING_SYSTEM_MACOS || options->target.os == OPERATING_SYSTEM_IOS) &&
                                                      string_equal(argument, S8("apple"))
                        : is_target_environment ? false
                                                : false;
        }
        else if (!has_feature)
        {
            return false;
        }
        node->token.token.kind = C_TOKEN_PREPROCESSING_NUMBER;
        node->token.token.punctuator = C_PUNCTUATOR_NONE;
        node->token.token.offset = supported ? C_SPELLING_ONE : C_SPELLING_ZERO;
        node->token.token.length = 1;
        node->token.token.symbol = 0;
        node->next = close->next;
    }
    return true;
}

// Parse-side constant queries share the reducer but retain their existing
// semantics; only conditional-inclusion arithmetic widens decoded types.
BUSTER_C_INTERNAL bool c_integer_expression_evaluate_with_features(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols, CMacro* first_macro,
                                                                     CPpStampTable* stamps, CPpToken* tokens, u32 token_count, u32 expansion_limit,
                                                                     bool preprocessor_arithmetic, CPreprocessResult* result,
                                                                     CPreprocessOptions* options, String8 including_path,
                                                                     CIncludeSearchOrigin including_origin, u64* value_out)
{
    bool valid = true;
    char8 const* base = space->base;
    CPpToken* transformed = arena_allocate(arena, CPpToken, token_count);
    u32 transformed_count = 0;
    for (u32 token_index = 0; valid && token_index < token_count; token_index += 1)
    {
        CPpToken token = tokens[token_index];
        if (token.token.kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, token.token, S8("defined")))
        {
            u32 name_index = token_index + 1;
            bool parenthesized = name_index < token_count && c_token_is_punctuator(&tokens[name_index].token, C_PUNCTUATOR_LEFT_PARENTHESIS);
            name_index += parenthesized;
            if (name_index >= token_count || tokens[name_index].token.kind != C_TOKEN_IDENTIFIER)
            {
                valid = false;
            }
            else
            {
                CMacro* macro = c_macro_find_token(first_macro, symbols, base, &tokens[name_index].token);
                CPpToken replacement = token;
                replacement.token.kind = C_TOKEN_PREPROCESSING_NUMBER;
                replacement.token.punctuator = C_PUNCTUATOR_NONE;
                replacement.token.offset = macro && macro->definition.defined ? C_SPELLING_ONE : C_SPELLING_ZERO;
                replacement.token.length = 1;
                replacement.token.symbol = 0;
                transformed[transformed_count++] = replacement;
                token_index = name_index;
                if (parenthesized)
                {
                    valid = token_index + 1 < token_count && c_token_is_punctuator(&tokens[token_index + 1].token, C_PUNCTUATOR_RIGHT_PARENTHESIS);
                    token_index += 1;
                }
            }
        }
        else
        {
            transformed[transformed_count++] = token;
        }
    }
    CPreprocessTokenNode* first_expanded = 0;
    CPreprocessTokenNode* last_expanded = 0;
    u64 expanded_count = 0;
    if (valid)
    {
        valid = c_preprocess_expand(arena, space, symbols, first_macro, 0, 0, stamps, transformed, transformed_count, &first_expanded,
                                    &last_expanded, &expanded_count, expansion_limit, result);
    }
    if (valid)
    {
        valid = c_conditional_feature_operators(arena, space, symbols, first_macro, first_expanded, options, including_path, including_origin);
    }
    if (valid)
    {
        u64* values = arena_allocate(arena, u64, expanded_count + 1);
        u8* value_flags = arena_allocate(arena, u8, expanded_count + 1);
        CConditionalOperator* operations = arena_allocate(arena, CConditionalOperator, expanded_count + 1);
        u32 value_count = 0;
        u32 operation_count = 0;
        bool expect_operand = true;
        for (CPreprocessTokenNode* node = first_expanded; valid && node; node = node->next)
        {
            CToken token = node->token.token;
            if (token.kind == C_TOKEN_PREPROCESSING_NUMBER)
            {
                u64 value = 0;
                String8 number_spelling = c_token_spelling(base, token);
                valid = expect_operand && c_conditional_number(number_spelling, &value);
                if (valid)
                {
                    // The literal is uintmax_t when it says so or when its
                    // value does not fit intmax_t. Character constants carry
                    // their decoded type only in preprocessing arithmetic.
                    bool literal_unsigned = value > (u64)INT64_MAX;
                    for (u64 suffix_index = 0; suffix_index < number_spelling.length; suffix_index += 1)
                    {
                        literal_unsigned |= number_spelling.pointer[suffix_index] == 'u' || number_spelling.pointer[suffix_index] == 'U';
                    }
                    value_flags[value_count] = literal_unsigned ? C_CONDITIONAL_VALUE_UNSIGNED : 0;
                    values[value_count++] = value;
                    expect_operand = false;
                }
            }
            else if (token.kind == C_TOKEN_CHARACTER_LITERAL)
            {
                u64 character = 0;
                CTypeKind character_kind = C_TYPE_INVALID;
                valid = expect_operand && c_ir_decode_character_value(arena, base, token, result->target, &character, &character_kind);
                bool character_unsigned = false;
                if (valid && preprocessor_arithmetic)
                {
                    IrTypeKind character_ir_kind;
                    u32 character_width = 0;
                    u32 character_alignment = 0;
                    bool character_signed = true;
                    valid = c_ir_scalar_type_properties(result->target, character_kind, &character_ir_kind, &character_width,
                                                        &character_signed, &character_alignment);
                    character_unsigned = valid && !character_signed;
                }
                if (valid)
                {
                    value_flags[value_count] = character_unsigned ? C_CONDITIONAL_VALUE_UNSIGNED : 0;
                    values[value_count++] = character;
                    expect_operand = false;
                }
            }
            else if (token.kind == C_TOKEN_IDENTIFIER)
            {
                valid = expect_operand;
                if (valid)
                {
                    value_flags[value_count] = 0;
                    values[value_count++] = c_preprocess_dialect_is_c23(result->dialect) && c_token_spelling_equal(base, token, S8("true"));
                    expect_operand = false;
                }
            }
            else if (token.kind != C_TOKEN_PUNCTUATOR)
            {
                valid = false;
            }
            else if (c_token_is_punctuator(&token, C_PUNCTUATOR_LEFT_PARENTHESIS))
            {
                valid = expect_operand;
                if (valid)
                {
                    operations[operation_count++] = C_CONDITIONAL_OPEN;
                }
            }
            else if (c_token_is_punctuator(&token, C_PUNCTUATOR_RIGHT_PARENTHESIS))
            {
                valid = !expect_operand;
                while (valid && operation_count && operations[operation_count - 1] != C_CONDITIONAL_OPEN)
                {
                    valid = c_conditional_apply(operations[--operation_count], values, value_flags, &value_count);
                }
                valid = valid && operation_count != 0;
                if (valid)
                {
                    operation_count -= 1;
                }
            }
            else if (c_token_is_punctuator(&token, C_PUNCTUATOR_QUESTION))
            {
                valid = !expect_operand;
                u32 precedence = c_conditional_precedence(C_CONDITIONAL_QUESTION);
                while (valid && operation_count && operations[operation_count - 1] != C_CONDITIONAL_OPEN &&
                       c_conditional_precedence(operations[operation_count - 1]) > precedence)
                {
                    valid = c_conditional_apply(operations[--operation_count], values, value_flags, &value_count);
                }
                if (valid)
                {
                    operations[operation_count++] = C_CONDITIONAL_QUESTION;
                    expect_operand = true;
                }
            }
            else if (c_token_is_punctuator(&token, C_PUNCTUATOR_COLON))
            {
                valid = !expect_operand;
                while (valid && operation_count && operations[operation_count - 1] != C_CONDITIONAL_QUESTION)
                {
                    CConditionalOperator previous = operations[--operation_count];
                    valid = previous != C_CONDITIONAL_OPEN && c_conditional_apply(previous, values, value_flags, &value_count);
                }
                valid = valid && operation_count != 0;
                if (valid)
                {
                    operations[operation_count - 1] = C_CONDITIONAL_SELECT;
                    expect_operand = true;
                }
            }
            else
            {
                CConditionalOperator operation = C_CONDITIONAL_OPERATOR_COUNT;
                valid = c_conditional_operator(token, expect_operand, &operation);
                bool unary = c_conditional_is_unary(operation);
                valid = valid && expect_operand == unary;
                u32 precedence = c_conditional_precedence(operation);
                while (valid && operation_count && operations[operation_count - 1] != C_CONDITIONAL_OPEN)
                {
                    CConditionalOperator previous = operations[operation_count - 1];
                    u32 previous_precedence = c_conditional_precedence(previous);
                    if (previous_precedence < precedence || (unary && previous_precedence == precedence))
                    {
                        break;
                    }
                    operation_count -= 1;
                    valid = c_conditional_apply(previous, values, value_flags, &value_count);
                }
                if (valid)
                {
                    operations[operation_count++] = operation;
                    expect_operand = true;
                }
            }
        }
        valid = valid && !expect_operand;
        while (valid && operation_count)
        {
            CConditionalOperator operation = operations[--operation_count];
            valid = operation != C_CONDITIONAL_OPEN && operation != C_CONDITIONAL_QUESTION &&
                    c_conditional_apply(operation, values, value_flags, &value_count);
        }
        valid = valid && value_count == 1 && !(value_flags[0] & C_CONDITIONAL_VALUE_FAULT);
        if (valid)
        {
            *value_out = values[0];
        }
    }
    return valid;
}

// The parse-side entry point: no macro table, so expansion is a pass-through
// and nothing ever allocates spelling bytes — the read-only space view over
// the finished result is enough, and any allocation attempt fails loudly.
BUSTER_C_SHARED bool c_integer_expression_evaluate(Arena* arena, char8 const* spelling_base, CToken* tokens, u32 token_count, u32 expansion_limit,
                                                       CPreprocessResult* result, u64* value_out)
{
    CSpellingSpace view = {
        .base = (char8*)spelling_base,
    };
    CPpToken* wrapped = arena_allocate(arena, CPpToken, token_count);
    for (u32 token_index = 0; token_index < token_count; token_index += 1)
    {
        wrapped[token_index] = (CPpToken){
            .token = tokens[token_index],
        };
    }
    return c_integer_expression_evaluate_with_features(arena, &view, 0, 0, 0, wrapped, token_count, expansion_limit, false, result, 0, (String8){0},
                                                       (CIncludeSearchOrigin){0}, value_out);
}

BUSTER_C_INTERNAL bool c_conditional_evaluate(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols, CMacro* first_macro, CPpStampTable* stamps,
                                                CPpToken* tokens, u32 token_count, u32 expansion_limit, CPreprocessResult* result, CPreprocessOptions options,
                                                String8 including_path, CIncludeSearchOrigin including_origin, bool* value_out)
{
    u64 value = 0;
    bool valid =
        c_integer_expression_evaluate_with_features(arena, space, symbols, first_macro, stamps, tokens, token_count, expansion_limit, true, result, &options, including_path,
                                                    including_origin, &value);
    *value_out = value != 0;
    return valid;
}

typedef struct CConditionalFrame CConditionalFrame;
struct CConditionalFrame
{
    CConditionalFrame* previous;
    CSourceLocation location;
    bool parent_active;
    bool active;
    bool branch_taken;
    bool else_seen;
};

BUSTER_C_INTERNAL bool c_preprocess_is_active(CConditionalFrame* conditional)
{
    return !conditional || conditional->active;
}

// The row scan the mask projection below replaces, kept as the definition of
// a line's end for a run that carries no shape sidecar and as the reference
// c_test_pp_class_masks_agree holds the mask path to.
BUSTER_C_INTERNAL u64 c_preprocess_line_end(CLexResult lex, u64 token_index)
{
    while (token_index < lex.token_count && lex.tokens[token_index].kind != C_TOKEN_NEWLINE && lex.tokens[token_index].kind != C_TOKEN_END_OF_FILE)
    {
        token_index += 1;
    }
    return token_index;
}

// The per-64-token class projection of one lexed run, built once when the run
// becomes a source frame and read by every per-line scan of the driver below.
//
// Every one of those scans asks the same closed set of questions of a token —
// does the line end here, is this a parenthesis, can this name a macro — and
// the one-byte shape sidecar answers all of them without touching a 12-byte
// row, so 64 tokens are one masked load and four compares. What that buys is
// not the compare but the advance: a line end becomes a trailing-zero count
// instead of a nine-step row loop with a mispredicted exit, and the
// parenthesis and macro-name scans visit only the lanes that can answer
// (12% and 20% of the stream on this workload) instead of every token of
// every line. C_TOKEN_INVALID is 0, so the masked tail lanes of the last
// window match no class and need no separate trim.
#define C_PP_CLASS_MASK_WINDOW 64

typedef struct CPpClassMasks CPpClassMasks;
struct CPpClassMasks
{
    Mask64* stop;
    Mask64* identifier;
    Mask64* parenthesis_left;
    Mask64* parenthesis_right;
    // 0 when the run carried no shape sidecar; every consumer falls back to
    // the row scans above on that run.
    u64 word_count;
};

BUSTER_C_INTERNAL void c_pp_class_masks_build(Arena* arena, CPpClassMasks* masks, CTokenShape const* shapes, u64 token_count)
{
    u64 word_count = (token_count + (C_PP_CLASS_MASK_WINDOW - 1)) / C_PP_CLASS_MASK_WINDOW;
    *masks = (CPpClassMasks){0};
    if (shapes && word_count)
    {
        masks->stop = arena_allocate(arena, Mask64, word_count);
        masks->identifier = arena_allocate(arena, Mask64, word_count);
        masks->parenthesis_left = arena_allocate(arena, Mask64, word_count);
        masks->parenthesis_right = arena_allocate(arena, Mask64, word_count);
        Simd512 newline_shape = simd512_splat((u8)C_TOKEN_NEWLINE);
        Simd512 end_shape = simd512_splat((u8)C_TOKEN_END_OF_FILE);
        Simd512 identifier_shape = simd512_splat((u8)C_TOKEN_IDENTIFIER);
        Simd512 left_shape = simd512_splat(c_token_shape_from_fields(C_TOKEN_PUNCTUATOR, C_PUNCTUATOR_LEFT_PARENTHESIS));
        Simd512 right_shape = simd512_splat(c_token_shape_from_fields(C_TOKEN_PUNCTUATOR, C_PUNCTUATOR_RIGHT_PARENTHESIS));
        for (u64 word_index = 0; word_index < word_count; word_index += 1)
        {
            u64 window_base = word_index * C_PP_CLASS_MASK_WINDOW;
            Mask64 window_mask = mask64_prefix(token_count - window_base);
            Simd512 window = simd512_load_masked(shapes + window_base, window_mask);
            masks->stop[word_index] = mask64_or(simd512_equal_byte(window, newline_shape), simd512_equal_byte(window, end_shape));
            masks->identifier[word_index] = simd512_equal_byte(window, identifier_shape);
            masks->parenthesis_left[word_index] = simd512_equal_byte(window, left_shape);
            masks->parenthesis_right[word_index] = simd512_equal_byte(window, right_shape);
        }
        masks->word_count = word_count;
    }
}

// The lanes of `word_index` that lie in [first, end): the whole word except
// at the two ends of the range.
BUSTER_C_INTERNAL Mask64 c_pp_class_range_mask(u64 word_index, u64 first, u64 end)
{
    Mask64 result = mask64_not(0);
    if (word_index == first / C_PP_CLASS_MASK_WINDOW)
    {
        result = mask64_and(result, mask64_shift_left(mask64_not(0), first % C_PP_CLASS_MASK_WINDOW));
    }
    if (word_index == (end - 1) / C_PP_CLASS_MASK_WINDOW)
    {
        result = mask64_and(result, mask64_prefix(((end - 1) % C_PP_CLASS_MASK_WINDOW) + 1));
    }
    return result;
}

// The first newline or end-of-file token at or after `token_index`, which is
// what c_preprocess_line_end answers by walking rows.
BUSTER_C_INTERNAL u64 c_pp_line_end_masked(CPpClassMasks const* masks, u64 token_count, u64 token_index)
{
    u64 result = token_count;
    if (token_index < token_count)
    {
        u64 word_index = token_index / C_PP_CLASS_MASK_WINDOW;
        Mask64 pending = mask64_and(masks->stop[word_index], mask64_shift_left(mask64_not(0), token_index % C_PP_CLASS_MASK_WINDOW));
        while (!pending && word_index + 1 < masks->word_count)
        {
            word_index += 1;
            pending = masks->stop[word_index];
        }
        if (pending)
        {
            result = word_index * C_PP_CLASS_MASK_WINDOW + mask64_first_set(pending);
        }
    }
    return result;
}

// The clamped parenthesis depth after [first, end), entered at `depth`: a
// ')' with nothing open is ignored, which is what the row scan did.
BUSTER_C_INTERNAL u32 c_pp_parenthesis_depth(CPpClassMasks const* masks, u64 first, u64 end, u32 depth)
{
    u32 result = depth;
    if (first < end)
    {
        u64 last_word = (end - 1) / C_PP_CLASS_MASK_WINDOW;
        for (u64 word_index = first / C_PP_CLASS_MASK_WINDOW; word_index <= last_word; word_index += 1)
        {
            Mask64 range = c_pp_class_range_mask(word_index, first, end);
            Mask64 opens = mask64_and(masks->parenthesis_left[word_index], range);
            Mask64 closes = mask64_and(masks->parenthesis_right[word_index], range);
            Mask64 pending = mask64_or(opens, closes);
            while (pending)
            {
                u32 lane = mask64_first_set(pending);
                bool opening = mask64_and(mask64_shift_right(opens, lane), 1) != 0;
                result = opening ? result + 1 : (result ? result - 1 : 0);
                pending = mask64_and(pending, pending - 1);
            }
        }
    }
    return result;
}

#if BUSTER_INCLUDE_TESTS
// The differential gate on the mask projection: every answer the driver takes
// from a mask must equal the row scan it replaced, on a run whose lines cross
// the 64-token windows at every offset.
bool c_test_pp_class_masks_agree(Arena* arena, String8 source)
{
    bool result = true;
    CLexResult lex = c_lex(arena, source);
    CPpClassMasks masks;
    c_pp_class_masks_build(arena, &masks, lex.token_shapes, lex.token_count);
    if (!masks.word_count && lex.token_count)
    {
        result = false;
    }
    for (u64 token_index = 0; result && token_index < lex.token_count; token_index += 1)
    {
        Mask64 word = masks.identifier[token_index / C_PP_CLASS_MASK_WINDOW];
        bool named = mask64_and(mask64_shift_right(word, token_index % C_PP_CLASS_MASK_WINDOW), 1) != 0;
        if (named != (lex.tokens[token_index].kind == C_TOKEN_IDENTIFIER))
        {
            result = false;
        }
        if (c_pp_line_end_masked(&masks, lex.token_count, token_index) != c_preprocess_line_end(lex, token_index))
        {
            result = false;
        }
    }
    for (u64 line_start = 0; result && line_start < lex.token_count;)
    {
        u64 line_end = c_preprocess_line_end(lex, line_start);
        u32 rows = 0;
        for (u64 scan = line_start; scan < line_end; scan += 1)
        {
            if (c_token_is_punctuator(&lex.tokens[scan], C_PUNCTUATOR_LEFT_PARENTHESIS))
            {
                rows += 1;
            }
            else if (c_token_is_punctuator(&lex.tokens[scan], C_PUNCTUATOR_RIGHT_PARENTHESIS) && rows)
            {
                rows -= 1;
            }
        }
        if (c_pp_parenthesis_depth(&masks, line_start, line_end, 0) != rows)
        {
            result = false;
        }
        line_start = line_end + 1;
    }
    return result;
}
#endif

// The whole-file include-guard proof, per source frame: SEARCHING until the
// file's first top-level directive, GUARDED while inside a leading
// `#ifndef NAME` conditional, CLOSED once its `#endif` returns to the
// frame's base with the shape still intact, and DISQUALIFIED as soon as any
// token or directive is seen at the frame's top level outside that one
// conditional. A frame that reaches end of file CLOSED has proven that
// re-lexing it while NAME is defined can only produce an empty token
// sequence, which is what lets the next inclusion be dropped unread.
typedef enum CIncludeGuardState
{
    C_INCLUDE_GUARD_SEARCHING = 0,
    C_INCLUDE_GUARD_GUARDED,
    C_INCLUDE_GUARD_CLOSED,
    C_INCLUDE_GUARD_DISQUALIFIED,
} CIncludeGuardState;

typedef struct CPreprocessSourceFrame CPreprocessSourceFrame;
struct CPreprocessSourceFrame
{
    CPreprocessSourceFrame* previous;
    CConditionalFrame* conditional_base;
    // The leading top-level conditional while the guard proof is GUARDED,
    // and the interned symbol of its `#ifndef` name (see CIncludeGuardState).
    CConditionalFrame* guard;
    CLexResult lex;
    // The class projection of `lex` (see CPpClassMasks); built once when the
    // frame is pushed, read by every per-line scan of the driver.
    CPpClassMasks class_masks;
    String8 path;
    // Suppression keys are deliberately separate from diagnostic/source-map
    // spellings. Filesystem frames carry descriptor identity while the resolved
    // path remains what diagnostics and source maps show.
    CIncludeFileIdentity identity;
    String8 logical_path;
    s64 line_delta;
    u64 token_index;
    // Index of the frame's current source-map entry (the file span or the
    // latest #line split); its file id is assigned lazily when the region
    // first stages a token, so files that contribute nothing never enter
    // the file table — include resolution differs between hosts (the
    // self-hosted stages lack the clang resource headers), and an eagerly
    // registered but token-free header would break the fixed point.
    u32 map_entry;
    u32 depth;
    u32 guard_symbol;
    u8 guard_state;
    bool line_start;
    FileMapRead source_map;
    CIncludeSearchOrigin include_origin;
};

// Test instrumentation observes the real probe loops without adding state or
// work to tests-disabled compiler builds.
#if BUSTER_INCLUDE_TESTS
#define C_INCLUDE_FILE_SLOT_HASH(table, entries, slot) ((table)->probe_count += 1, (entries)[slot].hash)
#else
#define C_INCLUDE_FILE_SLOT_HASH(table, entries, slot) ((entries)[slot].hash)
#endif

// The table stays at most half full. Growth first proves both the u32 doubling
// and this arena's remaining reservation, so neither an overflowing capacity
// nor a short allocation can turn into a smaller table followed by writes.
BUSTER_C_INTERNAL bool c_include_file_table_grow(CIncludeFileTable* table)
{
    bool result = false;
    u32 capacity = C_INCLUDE_FILE_INITIAL_CAPACITY;
    if (table->capacity)
    {
        if (table->capacity <= UINT32_MAX / 2)
        {
            capacity = table->capacity * 2;
        }
        else
        {
            capacity = 0;
        }
    }
    u64 byte_count = (u64)capacity * sizeof(*table->entries);
    u64 position = align_forward(table->arena->position, BUSTER_ALIGN_OF(CIncludeFileEntry));
    bool allocation_fits = capacity && position <= table->arena->reserved_size && byte_count <= table->arena->reserved_size - position;
    if (allocation_fits)
    {
        CIncludeFileEntry* entries = arena_allocate_zeroed(table->arena, CIncludeFileEntry, capacity);
        for (u32 old_slot = 0; old_slot < table->capacity; old_slot += 1)
        {
            CIncludeFileEntry entry = table->entries[old_slot];
            if (entry.hash)
            {
                u32 slot = (u32)entry.hash & (capacity - 1);
                while (C_INCLUDE_FILE_SLOT_HASH(table, entries, slot))
                {
                    slot = (slot + 1) & (capacity - 1);
                }
                entries[slot] = entry;
            }
        }
        table->entries = entries;
        table->capacity = capacity;
        result = true;
    }
    return result;
}

// Filesystem includes use identity captured from the descriptor that supplied
// their bytes. Builtin headers and non-filesystem namespaces retain a path key;
// neither case changes the resolved spelling kept for diagnostics/source maps.
BUSTER_C_INTERNAL CIncludeFileIdentity c_include_file_identity(String8 path, FileIdentity file_identity)
{
    CIncludeFileIdentity result = {
        .path = path,
    };
    if (file_identity.valid)
    {
        result = (CIncludeFileIdentity){
            .device = file_identity.device,
            .index = file_identity.index,
            .physical = true,
        };
    }
    return result;
}

BUSTER_C_INTERNAL bool c_include_file_identity_equal(CIncludeFileEntry const* entry, CIncludeFileIdentity identity)
{
    bool result = entry->physical == identity.physical;
    if (result)
    {
        result = identity.physical ? entry->device == identity.device && entry->index == identity.index : string_equal(entry->spelling, identity.path);
    }
    return result;
}

BUSTER_C_INTERNAL u64 c_include_file_identity_hash(CIncludeFileIdentity identity)
{
    u64 result;
    if (identity.physical)
    {
        u64 words[2] = {identity.device, identity.index};
        result = buster_hash_64((u8*)words, sizeof(words));
    }
    else
    {
        result = buster_hash_64((u8*)identity.path.pointer, identity.path.length);
    }
    // Zero marks an empty table entry. Preserve every bit of nonzero hashes
    // instead of forcing all home buckets odd.
    return result ? result : 1;
}

// Find or create the record for `identity`. The output is cleared on failure;
// callers must diagnose the status rather than silently losing once semantics.
BUSTER_C_INTERNAL CIncludeFileStatus c_include_file_entry(CIncludeFileTable* table, CIncludeFileIdentity identity, String8 spelling,
                                                          CIncludeFileEntry** entry_out)
{
    CIncludeFileStatus result = C_INCLUDE_FILE_INVALID_IDENTITY;
    *entry_out = 0;
    bool valid_identity = identity.physical || (identity.path.pointer && identity.path.length);
    if (valid_identity)
    {
        u64 hash = c_include_file_identity_hash(identity);
        u32 slot = 0;
        bool found = false;
        if (table->capacity)
        {
            slot = (u32)hash & (table->capacity - 1);
            while (!found && C_INCLUDE_FILE_SLOT_HASH(table, table->entries, slot))
            {
                CIncludeFileEntry* entry = table->entries + slot;
                found = entry->hash == hash && c_include_file_identity_equal(entry, identity);
                if (!found)
                {
                    slot = (slot + 1) & (table->capacity - 1);
                }
            }
        }
        bool capacity_ready = found || (table->capacity && table->count + 1 <= table->capacity / 2);
        if (!capacity_ready)
        {
            capacity_ready = c_include_file_table_grow(table);
            if (capacity_ready)
            {
                slot = (u32)hash & (table->capacity - 1);
                while (C_INCLUDE_FILE_SLOT_HASH(table, table->entries, slot))
                {
                    slot = (slot + 1) & (table->capacity - 1);
                }
            }
        }
        if (capacity_ready)
        {
            if (!found)
            {
                table->entries[slot] = (CIncludeFileEntry){
                    .spelling = spelling,
                    .hash = hash,
                    .device = identity.device,
                    .index = identity.index,
                    .physical = identity.physical,
                };
                table->count += 1;
            }
            *entry_out = table->entries + slot;
            result = C_INCLUDE_FILE_OK;
        }
        else
        {
            result = C_INCLUDE_FILE_ALLOCATION_FAILED;
        }
    }
    return result;
}

#undef C_INCLUDE_FILE_SLOT_HASH

#if BUSTER_INCLUDE_TESTS
CIncludeFileStatus c_test_include_file_entry(CIncludeFileTable* table, CIncludeFileIdentity identity, String8 spelling,
                                            CIncludeFileEntry** entry_out)
{
    return c_include_file_entry(table, identity, spelling, entry_out);
}

bool c_test_include_file_table_grow(CIncludeFileTable* table)
{
    return c_include_file_table_grow(table);
}
#endif

BUSTER_C_INTERNAL void c_include_file_diagnostic(Arena* arena, CPreprocessResult* preprocess, CSourceLocation location,
                                                  CIncludeFileStatus status, String8 spelling)
{
    String8 message = status == C_INCLUDE_FILE_INVALID_IDENTITY
                          ? string_format(arena, S8("included file has no usable identity: {S8}"), spelling)
                          : string_format(arena, S8("included-file tracking allocation failed: {S8}"), spelling);
    c_preprocess_diagnostic_push(arena, preprocess, location, C_DIAGNOSTIC_INVALID_INCLUDE, message);
}

typedef struct CPragmaPackStack CPragmaPackStack;
struct CPragmaPackStack
{
    CPragmaPackStack* previous;
    u16 alignment;
};

// The pack change list under construction. Entries are appended lazily at
// output-append time — the first token that lands after a state change
// carries the new value's span start — so pragmas on directive lines and
// _Pragma markers mid-expansion record through the same comparison, and
// consecutive changes with no token between them collapse to one entry.
typedef struct CPackAlignmentRecorder CPackAlignmentRecorder;
struct CPackAlignmentRecorder
{
    Arena* arena;
    CPackAlignment* changes;
    u32 count;
    u32 capacity;
    u16 recorded;
};

BUSTER_C_INTERNAL void c_pack_alignment_record(CPackAlignmentRecorder* recorder, u64 token_index, u16 alignment)
{
    if (alignment == recorder->recorded)
    {
        return;
    }
    if (recorder->count == recorder->capacity)
    {
        u32 capacity = recorder->capacity ? recorder->capacity * 2 : 16;
        CPackAlignment* changes = arena_allocate(recorder->arena, CPackAlignment, capacity);
        if (recorder->count)
        {
            memcpy(changes, recorder->changes, sizeof(*changes) * recorder->count);
        }
        recorder->changes = changes;
        recorder->capacity = capacity;
    }
    recorder->changes[recorder->count++] = (CPackAlignment){
        .token_index = (u32)token_index,
        .alignment = alignment,
    };
    recorder->recorded = alignment;
}

u32 c_preprocess_pack_alignment(CPreprocessResult const* preprocess, u64 token_index)
{
    u32 low = 0;
    u32 high = preprocess->pack_change_count;
    while (low < high)
    {
        u32 middle = low + (high - low) / 2;
        if (preprocess->pack_changes[middle].token_index <= token_index)
        {
            low = middle + 1;
        }
        else
        {
            high = middle;
        }
    }
    return low ? preprocess->pack_changes[low - 1].alignment : 0;
}

typedef struct CPreprocessPragmaContext CPreprocessPragmaContext;
struct CPreprocessPragmaContext
{
    Arena* arena;
    CPreprocessResult* preprocess;
    CSymbolTable* symbols;
    CMacro** first_macro;
    CMacro** last_macro;
    CMacroPushMacro** macro_push_stack;
    CPragmaPackStack** pack_stack;
    u16* pack_alignment;
    CPackAlignmentRecorder* pack_changes;
    CIncludeFileTable* include_files;
    String8 current_path;
    CIncludeFileIdentity current_identity;
    CSourceLocation current_location;
};

BUSTER_C_INTERNAL bool c_preprocess_pragma_macro_name(char8 const* base, CToken* tokens, u32 token_count, String8* name_out)
{
    if (token_count == 4 && tokens[0].kind == C_TOKEN_IDENTIFIER && c_token_is_punctuator(&tokens[1], C_PUNCTUATOR_LEFT_PARENTHESIS) &&
        tokens[2].kind == C_TOKEN_STRING_LITERAL && tokens[2].length >= 2 && c_token_is_punctuator(&tokens[3], C_PUNCTUATOR_RIGHT_PARENTHESIS))
    {
        String8 spelling = c_token_spelling(base, tokens[2]);
        *name_out = (String8){
            .pointer = spelling.pointer + 1,
            .length = spelling.length - 2,
        };
        return true;
    }
    return false;
}

BUSTER_C_INTERNAL void c_macro_push_definition(CPreprocessPragmaContext context, String8 name)
{
    CMacro* macro = c_macro_find(*context.first_macro, c_symbol_intern(context.symbols, name));
    CMacroPushMacro* entry = arena_allocate(context.arena, CMacroPushMacro, 1);
    *entry = (CMacroPushMacro){
        .previous = *context.macro_push_stack,
        .macro = macro,
        .name = string_duplicate_arena(context.arena, name, false),
        .definition = macro ? macro->definition : (CMacroDefinition){0},
    };
    if (macro && macro->definition.replacement_count)
    {
        entry->definition.replacement = arena_allocate(context.arena, CToken, macro->definition.replacement_count);
        memcpy(entry->definition.replacement, macro->definition.replacement,
               sizeof(*entry->definition.replacement) * macro->definition.replacement_count);
        if (macro->definition.replacement_space)
        {
            entry->definition.replacement_space = arena_allocate(context.arena, u8, macro->definition.replacement_count);
            memcpy(entry->definition.replacement_space, macro->definition.replacement_space,
                   sizeof(*entry->definition.replacement_space) * macro->definition.replacement_count);
        }
        entry->definition.parameter_index = arena_allocate(context.arena, u32, macro->definition.replacement_count);
        memcpy(entry->definition.parameter_index, macro->definition.parameter_index,
               sizeof(*entry->definition.parameter_index) * macro->definition.replacement_count);
    }
    if (macro && macro->definition.parameter_count)
    {
        entry->definition.parameters = arena_allocate(context.arena, String8, macro->definition.parameter_count);
        memcpy(entry->definition.parameters, macro->definition.parameters,
               sizeof(*entry->definition.parameters) * macro->definition.parameter_count);
        entry->definition.parameter_expand_count = arena_allocate(context.arena, u32, macro->definition.parameter_count);
        memcpy(entry->definition.parameter_expand_count, macro->definition.parameter_expand_count,
               sizeof(*entry->definition.parameter_expand_count) * macro->definition.parameter_count);
    }
    *context.macro_push_stack = entry;
}

BUSTER_C_INTERNAL void c_macro_clear_definition(CMacro* macro)
{
    if (!macro)
    {
        return;
    }
    macro->definition = (CMacroDefinition){0};
}

BUSTER_C_INTERNAL void c_macro_pop_definition(CPreprocessPragmaContext context, String8 name)
{
    CMacroPushMacro** cursor = context.macro_push_stack;
    while (*cursor && !string_equal((*cursor)->name, name))
    {
        cursor = &(*cursor)->previous;
    }
    if (!(!*cursor))
    {
        CMacroPushMacro* entry = *cursor;
        *cursor = entry->previous;
        if (!entry->macro)
        {
            c_macro_clear_definition(c_macro_find(*context.first_macro, c_symbol_intern(context.symbols, name)));
            return;
        }
        CMacro* macro = entry->macro;
        macro->definition = entry->definition;
        macro->disabled = false;
    }
}

// The bound is UINT16_MAX because CToken carries the alignment in a u16, and
// no ABI has a structure alignment that large to begin with.
BUSTER_C_INTERNAL bool c_preprocess_pragma_pack_value(char8 const* base, CToken token, u16* value_out)
{
    u64 value = 0;
    bool valid =
        token.kind == C_TOKEN_PREPROCESSING_NUMBER && c_conditional_number(c_token_spelling(base, token), &value) && value <= UINT16_MAX && value && !(value & (value - 1));
    if (valid)
    {
        *value_out = (u16)value;
    }
    return valid;
}

BUSTER_C_INTERNAL void c_preprocess_pragma_pack(CPreprocessPragmaContext context, char8 const* base, CToken* tokens, u32 token_count)
{
    if (token_count < 3 || tokens[0].kind != C_TOKEN_IDENTIFIER || !c_token_spelling_equal(base, tokens[0], S8("pack")) ||
        !c_token_is_punctuator(&tokens[1], C_PUNCTUATOR_LEFT_PARENTHESIS) || !c_token_is_punctuator(&tokens[token_count - 1], C_PUNCTUATOR_RIGHT_PARENTHESIS))
    {
        return;
    }
    CToken* arguments = tokens + 2;
    u32 argument_count = token_count - 3;
    if (!argument_count)
    {
        *context.pack_alignment = 0;
        return;
    }
    bool push = argument_count >= 1 && arguments[0].kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, arguments[0], S8("push"));
    bool pop = argument_count >= 1 && arguments[0].kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, arguments[0], S8("pop"));
    u32 value_index = UINT32_MAX;
    if (push)
    {
        if (argument_count == 1)
        {
            value_index = UINT32_MAX;
        }
        else if (argument_count == 3 && c_token_is_punctuator(&arguments[1], C_PUNCTUATOR_COMMA))
        {
            value_index = 2;
        }
        else if (argument_count == 5 && c_token_is_punctuator(&arguments[1], C_PUNCTUATOR_COMMA) && arguments[2].kind == C_TOKEN_IDENTIFIER &&
                 c_token_is_punctuator(&arguments[3], C_PUNCTUATOR_COMMA))
        {
            value_index = 4;
        }
        else
        {
            return;
        }
        u16 value = 0;
        bool valid_value = value_index != UINT32_MAX && c_preprocess_pragma_pack_value(base, arguments[value_index], &value);
        if (value_index != UINT32_MAX && !valid_value)
        {
            return;
        }
        CPragmaPackStack* entry = arena_allocate(context.arena, CPragmaPackStack, 1);
        *entry = (CPragmaPackStack){
            .previous = *context.pack_stack,
            .alignment = *context.pack_alignment,
        };
        *context.pack_stack = entry;
        if (valid_value)
        {
            *context.pack_alignment = value;
        }
        return;
    }
    if (pop)
    {
        if (argument_count != 1 &&
            !(argument_count == 3 && c_token_is_punctuator(&arguments[1], C_PUNCTUATOR_COMMA) && arguments[2].kind == C_TOKEN_IDENTIFIER))
        {
            return;
        }
        if (*context.pack_stack)
        {
            *context.pack_alignment = (*context.pack_stack)->alignment;
            *context.pack_stack = (*context.pack_stack)->previous;
        }
        return;
    }
    if (argument_count == 1)
    {
        u16 value = 0;
        if (c_preprocess_pragma_pack_value(base, arguments[0], &value))
        {
            *context.pack_alignment = value;
        }
    }
}

BUSTER_C_INTERNAL void c_preprocess_handle_pragma(CPreprocessPragmaContext context, char8 const* base, CToken* tokens, u32 token_count)
{
    if (token_count)
    {
        if (token_count == 1 && tokens[0].kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, tokens[0], S8("once")))
        {
            CIncludeFileEntry* entry = 0;
            CIncludeFileStatus status =
                c_include_file_entry(context.include_files, context.current_identity, context.current_path, &entry);
            if (status == C_INCLUDE_FILE_OK)
            {
                entry->once = true;
            }
            else
            {
                c_include_file_diagnostic(context.arena, context.preprocess, context.current_location, status, context.current_path);
            }
            return;
        }
        if (tokens[0].kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, tokens[0], S8("push_macro")))
        {
            String8 name = {0};
            if (c_preprocess_pragma_macro_name(base, tokens, token_count, &name))
            {
                c_macro_push_definition(context, name);
            }
            return;
        }
        if (tokens[0].kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, tokens[0], S8("pop_macro")))
        {
            String8 name = {0};
            if (c_preprocess_pragma_macro_name(base, tokens, token_count, &name))
            {
                c_macro_pop_definition(context, name);
            }
            return;
        }
        if (tokens[0].kind == C_TOKEN_IDENTIFIER && c_token_spelling_equal(base, tokens[0], S8("pack")))
        {
            c_preprocess_pragma_pack(context, base, tokens, token_count);
        }
        // GCC/Clang/MSVC diagnostic, visibility, system-header, warning,
        // comment, region, and OpenMP pragmas are compatibility no-ops. Unknown
        // pragma bodies are intentionally ignored as well.
    }
}

BUSTER_C_INTERNAL void c_preprocess_pragma_marker(CPreprocessPragmaContext context, char8 const* base, CToken marker)
{
    if (!marker.length)
    {
        return;
    }
    // The marker relex is standalone: its tokens' offsets are relative to its
    // own translated copy, so the handler reads them through that base.
    CLexResult lex = c_lex(context.arena, c_token_spelling(base, marker));
    u32 token_count = 0;
    while (token_count < lex.token_count && lex.tokens[token_count].kind != C_TOKEN_NEWLINE && lex.tokens[token_count].kind != C_TOKEN_END_OF_FILE)
    {
        token_count += 1;
    }
    c_preprocess_handle_pragma(context, lex.spelling_base, lex.tokens, token_count);
}

// Materialize an expanded line into the output stream. Foreign tokens (their
// location is a macro-invocation stamp, not a function of their spelling
// offset) get their spellings copied to fresh space offsets under an
// expansion source-map entry; one invocation's tokens share one stamped
// location, so runs of equal locations share one entry.
BUSTER_C_INTERNAL void c_preprocess_process_expanded_line(CPreprocessPragmaContext context, CSpellingSpace* space, CSourceMap* map,
                                                            CPpStampTable const* stamps, CPreprocessTokenNode* first_line, u64 line_output_count,
                                                            CTokenStream* token_stream, u64* output_count)
{
    CTokenShape* shapes = 0;
    CToken* tokens = c_token_stream_reserve(token_stream, line_output_count, &shapes);
    u64 count = 0;
    u64 foreign_length = 0;
    for (CPreprocessTokenNode* node = first_line; node; node = node->next)
    {
        foreign_length += node->token.foreign ? c_token_length(space->base, node->token.token) : 0;
    }
    char8* copy = foreign_length ? c_space_allocate(space, foreign_length) : 0;
    bool run_open = false;
    // Every stamp of a line is pushed from a distinct token, so two tokens
    // carry one location exactly when they carry one stamp.
    u32 run_stamp = 0;
    // The pack alignment can only change where a pragma marker fires, so the
    // sample is taken at the line's first token and again at the first token
    // after each marker, instead of asking the recorder once per token.
    bool pack_pending = true;
    for (CPreprocessTokenNode* node = first_line; node; node = node->next)
    {
        if (node->token.token.kind == C_TOKEN_PRAGMA)
        {
            context.current_location = c_pp_stamp_location(stamps, node->token.stamp);
            c_preprocess_pragma_marker(context, space->base, node->token.token);
            pack_pending = true;
            continue;
        }
        CPpToken item = node->token;
        if (pack_pending)
        {
            c_pack_alignment_record(context.pack_changes, *output_count + count, *context.pack_alignment);
            pack_pending = false;
        }
        if (item.foreign)
        {
            String8 spelling = c_token_spelling(space->base, item.token);
            BUSTER_CHECK(!spelling.length || copy); // Counted in foreign_length above.
            for (u64 byte_index = 0; byte_index < spelling.length; byte_index += 1)
            {
                copy[byte_index] = spelling.pointer[byte_index];
            }
            if (!run_open || run_stamp != item.stamp)
            {
                CSourceLocation location = c_pp_stamp_location(stamps, item.stamp);
                c_source_map_append(map, (IrSourceRegion){
                                             .start = c_space_offset(space, copy),
                                             .source = location.file,
                                             .stamp = c_position_from_source_location(location),
                                             .kind = IR_SOURCE_REGION_STAMP,
                                             .origin_plus_one = location.map_offset + 1,
                                         });
                run_open = true;
                run_stamp = item.stamp;
            }
            item.token.offset = c_space_offset(space, copy);
            copy += spelling.length;
        }
        else
        {
            run_open = false;
        }
        tokens[count] = item.token;
        shapes[count] = c_token_shape_from_token(item.token);
        count += 1;
    }
    c_token_stream_shrink(token_stream, line_output_count - count);
    *output_count += count;
}

BUSTER_C_INTERNAL u32 c_preprocess_tokens_from_nodes(CPreprocessTokenNode* first, Arena* arena, CToken** tokens_out)
{
    u32 token_count = 0;
    for (CPreprocessTokenNode* node = first; node; node = node->next)
    {
        token_count += node->token.token.kind != C_TOKEN_PRAGMA;
    }
    CToken* tokens = arena_allocate(arena, CToken, token_count);
    u32 output = 0;
    for (CPreprocessTokenNode* node = first; node; node = node->next)
    {
        if (node->token.token.kind != C_TOKEN_PRAGMA)
        {
            tokens[output++] = node->token.token;
        }
    }
    *tokens_out = tokens;
    return token_count;
}

BUSTER_C_INTERNAL String8 c_preprocess_message_from_tokens(Arena* arena, char8 const* base, CToken* tokens, u32 token_count)
{
    CToken first = {0};
    CToken last = {0};
    bool has_message = false;
    for (u32 token_index = 0; token_index < token_count; token_index += 1)
    {
        if (tokens[token_index].kind != C_TOKEN_PRAGMA)
        {
            if (!has_message) { first = tokens[token_index]; }
            last = tokens[token_index];
            has_message = true;
        }
    }
    String8 result = {0};
    if (has_message)
    {
        // These tokens belong to one directive line in the original spelling
        // space. Keep punctuation and the gaps between tokens as written.
        String8 spelling = {.pointer = (char8*)base + first.offset,
                            .length = last.offset + c_token_length(base, last) - first.offset};
        result = string_duplicate_arena(arena, spelling, true);
    }
    return result;
}

BUSTER_C_INTERNAL CSourceLocation c_preprocess_logical_location(CPreprocessSourceFrame* frame, CSourceLocation location);

// Wrap a frame's lex tokens for the expansion machinery (directive lines
// only; text lines wrap unstamped in the main loop and stamp on demand).
// Directive-line expansion output is transient — only diagnostics ever read
// these locations — so one recovery of the line head, the line's only
// stamp, serves every token.
BUSTER_C_INTERNAL CPpToken* c_frame_wrap_tokens(Arena* arena, CPpStampTable* stamps, CPreprocessSourceFrame* frame, u64 start, u64 end)
{
    CPpToken* wrapped = arena_allocate(arena, CPpToken, end - start);
    stamps->count = 0;
    u32 stamp = 0;
    if (start < end)
    {
        stamp = c_pp_stamp_push(stamps, c_preprocess_logical_location(frame, c_lex_token_location(&frame->lex, frame->lex.tokens[start])));
    }
    for (u64 index = start; index < end; index += 1)
    {
        wrapped[index - start] = (CPpToken){
            .token = frame->lex.tokens[index],
            .stamp = stamp & C_PP_STAMP_MASK,
        };
    }
    return wrapped;
}

typedef enum CPreprocessConditionalDirective
{
    C_PREPROCESS_CONDITIONAL_IF,
    C_PREPROCESS_CONDITIONAL_IFDEF,
    C_PREPROCESS_CONDITIONAL_IFNDEF,
    C_PREPROCESS_CONDITIONAL_ELIF,
    C_PREPROCESS_CONDITIONAL_ELSE,
    C_PREPROCESS_CONDITIONAL_ENDIF,
    C_PREPROCESS_CONDITIONAL_COUNT,
} CPreprocessConditionalDirective;

BUSTER_C_INTERNAL CSourceLocation c_preprocess_logical_location(CPreprocessSourceFrame* frame, CSourceLocation location);

BUSTER_C_INTERNAL CPreprocessConditionalDirective c_preprocess_conditional_directive_kind(char8 const* base, CToken directive)
{
    CPreprocessConditionalDirective result = C_PREPROCESS_CONDITIONAL_COUNT;
    if (c_token_spelling_equal(base, directive, S8("if")))
    {
        result = C_PREPROCESS_CONDITIONAL_IF;
    }
    else if (c_token_spelling_equal(base, directive, S8("ifdef")))
    {
        result = C_PREPROCESS_CONDITIONAL_IFDEF;
    }
    else if (c_token_spelling_equal(base, directive, S8("ifndef")))
    {
        result = C_PREPROCESS_CONDITIONAL_IFNDEF;
    }
    else if (c_token_spelling_equal(base, directive, S8("elif")))
    {
        result = C_PREPROCESS_CONDITIONAL_ELIF;
    }
    else if (c_token_spelling_equal(base, directive, S8("else")))
    {
        result = C_PREPROCESS_CONDITIONAL_ELSE;
    }
    else if (c_token_spelling_equal(base, directive, S8("endif")))
    {
        result = C_PREPROCESS_CONDITIONAL_ENDIF;
    }
    return result;
}

BUSTER_C_INTERNAL void c_preprocess_conditional_directive(Arena* arena, CSpellingSpace* space, CSymbolTable* symbol_table,
                                                          CMacro* first_macro, CPpStampTable* stamps, CPreprocessSourceFrame* source_frame,
                                                          CPreprocessConditionalDirective directive_kind, CToken directive, u64 token_index,
                                                          u64 line_end, u32 expansion_limit, CPreprocessResult* result, CPreprocessOptions options,
                                                          CConditionalFrame** conditional_pointer)
{
    CConditionalFrame* conditional = *conditional_pointer;
    CLexResult lex = source_frame->lex;
    char8 const* base = space->base;
    bool active = c_preprocess_is_active(conditional);
    CSourceLocation directive_location = c_preprocess_logical_location(source_frame, c_lex_token_location(&source_frame->lex, directive));
    if (directive_kind == C_PREPROCESS_CONDITIONAL_IF || directive_kind == C_PREPROCESS_CONDITIONAL_IFDEF ||
        directive_kind == C_PREPROCESS_CONDITIONAL_IFNDEF)
    {
        bool condition_value = false;
        bool valid = true;
        if (directive_kind == C_PREPROCESS_CONDITIONAL_IF)
        {
            if (active)
            {
                valid = c_conditional_evaluate(arena, space, symbol_table, first_macro, stamps,
                                               c_frame_wrap_tokens(arena, stamps, source_frame, token_index, line_end),
                                               (u32)(line_end - token_index), expansion_limit, result, options, source_frame->path,
                                               source_frame->include_origin, &condition_value);
            }
        }
        else if (token_index + 1 != line_end || lex.tokens[token_index].kind != C_TOKEN_IDENTIFIER)
        {
            valid = false;
        }
        else
        {
            CMacro* macro = c_macro_find_token(first_macro, symbol_table, base, &lex.tokens[token_index]);
            condition_value = macro && macro->definition.defined;
            condition_value ^= directive_kind == C_PREPROCESS_CONDITIONAL_IFNDEF;
        }
        if (!valid)
        {
            c_preprocess_diagnostic_push(arena, result, directive_location, C_DIAGNOSTIC_INVALID_CONDITIONAL,
                                         string_format(arena, S8("invalid preprocessing conditional expression in {S8}"), source_frame->path));
            condition_value = false;
        }
        CConditionalFrame* frame = arena_allocate(arena, CConditionalFrame, 1);
        *frame = (CConditionalFrame){
            .previous = conditional,
            .location = directive_location,
            .parent_active = active,
            .active = active && condition_value,
            .branch_taken = active && condition_value,
        };
        conditional = frame;
        if (conditional->previous == source_frame->conditional_base)
        {
            if (source_frame->guard_state == C_INCLUDE_GUARD_SEARCHING && directive_kind == C_PREPROCESS_CONDITIONAL_IFNDEF && valid)
            {
                CToken guard_name = lex.tokens[token_index];
                source_frame->guard_state = C_INCLUDE_GUARD_GUARDED;
                source_frame->guard = conditional;
                source_frame->guard_symbol =
                    guard_name.symbol ? guard_name.symbol : c_symbol_intern(symbol_table, c_token_spelling(base, guard_name));
            }
            else
            {
                source_frame->guard_state = C_INCLUDE_GUARD_DISQUALIFIED;
            }
        }
    }
    else if (directive_kind == C_PREPROCESS_CONDITIONAL_ELIF)
    {
        if (conditional == source_frame->conditional_base || conditional->else_seen)
        {
            c_preprocess_diagnostic_push(arena, result, directive_location, C_DIAGNOSTIC_UNMATCHED_CONDITIONAL,
                                         S8("'#elif' has no matching '#if', or follows '#else'"));
        }
        else
        {
            if (source_frame->guard_state == C_INCLUDE_GUARD_GUARDED && conditional == source_frame->guard)
            {
                source_frame->guard_state = C_INCLUDE_GUARD_DISQUALIFIED;
            }
            bool condition_value = false;
            bool evaluate = conditional->parent_active && !conditional->branch_taken;
            bool valid = true;
            if (evaluate)
            {
                valid = c_conditional_evaluate(arena, space, symbol_table, first_macro, stamps,
                                               c_frame_wrap_tokens(arena, stamps, source_frame, token_index, line_end),
                                               (u32)(line_end - token_index), expansion_limit, result, options, source_frame->path,
                                               source_frame->include_origin, &condition_value);
            }
            if (!valid)
            {
                c_preprocess_diagnostic_push(arena, result, directive_location, C_DIAGNOSTIC_INVALID_CONDITIONAL,
                                             S8("invalid '#elif' expression"));
                condition_value = false;
            }
            conditional->active = evaluate && condition_value;
            conditional->branch_taken |= conditional->active;
        }
    }
    else if (directive_kind == C_PREPROCESS_CONDITIONAL_ELSE)
    {
        if (conditional == source_frame->conditional_base || conditional->else_seen || token_index != line_end)
        {
            c_preprocess_diagnostic_push(arena, result, directive_location, C_DIAGNOSTIC_UNMATCHED_CONDITIONAL,
                                         S8("invalid or unmatched '#else' directive"));
        }
        else
        {
            if (source_frame->guard_state == C_INCLUDE_GUARD_GUARDED && conditional == source_frame->guard)
            {
                source_frame->guard_state = C_INCLUDE_GUARD_DISQUALIFIED;
            }
            conditional->else_seen = true;
            conditional->active = conditional->parent_active && !conditional->branch_taken;
            conditional->branch_taken |= conditional->active;
        }
    }
    else
    {
        if (conditional == source_frame->conditional_base || token_index != line_end)
        {
            c_preprocess_diagnostic_push(arena, result, directive_location, C_DIAGNOSTIC_UNMATCHED_CONDITIONAL,
                                         S8("invalid or unmatched '#endif' directive"));
        }
        else
        {
            if (source_frame->guard_state == C_INCLUDE_GUARD_GUARDED && conditional == source_frame->guard)
            {
                source_frame->guard_state = C_INCLUDE_GUARD_CLOSED;
            }
            conditional = conditional->previous;
        }
    }
    *conditional_pointer = conditional;
}

typedef struct CPreprocessSourceSegment CPreprocessSourceSegment;
struct CPreprocessSourceSegment
{
    CPreprocessSourceSegment* next;
    u64 first;
    u64 end;
};

BUSTER_C_INTERNAL void c_preprocess_source_segment_append(Arena* arena, CPreprocessSourceSegment** first_segment,
                                                          CPreprocessSourceSegment** last_segment, u64 first, u64 end)
{
    if (first != end)
    {
        CPreprocessSourceSegment* segment = arena_allocate(arena, CPreprocessSourceSegment, 1);
        *segment = (CPreprocessSourceSegment){
            .first = first,
            .end = end,
        };
        if (*last_segment)
        {
            (*last_segment)->next = segment;
        }
        else
        {
            *first_segment = segment;
        }
        *last_segment = segment;
    }
}

BUSTER_C_INTERNAL CSourceLocation c_preprocess_logical_location(CPreprocessSourceFrame* frame, CSourceLocation location)
{
    s64 line = (s64)location.line + frame->line_delta;
    if (line < 1)
    {
        line = 1;
    }
    if (line > (s64)UINT32_MAX)
    {
        line = (s64)UINT32_MAX;
    }
    location.line = (u32)line;
    return location;
}

// A text-line token's location, recovered from its offset through its
// frame's checkpoints only when an invocation needs it; the zero location
// stands in when there is no frame (the parse-side evaluator, which has no
// macros to invoke).
BUSTER_C_INTERNAL CSourceLocation c_preprocess_recover_location(CPreprocessSourceFrame* frame, u32 file, CToken token)
{
    CSourceLocation result = {0};
    if (frame)
    {
        result = c_preprocess_logical_location(frame, c_lex_token_location(&frame->lex, token));
        result.file = file;
    }
    return result;
}

// __LINE__'s value, recovered from the main loop's two-store breadcrumb only
// when the macro actually expands.
BUSTER_C_INTERNAL u32 c_preprocess_builtin_line(CMacro* first)
{
    CPreprocessSourceFrame* frame = first->builtin_frame;
    u32 result;
    if (!frame)
    {
        result = first->builtin_line;
    }
    else
    {
        CToken probe = {
            .offset = first->builtin_token_offset,
        };
        result = c_preprocess_logical_location(frame, c_lex_token_location(&frame->lex, probe)).line;
    }

    return result;
}

typedef struct CPreprocessFileTable CPreprocessFileTable;
struct CPreprocessFileTable
{
    String8* files;
    String8 memo_path;
    u32 memo_index;
    u32 count;
    u32 capacity;
    u32 reserved;
};

BUSTER_C_INTERNAL u32 c_preprocess_file_index(Arena* arena, CPreprocessFileTable* table, String8 path)
{
    u32 result;
    if (table->count && table->memo_path.pointer == path.pointer && table->memo_path.length == path.length)
    {
        result = table->memo_index;
    }
    else
    {
        u32 index = table->count;
        for (u32 existing = 0; existing < table->count; existing += 1)
        {
            if (string_equal(table->files[existing], path))
            {
                index = existing;
                break;
            }
        }
        if (index == table->count)
        {
            if (table->count == table->capacity)
            {
                u32 capacity = table->capacity ? table->capacity * 2 : 16;
                String8* files = arena_allocate(arena, String8, capacity);
                if (table->count)
                {
                    memcpy(files, table->files, table->count * sizeof(*files));
                }
                table->files = files;
                table->capacity = capacity;
            }
            table->files[table->count++] = path;
        }
        table->memo_path = path;
        table->memo_index = index;
        result = index;
    }

    return result;
}

// Regions are sorted before this cold publication step. Error locations may
// belong to a directive-only header, so register those names before resolving
// the compact original-source metadata. Successful token-free headers remain
// absent from the canonical file table.
BUSTER_C_INTERNAL void c_source_map_finish_origins(Arena* arena, CSourceMap* map, CPreprocessFileTable* files, CPreprocessResult* result)
{
    for (u64 diagnostic = 0; diagnostic < result->diagnostic_count; diagnostic += 1)
    {
        CDiagnostic* item = result->diagnostics + diagnostic;
        u32 offset = item->location.map_offset;
        bool done = false;
        for (u32 step = 0; step < map->count && !done; step += 1)
        {
            u32 low = 0;
            u32 high = map->count;
            while (low < high)
            {
                u32 middle = low + (high - low) / 2;
                if (map->regions[middle].start <= offset) low = middle + 1;
                else high = middle;
            }
            IrSourceRegion* region = map->regions + (low ? low - 1 : 0);
            if (!region->origin_plus_one)
            {
                done = true;
            }
            else if (region->kind == IR_SOURCE_REGION_TEXT)
            {
                CSourceRegionNames names = map->names[region->origin_plus_one - 1];
                if (region->source == UINT32_MAX)
                {
                    region->source = c_preprocess_file_index(arena, files, names.logical);
                }
                item->location.file = region->source;
                item->location.map_offset = offset;
                done = true;
            }
            else
            {
                offset = region->origin_plus_one - 1;
            }
        }
    }
    for (u32 index = 0; index < map->count; index += 1)
    {
        IrSourceRegion* region = map->regions + index;
        if (region->kind == IR_SOURCE_REGION_TEXT && region->origin_plus_one)
        {
            CSourceRegionNames names = map->names[region->origin_plus_one - 1];
            region->origin_plus_one = 0;
            if (region->source != UINT32_MAX)
            {
                u32 physical = string_equal(names.physical, names.logical) ? region->source : c_preprocess_file_index(arena, files, names.physical);
                region->origin_plus_one = physical + 1;
            }
        }
    }
}

BUSTER_C_INTERNAL String8 c_path_directory(String8 path)
{
    for (u64 index = path.length; index; index -= 1)
    {
        char8 character = path.pointer[index - 1];
        if (character == '/' || character == '\\')
        {
            return (String8){
                .pointer = path.pointer,
                .length = index - 1,
            };
        }
    }
    return S8(".");
}

BUSTER_C_INTERNAL bool c_path_is_absolute(String8 path)
{
    return path.length && (path.pointer[0] == '/' || path.pointer[0] == '\\' || (path.length >= 2 && c_ascii_alpha(path.pointer[0]) && path.pointer[1] == ':'));
}

BUSTER_C_INTERNAL bool c_include_read(Arena* arena, String8 directory, String8 name, String8* path_out, String8* source_out, FileMapRead* map_out)
{
    if (map_out)
    {
        *map_out = (FileMapRead){0};
    }
    String8 path = c_path_is_absolute(name) ? string_format_z(arena, S8("{S8}"), name) : string_format_z(arena, S8("{S8}/{S8}"), directory, name);
    FileMapRead map = file_map_read(arena, path, (FileReadOptions){0});
    ByteSlice bytes = map.bytes;
    bool result;
    if (!bytes.pointer)
    {
        result = false;
    }
    else
    {
        *path_out = path;
        *source_out = BYTE_SLICE_TO_STRING(8, bytes);
        if (map_out)
        {
            *map_out = map;
        }
        result = true;
    }

    return result;
}

BUSTER_C_INTERNAL bool c_include_builtin(String8 name, String8* path_out, String8* source_out)
{
    String8 source = {0};
    if (string_equal(name, S8("stdbool.h")))
    {
        source = S8("#ifndef __STDBOOL_H\n"
                    "#define __STDBOOL_H\n"
                    "#if __STDC_VERSION__ < 202311L\n"
                    "#define bool _Bool\n"
                    "#define true 1\n"
                    "#define false 0\n"
                    "#endif\n"
                    "#define __bool_true_false_are_defined 1\n"
                    "#endif\n");
    }
    else if (string_equal(name, S8("stdalign.h")))
    {
        source = S8("#ifndef __STDALIGN_H\n"
                    "#define __STDALIGN_H\n"
                    "#if __STDC_VERSION__ < 202311L\n"
                    "#define alignas _Alignas\n"
                    "#define alignof _Alignof\n"
                    "#endif\n"
                    "#endif\n");
    }
    else if (string_equal(name, S8("stdarg.h")))
    {
        // The Windows CRT may declare its public pointer-sized va_list in
        // vadefs.h before stdarg.h is included. Keep that public representation
        // and bridge its storage to the builtin cursor explicitly; typedef
        // spelling must not confer builtin type identity.
        source = S8("#ifndef __STDARG_H\n"
                    "#define __STDARG_H\n"
                    "typedef __builtin_va_list __gnuc_va_list;\n"
                    "#if defined(_WIN32)\n"
                    "#ifndef _VA_LIST_DEFINED\n"
                    "#define _VA_LIST_DEFINED\n"
                    "typedef char *va_list;\n"
                    "#endif\n"
                    "#define __BUSTER_STDARG_PLACE(arguments) (*((__builtin_va_list *)&(arguments)))\n"
                    "#else\n"
                    "typedef __gnuc_va_list va_list;\n"
                    "#define __BUSTER_STDARG_PLACE(arguments) (arguments)\n"
                    "#endif\n"
                    "#define va_start(arguments, last) "
                    "__builtin_va_start(__BUSTER_STDARG_PLACE(arguments), last)\n"
                    "#define va_end(arguments) "
                    "__builtin_va_end(__BUSTER_STDARG_PLACE(arguments))\n"
                    "#define va_arg(arguments, type) "
                    "__builtin_va_arg(__BUSTER_STDARG_PLACE(arguments), type)\n"
                    "#define va_copy(destination, source) "
                    "__builtin_va_copy(__BUSTER_STDARG_PLACE(destination), __BUSTER_STDARG_PLACE(source))\n"
                    "#if defined(_WIN32)\n"
                    "#ifdef __crt_va_start\n"
                    "#undef __crt_va_start\n"
                    "#define __crt_va_start(arguments, last) va_start(arguments, last)\n"
                    "#endif\n"
                    "#ifdef __crt_va_arg\n"
                    "#undef __crt_va_arg\n"
                    "#define __crt_va_arg(arguments, type) va_arg(arguments, type)\n"
                    "#endif\n"
                    "#ifdef __crt_va_end\n"
                    "#undef __crt_va_end\n"
                    "#define __crt_va_end(arguments) va_end(arguments)\n"
                    "#endif\n"
                    "#endif\n"
                    "#endif\n");
    }
    else if (string_equal(name, S8("stddef.h")))
    {
        source = S8("#ifndef __BUSTER_PTRDIFF_T\n"
                    "#define __BUSTER_PTRDIFF_T\n"
                    "typedef __PTRDIFF_TYPE__ ptrdiff_t;\n"
                    "#endif\n"
                    "#ifndef __BUSTER_SIZE_T\n"
                    "#define __BUSTER_SIZE_T\n"
                    "typedef __SIZE_TYPE__ size_t;\n"
                    "#endif\n"
                    "#ifndef __BUSTER_WCHAR_T\n"
                    "#define __BUSTER_WCHAR_T\n"
                    "typedef __WCHAR_TYPE__ wchar_t;\n"
                    "#endif\n"
                    "#ifndef __BUSTER_MAX_ALIGN_T\n"
                    "#define __BUSTER_MAX_ALIGN_T\n"
                    "typedef union {\n"
                    "    long long integer;\n"
                    "    long double real;\n"
                    "} max_align_t;\n"
                    "#endif\n"
                    "#if __STDC_VERSION__ >= 202311L\n"
                    "typedef typeof(nullptr) nullptr_t;\n"
                    "#endif\n"
                    "#ifndef NULL\n"
                    "#define NULL ((void *)0)\n"
                    "#endif\n"
                    "#define offsetof(type, member) "
                    "__builtin_offsetof(type, member)\n"
                    "#undef __need_ptrdiff_t\n"
                    "#undef __need_size_t\n"
                    "#undef __need_rsize_t\n"
                    "#undef __need_wchar_t\n"
                    "#undef __need_NULL\n"
                    "#undef __need_max_align_t\n"
                    "#undef __need_offsetof\n");
    }
    else if (string_equal(name, S8("limits.h")))
    {
        // The ISO constants below are ours, but <limits.h> is also where a
        // hosted platform publishes its POSIX limits (PATH_MAX, NAME_MAX,
        // _POSIX_ARG_MAX, ...). Pull the system header in first, exactly as
        // Clang and GCC do, then restate the ISO names so this frontend's
        // model of the target wins. _GCC_LIMITS_H_ is what glibc tests before
        // it reaches back for the compiler's header, so defining it here stops
        // that round trip.
        source = S8("#ifndef __LIMITS_H\n"
                    "#define __LIMITS_H\n"
                    "#if !defined(_GCC_LIMITS_H_)\n"
                    "#define _GCC_LIMITS_H_\n"
                    "#endif\n"
                    "#if __STDC_HOSTED__ && __has_include_next(<limits.h>)\n"
                    "#include_next <limits.h>\n"
                    "#endif\n"
                    "#undef CHAR_BIT\n"
                    "#undef SCHAR_MIN\n"
                    "#undef SCHAR_MAX\n"
                    "#undef UCHAR_MAX\n"
                    "#undef CHAR_MIN\n"
                    "#undef CHAR_MAX\n"
                    "#undef SHRT_MIN\n"
                    "#undef SHRT_MAX\n"
                    "#undef USHRT_MAX\n"
                    "#undef INT_MIN\n"
                    "#undef INT_MAX\n"
                    "#undef UINT_MAX\n"
                    "#undef LONG_MIN\n"
                    "#undef LONG_MAX\n"
                    "#undef ULONG_MAX\n"
                    "#undef LLONG_MIN\n"
                    "#undef LLONG_MAX\n"
                    "#undef ULLONG_MAX\n"
                    "#define CHAR_BIT 8\n"
                    "#define SCHAR_MIN (-128)\n"
                    "#define SCHAR_MAX 127\n"
                    "#define UCHAR_MAX 255\n"
                    // Plain char's range follows the target: signed on
                    // every SysV target, and the predefine block above
                    // spells __CHAR_UNSIGNED__ only where it is not.
                    // _testbuffer's `return CHAR_MAX;` sentinel through a
                    // plain char compared unequal to the unsigned spelling,
                    // and every error path fell through it.
                    "#ifdef __CHAR_UNSIGNED__\n"
                    "#define CHAR_MIN 0\n"
                    "#define CHAR_MAX UCHAR_MAX\n"
                    "#else\n"
                    "#define CHAR_MIN SCHAR_MIN\n"
                    "#define CHAR_MAX SCHAR_MAX\n"
                    "#endif\n"
                    "#define SHRT_MIN (-32768)\n"
                    "#define SHRT_MAX 32767\n"
                    "#define USHRT_MAX 65535\n"
                    "#define INT_MIN (-2147483647 - 1)\n"
                    "#define INT_MAX 2147483647\n"
                    "#define UINT_MAX 4294967295U\n"
                    "#if defined(_WIN64)\n"
                    "#define LONG_MIN INT_MIN\n"
                    "#define LONG_MAX INT_MAX\n"
                    "#define ULONG_MAX UINT_MAX\n"
                    "#else\n"
                    "#define LONG_MIN (-9223372036854775807L - 1)\n"
                    "#define LONG_MAX 9223372036854775807L\n"
                    "#define ULONG_MAX 18446744073709551615UL\n"
                    "#endif\n"
                    "#define LLONG_MIN "
                    "(-9223372036854775807LL - 1)\n"
                    "#define LLONG_MAX 9223372036854775807LL\n"
                    "#define ULLONG_MAX 18446744073709551615ULL\n"
                    "#ifndef MB_LEN_MAX\n"
                    "#define MB_LEN_MAX 16\n"
                    "#endif\n"
                    "#endif\n");
    }
    else if (string_equal(name, S8("buster_test_builtin_include_next.h")))
    {
        source = S8("#include_next <buster_test_builtin_include_next.h>\n");
    }
    bool result;
    if (!source.length)
    {
        result = false;
    }
    else
    {
        *path_out = name;
        *source_out = source;
        result = true;
    }

    return result;
}

BUSTER_C_INTERNAL bool c_include_resolve(Arena* arena, CPreprocessOptions options, String8 including_path, String8 name, bool quoted, String8* path_out,
                                           String8* source_out, FileMapRead* map_out, CIncludeSearchOrigin* origin_out)
{
    if (map_out)
    {
        *map_out = (FileMapRead){0};
    }
    if (origin_out)
    {
        *origin_out = (CIncludeSearchOrigin){0};
    }
    if (options.disable_external_includes)
    {
        if (c_include_builtin(name, path_out, source_out))
        {
            if (origin_out)
            {
                *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_BUILTIN};
            }
            return true;
        }
        return false;
    }
    if (c_path_is_absolute(name))
    {
        return c_include_read(arena, S8("."), name, path_out, source_out, map_out);
    }
    if (quoted && c_include_read(arena, c_path_directory(including_path), name, path_out, source_out, map_out))
    {
        if (origin_out)
        {
            *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_QUOTED};
        }
        return true;
    }
    for (u32 index = 0; index < options.include_path_count; index += 1)
    {
        if (c_include_read(arena, options.include_paths[index], name, path_out, source_out, map_out))
        {
            if (origin_out)
            {
                *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_INCLUDE_PATH, .index = index};
            }
            return true;
        }
    }
    if (c_include_builtin(name, path_out, source_out))
    {
        if (origin_out)
        {
            *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_BUILTIN};
        }
        return true;
    }
    for (u32 index = 0; index < options.system_include_path_count; index += 1)
    {
        if (c_include_read(arena, options.system_include_paths[index], name, path_out, source_out, map_out))
        {
            if (origin_out)
            {
                *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_SYSTEM_PATH, .index = index};
            }
            return true;
        }
    }
    return false;
}

BUSTER_C_INTERNAL bool c_include_resolve_next(Arena* arena, CPreprocessOptions options, String8 name, String8* path_out,
                                                String8* source_out, FileMapRead* map_out, CIncludeSearchOrigin origin,
                                                CIncludeSearchOrigin* origin_out)
{
    if (map_out)
    {
        *map_out = (FileMapRead){0};
    }
    if (origin_out)
    {
        *origin_out = (CIncludeSearchOrigin){0};
    }
    if (options.disable_external_includes)
    {
        if (c_include_builtin(name, path_out, source_out))
        {
            if (origin_out)
            {
                *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_BUILTIN};
            }
            return true;
        }
        return false;
    }
    u32 include_start = 0;
    u32 system_start = 0;
    if (origin.kind == C_INCLUDE_SEARCH_INCLUDE_PATH)
    {
        include_start = origin.index < options.include_path_count ? origin.index + 1 : options.include_path_count;
    }
    else if (origin.kind == C_INCLUDE_SEARCH_SYSTEM_PATH)
    {
        include_start = options.include_path_count;
        system_start = origin.index < options.system_include_path_count ? origin.index + 1 : options.system_include_path_count;
    }
    else if (origin.kind == C_INCLUDE_SEARCH_BUILTIN)
    {
        include_start = options.include_path_count;
    }
    for (u32 index = include_start; index < options.include_path_count; index += 1)
    {
        if (c_include_read(arena, options.include_paths[index], name, path_out, source_out, map_out))
        {
            if (origin_out)
            {
                *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_INCLUDE_PATH, .index = index};
            }
            return true;
        }
    }
    if (origin.kind != C_INCLUDE_SEARCH_SYSTEM_PATH && origin.kind != C_INCLUDE_SEARCH_BUILTIN && c_include_builtin(name, path_out, source_out))
    {
        if (origin_out)
        {
            *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_BUILTIN};
        }
        return true;
    }
    for (u32 index = system_start; index < options.system_include_path_count; index += 1)
    {
        if (c_include_read(arena, options.system_include_paths[index], name, path_out, source_out, map_out))
        {
            if (origin_out)
            {
                *origin_out = (CIncludeSearchOrigin){.kind = C_INCLUDE_SEARCH_SYSTEM_PATH, .index = index};
            }
            return true;
        }
    }
    return false;
}

BUSTER_C_INTERNAL bool c_include_name(Arena* arena, char8 const* base, CToken* tokens, u32 token_count, String8* name_out, bool* quoted_out)
{
    if (token_count == 1 && tokens[0].kind == C_TOKEN_STRING_LITERAL && tokens[0].length >= 2)
    {
        String8 spelling = c_token_spelling(base, tokens[0]);
        *name_out = (String8){
            .pointer = spelling.pointer + 1,
            .length = spelling.length - 2,
        };
        *quoted_out = true;
        return true;
    }
    if (token_count >= 3 && c_token_is_punctuator(&tokens[0], C_PUNCTUATOR_LESS) && c_token_is_punctuator(&tokens[token_count - 1], C_PUNCTUATOR_GREATER))
    {
        u64 length = 0;
        for (u32 index = 1; index + 1 < token_count; index += 1)
        {
            length += c_token_length(base, tokens[index]);
        }
        char8* name = arena_allocate(arena, char8, length + 1);
        u64 output = 0;
        for (u32 index = 1; index + 1 < token_count; index += 1)
        {
            String8 spelling = c_token_spelling(base, tokens[index]);
            if (spelling.length)
            {
                memcpy(name + output, spelling.pointer, spelling.length);
            }
            output += spelling.length;
        }
        name[output] = 0;
        *name_out = (String8){
            .pointer = name,
            .length = output,
        };
        *quoted_out = false;
        return true;
    }
    return false;
}

BUSTER_C_INTERNAL void c_preprocess_define_directive(Arena* arena, CSymbolTable* symbols, CLexResult lex, u64* token_index, CMacro** first_macro, CMacro** last_macro,
                                                       CPreprocessResult* result, CSourceLocation directive_location, u32 command_name_start,
                                                       u32 command_name_end);
BUSTER_C_INTERNAL void c_preprocess_undefine_directive(Arena* arena, CSymbolTable* symbols, CLexResult lex, u64* token_index, CMacro* first_macro,
                                                         CPreprocessResult* result, CSourceLocation directive_location, u32 command_name_start,
                                                         u32 command_name_end, bool allow_builtin);

BUSTER_C_INTERNAL CPreprocessorDefinition c_preprocess_command_operand(String8 operand)
{
    CPreprocessorDefinition result = {
        .name = operand,
        .value = S8("1"),
    };
    bool split = false;
    for (u64 index = 0; index < operand.length && !split; index += 1)
    {
        if (operand.pointer[index] == '=')
        {
            result.name = string_slice(operand, 0, index);
            result.value = string_slice(operand, index + 1, operand.length);
            split = true;
        }
    }
    return result;
}

BUSTER_C_INTERNAL void c_preprocess_command_definition(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols,
                                                         CPreprocessorDefinition definition, CMacro** first_macro, CMacro** last_macro,
                                                         CPreprocessResult* result)
{
    String8 prefix = S8("#define ");
    // Separate the synthetic directive terminator from a trailing backslash so translation cannot splice the replacement away.
    String8 text = string_format(arena, S8("{S8}{S8} {S8} \n"), prefix, definition.name, definition.value);
    CLexResult lex = c_lex_space(arena, space, text);
    for (u64 diagnostic_index = 0; diagnostic_index < lex.diagnostic_count; diagnostic_index += 1)
    {
        c_preprocess_diagnostic_copy(arena, result, lex.diagnostics[diagnostic_index]);
    }
    c_symbols_intern_tokens(symbols, lex.spelling_base, lex.tokens, lex.token_shapes, lex.token_count);
    u64 token_index = 2;
    u32 name_start = lex.translated_offset + (u32)prefix.length;
    u32 name_end = name_start + (u32)definition.name.length;
    c_preprocess_define_directive(arena, symbols, lex, &token_index, first_macro, last_macro, result,
                                  (CSourceLocation){.line = 1, .column = 1}, name_start, name_end);
}

BUSTER_C_INTERNAL void c_preprocess_command_undefinition(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols, String8 name,
                                                           CMacro* first_macro, CPreprocessResult* result)
{
    String8 prefix = S8("#undef ");
    String8 text = string_format(arena, S8("{S8}{S8}\n"), prefix, name);
    CLexResult lex = c_lex_space(arena, space, text);
    for (u64 diagnostic_index = 0; diagnostic_index < lex.diagnostic_count; diagnostic_index += 1)
    {
        c_preprocess_diagnostic_copy(arena, result, lex.diagnostics[diagnostic_index]);
    }
    c_symbols_intern_tokens(symbols, lex.spelling_base, lex.tokens, lex.token_shapes, lex.token_count);
    u64 token_index = 2;
    u32 name_start = lex.translated_offset + (u32)prefix.length;
    u32 name_end = name_start + (u32)name.length;
    c_preprocess_undefine_directive(arena, symbols, lex, &token_index, first_macro, result,
                                    (CSourceLocation){.line = 1, .column = 1}, name_start, name_end, true);
}

BUSTER_C_INTERNAL void c_preprocess_command_operations(Arena* arena, CSpellingSpace* space, CSymbolTable* symbols, CPreprocessOptions options,
                                                         CMacro** first_macro, CMacro** last_macro, CPreprocessResult* result)
{
    if (options.macro_operation_count)
    {
        for (u32 operation_index = 0; operation_index < options.macro_operation_count; operation_index += 1)
        {
            CPreprocessorOperation operation = options.macro_operations[operation_index];
            switch (operation.kind)
            {
            case C_PREPROCESSOR_OPERATION_DEFINE:
                c_preprocess_command_definition(arena, space, symbols, c_preprocess_command_operand(operation.operand), first_macro, last_macro, result);
                break;
            case C_PREPROCESSOR_OPERATION_UNDEFINE:
                c_preprocess_command_undefinition(arena, space, symbols, operation.operand, *first_macro, result);
                break;
            case C_PREPROCESSOR_OPERATION_COUNT:
                c_preprocess_diagnostic_push(arena, result, (CSourceLocation){.line = 1, .column = 1}, C_DIAGNOSTIC_INVALID_MACRO_DEFINITION,
                                             S8("invalid command-line macro operation"));
                break;
            }
        }
    }
    else
    {
        // Compatibility for pre-ordered API callers is the historical order:
        // all definitions first, followed by all undefinitions.
        for (u32 definition_index = 0; definition_index < options.definition_count; definition_index += 1)
        {
            c_preprocess_command_definition(arena, space, symbols, options.definitions[definition_index], first_macro, last_macro, result);
        }
        for (u32 undefinition_index = 0; undefinition_index < options.undefinition_count; undefinition_index += 1)
        {
            c_preprocess_command_undefinition(arena, space, symbols, options.undefinitions[undefinition_index], *first_macro, result);
        }
    }
}

// __LINE__ and __FILE__ are defined once as builtin-kind macros; the main
// preprocess loop refreshes the head-of-list line/path state each iteration
// and c_macro_replacement_tokens materializes the value only on expansion.
BUSTER_C_INTERNAL void c_preprocess_builtins(Arena* arena, CSymbolTable* symbols, CMacro** first_macro, CMacro** last_macro, String8 path, CSourceLocation location)
{
    CMacro* line_macro = c_macro_define(arena, 0, symbols, first_macro, last_macro, S8("__LINE__"), 0, 0, 0, 0, false, false);
    line_macro->builtin = C_MACRO_BUILTIN_LINE;
    CMacro* file_macro = c_macro_define(arena, 0, symbols, first_macro, last_macro, S8("__FILE__"), 0, 0, 0, 0, false, false);
    file_macro->builtin = C_MACRO_BUILTIN_FILE;
    (*first_macro)->builtin_line = location.line;
    (*first_macro)->builtin_path = path;
}

BUSTER_C_INTERNAL void c_preprocess_define_directive(Arena* arena, CSymbolTable* symbols, CLexResult lex, u64* token_index, CMacro** first_macro, CMacro** last_macro,
                                                       CPreprocessResult* result, CSourceLocation directive_location, u32 command_name_start,
                                                       u32 command_name_end)
{
    if (*token_index >= lex.token_count || lex.tokens[*token_index].kind != C_TOKEN_IDENTIFIER)
    {
        c_preprocess_diagnostic_push(arena, result, directive_location, C_DIAGNOSTIC_EXPECTED_MACRO_NAME, S8("expected macro name after '#define'"));
        return;
    }
    CToken name = lex.tokens[(*token_index)++];
    u32 parsed_name_end = name.offset + name.length;
    // Adjacency in translated offsets: a '(' that starts a parameter list
    // must follow the name with nothing between (a line splice deletes its
    // bytes in translation, which matches the standard's post-splice view).
    bool function_like = *token_index < lex.token_count && c_token_is_punctuator(&lex.tokens[*token_index], C_PUNCTUATOR_LEFT_PARENTHESIS) &&
                         lex.tokens[*token_index].offset == name.offset + name.length;
    String8* parameters = 0;
    u32 parameter_count = 0;
    bool variadic = false;
    bool valid = true;
    bool command_name_valid = true;
    if (function_like)
    {
        *token_index += 1;
        u64 parameter_capacity = 0;
        while (*token_index + parameter_capacity < lex.token_count)
        {
            CToken token = lex.tokens[*token_index + parameter_capacity];
            if (token.kind == C_TOKEN_NEWLINE || token.kind == C_TOKEN_END_OF_FILE)
            {
                break;
            }
            parameter_capacity += 1;
            if (c_token_is_punctuator(&token, C_PUNCTUATOR_RIGHT_PARENTHESIS))
            {
                break;
            }
        }
        parameters = arena_allocate(arena, String8, parameter_capacity);
        bool expect_parameter = true;
        while (*token_index < lex.token_count)
        {
            CToken token = lex.tokens[*token_index];
            if (c_token_is_punctuator(&token, C_PUNCTUATOR_RIGHT_PARENTHESIS))
            {
                valid = valid && (!expect_parameter || parameter_count == 0);
                parsed_name_end = token.offset + (u32)c_token_length(lex.spelling_base, token);
                *token_index += 1;
                break;
            }
            if (!expect_parameter)
            {
                if (c_token_is_punctuator(&token, C_PUNCTUATOR_COMMA))
                {
                    if (variadic)
                    {
                        valid = false;
                        break;
                    }
                    else
                    {
                        expect_parameter = true;
                        *token_index += 1;
                        continue;
                    }
                }
                valid = false;
                break;
            }
            if (c_token_is_punctuator(&token, C_PUNCTUATOR_ELLIPSIS))
            {
                String8 parameter = S8("__VA_ARGS__");
                for (u32 parameter_index = 0; parameter_index < parameter_count; parameter_index += 1)
                {
                    valid = valid && !string_equal(parameters[parameter_index], parameter);
                }
                parameters[parameter_count++] = parameter;
                variadic = true;
                expect_parameter = false;
                *token_index += 1;
                continue;
            }
            if (token.kind != C_TOKEN_IDENTIFIER)
            {
                valid = false;
                break;
            }
            String8 parameter = c_token_spelling(lex.spelling_base, token);
            for (u32 parameter_index = 0; parameter_index < parameter_count; parameter_index += 1)
            {
                valid = valid && !string_equal(parameters[parameter_index], parameter);
            }
            parameters[parameter_count++] = parameter;
            *token_index += 1;
            if (*token_index < lex.token_count && c_token_is_punctuator(&lex.tokens[*token_index], C_PUNCTUATOR_ELLIPSIS))
            {
                variadic = true;
                *token_index += 1;
            }
            expect_parameter = false;
        }
        if (*token_index > lex.token_count || (*token_index && !c_token_is_punctuator(&lex.tokens[*token_index - 1], C_PUNCTUATOR_RIGHT_PARENTHESIS)))
        {
            valid = false;
        }
    }
    if (command_name_start != UINT32_MAX)
    {
        command_name_valid = name.offset == command_name_start && parsed_name_end == command_name_end;
        valid = valid && command_name_valid;
    }
    u64 replacement_start = *token_index;
    // A block comment is one space, so a newline inside one does not end the
    // definition: CPython's FutureObj_HEAD writes a comment spanning lines
    // between its spliced ones, and the bit-fields after it vanished from
    // the struct.  The comment leaves no token, so the gap bytes between
    // tokens carry the state -- an unclosed /* before a newline token marks
    // it interior, and the interior newlines are dropped from the recorded
    // replacement so expansion and spacing read past them.
    {
        bool comment_open = false;
        u64 gap_start = replacement_start ? (u64)lex.tokens[replacement_start - 1].offset +
                                                c_token_length(lex.spelling_base, lex.tokens[replacement_start - 1])
                                          : 0;
        while (*token_index < lex.token_count && lex.tokens[*token_index].kind != C_TOKEN_END_OF_FILE)
        {
            CToken current = lex.tokens[*token_index];
            bool line_comment = false;
            for (u64 byte_index = gap_start; byte_index < current.offset; byte_index += 1)
            {
                char8 byte = lex.spelling_base[byte_index];
                if (comment_open)
                {
                    if (byte == '*' && byte_index + 1 < current.offset && lex.spelling_base[byte_index + 1] == '/')
                    {
                        comment_open = false;
                        byte_index += 1;
                    }
                }
                else if (!line_comment && byte == '/' && byte_index + 1 < current.offset)
                {
                    if (lex.spelling_base[byte_index + 1] == '*')
                    {
                        comment_open = true;
                        byte_index += 1;
                    }
                    else if (lex.spelling_base[byte_index + 1] == '/')
                    {
                        line_comment = true;
                        byte_index += 1;
                    }
                }
            }
            if (current.kind == C_TOKEN_NEWLINE && !comment_open)
            {
                break;
            }
            gap_start = (u64)current.offset + c_token_length(lex.spelling_base, current);
            *token_index += 1;
        }
    }
    if (!valid)
    {
        String8 message = command_name_valid ? S8("invalid function-like macro parameter list") : S8("invalid macro name after '#define'");
        c_preprocess_diagnostic_push(arena, result, c_lex_token_location(&lex, name), C_DIAGNOSTIC_INVALID_MACRO_DEFINITION,
                                     message);
        return;
    }
    u64 replacement_capacity = *token_index - replacement_start;
    CToken* replacement = arena_allocate(arena, CToken, replacement_capacity);
    u64 replacement_count = 0;
    for (u64 index = 0; index < replacement_capacity; index += 1)
    {
        CToken candidate = lex.tokens[replacement_start + index];
        if (candidate.kind != C_TOKEN_NEWLINE)
        {
            replacement[replacement_count++] = candidate;
        }
    }
    CMacro* macro = c_macro_define(arena, lex.spelling_base, symbols, first_macro, last_macro, c_token_spelling(lex.spelling_base, name), replacement,
                                   (u32)replacement_count, parameters, parameter_count, function_like, variadic);
    macro->definition.replacement_space = c_macro_replacement_spaces(arena, lex.spelling_base, replacement, (u32)replacement_count);
}

BUSTER_C_INTERNAL void c_preprocess_undefine_directive(Arena* arena, CSymbolTable* symbols, CLexResult lex, u64* token_index, CMacro* first_macro,
                                                         CPreprocessResult* result, CSourceLocation directive_location, u32 command_name_start,
                                                         u32 command_name_end, bool allow_builtin)
{
    bool valid = *token_index < lex.token_count && lex.tokens[*token_index].kind == C_TOKEN_IDENTIFIER;
    if (!valid)
    {
        c_preprocess_diagnostic_push(arena, result, directive_location, C_DIAGNOSTIC_EXPECTED_MACRO_NAME, S8("expected macro name after '#undef'"));
    }
    else
    {
        CToken name = lex.tokens[(*token_index)++];
        if (command_name_start != UINT32_MAX)
        {
            valid = name.offset == command_name_start && name.offset + name.length == command_name_end;
        }
        if (!valid)
        {
            c_preprocess_diagnostic_push(arena, result, c_lex_token_location(&lex, name), C_DIAGNOSTIC_INVALID_MACRO_DEFINITION,
                                         S8("invalid macro name after '#undef'"));
        }
        else
        {
            CMacro* macro = c_macro_find_token(first_macro, symbols, lex.spelling_base, &name);
            if (macro && (allow_builtin || !macro->builtin))
            {
                macro->definition.defined = false;
            }
        }
    }
}

bool c_preprocess_dialect_is_gnu(CPreprocessDialect dialect)
{
    return dialect == C_PREPROCESS_DIALECT_GNU99 || dialect == C_PREPROCESS_DIALECT_GNU11 || dialect == C_PREPROCESS_DIALECT_GNU17 ||
           dialect == C_PREPROCESS_DIALECT_GNU23;
}

BUSTER_C_INTERNAL String8 c_preprocess_standard_version(CPreprocessDialect dialect)
{
    switch (dialect)
    {
    case C_PREPROCESS_DIALECT_GNU99:
    case C_PREPROCESS_DIALECT_C99:
        return S8("199901L");
    case C_PREPROCESS_DIALECT_GNU11:
    case C_PREPROCESS_DIALECT_C11:
        return S8("201112L");
    case C_PREPROCESS_DIALECT_GNU17:
    case C_PREPROCESS_DIALECT_C17:
        return S8("201710L");
    case C_PREPROCESS_DIALECT_GNU23:
    case C_PREPROCESS_DIALECT_C23:
        return S8("202311L");
    case C_PREPROCESS_DIALECT_COUNT:
        return (String8){0};
    }
    return (String8){0};
}

BUSTER_C_SHARED bool c_preprocess_dialect_is_c23(CPreprocessDialect dialect)
{
    return dialect == C_PREPROCESS_DIALECT_GNU23 || dialect == C_PREPROCESS_DIALECT_C23;
}

// C23 spells the underscore keywords through aliases; the respell runs at
// the end of preprocessing while the spelling space is still open, so each
// respelled token points at prelude bytes copied under an expansion map
// entry that preserves its recovered source location.
BUSTER_C_INTERNAL void c_preprocess_respell_c23(CSpellingSpace* space, CSourceMap* map, CPreprocessResult* result)
{
    if (!c_preprocess_dialect_is_c23(result->dialect))
    {
        return;
    }
    char8 const* base = space->base;
    IrSourceMapCursor cursor = IR_SOURCE_MAP_CURSOR_EMPTY;
    for (u64 index = 0; index < result->token_count; index += 1)
    {
        CToken* token = result->tokens + index;
        if (token->kind != C_TOKEN_IDENTIFIER)
        {
            continue;
        }
        String8 spelling = c_token_spelling(base, *token);
        String8 respelled = {0};
        if (string_equal(spelling, S8("bool")))
        {
            respelled = S8("_Bool");
        }
        else if (string_equal(spelling, S8("alignas")))
        {
            respelled = S8("_Alignas");
        }
        else if (string_equal(spelling, S8("alignof")))
        {
            respelled = S8("_Alignof");
        }
        else if (string_equal(spelling, S8("static_assert")))
        {
            respelled = S8("_Static_assert");
        }
        else if (string_equal(spelling, S8("thread_local")))
        {
            respelled = S8("_Thread_local");
        }
        if (respelled.length)
        {
            CSourceLocation location = c_preprocess_token_location_cursor(result, *token, &cursor);
            CToken copy = c_space_token(space, respelled, C_TOKEN_IDENTIFIER, C_PUNCTUATOR_NONE);
            c_source_map_append(map, (IrSourceRegion){
                                         .start = copy.offset,
                                         .source = location.file,
                                         .stamp = c_position_from_source_location(location),
                                         .kind = IR_SOURCE_REGION_STAMP,
                                         .origin_plus_one = location.map_offset + 1,
                                     });
            // Appends can move the region array; keep the result's view (the
            // recovery above reads through it) current. The new region is at
            // the tail, past every key already published, so the lookups keep
            // answering through the keys until the map is republished.
            result->recovery->map.regions = map->regions;
            token->offset = copy.offset;
            token->length = copy.length;
            // The symbol travels with the spelling: a respelled token must
            // re-intern or every symbol-keyed consumer would classify it as
            // the old name.
            token->symbol = result->symbols ? c_symbol_intern(result->symbols, respelled) : 0;
        }
    }
}

typedef struct CTargetFeatureMacro CTargetFeatureMacro;
struct CTargetFeatureMacro
{
    String8 name;
    TargetCpuFeature feature;
    CpuArch cpu_arch;
};

// Exactly the features `<buster/lib/simd.h>` tests, in the GNU spelling.  The
// list is deliberately short: every entry is a promise that the frontend and
// the canonical backend can compile code written behind it.
BUSTER_C_INTERNAL CTargetFeatureMacro const c_target_feature_macros[] = {
    { S8_INITIALIZER("__SSE2__"), TARGET_CPU_FEATURE_X86_SSE2, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX__"), TARGET_CPU_FEATURE_X86_AVX, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX2__"), TARGET_CPU_FEATURE_X86_AVX2, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX512F__"), TARGET_CPU_FEATURE_X86_AVX512F, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX512BW__"), TARGET_CPU_FEATURE_X86_AVX512BW, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX512VL__"), TARGET_CPU_FEATURE_X86_AVX512VL, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX512DQ__"), TARGET_CPU_FEATURE_X86_AVX512DQ, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX512VBMI__"), TARGET_CPU_FEATURE_X86_AVX512VBMI, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__AVX512VBMI2__"), TARGET_CPU_FEATURE_X86_AVX512VBMI2, CPU_ARCH_X86_64 },
    { S8_INITIALIZER("__ARM_NEON"), TARGET_CPU_FEATURE_AARCH64_NEON, CPU_ARCH_AARCH64 },
};

CPreprocessResult c_preprocess(Arena* arena, String8 source, CPreprocessOptions options)
{
    if (options.dialect >= C_PREPROCESS_DIALECT_COUNT)
    {
        options.dialect = C_PREPROCESS_DIALECT_GNU17;
    }
    if (!target_data_layout_is_valid(options.data_layout))
    {
        options.data_layout = target_data_layout(options.target);
    }
    CPreprocessResult result = {
        .target = options.target,
        .dialect = options.dialect,
    };
    if (!arena)
    {
        return result;
    }
    // The detail block outlives this call in the caller's arena: the result is
    // returned and then copied by value all the way down the frontend, and
    // every copy shares this one block.
    result.detail = arena_allocate(arena, CPreprocessDetail, 1);
    *result.detail = (CPreprocessDetail){
        .data_layout = options.data_layout,
    };
    // The spelling space lives in its own commit-on-demand arena so its
    // offsets stay contiguous under one base without stealing reserve from
    // the caller's arena; the result carries the arena so a caller that
    // compiles many units can release it. The fixed prelude seeds the
    // well-known spellings, and its expansion entry gives synthesized-token
    // offsets the same all-zero location eagerly-built tokens used to carry.
    Arena* spelling_arena = arena_create((ArenaCreation){
        .reserved_size = BUSTER_GB(1),
        .flags = {.pool_reuse = 1},
    });
    // The output token stream gets the same private-arena treatment as the
    // spelling space, and for the same reason: the final token count is
    // unknown until the last line lands, and the caller's arena interleaves
    // every other preprocessing allocation between output appends. A private
    // reservation keeps the stream contiguous, so every surviving token is
    // written into its final slot exactly once instead of staged per line
    // and copied at the end.
    Arena* token_arena = spelling_arena ? arena_create((ArenaCreation){
                                              .reserved_size = BUSTER_GB(1),
                                              .flags = {.pool_reuse = 1},
                                          })
                                        : 0;
    Arena* token_shape_arena = token_arena ? arena_create((ArenaCreation){
                                                               .reserved_size = BUSTER_GB(1),
                                                               .flags = {.pool_reuse = 1},
                                                           })
                                          : 0;
    if (!token_shape_arena)
    {
        if (token_arena)
        {
            arena_destroy(token_arena, 1);
        }
        if (spelling_arena)
        {
            arena_destroy(spelling_arena, 1);
        }
        return result;
    }
    CSpellingSpace space_storage = {
        .base = (char8*)spelling_arena + arena_minimum_position,
        .arena = spelling_arena,
    };
    CSpellingSpace* space = &space_storage;
    CSourceMapRecovery* recovery = arena_allocate(arena, CSourceMapRecovery, 1);
    *recovery = (CSourceMapRecovery){
        .spelling_arena = spelling_arena,
        .token_arena = token_arena,
        .token_shape_arena = token_shape_arena,
    };
    result.recovery = recovery;
    result.spelling_base = space->base;
    memcpy(c_space_allocate(space, C_SPELLING_PRELUDE_LENGTH), C_SPELLING_PRELUDE_TEXT, C_SPELLING_PRELUDE_LENGTH);
    CSourceMap map = {
        .arena = arena,
    };
    c_source_map_append(&map, (IrSourceRegion){
                                  .start = 0,
                                  .kind = IR_SOURCE_REGION_STAMP,
                              });
    CLexResult root_lex = c_lex_space(arena, space, source);
    CSourceMetricsFileSet metrics_files = {0};
    c_source_metrics_add(&result.detail->source_lexed, &root_lex.metrics);
    {
        u32 root_row = c_source_metrics_file_row(arena, &metrics_files, options.source_path);
        BUSTER_CHECK(metrics_files.rows && root_row < metrics_files.count);
        if (metrics_files.rows[root_row].lex_count == 0)
        {
            c_source_metrics_add(&result.detail->source_unique, &root_lex.metrics);
        }
        metrics_files.rows[root_row].translated_bytes = root_lex.metrics.translated_bytes;
        metrics_files.rows[root_row].lex_count += 1;
    }
    CSymbolTable* symbol_table = arena_allocate(arena, CSymbolTable, 1);
    *symbol_table = c_symbol_table_create(arena);
    result.symbols = symbol_table;
    c_symbols_intern_tokens(symbol_table, root_lex.spelling_base, root_lex.tokens, root_lex.token_shapes, root_lex.token_count);
    CPpClassMasks root_class_masks;
    c_pp_class_masks_build(arena, &root_class_masks, root_lex.token_shapes, root_lex.token_count);
    result.diagnostic_capacity = BUSTER_MIN(source.length + options.macro_operation_count + options.definition_count + 1, UINT64_C(64));
    result.diagnostics = arena_allocate(arena, CDiagnostic, result.diagnostic_capacity);
    for (u64 diagnostic_index = 0; diagnostic_index < root_lex.diagnostic_count; diagnostic_index += 1)
    {
        c_preprocess_diagnostic_copy(arena, &result, root_lex.diagnostics[diagnostic_index]);
    }
    CMacro* first_macro = 0;
    CMacro* last_macro = 0;
    CToken* standard_replacement = arena_allocate(arena, CToken, 2);
    standard_replacement[0] = (CToken){
        .offset = C_SPELLING_ONE,
        .length = 1,
        .kind = C_TOKEN_PREPROCESSING_NUMBER,
    };
    standard_replacement[1] = c_space_token(space, c_preprocess_standard_version(options.dialect), C_TOKEN_PREPROCESSING_NUMBER, C_PUNCTUATOR_NONE);
    c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__STDC__"), standard_replacement, 1, 0, 0, false, false);
    c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__BUSTER__"), standard_replacement, 1, 0, 0, false, false);
    // The GNU version macros are not a dialect switch.  Both reference
    // compilers predefine them in every standard mode -- `clang -std=c99
    // -dM -E` reports `__GNUC__ 4` beside `__STRICT_ANSI__ 1`, and gcc does
    // the same with its own version -- because they describe which language
    // extensions the compiler implements, not which ones the dialect
    // permits.  Gating them on the GNU dialect made `ide cc -std=c99` read a
    // *different* source than clang did from the same header: musl's
    // <tgmath.h> drops its `__typeof__` return casts without `__GNUC__`, so
    // every type-generic macro then has the type of its widest arm and
    // `sizeof pow(2.0, 0.5)` came back as `long double _Complex`.
    // __STRICT_ANSI__ is the dialect switch, and it stays one.
    c_macro_define_object_text(arena, space, symbol_table, &first_macro, &last_macro, S8("__GNUC__"), S8("4"));
    c_macro_define_object_text(arena, space, symbol_table, &first_macro, &last_macro, S8("__GNUC_MINOR__"), S8("2"));
    c_macro_define_object_text(arena, space, symbol_table, &first_macro, &last_macro, S8("__GNUC_PATCHLEVEL__"), S8("1"));
    if (!c_preprocess_dialect_is_gnu(options.dialect))
    {
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__STRICT_ANSI__"), standard_replacement, 1, 0, 0, false, false);
    }
    static char const* atomic_order_names[] = {
        "__ATOMIC_RELAXED", "__ATOMIC_CONSUME", "__ATOMIC_ACQUIRE", "__ATOMIC_RELEASE", "__ATOMIC_ACQ_REL", "__ATOMIC_SEQ_CST",
    };
    for (u32 order = 0; order < BUSTER_ARRAY_LENGTH(atomic_order_names); order += 1)
    {
        CToken* replacement = arena_allocate(arena, CToken, 1);
        replacement[0] = c_space_token(space, string_format(arena, S8("{u32}"), order), C_TOKEN_PREPROCESSING_NUMBER, C_PUNCTUATOR_NONE);
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, string_from_pointer((char8*)atomic_order_names[order]), replacement, 1, 0, 0, false, false);
    }
    static char const* lock_free_macro_names[] = {
        "__CLANG_ATOMIC_BOOL_LOCK_FREE",     "__CLANG_ATOMIC_CHAR_LOCK_FREE",    "__CLANG_ATOMIC_CHAR8_T_LOCK_FREE", "__CLANG_ATOMIC_CHAR16_T_LOCK_FREE",
        "__CLANG_ATOMIC_CHAR32_T_LOCK_FREE", "__CLANG_ATOMIC_WCHAR_T_LOCK_FREE", "__CLANG_ATOMIC_SHORT_LOCK_FREE",   "__CLANG_ATOMIC_INT_LOCK_FREE",
        "__CLANG_ATOMIC_LONG_LOCK_FREE",     "__CLANG_ATOMIC_LLONG_LOCK_FREE",   "__CLANG_ATOMIC_POINTER_LOCK_FREE",
    };
    CToken* lock_free_replacement = arena_allocate(arena, CToken, 1);
    lock_free_replacement[0] = c_space_token(space, S8("2"), C_TOKEN_PREPROCESSING_NUMBER, C_PUNCTUATOR_NONE);
    for (u32 macro_index = 0; macro_index < BUSTER_ARRAY_LENGTH(lock_free_macro_names); macro_index += 1)
    {
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, string_from_pointer((char8*)lock_free_macro_names[macro_index]), lock_free_replacement, 1, 0, 0, false,
                       false);
    }
    String8* feature_parameters = arena_allocate(arena, String8, 1);
    feature_parameters[0] = S8("feature");
    static char const* feature_macro_names[] = {
        "__building_module", "__has_attribute", "__has_builtin", "__has_c_attribute", "__has_extension", "__has_feature", "__has_include", "__has_include_next",
        "__is_target_arch", "__is_target_environment", "__is_target_os", "__is_target_vendor",
    };
    for (u32 feature_index = 0; feature_index < BUSTER_ARRAY_LENGTH(feature_macro_names); feature_index += 1)
    {
        String8 feature_name = string_from_pointer((char8*)feature_macro_names[feature_index]);
        CToken* feature_replacement = arena_allocate(arena, CToken, 4);
        feature_replacement[0] = c_space_token(space, feature_name, C_TOKEN_IDENTIFIER, C_PUNCTUATOR_NONE);
        feature_replacement[1] = (CToken){
            .offset = C_SPELLING_LEFT_PARENTHESIS,
            .length = 1,
            .kind = C_TOKEN_PUNCTUATOR,
            .punctuator = C_PUNCTUATOR_LEFT_PARENTHESIS,
        };
        feature_replacement[2] = c_space_token(space, S8("feature"), C_TOKEN_IDENTIFIER, C_PUNCTUATOR_NONE);
        feature_replacement[3] = (CToken){
            .offset = C_SPELLING_RIGHT_PARENTHESIS,
            .length = 1,
            .kind = C_TOKEN_PUNCTUATOR,
            .punctuator = C_PUNCTUATOR_RIGHT_PARENTHESIS,
        };
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, feature_name, feature_replacement, 4, feature_parameters, 1, true, false);
    }
    String8* pragma_parameters = arena_allocate(arena, String8, 1);
    pragma_parameters[0] = S8("value");
    CMacro* pragma_macro = c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("_Pragma"), 0, 0, pragma_parameters, 1, true, false);
    pragma_macro->definition.pragma_like = true;
    if (options.target.os == OPERATING_SYSTEM_WINDOWS)
    {
        CMacro* windows_pragma_macro = c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__pragma"), 0, 0, pragma_parameters, 1, true, false);
        windows_pragma_macro->definition.pragma_like = true;
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("C_ASSERT"), 0, 0, pragma_parameters, 1, true, false);
        static char const* c_windows_calling_convention_names[] = {
            "__cdecl", "__stdcall", "__fastcall", "__thiscall", "__vectorcall", "__ptr32", "__ptr64", "__unaligned", "_W64",
        };
        for (u32 calling_convention_index = 0; calling_convention_index < BUSTER_ARRAY_LENGTH(c_windows_calling_convention_names);
             calling_convention_index += 1)
        {
            c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, string_from_pointer((char8*)c_windows_calling_convention_names[calling_convention_index]), 0, 0,
                           0, 0, false, false);
        }
    }
    TargetDataLayout layout = options.data_layout;
    CToken* constant_parameter_replacement = arena_allocate(arena, CToken, 1);
    constant_parameter_replacement[0] = c_space_token(space, S8("value"), C_TOKEN_IDENTIFIER, C_PUNCTUATOR_NONE);
    String8* constant_parameters = arena_allocate(arena, String8, 1);
    constant_parameters[0] = S8("value");
    static char const* constant_macro_names[] = {
        "__INT8_C", "__UINT8_C", "__INT16_C", "__UINT16_C", "__INT32_C", "__UINT32_C", "__INT64_C", "__UINT64_C", "__INTMAX_C", "__UINTMAX_C",
    };
    for (u32 macro_index = 0; macro_index < BUSTER_ARRAY_LENGTH(constant_macro_names); macro_index += 1)
    {
        // SDK stdint headers use these functions as their literal constructors.
        // Keep the promoted small types, unsigned int, and target 64-bit types;
        // identity replacements make UINT64_C(1) << lane a signed int shift.
        String8 suffix = S8("");
        if (macro_index == 5)
        {
            suffix = S8("U");
        }
        else if (macro_index >= 6)
        {
            bool is_unsigned = (macro_index & 1) != 0;
            suffix = layout.long_integer.size == 8 ? (is_unsigned ? S8("UL") : S8("L")) : (is_unsigned ? S8("ULL") : S8("LL"));
        }
        CToken* replacement = constant_parameter_replacement;
        u32 replacement_count = 1;
        if (suffix.length)
        {
            replacement = arena_allocate(arena, CToken, 3);
            replacement[0] = constant_parameter_replacement[0];
            replacement[1] = c_space_token(space, S8("##"), C_TOKEN_PUNCTUATOR, C_PUNCTUATOR_HASH_HASH);
            replacement[2] = c_space_token(space, suffix, C_TOKEN_IDENTIFIER, C_PUNCTUATOR_NONE);
            replacement_count = 3;
        }
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, string_from_pointer((char8*)constant_macro_names[macro_index]), replacement, replacement_count,
                       constant_parameters, 1, true, false);
    }
    bool windows_target = options.target.os == OPERATING_SYSTEM_WINDOWS;
    bool short_wchar_target = target_uses_16_bit_wchar(options.target);
    String8 signed_pointer_type = layout.long_integer.size == layout.pointer.size ? S8("long") : S8("long long");
    String8 unsigned_pointer_type = layout.unsigned_long_integer.size == layout.pointer.size ? S8("unsigned long") : S8("unsigned long long");
    String8 signed_64_type = layout.long_integer.bit_width == 64 ? S8("long") : S8("long long");
    String8 unsigned_64_type = layout.unsigned_long_integer.bit_width == 64 ? S8("unsigned long") : S8("unsigned long long");
#define C_DEFINE_TYPE_MACRO(name, replacement) c_macro_define_object_text(arena, space, symbol_table, &first_macro, &last_macro, S8(name), (replacement))
    C_DEFINE_TYPE_MACRO("__SIZE_TYPE__", unsigned_pointer_type);
    C_DEFINE_TYPE_MACRO("__PTRDIFF_TYPE__", signed_pointer_type);
    C_DEFINE_TYPE_MACRO("__INTPTR_TYPE__", signed_pointer_type);
    C_DEFINE_TYPE_MACRO("__UINTPTR_TYPE__", unsigned_pointer_type);
    C_DEFINE_TYPE_MACRO("__INTMAX_TYPE__", signed_64_type);
    C_DEFINE_TYPE_MACRO("__UINTMAX_TYPE__", unsigned_64_type);
    C_DEFINE_TYPE_MACRO("__INT8_TYPE__", S8("signed char"));
    C_DEFINE_TYPE_MACRO("__UINT8_TYPE__", S8("unsigned char"));
    C_DEFINE_TYPE_MACRO("__INT16_TYPE__", S8("short"));
    C_DEFINE_TYPE_MACRO("__UINT16_TYPE__", S8("unsigned short"));
    C_DEFINE_TYPE_MACRO("__INT32_TYPE__", S8("int"));
    C_DEFINE_TYPE_MACRO("__UINT32_TYPE__", S8("unsigned int"));
    C_DEFINE_TYPE_MACRO("__INT64_TYPE__", signed_64_type);
    C_DEFINE_TYPE_MACRO("__UINT64_TYPE__", unsigned_64_type);
    C_DEFINE_TYPE_MACRO("__WCHAR_TYPE__", short_wchar_target ? S8("unsigned short") :
                      target_uses_unsigned_wchar(options.target) ? S8("unsigned int") : S8("int"));
    C_DEFINE_TYPE_MACRO("__WINT_TYPE__", options.target.os == OPERATING_SYSTEM_UEFI ? S8("unsigned short") : S8("unsigned int"));
    C_DEFINE_TYPE_MACRO("__CHAR8_TYPE__", S8("unsigned char"));
    C_DEFINE_TYPE_MACRO("__CHAR16_TYPE__", S8("unsigned short"));
    C_DEFINE_TYPE_MACRO("__CHAR32_TYPE__", S8("unsigned int"));
    C_DEFINE_TYPE_MACRO("__SIZEOF_POINTER__", string_format(arena, S8("{u32}"), layout.pointer.size));
    C_DEFINE_TYPE_MACRO("__POINTER_WIDTH__", string_format(arena, S8("{u32}"), layout.pointer.bit_width));
    C_DEFINE_TYPE_MACRO("__SIZE_WIDTH__", string_format(arena, S8("{u32}"), layout.pointer.bit_width));
    C_DEFINE_TYPE_MACRO("__INTPTR_WIDTH__", string_format(arena, S8("{u32}"), layout.pointer.bit_width));
    C_DEFINE_TYPE_MACRO("__INT_WIDTH__", string_format(arena, S8("{u32}"), layout.integer.bit_width));
    C_DEFINE_TYPE_MACRO("__LONG_WIDTH__", string_format(arena, S8("{u32}"), layout.long_integer.bit_width));
    C_DEFINE_TYPE_MACRO("__LONG_LONG_WIDTH__", string_format(arena, S8("{u32}"), layout.long_long_integer.bit_width));
    C_DEFINE_TYPE_MACRO("__SCHAR_MAX__", S8("127"));
    C_DEFINE_TYPE_MACRO("__SHRT_MAX__", S8("32767"));
    C_DEFINE_TYPE_MACRO("__INT_MAX__", S8("2147483647"));
    C_DEFINE_TYPE_MACRO("__LONG_MAX__", layout.long_integer.bit_width == 64 ? S8("9223372036854775807L") : S8("2147483647L"));
    C_DEFINE_TYPE_MACRO("__LONG_LONG_MAX__", S8("9223372036854775807LL"));
    C_DEFINE_TYPE_MACRO("__SIZEOF_SHORT__", string_format(arena, S8("{u32}"), layout.short_integer.size));
    C_DEFINE_TYPE_MACRO("__SIZEOF_INT__", string_format(arena, S8("{u32}"), layout.integer.size));
    C_DEFINE_TYPE_MACRO("__SIZEOF_LONG__", string_format(arena, S8("{u32}"), layout.long_integer.size));
    C_DEFINE_TYPE_MACRO("__SIZEOF_LONG_LONG__", string_format(arena, S8("{u32}"), layout.long_long_integer.size));
    if (layout.has_128_bit_integer)
    {
        C_DEFINE_TYPE_MACRO("__SIZEOF_INT128__", string_format(arena, S8("{u32}"), layout.integer128.size));
        // Clang and GCC predefine these two spellings as builtin typedef names
        // for the 128-bit integer keyword rather than declaring them in a
        // header, and code that uses 128-bit arithmetic reaches for them
        // directly (SQLite's decimal and integer-overflow helpers do).  The
        // keyword itself is already understood, so retain it in the expansion.
        C_DEFINE_TYPE_MACRO("__int128_t", S8("__int128"));
        C_DEFINE_TYPE_MACRO("__uint128_t", S8("unsigned __int128"));
    }
    C_DEFINE_TYPE_MACRO("__SIZEOF_FLOAT__", string_format(arena, S8("{u32}"), layout.float_type.size));
    // The `_Float16` half of the <float.h> vocabulary, with clang's own
    // spellings and values. They describe IEEE-754 binary16, which is what
    // `_Float16` is on every target here, and they carry the C23 `F16`
    // suffix exactly as clang's do -- a resource header that reaches for
    // FLT16_MAX gets a constant of the right type, not a double.
    C_DEFINE_TYPE_MACRO("__FLT16_MANT_DIG__", S8("11"));
    C_DEFINE_TYPE_MACRO("__FLT16_DIG__", S8("3"));
    C_DEFINE_TYPE_MACRO("__FLT16_DECIMAL_DIG__", S8("5"));
    C_DEFINE_TYPE_MACRO("__FLT16_MAX__", S8("6.5504e+4F16"));
    C_DEFINE_TYPE_MACRO("__FLT16_NORM_MAX__", S8("6.5504e+4F16"));
    C_DEFINE_TYPE_MACRO("__FLT16_MIN__", S8("6.103515625e-5F16"));
    C_DEFINE_TYPE_MACRO("__FLT16_DENORM_MIN__", S8("5.9604644775390625e-8F16"));
    C_DEFINE_TYPE_MACRO("__FLT16_EPSILON__", S8("9.765625e-4F16"));
    C_DEFINE_TYPE_MACRO("__FLT16_MAX_EXP__", S8("16"));
    C_DEFINE_TYPE_MACRO("__FLT16_MIN_EXP__", S8("(-13)"));
    C_DEFINE_TYPE_MACRO("__FLT16_MAX_10_EXP__", S8("4"));
    C_DEFINE_TYPE_MACRO("__FLT16_MIN_10_EXP__", S8("(-4)"));
    C_DEFINE_TYPE_MACRO("__FLT16_HAS_DENORM__", S8("1"));
    C_DEFINE_TYPE_MACRO("__FLT16_HAS_INFINITY__", S8("1"));
    C_DEFINE_TYPE_MACRO("__FLT16_HAS_QUIET_NAN__", S8("1"));
    C_DEFINE_TYPE_MACRO("__SIZEOF_FLOAT16__", string_format(arena, S8("{u32}"), layout.float16_type.size));
    C_DEFINE_TYPE_MACRO("__SIZEOF_DOUBLE__", string_format(arena, S8("{u32}"), layout.double_type.size));
    C_DEFINE_TYPE_MACRO("__SIZEOF_LONG_DOUBLE__", string_format(arena, S8("{u32}"), layout.long_double_type.size));
    // The hosted <float.h> supplied by Clang/GCC spells DBL_EPSILON in terms
    // of this predefined macro.  Keep the value in the compiler's prelude so
    // an otherwise ordinary system header does not depend on a host compiler
    // having supplied it first (cJSON uses DBL_EPSILON directly).
    C_DEFINE_TYPE_MACRO("__DBL_EPSILON__", S8("2.220446049250313080847263336181640625e-16"));
    // Lua's number formatting and conversion code queries the corresponding
    // mantissa width through <float.h>'s __DBL_MANT_DIG__ spelling.  Keep the
    // IEEE-754 double contract explicit in the builtin prelude, just as the
    // epsilon above, so an external resource header cannot leave it undefined.
    C_DEFINE_TYPE_MACRO("__DBL_MANT_DIG__", S8("53"));
    // Lua's string formatter also uses the decimal exponent bound from
    // <float.h>; this is the IEEE-754 binary64 value required by
    // DBL_MAX_10_EXP on every hosted target currently supported here.
    C_DEFINE_TYPE_MACRO("__DBL_MAX_10_EXP__", S8("308"));
    // C99's decimal-roundtrip precision macros are exposed by <float.h> in
    // terms of the compiler predefined spellings.  Keep the IEEE-754 values
    // in the prelude so external headers (and yyjson's number tests) do not
    // inherit a host compiler's macro set.
    C_DEFINE_TYPE_MACRO("__FLT_DECIMAL_DIG__", S8("9"));
    C_DEFINE_TYPE_MACRO("__DBL_DECIMAL_DIG__", S8("17"));
    // The rest of the <float.h> vocabulary, with Clang's own spellings: the
    // hosted header defines every FLT_/DBL_/LDBL_ constant in terms of these
    // predefines, so a compiler that lacks one turns an ordinary
    // `double m = DBL_MAX;` into an undeclared identifier -- which is where
    // CPython's Objects/floatobject.c stopped.  float and double are IEEE
    // binary32/64 on every hosted target here; the long double family
    // follows the target's layout below.
    C_DEFINE_TYPE_MACRO("__FLT_RADIX__", S8("2"));
    C_DEFINE_TYPE_MACRO("__FLT_MANT_DIG__", S8("24"));
    C_DEFINE_TYPE_MACRO("__FLT_DIG__", S8("6"));
    C_DEFINE_TYPE_MACRO("__FLT_MAX__", S8("3.40282347e+38F"));
    C_DEFINE_TYPE_MACRO("__FLT_NORM_MAX__", S8("3.40282347e+38F"));
    C_DEFINE_TYPE_MACRO("__FLT_MIN__", S8("1.17549435e-38F"));
    C_DEFINE_TYPE_MACRO("__FLT_DENORM_MIN__", S8("1.40129846e-45F"));
    C_DEFINE_TYPE_MACRO("__FLT_EPSILON__", S8("1.19209290e-7F"));
    C_DEFINE_TYPE_MACRO("__FLT_MAX_EXP__", S8("128"));
    C_DEFINE_TYPE_MACRO("__FLT_MIN_EXP__", S8("(-125)"));
    C_DEFINE_TYPE_MACRO("__FLT_MAX_10_EXP__", S8("38"));
    C_DEFINE_TYPE_MACRO("__FLT_MIN_10_EXP__", S8("(-37)"));
    C_DEFINE_TYPE_MACRO("__FLT_HAS_DENORM__", S8("1"));
    C_DEFINE_TYPE_MACRO("__FLT_HAS_INFINITY__", S8("1"));
    C_DEFINE_TYPE_MACRO("__FLT_HAS_QUIET_NAN__", S8("1"));
    C_DEFINE_TYPE_MACRO("__DBL_DIG__", S8("15"));
    C_DEFINE_TYPE_MACRO("__DBL_MAX__", S8("1.7976931348623157e+308"));
    C_DEFINE_TYPE_MACRO("__DBL_NORM_MAX__", S8("1.7976931348623157e+308"));
    C_DEFINE_TYPE_MACRO("__DBL_MIN__", S8("2.2250738585072014e-308"));
    C_DEFINE_TYPE_MACRO("__DBL_DENORM_MIN__", S8("4.9406564584124654e-324"));
    C_DEFINE_TYPE_MACRO("__DBL_MAX_EXP__", S8("1024"));
    C_DEFINE_TYPE_MACRO("__DBL_MIN_EXP__", S8("(-1021)"));
    C_DEFINE_TYPE_MACRO("__DBL_MIN_10_EXP__", S8("(-307)"));
    C_DEFINE_TYPE_MACRO("__DBL_HAS_DENORM__", S8("1"));
    C_DEFINE_TYPE_MACRO("__DBL_HAS_INFINITY__", S8("1"));
    C_DEFINE_TYPE_MACRO("__DBL_HAS_QUIET_NAN__", S8("1"));
    C_DEFINE_TYPE_MACRO("__DECIMAL_DIG__", S8("__LDBL_DECIMAL_DIG__"));
    {
        // <float.h> spells FLT_ROUNDS as `(__builtin_flt_rounds())`, a call
        // that reads the dynamic rounding mode.  The prelude answers 1 --
        // round to nearest, every hosted process's startup mode, and GCC's
        // own historical answer -- as a zero-parameter function-like macro,
        // so the spelling folds before lowering ever meets a builtin call.
        // The documented cost: a program that calls fesetround and then
        // reads FLT_ROUNDS sees a stale 1, exactly as it did under GCC
        // before the builtin existed.
        CLexResult flt_rounds_lex = c_lex_space(arena, space, S8("1"));
        c_symbols_intern_tokens(symbol_table, flt_rounds_lex.spelling_base, flt_rounds_lex.tokens, flt_rounds_lex.token_shapes, flt_rounds_lex.token_count);
        CMacro* flt_rounds_macro =
            c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__builtin_flt_rounds"), flt_rounds_lex.tokens, 1, 0, 0, true, false);
        flt_rounds_macro->definition.replacement_space = c_macro_replacement_spaces(arena, flt_rounds_lex.spelling_base, flt_rounds_lex.tokens, 1);
    }
    C_DEFINE_TYPE_MACRO("__LDBL_HAS_DENORM__", S8("1"));
    C_DEFINE_TYPE_MACRO("__LDBL_HAS_INFINITY__", S8("1"));
    C_DEFINE_TYPE_MACRO("__LDBL_HAS_QUIET_NAN__", S8("1"));
    if (layout.long_double_type.bit_width == 80)
    {
        // The x87 extended format, x86-64 Linux's long double.
        C_DEFINE_TYPE_MACRO("__LDBL_MANT_DIG__", S8("64"));
        C_DEFINE_TYPE_MACRO("__LDBL_DIG__", S8("18"));
        C_DEFINE_TYPE_MACRO("__LDBL_DECIMAL_DIG__", S8("21"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX__", S8("1.18973149535723176502e+4932L"));
        C_DEFINE_TYPE_MACRO("__LDBL_NORM_MAX__", S8("1.18973149535723176502e+4932L"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN__", S8("3.36210314311209350626e-4932L"));
        C_DEFINE_TYPE_MACRO("__LDBL_DENORM_MIN__", S8("3.64519953188247460253e-4951L"));
        C_DEFINE_TYPE_MACRO("__LDBL_EPSILON__", S8("1.08420217248550443401e-19L"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX_EXP__", S8("16384"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN_EXP__", S8("(-16381)"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX_10_EXP__", S8("4932"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN_10_EXP__", S8("(-4931)"));
    }
    else if (layout.long_double_type.bit_width == 128)
    {
        // IEEE binary128, AArch64 Linux's long double.
        C_DEFINE_TYPE_MACRO("__LDBL_MANT_DIG__", S8("113"));
        C_DEFINE_TYPE_MACRO("__LDBL_DIG__", S8("33"));
        C_DEFINE_TYPE_MACRO("__LDBL_DECIMAL_DIG__", S8("36"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX__", S8("1.18973149535723176508575932662800702e+4932L"));
        C_DEFINE_TYPE_MACRO("__LDBL_NORM_MAX__", S8("1.18973149535723176508575932662800702e+4932L"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN__", S8("3.36210314311209350626267781732175260e-4932L"));
        C_DEFINE_TYPE_MACRO("__LDBL_DENORM_MIN__", S8("6.47517511943802511092443895822764655e-4966L"));
        C_DEFINE_TYPE_MACRO("__LDBL_EPSILON__", S8("1.92592994438723585305597794258492732e-34L"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX_EXP__", S8("16384"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN_EXP__", S8("(-16381)"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX_10_EXP__", S8("4932"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN_10_EXP__", S8("(-4931)"));
    }
    else
    {
        // long double is double: Windows, and any other 64-bit layout.
        C_DEFINE_TYPE_MACRO("__LDBL_MANT_DIG__", S8("53"));
        C_DEFINE_TYPE_MACRO("__LDBL_DIG__", S8("15"));
        C_DEFINE_TYPE_MACRO("__LDBL_DECIMAL_DIG__", S8("17"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX__", S8("1.7976931348623157e+308L"));
        C_DEFINE_TYPE_MACRO("__LDBL_NORM_MAX__", S8("1.7976931348623157e+308L"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN__", S8("2.2250738585072014e-308L"));
        C_DEFINE_TYPE_MACRO("__LDBL_DENORM_MIN__", S8("4.9406564584124654e-324L"));
        C_DEFINE_TYPE_MACRO("__LDBL_EPSILON__", S8("2.2204460492503131e-16L"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX_EXP__", S8("1024"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN_EXP__", S8("(-1021)"));
        C_DEFINE_TYPE_MACRO("__LDBL_MAX_10_EXP__", S8("308"));
        C_DEFINE_TYPE_MACRO("__LDBL_MIN_10_EXP__", S8("(-307)"));
    }
    C_DEFINE_TYPE_MACRO("__SIZEOF_VA_LIST__", string_format(arena, S8("{u32}"), layout.va_list.size));
    C_DEFINE_TYPE_MACRO("__LONG_DOUBLE_WIDTH__", string_format(arena, S8("{u32}"), layout.long_double_type.bit_width));
    C_DEFINE_TYPE_MACRO("__WCHAR_WIDTH__", short_wchar_target ? S8("16") : S8("32"));
    C_DEFINE_TYPE_MACRO("__ORDER_LITTLE_ENDIAN__", S8("1234"));
    C_DEFINE_TYPE_MACRO("__ORDER_BIG_ENDIAN__", S8("4321"));
    C_DEFINE_TYPE_MACRO("__BYTE_ORDER__", layout.endianness == TARGET_ENDIAN_LITTLE ? S8("__ORDER_LITTLE_ENDIAN__") : S8("__ORDER_BIG_ENDIAN__"));
    C_DEFINE_TYPE_MACRO("__clang__", S8("1"));
    C_DEFINE_TYPE_MACRO("__clang_major__", S8("18"));
    C_DEFINE_TYPE_MACRO("__clang_minor__", S8("0"));
    C_DEFINE_TYPE_MACRO("__clang_patchlevel__", S8("0"));
    // The string form beside the three numbers: CPython's Python/getcompiler.c
    // builds sys.version's compiler field from it.
    C_DEFINE_TYPE_MACRO("__clang_version__", S8("\"18.0.0 (buster)\""));
    // C11 6.10.8.1 mandates both, in exactly these spellings ("Mmm dd yyyy"
    // and "hh:mm:ss").  A fixed epoch keeps builds reproducible; consumers
    // parse the SHAPE -- CPython's platform.py rejects sys.version when the
    // date field carries anything outside [\w ], which is what the
    // getbuildinfo fallback ("xx/xx/xx") for a missing __DATE__ does.
    C_DEFINE_TYPE_MACRO("__DATE__", S8("\"Jan  1 1970\""));
    C_DEFINE_TYPE_MACRO("__TIME__", S8("\"00:00:00\""));
    if (!layout.plain_char_is_signed)
    {
        C_DEFINE_TYPE_MACRO("__CHAR_UNSIGNED__", S8("1"));
    }
    if (windows_target)
    {
        C_DEFINE_TYPE_MACRO("__int8", S8("signed char"));
        C_DEFINE_TYPE_MACRO("__int16", S8("short"));
        C_DEFINE_TYPE_MACRO("__int32", S8("int"));
        C_DEFINE_TYPE_MACRO("__int64", S8("long long"));
        C_DEFINE_TYPE_MACRO("_MSC_VER", S8("1940"));
        C_DEFINE_TYPE_MACRO("_MSC_FULL_VER", S8("194000000"));
        C_DEFINE_TYPE_MACRO("_MSC_EXTENSIONS", S8("1"));
        C_DEFINE_TYPE_MACRO("__inline", S8("static inline"));
        C_DEFINE_TYPE_MACRO("__forceinline", S8("static inline"));
        C_DEFINE_TYPE_MACRO("SORTPP_PASS", S8("1"));
        C_DEFINE_TYPE_MACRO("_WIN64", S8("1"));
        if (options.target.cpu_arch == CPU_ARCH_X86_64)
        {
            C_DEFINE_TYPE_MACRO("_AMD64_", S8("1"));
            C_DEFINE_TYPE_MACRO("_M_AMD64", S8("100"));
            C_DEFINE_TYPE_MACRO("_M_X64", S8("100"));
        }
        else if (options.target.cpu_arch == CPU_ARCH_AARCH64)
        {
            C_DEFINE_TYPE_MACRO("_ARM64_", S8("1"));
            C_DEFINE_TYPE_MACRO("_M_ARM64", S8("1"));
        }
    }
    if (layout.pointer.size == 8 && layout.long_integer.size == 8)
    {
        C_DEFINE_TYPE_MACRO("__LP64__", S8("1"));
        C_DEFINE_TYPE_MACRO("_LP64", S8("1"));
    }
    else if (layout.pointer.size == 4 && layout.long_integer.size == 4)
    {
        C_DEFINE_TYPE_MACRO("__ILP32__", S8("1"));
        C_DEFINE_TYPE_MACRO("_ILP32", S8("1"));
    }
    if (options.target.os == OPERATING_SYSTEM_ANDROID && options.target.os_version_major)
    {
        C_DEFINE_TYPE_MACRO("__ANDROID_MIN_SDK_VERSION__", string_format(arena, S8("{u32}"), (u32)options.target.os_version_major));
        C_DEFINE_TYPE_MACRO("__ANDROID_API__", S8("__ANDROID_MIN_SDK_VERSION__"));
    }
#undef C_DEFINE_TYPE_MACRO
    String8 operating_system_macros[7] = {0};
    u32 operating_system_macro_count = 0;
    switch (options.target.os)
    {
    case OPERATING_SYSTEM_WINDOWS:
    {
        operating_system_macros[operating_system_macro_count++] = S8("_WIN32");
    }
    break;
    case OPERATING_SYSTEM_UEFI:
    {
        operating_system_macros[operating_system_macro_count++] = S8("__UEFI__");
    }
    break;
    case OPERATING_SYSTEM_MACOS:
    {
        operating_system_macros[operating_system_macro_count++] = S8("__APPLE__");
        operating_system_macros[operating_system_macro_count++] = S8("__MACH__");
        operating_system_macros[operating_system_macro_count++] = S8("__BUSTER_TARGET_MACOS__");
    }
    break;
    case OPERATING_SYSTEM_IOS:
    {
        operating_system_macros[operating_system_macro_count++] = S8("__APPLE__");
        operating_system_macros[operating_system_macro_count++] = S8("__MACH__");
    }
    break;
    case OPERATING_SYSTEM_ANDROID:
    {
        operating_system_macros[operating_system_macro_count++] = S8("__ANDROID__");
        operating_system_macros[operating_system_macro_count++] = S8("__linux");
        operating_system_macros[operating_system_macro_count++] = S8("__linux__");
        operating_system_macros[operating_system_macro_count++] = S8("__unix");
        operating_system_macros[operating_system_macro_count++] = S8("__unix__");
        operating_system_macros[operating_system_macro_count++] = S8("__ELF__");
    }
    break;
    case OPERATING_SYSTEM_LINUX:
    {
        operating_system_macros[operating_system_macro_count++] = S8("__gnu_linux__");
        operating_system_macros[operating_system_macro_count++] = S8("__linux");
        operating_system_macros[operating_system_macro_count++] = S8("__linux__");
        operating_system_macros[operating_system_macro_count++] = S8("__unix");
        operating_system_macros[operating_system_macro_count++] = S8("__unix__");
        operating_system_macros[operating_system_macro_count++] = S8("__ELF__");
    }
    break;
    case OPERATING_SYSTEM_WASI:
    {
        operating_system_macros[operating_system_macro_count++] = S8("__wasi__");
        operating_system_macros[operating_system_macro_count++] = S8("__wasip1__");
    }
    break;
    case OPERATING_SYSTEM_FREESTANDING:
    case OPERATING_SYSTEM_COUNT:
    {
    }
    break;
    }
    for (u32 macro_index = 0; macro_index < operating_system_macro_count; macro_index += 1)
    {
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, operating_system_macros[macro_index], standard_replacement, 1, 0, 0, false, false);
    }
    if (options.target.os == OPERATING_SYSTEM_MACOS || options.target.os == OPERATING_SYSTEM_IOS)
    {
        c_macro_define_object_text(arena, space, symbol_table, &first_macro, &last_macro, S8("__APPLE_CC__"), S8("6000"));
    }
    String8 architecture_macro = options.target.cpu_arch == CPU_ARCH_AARCH64 ? S8("__aarch64__")
                               : options.target.cpu_arch == CPU_ARCH_WASM32  ? S8("__wasm32__")
                               : options.target.cpu_arch == CPU_ARCH_WASM64  ? S8("__wasm64__")
                               : options.target.cpu_arch == CPU_ARCH_BPFEL   ? S8("__bpfel__")
                                                                             : S8("__x86_64__");
    c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, architecture_macro, standard_replacement, 1, 0, 0, false, false);
    if (options.target.cpu_arch == CPU_ARCH_WASM32 || options.target.cpu_arch == CPU_ARCH_WASM64)
    {
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__wasm__"), standard_replacement, 1, 0, 0, false, false);
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__wasm"), standard_replacement, 1, 0, 0, false, false);
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro,
                       options.target.cpu_arch == CPU_ARCH_WASM32 ? S8("__wasm32") : S8("__wasm64"), standard_replacement, 1, 0, 0, false,
                       false);
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__wasm_mutable_globals__"), standard_replacement, 1, 0, 0, false, false);
    }
    if (options.target.cpu_arch == CPU_ARCH_WASM64)
    {
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__wasm_memory64__"), standard_replacement, 1, 0, 0, false, false);
    }
    if (options.target.cpu_arch == CPU_ARCH_BPFEL)
    {
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__bpf__"), standard_replacement, 1, 0, 0, false, false);
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__BPF__"), standard_replacement, 1, 0, 0, false, false);
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__BUSTER_EBPF__"), standard_replacement, 1, 0, 0, false, false);
    }
    if ((options.target.os == OPERATING_SYSTEM_MACOS || options.target.os == OPERATING_SYSTEM_IOS) && options.target.cpu_arch == CPU_ARCH_AARCH64)
    {
        c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__arm64__"), standard_replacement, 1, 0, 0, false, false);
    }
    // The vector-extension macros the GNU family predefines from -march, so a
    // header guarding an explicit SIMD kernel writes one condition that holds
    // for clang, gcc, and the self-hosted stages alike.  Only the features the
    // buster SIMD vocabulary can actually lower are published; announcing more
    // would invite a host header down a path this frontend cannot compile.
    for (u32 feature_index = 0; feature_index < BUSTER_ARRAY_LENGTH(c_target_feature_macros); feature_index += 1)
    {
        CTargetFeatureMacro entry = c_target_feature_macros[feature_index];
        if (entry.cpu_arch == options.target.cpu_arch && target_cpu_feature_has(options.target, entry.feature))
        {
            c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, entry.name, standard_replacement, 1, 0, 0, false, false);
        }
    }
    CToken hosted_replacement = standard_replacement[0];
    if (options.target.os == OPERATING_SYSTEM_FREESTANDING || options.target.os == OPERATING_SYSTEM_UEFI ||
        options.target.cpu_arch == CPU_ARCH_BPFEL)
    {
        hosted_replacement.offset = C_SPELLING_ZERO;
    }
    c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__STDC_HOSTED__"), &hosted_replacement, 1, 0, 0, false, false);
    c_macro_define(arena, space->base, symbol_table, &first_macro, &last_macro, S8("__STDC_VERSION__"), standard_replacement + 1, 1, 0, 0, false, false);
    CTokenStream token_stream = {
        .arena = token_arena,
        .shape_arena = token_shape_arena,
        .base = (CToken*)((char8*)token_arena + arena_minimum_position),
        .shape_base = (CTokenShape*)((char8*)token_shape_arena + arena_minimum_position),
    };
    u64 output_count = 0;
    CPragmaPackStack* pack_stack = 0;
    CMacroPushMacro* macro_push_stack = 0;
    u16 pack_alignment = 0;
    CPackAlignmentRecorder pack_changes = {
        .arena = arena,
    };
    u32 expansion_limit = options.expansion_limit ? options.expansion_limit : 65536;
    bool expansion_ok = true;
    CConditionalFrame* conditional = 0;
    CPreprocessSourceFrame root_frame = {
        .lex = root_lex,
        .class_masks = root_class_masks,
        .path = options.source_path.length ? options.source_path : S8("."),
        .identity = c_include_file_identity(options.source_path.length ? options.source_path : S8("."), (FileIdentity){0}),
        .logical_path = options.source_path.length ? options.source_path : S8("."),
        .line_start = true,
    };
    CPreprocessSourceFrame* source_frame = &root_frame;
    CPreprocessFileTable file_table = {0};
    root_frame.map_entry = map.count;
    c_source_map_append(&map, (IrSourceRegion){
                                  .start = root_lex.translated_offset,
                                  .source = c_preprocess_file_index(arena, &file_table, root_frame.logical_path),
                                  .checkpoints = root_lex.checkpoints,
                                  .checkpoint_offsets = root_lex.checkpoint_offsets,
                                  .checkpoint_pages = root_lex.checkpoint_pages,
                                  .checkpoint_page_count = root_lex.checkpoint_page_count,
                                  .checkpoint_count = root_lex.checkpoint_count,
                                  .base = root_lex.translated_offset,
                                  .kind = IR_SOURCE_REGION_TEXT,
                              });
    c_source_map_name(&map, root_frame.path, root_frame.logical_path);
    u32 include_depth_limit = options.include_depth_limit ? options.include_depth_limit : 256;
    c_preprocess_builtins(arena, symbol_table, &first_macro, &last_macro, root_frame.logical_path,
                          (CSourceLocation){.line = 1, .column = 1});
    if (!options.already_preprocessed)
    {
        c_preprocess_command_operations(arena, space, symbol_table, options, &first_macro, &last_macro, &result);
    }
    CIncludeFileTable include_files = {
        .arena = arena,
    };
    CPpStampTable stamps = {
        .arena = arena,
    };
    CPreprocessPragmaContext pragma_context = {
        .arena = arena,
        .preprocess = &result,
        .symbols = symbol_table,
        .first_macro = &first_macro,
        .last_macro = &last_macro,
        .macro_push_stack = &macro_push_stack,
        .pack_stack = &pack_stack,
        .pack_alignment = &pack_alignment,
        .pack_changes = &pack_changes,
        .include_files = &include_files,
    };
    while (source_frame)
    {
        pragma_context.current_path = source_frame->path;
        pragma_context.current_identity = source_frame->identity;
        CLexResult lex = source_frame->lex;
        CPpClassMasks const* class_masks = &source_frame->class_masks;
        u64 token_index = source_frame->token_index;
        bool line_start = source_frame->line_start;
        CToken token = lex.tokens[token_index];
        if (token.kind == C_TOKEN_END_OF_FILE)
        {
            while (conditional != source_frame->conditional_base)
            {
                c_preprocess_diagnostic_push(arena, &result, conditional->location, C_DIAGNOSTIC_UNMATCHED_CONDITIONAL, S8("unterminated preprocessing conditional"));
                conditional = conditional->previous;
            }
            if (source_frame != &root_frame)
            {
                if (source_frame->guard_state == C_INCLUDE_GUARD_CLOSED)
                {
                    CIncludeFileEntry* entry = 0;
                    CIncludeFileStatus status =
                        c_include_file_entry(&include_files, source_frame->identity, source_frame->path, &entry);
                    if (status == C_INCLUDE_FILE_OK)
                    {
                        entry->guard_symbol = source_frame->guard_symbol;
                    }
                    else
                    {
                        CSourceLocation location = c_preprocess_logical_location(source_frame, c_lex_token_location(&source_frame->lex, token));
                        c_include_file_diagnostic(arena, &result, location, status, source_frame->path);
                    }
                }
                file_map_unmap(source_frame->source_map);
            }
            source_frame = source_frame->previous;
            continue;
        }
        if (token.kind == C_TOKEN_NEWLINE)
        {
            source_frame->line_start = true;
            source_frame->token_index += 1;
            continue;
        }
        first_macro->builtin_frame = source_frame;
        first_macro->builtin_token_offset = token.offset;
        first_macro->builtin_path = source_frame->logical_path;
        if (line_start && c_token_is_punctuator(&token, C_PUNCTUATOR_HASH))
        {
            CPreprocessSourceFrame* include_frame = 0;
            token_index += 1;
            bool is_line_marker = token_index < lex.token_count && lex.tokens[token_index].kind == C_TOKEN_PREPROCESSING_NUMBER;
            if (token_index >= lex.token_count || (lex.tokens[token_index].kind != C_TOKEN_IDENTIFIER && !is_line_marker))
            {
                // A null directive is valid even in an inactive group and
                // at EOF. It emits nothing; punctuation such as '#+' remains
                // an invalid directive rather than an assembly comment.
                bool null_directive = token_index < lex.token_count &&
                                      (lex.tokens[token_index].kind == C_TOKEN_NEWLINE || lex.tokens[token_index].kind == C_TOKEN_END_OF_FILE);
                if (!null_directive && !options.assembly_comment_lines && !options.already_preprocessed)
                {
                    c_preprocess_diagnostic_push(arena, &result, c_lex_token_location(&source_frame->lex, token), C_DIAGNOSTIC_EXPECTED_DIRECTIVE,
                                                 S8("expected preprocessing directive after '#'"));
                }
            }
            else
            {
                CToken directive = lex.tokens[token_index];
                if (!is_line_marker)
                {
                    token_index += 1;
                }
                u32 physical_directive_line = c_lex_token_location(&source_frame->lex, directive).line;
                CSourceLocation directive_location = c_preprocess_logical_location(source_frame, c_lex_token_location(&source_frame->lex, directive));
                u64 line_end = class_masks->word_count ? c_pp_line_end_masked(class_masks, lex.token_count, token_index) : c_preprocess_line_end(lex, token_index);
                bool active = c_preprocess_is_active(conditional);
                char8 const* base = space->base;
                bool is_if = c_token_spelling_equal(base, directive, S8("if"));
                bool is_ifdef = c_token_spelling_equal(base, directive, S8("ifdef"));
                bool is_ifndef = c_token_spelling_equal(base, directive, S8("ifndef"));
                bool is_elif = c_token_spelling_equal(base, directive, S8("elif"));
                bool is_else = c_token_spelling_equal(base, directive, S8("else"));
                bool is_endif = c_token_spelling_equal(base, directive, S8("endif"));
                bool is_include = c_token_spelling_equal(base, directive, S8("include"));
                bool is_include_next = c_token_spelling_equal(base, directive, S8("include_next"));
                bool is_import = c_token_spelling_equal(base, directive, S8("import"));
                bool is_line = is_line_marker || c_token_spelling_equal(base, directive, S8("line"));
                bool is_pragma = c_token_spelling_equal(base, directive, S8("pragma"));
                bool is_error = c_token_spelling_equal(base, directive, S8("error"));
                bool is_warning = c_token_spelling_equal(base, directive, S8("warning"));
                CPreprocessConditionalDirective conditional_directive = c_preprocess_conditional_directive_kind(base, directive);
                // Any directive at the frame's top level other than the
                // conditionals themselves sits outside a candidate include
                // guard, so the file cannot be guard-shaped.
                if (!(is_if || is_ifdef || is_ifndef || is_elif || is_else || is_endif) && conditional == source_frame->conditional_base)
                {
                    source_frame->guard_state = C_INCLUDE_GUARD_DISQUALIFIED;
                }
                if (options.already_preprocessed && !is_line && !is_pragma)
                {
                    // A cpp-output stream has already resolved conditionals,
                    // definitions, includes and diagnostics. Unknown or stale
                    // directive lines are tokenizer metadata here, not a
                    // second preprocessing program.
                }
                else if (is_if || is_ifdef || is_ifndef)
                {
                    c_preprocess_conditional_directive(arena, space, symbol_table, first_macro, &stamps, source_frame, conditional_directive,
                                                       directive, token_index, line_end, expansion_limit, &result, options, &conditional);
                }
                else if (is_elif)
                {
                    c_preprocess_conditional_directive(arena, space, symbol_table, first_macro, &stamps, source_frame, conditional_directive,
                                                       directive, token_index, line_end, expansion_limit, &result, options, &conditional);
                }
                else if (is_else)
                {
                    c_preprocess_conditional_directive(arena, space, symbol_table, first_macro, &stamps, source_frame, conditional_directive,
                                                       directive, token_index, line_end, expansion_limit, &result, options, &conditional);
                }
                else if (is_endif)
                {
                    c_preprocess_conditional_directive(arena, space, symbol_table, first_macro, &stamps, source_frame, conditional_directive,
                                                       directive, token_index, line_end, expansion_limit, &result, options, &conditional);
                }
                else if (active && (is_error || is_warning))
                {
                    c_preprocess_diagnostic_push_severity(arena, &result, directive_location,
                                                           is_error ? C_DIAGNOSTIC_PREPROCESSOR_ERROR : C_DIAGNOSTIC_PREPROCESSOR_WARNING,
                                                           is_error ? C_DIAGNOSTIC_ERROR : C_DIAGNOSTIC_WARNING,
                                                           c_preprocess_message_from_tokens(arena, base, lex.tokens + token_index,
                                                                                            (u32)(line_end - token_index)));
                }
                else if (active && is_line)
                {
                    u64 line_token_count = line_end - token_index;
                    CToken* line_tokens = lex.tokens + token_index;
                    bool line_expanded = true;
                    if (!options.already_preprocessed)
                    {
                        CPreprocessTokenNode* first_line = 0;
                        CPreprocessTokenNode* last_line = 0;
                        line_token_count = 0;
                        line_expanded = c_preprocess_expand(arena, space, symbol_table, first_macro, 0, 0, &stamps,
                                                            c_frame_wrap_tokens(arena, &stamps, source_frame, token_index, line_end),
                                                            (u32)(line_end - token_index), &first_line, &last_line, &line_token_count,
                                                            expansion_limit, &result);
                        line_tokens = arena_allocate(arena, CToken, line_token_count);
                        u32 line_index = 0;
                        for (CPreprocessTokenNode* node = first_line; node; node = node->next)
                        {
                            line_tokens[line_index++] = node->token.token;
                        }
                    }
                    u64 requested_line = 0;
                    bool has_file_name = line_token_count >= 2 && line_tokens[1].kind == C_TOKEN_STRING_LITERAL && line_tokens[1].length >= 2;
                    bool valid_line = line_expanded && line_token_count >= 1 && line_tokens[0].kind == C_TOKEN_PREPROCESSING_NUMBER &&
                                      c_conditional_number(c_token_spelling(base, line_tokens[0]), &requested_line) && requested_line >= 1 &&
                                      requested_line <= UINT32_MAX &&
                                      ((!is_line_marker && (line_token_count == 1 || (line_token_count == 2 && has_file_name))) ||
                                       (is_line_marker && (line_token_count == 1 || has_file_name)));
                    if (valid_line && is_line_marker && line_token_count > 2)
                    {
                        for (u32 flag_index = 2; flag_index < line_token_count; flag_index += 1)
                        {
                            u64 flag = 0;
                            valid_line &= line_tokens[flag_index].kind == C_TOKEN_PREPROCESSING_NUMBER &&
                                          c_conditional_number(c_token_spelling(base, line_tokens[flag_index]), &flag) && flag >= 1 && flag <= 4;
                        }
                    }
                    if (!valid_line)
                    {
                        c_preprocess_diagnostic_push(arena, &result, directive_location, C_DIAGNOSTIC_INVALID_LINE,
                                                     S8("expected '#line' followed by a positive line number and optional file name"));
                    }
                    else
                    {
                        source_frame->line_delta = (s64)requested_line - ((s64)physical_directive_line + 1);
                        if (has_file_name)
                        {
                            String8 name_spelling = c_token_spelling(base, line_tokens[1]);
                            source_frame->logical_path = (String8){
                                .pointer = name_spelling.pointer + 1,
                                .length = name_spelling.length - 2,
                            };
                        }
                        // The region after the directive maps through the new
                        // delta and logical file; entries partition the file's
                        // span by offset, so the split is one append.
                        source_frame->map_entry = map.count;
                        c_source_map_append(&map, (IrSourceRegion){
                                                      .start = lex.tokens[line_end].offset,
                                                      .source = UINT32_MAX,
                                                      .checkpoints = source_frame->lex.checkpoints,
                                                      .checkpoint_offsets = source_frame->lex.checkpoint_offsets,
                                                      .checkpoint_pages = source_frame->lex.checkpoint_pages,
                                                      .checkpoint_page_count = source_frame->lex.checkpoint_page_count,
                                                      .checkpoint_count = source_frame->lex.checkpoint_count,
                                                      .base = source_frame->lex.translated_offset,
                                                      .line_delta = source_frame->line_delta,
                                                      .kind = IR_SOURCE_REGION_TEXT,
                                                  });
                        c_source_map_name(&map, source_frame->path, source_frame->logical_path);
                    }
                }
                else if (active && c_token_spelling_equal(base, directive, S8("define")))
                {
                    c_preprocess_define_directive(arena, symbol_table, lex, &token_index, &first_macro, &last_macro, &result, directive_location,
                                                  UINT32_MAX, UINT32_MAX);
                    // Directives reached, not macros surviving: a header
                    // included twice defines its macros twice.
                    result.detail->preprocessed.definitions += 1;
                }
                else if (active && c_token_spelling_equal(base, directive, S8("undef")))
                {
                    c_preprocess_undefine_directive(arena, symbol_table, lex, &token_index, first_macro, &result, directive_location, UINT32_MAX,
                                                    UINT32_MAX, false);
                }
                else if (active && (is_include || is_include_next || is_import))
                {
                    CPreprocessTokenNode* first_include = 0;
                    CPreprocessTokenNode* last_include = 0;
                    u64 include_token_count = 0;
                    String8 include_name = {0};
                    bool quoted = false;
                    u32 raw_include_count = (u32)(line_end - token_index);
                    bool include_expanded = c_include_name(arena, base, lex.tokens + token_index, raw_include_count, &include_name, &quoted);
                    if (!include_expanded)
                    {
                        include_expanded = c_preprocess_expand(arena, space, symbol_table, first_macro, 0, 0, &stamps,
                                                               c_frame_wrap_tokens(arena, &stamps, source_frame, token_index, line_end), raw_include_count,
                                                               &first_include, &last_include, &include_token_count, expansion_limit, &result);
                        CToken* include_tokens = arena_allocate(arena, CToken, include_token_count);
                        u32 include_index = 0;
                        for (CPreprocessTokenNode* node = first_include; node; node = node->next)
                        {
                            include_tokens[include_index++] = node->token.token;
                        }
                        include_expanded = include_expanded && c_include_name(arena, base, include_tokens, include_index, &include_name, &quoted);
                    }
                    if (!include_expanded)
                    {
                            c_preprocess_diagnostic_push(arena, &result, directive_location, C_DIAGNOSTIC_INVALID_INCLUDE,
                                                     S8("expected a quoted or angle-bracket header name"));
                    }
                    else if (source_frame->depth >= include_depth_limit)
                    {
                        c_preprocess_diagnostic_push(arena, &result, directive_location, C_DIAGNOSTIC_INCLUDE_DEPTH, S8("preprocessor include depth limit exceeded"));
                    }
                    else
                    {
                        String8 include_path = {0};
                        String8 include_source = {0};
                        FileMapRead include_source_map = {0};
                        CIncludeSearchOrigin include_origin = {0};
                        bool include_resolved =
                            is_include_next ? c_include_resolve_next(arena, options, include_name, &include_path, &include_source, &include_source_map,
                                                                      source_frame->include_origin, &include_origin)
                                            : c_include_resolve(arena, options, source_frame->path, include_name, quoted, &include_path, &include_source,
                                                                &include_source_map, &include_origin);
                        if (!include_resolved)
                        {
                            c_preprocess_diagnostic_push(arena, &result, directive_location, C_DIAGNOSTIC_INCLUDE_NOT_FOUND,
                                                         string_format(arena, S8("included file was not found: {S8}"), include_name));
                        }
                        else
                        {
                            // Identity comes from the descriptor that supplied
                            // these bytes; the resolved spelling remains separate for
                            // diagnostics, source maps and per-path attribution.
                            CIncludeFileIdentity include_identity = c_include_file_identity(include_path, include_source_map.identity);
                            CIncludeFileEntry* include_file = 0;
                            CIncludeFileStatus include_file_status =
                                c_include_file_entry(&include_files, include_identity, include_path, &include_file);
                            if (include_file_status != C_INCLUDE_FILE_OK)
                            {
                                c_include_file_diagnostic(arena, &result, directive_location, include_file_status, include_path);
                                file_map_unmap(include_source_map);
                            }
                            else
                            {
                                bool include_once = include_file->once;
                                if (is_import)
                                {
                                    // Mark before descending so a recursive
                                    // #import of this identity is suppressed.
                                    include_file->once = true;
                                }
                                if (!include_once)
                                {
                                    // The multiple-include optimization: a file
                                    // that proved the whole-file guard shape on
                                    // an earlier lex produces no tokens while
                                    // its guard macro is defined, so it shares
                                    // the same identity lookup as once files.
                                    u32 guard_symbol = include_file->guard_symbol;
                                    CMacro* guard_macro = guard_symbol ? c_macro_find(first_macro, guard_symbol) : 0;
                                    include_once = guard_macro && guard_macro->definition.defined;
                                }
                                CLexResult include_lex = include_once ? (CLexResult){0} : c_lex_space(arena, space, include_source);
                                // A suppressed include lexed nothing and adds
                                // zeroes; its path was already counted by the
                                // inclusion that did the lexing, and its
                                // attribution row keeps that lex count.
                                c_source_metrics_add(&result.detail->source_lexed, &include_lex.metrics);
                                u32 include_row = c_source_metrics_file_row(arena, &metrics_files, include_path);
                                if (metrics_files.rows[include_row].lex_count == 0)
                                {
                                    c_source_metrics_add(&result.detail->source_unique, &include_lex.metrics);
                                }
                                if (!include_once)
                                {
                                    metrics_files.rows[include_row].translated_bytes = include_lex.metrics.translated_bytes;
                                    metrics_files.rows[include_row].lex_count += 1;
                                }
                                c_symbols_intern_tokens(symbol_table, include_lex.spelling_base, include_lex.tokens, include_lex.token_shapes, include_lex.token_count);
                                CPpClassMasks include_class_masks;
                                c_pp_class_masks_build(arena, &include_class_masks, include_lex.token_shapes, include_lex.token_count);
                                for (u64 index = 0; index < include_lex.diagnostic_count; index += 1)
                                {
                                    CDiagnostic diagnostic = include_lex.diagnostics[index];
                                    c_preprocess_diagnostic_copy(arena, &result, diagnostic);
                                }
                                if (!include_once)
                                {
                                    include_frame = arena_allocate(arena, CPreprocessSourceFrame, 1);
                                    *include_frame = (CPreprocessSourceFrame){
                                        .previous = source_frame,
                                        .conditional_base = conditional,
                                        .lex = include_lex,
                                        .class_masks = include_class_masks,
                                        .path = include_path,
                                        .identity = include_identity,
                                        .logical_path = include_path,
                                        .source_map = include_source_map,
                                        .depth = source_frame->depth + 1,
                                        .line_start = true,
                                        .include_origin = include_origin,
                                    };
                                    include_frame->map_entry = map.count;
                                    c_source_map_append(&map, (IrSourceRegion){
                                                                  .start = include_lex.translated_offset,
                                                                  .source = UINT32_MAX,
                                                                  .checkpoints = include_lex.checkpoints,
                                                                  .checkpoint_offsets = include_lex.checkpoint_offsets,
                                                                  .checkpoint_pages = include_lex.checkpoint_pages,
                                                                  .checkpoint_page_count = include_lex.checkpoint_page_count,
                                                                  .checkpoint_count = include_lex.checkpoint_count,
                                                                  .base = include_lex.translated_offset,
                                                                  .kind = IR_SOURCE_REGION_TEXT,
                                                              });
                                    c_source_map_name(&map, include_path, include_path);
                                }
                                else
                                {
                                    file_map_unmap(include_source_map);
                                }
                            }
                        }
                    }
                }
                else if (active && is_pragma)
                {
                    bool pragma_expanded = true;
                    CToken* pragma_tokens = lex.tokens + token_index;
                    u32 expanded_pragma_count = (u32)(line_end - token_index);
                    if (!options.already_preprocessed)
                    {
                        CPreprocessTokenNode* first_pragma = 0;
                        CPreprocessTokenNode* last_pragma = 0;
                        u64 pragma_token_count = 0;
                        pragma_expanded = c_preprocess_expand(arena, space, symbol_table, first_macro, 0, 0, &stamps,
                                                              c_frame_wrap_tokens(arena, &stamps, source_frame, token_index, line_end),
                                                              (u32)(line_end - token_index), &first_pragma, &last_pragma, &pragma_token_count,
                                                              expansion_limit, &result);
                        expanded_pragma_count = c_preprocess_tokens_from_nodes(first_pragma, arena, &pragma_tokens);
                    }
                    if (pragma_expanded)
                    {
                        pragma_context.current_location = directive_location;
                        c_preprocess_handle_pragma(pragma_context, base, pragma_tokens, expanded_pragma_count);
                    }
                }
                else if (active && !options.assembly_comment_lines)
                {
                    c_preprocess_diagnostic_push(arena, &result, directive_location, C_DIAGNOSTIC_UNSUPPORTED_DIRECTIVE,
                                                 string_format(arena, S8("{S8}: preprocessing directive is not implemented yet: {S8}"), source_frame->path,
                                                               c_token_spelling(base, directive)));
                }
            }
            while (token_index < lex.token_count && lex.tokens[token_index].kind != C_TOKEN_NEWLINE && lex.tokens[token_index].kind != C_TOKEN_END_OF_FILE)
            {
                token_index += 1;
            }
            source_frame->token_index = token_index;
            source_frame->line_start = true;
            if (include_frame)
            {
                source_frame = include_frame;
            }
            continue;
        }
        source_frame->line_start = false;
        // A token line at the frame's top level sits outside any candidate
        // include guard, so tokens would survive a re-include.
        if (conditional == source_frame->conditional_base)
        {
            source_frame->guard_state = C_INCLUDE_GUARD_DISQUALIFIED;
        }
        bool classified = class_masks->word_count != 0;
        u64 line_end = classified ? c_pp_line_end_masked(class_masks, lex.token_count, token_index) : c_preprocess_line_end(lex, token_index);
        if (!c_preprocess_is_active(conditional))
        {
            source_frame->token_index = line_end;
            continue;
        }
        u64 logical_end = line_end;
        u32 parenthesis_depth = 0;
        bool source_conditionals = false;
        CPreprocessSourceSegment* first_segment = 0;
        CPreprocessSourceSegment* last_segment = 0;
        if (!options.already_preprocessed)
        {
            if (classified)
            {
                parenthesis_depth = c_pp_parenthesis_depth(class_masks, token_index, logical_end, 0);
            }
            else
            {
                for (u64 scan = token_index; scan < logical_end; scan += 1)
                {
                    if (c_token_is_punctuator(&lex.tokens[scan], C_PUNCTUATOR_LEFT_PARENTHESIS))
                    {
                        parenthesis_depth += 1;
                    }
                    else if (c_token_is_punctuator(&lex.tokens[scan], C_PUNCTUATOR_RIGHT_PARENTHESIS) && parenthesis_depth)
                    {
                        parenthesis_depth -= 1;
                    }
                }
            }
        }
        while (parenthesis_depth && logical_end < lex.token_count && lex.tokens[logical_end].kind == C_TOKEN_NEWLINE)
        {
            u64 next_line_start = logical_end + 1;
            if (next_line_start < lex.token_count && c_token_is_punctuator(&lex.tokens[next_line_start], C_PUNCTUATOR_HASH))
            {
                u64 directive_index = next_line_start + 1;
                if (directive_index >= lex.token_count || lex.tokens[directive_index].kind != C_TOKEN_IDENTIFIER)
                {
                    break;
                }
                CToken directive = lex.tokens[directive_index];
                CPreprocessConditionalDirective directive_kind = c_preprocess_conditional_directive_kind(space->base, directive);
                if (directive_kind == C_PREPROCESS_CONDITIONAL_COUNT)
                {
                    if (!c_preprocess_is_active(conditional))
                    {
                        directive_index += 1;
                        logical_end = classified ? c_pp_line_end_masked(class_masks, lex.token_count, directive_index)
                                                 : c_preprocess_line_end(lex, directive_index);
                        continue;
                    }
                    break;
                }
                if (!source_conditionals)
                {
                    c_preprocess_source_segment_append(arena, &first_segment, &last_segment, token_index, logical_end);
                    source_conditionals = true;
                }
                directive_index += 1;
                u64 directive_end = classified ? c_pp_line_end_masked(class_masks, lex.token_count, directive_index)
                                               : c_preprocess_line_end(lex, directive_index);
                first_macro->builtin_token_offset = directive.offset;
                c_preprocess_conditional_directive(arena, space, symbol_table, first_macro, &stamps, source_frame, directive_kind, directive,
                                                   directive_index, directive_end, expansion_limit, &result, options, &conditional);
                first_macro->builtin_token_offset = token.offset;
                logical_end = directive_end;
                continue;
            }
            u64 next_line_end = classified ? c_pp_line_end_masked(class_masks, lex.token_count, next_line_start)
                                           : c_preprocess_line_end(lex, next_line_start);
            if (c_preprocess_is_active(conditional))
            {
                if (conditional == source_frame->conditional_base)
                {
                    source_frame->guard_state = C_INCLUDE_GUARD_DISQUALIFIED;
                }
                if (source_conditionals)
                {
                    c_preprocess_source_segment_append(arena, &first_segment, &last_segment, next_line_start, next_line_end);
                }
                if (classified)
                {
                    parenthesis_depth = c_pp_parenthesis_depth(class_masks, next_line_start, next_line_end, parenthesis_depth);
                }
                else
                {
                    for (u64 scan = next_line_start; scan < next_line_end; scan += 1)
                    {
                        if (c_token_is_punctuator(&lex.tokens[scan], C_PUNCTUATOR_LEFT_PARENTHESIS))
                        {
                            parenthesis_depth += 1;
                        }
                        else if (c_token_is_punctuator(&lex.tokens[scan], C_PUNCTUATOR_RIGHT_PARENTHESIS) && parenthesis_depth)
                        {
                            parenthesis_depth -= 1;
                        }
                    }
                }
            }
            logical_end = next_line_end;
        }
        if (source_conditionals && logical_end < lex.token_count && lex.tokens[logical_end].kind == C_TOKEN_END_OF_FILE)
        {
            while (conditional != source_frame->conditional_base)
            {
                c_preprocess_diagnostic_push(arena, &result, conditional->location, C_DIAGNOSTIC_UNMATCHED_CONDITIONAL,
                                             S8("unterminated preprocessing conditional"));
                conditional = conditional->previous;
            }
        }
        // A line whose identifiers name no defined macro expands to itself,
        // so its lexed tokens stream straight to the output with the
        // newlines stripped and the expansion machinery (a task node and an
        // output node per token) is skipped. Locations are not materialized
        // at all on this path: the file's source-map entry recovers them
        // from the offsets on demand.
        bool needs_expansion = false;
        if (source_conditionals)
        {
            needs_expansion = true;
        }
        else if (classified && !options.already_preprocessed)
        {
            u64 last_word = (logical_end - 1) / C_PP_CLASS_MASK_WINDOW;
            for (u64 word_index = token_index / C_PP_CLASS_MASK_WINDOW; word_index <= last_word && !needs_expansion; word_index += 1)
            {
                Mask64 names = mask64_and(class_masks->identifier[word_index], c_pp_class_range_mask(word_index, token_index, logical_end));
                while (names && !needs_expansion)
                {
                    u64 scan = word_index * C_PP_CLASS_MASK_WINDOW + mask64_first_set(names);
                    CMacro* line_macro = c_macro_find_token(first_macro, symbol_table, space->base, &lex.tokens[scan]);
                    needs_expansion = line_macro && line_macro->definition.defined;
                    names = mask64_and(names, names - 1);
                }
            }
        }
        else if (!options.already_preprocessed)
        {
            for (u64 scan = token_index; scan < logical_end && !needs_expansion; scan += 1)
            {
                if (lex.tokens[scan].kind == C_TOKEN_IDENTIFIER)
                {
                    CMacro* line_macro = c_macro_find_token(first_macro, symbol_table, space->base, &lex.tokens[scan]);
                    needs_expansion = line_macro && line_macro->definition.defined;
                }
            }
        }
        // The line holds at least one token: this path is only entered on a
        // token that is neither a newline nor the end of the file.
        if (map.regions[source_frame->map_entry].source == UINT32_MAX)
        {
            map.regions[source_frame->map_entry].source = c_preprocess_file_index(arena, &file_table, source_frame->logical_path);
        }
        if (!needs_expansion)
        {
            // Pragmas cannot fire inside a text line on this path (only
            // directive lines and _Pragma markers change pack state), so
            // one sample covers the whole batch.
            c_pack_alignment_record(&pack_changes, output_count, pack_alignment);
            CTokenShape* line_shapes = 0;
            CToken* line_output = c_token_stream_reserve(&token_stream, logical_end - token_index, &line_shapes);
            u64 written = 0;
            for (u64 scan = token_index; scan < logical_end;)
            {
                u64 segment_start = scan;
                if (classified)
                {
                    scan = BUSTER_MIN(c_pp_line_end_masked(class_masks, lex.token_count, scan), logical_end);
                }
                else
                {
                    while (scan < logical_end && lex.tokens[scan].kind != C_TOKEN_NEWLINE)
                    {
                        scan += 1;
                    }
                }
                u64 segment_count = scan - segment_start;
                if (segment_count)
                {
                    memcpy(line_output + written, lex.tokens + segment_start, segment_count * sizeof(*line_output));
                    if (lex.token_shapes)
                    {
                        memcpy(line_shapes + written, lex.token_shapes + segment_start, segment_count * sizeof(*line_shapes));
                    }
                    else
                    {
                        for (u64 segment_index = 0; segment_index < segment_count; segment_index += 1)
                        {
                            line_shapes[written + segment_index] = c_token_shape_from_token(line_output[written + segment_index]);
                        }
                    }
                    written += segment_count;
                }
                if (scan < logical_end)
                {
                    scan += 1;
                }
            }
            c_token_stream_shrink(&token_stream, (logical_end - token_index) - written);
            output_count += written;
        }
        else
        {
            u32 token_file = c_preprocess_file_index(arena, &file_table, source_frame->logical_path);
            u64 wrapped_capacity = logical_end - token_index;
            CPpToken* wrapped_tokens = arena_allocate(arena, CPpToken, wrapped_capacity);
            u32 wrapped_count = 0;
            stamps.count = 0;
            if (source_conditionals)
            {
                for (CPreprocessSourceSegment* segment = first_segment; segment; segment = segment->next)
                {
                    for (u64 scan = segment->first; scan < segment->end; scan += 1)
                    {
                        if (lex.tokens[scan].kind != C_TOKEN_NEWLINE)
                        {
                            wrapped_tokens[wrapped_count] = (CPpToken){
                                .token = lex.tokens[scan],
                            };
                            wrapped_count += 1;
                        }
                    }
                }
            }
            else if (classified)
            {
                // Wrapping runs of tokens between the line's newlines, the
                // same segments the fast path copies, so the newline test is
                // one mask lookup per segment instead of one per token.
                for (u64 scan = token_index; scan < logical_end;)
                {
                    u64 segment_end = BUSTER_MIN(c_pp_line_end_masked(class_masks, lex.token_count, scan), logical_end);
                    for (; scan < segment_end; scan += 1)
                    {
                        // Unstamped: an invocation recovers its own location
                        // through the frame (c_preprocess_recover_location).
                        wrapped_tokens[wrapped_count] = (CPpToken){
                            .token = lex.tokens[scan],
                        };
                        wrapped_count += 1;
                    }
                    scan += 1;
                }
            }
            else
            {
                for (u64 scan = token_index; scan < logical_end; scan += 1)
                {
                    if (lex.tokens[scan].kind != C_TOKEN_NEWLINE)
                    {
                        wrapped_tokens[wrapped_count] = (CPpToken){
                            .token = lex.tokens[scan],
                        };
                        wrapped_count += 1;
                    }
                }
            }
            CPreprocessTokenNode* first_line = 0;
            CPreprocessTokenNode* last_line = 0;
            u64 line_output_count = 0;
            expansion_ok = c_preprocess_expand(arena, space, symbol_table, first_macro, source_frame, token_file, &stamps, wrapped_tokens, wrapped_count, &first_line, &last_line,
                                               &line_output_count, expansion_limit, &result);
            if (expansion_ok)
            {
                c_preprocess_process_expanded_line(pragma_context, space, &map, &stamps, first_line, line_output_count, &token_stream, &output_count);
            }
        }
        source_frame->token_index = logical_end;
        if (!expansion_ok)
        {
            break;
        }
    }
    CTokenShape* end_of_file_shape = 0;
    CToken* end_of_file = c_token_stream_reserve(&token_stream, 1, &end_of_file_shape);
    *end_of_file = (CToken){
        .offset = root_lex.tokens[root_lex.token_count - 1].offset,
        .kind = C_TOKEN_END_OF_FILE,
    };
    end_of_file_shape[0] = c_token_shape_from_token(*end_of_file);
    result.tokens = token_stream.base;
    recovery->token_shapes = token_stream.shape_base;
    result.token_count = output_count + 1;
    result.pack_changes = pack_changes.changes;
    result.pack_change_count = pack_changes.count;
    // The stream is contiguous, so the spellings sum in one linear pass
    // rather than one add per token as the lines were appended.
    result.detail->preprocessed.tokens = output_count;
    {
        // The accumulator and both bases are locals on purpose. c_token_length
        // keeps a call in its oversized arm, so a member accumulator has to be
        // reloaded and stored once per token against that call's possible
        // writes, and the stream and spelling bases with it: three extra memory
        // operations per token over a stream that is already the largest cold
        // read of the phase.
        char8 const* spelling_base = space->base;
        CToken const* stream = result.tokens;
        u64 spelled_bytes = 0;
        for (u64 token_index = 0; token_index < output_count; token_index += 1)
        {
            spelled_bytes += c_token_length(spelling_base, stream[token_index]);
        }
        result.detail->preprocessed.bytes += spelled_bytes;
    }
    result.detail->preprocessed.spelling_bytes = space->used;
    result.detail->lexed_files = metrics_files.rows;
    result.detail->lexed_file_count = metrics_files.count;
#if BUSTER_INCLUDE_TESTS
    result.detail->include_file_probe_count = include_files.probe_count;
#endif
    // Origin recovery and publication both require the stable key order.
    c_source_map_sort(arena, map.regions, map.count);
    c_source_map_finish_origins(arena, &map, &file_table, &result);
    result.files = file_table.files;
    result.file_count = file_table.count;
    c_source_map_publish(arena, recovery, &map);
    // Respelling queries the published prefix and may append regions (moving
    // their backing array). Rebuild keys only for that appended tail; without
    // it, a second publication would retain an identical key array in the TU.
    c_preprocess_respell_c23(space, &map, &result);
    c_source_map_publish_appended(arena, recovery, &map);
    u32 page_count = (u32)((space->used >> IR_SOURCE_MAP_PAGE_SHIFT) + 1);
    u32* pages = arena_allocate(arena, u32, page_count);
    u32 fill_entry = 0;
    for (u32 page = 0; page < page_count; page += 1)
    {
        u32 page_start = page << IR_SOURCE_MAP_PAGE_SHIFT;
        while (fill_entry + 1 < map.count && map.regions[fill_entry + 1].start <= page_start)
        {
            fill_entry += 1;
        }
        pages[page] = fill_entry;
    }
    recovery->map.pages = pages;
    recovery->map.page_count = page_count;
    for (u64 index = 0; index < result.diagnostic_count; index += 1)
    {
        CDiagnostic* diagnostic = result.diagnostics + index;
        IrSourcePosition position = ir_source_map_position(&recovery->map, diagnostic->location.map_offset, 0);
        if (position.line)
        {
            diagnostic->location = c_source_location_from_position(diagnostic->location.map_offset, position);
        }
    }
    return result;
}

BUSTER_C_SHARED bool c_parse_auto_type_word(String8 spelling)
{
    return string_equal(spelling, S8("__auto_type"));
}

// The keyword set is probed once per identifier from several parser scan
// loops, so it is a hashed set built once from the spellings table rather
// than a linear walk that re-derived every keyword's length per query.

BUSTER_C_SHARED u8 c_declaration_keyword_slots[C_DECLARATION_KEYWORD_SLOT_COUNT];
BUSTER_C_SHARED bool c_declaration_keyword_slots_built;

BUSTER_C_SHARED void c_declaration_keyword_slots_build(void)
{
    BUSTER_CHECK_SERIAL_INITIALIZATION();
    for (u32 keyword_index = 0; keyword_index < BUSTER_ARRAY_LENGTH(c_declaration_keyword_spellings); keyword_index += 1)
    {
        u32 slot = (u32)(c_macro_name_hash(c_declaration_keyword_spellings[keyword_index]) & (C_DECLARATION_KEYWORD_SLOT_COUNT - 1));
        while (c_declaration_keyword_slots[slot])
        {
            slot = (slot + 1) & (C_DECLARATION_KEYWORD_SLOT_COUNT - 1);
        }
        c_declaration_keyword_slots[slot] = (u8)(keyword_index + 1);
    }
    c_declaration_keyword_slots_built = true;
}

// Every C frontend table that is built on first use is filled here on the
// calling thread. The character-class tables remain runtime-derived because
// spelling their predicates through the preprocessor measurably inflates the
// frontend translation unit.
void c_prewarm(void)
{
#if BUSTER_C_LEX_COMPACT
    if (!c_lex_compact_tables_built)
    {
        c_lex_compact_tables_build();
    }
#endif
    if (!c_identifier_continue_table_built)
    {
        c_identifier_continue_table_build();
    }
    if (!c_literal_plain_table_built)
    {
        c_literal_plain_table_build();
    }
    if (!c_punctuator_dispatch_built)
    {
        c_punctuator_dispatch_build();
    }
    if (!c_declaration_keyword_slots_built)
    {
        c_declaration_keyword_slots_build();
    }
}

#if !BUSTER_UNITY_BUILD
String8 c_token_kind_name(CTokenKind kind)
{
    switch (kind)
    {
    case C_TOKEN_INVALID:
        return S8("invalid");
    case C_TOKEN_END_OF_FILE:
        return S8("end of file");
    case C_TOKEN_IDENTIFIER:
        return S8("identifier");
    case C_TOKEN_PREPROCESSING_NUMBER:
        return S8("preprocessing number");
    case C_TOKEN_CHARACTER_LITERAL:
        return S8("character literal");
    case C_TOKEN_STRING_LITERAL:
        return S8("string literal");
    case C_TOKEN_PUNCTUATOR:
        return S8("punctuator");
    case C_TOKEN_NEWLINE:
        return S8("newline");
    case C_TOKEN_PRAGMA:
        return S8("pragma");
    case C_TOKEN_KIND_COUNT:
        return S8("invalid token kind");
    }
    return S8("invalid token kind");
}
#endif
