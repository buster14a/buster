// Machine backend regressions: instruction metadata, selection, allocation,
// CFG/parameter-edge remapping, scheduling and native ABI execution.
// machine_tests is the module entry; machine_test_parameter_edge_split owns
// the bounded linear remapping oracle and large-fanout structural controls.
// machine_test_a64_atomic_pair_updates pins pair-update payloads, clobbers,
// both frontend forms, small/large frame expansion and the direct CAS oracle.
// machine_test_a64_large_aggregate_copy covers pointer/frame copies beyond imm12.
// machine_test_sparse_local_state compares sparse and row-based local discovery.

#include <buster/tests/compiler/codegen/machine_test.h>
#if BUSTER_INCLUDE_TESTS

#include <buster/lib/compiler/assembly/aarch64_encoding.h>
#include <buster/lib/compiler/assembly/assembly.h>
#include <buster/lib/compiler/codegen/codegen.h>
#include <buster/lib/compiler/codegen/machine_x86_64_emit_registry.h>
#include <buster/lib/compiler/codegen/machine_x86_64_internal.h>
#include <buster/lib/compiler/codegen/machine_schedule_internal.h>
#include <buster/lib/compiler/codegen/register_allocator_fast_internal.h>
#include <buster/lib/compiler/codegen/register_allocator_quality_internal.h>
#include <buster/lib/compiler/frontend/c/c.h>
#include <buster/lib/file.h>
#include <buster/lib/compiler/ir/ir.h>
#include <buster/lib/simd.h>
#include <buster/lib/string.h>
#include <buster/lib/time.h>
#include <buster/lib/x86_64.h>

// Size census for the hot records the register-allocator project depends
// on. The machine rows are all-integer and hold everywhere; the typed IR and
// codegen records carry pointers, so their checks apply to 64-bit builds
// only. A designed size change must update these checks in the same change —
// they exist so design documents can never drift from the code the way the
// historical IrInstructionExtra comment did.
BUSTER_CT_CHECK(sizeof(MachineInstruction) == 24);
BUSTER_CT_CHECK(sizeof(MachineVirtualRegister) == 16);
BUSTER_CT_CHECK(sizeof(MachineBlock) == 32);
BUSTER_CT_CHECK(sizeof(MachineEdge) == 16);
BUSTER_CT_CHECK(sizeof(MachineEdit) == 16);
BUSTER_CT_CHECK(sizeof(void*) != 8 || sizeof(MachineEncodeResult) == 88);
BUSTER_CT_CHECK(sizeof(void*) != 8 || sizeof(IrInstruction) == 64);
BUSTER_CT_CHECK(sizeof(void*) != 8 || sizeof(IrValue) == 16);
BUSTER_CT_CHECK(sizeof(void*) != 8 || sizeof(IrBlock) == 64);
BUSTER_CT_CHECK(sizeof(void*) != 8 || sizeof(IrBlockParameter) == 40);
BUSTER_CT_CHECK(sizeof(void*) != 8 || sizeof(IrIncoming) == 16);
// Independently addressable diagnostic flags keep self-hosted IR loads typed.
// The by-value module options still fit in one native argument eightbyte.
BUSTER_CT_CHECK(sizeof(CodegenModuleOptions) == 7);
BUSTER_CT_CHECK(sizeof(MachineQualityInterval) == 24);

// Independent integer goldens at the old 32-bit boundary. These call the same
// accumulation, heap and regional selection used by real QUALITY placement;
// seeded costs reach the boundary without constructing a million MIR rows.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_quality_traffic(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u64 starts[] = {0, 2, UINT32_MAX - 4095u, UINT32_MAX, UINT64_C(4294967296), UINT64_C(17592186036224)};
    u32 weights[] = {0, 1, 4096, 1, 4096, 4096};
    u64 expected[] = {0, 3, UINT64_C(4294967296), UINT64_C(4294967296), UINT64_C(4294971392), UINT64_C(17592186040320)};
    for (u32 probe = 0; probe < BUSTER_ARRAY_LENGTH(starts); probe += 1)
    {
        MachineQualityTraffic traffic = (MachineQualityTraffic)starts[probe];
        machine_quality_traffic_add(&traffic, weights[probe]);
        BUSTER_TEST_RAW(arguments, traffic == expected[probe], S8("QUALITY weighted sum"));
        BUSTER_TEST(arguments, (traffic >= 3) == (expected[probe] >= 3));
    }

    u64 heap_costs[] = {3, UINT64_C(4294967297), UINT32_MAX, UINT64_C(4294967296)};
    u32 heap_expected[] = {1, 3, 2, 0};
    for (u32 repeat = 0; repeat < 3; repeat += 1)
    {
        MachineQualityInterval heap[BUSTER_ARRAY_LENGTH(heap_costs)];
        u32 count = BUSTER_ARRAY_LENGTH(heap);
        for (u32 index = 0; index < count; index += 1)
        {
            heap[index] = (MachineQualityInterval){.virtual_register = index, .weight = (MachineQualityTraffic)heap_costs[index]};
        }
        for (u32 root = count / 2; root > 0; root -= 1)
        {
            machine_quality_heap_sift(heap, count, root - 1);
        }
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(heap_expected); index += 1)
        {
            BUSTER_TEST_RAW(arguments, heap[0].virtual_register == heap_expected[index], S8("QUALITY descending weighted heap"));
            count -= 1;
            heap[0] = heap[count];
            machine_quality_heap_sift(heap, count, 0);
        }
        // The existing strict-greater heap tie policy is deterministic but is
        // not a stable sort: replacing the root with the last item gives 0,2,1.
        MachineQualityInterval ties[] = {{.virtual_register = 0, .weight = 7},
                                         {.virtual_register = 1, .weight = 7},
                                         {.virtual_register = 2, .weight = 7}};
        u32 tie_expected[] = {0, 2, 1};
        count = BUSTER_ARRAY_LENGTH(ties);
        machine_quality_heap_sift(ties, count, 0);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(tie_expected); index += 1)
        {
            BUSTER_TEST(arguments, ties[0].virtual_register == tie_expected[index]);
            count -= 1;
            ties[0] = ties[count];
            machine_quality_heap_sift(ties, count, 0);
        }
    }
    machine_quality_heap_sift(0, 0, 0);

    u64 region_costs[] = {0, UINT32_MAX, UINT64_C(4294967296), UINT64_C(4294967296), 3, UINT64_C(17592186040320)};
    u32 region_expected[] = {5, 2, 3, 1, 4, UINT32_MAX};
    MachineQualityTraffic regions[BUSTER_ARRAY_LENGTH(region_costs)];
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(regions); index += 1)
    {
        regions[index] = (MachineQualityTraffic)region_costs[index];
    }
    for (u32 repeat = 0; repeat < 3; repeat += 1)
    {
        u32 previous = UINT32_MAX;
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(region_expected); index += 1)
        {
            previous = machine_quality_region_next(regions, BUSTER_ARRAY_LENGTH(regions), previous);
            BUSTER_TEST_RAW(arguments, previous == region_expected[index], S8("QUALITY descending region order"));
        }
    }
    MachineQualityTraffic zeros[] = {0, 0, 0};
    BUSTER_TEST(arguments, machine_quality_region_next(0, 0, UINT32_MAX) == UINT32_MAX);
    BUSTER_TEST(arguments, machine_quality_region_next(zeros, BUSTER_ARRAY_LENGTH(zeros), UINT32_MAX) == UINT32_MAX);

    // The sparse row order must reproduce the dense query sequence exactly.
    // Deterministic generated rows cover empty, single, dense, sparse,
    // tie-heavy, zero-bearing, unsorted and duplicate-region rows, all
    // written over dirty storage.
    {
        enum
        {
            ROW_REGION_LIMIT = 48,
            ROW_ENTRY_LIMIT = 96,
        };
        MachineQualityRegionTraffic row[ROW_ENTRY_LIMIT];
        MachineQualityTraffic dense[ROW_REGION_LIMIT];
        u64 state = UINT64_C(0x9e3779b97f4a7c15);
        for (u32 trial = 0; trial < 512; trial += 1)
        {
            u32 shape = trial % 8;
            u32 region_count = 1 + (u32)(trial % ROW_REGION_LIMIT);
            u32 entry_count = shape == 0 ? 0 : shape == 1 ? 1 : shape == 2 ? region_count : shape == 3 ? 1 + region_count / 8 : 1 + (u32)(trial % ROW_ENTRY_LIMIT);
            for (u32 index = 0; index < ROW_ENTRY_LIMIT; index += 1)
            {
                row[index] = (MachineQualityRegionTraffic){.traffic = UINT64_MAX, .region = UINT32_MAX, .reserved = UINT32_MAX};
            }
            for (u32 region = 0; region < region_count; region += 1)
            {
                dense[region] = 0;
            }
            for (u32 index = 0; index < entry_count; index += 1)
            {
                state = state * UINT64_C(6364136223846793005) + UINT64_C(1442695040888963407);
                u32 random = (u32)(state >> 33);
                u32 region = shape <= 2 ? index % region_count : shape == 3 ? (index * 8) % region_count : random % region_count;
                if (shape == 4 && index)
                {
                    region = row[index - 1].region + (random % 3 == 0 ? 0 : 1) < region_count ? row[index - 1].region + (random % 3 == 0 ? 0 : 1)
                                                                                               : row[index - 1].region;
                }
                MachineQualityTraffic traffic = shape == 5 ? (MachineQualityTraffic)(1 + random % 2)
                                              : shape == 6 ? (MachineQualityTraffic)(random % 4)
                                                           : (MachineQualityTraffic)(random % 4096) << (random % 32);
                row[index] = (MachineQualityRegionTraffic){.traffic = traffic, .region = region};
                dense[region] += traffic;
            }
            u32 ordered = machine_quality_region_row_build(row, entry_count);
            u32 previous = UINT32_MAX;
            u32 matched = 0;
            for (;;)
            {
                previous = machine_quality_region_next(dense, region_count, previous);
                if (previous == UINT32_MAX)
                {
                    break;
                }
                BUSTER_TEST_RAW(arguments, matched < ordered && row[matched].region == previous && row[matched].traffic == dense[previous],
                                string_format(arguments->arena, S8("QUALITY sparse region order trial {u32} rank {u32}"), trial, matched));
                matched += 1;
            }
            BUSTER_TEST(arguments, matched == ordered);
        }
        BUSTER_TEST(arguments, machine_quality_region_row_build(0, 0) == 0);
        MachineQualityRegionTraffic ties[] = {
            {.traffic = 3, .region = 4}, {.traffic = 7, .region = 1}, {.traffic = 3, .region = 0},
            {.traffic = 0, .region = 2}, {.traffic = 4, .region = 0}, {.traffic = 7, .region = 3},
        };
        u32 tie_regions[] = {0, 1, 3, 4};
        u32 tie_count = machine_quality_region_row_build(ties, BUSTER_ARRAY_LENGTH(ties));
        BUSTER_TEST(arguments, tie_count == BUSTER_ARRAY_LENGTH(tie_regions));
        for (u32 index = 0; index < tie_count && index < BUSTER_ARRAY_LENGTH(tie_regions); index += 1)
        {
            BUSTER_TEST(arguments, ties[index].region == tie_regions[index]);
        }
    }
    return result;
}
// Independent goldens correspond to x86_64_movabs_encoding_oracle.s. The
// bounded producer comparison also checks every byte outside the instruction.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_prepared_movabs(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    BUSTER_TEST(arguments, machine_x64_test_movabs_prepared());
    u64 values[] = {0, 1, 127, 128, 255, 256, UINT64_C(0x7fffffff), UINT64_C(0x80000000),
                    UINT64_C(0xffffffff), UINT64_C(0x100000000), UINT64_C(0xffffffff80000000),
                    UINT64_C(0x7fffffffffffffff), UINT64_C(0x8000000000000000), UINT64_MAX,
                    UINT64_C(0x0123456789abcdef)};
    u8 prefixes[16][2] = {
        {0x48, 0xb8}, {0x48, 0xb9}, {0x48, 0xba}, {0x48, 0xbb},
        {0x48, 0xbc}, {0x48, 0xbd}, {0x48, 0xbe}, {0x48, 0xbf},
        {0x49, 0xb8}, {0x49, 0xb9}, {0x49, 0xba}, {0x49, 0xbb},
        {0x49, 0xbc}, {0x49, 0xbd}, {0x49, 0xbe}, {0x49, 0xbf},
    };
    for (u32 reg = 0; reg < 16; reg += 1)
    {
        for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1)
        {
            u64 value = values[value_index];
            for (u32 start = 0; start <= 17; start += 1)
            {
                for (u32 available = 0; available <= 17; available += 1)
                {
                    u8 bytes[64];
                    u8 reference[64];
                    u8 expected[64];
                    memset(bytes, 0xa5, sizeof(bytes));
                    memset(reference, 0xa5, sizeof(reference));
                    memset(expected, 0xa5, sizeof(expected));
                    bool valid = available >= 10;
                    if (valid)
                    {
                        expected[start] = prefixes[reg][0];
                        expected[start + 1] = prefixes[reg][1];
                        for (u32 byte = 0; byte < 8; byte += 1)
                        {
                            expected[start + 2 + byte] = (u8)(value >> (8u * byte));
                        }
                    }
                    MachineEncodeResult emitted = machine_x64_test_emit_movabs(bytes, start + available, start, reg, value, false);
                    MachineEncodeResult oracle = machine_x64_test_emit_movabs(reference, start + available, start, reg, value, true);
                    BUSTER_TEST(arguments, emitted.valid == valid && oracle.valid == valid);
                    BUSTER_TEST(arguments, emitted.byte_count == start + (valid ? 10u : 0u) && emitted.byte_count == oracle.byte_count);
                    BUSTER_TEST(arguments, emitted.exact_attempts == 1 && emitted.exact_successes == (u32)valid &&
                                           emitted.exact_failures == (u32)!valid);
                    BUSTER_TEST(arguments, emitted.exact_attempts == oracle.exact_attempts &&
                                           emitted.exact_successes == oracle.exact_successes && emitted.exact_failures == oracle.exact_failures);
                    BUSTER_TEST(arguments, memcmp(bytes, reference, sizeof(bytes)) == 0 && memcmp(bytes, expected, sizeof(bytes)) == 0);
                }
            }
        }
    }
    u32 invalid_registers[] = {16, 31, 32, UINT16_MAX, 65536, UINT32_MAX};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(invalid_registers) + 3; index += 1)
    {
        u8 bytes[32];
        u8 expected[32];
        memset(bytes, 0xa5, sizeof(bytes));
        memset(expected, 0xa5, sizeof(expected));
        u32 reg = index < BUSTER_ARRAY_LENGTH(invalid_registers) ? invalid_registers[index] : 0;
        bool null_output = index == BUSTER_ARRAY_LENGTH(invalid_registers);
        u32 start = index == BUSTER_ARRAY_LENGTH(invalid_registers) + 1 ? 33u :
                    index == BUSTER_ARRAY_LENGTH(invalid_registers) + 2 ? UINT32_MAX : 0u;
        MachineEncodeResult emitted = machine_x64_test_emit_movabs(null_output ? 0 : bytes, sizeof(bytes), start, reg, 0, false);
        BUSTER_TEST(arguments, !emitted.valid && emitted.byte_count == start);
        BUSTER_TEST(arguments, emitted.exact_attempts == 1 && emitted.exact_successes == 0 && emitted.exact_failures == 1);
        BUSTER_TEST(arguments, memcmp(bytes, expected, sizeof(bytes)) == 0);
    }
    return result;
}

// Independent goldens: GNU as and LLVM MC agree on every row. Each row is the
// instruction before its disp32 for -0x1000(%rbp): loads (MOVZX r64 for one
// and two bytes, MOV otherwise) then stores, widths 1/2/4/8, registers 0-15.
// The reference is the metadata exact form the prepared records are copied
// from; bytes past the instruction but inside capacity are the emitter's
// spare record bytes and are not compared.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_prepared_frame_chunk(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    BUSTER_TEST(arguments, machine_x64_test_frame_chunk_prepared());
    static u8 const goldens[2][4][16][5] = {
        {
            {{4, 0x48, 0x0f, 0xb6, 0x85}, {4, 0x48, 0x0f, 0xb6, 0x8d}, {4, 0x48, 0x0f, 0xb6, 0x95}, {4, 0x48, 0x0f, 0xb6, 0x9d}, {4, 0x48, 0x0f, 0xb6, 0xa5}, {4, 0x48, 0x0f, 0xb6, 0xad}, {4, 0x48, 0x0f, 0xb6, 0xb5}, {4, 0x48, 0x0f, 0xb6, 0xbd}, {4, 0x4c, 0x0f, 0xb6, 0x85}, {4, 0x4c, 0x0f, 0xb6, 0x8d}, {4, 0x4c, 0x0f, 0xb6, 0x95}, {4, 0x4c, 0x0f, 0xb6, 0x9d}, {4, 0x4c, 0x0f, 0xb6, 0xa5}, {4, 0x4c, 0x0f, 0xb6, 0xad}, {4, 0x4c, 0x0f, 0xb6, 0xb5}, {4, 0x4c, 0x0f, 0xb6, 0xbd}},
            {{4, 0x48, 0x0f, 0xb7, 0x85}, {4, 0x48, 0x0f, 0xb7, 0x8d}, {4, 0x48, 0x0f, 0xb7, 0x95}, {4, 0x48, 0x0f, 0xb7, 0x9d}, {4, 0x48, 0x0f, 0xb7, 0xa5}, {4, 0x48, 0x0f, 0xb7, 0xad}, {4, 0x48, 0x0f, 0xb7, 0xb5}, {4, 0x48, 0x0f, 0xb7, 0xbd}, {4, 0x4c, 0x0f, 0xb7, 0x85}, {4, 0x4c, 0x0f, 0xb7, 0x8d}, {4, 0x4c, 0x0f, 0xb7, 0x95}, {4, 0x4c, 0x0f, 0xb7, 0x9d}, {4, 0x4c, 0x0f, 0xb7, 0xa5}, {4, 0x4c, 0x0f, 0xb7, 0xad}, {4, 0x4c, 0x0f, 0xb7, 0xb5}, {4, 0x4c, 0x0f, 0xb7, 0xbd}},
            {{2, 0x8b, 0x85}, {2, 0x8b, 0x8d}, {2, 0x8b, 0x95}, {2, 0x8b, 0x9d}, {2, 0x8b, 0xa5}, {2, 0x8b, 0xad}, {2, 0x8b, 0xb5}, {2, 0x8b, 0xbd}, {3, 0x44, 0x8b, 0x85}, {3, 0x44, 0x8b, 0x8d}, {3, 0x44, 0x8b, 0x95}, {3, 0x44, 0x8b, 0x9d}, {3, 0x44, 0x8b, 0xa5}, {3, 0x44, 0x8b, 0xad}, {3, 0x44, 0x8b, 0xb5}, {3, 0x44, 0x8b, 0xbd}},
            {{3, 0x48, 0x8b, 0x85}, {3, 0x48, 0x8b, 0x8d}, {3, 0x48, 0x8b, 0x95}, {3, 0x48, 0x8b, 0x9d}, {3, 0x48, 0x8b, 0xa5}, {3, 0x48, 0x8b, 0xad}, {3, 0x48, 0x8b, 0xb5}, {3, 0x48, 0x8b, 0xbd}, {3, 0x4c, 0x8b, 0x85}, {3, 0x4c, 0x8b, 0x8d}, {3, 0x4c, 0x8b, 0x95}, {3, 0x4c, 0x8b, 0x9d}, {3, 0x4c, 0x8b, 0xa5}, {3, 0x4c, 0x8b, 0xad}, {3, 0x4c, 0x8b, 0xb5}, {3, 0x4c, 0x8b, 0xbd}},
        },
        {
            {{2, 0x88, 0x85}, {2, 0x88, 0x8d}, {2, 0x88, 0x95}, {2, 0x88, 0x9d}, {3, 0x40, 0x88, 0xa5}, {3, 0x40, 0x88, 0xad}, {3, 0x40, 0x88, 0xb5}, {3, 0x40, 0x88, 0xbd}, {3, 0x44, 0x88, 0x85}, {3, 0x44, 0x88, 0x8d}, {3, 0x44, 0x88, 0x95}, {3, 0x44, 0x88, 0x9d}, {3, 0x44, 0x88, 0xa5}, {3, 0x44, 0x88, 0xad}, {3, 0x44, 0x88, 0xb5}, {3, 0x44, 0x88, 0xbd}},
            {{3, 0x66, 0x89, 0x85}, {3, 0x66, 0x89, 0x8d}, {3, 0x66, 0x89, 0x95}, {3, 0x66, 0x89, 0x9d}, {3, 0x66, 0x89, 0xa5}, {3, 0x66, 0x89, 0xad}, {3, 0x66, 0x89, 0xb5}, {3, 0x66, 0x89, 0xbd}, {4, 0x66, 0x44, 0x89, 0x85}, {4, 0x66, 0x44, 0x89, 0x8d}, {4, 0x66, 0x44, 0x89, 0x95}, {4, 0x66, 0x44, 0x89, 0x9d}, {4, 0x66, 0x44, 0x89, 0xa5}, {4, 0x66, 0x44, 0x89, 0xad}, {4, 0x66, 0x44, 0x89, 0xb5}, {4, 0x66, 0x44, 0x89, 0xbd}},
            {{2, 0x89, 0x85}, {2, 0x89, 0x8d}, {2, 0x89, 0x95}, {2, 0x89, 0x9d}, {2, 0x89, 0xa5}, {2, 0x89, 0xad}, {2, 0x89, 0xb5}, {2, 0x89, 0xbd}, {3, 0x44, 0x89, 0x85}, {3, 0x44, 0x89, 0x8d}, {3, 0x44, 0x89, 0x95}, {3, 0x44, 0x89, 0x9d}, {3, 0x44, 0x89, 0xa5}, {3, 0x44, 0x89, 0xad}, {3, 0x44, 0x89, 0xb5}, {3, 0x44, 0x89, 0xbd}},
            {{3, 0x48, 0x89, 0x85}, {3, 0x48, 0x89, 0x8d}, {3, 0x48, 0x89, 0x95}, {3, 0x48, 0x89, 0x9d}, {3, 0x48, 0x89, 0xa5}, {3, 0x48, 0x89, 0xad}, {3, 0x48, 0x89, 0xb5}, {3, 0x48, 0x89, 0xbd}, {3, 0x4c, 0x89, 0x85}, {3, 0x4c, 0x89, 0x8d}, {3, 0x4c, 0x89, 0x95}, {3, 0x4c, 0x89, 0x9d}, {3, 0x4c, 0x89, 0xa5}, {3, 0x4c, 0x89, 0xad}, {3, 0x4c, 0x89, 0xb5}, {3, 0x4c, 0x89, 0xbd}},
        },
    };
    u32 const chunks[4] = {1, 2, 4, 8};
    u32 const offsets[] = {0, 8, 0x7f, 0x80, 0x1000, 0x12345678, 0x7fffffff, 0xfffffff8u};
    u32 const frame_bases[] = {0, 0x30, 0x12345};
    u32 const starts[] = {0, 1, 7, 15, 16, 17};
    for (u32 direction = 0; direction < 2; direction += 1)
    {
        bool load = direction == 0;
        for (u32 width_slot = 0; width_slot < 4; width_slot += 1)
        {
            for (u32 reg = 0; reg < 16; reg += 1)
            {
                u8 const* golden = goldens[direction][width_slot][reg];
                u32 length = golden[0] + (u32)sizeof(u32);
                u8 bytes[64];
                memset(bytes, 0xa5, sizeof(bytes));
                MachineEncodeResult emitted = machine_x64_test_emit_frame_chunk(bytes, sizeof(bytes), 0, 0, load, reg, 0x1000, chunks[width_slot], false);
                u8 const displacement[4] = {0x00, 0xf0, 0xff, 0xff};
                BUSTER_TEST(arguments, emitted.valid && emitted.byte_count == length && memcmp(bytes, golden + 1, golden[0]) == 0 &&
                                           memcmp(bytes + golden[0], displacement, sizeof(displacement)) == 0);

                bool row_matches = true;
                for (u32 offset_index = 0; offset_index < BUSTER_ARRAY_LENGTH(offsets); offset_index += 1)
                {
                    for (u32 base_index = 0; base_index < BUSTER_ARRAY_LENGTH(frame_bases); base_index += 1)
                    {
                        u32 offset = offsets[offset_index];
                        u32 frame_base = frame_bases[base_index];
                        u32 value = (0u - offset) + frame_base;
                        for (u32 start_index = 0; start_index < BUSTER_ARRAY_LENGTH(starts); start_index += 1)
                        {
                            u32 start = starts[start_index];
                            for (u32 available = 0; available <= 17; available += 1)
                            {
                                u32 capacity = start + available;
                                bool valid = available >= length;
                                u8 reference[64];
                                memset(bytes, 0xa5, sizeof(bytes));
                                memset(reference, 0xa5, sizeof(reference));
                                MachineEncodeResult prepared =
                                    machine_x64_test_emit_frame_chunk(bytes, capacity, start, frame_base, load, reg, offset, chunks[width_slot], false);
                                MachineEncodeResult oracle =
                                    machine_x64_test_emit_frame_chunk(reference, capacity, start, frame_base, load, reg, offset, chunks[width_slot], true);
                                row_matches &= prepared.valid == valid && oracle.valid == valid;
                                row_matches &= prepared.byte_count == start + (valid ? length : 0u) && prepared.byte_count == oracle.byte_count;
                                row_matches &= prepared.exact_attempts == 1 && prepared.exact_successes == (u32)valid &&
                                               prepared.exact_failures == (u32)!valid;
                                if (valid)
                                {
                                    row_matches &= oracle.exact_attempts == 1 && oracle.exact_successes == 1 && oracle.exact_failures == 0;
                                    row_matches &= memcmp(bytes, reference, start + length) == 0;
                                    row_matches &= memcmp(bytes + start, golden + 1, golden[0]) == 0;
                                    u32 patched;
                                    memcpy(&patched, bytes + start + golden[0], sizeof(patched));
                                    row_matches &= patched == value;
                                }
                                for (u32 index = 0; index < sizeof(bytes); index += 1)
                                {
                                    bool untouched = index < start || index >= capacity || !valid;
                                    row_matches &= !untouched || bytes[index] == 0xa5;
                                }
                            }
                        }
                    }
                }
                BUSTER_TEST(arguments, row_matches);
            }
        }
    }
    // An encoder already past its capacity and a register outside the dense
    // records both keep the metadata path's refusal and accounting.
    u32 const refused_registers[] = {0, 16, UINT32_MAX};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(refused_registers); index += 1)
    {
        u32 reg = refused_registers[index];
        u32 start = reg == 0 ? 33u : 0u;
        u8 bytes[32];
        u8 reference[32];
        u8 expected[32];
        memset(bytes, 0xa5, sizeof(bytes));
        memset(reference, 0xa5, sizeof(reference));
        memset(expected, 0xa5, sizeof(expected));
        MachineEncodeResult prepared = machine_x64_test_emit_frame_chunk(bytes, sizeof(bytes), start, 0, true, reg, 8, 8, false);
        MachineEncodeResult oracle = machine_x64_test_emit_frame_chunk(reference, sizeof(reference), start, 0, true, reg, 8, 8, reg != 0);
        BUSTER_TEST(arguments, !prepared.valid && prepared.byte_count == start && prepared.exact_attempts == 1 && prepared.exact_successes == 0 &&
                                   prepared.exact_failures == 1);
        BUSTER_TEST(arguments, prepared.valid == oracle.valid && prepared.byte_count == oracle.byte_count &&
                                   prepared.exact_attempts == oracle.exact_attempts && prepared.exact_successes == oracle.exact_successes &&
                                   prepared.exact_failures == oracle.exact_failures);
        BUSTER_TEST(arguments, memcmp(bytes, expected, sizeof(bytes)) == 0 && memcmp(reference, expected, sizeof(reference)) == 0);
    }
    return result;
}

// Compiles one C source through the C frontend into a canonical IrProgram
// for machine-selection tests. Diagnostics fail the caller's assertions.
BUSTER_GLOBAL_LOCAL IrProgram* machine_test_compile_c_with_options(Arena* arena, String8 name, String8 source, Target target, CIRLowerOptions options)
{
    CPreprocessResult tokens = c_preprocess(arena, source, (CPreprocessOptions){.source_path = name, .target = target});
    if (tokens.error_count)
    {
        return 0;
    }
    CParseResult parse = c_parse(arena, tokens);
    if (parse.diagnostic_count)
    {
        return 0;
    }
    CIRLowerResult lowered = c_lower_to_ir_with_options(arena, name, tokens, parse, target, options);
    IrProgram* result;
    if (lowered.diagnostic_count)
    {
        result = 0;
    }
    else
    {
        result = lowered.program;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL IrProgram* machine_test_compile_c(Arena* arena, String8 name, String8 source, Target target)
{
    return machine_test_compile_c_with_options(arena, name, source, target, (CIRLowerOptions){0});
}

BUSTER_GLOBAL_LOCAL IrFunction* machine_test_ir_function_find(IrModule* module, String8 name)
{
    for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
    {
        if (string_equal(module->functions[function_index].name, name))
        {
            return module->functions + function_index;
        }
    }
    return 0;
}

// Selects, verifies, places, and encodes one function; returns encoded
// bytes with valid=false at the first failing pipeline step.
BUSTER_GLOBAL_LOCAL MachineEncodeResult machine_test_encode(Arena* arena, IrProgram* program, IrFunction* function, Target target,
                                                            MachineSelectResult* select_out)
{
    MachineEncodeResult encoded = {0};
    MachineSelectResult selected = machine_select_canonical_function(arena, program, function, target);
    if (select_out)
    {
        *select_out = selected;
    }
    if (!selected.supported || !selected.selector_certified || machine_verify_function(&selected.function).error != MACHINE_VERIFY_NONE)
    {
        return encoded;
    }
    MachineStackPlacement placement = machine_stack_placement_build(arena, &selected.function);
    if (!placement.valid)
    {
        return encoded;
    }
    return target.cpu_arch == CPU_ARCH_AARCH64 ? machine_encode_aarch64(arena, &selected.function, &placement)
                                               : machine_encode_x86_64(arena, &selected.function, &placement);
}

// Structural oracle for baseline AArch64 pair-exclusive updates. The mnemonic
// source in tests/aarch64_atomic_update_pair_oracle.s is independently
// assemblable. A CAS mismatch cannot leave the exclusive window before STXP:
// the old pair is not single-copy atomic until that store succeeds.
BUSTER_GLOBAL_LOCAL bool machine_test_a64_atomic_update_loop(u8 const* bytes, u64 count, u32 flags, bool compare_exchange, u32 operation)
{
    u32 load = (flags & MACHINE_A64_ATOMIC_PAIR_ACQUIRE ? UINT32_C(0xc87f8000) : UINT32_C(0xc87f0000)) |
               (14u << 10) | (10u << 5) | 9u;
    u32 store = (flags & MACHINE_A64_ATOMIC_PAIR_RELEASE ? UINT32_C(0xc8208000) : UINT32_C(0xc8200000)) |
                (13u << 16) | (12u << 10) | (10u << 5) | 11u;
    u32 arithmetic[][2] = {{UINT32_C(0xab0b012b), UINT32_C(0x9a0c01cc)},
                           {UINT32_C(0xeb0b012b), UINT32_C(0xda0c01cc)},
                           {UINT32_C(0x8a0b012b), UINT32_C(0x8a0c01cc)},
                           {UINT32_C(0xaa0b012b), UINT32_C(0xaa0c01cc)},
                           {UINT32_C(0xca0b012b), UINT32_C(0xca0c01cc)}};
    u32 loops = 0;
    bool valid = true;
    for (u64 start = 0; bytes && start + sizeof(u32) <= count; start += sizeof(u32))
    {
        u32 word;
        memcpy(&word, bytes + start, sizeof(word));
        if (word == load)
        {
            loops += 1;
            u64 offset = start + sizeof(u32);
            u32 select_count = 0;
            u32 arithmetic_count = 0;
            bool saw_compare = false;
            bool saw_conditional_compare = false;
            bool saw_store = false;
            while (!saw_store && offset + sizeof(u32) <= count)
            {
                memcpy(&word, bytes + offset, sizeof(word));
                saw_store = word == store;
                // No branch can return an unvalidated pair, or escape the
                // window between the pair load and the successful store.
                valid &= (word & UINT32_C(0x7c000000)) != UINT32_C(0x14000000) &&
                         (word & UINT32_C(0xff000010)) != UINT32_C(0x54000000) &&
                         (word & UINT32_C(0x7e000000)) != UINT32_C(0x34000000) &&
                         (word & UINT32_C(0x7e000000)) != UINT32_C(0x36000000);
                if (compare_exchange)
                {
                    if (word == UINT32_C(0xeb0b013f)) saw_compare = true;
                    if (word == UINT32_C(0xfa4c01c0)) saw_conditional_compare = saw_compare;
                    if (word == UINT32_C(0x9a8901eb))
                    {
                        valid &= saw_conditional_compare && select_count == 0;
                        select_count += 1;
                    }
                    else if (word == UINT32_C(0x9a8e022c))
                    {
                        valid &= select_count == 1;
                        select_count += 1;
                    }

                }
                else if (operation < BUSTER_ARRAY_LENGTH(arithmetic))
                {
                    if (word == arithmetic[operation][0])
                    {
                        valid &= arithmetic_count == 0;
                        arithmetic_count += 1;
                    }
                    if (word == arithmetic[operation][1])
                    {
                        valid &= arithmetic_count == 1;
                        arithmetic_count += 1;
                    }
                }
                bool register_operation = compare_exchange
                    ? word == UINT32_C(0xeb0b013f) || word == UINT32_C(0xfa4c01c0) ||
                      word == UINT32_C(0x9a8901eb) || word == UINT32_C(0x9a8e022c)
                    : operation < BUSTER_ARRAY_LENGTH(arithmetic) &&
                      (word == arithmetic[operation][0] || word == arithmetic[operation][1]);
                valid &= saw_store || register_operation;
                offset += sizeof(u32);
            }
            valid &= saw_store && (compare_exchange ? select_count == 2 :
                                   operation == IR_ATOMIC_EXCHANGE || arithmetic_count == 2);
            if (saw_store && offset + sizeof(u32) <= count)
            {
                memcpy(&word, bytes + offset, sizeof(word));
                u32 encoded_delta = (word >> 5) & 0x7ffffu;
                s32 word_delta = (s32)(encoded_delta ^ 0x40000u) - 0x40000;
                s64 retry = (s64)offset + (s64)word_delta * 4;
                valid &= (word & UINT32_C(0xff00001f)) == UINT32_C(0x3500000d) && retry >= 0 && retry < (s64)start;
                // Every retry must reload all frame-backed input halves.
                // Address materialization can add register-only words.
                u32 loaded_registers = 0;
                for (s64 before = retry; valid && before < (s64)start; before += (s64)sizeof(u32))
                {
                    memcpy(&word, bytes + before, sizeof(word));
                    if ((word & UINT32_C(0xffc00000)) == UINT32_C(0xf9400000))
                    {
                        u32 bit = 1u << (word & 31u);
                        valid &= !(loaded_registers & bit);
                        loaded_registers |= bit;
                    }
                    else
                    {
                        valid &= (word & UINT32_C(0xff80001f)) == UINT32_C(0xd2800010) ||
                                 (word & UINT32_C(0xff80001f)) == UINT32_C(0xf2800010) ||
                                 word == UINT32_C(0x8b100390);
                    }
                }
                u32 expected_loads = (1u << 11) | (1u << 12) | (compare_exchange ? (1u << 15) | (1u << 17) : 0);
                valid &= loaded_registers == expected_loads;
            }
            else
            {
                valid = false;
            }
        }
    }
    return valid && loops == 1;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_a64_atomic_pair_updates(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Target target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX};
    String8 builtins[] = {S8("fetch_add"), S8("fetch_sub"), S8("fetch_and"), S8("fetch_or"), S8("fetch_xor"), S8("exchange"),
                          S8("compare_exchange_strong"), S8("compare_exchange_weak")};
    // GNU/C11 order constants: relaxed, consume, acquire, release, acq_rel, seq_cst.
    u32 failure_orders[] = {0, 1, 2, 0, 2, 5};
    u32 order_flags[] = {0, MACHINE_A64_ATOMIC_PAIR_ACQUIRE, MACHINE_A64_ATOMIC_PAIR_ACQUIRE, MACHINE_A64_ATOMIC_PAIR_RELEASE,
                         MACHINE_A64_ATOMIC_PAIR_ACQUIRE | MACHINE_A64_ATOMIC_PAIR_RELEASE,
                         MACHINE_A64_ATOMIC_PAIR_ACQUIRE | MACHINE_A64_ATOMIC_PAIR_RELEASE};
    for (u32 frontend = 0; frontend < 2; frontend += 1)
    {
        for (u32 operation = 0; operation < BUSTER_ARRAY_LENGTH(builtins); operation += 1)
        {
            for (u32 order = 0; order < BUSTER_ARRAY_LENGTH(order_flags); order += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                bool compare_exchange = operation >= BUSTER_ARRAY_LENGTH(builtins) - 2;
                String8 source = compare_exchange
                    ? string_format(temporary.arena, S8("typedef unsigned __int128 U; int update(_Atomic(U)* cell, U* expected, U const* value) {{ "
                                                        "return __c11_atomic_{S8}(cell, expected, *value, {u32}, {u32}); }"),
                                    builtins[operation], order, failure_orders[order])
                    : string_format(temporary.arena, S8("typedef unsigned __int128 U; void update(_Atomic(U)* cell, U const* value, U* old) {{ "
                                                        "*old = __c11_atomic_{S8}(cell, *value, {u32}); }"), builtins[operation], order);
                IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("atomic-pair-update.c"), source, target,
                                                                         (CIRLowerOptions){.disable_direct_ssa = frontend != 0});
                String8 description = string_format(arguments->arena, S8("a64 atomic {S8} order={u32} memory-form={u32}"),
                                                     builtins[operation], order, frontend);
                BUSTER_TEST_RAW(arguments, program && program->module_count, description);
                if (program && program->module_count)
                {
                    IrFunction* ir_function = machine_test_ir_function_find(program->modules, S8("update"));
                    BUSTER_TEST_RAW(arguments, ir_function != 0, description);
                    if (ir_function)
                    {
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, ir_function, target);
                        BUSTER_TEST_RAW(arguments, selected.supported, description);
                        if (selected.supported)
                        {
                            MachineFunction* function = &selected.function;
                            BUSTER_TEST_RAW(arguments, machine_verify_function(function).error == MACHINE_VERIFY_NONE, description);
                            u32 update_rows = 0;
                            for (u32 index = 0; index < function->instruction_count; index += 1)
                            {
                                MachineInstruction* row = function->instructions + index;
                                u32 opcode = compare_exchange ? MACHINE_A64_ATOMIC_CAS_PAIR : MACHINE_A64_ATOMIC_RMW_PAIR;
                                if (row->opcode == opcode)
                                {
                                    update_rows += 1;
                                    u32 payload = 16u | order_flags[order] |
                                                  (compare_exchange ? 0 : operation << MACHINE_A64_ATOMIC_PAIR_OPERATION_SHIFT);
                                    BUSTER_TEST_RAW(arguments, row->payload == payload, description);
                                    MachineOpcodeInfo const* info = machine_opcode_info(row->opcode);
                                    u32 scratch_mask = (1u << MACHINE_A64_X9) | (1u << MACHINE_A64_X11) | (1u << MACHINE_A64_X12) |
                                                       (1u << MACHINE_A64_X13) | (1u << MACHINE_A64_X14) |
                                                       (compare_exchange ? (1u << MACHINE_A64_X15) | (1u << MACHINE_A64_X17) : 0);
                                    BUSTER_TEST(arguments, info->clobber_mask == scratch_mask && info->fixed_register_mask == 1 &&
                                                           info->fixed_registers[0] == MACHINE_A64_X10 &&
                                                           (info->attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE) &&
                                                           info->memory_effect == MACHINE_MEMORY_EFFECT_READ_WRITE);
                                    // Isolate this row: shrinking a real selected input slot
                                    // could fail an earlier copy instead of the new contract.
                                    u32 operand_count = compare_exchange ? 4u : 3u;
                                    BUSTER_TEST(arguments, info->operand_count == operand_count);
                                    MachineInstruction probe_rows[2] = {*row, {.opcode = MACHINE_A64_RET}};
                                    u32 probe_sizes[3] = {16, 16, 16};
                                    MachineBlock probe_block = {.instruction_count = 2};
                                    probe_rows[0].operands[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_A64_X10);
                                    for (u32 operand = 1; operand < operand_count; operand += 1)
                                    {
                                        probe_rows[0].operands[operand] = machine_ref_make(MACHINE_REF_STACK_SLOT, operand - 1);
                                    }
                                    MachineFunction probe = {.instructions = probe_rows, .instruction_count = 2,
                                        .blocks = &probe_block, .block_count = 1, .target = machine_target_aarch64(),
                                        .stack_slot_sizes = probe_sizes, .stack_slot_count = operand_count - 1};
                                    BUSTER_TEST(arguments, machine_verify_function(&probe).error == MACHINE_VERIFY_NONE);
                                    u32 bad_payloads[] = {(payload & ~0xffu) | 8u, payload | 0x400u,
                                                          16u | (IR_ATOMIC_OPERATION_COUNT << MACHINE_A64_ATOMIC_PAIR_OPERATION_SHIFT)};
                                    for (u32 bad = 0; bad < BUSTER_ARRAY_LENGTH(bad_payloads); bad += 1)
                                    {
                                        probe_rows[0].payload = bad_payloads[bad];
                                        MachineVerifyResult rejected = machine_verify_function(&probe);
                                        BUSTER_TEST(arguments, rejected.error == MACHINE_VERIFY_PAYLOAD && rejected.instruction == 0);
                                    }
                                    probe_rows[0].payload = payload;
                                    for (u32 slot = 0; slot < probe.stack_slot_count; slot += 1)
                                    {
                                        probe_sizes[slot] = 15;
                                        MachineVerifyResult rejected = machine_verify_function(&probe);
                                        BUSTER_TEST(arguments, rejected.error == MACHINE_VERIFY_PAYLOAD && rejected.instruction == 0);
                                        probe_sizes[slot] = 16;
                                    }
                                    BUSTER_TEST(arguments, machine_verify_function(&probe).error == MACHINE_VERIFY_NONE);
                                }
                            }
                            BUSTER_TEST_RAW(arguments, update_rows == 1, description);
                            MachineStackPlacement placement = machine_stack_placement_build(temporary.arena, function);
                            BUSTER_TEST_RAW(arguments, placement.valid, description);
                            if (placement.valid)
                            {
                                // Leave the logical offsets unchanged and reserve unused space
                                // below them. Every input/result frame access must now take the
                                // large-offset path, not just the prologue's save instructions.
                                for (u32 large = 0; large < 2; large += 1)
                                {
                                    MachineStackPlacement adjusted = placement;
                                    adjusted.frame_size += large * 65536u;
                                    MachineEncodeResult encoded = machine_encode_aarch64(temporary.arena, function, &adjusted);
                                    BUSTER_TEST_RAW(arguments, encoded.valid, description);
                                    BUSTER_TEST_RAW(arguments, encoded.valid && machine_test_a64_atomic_update_loop(encoded.bytes,
                                        encoded.byte_count, order_flags[order], compare_exchange, operation), description);
                                }
                            }
                        }
                        CodegenModule direct = codegen_generate_canonical_module(temporary.arena, program, program->modules, target,
                                                                                 (CodegenModuleOptions){0});
                        BUSTER_TEST_RAW(arguments, direct.error == CODEGEN_ERROR_NONE, description);
                        BUSTER_TEST_RAW(arguments, direct.error == CODEGEN_ERROR_NONE && machine_test_a64_atomic_update_loop(direct.code.pointer,
                            direct.code.length, order_flags[order], compare_exchange, operation), description);
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

typedef struct MachineX64SourceSpan MachineX64SourceSpan;
struct MachineX64SourceSpan
{
    u8 const* bytes;
    u64 length;
    u64 start;
    u64 end;
};

typedef enum MachineX64SourceArch
{
    MACHINE_X64_SOURCE_ARCH_UNKNOWN,
    MACHINE_X64_SOURCE_ARCH_X86,
    MACHINE_X64_SOURCE_ARCH_AARCH64,
} MachineX64SourceArch;

typedef struct MachineX64SourceAudit MachineX64SourceAudit;
struct MachineX64SourceAudit
{
    bool files_readable;
    bool owners_found;
    u32 owner_count;
    u32 forbidden_count;
    u32 forbidden_constructor_count;
    u32 neutral_patch_count;
    u32 aarch64_write_count;
    u32 data_directive_count;
};

BUSTER_GLOBAL_LOCAL bool machine_test_source_identifier_start(u8 byte)
{
    return (byte >= 'a' && byte <= 'z') || (byte >= 'A' && byte <= 'Z') || byte == '_';
}

BUSTER_GLOBAL_LOCAL bool machine_test_source_identifier_continue(u8 byte)
{
    return machine_test_source_identifier_start(byte) || (byte >= '0' && byte <= '9');
}

BUSTER_GLOBAL_LOCAL bool machine_test_source_token_at(MachineX64SourceSpan source, u64 offset, String8 token)
{
    if (!source.bytes || source.start > source.end || source.end > source.length || offset < source.start || offset > source.end || !token.length ||
        token.length > source.end - offset)
        return false;
    if (memcmp(source.bytes + offset, token.pointer, token.length) != 0) return false;
    bool left_boundary = offset == source.start || !machine_test_source_identifier_continue(source.bytes[offset - 1]);
    u64 end = offset + token.length;
    bool right_boundary = end == source.end || !machine_test_source_identifier_continue(source.bytes[end]);
    return left_boundary && right_boundary;
}

BUSTER_GLOBAL_LOCAL bool machine_test_source_span_contains_sequence(MachineX64SourceSpan source, String8 sequence)
{
    if (source.bytes && source.start <= source.end && source.end <= source.length && sequence.length && sequence.length <= source.end - source.start)
    {
        u8 const* bytes = source.bytes + source.start;
        u64 length = source.end - source.start;
        for (u64 offset = 0; offset + sequence.length <= length; offset += 1)
            if (memcmp(bytes + offset, sequence.pointer, sequence.length) == 0) return true;
    }

    return false;
}

BUSTER_GLOBAL_LOCAL u8* machine_test_source_sanitize(Arena* arena, ByteSlice input)
{
    u8* result = arena_allocate(arena, u8, input.length + 1);
    u64 index = 0;
    while (index < input.length)
    {
        u8 byte = input.pointer[index];
        if (byte == '/' && index + 1 < input.length && input.pointer[index + 1] == '/')
        {
            while (index < input.length && input.pointer[index] != '\n')
            {
                result[index] = ' ';
                index += 1;
            }
            continue;
        }
        if (byte == '/' && index + 1 < input.length && input.pointer[index + 1] == '*')
        {
            result[index++] = ' ';
            result[index++] = ' ';
            while (index < input.length)
            {
                if (input.pointer[index] == '*' && index + 1 < input.length && input.pointer[index + 1] == '/')
                {
                    result[index++] = ' ';
                    result[index++] = ' ';
                    break;
                }
                result[index] = input.pointer[index] == '\n' ? '\n' : ' ';
                index += 1;
            }
            continue;
        }
        if (byte == '"' || byte == '\'')
        {
            u8 quote = byte;
            result[index++] = ' ';
            while (index < input.length)
            {
                byte = input.pointer[index];
                if (byte == '\\' && index + 1 < input.length)
                {
                    result[index++] = ' ';
                    u8 escaped = input.pointer[index];
                    result[index++] = escaped == '\n' ? '\n' : ' ';
                    continue;
                }
                result[index] = byte == '\n' ? '\n' : ' ';
                index += 1;
                if (byte == quote) break;
            }
            continue;
        }
        result[index] = byte;
        index += 1;
    }
    result[input.length] = 0;
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_test_source_function_body_at(MachineX64SourceSpan source, String8 owner, u64 offset,
                                                               MachineX64SourceSpan* body)
{
    if (!owner.length || !source.bytes || source.start > source.end || source.end > source.length || offset < source.start ||
        offset + owner.length > source.end || !machine_test_source_token_at(source, offset, owner))
        return false;
    u64 cursor = offset + owner.length;
    while (cursor < source.end && (source.bytes[cursor] == ' ' || source.bytes[cursor] == '\t' || source.bytes[cursor] == '\r' ||
                                   source.bytes[cursor] == '\n'))
        cursor += 1;
    if (cursor < source.end && source.bytes[cursor] == '(')
    {
        u64 parentheses = 0;
        for (; cursor < source.end; cursor += 1)
        {
            if (source.bytes[cursor] == '(') parentheses += 1;
            else if (source.bytes[cursor] == ')' && parentheses && --parentheses == 0)
            {
                cursor += 1;
                break;
            }
        }
        if (!parentheses && cursor < source.end)
        {
            // Definitions in this codebase put the opening brace immediately after
            // the parameter list (modulo whitespace).  Requiring that shape rejects
            // calls such as x64_emit_foo(...) followed by a block and keeps prefix
            // discovery independent of line numbers or call-site lists.
            while (cursor < source.end && (source.bytes[cursor] == ' ' || source.bytes[cursor] == '\t' || source.bytes[cursor] == '\r' ||
                                           source.bytes[cursor] == '\n'))
                cursor += 1;
            if (cursor < source.end && source.bytes[cursor] == '{')
            {
                u64 depth = 0;
                for (u64 index = cursor; index < source.end; index += 1)
                {
                    if (source.bytes[index] == '{') depth += 1;
                    else if (source.bytes[index] == '}')
                    {
                        if (!depth) break;
                        depth -= 1;
                        if (!depth)
                        {
                            if (body)
                            {
                                *body = (MachineX64SourceSpan){
                                    .bytes = source.bytes,
                                    .length = source.length,
                                    .start = cursor,
                                    .end = index + 1,
                                };
                            }
                            return true;
                        }
                    }
                }
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool machine_test_source_function_body_from(MachineX64SourceSpan source, String8 owner, u64 search_start,
                                                                 MachineX64SourceSpan* body)
{
    if (owner.length && source.bytes && source.start <= source.end && source.end <= source.length)
    {
        u64 first_offset = BUSTER_MAX(search_start, source.start);
        for (u64 offset = first_offset; offset + owner.length <= source.end; offset += 1)
        {
            if (machine_test_source_function_body_at(source, owner, offset, body)) return true;
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool machine_test_source_function_body(MachineX64SourceSpan source, String8 owner, MachineX64SourceSpan* body)
{
    return machine_test_source_function_body_from(source, owner, source.start, body);
}

BUSTER_GLOBAL_LOCAL MachineX64SourceArch machine_test_source_arch_inverse(MachineX64SourceArch arch)
{
    return arch == MACHINE_X64_SOURCE_ARCH_X86   ? MACHINE_X64_SOURCE_ARCH_AARCH64
           : arch == MACHINE_X64_SOURCE_ARCH_AARCH64 ? MACHINE_X64_SOURCE_ARCH_X86
                                                     : MACHINE_X64_SOURCE_ARCH_UNKNOWN;
}

BUSTER_GLOBAL_LOCAL MachineX64SourceArch machine_test_source_arch_markers(MachineX64SourceSpan source, u64 start, u64 end)
{
    if (source.bytes && start <= end && end <= source.end)
    {
        String8 x86_name = S8("CPU_ARCH_X86_64");
        String8 aarch64_name = S8("CPU_ARCH_AARCH64");
        bool x86_found = false;
        bool aarch64_found = false;
        for (u64 offset = start; offset + x86_name.length <= end; offset += 1)
        {
            x86_found |= machine_test_source_token_at(source, offset, x86_name);
        }
        for (u64 offset = start; offset + aarch64_name.length <= end; offset += 1)
        {
            aarch64_found |= machine_test_source_token_at(source, offset, aarch64_name);
        }
        if (x86_found && !aarch64_found) return MACHINE_X64_SOURCE_ARCH_X86;
        if (aarch64_found && !x86_found) return MACHINE_X64_SOURCE_ARCH_AARCH64;
    }

    return MACHINE_X64_SOURCE_ARCH_UNKNOWN;
}

BUSTER_GLOBAL_LOCAL MachineX64SourceArch machine_test_source_arch_for_brace(MachineX64SourceSpan source, MachineX64SourceSpan body, u64 brace,
                                                                              MachineX64SourceArch parent, MachineX64SourceArch else_parent)
{
    u64 segment_start = brace;
    while (segment_start > body.start)
    {
        u8 byte = source.bytes[segment_start - 1];
        if (byte == ';' || byte == '{' || byte == '}') break;
        segment_start -= 1;
    }
    MachineX64SourceArch marker_arch = machine_test_source_arch_markers(source, segment_start, brace);
    if (marker_arch != MACHINE_X64_SOURCE_ARCH_UNKNOWN) return marker_arch;
    String8 else_name = S8("else");
    for (u64 offset = segment_start; offset + else_name.length <= brace; offset += 1)
    {
        if (machine_test_source_token_at(source, offset, else_name))
            return parent == MACHINE_X64_SOURCE_ARCH_UNKNOWN && else_parent != MACHINE_X64_SOURCE_ARCH_UNKNOWN
                       ? machine_test_source_arch_inverse(else_parent)
                       : parent;
    }
    return parent;
}

BUSTER_GLOBAL_LOCAL MachineX64SourceArch machine_test_source_arch_for_writer(MachineX64SourceSpan source, MachineX64SourceSpan body,
                                                                                u64 writer_offset, MachineX64SourceArch default_arch)
{
    MachineX64SourceArch stack[256] = {0};
    u32 depth = 0;
    MachineX64SourceArch current = default_arch;
    MachineX64SourceArch last_closed = MACHINE_X64_SOURCE_ARCH_UNKNOWN;
    for (u64 offset = body.start; offset < writer_offset && offset < body.end; offset += 1)
    {
        if (source.bytes[offset] == '{')
        {
            if (depth < BUSTER_ARRAY_LENGTH(stack))
            {
                stack[depth++] = current;
                current = machine_test_source_arch_for_brace(source, body, offset, current, last_closed);
                last_closed = MACHINE_X64_SOURCE_ARCH_UNKNOWN;
            }
        }
        else if (source.bytes[offset] == '}' && depth)
        {
            last_closed = current;
            current = stack[--depth];
        }
    }
    if (current != MACHINE_X64_SOURCE_ARCH_UNKNOWN) return current;

    // A ternary architecture guard (the code-buffer alignment path is the
    // important example) has no enclosing brace.  Restrict the look-back to
    // the current statement so a previous branch cannot classify a .byte/data
    // write as an instruction.
    u64 statement_start = writer_offset;
    while (statement_start > body.start)
    {
        u8 byte = source.bytes[statement_start - 1];
        if (byte == ';' || byte == '{' || byte == '}') break;
        statement_start -= 1;
    }
    u64 question = UINT64_MAX;
    u64 colon = UINT64_MAX;
    for (u64 offset = statement_start; offset < writer_offset; offset += 1)
    {
        if (source.bytes[offset] == '?') question = offset;
    }
    if (question != UINT64_MAX)
    {
        for (u64 offset = question + 1; offset < body.end; offset += 1)
        {
            if (source.bytes[offset] == ':')
            {
                colon = offset;
                break;
            }
        }
        MachineX64SourceArch condition_arch = machine_test_source_arch_markers(source, statement_start, question);
        if (condition_arch != MACHINE_X64_SOURCE_ARCH_UNKNOWN)
        {
            if (writer_offset < colon) return condition_arch;
            if (colon != UINT64_MAX && writer_offset > colon) return machine_test_source_arch_inverse(condition_arch);
        }
    }
    MachineX64SourceArch marker_arch = machine_test_source_arch_markers(source, statement_start, writer_offset);
    MachineX64SourceArch result;
    if (marker_arch != MACHINE_X64_SOURCE_ARCH_UNKNOWN)
    {
        result = marker_arch;
    }
    else
    {
        result = default_arch;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL void machine_test_source_scan_writers(MachineX64SourceSpan source, MachineX64SourceSpan body,
                                                            MachineX64SourceArch default_arch, String8 const* writers, u32 writer_count,
                                                            bool* has_x86, bool* has_aarch64, bool* has_unknown)
{
    for (u32 writer_index = 0; writer_index < writer_count; writer_index += 1)
    {
        String8 writer = writers[writer_index];
        for (u64 offset = body.start; offset + writer.length <= body.end; offset += 1)
        {
            if (!machine_test_source_token_at(source, offset, writer)) continue;
            MachineX64SourceArch arch = machine_test_source_arch_for_writer(source, body, offset, default_arch);
            if (arch == MACHINE_X64_SOURCE_ARCH_X86)
            {
                if (has_x86) *has_x86 = true;
            }
            else if (arch == MACHINE_X64_SOURCE_ARCH_AARCH64)
            {
                if (has_aarch64) *has_aarch64 = true;
            }
            else if (has_unknown)
            {
                *has_unknown = true;
            }
        }
    }
}

BUSTER_GLOBAL_LOCAL MachineX64SourceAudit machine_test_x86_source_authority_audit(Arena* arena)
{
    MachineX64SourceAudit audit = {.files_readable = true, .owners_found = true};
    typedef struct MachineX64SourceFile MachineX64SourceFile;
    struct MachineX64SourceFile
    {
        String8 path;
        MachineX64SourceArch default_arch;
    };
    typedef struct MachineX64ConsumerSite MachineX64ConsumerSite;
    struct MachineX64ConsumerSite
    {
        String8 source_file;
        String8 owner_symbol;
    };
    typedef struct MachineX64NeutralSite MachineX64NeutralSite;
    struct MachineX64NeutralSite
    {
        String8 source_file;
        String8 owner_symbol;
        bool fixed_sequence;
    };
    // Consumers are kept as migration anchors for the source audit, but are
    // not counted as authorities: their bodies must route instruction
    // construction through one of the metadata entry points.
    static MachineX64ConsumerSite const consumers[] = {
        {S8_INITIALIZER("src/buster/lib/compiler/codegen/codegen.c"), S8_INITIALIZER("codegen_canonical_x64_metadata_emit")},
        {S8_INITIALIZER("src/buster/lib/compiler/codegen/codegen.c"), S8_INITIALIZER("codegen_canonical_x64_thread_local_general_dynamic")},
        {S8_INITIALIZER("src/buster/lib/compiler/codegen/codegen.c"), S8_INITIALIZER("codegen_generate_canonical_module_attempt")},
        {S8_INITIALIZER("src/buster/lib/compiler/codegen/codegen.c"), S8_INITIALIZER("codegen_emit_global_assembly")},
        {S8_INITIALIZER("src/buster/lib/compiler/assembly/assembly.c"), S8_INITIALIZER("assembly_x86_metadata_emit")},
        {S8_INITIALIZER("src/buster/lib/compiler/assembly/assembly.c"), S8_INITIALIZER("assembly_instructions_emit")},
        {S8_INITIALIZER("src/buster/lib/x86_64.c"), S8_INITIALIZER("x86_64_encode_register_operation")},
        {S8_INITIALIZER("src/buster/lib/compiler/jit/jit.c"), S8_INITIALIZER("jit_emit_thunks")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_x86_emit")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_x86_build_elf_entry_stub")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_x86_build_pe_entry_stub")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_native_executable_elf64_x86_64")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_native_executable_elf64_x86_64_dynamic")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_native_executable_pe64")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_native_executable_mach_o64")},
    };
    static MachineX64NeutralSite const neutral_sites[] = {
        {S8_INITIALIZER("src/buster/lib/compiler/codegen/codegen.c"), S8_INITIALIZER("codegen_emit_global_assembly"), false},
        {S8_INITIALIZER("src/buster/lib/compiler/codegen/codegen.c"), S8_INITIALIZER("codegen_generate_canonical_module_attempt")},
        {S8_INITIALIZER("src/buster/lib/compiler/assembly/assembly.c"), S8_INITIALIZER("assembly_x86_metadata_local_relocation")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_address_difference")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_write_u16")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_write_u32")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_write_u32_be")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_write_u64")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_native_executable_elf64_x86_64")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_native_executable_elf64_x86_64_dynamic")},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), S8_INITIALIZER("link_native_executable_mach_o64")},
        {S8_INITIALIZER("src/buster/lib/compiler/jit/jit.c"), S8_INITIALIZER("jit_emit_thunks")},
        {S8_INITIALIZER("src/buster/lib/compiler/jit/jit.c"), S8_INITIALIZER("jit_apply_relocations")},
        {S8_INITIALIZER("src/buster/lib/compiler/jit/jit.c"), S8_INITIALIZER("jit_apply_aarch64_mach_page_relocation")},
    };
    static MachineX64SourceFile const files[] = {
        {S8_INITIALIZER("src/buster/lib/compiler/codegen/codegen.c"), MACHINE_X64_SOURCE_ARCH_UNKNOWN},
        {S8_INITIALIZER("src/buster/lib/compiler/assembly/assembly.c"), MACHINE_X64_SOURCE_ARCH_UNKNOWN},
        {S8_INITIALIZER("src/buster/lib/x86_64.c"), MACHINE_X64_SOURCE_ARCH_X86},
        {S8_INITIALIZER("src/buster/lib/compiler/jit/jit.c"), MACHINE_X64_SOURCE_ARCH_UNKNOWN},
        {S8_INITIALIZER("src/buster/lib/compiler/link/link.c"), MACHINE_X64_SOURCE_ARCH_UNKNOWN},
    };
    static String8 const codegen_writers[] = {
        S8_INITIALIZER("codegen_emit_u8"),
        S8_INITIALIZER("codegen_emit_u32"),
        S8_INITIALIZER("codegen_emit_u64"),
    };
    static String8 const assembly_writers[] = {
        S8_INITIALIZER("assembly_emit_byte"),
        S8_INITIALIZER("assembly_emit_immediate"),
    };
    u8 neutral_site_seen[BUSTER_ARRAY_LENGTH(neutral_sites)] = {0};
    for (u32 file_index = 0; file_index < BUSTER_ARRAY_LENGTH(files); file_index += 1)
    {
        MachineX64SourceFile file = files[file_index];
        ByteSlice input = file_read(arena, file.path, (FileReadOptions){0});
        if (!input.pointer || !input.length)
        {
            audit.files_readable = false;
            continue;
        }
        u8* sanitized = machine_test_source_sanitize(arena, input);
        MachineX64SourceSpan source = {.bytes = sanitized, .length = input.length, .start = 0, .end = input.length};

        // Neutral patch owners are audited independently of metadata
        // consumers.  A patch helper may legitimately write bytes, but the
        // owner must be named in the registry so a new writer cannot be
        // smuggled in as an unreviewed exception.
        for (u32 neutral_index = 0; neutral_index < BUSTER_ARRAY_LENGTH(neutral_sites); neutral_index += 1)
        {
            MachineX64NeutralSite site = neutral_sites[neutral_index];
            if (neutral_site_seen[neutral_index] || !string_equal(site.source_file, file.path)) continue;
            MachineX64SourceSpan body = {0};
            if (!machine_test_source_function_body(source, site.owner_symbol, &body))
            {
                audit.owners_found = false;
                continue;
            }
            neutral_site_seen[neutral_index] = 1;
            audit.neutral_patch_count += 1;
        }

        // First audit the explicitly named metadata consumers.  They are
        // stable migration anchors; byte writes in a consumer are judged by
        // the active architecture guard, not by a source line allowlist.
        for (u32 site_index = 0; site_index < BUSTER_ARRAY_LENGTH(consumers); site_index += 1)
        {
            MachineX64ConsumerSite site = consumers[site_index];
            if (!string_equal(site.source_file, file.path)) continue;
            MachineX64SourceSpan body = {0};
            if (!machine_test_source_function_body(source, site.owner_symbol, &body))
            {
                audit.owners_found = false;
                continue;
            }
            audit.owner_count += 1;
            bool has_x86 = false;
            bool has_aarch64 = false;
            bool has_unknown = false;
            bool assembly_file = string_equal(file.path, S8("src/buster/lib/compiler/assembly/assembly.c"));
            String8 const* writers = assembly_file ? assembly_writers : codegen_writers;
            u32 writer_count = assembly_file ? BUSTER_ARRAY_LENGTH(assembly_writers) : BUSTER_ARRAY_LENGTH(codegen_writers);
            machine_test_source_scan_writers(source, body, file.default_arch, writers, writer_count, &has_x86, &has_aarch64, &has_unknown);
            if (assembly_file)
            {
                // The AArch64 fixed-word/semantic branches use assembly_emit_u32
                // and never call an assembly_x86_emit_* helper.  A call to an
                // x86 helper is therefore the architecture-independent marker
                // for a handwritten x86 constructor in the mixed emitter.
                bool has_handwritten_x86 = string_equal(site.owner_symbol, S8("assembly_instructions_emit")) &&
                                           machine_test_source_span_contains_sequence(body, S8("assembly_x86_emit_"));
                if (has_handwritten_x86 || has_unknown)
                {
                    audit.forbidden_count += 1;
                    audit.forbidden_constructor_count += 1;
                }
            }
            else if (string_equal(file.path, S8("src/buster/lib/compiler/codegen/codegen.c")))
            {
                bool has_data_directive = has_unknown && machine_test_source_span_contains_sequence(body, S8(".byte"));
                if (has_x86)
                {
                    // `.byte` is data, while a target-guarded 0x90 alignment
                    // byte is an x86 instruction and remains forbidden until
                    // it is routed through metadata.
                    audit.forbidden_count += 1;
                    audit.forbidden_constructor_count += 1;
                }
                else if (has_unknown && !has_data_directive)
                {
                    // An unguarded byte writer in a mixed codegen owner is
                    // not safely attributable to AArch64.  Treat unknown as
                    // a handwritten x86 producer until an architecture guard
                    // (or a recognized .byte data parser) makes its intent
                    // explicit.
                    audit.forbidden_count += 1;
                    audit.forbidden_constructor_count += 1;
                }
                if (has_aarch64) audit.aarch64_write_count += 1;
                if (has_data_directive) audit.data_directive_count += 1;
            }
        }

        // Discover x86-named helper definitions instead of keeping a brittle
        // line-number or hand-maintained helper allowlist.  x64 helpers are
        // x86 by default; a nested AArch64 guard is handled by the brace
        // tracker above.  The assembly metadata adapter is a consumer and has
        // no assembly_emit_byte call, so it naturally remains clean.
        String8 prefixes[2] = {0};
        MachineX64SourceArch prefix_arch[2] = {0};
        u32 prefix_count = 0;
        if (string_equal(file.path, S8("src/buster/lib/compiler/codegen/codegen.c")))
        {
            prefixes[prefix_count] = S8("codegen_canonical_x64_");
            prefix_arch[prefix_count++] = MACHINE_X64_SOURCE_ARCH_X86;
            prefixes[prefix_count] = S8("x64_emit_");
            prefix_arch[prefix_count++] = MACHINE_X64_SOURCE_ARCH_X86;
        }
        else if (string_equal(file.path, S8("src/buster/lib/compiler/assembly/assembly.c")))
        {
            prefixes[prefix_count] = S8("assembly_x86_");
            prefix_arch[prefix_count++] = MACHINE_X64_SOURCE_ARCH_X86;
        }
        for (u32 prefix_index = 0; prefix_index < prefix_count; prefix_index += 1)
        {
            String8 prefix = prefixes[prefix_index];
            for (u64 offset = source.start; offset + prefix.length <= source.end; offset += 1)
            {
                if (memcmp(source.bytes + offset, prefix.pointer, prefix.length) != 0 ||
                    (offset && machine_test_source_identifier_continue(source.bytes[offset - 1])))
                    continue;
                u64 end = offset + prefix.length;
                while (end < source.end && machine_test_source_identifier_continue(source.bytes[end])) end += 1;
                String8 owner = {.pointer = (char8*)(source.bytes + offset), .length = end - offset};
                // A registered fixed-sequence site is the one kind of x86
                // byte writer the metadata encoder cannot stand in for: its
                // bytes are matched and replaced whole by a linker, so the
                // shortest encoding of the same instructions is the wrong
                // answer.  Naming the owner in the neutral registry is what
                // keeps it reviewed; the registry membership is checked
                // above, so here it only stops the discovery scan from
                // counting the same site as a handwritten constructor.
                bool fixed_sequence = false;
                for (u32 neutral_index = 0; neutral_index < BUSTER_ARRAY_LENGTH(neutral_sites); neutral_index += 1)
                {
                    MachineX64NeutralSite site = neutral_sites[neutral_index];
                    fixed_sequence |= site.fixed_sequence && string_equal(site.source_file, file.path) && string_equal(site.owner_symbol, owner);
                }
                MachineX64SourceSpan body = {0};
                // The name starts at `offset`, so ask whether a definition
                // begins *here* rather than searching forward for one.  The
                // forward search made every call site cost a scan to the end
                // of the file -- half the module's time on codegen.c alone --
                // and it could also step over an intervening definition,
                // because a call site that resolved to a later definition
                // advanced the cursor past that definition's body.
                if (!machine_test_source_function_body_at(source, owner, offset, &body)) continue;
                audit.owner_count += 1;
                bool has_x86 = false;
                bool has_aarch64 = false;
                bool has_unknown = false;
                if (prefix_arch[prefix_index] == MACHINE_X64_SOURCE_ARCH_X86)
                {
                    machine_test_source_scan_writers(source, body, prefix_arch[prefix_index],
                                                      string_equal(file.path, S8("src/buster/lib/compiler/assembly/assembly.c"))
                                                          ? assembly_writers
                                                          : codegen_writers,
                                                      string_equal(file.path, S8("src/buster/lib/compiler/assembly/assembly.c"))
                                                          ? BUSTER_ARRAY_LENGTH(assembly_writers)
                                                          : BUSTER_ARRAY_LENGTH(codegen_writers),
                                                      &has_x86, &has_aarch64, &has_unknown);
                }
                if (!fixed_sequence && (has_x86 || has_unknown))
                {
                    audit.forbidden_count += 1;
                    audit.forbidden_constructor_count += 1;
                }
                if (has_aarch64) audit.aarch64_write_count += 1;
                offset = end - 1;
            }
        }
    }
    return audit;
}

// Native tests resolve function entries by symbol. Each execution site
// chooses the matching host ABI: Windows variadic tests use Win64, while
// the System V and AArch64 fixtures keep their Unix execution guards.
#if (BUSTER_CPU_ARCH_X86_64 || (BUSTER_CPU_ARCH_AARCH64 && !BUSTER_WINDOWS)) && !BUSTER_SANITIZE
BUSTER_GLOBAL_LOCAL u32 machine_test_module_offset(CodegenModule* module, IrModule* ir_module, String8 name)
{
    IrFunction* ir_function = machine_test_ir_function_find(ir_module, name);
    for (u32 entry_index = 0; ir_function && entry_index < module->entry_count; entry_index += 1)
    {
        if (module->entries[entry_index].symbol.value == ir_function->symbol.value)
        {
            return module->entries[entry_index].offset;
        }
    }
    return UINT32_MAX;
}
#endif

// Full C->canonical->MIR->bytes coverage for both directions of pointer/frame
// copies across imm12, including sized tails. Native AArch64 Unix hosts also
// execute the generated function and compare every byte plus guard regions.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_a64_large_aggregate_copy(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u32 sizes[] = {32768, 32775, 65543};
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_MACOS, OPERATING_SYSTEM_WINDOWS};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        Target target = {.cpu_arch = CPU_ARCH_AARCH64, .os = systems[system]};
        for (u32 size_index = 0; size_index < BUSTER_ARRAY_LENGTH(sizes); size_index += 1)
        {
            for (u32 frontend = 0; frontend < 2; frontend += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                u32 size = sizes[size_index];
                String8 source = string_format(temporary.arena,
                    S8("typedef struct Payload {{ unsigned char bytes[{u32}]; }} Payload; "
                       "void copy_payload(Payload *out, Payload const *in) {{ Payload local = *in; *out = local; }"), size);
                IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("large-aggregate-copy.c"), source, target,
                    (CIRLowerOptions){.disable_direct_ssa = frontend != 0});
                BUSTER_TEST(arguments, program && program->module_count);
                if (program && program->module_count)
                {
                    IrModule* module = program->modules;
                    IrFunction* function = machine_test_ir_function_find(module, S8("copy_payload"));
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                        BUSTER_TEST(arguments, selected.supported && machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        bool from_pointer = false;
                        bool to_pointer = false;
                        for (u32 row = 0; selected.supported && row < selected.function.instruction_count; row += 1)
                        {
                            MachineInstruction const* instruction = selected.function.instructions + row;
                            from_pointer |= instruction->opcode == MACHINE_A64_COPY_FRAME_FROM_PTR && instruction->payload == size;
                            to_pointer |= instruction->opcode == MACHINE_A64_COPY_PTR_FROM_FRAME && instruction->payload == size;
                        }
                        BUSTER_TEST(arguments, from_pointer && to_pointer);
                    }
                    for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                    {
                        CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                            (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                        BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE && generated.code.length != 0);
                        BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0 && generated.relocation_count == 0);
#if BUSTER_CPU_ARCH_AARCH64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                        if (target.os == target_native.os && generated.error == CODEGEN_ERROR_NONE && generated.relocation_count == 0)
                        {
                            CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                            u32 offset = machine_test_module_offset(&generated, module, S8("copy_payload"));
                            BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE && offset != UINT32_MAX);
                            if (executable.address && offset != UINT32_MAX)
                            {
                                u8* input = arena_allocate(temporary.arena, u8, size);
                                u8* output = arena_allocate(temporary.arena, u8, size + 16u);
                                for (u32 index = 0; index < size; index += 1)
                                {
                                    input[index] = (u8)(index * 37u + 19u);
                                }
                                memset(output, 0xa5, size + 16u);
                                void* address = (u8*)executable.address + offset;
                                void (*copy)(void*, void const*) = 0;
                                memcpy(&copy, &address, sizeof(copy));
                                copy(output + 8, input);
                                BUSTER_TEST(arguments, memcmp(output + 8, input, size) == 0);
                                bool guards = true;
                                for (u32 index = 0; index < 8; index += 1)
                                {
                                    guards &= output[index] == 0xa5 && output[size + 8u + index] == 0xa5;
                                }
                                BUSTER_TEST(arguments, guards);
                            }
                            codegen_release_executable(executable);
                        }
#endif
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL MachineFunction machine_test_build_function(Arena* arena)
{
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    u32 source = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
                                                                .definition_point = MACHINE_POINT_INVALID,
                                                                .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                .typed_origin = IR_ID_UNDERLYING_INVALID,
                                                            });
    u32 destination = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
                                                                     .definition_point = machine_point_make(0, MACHINE_POINT_AFTER),
                                                                     .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                     .typed_origin = IR_ID_UNDERLYING_INVALID,
                                                                 });
    u32 source_parameter_offset = machine_builder_block_parameter(&builder, (MachineBlockParameter){.virtual_register = source});
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){
                                              .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, destination),
                                                           machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source)},
                                              .opcode = MACHINE_OPCODE_SKELETON_COPY,
                                          });
    machine_builder_instruction(&builder, (MachineInstruction){
                                              .opcode = MACHINE_OPCODE_SKELETON_RETURN,
                                          });
    machine_builder_block_end(&builder, (MachineBlock){.parameter_offset = source_parameter_offset, .parameter_count = 1});
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){
                                              .opcode = MACHINE_OPCODE_SKELETON_NOP,
                                          });
    machine_builder_instruction(&builder, (MachineInstruction){
                                              .opcode = MACHINE_OPCODE_SKELETON_RETURN,
                                          });
    machine_builder_block_end(&builder, (MachineBlock){0});
    return machine_function_builder_finish(arena, &builder);
}

BUSTER_GLOBAL_LOCAL MachineFunction machine_test_build_cmpxchg16_function(Arena* arena)
{
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    u32 address = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
                                                               .definition_point = machine_point_make(0, MACHINE_POINT_AFTER),
                                                               .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                           });
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){
                                              .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address),
                                                           machine_ref_make(MACHINE_REF_IMMEDIATE, 0)},
                                              .opcode = MACHINE_X64_MOV_RI,
                                          });
    machine_builder_instruction(&builder, (MachineInstruction){
                                              .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, 0),
                                                           machine_ref_make(MACHINE_REF_STACK_SLOT, 1),
                                                           machine_ref_make(MACHINE_REF_STACK_SLOT, 2),
                                                           machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address)},
                                              .opcode = MACHINE_X64_ATOMIC_CMPXCHG16,
                                          });
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
    function.immediates = arena_allocate(arena, u64, 1);
    function.immediates[0] = 0;
    function.immediate_count = 1;
    function.stack_slot_sizes = arena_allocate(arena, u32, 3);
    function.stack_slot_alignments = arena_allocate(arena, u32, 3);
    for (u32 slot = 0; slot < 3; slot += 1)
    {
        function.stack_slot_sizes[slot] = 16;
        function.stack_slot_alignments[slot] = 16;
    }
    function.stack_slot_count = 3;
    return function;
}

// A zero-operand DIRECT pair used by the x86 exact-form migration tests.  The
// rows deliberately sit before RET so the encoder must emit both metadata
// forms in one ordinary placed function; no executable call is attempted
// because INT3 is intentionally a trap.
BUSTER_GLOBAL_LOCAL MachineFunction machine_test_build_exact_barrier_function(Arena* arena)
{
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_MFENCE});
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_INT3});
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
    return function;
}

// One physical-register fixture covering every migrated register-only DIRECT
// row.  Alternating RAX/R9 makes the REX.R/REX.B projections observable while
// the paired 32/64 and narrow-extension rows keep width projections exercised
// in one encode; ALU/IMUL rows use their tied destination in slot 1.
BUSTER_GLOBAL_LOCAL MachineFunction machine_test_build_exact_register_function(Arena* arena)
{
#define MACHINE_TEST_EXACT_PHYSICAL(reg) machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, (reg))
#define MACHINE_TEST_EXACT_UNARY(op_value, reg) \
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = (op_value), .operands = {MACHINE_TEST_EXACT_PHYSICAL(reg)}})
#define MACHINE_TEST_EXACT_BINARY(op_value, destination, source) \
    machine_builder_instruction(&builder,                                                                                 \
                                (MachineInstruction){.opcode = (op_value),                                             \
                                                     .operands = {MACHINE_TEST_EXACT_PHYSICAL(destination),            \
                                                                  MACHINE_TEST_EXACT_PHYSICAL(source)}})
#define MACHINE_TEST_EXACT_TIED(op_value, destination, source) \
    machine_builder_instruction(&builder,                                                                                 \
                                (MachineInstruction){.opcode = (op_value),                                             \
                                                     .operands = {MACHINE_TEST_EXACT_PHYSICAL(destination),            \
                                                                  MACHINE_TEST_EXACT_PHYSICAL(destination),            \
                                                                  MACHINE_TEST_EXACT_PHYSICAL(source)}})
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    machine_builder_block_begin(&builder);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_MOV_RR, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_MOV32_RR, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_MOVSX8_RR, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_MOVSX16_RR, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_MOVSX32_RR, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_MOVZX8_RR, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_MOVZX16_RR, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_ADD32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_ADD64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_SUB32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_SUB64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_AND32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_AND64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_OR32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_OR64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_XOR32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_XOR64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_IMUL32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_TIED(MACHINE_X64_IMUL64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_UNARY(MACHINE_X64_NEG32, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_UNARY(MACHINE_X64_NEG64, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_UNARY(MACHINE_X64_NOT32, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_UNARY(MACHINE_X64_NOT64, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_BSF32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_BSF64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_BSR32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_BSR64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_CMP32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_CMP64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_BINARY(MACHINE_X64_TEST_RR, MACHINE_X64_RAX, MACHINE_X64_R9);
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
#undef MACHINE_TEST_EXACT_TIED
#undef MACHINE_TEST_EXACT_BINARY
#undef MACHINE_TEST_EXACT_UNARY
#undef MACHINE_TEST_EXACT_PHYSICAL
    return function;
}

// The second exact DIRECT cohort exercises feature-gated POPCNT, the
// implicit-CL shifts, XMM/GPR payload projections, and synthesized fixed-RSP
// immediate operands. Physical RAX/RCX constraints mirror the selector rows;
// MOVQ and the stack rows carry their non-machine-visible payloads directly.
BUSTER_GLOBAL_LOCAL MachineFunction machine_test_build_exact_second_register_function(Arena* arena)
{
#define MACHINE_TEST_EXACT_SECOND_PHYSICAL(reg) machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, (reg))
#define MACHINE_TEST_EXACT_SECOND_BINARY(op_value, destination, source) \
    machine_builder_instruction(&builder,                                                                                 \
                                (MachineInstruction){.opcode = (op_value),                                             \
                                                     .operands = {MACHINE_TEST_EXACT_SECOND_PHYSICAL(destination),     \
                                                                  MACHINE_TEST_EXACT_SECOND_PHYSICAL(source)}})
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    machine_builder_block_begin(&builder);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_POPCNT32, MACHINE_X64_RAX, MACHINE_X64_R9);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_POPCNT64, MACHINE_X64_R9, MACHINE_X64_RAX);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_SHL32, MACHINE_X64_RAX, MACHINE_X64_RCX);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_SHL64, MACHINE_X64_RAX, MACHINE_X64_RCX);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_SAR32, MACHINE_X64_RAX, MACHINE_X64_RCX);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_SAR64, MACHINE_X64_RAX, MACHINE_X64_RCX);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_SHR32, MACHINE_X64_RAX, MACHINE_X64_RCX);
    MACHINE_TEST_EXACT_SECOND_BINARY(MACHINE_X64_SHR64, MACHINE_X64_RAX, MACHINE_X64_RCX);
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .opcode = MACHINE_X64_MOVQ_TO_XMM,
                                                      .payload = 0,
                                                      .operands = {MACHINE_TEST_EXACT_SECOND_PHYSICAL(MACHINE_X64_R9)},
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .opcode = MACHINE_X64_MOVQ_FROM_XMM,
                                                      .payload = 1,
                                                      .operands = {MACHINE_TEST_EXACT_SECOND_PHYSICAL(MACHINE_X64_RAX)},
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .opcode = MACHINE_X64_PUSH_REGISTER,
                                                      .operands = {MACHINE_TEST_EXACT_SECOND_PHYSICAL(MACHINE_X64_R9)},
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_ADD_RSP, .payload = 16});
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
#undef MACHINE_TEST_EXACT_SECOND_BINARY
#undef MACHINE_TEST_EXACT_SECOND_PHYSICAL
    return function;
}

// LOAD_INCOMING is the final direct recipe migrated to metadata.  Keep the
// incoming offsets at the legacy producer's boundary values: payload 0 gives
// the ordinary positive disp32, 112 reaches the disp8/disp32 boundary after
// the fixed frame prefix, and 128 exercises a larger displacement.  R9/R10
// make the REX.R destination projection observable alongside RAX.
BUSTER_GLOBAL_LOCAL MachineFunction machine_test_build_exact_load_incoming_function(Arena* arena)
{
#define MACHINE_TEST_LOAD_INCOMING_PHYSICAL(reg) machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, (reg))
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .opcode = MACHINE_X64_LOAD_INCOMING,
                                                      .payload = 0,
                                                      .operands = {MACHINE_TEST_LOAD_INCOMING_PHYSICAL(MACHINE_X64_RAX)},
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .opcode = MACHINE_X64_LOAD_INCOMING,
                                                      .payload = 112,
                                                      .operands = {MACHINE_TEST_LOAD_INCOMING_PHYSICAL(MACHINE_X64_R9)},
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .opcode = MACHINE_X64_LOAD_INCOMING,
                                                      .payload = 128,
                                                      .operands = {MACHINE_TEST_LOAD_INCOMING_PHYSICAL(MACHINE_X64_R10)},
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
#undef MACHINE_TEST_LOAD_INCOMING_PHYSICAL
    return function;
}

// Relative/symbolic DIRECT rows keep their canonical fixup streams: JMP is
// queried with a neutral rel32 and patched to its block, while LEA_SYMBOL is
// queried with a neutral RIP-relative AGEN and retained as a call-site row.
// The block order gives one forward and one backward branch, and the two
// destination registers make both low and extended REX.R projections visible.
BUSTER_GLOBAL_LOCAL MachineFunction machine_test_build_exact_relative_function(Arena* arena)
{
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .operands = {machine_ref_make(MACHINE_REF_BLOCK, 2)},
                                                      .opcode = MACHINE_X64_JMP,
                                                  });
    machine_builder_block_end(&builder, (MachineBlock){0});
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_R8)},
                                                      .payload = 1,
                                                      .opcode = MACHINE_X64_LEA_SYMBOL,
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)},
                                                      .payload = 0,
                                                      .opcode = MACHINE_X64_LEA_SYMBOL,
                                                  });
    machine_builder_instruction(&builder, (MachineInstruction){
                                                      .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1)},
                                                      .opcode = MACHINE_X64_JMP,
                                                  });
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
    function.call_target_count = 2;
    function.call_targets = arena_allocate(arena, IrSymbolId, function.call_target_count);
    function.call_targets[0] = (IrSymbolId){.value = 0};
    function.call_targets[1] = (IrSymbolId){.value = 1};
    return function;
}

typedef enum MachineAliasTestKind
{
    MACHINE_ALIAS_TEST_DISTINCT,
    MACHINE_ALIAS_TEST_OVERLAPPING,
    MACHINE_ALIAS_TEST_UNKNOWN_POINTER,
    MACHINE_ALIAS_TEST_CALL,
    MACHINE_ALIAS_TEST_ATOMIC,
    MACHINE_ALIAS_TEST_FENCE,
    MACHINE_ALIAS_TEST_AGGREGATE,
    MACHINE_ALIAS_TEST_UNCERTIFIED,
    MACHINE_ALIAS_TEST_SHORT_SLOT,
    MACHINE_ALIAS_TEST_INVALID_OFFSET,
    MACHINE_ALIAS_TEST_INCOMING,
    MACHINE_ALIAS_TEST_INCOMING_UNCERTIFIED,
    MACHINE_ALIAS_TEST_DISJOINT_RANGES,
    MACHINE_ALIAS_TEST_FOLDED_RANGES,
    MACHINE_ALIAS_TEST_MIXED_VOLATILE,
    MACHINE_ALIAS_TEST_VECTOR,
    MACHINE_ALIAS_TEST_COUNT,
} MachineAliasTestKind;

// Sixty-four live load results force the real pressure gate on both native
// targets. Balanced consumers can sink disjoint loads, while the intervening
// stores and unknown/barrier rows expose missing memory dependencies.
BUSTER_GLOBAL_LOCAL MachineFunction machine_test_alias_function(Arena* arena, bool aarch64, u32 variant)
{
    bool vector = variant == MACHINE_ALIAS_TEST_VECTOR;
    bool incoming = variant == MACHINE_ALIAS_TEST_INCOMING || variant == MACHINE_ALIAS_TEST_INCOMING_UNCERTIFIED;
    bool ranges = variant == MACHINE_ALIAS_TEST_DISJOINT_RANGES || variant == MACHINE_ALIAS_TEST_FOLDED_RANGES;
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    u32 pointer = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
        .definition_point = MACHINE_POINT_INVALID, .register_class = MACHINE_REGISTER_CLASS_GENERAL, .typed_origin = IR_ID_UNDERLYING_INVALID});
    machine_builder_block_parameter(&builder, (MachineBlockParameter){.virtual_register = pointer});
    machine_builder_block_begin(&builder);
    u32 values[64];
    for (u32 leaf = 0; leaf < BUSTER_ARRAY_LENGTH(values); leaf += 1)
    {
        u32 slot = variant == MACHINE_ALIAS_TEST_OVERLAPPING ? leaf / 4 : ranges ? leaf / 8 : leaf;
        u32 offset = variant == MACHINE_ALIAS_TEST_OVERLAPPING ? (leaf & 1u) * 4u : variant == MACHINE_ALIAS_TEST_INVALID_OFFSET ? UINT32_MAX :
                     ranges ? (leaf & 7u) * (variant == MACHINE_ALIAS_TEST_FOLDED_RANGES ? 64u : 8u) : 0;
        values[leaf] = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
            .definition_point = machine_point_make(builder.instructions.total_count, MACHINE_POINT_AFTER),
            .register_class = vector ? MACHINE_REGISTER_CLASS_VECTOR : MACHINE_REGISTER_CLASS_GENERAL, .typed_origin = IR_ID_UNDERLYING_INVALID});
        machine_builder_instruction(&builder, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[leaf]), incoming ? 0 : machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
            .payload = incoming ? (aarch64 ? 16u : 0u) + leaf * 8u : offset,
            .opcode = incoming ? (aarch64 ? MACHINE_A64_LOAD_INCOMING : MACHINE_X64_LOAD_INCOMING) :
                      vector ? MACHINE_X64_VLOAD_FRAME : aarch64 ? MACHINE_A64_LOAD_FRAME : MACHINE_X64_LOAD_FRAME});
        machine_builder_instruction(&builder, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[leaf])},
            .payload = offset, .opcode = vector ? MACHINE_X64_VSTORE_FRAME : aarch64 ? MACHINE_A64_STORE_FRAME64 : MACHINE_X64_STORE_FRAME64});
        if ((leaf == 15 || leaf == 31 || leaf == 47) &&
            ((variant >= MACHINE_ALIAS_TEST_UNKNOWN_POINTER && variant <= MACHINE_ALIAS_TEST_AGGREGATE) || incoming))
        {
            MachineInstruction inserted = {0};
            if (variant == MACHINE_ALIAS_TEST_UNKNOWN_POINTER || incoming)
            {
                inserted = (MachineInstruction){.opcode = aarch64 ? MACHINE_A64_STORE_PTR64 : MACHINE_X64_STORE_PTR64,
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[leaf])}};
            }
            else if (variant == MACHINE_ALIAS_TEST_CALL)
            {
                inserted = (MachineInstruction){.opcode = aarch64 ? MACHINE_A64_CALL_INDIRECT : MACHINE_X64_CALL_INDIRECT,
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer)}};
            }
            else if (variant == MACHINE_ALIAS_TEST_ATOMIC)
            {
                inserted = (MachineInstruction){.opcode = aarch64 ? MACHINE_A64_ATOMIC_STORE : MACHINE_X64_ATOMIC_STORE_XCHG, .payload = 8,
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[leaf])}};
            }
            else if (variant == MACHINE_ALIAS_TEST_FENCE)
            {
                inserted.opcode = aarch64 ? MACHINE_A64_ATOMIC_FENCE : MACHINE_X64_MFENCE;
            }
            else
            {
                inserted = (MachineInstruction){.opcode = aarch64 ? MACHINE_A64_COPY_FRAME_FROM_FRAME : MACHINE_X64_COPY_FRAME_FROM_FRAME,
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, 0), machine_ref_make(MACHINE_REF_STACK_SLOT, 63)}, .payload = 8};
            }
            machine_builder_instruction(&builder, inserted);
        }
    }
    // Pair values far apart in the source stream. A source-order memory
    // chain cannot place these pairs together without retaining other leaves.
    u32 reordered[64];
    for (u32 leaf = 0; leaf < 64; leaf += 1)
    {
        u32 reverse = 0;
        for (u32 bit = 0; bit < 6; bit += 1)
        {
            reverse = (reverse << 1) | ((leaf >> bit) & 1u);
        }
        reordered[leaf] = values[reverse];
    }
    memcpy(values, reordered, sizeof(values));
    for (u32 width = 64; width > 1; width /= 2)
    {
        for (u32 pair = 0; pair < width / 2; pair += 1)
        {
            u32 value = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
                .definition_point = machine_point_make(builder.instructions.total_count, MACHINE_POINT_AFTER),
                .register_class = vector ? MACHINE_REGISTER_CLASS_VECTOR : MACHINE_REGISTER_CLASS_GENERAL, .typed_origin = IR_ID_UNDERLYING_INVALID});
            machine_builder_instruction(&builder, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[2 * pair]),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[2 * pair + 1])},
                .opcode = vector ? MACHINE_X64_VBINARY : aarch64 ? MACHINE_A64_ADD64 : MACHINE_X64_ADD64, .payload = vector ? 0xefu : 0});
            values[pair] = value;
        }
    }
    machine_builder_instruction(&builder, (MachineInstruction){
        .operands = {machine_ref_make(vector ? MACHINE_REF_STACK_SLOT : MACHINE_REF_PHYSICAL_REGISTER, vector ? 64u : 0u),
                     machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[0])},
        .opcode = vector ? MACHINE_X64_VSTORE_FRAME : aarch64 ? MACHINE_A64_MOV_RR : MACHINE_X64_MOV_RR});
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = aarch64 ? MACHINE_A64_RET : MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){.parameter_count = 1});
    MachineFunction result = machine_function_builder_finish(arena, &builder);
    result.target = aarch64 ? machine_target_aarch64() : machine_target_x86_64();
    result.nonvolatile_memory_certified = variant != MACHINE_ALIAS_TEST_UNCERTIFIED && variant != MACHINE_ALIAS_TEST_INCOMING_UNCERTIFIED &&
                                            variant != MACHINE_ALIAS_TEST_MIXED_VOLATILE;
    result.stack_slot_count = 65;
    result.stack_slot_sizes = arena_allocate(arena, u32, result.stack_slot_count);
    for (u32 slot = 0; slot < result.stack_slot_count; slot += 1)
    {
        result.stack_slot_sizes[slot] = variant == MACHINE_ALIAS_TEST_SHORT_SLOT ? 4u : ranges ? 512u : vector ? 64u : 16u;
    }
    result.line_mark_count = result.instruction_count;
    result.line_marks = arena_allocate(arena, MachineLineMark, result.line_mark_count);
    for (u32 row = 0; row < result.instruction_count; row += 1)
    {
        result.line_marks[row] = (MachineLineMark){.row = row, .instruction = row};
    }
    if (variant == MACHINE_ALIAS_TEST_MIXED_VOLATILE)
    {
        IrInstruction* canonical_rows = arena_allocate(arena, IrInstruction, result.instruction_count);
        memset(canonical_rows, 0, result.instruction_count * sizeof(IrInstruction));
        canonical_rows[30].volatile_access = true;
        canonical_rows[63].volatile_access = true;
        canonical_rows[94].volatile_access = true;
        IrFunction canonical = {.instructions = canonical_rows, .instruction_count = result.instruction_count};
        machine_selection_certify_stack_memory(arena, &result, &canonical);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_stack_aliases(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    for (u32 architecture = 0; architecture < 2; architecture += 1)
    {
        u32 sizes[] = {0, 1, 7, 8, 16, 64, 65, UINT32_MAX};
        u32 offsets[] = {0, 1, 7, 8, 15, 56, 63, 64, UINT32_MAX - 7u, UINT32_MAX};
        for (u32 size_index = 0; size_index < BUSTER_ARRAY_LENGTH(sizes); size_index += 1)
        {
            MachineFunction proof_function = {.stack_slot_count = 1, .stack_slot_sizes = sizes + size_index};
            for (u32 offset_index = 0; offset_index < BUSTER_ARRAY_LENGTH(offsets); offset_index += 1)
            {
                MachineInstruction load = {.opcode = architecture ? MACHINE_A64_LOAD_FRAME : MACHINE_X64_LOAD_FRAME,
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0), machine_ref_make(MACHINE_REF_STACK_SLOT, 0)},
                    .payload = offsets[offset_index]};
                BUSTER_TEST(arguments, machine_schedule_memory_access(&proof_function, &load).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
                proof_function.nonvolatile_memory_certified = true;
                MachineScheduleMemoryAccess access = machine_schedule_memory_access(&proof_function, &load);
                bool bounded = (u64)load.payload + 8u <= sizes[size_index];
                BUSTER_TEST(arguments, (access.kind == MACHINE_SCHEDULE_MEMORY_STACK_RANGE) == bounded);
                BUSTER_TEST(arguments, !bounded || (access.stack_slot == 0 && access.offset == load.payload && access.size == 8));
                load.operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 1);
                BUSTER_TEST(arguments, machine_schedule_memory_access(&proof_function, &load).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
                load.operands[1] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0);
                BUSTER_TEST(arguments, machine_schedule_memory_access(&proof_function, &load).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
                proof_function.nonvolatile_memory_certified = false;
            }
        }
        u32 pointer_slot_size = 32;
        MachineVirtualRegister pointer_values[2] = {
            {.definition_point = machine_point_make(0, MACHINE_POINT_AFTER), .register_class = MACHINE_REGISTER_CLASS_GENERAL},
            {.definition_point = machine_point_make(1, MACHINE_POINT_AFTER), .register_class = MACHINE_REGISTER_CLASS_GENERAL},
        };
        MachineInstruction pointer_rows[2] = {
            {.opcode = architecture ? MACHINE_A64_LEA_FRAME : MACHINE_X64_LEA_FRAME, .payload = 8,
             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0), machine_ref_make(MACHINE_REF_STACK_SLOT, 0)}},
            {.opcode = architecture ? MACHINE_A64_LOAD_PTR64 : MACHINE_X64_LOAD_PTR64,
             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0)}},
        };
        MachineFunction pointer_function = {.instructions = pointer_rows, .instruction_count = 2,
            .virtual_registers = pointer_values, .virtual_register_count = 2, .stack_slot_sizes = &pointer_slot_size, .stack_slot_count = 1,
            .nonvolatile_memory_certified = true};
        MachineScheduleMemoryAccess pointer_access = machine_schedule_memory_access(&pointer_function, pointer_rows + 1);
        BUSTER_TEST(arguments, pointer_access.kind == MACHINE_SCHEDULE_MEMORY_STACK_RANGE && pointer_access.stack_slot == 0 &&
            pointer_access.offset == 8 && pointer_access.size == 8);
        pointer_values[0].flags = MACHINE_VIRTUAL_REGISTER_FLAG_MUTABLE;
        BUSTER_TEST(arguments, machine_schedule_memory_access(&pointer_function, pointer_rows + 1).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
        pointer_values[0].flags = 0;
        pointer_values[0].definition_point = MACHINE_POINT_INVALID;
        BUSTER_TEST(arguments, machine_schedule_memory_access(&pointer_function, pointer_rows + 1).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
        pointer_values[0].definition_point = machine_point_make(0, MACHINE_POINT_AFTER);
        pointer_rows[0].operands[0] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1);
        BUSTER_TEST(arguments, machine_schedule_memory_access(&pointer_function, pointer_rows + 1).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
        pointer_rows[0].operands[0] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0);
        IrInstruction volatile_pointer_source = {.volatile_access = true};
        IrFunction volatile_pointer_function = {.instructions = &volatile_pointer_source, .instruction_count = 1};
        MachineLineMark volatile_pointer_mark = {.row = 1, .instruction = 0};
        pointer_function.nonvolatile_memory_certified = false;
        pointer_function.line_marks = &volatile_pointer_mark;
        pointer_function.line_mark_count = 1;
        machine_selection_certify_stack_memory(arguments->arena, &pointer_function, &volatile_pointer_function);
        BUSTER_TEST(arguments, pointer_function.stack_slot_memory_flags && !pointer_function.stack_slot_memory_flags[0]);
        BUSTER_TEST(arguments, machine_schedule_memory_access(&pointer_function, pointer_rows + 1).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
        u16 incoming_opcode = architecture ? MACHINE_A64_LOAD_INCOMING : MACHINE_X64_LOAD_INCOMING;
        BUSTER_TEST(arguments, machine_opcode_memory_effect(machine_opcode_info(incoming_opcode)) == MACHINE_MEMORY_EFFECT_READ);
        BUSTER_TEST(arguments, (machine_opcode_row_table()[incoming_opcode].schedule_flags & MACHINE_SCHEDULE_UNIT_MEMORY) != 0);
        for (u32 variant = 0; variant < (architecture ? MACHINE_ALIAS_TEST_VECTOR : MACHINE_ALIAS_TEST_COUNT); variant += 1)
        {
            MachineFunction function = machine_test_alias_function(arguments->arena, architecture != 0, variant);
            BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_NONE);
            if (variant == MACHINE_ALIAS_TEST_MIXED_VOLATILE)
            {
                BUSTER_TEST(arguments, function.stack_slot_memory_flags != 0);
                for (u32 slot = 0; slot < function.stack_slot_count; slot += 1)
                {
                    BUSTER_TEST(arguments, function.stack_slot_memory_flags[slot] ==
                        (u32)(slot != 15 && slot != 31 && slot != 47));
                }
                function.stack_slot_memory_flags[0] = 2;
                BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_PAYLOAD);
                BUSTER_TEST(arguments, machine_schedule_memory_access(&function, function.instructions).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
                function.stack_slot_memory_flags[0] = MACHINE_STACK_SLOT_MEMORY_NONVOLATILE;
            }
            MachineScheduleResult scheduled = machine_schedule_function(arguments->arena, &function);
            MachineScheduleResult repeated = machine_schedule_function(arguments->arena, &function);
            BUSTER_TEST(arguments, scheduled.function.nonvolatile_memory_certified == function.nonvolatile_memory_certified);
            BUSTER_TEST(arguments, scheduled.function.stack_slot_memory_flags == function.stack_slot_memory_flags);
            BUSTER_TEST(arguments, scheduled.moved == repeated.moved &&
                memcmp(scheduled.function.instructions, repeated.function.instructions, function.instruction_count * sizeof(MachineInstruction)) == 0);
            BUSTER_TEST(arguments, machine_verify_function(&scheduled.function).error == MACHINE_VERIFY_NONE);
            u32* positions = arena_allocate(arguments->arena, u32, function.instruction_count);
            for (u32 mark = 0; mark < scheduled.function.line_mark_count; mark += 1)
            {
                MachineLineMark line = scheduled.function.line_marks[mark];
                positions[line.instruction] = line.row;
            }
            // Incoming reads are an independent oracle here, not inferred
            // solely from the metadata whose missing READ effect is tested.
            bool memory_order = true;
            bool independent_memory_moved = false;
            bool independent_range_moved = false;
            for (u32 first = 0; first < function.instruction_count; first += 1)
            {
                MachineInstruction* before = function.instructions + first;
                MachineOpcodeInfo const* before_info = machine_opcode_info(before->opcode);
                bool before_barrier = (before_info->attributes & (MACHINE_OPCODE_ATTRIBUTE_CALL | MACHINE_OPCODE_ATTRIBUTE_SIDE_EFFECTS |
                                                                  MACHINE_OPCODE_ATTRIBUTE_TERMINATOR)) != 0;
                bool before_memory = machine_opcode_is_memory(before_info);
                u32 before_slot = UINT32_MAX;
                if (machine_ref_kind(before->operands[0]) == MACHINE_REF_STACK_SLOT) before_slot = machine_ref_payload(before->operands[0]);
                if (machine_ref_kind(before->operands[1]) == MACHINE_REF_STACK_SLOT) before_slot = machine_ref_payload(before->operands[1]);
                for (u32 second = first + 1; second < function.instruction_count; second += 1)
                {
                    MachineInstruction* after = function.instructions + second;
                    MachineOpcodeInfo const* after_info = machine_opcode_info(after->opcode);
                    bool after_barrier = (after_info->attributes & (MACHINE_OPCODE_ATTRIBUTE_CALL | MACHINE_OPCODE_ATTRIBUTE_SIDE_EFFECTS |
                                                                    MACHINE_OPCODE_ATTRIBUTE_TERMINATOR)) != 0;
                    bool after_memory = machine_opcode_is_memory(after_info);
                    u32 after_slot = UINT32_MAX;
                    if (machine_ref_kind(after->operands[0]) == MACHINE_REF_STACK_SLOT) after_slot = machine_ref_payload(after->operands[0]);
                    if (machine_ref_kind(after->operands[1]) == MACHINE_REF_STACK_SLOT) after_slot = machine_ref_payload(after->operands[1]);
                    bool unknown = before_slot == UINT32_MAX || after_slot == UINT32_MAX ||
                                   before->opcode == MACHINE_X64_COPY_FRAME_FROM_FRAME || before->opcode == MACHINE_A64_COPY_FRAME_FROM_FRAME ||
                                   after->opcode == MACHINE_X64_COPY_FRAME_FROM_FRAME || after->opcode == MACHINE_A64_COPY_FRAME_FROM_FRAME;
                    // Independent byte-interval oracle: an overlapping byte
                    // must retain source order even across an eight-byte cell.
                    u32 access_size = variant == MACHINE_ALIAS_TEST_VECTOR ? 64u : 8u;
                    bool overlap = (u64)before->payload < (u64)after->payload + access_size &&
                                   (u64)after->payload < (u64)before->payload + access_size;
                    bool volatile_slot = variant == MACHINE_ALIAS_TEST_MIXED_VOLATILE &&
                        (before_slot == 15 || before_slot == 31 || before_slot == 47 || after_slot == 15 || after_slot == 31 || after_slot == 47);
                    bool ordered = before_barrier || after_barrier || (before_memory && after_memory &&
                                   (unknown || volatile_slot || (before_slot == after_slot && overlap) ||
                                    (!function.nonvolatile_memory_certified && !function.stack_slot_memory_flags) ||
                                    variant == MACHINE_ALIAS_TEST_SHORT_SLOT || variant == MACHINE_ALIAS_TEST_INVALID_OFFSET));
                    memory_order &= !ordered || positions[first] < positions[second];
                    independent_memory_moved |= before_memory && after_memory && !ordered && positions[first] > positions[second];
                    independent_range_moved |= before_memory && after_memory && before_slot == after_slot &&
                                               !ordered && positions[first] > positions[second];
                }
            }
            BUSTER_TEST(arguments, memory_order);
            if (variant == MACHINE_ALIAS_TEST_DISJOINT_RANGES)
            {
                BUSTER_TEST(arguments, independent_range_moved);
            }
            if (variant == MACHINE_ALIAS_TEST_FOLDED_RANGES)
            {
                BUSTER_TEST(arguments, !independent_range_moved);
            }
            if (variant == MACHINE_ALIAS_TEST_DISTINCT || variant == MACHINE_ALIAS_TEST_VECTOR || variant == MACHINE_ALIAS_TEST_DISJOINT_RANGES ||
                variant == MACHINE_ALIAS_TEST_MIXED_VOLATILE)
            {
                BUSTER_TEST(arguments, scheduled.moved && independent_memory_moved);
                MachineStackPlacement original_placement = machine_fast_placement_build(arguments->arena, &function);
                MachineStackPlacement new_placement = machine_fast_placement_build(arguments->arena, &scheduled.function);
                MachineStackPlacement repeated_placement = machine_fast_placement_build(arguments->arena, &repeated.function);
                BUSTER_TEST(arguments, original_placement.valid && new_placement.valid && repeated_placement.valid);
                BUSTER_TEST(arguments, new_placement.spill_count + new_placement.reload_count < original_placement.spill_count + original_placement.reload_count);
                BUSTER_TEST(arguments, new_placement.spill_count == repeated_placement.spill_count && new_placement.reload_count == repeated_placement.reload_count &&
                    new_placement.edit_count == repeated_placement.edit_count &&
                    memcmp(new_placement.edits, repeated_placement.edits, new_placement.edit_count * sizeof(MachineEdit)) == 0);
            }
            if (variant == MACHINE_ALIAS_TEST_DISTINCT || variant == MACHINE_ALIAS_TEST_MIXED_VOLATILE)
            {
                ByteSlice replay = machine_replay_serialize(arguments->arena, &function);
                MachineFunction restored = {.nonvolatile_memory_certified = true, .stack_slot_memory_flags = function.stack_slot_memory_flags};
                BUSTER_TEST(arguments, machine_replay_deserialize(arguments->arena, replay, &restored));
                BUSTER_TEST(arguments, !restored.nonvolatile_memory_certified);
                BUSTER_TEST(arguments, !restored.stack_slot_memory_flags);
            }
        }
        MachineFunction spans = machine_test_alias_function(arguments->arena, architecture != 0, MACHINE_ALIAS_TEST_DISTINCT);
        spans.nonvolatile_memory_certified = false;
        IrInstruction provenance_rows[3] = {{.volatile_access = true}, {0}, {.volatile_access = true}};
        IrFunction provenance = {.instructions = provenance_rows, .instruction_count = BUSTER_ARRAY_LENGTH(provenance_rows)};
        MachineLineMark source_marks[3] = {{.row = 0, .instruction = 0}, {.row = 2, .instruction = 1},
                                         {.row = spans.instruction_count, .instruction = 2}};
        spans.line_marks = source_marks;
        spans.line_mark_count = BUSTER_ARRAY_LENGTH(source_marks);
        machine_selection_certify_stack_memory(arguments->arena, &spans, &provenance);
        BUSTER_TEST(arguments, spans.stack_slot_memory_flags != 0);
        for (u32 slot = 0; slot < spans.stack_slot_count; slot += 1)
        {
            // Both rows lowered from the first volatile canonical operation
            // touch slot zero; a terminal zero-row mark touches no object.
            BUSTER_TEST(arguments, spans.stack_slot_memory_flags[slot] == (u32)(slot != 0));
        }
        source_marks[1].instruction = provenance.instruction_count;
        machine_selection_certify_stack_memory(arguments->arena, &spans, &provenance);
        BUSTER_TEST(arguments, !spans.stack_slot_memory_flags);
        source_marks[1].instruction = 1;
        source_marks[1].row = spans.instruction_count + 1;
        machine_selection_certify_stack_memory(arguments->arena, &spans, &provenance);
        BUSTER_TEST(arguments, !spans.stack_slot_memory_flags);
        source_marks[1].row = 0;
        source_marks[0].row = 1;
        machine_selection_certify_stack_memory(arguments->arena, &spans, &provenance);
        BUSTER_TEST(arguments, !spans.stack_slot_memory_flags);
        // A mutable block parameter already has an incoming definition, but
        // only one defining instruction. Preserve its old-value store before
        // the update and its new-value store afterward; textual def counts
        // alone cannot identify this anti-dependence.
        MachineFunction mutable = machine_test_alias_function(arguments->arena, architecture != 0, MACHINE_ALIAS_TEST_DISTINCT);
        MachineRef mutable_reference = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0);
        mutable.virtual_registers[0].flags = MACHINE_VIRTUAL_REGISTER_FLAG_MUTABLE;
        mutable.instructions[1].operands[1] = mutable_reference;
        mutable.instructions[65] = (MachineInstruction){.opcode = architecture ? MACHINE_A64_MOV_RR : MACHINE_X64_MOV_RR,
            .operands = {mutable_reference, mutable.instructions[64].operands[0]}};
        mutable.instructions[127].operands[1] = mutable_reference;
        BUSTER_TEST(arguments, machine_verify_function(&mutable).error == MACHINE_VERIFY_NONE);
        MachineScheduleResult mutable_schedule = machine_schedule_function(arguments->arena, &mutable);
        BUSTER_TEST(arguments, mutable_schedule.moved && machine_verify_function(&mutable_schedule.function).error == MACHINE_VERIFY_NONE);
        u32 mutable_positions[3] = {0};
        for (u32 mark = 0; mark < mutable_schedule.function.line_mark_count; mark += 1)
        {
            MachineLineMark line = mutable_schedule.function.line_marks[mark];
            if (line.instruction == 1) mutable_positions[0] = line.row;
            if (line.instruction == 65) mutable_positions[1] = line.row;
            if (line.instruction == 127) mutable_positions[2] = line.row;
        }
        BUSTER_TEST(arguments, mutable_positions[0] < mutable_positions[1] && mutable_positions[1] < mutable_positions[2]);
        MachineBlock oversized_block = {.instruction_count = UINT32_MAX};
        MachineFunction oversized = {.instruction_count = UINT32_MAX, .block_count = 1, .blocks = &oversized_block,
                                    .target = architecture ? machine_target_aarch64() : machine_target_x86_64()};
        BUSTER_TEST(arguments, !machine_schedule_function(arguments->arena, &oversized).moved);
        Target target = {.cpu_arch = architecture ? CPU_ARCH_AARCH64 : CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX};
        ByteSlice source = file_read(arguments->arena, S8("tests/basic_c_machine_alias.c"), (FileReadOptions){0});
        IrProgram* source_program = source.pointer ? machine_test_compile_c(arguments->arena, S8("machine-alias.c"),
            (String8){.pointer = (char8*)source.pointer, .length = source.length}, target) : 0;
        BUSTER_TEST(arguments, source_program && source_program->module_count);
        if (source_program && source_program->module_count)
        {
            IrFunction* source_function = machine_test_ir_function_find(source_program->modules, S8("alias_pressure"));
            MachineSelectResult selected = machine_select_canonical_function(arguments->arena, source_program, source_function, target);
            BUSTER_TEST(arguments, selected.supported && selected.function.nonvolatile_memory_certified);
            if (selected.supported)
            {
                MachineScheduleResult scheduled = machine_schedule_function(arguments->arena, &selected.function);
                MachineFunction conservative = selected.function;
                conservative.nonvolatile_memory_certified = false;
                MachineScheduleResult original = machine_schedule_function(arguments->arena, &conservative);
                MachineStackPlacement improved = machine_fast_placement_build(arguments->arena, &scheduled.function);
                MachineStackPlacement previous = machine_fast_placement_build(arguments->arena, &original.function);
                BUSTER_TEST(arguments, improved.valid && previous.valid);
                BUSTER_TEST(arguments, improved.spill_count + improved.reload_count < previous.spill_count + previous.reload_count);
            }
            String8 range_names[] = {S8("alias_range_pressure"), S8("alias_mixed_pressure")};
            for (u32 range_case = 0; range_case < BUSTER_ARRAY_LENGTH(range_names); range_case += 1)
            {
                IrFunction* range_function = machine_test_ir_function_find(source_program->modules, range_names[range_case]);
                MachineSelectResult range_selected = machine_select_canonical_function(arguments->arena, source_program, range_function, target);
                BUSTER_TEST(arguments, range_selected.supported && machine_verify_function(&range_selected.function).error == MACHINE_VERIFY_NONE);
                if (range_selected.supported)
                {
                    BUSTER_TEST(arguments, range_selected.function.nonvolatile_memory_certified == (range_case == 0));
                    if (range_case)
                    {
                        BUSTER_TEST(arguments, range_selected.function.stack_slot_memory_flags != 0);
                        u32 nonvolatile_slots = 0;
                        for (u32 slot = 0; slot < range_selected.function.stack_slot_count; slot += 1)
                        {
                            nonvolatile_slots += range_selected.function.stack_slot_memory_flags[slot] == MACHINE_STACK_SLOT_MEMORY_NONVOLATILE;
                        }
                        BUSTER_TEST(arguments, nonvolatile_slots && nonvolatile_slots < range_selected.function.stack_slot_count);
                    }
                    MachineScheduleResult ranged = machine_schedule_function(arguments->arena, &range_selected.function);
                    MachineFunction conservative = range_selected.function;
                    conservative.nonvolatile_memory_certified = false;
                    conservative.stack_slot_memory_flags = 0;
                    MachineScheduleResult original = machine_schedule_function(arguments->arena, &conservative);
                    MachineStackPlacement improved = machine_fast_placement_build(arguments->arena, &ranged.function);
                    MachineStackPlacement previous = machine_fast_placement_build(arguments->arena, &original.function);
                    arguments->show(arguments, S8("MACHINE_ALIAS_RANGE architecture={u32} mixed={u32} before_spill_reload={u32} after_spill_reload={u32}\n"),
                        architecture, range_case, previous.spill_count + previous.reload_count, improved.spill_count + improved.reload_count);
                    BUSTER_TEST(arguments, improved.valid && previous.valid);
                    BUSTER_TEST(arguments, improved.spill_count + improved.reload_count < previous.spill_count + previous.reload_count);
                }
            }
            IrFunction* volatile_fields = machine_test_ir_function_find(source_program->modules, S8("alias_volatile_fields"));
            MachineSelectResult fields_selected = machine_select_canonical_function(arguments->arena, source_program, volatile_fields, target);
            BUSTER_TEST(arguments, fields_selected.supported && !fields_selected.function.nonvolatile_memory_certified);
            if (fields_selected.supported)
            {
                u32 volatile_frame_accesses = 0;
                MachineFunction* fields = &fields_selected.function;
                for (u32 mark_index = 0; mark_index < fields->line_mark_count; mark_index += 1)
                {
                    MachineLineMark mark = fields->line_marks[mark_index];
                    if (volatile_fields->instructions[mark.instruction].volatile_access)
                    {
                        u32 end = mark_index + 1 < fields->line_mark_count ? fields->line_marks[mark_index + 1].row : fields->instruction_count;
                        for (u32 row = mark.row; row < end; row += 1)
                        {
                            if (machine_schedule_frame_access(fields, fields->instructions + row).kind == MACHINE_SCHEDULE_MEMORY_STACK_RANGE)
                            {
                                volatile_frame_accesses += 1;
                                BUSTER_TEST(arguments, machine_schedule_memory_access(fields, fields->instructions + row).kind == MACHINE_SCHEDULE_MEMORY_UNKNOWN);
                            }
                        }
                    }
                }
                BUSTER_TEST(arguments, volatile_frame_accesses >= 4);
                BUSTER_TEST(arguments, machine_verify_function(fields).error == MACHINE_VERIFY_NONE);
            }
        }
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* incoming_program = source.pointer ? machine_test_compile_c_with_options(temporary.arena, S8("machine-incoming.c"),
                (String8){.pointer = (char8*)source.pointer, .length = source.length}, target,
                (CIRLowerOptions){.disable_direct_ssa = memory_form != 0}) : 0;
            BUSTER_TEST(arguments, incoming_program && incoming_program->module_count == 1);
            if (incoming_program && incoming_program->module_count == 1)
            {
                IrModule* module = incoming_program->modules;
                BUSTER_TEST(arguments, ir_validate_canonical_module(incoming_program, module).error == IR_VALIDATION_NONE);
                IrFunction* incoming_function = machine_test_ir_function_find(module, S8("alias_incoming"));
                BUSTER_TEST(arguments, incoming_function != 0);
                if (incoming_function)
                {
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, incoming_program, incoming_function, target);
                    BUSTER_TEST(arguments, selected.supported && selected.function.nonvolatile_memory_certified);
                    if (selected.supported)
                    {
                        u32 incoming_count = 0;
                        u32 pointer_store_count = 0;
                        for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                        {
                            u32 opcode = selected.function.instructions[row].opcode;
                            incoming_count += opcode == incoming_opcode;
                            pointer_store_count += opcode == MACHINE_X64_STORE_PTR64 || opcode == MACHINE_A64_STORE_PTR64;
                        }
                        BUSTER_TEST(arguments, incoming_count >= 3 && pointer_store_count != 0);
                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        MachineScheduleResult scheduled = machine_schedule_function(temporary.arena, &selected.function);
                        BUSTER_TEST(arguments, machine_verify_function(&scheduled.function).error == MACHINE_VERIFY_NONE);
                        MachineStackPlacement placement = machine_fast_placement_build(temporary.arena, &scheduled.function);
                        BUSTER_TEST(arguments, placement.valid);
                    }
                }
            }
            scratch_end(temporary);
        }
        IrProgram* volatile_program = machine_test_compile_c(arguments->arena, S8("volatile-alias.c"),
            S8("unsigned long f(void) { volatile unsigned long a = 1, b = 2; a = b; return a + b; }"), target);
        BUSTER_TEST(arguments, volatile_program && volatile_program->module_count);
        if (volatile_program && volatile_program->module_count)
        {
            MachineSelectResult selected = machine_select_canonical_function(arguments->arena, volatile_program,
                machine_test_ir_function_find(volatile_program->modules, S8("f")), target);
            BUSTER_TEST(arguments, selected.supported && !selected.function.nonvolatile_memory_certified);
        }
        IrProgram* asm_program = machine_test_compile_c(arguments->arena, S8("asm-alias.c"),
            S8("unsigned long f(unsigned long *p) { unsigned long a = *p; __asm__ volatile (\"\" ::: \"memory\"); return a + *p; }"), target);
        BUSTER_TEST(arguments, asm_program && asm_program->module_count);
        if (asm_program && asm_program->module_count)
        {
            MachineSelectResult selected = machine_select_canonical_function(arguments->arena, asm_program,
                machine_test_ir_function_find(asm_program->modules, S8("f")), target);
            // The exact memory-only compiler barrier is selectable, but it
            // deliberately invalidates nonvolatile-memory certification.
            BUSTER_TEST(arguments, selected.supported && !selected.function.nonvolatile_memory_certified);
            if (selected.supported)
            {
                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
            }
        }
    }
    return result;
}

// Topology/remapping oracle, independent of the production outgoing index.
// Allocation and executable parallel-copy semantics remain covered by the
// registered basic_c_fast_ra_cfg and local-promotion mode-matrix fixtures.
BUSTER_GLOBAL_LOCAL u32 machine_test_split_target(MachineEdge const* edges, u32 edge_count, u32 const* split_ids,
                                                 u32 const* block_map, u32 source, u32 destination)
{
    u32 result = block_map[destination];
    for (u32 edge_index = 0; edge_index < edge_count; edge_index += 1)
    {
        if (edges[edge_index].source_block == source && edges[edge_index].destination_block == destination && split_ids[edge_index] != UINT32_MAX)
        {
            result = split_ids[edge_index];
            break;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_parameter_edge_split(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Arena* arena = arguments->arena;
    u64 start = arena->position;
    enum { BLOCK_COUNT = 7, ROW_COUNT = BLOCK_COUNT * 2, EDGE_COUNT = BLOCK_COUNT * 3, CASE_COUNT = BLOCK_COUNT * 3 };
    for (u32 architecture = 0; architecture < 2; architecture += 1)
    {
        MachineTargetDescription const* target = architecture ? machine_target_aarch64() : machine_target_x86_64();
        MachineFunction empty = {.target = target};
        BUSTER_TEST(arguments, machine_function_split_parameter_edges(arena, &empty));
        BUSTER_TEST(arguments, arena->position == start && empty.block_count == 0 && empty.edges == 0);
        {
            u8 x64_inline_bytes[] = {0xe9, 0, 0, 0, 0};
            u8 a64_inline_bytes[] = {0, 0, 0, 0x14};
            ByteSlice inline_bytes = architecture ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(a64_inline_bytes)
                                                  : (ByteSlice)BUSTER_ARRAY_TO_SLICE(x64_inline_bytes);
            MachineInstruction rows[] = {
                {.opcode = (u16)(architecture ? MACHINE_A64_BCC : MACHINE_X64_JCC),
                 .operands = {machine_ref_make(MACHINE_REF_BLOCK, 5), machine_ref_make(MACHINE_REF_BLOCK, 5)}},
                {.opcode = (u16)(architecture ? MACHINE_A64_INLINE_ASSEMBLY : MACHINE_X64_INLINE_ASSEMBLY)},
                {.opcode = target->unconditional_branch_opcode, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 5)}},
                {.opcode = target->unconditional_branch_opcode, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 5)}},
                {.opcode = target->unconditional_branch_opcode, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 5)}},
                {.opcode = (u16)(architecture ? MACHINE_A64_RET : MACHINE_X64_RET)},
            };
            MachineBlock blocks[] = {
                {.first_instruction = 0, .instruction_count = 1},
                {.first_instruction = 1, .instruction_count = 1},
                {.first_instruction = 2, .instruction_count = 1},
                {.first_instruction = 3, .instruction_count = 1},
                {.first_instruction = 4, .instruction_count = 1},
                {.first_instruction = 5, .instruction_count = 1},
            };
            MachineEdge edges[] = {
                {.source_block = 0, .destination_block = 5, .copy_count = 1},
                {.source_block = 1, .destination_block = 2},
                {.source_block = 1, .destination_block = 3},
                {.source_block = 1, .destination_block = 4},
                {.source_block = 2, .destination_block = 5},
                {.source_block = 3, .destination_block = 5},
                {.source_block = 4, .destination_block = 5},
            };
            MachineInlineAssemblyRelocation relocation = {
                .offset = architecture ? 0 : 1,
                .block = 5,
                .continuation_block = 4,
                .target_index = 1,
                .kind = (u8)(architecture ? ASSEMBLY_RELOCATION_AARCH64_BRANCH26 : ASSEMBLY_RELOCATION_X86_PC32),
                .is_block = true,
                .is_control = true,
            };
            MachineInlineAssembly assembly = {
                .bytes = inline_bytes,
                .relocation_count = 1,
                .effects = MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR,
                .successor_count = 3,
                .declared_successor_count = 2,
                .fallthrough_block = 2,
            };
            MachineFunction inline_split = {
                .instructions = rows,
                .instruction_count = BUSTER_ARRAY_LENGTH(rows),
                .blocks = blocks,
                .block_count = BUSTER_ARRAY_LENGTH(blocks),
                .edges = edges,
                .edge_count = BUSTER_ARRAY_LENGTH(edges),
                .inline_assemblies = &assembly,
                .inline_assembly_count = 1,
                .inline_assembly_relocations = &relocation,
                .inline_assembly_relocation_count = 1,
                .target = target,
            };
            BUSTER_TEST(arguments, machine_function_split_parameter_edges(arena, &inline_split));
            BUSTER_TEST(arguments, inline_split.block_count == 7 && inline_split.inline_assemblies != &assembly &&
                                       inline_split.inline_assembly_relocations != &relocation &&
                                       inline_split.inline_assemblies[0].fallthrough_block == 3 &&
                                       inline_split.inline_assemblies[0].successor_count == 3 &&
                                       inline_split.inline_assembly_relocations[0].block == 6 &&
                                       inline_split.inline_assembly_relocations[0].continuation_block == 5);
            arena_set_position(arena, start);
        }
        for (u32 variant = 0; variant < 16; variant += 1)
        {
            MachineInstruction rows[ROW_COUNT] = {0};
            MachineBlock blocks[BLOCK_COUNT] = {0};
            MachineEdge edges[EDGE_COUNT] = {0};
            MachineSwitchCase cases[CASE_COUNT] = {0};
            MachineVirtualRegister values[BLOCK_COUNT] = {0};
            MachineLineMark marks[ROW_COUNT + 2] = {0};
            MachineRef copies[] = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0),
                                   machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1)};
            MachineBlockParameter parameters[] = {{.virtual_register = 0}, {.virtual_register = 1}};
            u32 kinds[BLOCK_COUNT] = {0};
            u32 block_map[BLOCK_COUNT] = {0};
            u32 row_map[ROW_COUNT] = {0};
            u32 split_ids[EDGE_COUNT];
            memset(split_ids, 0xff, sizeof(split_ids));
            for (u32 block = 0; block < BLOCK_COUNT; block += 1)
            {
                // Conditional duplicate targets, switch duplicates, computed
                // labels, unconditional copies, backedges and missing pairs.
                u32 kind = variant ? block % 4u : 3u;
                kinds[block] = kind;
                u32 first = (block + 1u) % BLOCK_COUNT;
                u32 second = variant & 1u ? first : (block + 3u) % BLOCK_COUNT;
                blocks[block] = (MachineBlock){.first_instruction = block * 2u, .instruction_count = 2, .parameter_count = 2,
                                              .frequency_class = (u16)block};
                rows[block * 2u] = (MachineInstruction){.opcode = (u16)(architecture ? MACHINE_A64_LEA_BLOCK : MACHINE_X64_LEA_BLOCK),
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, block)}, .payload = first};
                MachineInstruction* branch = rows + block * 2u + 1u;
                if (kind == 0)
                {
                    *branch = (MachineInstruction){.opcode = (u16)(architecture ? MACHINE_A64_BCC : MACHINE_X64_JCC),
                        .operands = {machine_ref_make(MACHINE_REF_BLOCK, first), machine_ref_make(MACHINE_REF_BLOCK, second)}};
                }
                else if (kind == 1 || kind == 2)
                {
                    *branch = (MachineInstruction){.opcode = kind == 1 ? target->switch_opcode : (u16)(architecture ? MACHINE_A64_INDIRECT_BRANCH : MACHINE_X64_INDIRECT_BRANCH),
                        .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, 0)}, .payload = block * 3u, .flags = 3};
                    if (kind == 1) { branch->operands[1] = machine_ref_make(MACHINE_REF_BLOCK, second); }
                }
                else
                {
                    *branch = (MachineInstruction){.opcode = target->unconditional_branch_opcode,
                        .operands = {machine_ref_make(MACHINE_REF_BLOCK, first)}};
                }
                for (u32 slot = 0; slot < 3; slot += 1)
                {
                    u32 destination = slot == 1 ? second : first;
                    // An earlier no-copy duplicate must not hide a later split.
                    edges[block * 3u + slot] = (MachineEdge){.source_block = block, .destination_block = destination,
                        .copy_offset = slot == 1 ? 2u : 0u, .copy_count = (u16)(slot ? 2 : 0), .flags = (u16)(block * 3u + slot)};
                    cases[block * 3u + slot] = (MachineSwitchCase){.value = slot, .target_block = destination, .compare_width = 32};
                }
                values[block] = (MachineVirtualRegister){.definition_point = block ? machine_point_make(block * 2u, block & 1u ? MACHINE_POINT_AFTER : MACHINE_POINT_BEFORE) : MACHINE_POINT_INVALID,
                    .register_class = MACHINE_REGISTER_CLASS_GENERAL, .typed_origin = block + 11u};
            }
            u32 random = 0x31974adbu + variant;
            for (u32 count = EDGE_COUNT; count > 1; count -= 1)
            {
                random = random * 1664525u + 1013904223u;
                u32 other = random % count;
                MachineEdge swap = edges[count - 1u];
                edges[count - 1u] = edges[other];
                edges[other] = swap;
            }
            u32 edge_count = variant == 15 ? EDGE_COUNT / 3u : EDGE_COUNT;
            for (u32 row = 0; row <= ROW_COUNT; row += 1) { marks[row] = (MachineLineMark){.row = row, .instruction = row + 17u}; }
            marks[ROW_COUNT + 1] = marks[ROW_COUNT];
            MachineFunction function = {.instructions = rows, .instruction_count = ROW_COUNT, .blocks = blocks, .block_count = BLOCK_COUNT,
                .edges = edges, .edge_count = edge_count, .switch_cases = cases, .switch_case_count = CASE_COUNT,
                .virtual_registers = values, .virtual_register_count = BLOCK_COUNT, .line_marks = marks, .line_mark_count = ROW_COUNT + 2,
                .edge_copy_sources = copies, .edge_copy_source_count = BUSTER_ARRAY_LENGTH(copies),
                .block_parameters = parameters, .block_parameter_count = BUSTER_ARRAY_LENGTH(parameters), .target = target};
            u32 expected_blocks = 0;
            for (u32 block = 0; block < BLOCK_COUNT; block += 1)
            {
                block_map[block] = expected_blocks++;
                for (u32 edge = 0; edge < edge_count; edge += 1)
                {
                    if (edges[edge].source_block == block && edges[edge].copy_count && kinds[block] != 3)
                    {
                        split_ids[edge] = expected_blocks++;
                    }
                }
            }
            u32 split_count = expected_blocks - BLOCK_COUNT;
            MachineInstruction expected_rows[ROW_COUNT + EDGE_COUNT] = {0};
            MachineBlock expected_block_rows[BLOCK_COUNT + EDGE_COUNT] = {0};
            MachineEdge expected_edges[EDGE_COUNT * 2] = {0};
            MachineSwitchCase expected_cases[CASE_COUNT];
            memcpy(expected_cases, cases, sizeof(cases));
            u32 row_cursor = 0;
            for (u32 block = 0; block < BLOCK_COUNT; block += 1)
            {
                expected_block_rows[block_map[block]] = blocks[block];
                expected_block_rows[block_map[block]].first_instruction = row_cursor;
                for (u32 offset = 0; offset < 2; offset += 1)
                {
                    u32 row = block * 2u + offset;
                    row_map[row] = row_cursor;
                    MachineInstruction copy = rows[row];
                    if (offset == 0) { copy.payload = block_map[copy.payload]; }
                    for (u32 slot = 0; slot < MACHINE_INSTRUCTION_OPERAND_COUNT; slot += 1)
                    {
                        if (machine_ref_kind(copy.operands[slot]) == MACHINE_REF_BLOCK)
                        {
                            u32 destination = machine_ref_payload(copy.operands[slot]);
                            copy.operands[slot] = machine_ref_make(MACHINE_REF_BLOCK,
                                machine_test_split_target(edges, edge_count, split_ids, block_map, block, destination));
                        }
                    }
                    expected_rows[row_cursor++] = copy;
                }
                if (kinds[block] == 1 || kinds[block] == 2)
                {
                    for (u32 slot = 0; slot < 3; slot += 1)
                    {
                        MachineSwitchCase* item = expected_cases + block * 3u + slot;
                        item->target_block = machine_test_split_target(edges, edge_count, split_ids, block_map, block, item->target_block);
                    }
                }
                for (u32 edge = 0; edge < edge_count; edge += 1)
                {
                    if (edges[edge].source_block == block && split_ids[edge] != UINT32_MAX)
                    {
                        expected_block_rows[split_ids[edge]] = (MachineBlock){.first_instruction = row_cursor, .instruction_count = 1};
                        expected_rows[row_cursor++] = (MachineInstruction){.opcode = target->unconditional_branch_opcode,
                            .operands = {machine_ref_make(MACHINE_REF_BLOCK, block_map[edges[edge].destination_block])}};
                    }
                }
            }
            u32 edge_cursor = 0;
            for (u32 edge = 0; edge < edge_count; edge += 1)
            {
                MachineEdge copy = edges[edge];
                copy.source_block = block_map[copy.source_block];
                copy.destination_block = block_map[copy.destination_block];
                if (split_ids[edge] != UINT32_MAX)
                {
                    MachineEdge first = copy;
                    first.destination_block = split_ids[edge];
                    first.copy_count = 0;
                    expected_edges[edge_cursor++] = first;
                    copy.source_block = split_ids[edge];
                }
                expected_edges[edge_cursor++] = copy;
            }
            bool valid = machine_function_split_parameter_edges(arena, &function);
            BUSTER_TEST(arguments, valid);
            BUSTER_TEST(arguments, function.block_count == expected_blocks && function.instruction_count == row_cursor && function.edge_count == edge_cursor);
            u64 retained = arena->position - start;
            u64 output_bytes = (u64)row_cursor * sizeof(MachineInstruction) + (u64)expected_blocks * sizeof(MachineBlock) +
                               (u64)edge_cursor * sizeof(MachineEdge) + sizeof(cases);
            BUSTER_TEST(arguments, split_count ? retained >= output_bytes && retained <= output_bytes + 64u : retained == 0);
            // Poison every reclaimed mapping/index word before examining output.
            u32* poison = arena_allocate(arena, u32, ROW_COUNT + 2u * EDGE_COUNT + 3u * BLOCK_COUNT + 16u);
            memset(poison, 0xa5, (ROW_COUNT + 2u * EDGE_COUNT + 3u * BLOCK_COUNT + 16u) * sizeof(u32));
            if (valid && function.block_count == expected_blocks && function.instruction_count == row_cursor && function.edge_count == edge_cursor)
            {
                BUSTER_TEST(arguments, memcmp(function.instructions, expected_rows, (u64)row_cursor * sizeof(MachineInstruction)) == 0);
                BUSTER_TEST(arguments, memcmp(function.blocks, expected_block_rows, (u64)expected_blocks * sizeof(MachineBlock)) == 0);
                BUSTER_TEST(arguments, memcmp(function.edges, expected_edges, (u64)edge_cursor * sizeof(MachineEdge)) == 0);
                BUSTER_TEST(arguments, memcmp(function.switch_cases, expected_cases, sizeof(cases)) == 0);
                BUSTER_TEST(arguments, function.edge_copy_sources == copies && function.block_parameters == parameters);
                BUSTER_TEST(arguments, copies[0] == machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1) && copies[1] == machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0) &&
                                       copies[2] == machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0) && copies[3] == machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1));
                for (u32 value = 0; value < BLOCK_COUNT; value += 1)
                {
                    BUSTER_TEST(arguments, values[value].definition_point == (value ? machine_point_make(row_map[value * 2u], value & 1u ? MACHINE_POINT_AFTER : MACHINE_POINT_BEFORE) : MACHINE_POINT_INVALID));
                    BUSTER_TEST(arguments, values[value].typed_origin == value + 11u);
                }
                for (u32 row = 0; row <= ROW_COUNT; row += 1)
                {
                    BUSTER_TEST(arguments, marks[row].row == (row < ROW_COUNT ? row_map[row] : row_cursor) && marks[row].instruction == row + 17u);
                }
                BUSTER_TEST(arguments, marks[ROW_COUNT + 1].row == row_cursor);
                u64 before_repeat = arena->position;
                MachineInstruction* published = function.instructions;
                BUSTER_TEST(arguments, machine_function_split_parameter_edges(arena, &function));
                BUSTER_TEST(arguments, arena->position == before_repeat && function.instructions == published);
            }
            arena_set_position(arena, start);
        }
        // Large chain/fanout controls use direct formulas, not a quadratic oracle.
        u32 sizes[] = {2, 257, 4097};
        for (u32 size = 0; size < BUSTER_ARRAY_LENGTH(sizes); size += 1)
        {
            for (u32 chain = 0; chain < 2; chain += 1)
            {
                u32 block_count = sizes[size];
                u32 edge_count = block_count - 1u;
                MachineFunction function = {.target = target, .block_count = block_count, .instruction_count = block_count,
                    .edge_count = edge_count, .switch_case_count = chain ? 0 : edge_count};
                function.blocks = arena_allocate(arena, MachineBlock, block_count);
                function.instructions = arena_allocate(arena, MachineInstruction, block_count);
                function.edges = arena_allocate(arena, MachineEdge, edge_count);
                function.switch_cases = arena_allocate(arena, MachineSwitchCase, function.switch_case_count);
                for (u32 block = 0; block < block_count; block += 1)
                {
                    function.blocks[block] = (MachineBlock){.first_instruction = block, .instruction_count = 1};
                    function.instructions[block] = (MachineInstruction){.opcode = (u16)(architecture ? MACHINE_A64_RET : MACHINE_X64_RET)};
                }
                if (chain)
                {
                    for (u32 block = 0; block < edge_count; block += 1)
                    {
                        MachineRef next = machine_ref_make(MACHINE_REF_BLOCK, block + 1u);
                        function.instructions[block] = (MachineInstruction){.opcode = (u16)(architecture ? MACHINE_A64_BCC : MACHINE_X64_JCC), .operands = {next, next}};
                    }
                }
                else
                {
                    function.instructions[0] = (MachineInstruction){.opcode = target->switch_opcode, .flags = (u16)edge_count,
                        .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, 0), machine_ref_make(MACHINE_REF_BLOCK, 1)}};
                }
                for (u32 edge = 0; edge < edge_count; edge += 1)
                {
                    function.edges[edge] = (MachineEdge){.source_block = chain ? edge_count - edge - 1u : 0, .destination_block = edge_count - edge, .copy_count = 1};
                    if (!chain) { function.switch_cases[edge] = (MachineSwitchCase){.value = edge, .target_block = edge + 1u}; }
                }
                u64 before_split = arena->position;
                if (edge_count > 1)
                {
                    MachineEdge saved = function.edges[0];
                    MachineInstruction* original = function.instructions;
                    for (u32 endpoint = 0; endpoint < 2; endpoint += 1)
                    {
                        function.edges[0] = saved;
                        if (endpoint == 0) { function.edges[0].source_block = block_count; }
                        else { function.edges[0].destination_block = block_count; }
                        BUSTER_TEST(arguments, !machine_function_split_parameter_edges(arena, &function));
                        BUSTER_TEST(arguments, function.instructions == original && function.block_count == block_count);
                        arena_set_position(arena, before_split);
                    }
                    function.edges[0] = saved;
                }
                bool valid = machine_function_split_parameter_edges(arena, &function);
                BUSTER_TEST(arguments, valid);
                BUSTER_TEST(arguments, function.block_count == block_count + edge_count && function.edge_count == 2u * edge_count);
                u64 expected_bytes = (u64)(block_count + edge_count) * (sizeof(MachineInstruction) + sizeof(MachineBlock)) +
                                     (u64)edge_count * 2u * sizeof(MachineEdge) + (u64)function.switch_case_count * sizeof(MachineSwitchCase);
                BUSTER_TEST(arguments, arena->position - before_split >= expected_bytes && arena->position - before_split <= expected_bytes + 64u);
                if (valid && function.block_count == block_count + edge_count && function.edge_count == 2u * edge_count)
                {
                    BUSTER_TEST(arguments, machine_ref_payload(function.instructions[0].operands[1]) == (chain ? 1u : edge_count));
                    for (u32 edge = 0; edge < edge_count; edge += 1)
                    {
                        u32 source = chain ? 2u * (edge_count - edge - 1u) : 0;
                        u32 split = chain ? source + 1u : edge + 1u;
                        u32 destination = chain ? 2u * (edge_count - edge) : 2u * edge_count - edge;
                        BUSTER_TEST(arguments, function.edges[edge * 2u].source_block == source && function.edges[edge * 2u].destination_block == split && function.edges[edge * 2u].copy_count == 0);
                        BUSTER_TEST(arguments, function.edges[edge * 2u + 1u].source_block == split && function.edges[edge * 2u + 1u].destination_block == destination && function.edges[edge * 2u + 1u].copy_count == 1);
                        BUSTER_TEST(arguments, function.instructions[split].opcode == target->unconditional_branch_opcode && machine_ref_payload(function.instructions[split].operands[0]) == destination);
                        if (!chain)
                        {
                            BUSTER_TEST(arguments, function.switch_cases[edge].target_block == edge_count - edge && function.switch_cases[edge].value == edge);
                        }
                    }
                }
                arena_set_position(arena, start);
            }
        }
    }
    return result;
}

// The linear oracle is intentionally test-only. Raw edge order need not agree
// with block order, and duplicate pairs must keep the first edge, not the last.
BUSTER_GLOBAL_LOCAL u32 machine_test_first_edge(MachineFunction const* function, u32 source, u32 destination)
{
    u32 result = UINT32_MAX;
    for (u32 edge_index = 0; edge_index < function->edge_count; edge_index += 1)
    {
        MachineEdge const* edge = function->edges + edge_index;
        if (edge->source_block == source && edge->destination_block == destination)
        {
            result = edge_index;
            break;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_fast_edge_index(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Arena* arena = arguments->arena;
    u64 start = arena->position;
    for (u32 target_index = 0; target_index < 2; target_index += 1)
    {
        for (u32 variant = 0; variant < 6; variant += 1)
        {
            u32 block_count = 37;
            MachineFunction function = {0};
            function.target = target_index ? machine_target_aarch64() : machine_target_x86_64();
            function.block_count = block_count;
            function.instruction_count = block_count;
            function.blocks = arena_allocate(arena, MachineBlock, block_count);
            function.instructions = arena_allocate(arena, MachineInstruction, block_count);
            function.edges = arena_allocate(arena, MachineEdge, (u64)block_count * 3u);
            for (u32 block_index = 0; block_index < block_count; block_index += 1)
            {
                function.blocks[block_index] = (MachineBlock){.first_instruction = block_index, .instruction_count = 1};
                u32 targets[2] = {(block_index + 1u) % block_count, (block_index * 7u + 3u) % block_count};
                // Includes duplicate branch targets, self loops, joins, forward
                // and backward edges, and conditional sources of critical edges.
                targets[1] = variant == 1 ? targets[0] : targets[1];
                function.instructions[block_index] = (MachineInstruction){
                    .opcode = (u16)(target_index ? MACHINE_A64_BCC : MACHINE_X64_JCC),
                    .operands = {machine_ref_make(MACHINE_REF_BLOCK, targets[0]), machine_ref_make(MACHINE_REF_BLOCK, targets[1])},
                };
                for (u32 slot = 0; slot < 2; slot += 1)
                {
                    function.edges[function.edge_count++] = (MachineEdge){.source_block = block_index, .destination_block = targets[slot]};
                }
                // Distinct payloads expose accidental last-match semantics even
                // though this indexing-only fixture needs no parameter copies.
                function.edges[function.edge_count++] = (MachineEdge){.source_block = block_index, .destination_block = targets[0], .copy_offset = 1};
            }
            u32 random = 0x31974adbu + variant;
            for (u32 count = function.edge_count; count > 1; count -= 1)
            {
                random = random * 1664525u + 1013904223u;
                u32 other = random % count;
                MachineEdge temporary = function.edges[count - 1u];
                function.edges[count - 1u] = function.edges[other];
                function.edges[other] = temporary;
            }
            if (variant == 2)
            {
                // A nonempty raw table can still lack a queried pair.
                function.edge_count /= 3u;
            }
            else if (variant == 3)
            {
                function.edge_count = 0;
                function.edges = 0;
            }
            else if (variant == 4)
            {
                function.edges[0].source_block = block_count;
            }
            else if (variant == 5)
            {
                function.edges[0].destination_block = block_count;
            }
            u64 prepass_start = arena->position;
            for (u32 quality = 0; quality < 2; quality += 1)
            {
                MachineFastPrepass prepass = machine_fast_prepass_build(arena, &function, quality != 0);
                BUSTER_TEST(arguments, prepass.valid == (variant < 4));
                if (prepass.valid)
                {
                    BUSTER_TEST(arguments, (prepass.predecessor_edges != 0) == (function.edge_count != 0));
                    BUSTER_TEST(arguments, (prepass.terminator_edges != 0) == (function.edge_count != 0));
                    BUSTER_TEST(arguments, prepass.predecessor_offsets[block_count] == 2u * block_count);
                    if (function.edge_count)
                    {
                        // Overwrite reclaimed CSR scratch before reading the
                        // persistent query results: no result may alias scratch.
                        u32* overwrite = arena_allocate(arena, u32, block_count * 8u);
                        memset(overwrite, 0xa5, (u64)block_count * 8u * sizeof(u32));
                        for (u32 destination = 0; destination < block_count; destination += 1)
                        {
                            for (u32 predecessor_index = prepass.predecessor_offsets[destination];
                                 predecessor_index < prepass.predecessor_offsets[destination + 1u]; predecessor_index += 1)
                            {
                                u32 source = prepass.predecessor_list[predecessor_index];
                                BUSTER_TEST(arguments, prepass.predecessor_edges[predecessor_index] == machine_test_first_edge(&function, source, destination));
                            }
                        }
                        for (u32 source = 0; source < block_count; source += 1)
                        {
                            for (u32 slot = 0; slot < 2; slot += 1)
                            {
                                u32 destination = machine_ref_payload(function.instructions[source].operands[slot]);
                                BUSTER_TEST(arguments, prepass.terminator_edges[(u64)source * MACHINE_INSTRUCTION_OPERAND_COUNT + slot] ==
                                                          machine_test_first_edge(&function, source, destination));
                            }
                        }
                    }
                    MachineStackPlacement placement = machine_fast_placement_build_prepassed(arena, &function, &prepass, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    BUSTER_TEST(arguments, placement.valid && !placement.edit_count && !placement.frame_size);
                }
                arena_set_position(arena, prepass_start);
            }
            arena_set_position(arena, start);
        }
    }
    // Four times as many blocks must retain only four times the prepass
    // storage. Reverse-ordered raw edges were quadratic at the four old call
    // sites. Check every result directly rather than making this test's oracle
    // quadratic too. No noisy wall-clock threshold belongs in this gate.
    for (u32 fanout = 0; fanout < 2; fanout += 1)
    {
        u64 previous_bytes = 0;
        for (u32 block_count = 256; block_count <= 1024; block_count *= 4u)
        {
            MachineFunction function = {0};
            function.target = machine_target_x86_64();
            function.block_count = function.instruction_count = block_count;
            function.edge_count = block_count - 1u;
            function.blocks = arena_allocate(arena, MachineBlock, block_count);
            function.instructions = arena_allocate(arena, MachineInstruction, block_count);
            function.edges = arena_allocate(arena, MachineEdge, function.edge_count);
            for (u32 block_index = 0; block_index < block_count; block_index += 1)
            {
                function.blocks[block_index] = (MachineBlock){.first_instruction = block_index, .instruction_count = 1};
                function.instructions[block_index] = (MachineInstruction){.opcode = MACHINE_X64_RET};
                if (block_index + 1u < block_count)
                {
                    function.instructions[block_index].opcode = MACHINE_X64_JMP;
                    function.instructions[block_index].operands[0] = machine_ref_make(MACHINE_REF_BLOCK, block_index + 1u);
                    function.edges[block_count - 2u - block_index] = (MachineEdge){.source_block = block_index, .destination_block = block_index + 1u};
                }
            }
            if (fanout)
            {
                function.switch_case_count = block_count - 1u;
                function.switch_cases = arena_allocate(arena, MachineSwitchCase, function.switch_case_count);
                function.instructions[0] = (MachineInstruction){
                    .opcode = MACHINE_X64_INDIRECT_BRANCH,
                    .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)},
                    .flags = (u16)(block_count - 1u),
                };
                for (u32 destination = 1; destination < block_count; destination += 1)
                {
                    function.instructions[destination] = (MachineInstruction){.opcode = MACHINE_X64_RET};
                    function.switch_cases[destination - 1u] = (MachineSwitchCase){.target_block = destination};
                    function.edges[block_count - 1u - destination] = (MachineEdge){.source_block = 0, .destination_block = destination};
                }
            }
            u64 before = arena->position;
            MachineFastPrepass prepass = machine_fast_prepass_build(arena, &function, false);
            u64 bytes = arena->position - before;
            BUSTER_TEST(arguments, prepass.valid && bytes <= (u64)block_count * 48u + 256u);
            BUSTER_TEST(arguments, !previous_bytes || bytes <= previous_bytes * 4u + 256u);
            for (u32 source = 0; source + 1u < block_count; source += 1)
            {
                BUSTER_TEST(arguments, prepass.predecessor_edges[prepass.predecessor_offsets[source + 1u]] == block_count - 2u - source);
                if (!fanout)
                {
                    BUSTER_TEST(arguments, prepass.terminator_edges[(u64)source * MACHINE_INSTRUCTION_OPERAND_COUNT] == block_count - 2u - source);
                }
            }
            MachineStackPlacement placement = machine_fast_placement_build_prepassed(arena, &function, &prepass, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            BUSTER_TEST(arguments, placement.valid && !placement.edit_count && !placement.frame_size);
            previous_bytes = bytes;
            arena_set_position(arena, start);
        }
    }
    return result;
}

// Frame objects whose touched rows miss each other share storage; the ones
// whose storage has to outlive their rows do not. The first fixture writes and
// reads slot zero, then slot one, in one straight-line block — disjoint ranges
// — and hands slot two's address to a register, which puts every later read of
// it out of the rows' reach. The second puts a slot's only rows on both sides
// of a backward edge, so a loop re-executes the rows between them. The final
// fixture drives two disjoint waves of non-rematerializable values across block
// boundaries and requires their allocator-created homes to reuse offsets.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_frame_storage_reuse(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Arena* arena = arguments->arena;
    u32 slot_count = 4;
    u32 value_count = 5;
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    MachineRef values[5];
    u32 definition_rows[5] = {0, 2, 4, 5, 7};
    for (u32 index = 0; index < value_count; index += 1)
    {
        u32 value = machine_builder_virtual_register(
            &builder, (MachineVirtualRegister){.definition_point = machine_point_make(definition_rows[index], MACHINE_POINT_AFTER),
                                               .register_class = MACHINE_REGISTER_CLASS_GENERAL});
        values[index] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value);
    }
    machine_builder_block_begin(&builder);
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_MOV_RI,
                                                               .operands = {values[0], machine_ref_make(MACHINE_REF_IMMEDIATE, 0)}});
    for (u32 slot = 0; slot < 2; slot += 1)
    {
        machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_STORE_FRAME64,
                                                                   .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot), values[slot]}});
        machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_LOAD_FRAME,
                                                                   .operands = {values[slot + 1u], machine_ref_make(MACHINE_REF_STACK_SLOT, slot)}});
    }
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_LEA_FRAME,
                                                               .operands = {values[3], machine_ref_make(MACHINE_REF_STACK_SLOT, 2)}});
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_STORE_FRAME64,
                                                               .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, 3), values[3]}});
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_LOAD_FRAME,
                                                               .operands = {values[4], machine_ref_make(MACHINE_REF_STACK_SLOT, 3)}});
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
    function.immediates = arena_allocate(arena, u64, 1);
    function.immediate_count = 1;
    function.stack_slot_sizes = arena_allocate(arena, u32, slot_count);
    function.stack_slot_alignments = arena_allocate(arena, u32, slot_count);
    for (u32 slot = 0; slot < slot_count; slot += 1)
    {
        function.stack_slot_sizes[slot] = 8;
        function.stack_slot_alignments[slot] = 8;
    }
    function.stack_slot_count = slot_count;
    // The selectors certify this; a hand-built function has to say so itself,
    // and an uncertified one must keep one object per storage.
    function.returns_twice_absence_certified = true;
    BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement dedicated = machine_stack_placement_build(arena, &function);
    MachineStackPlacement reused = machine_fast_placement_build(arena, &function);
    BUSTER_TEST(arguments, dedicated.valid && reused.valid);
    BUSTER_TEST(arguments, dedicated.stack_slot_offsets[0] != dedicated.stack_slot_offsets[1] &&
                               dedicated.stack_slot_offsets[0] != dedicated.stack_slot_offsets[3]);
    BUSTER_TEST(arguments, reused.stack_slot_offsets[0] == reused.stack_slot_offsets[1] &&
                               reused.stack_slot_offsets[0] == reused.stack_slot_offsets[3]);
    BUSTER_TEST(arguments, reused.stack_slot_offsets[2] != reused.stack_slot_offsets[0]);
    BUSTER_TEST(arguments, reused.frame_size < dedicated.frame_size);
    function.returns_twice_absence_certified = false;
    MachineStackPlacement uncertified = machine_fast_placement_build(arena, &function);
    BUSTER_TEST(arguments, uncertified.valid && uncertified.stack_slot_offsets[0] != uncertified.stack_slot_offsets[1]);

    // Slot zero is written before the loop and read after it, so the loop can
    // re-execute every row between — including slot one's — and the two ranges
    // that look disjoint in row order are not.
    MachineFunctionBuilder loop_builder = machine_function_builder_begin(arena);
    MachineRef loop_values[3];
    u32 loop_definition_rows[3] = {0, 4, 6};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(loop_values); index += 1)
    {
        u32 loop_value = machine_builder_virtual_register(
            &loop_builder, (MachineVirtualRegister){.definition_point = machine_point_make(loop_definition_rows[index], MACHINE_POINT_AFTER),
                                                    .register_class = MACHINE_REGISTER_CLASS_GENERAL});
        loop_values[index] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, loop_value);
    }
    machine_builder_block_begin(&loop_builder);
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_MOV_RI,
                                                                    .operands = {loop_values[0], machine_ref_make(MACHINE_REF_IMMEDIATE, 0)}});
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_STORE_FRAME64,
                                                                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, 0), loop_values[0]}});
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_JMP,
                                                                    .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1)}});
    machine_builder_block_end(&loop_builder, (MachineBlock){0});
    machine_builder_block_begin(&loop_builder);
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_STORE_FRAME64,
                                                                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, 1), loop_values[0]}});
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_LOAD_FRAME,
                                                                    .operands = {loop_values[1], machine_ref_make(MACHINE_REF_STACK_SLOT, 1)}});
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_JMP,
                                                                    .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1)}});
    machine_builder_block_end(&loop_builder, (MachineBlock){0});
    machine_builder_block_begin(&loop_builder);
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_LOAD_FRAME,
                                                                    .operands = {loop_values[2], machine_ref_make(MACHINE_REF_STACK_SLOT, 0)}});
    machine_builder_instruction(&loop_builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&loop_builder, (MachineBlock){0});
    MachineFunction loop_function = machine_function_builder_finish(arena, &loop_builder);
    loop_function.target = machine_target_x86_64();
    loop_function.immediates = arena_allocate(arena, u64, 1);
    loop_function.immediate_count = 1;
    loop_function.stack_slot_sizes = arena_allocate(arena, u32, 2);
    loop_function.stack_slot_alignments = arena_allocate(arena, u32, 2);
    for (u32 slot = 0; slot < 2; slot += 1)
    {
        loop_function.stack_slot_sizes[slot] = 8;
        loop_function.stack_slot_alignments[slot] = 8;
    }
    loop_function.stack_slot_count = 2;
    loop_function.returns_twice_absence_certified = true;
    MachineStackPlacement loop_placement = machine_fast_placement_build(arena, &loop_function);
    BUSTER_TEST(arguments, loop_placement.valid && loop_placement.stack_slot_offsets[0] != loop_placement.stack_slot_offsets[1]);

    // The switch side table is part of the CFG too. Slot zero is read in an
    // early case, while the later case writes slot one and jumps back to the
    // dispatch. A subsequent trip may select the early case, so slot zero is
    // live through the later case even though their touched rows are disjoint.
    // Omitting case targets from the predecessor graph aliases the two slots.
    MachineFunctionBuilder switch_builder = machine_function_builder_begin(arena);
    MachineRef slot_zero = machine_ref_make(MACHINE_REF_STACK_SLOT, 0);
    MachineRef slot_one = machine_ref_make(MACHINE_REF_STACK_SLOT, 1);
    MachineRef rax = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX);
    MachineRef rdx = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RDX);
    machine_builder_block_begin(&switch_builder);
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_STORE_FRAME64,
                                                                      .operands = {slot_zero, rax}});
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_JMP,
                                                                      .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1)}});
    machine_builder_block_end(&switch_builder, (MachineBlock){0});
    machine_builder_edge(&switch_builder, (MachineEdge){.source_block = 0, .destination_block = 1});
    machine_builder_block_begin(&switch_builder);
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_SWITCH,
                                                                      .operands = {rax, machine_ref_make(MACHINE_REF_BLOCK, 4)},
                                                                      .payload = 0, .flags = 2});
    machine_builder_block_end(&switch_builder, (MachineBlock){0});
    machine_builder_edge(&switch_builder, (MachineEdge){.source_block = 1, .destination_block = 2});
    machine_builder_edge(&switch_builder, (MachineEdge){.source_block = 1, .destination_block = 3});
    machine_builder_edge(&switch_builder, (MachineEdge){.source_block = 1, .destination_block = 4});
    machine_builder_block_begin(&switch_builder);
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_LOAD_FRAME,
                                                                      .operands = {rdx, slot_zero}});
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&switch_builder, (MachineBlock){0});
    machine_builder_block_begin(&switch_builder);
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_STORE_FRAME64,
                                                                      .operands = {slot_one, rax}});
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_LOAD_FRAME,
                                                                      .operands = {rdx, slot_one}});
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_JMP,
                                                                      .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1)}});
    machine_builder_block_end(&switch_builder, (MachineBlock){0});
    machine_builder_edge(&switch_builder, (MachineEdge){.source_block = 3, .destination_block = 1});
    machine_builder_block_begin(&switch_builder);
    machine_builder_instruction(&switch_builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&switch_builder, (MachineBlock){0});
    MachineFunction switch_function = machine_function_builder_finish(arena, &switch_builder);
    switch_function.target = machine_target_x86_64();
    switch_function.switch_cases = arena_allocate(arena, MachineSwitchCase, 2);
    switch_function.switch_cases[0] = (MachineSwitchCase){.value = 0, .target_block = 2};
    switch_function.switch_cases[1] = (MachineSwitchCase){.value = 1, .target_block = 3};
    switch_function.switch_case_count = 2;
    switch_function.stack_slot_sizes = arena_allocate(arena, u32, 2);
    switch_function.stack_slot_alignments = arena_allocate(arena, u32, 2);
    for (u32 slot = 0; slot < 2; slot += 1)
    {
        switch_function.stack_slot_sizes[slot] = 8;
        switch_function.stack_slot_alignments[slot] = 8;
    }
    switch_function.stack_slot_count = 2;
    switch_function.returns_twice_absence_certified = true;
    BUSTER_TEST(arguments, machine_verify_function(&switch_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement switch_placement = machine_fast_placement_build(arena, &switch_function);
    BUSTER_TEST(arguments, switch_placement.valid &&
                               switch_placement.stack_slot_offsets[0] != switch_placement.stack_slot_offsets[1]);

    // Each wave defines more cross-block values than the target register file
    // can retain, then consumes all of them in the next block. The waves never
    // overlap. Without CFG-derived home liveness every escaping value remains
    // dedicated; with it, at least one scalar home offset must serve both waves.
    enum
    {
        HOME_PRESSURE = 24,
        HOME_WAVE_COUNT = 2,
    };
    MachineFunctionBuilder home_builder = machine_function_builder_begin(arena);
    MachineRef home_values[HOME_WAVE_COUNT][HOME_PRESSURE];
    u32 home_indices[HOME_WAVE_COUNT][HOME_PRESSURE];
    for (u32 wave = 0; wave < HOME_WAVE_COUNT; wave += 1)
    {
        machine_builder_block_begin(&home_builder);
        for (u32 index = 0; index < HOME_PRESSURE; index += 1)
        {
            u32 row = home_builder.instructions.total_count;
            u32 value = machine_builder_virtual_register(&home_builder,
                (MachineVirtualRegister){.definition_point = machine_point_make(row, MACHINE_POINT_AFTER),
                                         .register_class = MACHINE_REGISTER_CLASS_GENERAL});
            home_indices[wave][index] = value;
            home_values[wave][index] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value);
            machine_builder_instruction(&home_builder,
                (MachineInstruction){.opcode = MACHINE_X64_MOV_RR,
                                     .operands = {home_values[wave][index], machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)}});
        }
        u32 definition_block = 2u * wave;
        u32 use_block = definition_block + 1u;
        machine_builder_instruction(&home_builder,
            (MachineInstruction){.opcode = MACHINE_X64_JMP, .operands = {machine_ref_make(MACHINE_REF_BLOCK, use_block)}});
        machine_builder_block_end(&home_builder, (MachineBlock){0});
        machine_builder_edge(&home_builder, (MachineEdge){.source_block = definition_block, .destination_block = use_block});
        machine_builder_block_begin(&home_builder);
        for (u32 index = 0; index < HOME_PRESSURE; index += 1)
        {
            machine_builder_instruction(&home_builder,
                (MachineInstruction){.opcode = MACHINE_X64_MOV_RR,
                                     .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), home_values[wave][index]}});
        }
        if (wave + 1u < HOME_WAVE_COUNT)
        {
            u32 next_block = use_block + 1u;
            machine_builder_instruction(&home_builder,
                (MachineInstruction){.opcode = MACHINE_X64_JMP, .operands = {machine_ref_make(MACHINE_REF_BLOCK, next_block)}});
            machine_builder_edge(&home_builder, (MachineEdge){.source_block = use_block, .destination_block = next_block});
        }
        else
        {
            machine_builder_instruction(&home_builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
        }
        machine_builder_block_end(&home_builder, (MachineBlock){0});
    }
    MachineFunction home_function = machine_function_builder_finish(arena, &home_builder);
    home_function.target = machine_target_x86_64();
    BUSTER_TEST(arguments, machine_verify_function(&home_function).error == MACHINE_VERIFY_NONE);
    home_function.returns_twice_absence_certified = false;
    MachineStackPlacement home_dedicated = machine_fast_placement_build(arena, &home_function);
    home_function.returns_twice_absence_certified = true;
    MachineStackPlacement home_reused = machine_fast_placement_build(arena, &home_function);
    BUSTER_TEST(arguments, home_dedicated.valid && home_reused.valid && home_reused.frame_size < home_dedicated.frame_size);
    u32 wave_homes[HOME_WAVE_COUNT] = {0};
    u32 shared_offsets = 0;
    for (u32 first = 0; first < HOME_PRESSURE; first += 1)
    {
        u32 first_offset = home_reused.virtual_register_offsets[home_indices[0][first]];
        wave_homes[0] += first_offset != MACHINE_VIRTUAL_REGISTER_NO_HOME;
        for (u32 second = 0; first_offset != MACHINE_VIRTUAL_REGISTER_NO_HOME && second < HOME_PRESSURE; second += 1)
        {
            u32 second_offset = home_reused.virtual_register_offsets[home_indices[1][second]];
            shared_offsets += second_offset != MACHINE_VIRTUAL_REGISTER_NO_HOME && first_offset == second_offset;
        }
    }
    for (u32 second = 0; second < HOME_PRESSURE; second += 1)
    {
        wave_homes[1] += home_reused.virtual_register_offsets[home_indices[1][second]] != MACHINE_VIRTUAL_REGISTER_NO_HOME;
    }
    BUSTER_TEST(arguments, wave_homes[0] && wave_homes[1] && shared_offsets);
    MachineEncodeResult home_encoded = machine_encode_x86_64(arena, &home_function, &home_reused);
    BUSTER_TEST(arguments, home_encoded.valid);

    // A second pressure set is born and consumed inside a loop while the first
    // set remains live from the entry block to the exit. Their edit rows are
    // separated in linear order, but the backedge can execute the inner rows
    // while every outer home still holds its value, so no offset may be shared.
    MachineFunctionBuilder loop_home_builder = machine_function_builder_begin(arena);
    MachineRef loop_home_values[HOME_WAVE_COUNT][HOME_PRESSURE];
    u32 loop_home_indices[HOME_WAVE_COUNT][HOME_PRESSURE];
    machine_builder_block_begin(&loop_home_builder);
    for (u32 index = 0; index < HOME_PRESSURE; index += 1)
    {
        u32 row = loop_home_builder.instructions.total_count;
        u32 value = machine_builder_virtual_register(&loop_home_builder,
            (MachineVirtualRegister){.definition_point = machine_point_make(row, MACHINE_POINT_AFTER),
                                     .register_class = MACHINE_REGISTER_CLASS_GENERAL});
        loop_home_indices[0][index] = value;
        loop_home_values[0][index] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value);
        machine_builder_instruction(&loop_home_builder,
            (MachineInstruction){.opcode = MACHINE_X64_MOV_RR,
                                 .operands = {loop_home_values[0][index], machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)}});
    }
    machine_builder_instruction(&loop_home_builder,
        (MachineInstruction){.opcode = MACHINE_X64_JMP, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1)}});
    machine_builder_block_end(&loop_home_builder, (MachineBlock){0});
    machine_builder_edge(&loop_home_builder, (MachineEdge){.source_block = 0, .destination_block = 1});
    machine_builder_block_begin(&loop_home_builder);
    for (u32 index = 0; index < HOME_PRESSURE; index += 1)
    {
        u32 row = loop_home_builder.instructions.total_count;
        u32 value = machine_builder_virtual_register(&loop_home_builder,
            (MachineVirtualRegister){.definition_point = machine_point_make(row, MACHINE_POINT_AFTER),
                                     .register_class = MACHINE_REGISTER_CLASS_GENERAL});
        loop_home_indices[1][index] = value;
        loop_home_values[1][index] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value);
        machine_builder_instruction(&loop_home_builder,
            (MachineInstruction){.opcode = MACHINE_X64_MOV_RR,
                                 .operands = {loop_home_values[1][index], machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)}});
    }
    for (u32 index = 0; index < HOME_PRESSURE; index += 1)
    {
        machine_builder_instruction(&loop_home_builder,
            (MachineInstruction){.opcode = MACHINE_X64_MOV_RR,
                                 .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), loop_home_values[1][index]}});
    }
    machine_builder_instruction(&loop_home_builder,
        (MachineInstruction){.opcode = MACHINE_X64_CMP64,
                             .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX),
                                          machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)}});
    machine_builder_instruction(&loop_home_builder,
        (MachineInstruction){.opcode = MACHINE_X64_JCC, .payload = MACHINE_X64_CONDITION_EQUAL,
                             .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1), machine_ref_make(MACHINE_REF_BLOCK, 2)}});
    machine_builder_block_end(&loop_home_builder, (MachineBlock){0});
    machine_builder_edge(&loop_home_builder, (MachineEdge){.source_block = 1, .destination_block = 1});
    machine_builder_edge(&loop_home_builder, (MachineEdge){.source_block = 1, .destination_block = 2});
    machine_builder_block_begin(&loop_home_builder);
    for (u32 index = 0; index < HOME_PRESSURE; index += 1)
    {
        machine_builder_instruction(&loop_home_builder,
            (MachineInstruction){.opcode = MACHINE_X64_MOV_RR,
                                 .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), loop_home_values[0][index]}});
    }
    machine_builder_instruction(&loop_home_builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&loop_home_builder, (MachineBlock){0});
    MachineFunction loop_home_function = machine_function_builder_finish(arena, &loop_home_builder);
    loop_home_function.target = machine_target_x86_64();
    loop_home_function.returns_twice_absence_certified = true;
    BUSTER_TEST(arguments, machine_verify_function(&loop_home_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement loop_home_placement = machine_fast_placement_build(arena, &loop_home_function);
    BUSTER_TEST(arguments, loop_home_placement.valid);
    u32 loop_wave_homes[HOME_WAVE_COUNT] = {0};
    u32 loop_shared_offsets = 0;
    for (u32 outer = 0; outer < HOME_PRESSURE; outer += 1)
    {
        u32 outer_offset = loop_home_placement.virtual_register_offsets[loop_home_indices[0][outer]];
        loop_wave_homes[0] += outer_offset != MACHINE_VIRTUAL_REGISTER_NO_HOME;
        for (u32 inner = 0; outer_offset != MACHINE_VIRTUAL_REGISTER_NO_HOME && inner < HOME_PRESSURE; inner += 1)
        {
            u32 inner_offset = loop_home_placement.virtual_register_offsets[loop_home_indices[1][inner]];
            loop_shared_offsets += inner_offset != MACHINE_VIRTUAL_REGISTER_NO_HOME && outer_offset == inner_offset;
        }
    }
    for (u32 inner = 0; inner < HOME_PRESSURE; inner += 1)
    {
        loop_wave_homes[1] += loop_home_placement.virtual_register_offsets[loop_home_indices[1][inner]] != MACHINE_VIRTUAL_REGISTER_NO_HOME;
    }
    BUSTER_TEST(arguments, loop_wave_homes[0] && loop_wave_homes[1] && !loop_shared_offsets);
    MachineEncodeResult loop_home_encoded = machine_encode_x86_64(arena, &loop_home_function, &loop_home_placement);
    BUSTER_TEST(arguments, loop_home_encoded.valid);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_disconnected_dominance(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    MachineBlock capacity_block = {0};
    MachineFunction capacity_function = {.blocks = &capacity_block, .block_count = MACHINE_POINT_INSTRUCTION_LIMIT};
    BUSTER_TEST(arguments, machine_verify_function(&capacity_function).error == MACHINE_VERIFY_POINT_CAPACITY);
    // Entry zero returns independently. Permute every other block so a
    // disconnected chain's true entry can be stored after its users.
    for (u32 root_a = 1; root_a <= 4; root_a += 1)
    {
        for (u32 middle = 1; middle <= 4; middle += 1)
        {
            for (u32 sink = 1; sink <= 4; sink += 1)
            {
                if (root_a == middle || root_a == sink || middle == sink)
                {
                    continue;
                }
                u32 root_b = 10u - root_a - middle - sink;
                for (u32 variant = 0; variant < 6; variant += 1)
                {
                    MachineInstruction instructions[5] = {0};
                    MachineBlock blocks[5] = {0};
                    for (u32 block = 0; block < BUSTER_ARRAY_LENGTH(blocks); block += 1)
                    {
                        instructions[block].opcode = MACHINE_OPCODE_SKELETON_RETURN;
                        blocks[block] = (MachineBlock){.first_instruction = block, .instruction_count = 1, .parameter_offset = 3};
                    }
                    MachineVirtualRegister registers[3] = {0};
                    MachineBlockParameter parameters[3] = {0};
                    for (u32 reg = 0; reg < BUSTER_ARRAY_LENGTH(registers); reg += 1)
                    {
                        registers[reg] = (MachineVirtualRegister){.definition_point = MACHINE_POINT_INVALID,
                            .register_class = MACHINE_REGISTER_CLASS_GENERAL, .typed_origin = IR_ID_UNDERLYING_INVALID};
                        parameters[reg].virtual_register = reg;
                    }
                    blocks[root_a].parameter_offset = 0;
                    blocks[root_a].parameter_count = 1;
                    blocks[root_b].parameter_offset = 1;
                    blocks[root_b].parameter_count = 1;
                    blocks[sink].parameter_offset = 2;
                    blocks[sink].parameter_count = 1;
                    MachineRef sources[] = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0),
                                            machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1)};
                    MachineEdge edges[5] = {
                        {.source_block = root_a, .destination_block = middle},
                        {.source_block = middle, .destination_block = sink, .copy_count = 1},
                    };
                    u32 edge_count = 2;
                    if (variant == 1)
                    {
                        // Either root can reach the join. A value defined at
                        // only root A cannot dominate the outgoing copy.
                        edges[edge_count++] = (MachineEdge){.source_block = root_b, .destination_block = middle};
                    }
                    else if (variant >= 4)
                    {
                        // A downstream cycle must start its traversal from
                        // the real entry, even if an interior block is stored
                        // first. Adding a second entry invalidates B's value
                        // on the path that bypasses B.
                        edges[0] = (MachineEdge){.source_block = root_a, .destination_block = root_b, .copy_count = 1};
                        edges[1] = (MachineEdge){.source_block = root_b, .destination_block = middle};
                        edges[2] = (MachineEdge){.source_block = middle, .destination_block = root_b, .copy_offset = 1, .copy_count = 1};
                        edges[3] = (MachineEdge){.source_block = middle, .destination_block = sink, .copy_offset = 1, .copy_count = 1};
                        edge_count = 4;
                        if (variant == 5)
                        {
                            edges[edge_count++] = (MachineEdge){.source_block = root_a, .destination_block = middle};
                        }
                    }
                    else if (variant >= 2)
                    {
                        // A closed source cycle has no distinguished entry.
                        // Both members define their own parameters; only B
                        // dominates the tail reached exclusively from B.
                        edges[0].source_block = root_b;
                        edges[1].copy_offset = variant == 2 ? 1u : 0u;
                        edges[edge_count++] = (MachineEdge){.source_block = root_a, .destination_block = root_b, .copy_count = 1};
                        edges[edge_count++] = (MachineEdge){.source_block = root_b, .destination_block = root_a, .copy_offset = 1, .copy_count = 1};
                    }
                    MachineFunction function = {
                        .instructions = instructions, .instruction_count = BUSTER_ARRAY_LENGTH(instructions),
                        .blocks = blocks, .block_count = BUSTER_ARRAY_LENGTH(blocks),
                        .virtual_registers = registers, .virtual_register_count = BUSTER_ARRAY_LENGTH(registers),
                        .block_parameters = parameters, .block_parameter_count = BUSTER_ARRAY_LENGTH(parameters),
                        .edges = edges, .edge_count = edge_count,
                        .edge_copy_sources = sources, .edge_copy_source_count = BUSTER_ARRAY_LENGTH(sources),
                    };
                    MachineVerifyError expected = variant & 1u ? MACHINE_VERIFY_VIRTUAL_REGISTER_USE_BEFORE_DEFINITION : MACHINE_VERIFY_NONE;
                    BUSTER_TEST_RAW(arguments, machine_verify_function(&function).error == expected,
                                    string_format(arguments->arena, S8("disconnected roots {u32}/{u32}, middle {u32}, sink {u32}, variant {u32}"),
                                                  root_a, root_b, middle, sink, variant));
                }
            }
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_i128_block_parameters(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/basic_c_i128_block_parameters.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, source.length != 0);
    String8 names[] = {S8("wide_choose"), S8("wide_signed"), S8("wide_nested"), S8("wide_swap"),
                       S8("wide_rotate"), S8("wide_switch"), S8("wide_indirect")};
    Target targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
    };
    for (u32 target = 0; source.length && target < BUSTER_ARRAY_LENGTH(targets); target += 1)
    {
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("i128-block-parameters.c"), source, targets[target],
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                {
                    IrFunction* function = machine_test_ir_function_find(program->modules, names[name]);
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        u32 parameters = 0;
                        u32 wide_parameters = 0;
                        u32 cycle_sources = 0;
                        for (u32 block = 0; block < function->block_count; block += 1)
                        {
                            for (IrBlockParameter* parameter = function->blocks[block].first_parameter; parameter; parameter = parameter->next)
                            {
                                parameters += 1;
                                IrType* type = ir_type_from_id(&program->types, parameter->canonical_type);
                                bool wide = type && type->kind == IR_TYPE_INTEGER && type->bit_width == 128;
                                wide_parameters += wide;
                                if (wide)
                                {
                                    for (IrIncoming* incoming = parameter->first_incoming; incoming; incoming = incoming->next)
                                    {
                                        for (IrBlockParameter* other = function->blocks[block].first_parameter; other; other = other->next)
                                        {
                                            cycle_sources += other != parameter && incoming->value.value == other->value.value;
                                        }
                                    }
                                }
                            }
                        }
                        // Require actual i128 joins, including two- and three-value
                        // loop cycles, so frontend changes cannot make this vacuous.
                        // Computed goto deliberately disables local promotion; its
                        // memory-form execution is covered by the driver fixture.
                        BUSTER_TEST_RAW(arguments, memory_form || name == 6 || wide_parameters != 0, names[name]);
                        if (!memory_form && (name == 3 || name == 4))
                        {
                            BUSTER_TEST_RAW(arguments, cycle_sources >= (name == 3 ? 2u : 3u), names[name]);
                        }
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, targets[target]);
                        BUSTER_TEST_RAW(arguments, selected.supported, names[name]);
                        if (selected.supported)
                        {
                            BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                            BUSTER_TEST(arguments, selected.function.block_parameter_count == parameters + wide_parameters);
                            for (u32 parameter = 0; parameter < selected.function.block_parameter_count; parameter += 1)
                            {
                                u32 reg = selected.function.block_parameters[parameter].virtual_register;
                                BUSTER_TEST(arguments, selected.function.virtual_registers[reg].definition_point == MACHINE_POINT_INVALID);
                            }
                        }
                    }
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_pointer_block_parameters(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 source = S8(
        "int pointer_join(int *a, int *b, int n) { int *p; if (n) p = b; else p = a; return p[2]; }\n"
        "int pointer_walk(int *a, int *b, int n) { int *p = a; int sum = 0; while (n > 0) { sum += *p; p += 1; n -= 1; } return sum; }\n"
        "int pointer_backwards(int *a, int *b, int n) { int *p = a + n; int sum = 0; while (p != a) { p -= 1; sum += p[0]; } return sum; }\n"
        "int pointer_swap(int *a, int *b, int n) { int sum = 0; while (n > 0) { int *tmp = a; a = b; b = tmp; sum += a[0]; n -= 1; } return sum; }\n"
        "int pointer_length(int *a, int *b, int n) { int *p = a; while (*p) p += 1; return (int)(p - a); }\n");
    String8 names[] = {S8("pointer_join"), S8("pointer_walk"), S8("pointer_backwards"), S8("pointer_swap"), S8("pointer_length")};
    Target targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
    };
    CodegenRegisterAllocatorMode modes[] = {
        CODEGEN_REGISTER_ALLOCATOR_NONE, CODEGEN_REGISTER_ALLOCATOR_MIR_STACK,
        CODEGEN_REGISTER_ALLOCATOR_FAST, CODEGEN_REGISTER_ALLOCATOR_QUALITY,
    };
    for (u32 target_index = 0; target_index < BUSTER_ARRAY_LENGTH(targets); target_index += 1)
    {
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("pointer-block-parameters.c"), source, targets[target_index],
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(names); name_index += 1)
                {
                    IrFunction* function = machine_test_ir_function_find(module, names[name_index]);
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        u32 pointer_parameters = 0;
                        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
                        {
                            for (IrBlockParameter* parameter = function->blocks[block_index].first_parameter; parameter; parameter = parameter->next)
                            {
                                IrType* type = ir_type_from_id(&program->types, parameter->canonical_type);
                                pointer_parameters += type && type->kind == IR_TYPE_POINTER;
                            }
                        }
                        // Keep the original failure reachable even if frontend
                        // lowering changes: the SSA fixture must contain joins.
                        BUSTER_TEST(arguments, memory_form || pointer_parameters != 0);
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, targets[target_index]);
                        BUSTER_TEST_RAW(arguments, selected.supported, names[name_index]);
                        if (selected.supported)
                        {
                            BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        }
                    }
                }
                for (u32 mode_index = 0; mode_index < BUSTER_ARRAY_LENGTH(modes); mode_index += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, targets[target_index],
                                                                                (CodegenModuleOptions){.register_allocator = (u8)modes[mode_index]});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
#if (BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64) && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                    bool native_arch = (BUSTER_CPU_ARCH_X86_64 && target_index == 0) || (BUSTER_CPU_ARCH_AARCH64 && target_index == 1);
                    if (native_arch && generated.error == CODEGEN_ERROR_NONE)
                    {
                        BUSTER_TEST(arguments, generated.relocation_count == 0);
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            s32 a[] = {3, -7, 19, 4, 11, -2, 0};
                            s32 b[] = {13, 5, -17, 8, -9, 6};
                            for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(names); name_index += 1)
                            {
                                u32 offset = machine_test_module_offset(&generated, module, names[name_index]);
                                BUSTER_TEST(arguments, offset != UINT32_MAX);
                                if (offset != UINT32_MAX)
                                {
                                    typedef s32 PointerCall(s32*, s32*, s32);
                                    PointerCall* call = 0;
                                    void* address = (u8*)executable.address + offset;
                                    memcpy(&call, &address, sizeof(call));
                                    for (s32 n = 0; n <= 6; n += 1)
                                    {
                                        s32 expected = 0;
                                        if (name_index == 0)
                                        {
                                            expected = n ? b[2] : a[2];
                                        }
                                        else if (name_index == 4)
                                        {
                                            expected = 6;
                                        }
                                        else
                                        {
                                            for (s32 i = 0; i < n; i += 1)
                                            {
                                                expected += name_index == 3 ? (i & 1 ? a[0] : b[0]) : a[i];
                                            }
                                        }
                                        BUSTER_TEST_RAW(arguments, call(a, b, n) == expected, names[name_index]);
                                    }
                                }
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_x64_i128_complement(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/basic_c_x86_64_i128_complement.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, source.length != 0);
    String8 names[] = {S8("complement_unsigned"), S8("complement_signed")};
    Target targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS},
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},
    };
    for (u32 target = 0; source.length && target < BUSTER_ARRAY_LENGTH(targets); target += 1)
    {
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("i128-complement.c"), source, targets[target],
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                {
                    IrFunction* function = machine_test_ir_function_find(program->modules, names[name]);
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        u32 complements = 0;
                        for (u32 row = 0; row < function->instruction_count; row += 1)
                        {
                            IrInstruction* instruction = function->instructions + row;
                            if (instruction->opcode == IR_OPCODE_UNARY && instruction->unary_operation == IR_UNARY_INTEGER_BITWISE_NOT)
                            {
                                IrType* type = ir_type_from_id(&program->types, instruction->canonical_type);
                                complements += type && type->kind == IR_TYPE_INTEGER && type->bit_width == 128;
                            }
                        }
                        BUSTER_TEST(arguments, complements == 1);
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, targets[target]);
                        BUSTER_TEST_RAW(arguments, selected.supported, names[name]);
                        if (selected.supported)
                        {
                            BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                            u32 limb_results = 0;
                            for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                            {
                                MachineInstruction* instruction = selected.function.instructions + row;
                                if (instruction->opcode == MACHINE_X64_XOR64)
                                {
                                    limb_results += 1;
                                    u32 reg = machine_ref_payload(instruction->operands[0]);
                                    bool valid = machine_ref_kind(instruction->operands[0]) == MACHINE_REF_VIRTUAL_REGISTER &&
                                                 reg < selected.function.virtual_register_count;
                                    BUSTER_TEST(arguments, valid);
                                    if (valid)
                                    {
                                        MachineVirtualRegister* definition = selected.function.virtual_registers + reg;
                                        BUSTER_TEST(arguments, definition->definition_point == machine_point_make(row, MACHINE_POINT_AFTER));
                                        BUSTER_TEST(arguments, !(definition->flags & MACHINE_VIRTUAL_REGISTER_FLAG_MUTABLE));
                                    }
                                }
                            }
                            BUSTER_TEST(arguments, limb_results == 2);
                        }
                    }
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_x64_dynamic_stack(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/basic_c_win64_dynamic_stack.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, source.length != 0);
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS};
    for (u32 memory_form = 0; source.length && memory_form < 2; memory_form += 1)
    {
        TemporalArena temporary = scratch_begin(&arguments->arena, 1);
        IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("win64-dynamic-stack.c"), source, target,
                                                                 (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
        BUSTER_TEST(arguments, program && program->module_count == 1);
        if (program && program->module_count == 1)
        {
            IrFunction* function = machine_test_ir_function_find(program->modules, S8("exercise"));
            BUSTER_TEST(arguments, function != 0);
            if (function)
            {
                MachineSelectResult selected;
                MachineEncodeResult encoded = machine_test_encode(temporary.arena, program, function, target, &selected);
                BUSTER_TEST(arguments, selected.supported && encoded.valid);
                if (selected.supported && encoded.valid)
                {
                    BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                    BUSTER_TEST(arguments, selected.function.outgoing_bytes == 0);
                    BUSTER_TEST(arguments, encoded.frame_pointer_offset != 0);
                    u32 allocations = 0;
                    u32 stack_stores = 0;
                    for (u32 index = 0; index < selected.function.instruction_count; index += 1)
                    {
                        MachineInstruction* row = selected.function.instructions + index;
                        allocations += row->opcode == MACHINE_X64_STACK_ALLOCATE;
                        stack_stores += row->opcode == MACHINE_X64_STORE_PTR64;
                    }
                    BUSTER_TEST(arguments, allocations == 4 && stack_stores == 8);
                }
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, program->modules, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE && generated.statistics.fallback_function_count == 0);
                    for (u32 index = 0; index < generated.function_count; index += 1)
                    {
                        CodegenFunctionDescriptor* descriptor = generated.functions + index;
                        if (descriptor->symbol.value == function->symbol.value)
                        {
                            BUSTER_TEST(arguments, descriptor->unwind_action_count >= 3);
                            if (descriptor->unwind_action_count >= 3)
                            {
                                CodegenUnwindAction* last = descriptor->unwind_actions + descriptor->unwind_action_count - 1;
                                BUSTER_TEST(arguments, last->kind == CODEGEN_UNWIND_ACTION_SET_FRAME_POINTER && last->register_index == MACHINE_X64_RBP &&
                                    last->value == 0 && last->code_offset == descriptor->prolog_size);
                            }
                        }
                    }
                }
            }
        }
        scratch_end(temporary);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_unsigned_switch(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/switch_unsigned.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, source.length != 0);
    String8 names[] = {S8("switch_u32"), S8("switch_u64")};
    Target targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
    };
    for (u32 target_index = 0; source.length && target_index < BUSTER_ARRAY_LENGTH(targets); target_index += 1)
    {
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("switch-unsigned.c"), source, targets[target_index],
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(names); name_index += 1)
                {
                    IrFunction* function = machine_test_ir_function_find(module, names[name_index]);
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        MachineSelectResult selected;
                        MachineEncodeResult encoded = machine_test_encode(temporary.arena, program, function, targets[target_index], &selected);
                        BUSTER_TEST_RAW(arguments, encoded.valid, names[name_index]);
                        // Keep the original encoder path covered even if the
                        // frontend later changes its switch lowering strategy.
                        u32 cases = 0;
                        for (u32 row = 0; row < selected.function.switch_case_count; row += 1)
                        {
                            MachineSwitchCase* item = selected.function.switch_cases + row;
                            cases += item->compare_width == (name_index ? 64 : 32);
                        }
                        BUSTER_TEST(arguments, cases == (name_index ? 7u : 5u));
                    }
                }
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, targets[target_index],
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
#if (BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64) && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                    bool native_arch = (BUSTER_CPU_ARCH_X86_64 && target_index == 0) || (BUSTER_CPU_ARCH_AARCH64 && target_index == 1);
                    if (native_arch && generated.error == CODEGEN_ERROR_NONE)
                    {
                        BUSTER_TEST(arguments, generated.relocation_count == 0);
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            u64 values[] = {0, 0x7fffffff, 0x80000000, 0xb9000000, 0xf9400000, 0xffffffff,
                                UINT64_C(0xffffffff80000000), UINT64_MAX, UINT64_C(0x180000000), UINT64_C(0x100000000)};
                            u32 expected[2][10] = {{0, 1, 2, 3, 4, 5, 2, 5, 2, 0}, {0, 1, 2, 3, 4, 5, 6, 7, 0, 0}};
                            for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(names); name_index += 1)
                            {
                                u32 offset = machine_test_module_offset(&generated, module, names[name_index]);
                                BUSTER_TEST(arguments, offset != UINT32_MAX);
                                if (offset != UINT32_MAX)
                                {
                                    typedef u64 SwitchCall(u64);
                                    SwitchCall* call = 0;
                                    void* address = (u8*)executable.address + offset;
                                    memcpy(&call, &address, sizeof(call));
                                    for (u32 i = 0; i < BUSTER_ARRAY_LENGTH(values); i += 1)
                                    {
                                        BUSTER_TEST_RAW(arguments, call(values[i]) == expected[name_index][i], names[name_index]);
                                    }
                                }
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_clear_instruction_cache(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/clear_cache.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, source.length != 0);
    Target targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_WINDOWS},
    };
    // Clang's encoding of tests/differential/clear_cache_aarch64.s. The
    // alignment and both loop targets are part of this independent oracle.
    u32 cache_words[] = {0x927ef52b, 0xaa0b03e9, 0xeb0a013f, 0x54000082, 0xd50b7b29, 0x91001129, 0x17fffffc, 0xd5033b9f,
                        0xaa0b03e9, 0xeb0a013f, 0x54000082, 0xd50b7529, 0x91001129, 0x17fffffc, 0xd5033b9f, 0xd5033fdf};
    MachineOpcodeInfo const* info = machine_opcode_info(MACHINE_A64_CLEAR_INSTRUCTION_CACHE);
    BUSTER_TEST(arguments, machine_opcode_fixed_register(info, 0) == MACHINE_A64_X9);
    BUSTER_TEST(arguments, machine_opcode_fixed_register(info, 1) == MACHINE_A64_X10);
    BUSTER_TEST(arguments, info->clobber_mask == ((1u << MACHINE_A64_X9) | (1u << MACHINE_A64_X11)));
    BUSTER_TEST(arguments, (info->attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE) != 0);
    for (u32 target_index = 0; source.length && target_index < BUSTER_ARRAY_LENGTH(targets); target_index += 1)
    {
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("clear-cache.c"), source, targets[target_index],
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                u32 clear_instruction_count = 0;
                u32 clear_runtime_call_count = 0;
                u32 clear_runtime_symbol_count = 0;
                for (u32 symbol_index = 0; symbol_index < program->symbols.count; symbol_index += 1)
                {
                    IrSymbol* symbol = program->symbols.symbols + symbol_index;
                    if (symbol->kind == IR_SYMBOL_FUNCTION && string_equal(symbol->link_name, S8("__clear_cache")))
                    {
                        clear_runtime_symbol_count += 1;
                        IrType* function_type = ir_type_from_id(&program->types, symbol->type);
                        IrType* return_type = function_type ? ir_type_from_id(&program->types, function_type->return_type) : 0;
                        BUSTER_TEST(arguments, symbol->linkage == IR_LINKAGE_IMPORT);
                        BUSTER_TEST(arguments, function_type && function_type->kind == IR_TYPE_FUNCTION &&
                                                   function_type->calling_convention == IR_CALLING_CONVENTION_C &&
                                                   !function_type->is_variadic && function_type->parameter_count == 2);
                        BUSTER_TEST(arguments, return_type && return_type->kind == IR_TYPE_VOID);
                        if (function_type && function_type->parameter_count == 2)
                        {
                            IrType* first_parameter = ir_type_from_id(&program->types, function_type->parameter_types[0]);
                            IrType* second_parameter = ir_type_from_id(&program->types, function_type->parameter_types[1]);
                            BUSTER_TEST(arguments, first_parameter && first_parameter->kind == IR_TYPE_POINTER);
                            BUSTER_TEST(arguments, second_parameter && second_parameter->kind == IR_TYPE_POINTER);
                        }
                    }
                }
                for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
                {
                    IrFunction* function = module->functions + function_index;
                    for (u32 instruction_index = 0; instruction_index < function->instruction_count; instruction_index += 1)
                    {
                        IrInstruction* instruction = function->instructions + instruction_index;
                        clear_instruction_count += instruction->opcode == IR_OPCODE_CLEAR_INSTRUCTION_CACHE;
                        IrSymbol* symbol = instruction->opcode == IR_OPCODE_CALL ? ir_symbol_from_id(&program->symbols, instruction->symbol) : 0;
                        if (symbol && string_equal(symbol->link_name, S8("__clear_cache")))
                        {
                            IrType* result_type = ir_type_from_id(&program->types, instruction->canonical_type);
                            clear_runtime_call_count += 1;
                            BUSTER_TEST(arguments, symbol->linkage == IR_LINKAGE_IMPORT);
                            BUSTER_TEST(arguments, result_type && result_type->kind == IR_TYPE_VOID &&
                                                       instruction->result.value == IR_ID_UNDERLYING_INVALID);
                        }
                    }
                }
                BUSTER_TEST(arguments, clear_instruction_count == (target_index == 2 ? 0u : 3u));
                BUSTER_TEST(arguments, clear_runtime_call_count == (target_index == 2 ? 3u : 0u));
                BUSTER_TEST(arguments, clear_runtime_symbol_count == (target_index == 2 ? 1u : 0u));
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, targets[target_index],
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
                    if (target_index == 1 && generated.error == CODEGEN_ERROR_NONE)
                    {
                        u32 sequences = 0;
                        for (u64 offset = 0; offset + sizeof(cache_words) <= generated.code.length; offset += 4)
                        {
                            sequences += memcmp(generated.code.pointer + offset, cache_words, sizeof(cache_words)) == 0;
                        }
                        BUSTER_TEST(arguments, sequences == 3);
                    }
                    if (target_index == 2 && generated.error == CODEGEN_ERROR_NONE)
                    {
                        u32 direct_maintenance_words = 0;
                        for (u64 offset = 0; offset + sizeof(u32) <= generated.code.length; offset += sizeof(u32))
                        {
                            u32 word;
                            memcpy(&word, generated.code.pointer + offset, sizeof(word));
                            direct_maintenance_words += (word & UINT32_C(0xffffffe0)) == UINT32_C(0xd50b7b20) ||
                                                        (word & UINT32_C(0xffffffe0)) == UINT32_C(0xd50b7520);
                        }
                        BUSTER_TEST(arguments, direct_maintenance_words == 0);
                        BUSTER_TEST(arguments, generated.relocation_count == 3);
                        for (u32 relocation_index = 0; relocation_index < generated.relocation_count; relocation_index += 1)
                        {
                            CodegenModuleRelocation* relocation = generated.relocations + relocation_index;
                            IrSymbol* symbol = ir_symbol_from_id(&program->symbols, relocation->symbol);
                            BUSTER_TEST(arguments, relocation->kind == CODEGEN_MODULE_RELOCATION_AARCH64_CALL26);
                            BUSTER_TEST(arguments, symbol && string_equal(symbol->link_name, S8("__clear_cache")));
                            BUSTER_TEST(arguments, symbol && symbol->linkage == IR_LINKAGE_IMPORT);
                        }
                    }
#if (BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64) && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                    bool native_arch = (BUSTER_CPU_ARCH_X86_64 && target_index == 0) || (BUSTER_CPU_ARCH_AARCH64 && target_index == 1);
                    if (native_arch && generated.error == CODEGEN_ERROR_NONE)
                    {
                        BUSTER_TEST(arguments, generated.relocation_count == 0);
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            u32 range_offset = machine_test_module_offset(&generated, module, S8("clear_range"));
                            u32 argument_offset = machine_test_module_offset(&generated, module, S8("clear_arguments"));
                            u32 live_offset = machine_test_module_offset(&generated, module, S8("clear_live"));
                            BUSTER_TEST(arguments, range_offset != UINT32_MAX && argument_offset != UINT32_MAX && live_offset != UINT32_MAX);
                            if (range_offset != UINT32_MAX && argument_offset != UINT32_MAX && live_offset != UINT32_MAX)
                            {
                                typedef void ClearRange(char*, char*);
                                typedef s32 ClearArguments(char*, s32, s32*, s32*);
                                typedef u64 ClearLive(char*, u64, u64, u64, u64, u64, u64, u64);
                                ClearRange* range = 0;
                                ClearArguments* call = 0;
                                ClearLive* live = 0;
                                void* address = (u8*)executable.address + range_offset;
                                memcpy(&range, &address, sizeof(range));
                                address = (u8*)executable.address + argument_offset;
                                memcpy(&call, &address, sizeof(call));
                                address = (u8*)executable.address + live_offset;
                                memcpy(&live, &address, sizeof(live));
                                char bytes[256] = {0};
                                for (s32 start = 0; start < 128; start += 1)
                                {
                                    s32 first = start;
                                    s32 second = 5;
                                    range(bytes + start, bytes + start);
                                    range(bytes + start, bytes + start + 2);
                                    BUSTER_TEST(arguments, call(bytes + start, 65, &first, &second) == start + 43);
                                    BUSTER_TEST(arguments, first == start + 1 && second == 6);
                                    BUSTER_TEST(arguments, live(bytes, 1, 2, 3, 4, 5, 6, 7) == 406);
                                }
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_cpu_queries(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/cpu_queries.c"), (FileReadOptions){0});
    String8 source = string_format(arguments->arena, S8("#define BUSTER_CPU_QUERY_TEST 1\n{S8}"),
                                  (String8){.pointer = (char8*)input.pointer, .length = input.length});
    BUSTER_TEST(arguments, input.length != 0);
    String8 names[] = {S8("query_four"), S8("query_tied"), S8("query_places"), S8("query_xcr")};
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_MACOS};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_INTEL_HASWELL, .os = systems[system]};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("cpu-queries.c"), source, target,
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                {
                    IrFunction* function = machine_test_ir_function_find(module, names[name]);
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                        BUSTER_TEST_RAW(arguments, selected.supported, names[name]);
                        if (selected.supported)
                        {
                            BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                            MachineStackPlacement placement = machine_stack_placement_build(temporary.arena, &selected.function);
                            BUSTER_TEST(arguments, placement.valid);
                            if (name != 3) { BUSTER_TEST(arguments, (placement.callee_saved_mask & (1u << MACHINE_X64_RBX)) != 0); }
                            u32 queries = 0;
                            for (u32 index = 0; index < selected.function.instruction_count; index += 1)
                            {
                                MachineInstruction* row = selected.function.instructions + index;
                                if (row->opcode == MACHINE_X64_CPUID || row->opcode == MACHINE_X64_XGETBV)
                                {
                                    bool cpuid = row->opcode == MACHINE_X64_CPUID;
                                    u32 slot = machine_ref_payload(row->operands[cpuid ? 2u : 1u]);
                                    u32 size = selected.function.stack_slot_sizes[slot];
                                    selected.function.stack_slot_sizes[slot] = cpuid ? 31u : 15u;
                                    BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                    selected.function.stack_slot_sizes[slot] = size;
                                    queries += 1;
                                }
                            }
                            BUSTER_TEST(arguments, queries == 1);
                        }
                        if (name == 3)
                        {
                            Target baseline = target;
                            baseline.cpu_model = CPU_MODEL_BASELINE;
                            MachineSelectResult rejected = machine_select_canonical_function(temporary.arena, program, function, baseline);
                            BUSTER_TEST(arguments, !rejected.supported && rejected.failed_opcode == IR_OPCODE_INLINE_ASSEMBLY);
                        }
                    }
                }
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                    if (system == 0 && generated.error == CODEGEN_ERROR_NONE)
                    {
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            u32 expected[4];
                            __asm__ volatile("cpuid" : "=a"(expected[0]), "=b"(expected[1]), "=c"(expected[2]), "=d"(expected[3]) : "a"(0), "c"(0));
                            for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                            {
                                u32 offset = machine_test_module_offset(&generated, module, names[name]);
                                BUSTER_TEST(arguments, offset != UINT32_MAX);
                                if (offset != UINT32_MAX)
                                {
                                    void* address = (u8*)executable.address + offset;
                                    if (name == 0 || name == 2)
                                    {
                                        typedef void QueryFour(u32, u32, u32*);
                                        QueryFour* call = 0;
                                        memcpy(&call, &address, sizeof(call));
                                        u32 actual[4] = {0};
                                        call(0, 0, actual);
                                        BUSTER_TEST(arguments, memcmp(actual, expected, sizeof(actual)) == 0);
                                    }
                                    else if (name == 1)
                                    {
                                        typedef u64 QueryTied(u32, u32, u32);
                                        QueryTied* call = 0;
                                        memcpy(&call, &address, sizeof(call));
                                        u64 expected_value = (u64)expected[0] + 3ull*expected[1] + 5ull*expected[2] + 7ull*expected[3] + 17ull*UINT32_MAX;
                                        BUSTER_TEST(arguments, call(0, 0, UINT32_MAX) == expected_value);
                                    }
                                    else
                                    {
                                        u32 capabilities[4];
                                        __asm__ volatile("cpuid" : "=a"(capabilities[0]), "=b"(capabilities[1]), "=c"(capabilities[2]), "=d"(capabilities[3]) : "a"(1), "c"(0));
                                        if (capabilities[2] & (1u << 27))
                                        {
                                            u32 low, high;
                                            __asm__ volatile("xgetbv" : "=a"(low), "=d"(high) : "c"(0));
                                            typedef u64 QueryXcr(u32);
                                            QueryXcr* call = 0;
                                            memcpy(&call, &address, sizeof(call));
                                            BUSTER_TEST(arguments, call(0) == ((u64)low | ((u64)high << 32)));
                                        }
                                    }
                                }
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

typedef struct MachineCompilerBarrierTestFixture MachineCompilerBarrierTestFixture;
struct MachineCompilerBarrierTestFixture
{
    String8 path;
    String8* names;
    u32 name_count;
    bool supported;
    bool identity;
    bool general;
};

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_compiler_barrier(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 accepted[] = {
        S8("compiler_barrier_memory"), S8("compiler_barrier_empty_extended"), S8("compiler_barrier_empty_basic"),
        S8("compiler_barrier_implicit_volatile"), S8("compiler_barrier_cc"), S8("compiler_barrier_memory_cc"),
        S8("compiler_barrier_cc_memory"),
    };
    String8 general[] = {
        S8("compiler_barrier_template"), S8("compiler_barrier_register_after_memory"),
        S8("compiler_barrier_register_before_cc"),
        S8("compiler_hint_input"), S8("compiler_hint_register"), S8("compiler_hint_goto"),
        S8("compiler_barrier_untied_output"),
    };
    String8 identities[] = {
        S8("compiler_barrier_input"), S8("compiler_barrier_read_write"),
        S8("compiler_barrier_numeric_tie"), S8("compiler_barrier_named_tie"),
    };
    String8 gotos[] = {S8("compiler_barrier_goto")};
    MachineCompilerBarrierTestFixture fixtures[] = {
        {S8("tests/basic_c_compiler_barrier.c"), accepted, BUSTER_ARRAY_LENGTH(accepted), true},
        {S8("tests/basic_c_compiler_barrier_fallback.c"), general, BUSTER_ARRAY_LENGTH(general), true, false, true},
        {S8("tests/basic_c_compiler_barrier_fallback.c"), identities, BUSTER_ARRAY_LENGTH(identities), true, true},
        {S8("tests/basic_c_compiler_barrier_fallback.c"), gotos, BUSTER_ARRAY_LENGTH(gotos), true},
    };
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    for (u32 fixture = 0; fixture < BUSTER_ARRAY_LENGTH(fixtures); fixture += 1)
    {
        ByteSlice input = file_read(arguments->arena, fixtures[fixture].path, (FileReadOptions){0});
        String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
        BUSTER_TEST_RAW(arguments, input.length != 0, fixtures[fixture].path);
        for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
        {
            Target target = {.cpu_arch = architectures[architecture], .cpu_model = CPU_MODEL_BASELINE, .os = OPERATING_SYSTEM_LINUX};
            for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                IrProgram* program = machine_test_compile_c_with_options(temporary.arena, fixtures[fixture].path, source, target,
                                                                         (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
                BUSTER_TEST(arguments, program && program->module_count == 1);
                if (program && program->module_count == 1)
                {
                    for (u32 name = 0; name < fixtures[fixture].name_count; name += 1)
                    {
                        String8 description = fixtures[fixture].names[name];
                        IrFunction* function = machine_test_ir_function_find(program->modules, description);
                        BUSTER_TEST_RAW(arguments, function != 0, description);
                        if (function)
                        {
                            MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                            bool supported = fixtures[fixture].supported;
                            BUSTER_TEST_RAW(arguments, selected.supported == supported, description);
                            if (supported && selected.supported)
                            {
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                                bool memory_effect = string_equal(description, S8("compiler_barrier_memory")) ||
                                                     string_equal(description, S8("compiler_barrier_memory_cc")) ||
                                                     string_equal(description, S8("compiler_barrier_cc_memory")) ||
                                                     string_equal(description, S8("compiler_barrier_goto")) ||
                                                     string_equal(description, S8("compiler_barrier_template")) ||
                                                     string_equal(description, S8("compiler_barrier_register_after_memory")) ||
                                                     string_equal(description, S8("compiler_hint_input")) ||
                                                     string_equal(description, S8("compiler_hint_goto"));
                                bool flags_effect = string_equal(description, S8("compiler_barrier_cc")) ||
                                                    string_equal(description, S8("compiler_barrier_memory_cc")) ||
                                                    string_equal(description, S8("compiler_barrier_cc_memory")) ||
                                                    string_equal(description, S8("compiler_barrier_register_before_cc")) ||
                                                    string_equal(description, S8("compiler_hint_register"));
                                u32 effect_index = (memory_effect ? 1u : 0u) | (flags_effect ? 2u : 0u);
                                u16 barrier_opcode = fixtures[fixture].general
                                                         ? (architectures[architecture] == CPU_ARCH_X86_64 ? MACHINE_X64_INLINE_ASSEMBLY
                                                                                                         : MACHINE_A64_INLINE_ASSEMBLY)
                                                         : (u16)((architectures[architecture] == CPU_ARCH_X86_64
                                                               ? MACHINE_X64_INLINE_EFFECTS_NONE
                                                               : MACHINE_A64_INLINE_EFFECTS_NONE) + effect_index);
                                if (fixtures[fixture].identity)
                                {
                                    barrier_opcode = architectures[architecture] == CPU_ARCH_X86_64 ? MACHINE_X64_ASM_IDENTITY : MACHINE_A64_ASM_IDENTITY;
                                }
                                u32 barrier_count = 0;
                                u32 observed_assembly_opcode = UINT32_MAX;
                                for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                                {
                                    u32 opcode = selected.function.instructions[row].opcode;
                                    barrier_count += opcode == barrier_opcode;
                                    if ((opcode >= MACHINE_X64_INLINE_ASSEMBLY && opcode <= MACHINE_X64_INLINE_EFFECTS_MEMORY_FLAGS) ||
                                        (opcode >= MACHINE_A64_INLINE_ASSEMBLY && opcode <= MACHINE_A64_INLINE_EFFECTS_MEMORY_FLAGS))
                                    {
                                        observed_assembly_opcode = opcode;
                                    }
                                }
                                BUSTER_TEST_RAW(arguments, barrier_count == 1,
                                                string_format(arguments->arena, S8("{S8}: expected opcode {u32}, count {u32}, observed {u32}"),
                                                              description, barrier_opcode, barrier_count, observed_assembly_opcode));
                                MachineOpcodeInfo const* info = machine_opcode_info(barrier_opcode);
                                if (fixtures[fixture].general)
                                {
                                    MachineInlineAssembly* descriptor = 0;
                                    for (u32 row = 0; row < selected.function.instruction_count && !descriptor; row += 1)
                                    {
                                        MachineInstruction* machine_row = selected.function.instructions + row;
                                        if (machine_row->opcode == barrier_opcode && machine_row->payload < selected.function.inline_assembly_count)
                                        {
                                            descriptor = selected.function.inline_assemblies + machine_row->payload;
                                        }
                                    }
                                    bool terminator = string_equal(description, S8("compiler_hint_goto"));
                                    bool register_visible = !string_equal(description, S8("compiler_barrier_template")) &&
                                                            !string_equal(description, S8("compiler_hint_goto"));
                                    BUSTER_TEST(arguments, descriptor &&
                                                               ((descriptor->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_MEMORY) != 0) == memory_effect &&
                                                               ((descriptor->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_FLAGS) != 0) == flags_effect &&
                                                               ((descriptor->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR) != 0) == terminator &&
                                                               (descriptor->clobber_mask != 0) == register_visible);
                                }
                                else
                                {
                                    u16 required = MACHINE_OPCODE_ATTRIBUTE_SIDE_EFFECTS |
                                                   ((effect_index & 2u) || fixtures[fixture].identity ? MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE : 0);
                                    MachineMemoryEffect memory = (effect_index & 1u) || fixtures[fixture].identity
                                                                     ? MACHINE_MEMORY_EFFECT_BARRIER
                                                                     : MACHINE_MEMORY_EFFECT_NONE;
                                    bool flags_define = info && (info->attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE) != 0;
                                    bool expected_flags = (effect_index & 2u) != 0 || fixtures[fixture].identity;
                                    BUSTER_TEST(arguments, info && (info->attributes & required) == required &&
                                                               flags_define == expected_flags &&
                                                               machine_opcode_memory_effect(info) == memory);
                                }
                                if (fixtures[fixture].identity)
                                {
                                    BUSTER_TEST(arguments, machine_opcode_operand_is_tied(info, 0, 1));
                                }
                            }
                        }
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

// The x86-64 atomic fixtures use the GNU asm idiom `=a` plus `a`: both the
// output and its comparison input intentionally name RAX.  Keep this check on
// the whole fixture so selection, placement and emitted execution agree on
// the alias instead of only accepting a synthetic instruction.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_inline_assembly_fixed_register_alias(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 paths[] = {S8("tests/basic_c_atomic_asm.c"), S8("tests/basic_musl_freestanding.c"),
                       S8("tests/basic_c_register_variable.c")};
    String8 names[][3] = {{S8("a_cas"), S8("a_cas_p")},
                          {S8("system_call3")},
                          {S8("syscall2"), S8("syscall4"), S8("syscall6")}};
    u32 name_counts[] = {2, 1, 3};
    u32 operand_counts[][3] = {{4, 4}, {5}, {4, 6, 8}};
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_BASELINE, .os = OPERATING_SYSTEM_LINUX};
    for (u32 fixture_index = 0; fixture_index < BUSTER_ARRAY_LENGTH(paths); fixture_index += 1)
    {
        String8 path = paths[fixture_index];
        ByteSlice input = file_read(arguments->arena, path, (FileReadOptions){0});
        String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
        BUSTER_TEST_RAW(arguments, input.length != 0, path);
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, path, source, target,
                                                                      (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 name_index = 0; name_index < name_counts[fixture_index]; name_index += 1)
                {
                    String8 name = names[fixture_index][name_index];
                    IrFunction* function = machine_test_ir_function_find(module, name);
                    BUSTER_TEST_RAW(arguments, function != 0, name);
                    if (!function) continue;
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                    BUSTER_TEST_RAW(arguments, selected.supported, name);
                    if (!selected.supported) continue;
                    BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                    BUSTER_TEST(arguments, selected.function.inline_assembly_count == 1);
                    if (selected.function.inline_assembly_count == 1)
                    {
                        MachineInlineAssembly* descriptor = selected.function.inline_assemblies;
                        BUSTER_TEST(arguments, descriptor->operand_count == operand_counts[fixture_index][name_index]);
                        if (descriptor->operand_count == operand_counts[fixture_index][name_index])
                        {
                            MachineInlineAssemblyOperand* operands = selected.function.inline_assembly_operands + descriptor->first_operand;
                            if (fixture_index == 0)
                            {
                                // GCC's descriptor order keeps both outputs
                                // first: A output, M output, A input, R
                                // input. The tied fixed register is therefore
                                // the (0, 2) pair, not adjacent operands.
                                BUSTER_TEST(arguments, operands[0].constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_A &&
                                                           operands[1].constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_M &&
                                                           operands[2].constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_A &&
                                                           operands[3].constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_R);
                                BUSTER_TEST(arguments, operands[0].physical_register == MACHINE_X64_RAX &&
                                                           operands[2].physical_register == MACHINE_X64_RAX);
                                BUSTER_TEST(arguments, (operands[0].flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT) != 0 &&
                                                           (operands[1].flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT) != 0 &&
                                                           (operands[2].flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT) != 0 &&
                                                           (operands[3].flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT) != 0);
                            }
                            else
                            {
                                BUSTER_TEST(arguments, operands[0].constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_A &&
                                                           operands[1].constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_A);
                                BUSTER_TEST(arguments, operands[0].physical_register == MACHINE_X64_RAX &&
                                                           operands[1].physical_register == MACHINE_X64_RAX);
                                BUSTER_TEST(arguments, (operands[0].flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT) != 0 &&
                                                           (operands[1].flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT) != 0);
                            }
                        }
                    }
                }
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(
                        temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                    if (fixture_index == 0 && generated.error == CODEGEN_ERROR_NONE && generated.relocation_count == 0)
                    {
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            u32 cas_offset = machine_test_module_offset(&generated, module, names[fixture_index][0]);
                            u32 cas_pointer_offset = machine_test_module_offset(&generated, module, names[fixture_index][1]);
                            BUSTER_TEST(arguments, cas_offset != UINT32_MAX && cas_pointer_offset != UINT32_MAX);
                            if (cas_offset != UINT32_MAX)
                            {
                                typedef int AtomicCompareExchange(volatile int*, int, int);
                                AtomicCompareExchange* call = 0;
                                void* address = (u8*)executable.address + cas_offset;
                                memcpy(&call, &address, sizeof(call));
                                volatile int cell = 5;
                                BUSTER_TEST(arguments, call(&cell, 5, 9) == 5 && cell == 9);
                                BUSTER_TEST(arguments, call(&cell, 5, 11) == 9 && cell == 9);
                            }
                            if (cas_pointer_offset != UINT32_MAX)
                            {
                                typedef void* AtomicCompareExchangePointer(volatile void*, void*, void*);
                                AtomicCompareExchangePointer* call = 0;
                                void* address = (u8*)executable.address + cas_pointer_offset;
                                memcpy(&call, &address, sizeof(call));
                                volatile void* cell = 0;
                                int first = 0;
                                int second = 0;
                                BUSTER_TEST(arguments, call(&cell, 0, &first) == 0 && cell == &first);
                                BUSTER_TEST(arguments, call(&cell, 0, &second) == &first && cell == &first);
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

// C validation rejects malformed duplicate fixed operands, but the selector
// is also a direct IR boundary. Probe duplicate outputs and an explicit RAX
// clobber against the valid atomic fixture without widening the source corpus
// or weakening the accepted output/input alias.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_inline_assembly_fixed_register_overlap(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 path = S8("tests/basic_c_atomic_asm.c");
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_BASELINE, .os = OPERATING_SYSTEM_LINUX};
    ByteSlice input = file_read(arguments->arena, path, (FileReadOptions){0});
    TemporalArena temporary = scratch_begin(&arguments->arena, 1);
    IrProgram* program = machine_test_compile_c(temporary.arena, path,
                                                 (String8){.pointer = (char8*)input.pointer, .length = input.length}, target);
    BUSTER_TEST(arguments, program && program->module_count == 1);
    if (program && program->module_count == 1)
    {
        IrFunction* function = machine_test_ir_function_find(program->modules, S8("a_cas"));
        BUSTER_TEST(arguments, function != 0);
        if (function)
        {
            MachineSelectResult baseline = machine_select_canonical_function(temporary.arena, program, function, target);
            BUSTER_TEST(arguments, baseline.supported);
            IrInstruction* inline_instruction = 0;
            IrInstructionId inline_id = {.value = IR_ID_UNDERLYING_INVALID};
            for (u32 instruction_index = 0; instruction_index < function->instruction_count; instruction_index += 1)
            {
                if (function->instructions[instruction_index].opcode == IR_OPCODE_INLINE_ASSEMBLY)
                {
                    inline_instruction = function->instructions + instruction_index;
                    inline_id.value = instruction_index;
                    break;
                }
            }
            BUSTER_TEST(arguments, inline_instruction && inline_instruction->operand_count >= 3);
            if (baseline.supported && inline_instruction && inline_instruction->operand_count >= 3)
            {
                u64 original_input_constraint = inline_instruction->immediates[2];
                inline_instruction->immediates[2] |= IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT;
                MachineSelectResult duplicate_outputs = machine_select_canonical_function_x86_64(
                    temporary.arena, program, function, target, false, true, true, false, 0);
                BUSTER_TEST(arguments, !duplicate_outputs.supported);
                inline_instruction->immediates[2] = original_input_constraint;

                IrInstructionExtra* extra = ir_instruction_extra_ensure(temporary.arena, function, inline_id);
                BUSTER_TEST(arguments, extra != 0);
                if (extra)
                {
                    String8* clobbers = arena_allocate(temporary.arena, String8, 1);
                    String8* original_clobbers = extra->clobbers;
                    u32 original_clobber_count = extra->clobber_count;
                    *clobbers = S8("rax");
                    extra->clobbers = clobbers;
                    extra->clobber_count = 1;
                    MachineSelectResult clobber_overlap = machine_select_canonical_function_x86_64(
                        temporary.arena, program, function, target, false, true, true, false, 0);
                    BUSTER_TEST(arguments, !clobber_overlap.supported);
                    extra->clobbers = original_clobbers;
                    extra->clobber_count = original_clobber_count;
                }
            }
        }
    }
    scratch_end(temporary);
    return result;
}

// UEFI uses the Win64 va_list pointer representation. Keep the complete
// platform-variadic fixtures as the regression input: the fold/forward pair
// exercises by-value and pointer va_list exchange, while each fixture's main
// (or host_run) retains its independent semantic oracle. UEFI objects cannot
// execute under a Linux host ABI, so this test proves the target ABI rows,
// verifier, module generation, and every MIR allocator across both frontend
// forms and PIC settings.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_x64_uefi_platform_variadic(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 paths[] = {S8("tests/basic_c_aarch64_platform_variadic.c"), S8("tests/differential/aarch64_platform_variadic.c"),
                       S8("tests/differential/aarch64_platform_variadic_host.c")};
    String8 names[][2] = {{S8("platform_va_fold"), S8("platform_va_forward")},
                          {S8("platform_va_fold"), S8("platform_va_forward")},
                          {S8("platform_va_host_fold"), S8("platform_va_host_forward")}};
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_BASELINE, .os = OPERATING_SYSTEM_UEFI};
    for (u32 fixture = 0; fixture < BUSTER_ARRAY_LENGTH(paths); fixture += 1)
    {
        ByteSlice input = file_read(arguments->arena, paths[fixture], (FileReadOptions){0});
        String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
        BUSTER_TEST_RAW(arguments, input.length != 0, paths[fixture]);
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            for (u32 position_independent = 0; position_independent < 2; position_independent += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                IrProgram* program = machine_test_compile_c_with_options(
                    temporary.arena, paths[fixture], source, target,
                    (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
                BUSTER_TEST(arguments, program && program->module_count == 1);
                if (program && program->module_count == 1)
                {
                    IrModule* module = program->modules;
                    for (u32 name_index = 0; name_index < 2; name_index += 1)
                    {
                        String8 name = names[fixture][name_index];
                        IrFunction* function = machine_test_ir_function_find(module, name);
                        BUSTER_TEST_RAW(arguments, function != 0, name);
                        if (!function) continue;
                        MachineSelectResult selected = machine_select_validated_canonical_function(
                            temporary.arena, program, function, target, position_independent != 0, true, false, 0);
                        BUSTER_TEST_RAW(arguments, selected.supported, name);
                        if (!selected.supported) continue;
                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        bool pointer_load = false;
                        for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                        {
                            u16 opcode = selected.function.instructions[row].opcode;
                            pointer_load |= opcode == MACHINE_X64_LOAD_PTR64;
                            BUSTER_TEST(arguments, opcode != MACHINE_X64_VA_ARG);
                        }
                        BUSTER_TEST(arguments, selected.function.va_arg_count == 0 && pointer_load);
                    }
                    for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                    {
                        CodegenModule generated = codegen_generate_canonical_module(
                            temporary.arena, program, module, target,
                            (CodegenModuleOptions){.position_independent = position_independent != 0,
                                                    .register_allocator = (u8)mode,
                                                    .verify_invariants = true});
                        BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                        BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_inline_assembly_goto(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 path = S8("tests/basic_c_asm_goto_identity.c");
    ByteSlice input = file_read(arguments->arena, path, (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    String8 names[] = {S8("goto_numeric"), S8("goto_named"), S8("goto_swap"), S8("goto_fallthrough"),
                       S8("goto_join"), S8("goto_loop"), S8("goto_no_operands"), S8("goto_conditional"),
                       S8("goto_multiple_targets"), S8("goto_read_write"), S8("goto_repeated_target")};
    BUSTER_TEST(arguments, input.length != 0);
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
    {
        Target target = {.cpu_arch = architectures[architecture], .cpu_model = CPU_MODEL_BASELINE, .os = OPERATING_SYSTEM_LINUX};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, path, source, target,
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                {
                    IrFunction* function = machine_test_ir_function_find(program->modules, names[name]);
                    BUSTER_TEST_RAW(arguments, function != 0, names[name]);
                    if (!function) continue;
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                    BUSTER_TEST_RAW(arguments, selected.supported, names[name]);
                    if (!selected.supported) continue;
                    BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                    u32 assembly_blocks = 0;
                    for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
                    {
                        IrInstruction* terminator = function->instructions + function->blocks[block_index].last_instruction.value;
                        if (terminator->opcode != IR_OPCODE_INLINE_ASSEMBLY) continue;
                        assembly_blocks += 1;
                        IrInstructionExtra extra = ir_instruction_extra(function, ir_instruction_self_id(function, terminator));
                        u32 target_index = 0;
                        bool recognized = !extra.literal.length ||
                                          ir_inline_assembly_jump_target(function, terminator, extra.literal, architectures[architecture] == CPU_ARCH_AARCH64 ? S8("b %l") : S8("jmp %l"), &target_index);
                        if (recognized)
                        {
                            MachineBlock* block = selected.function.blocks + block_index;
                            MachineInstruction* branch = selected.function.instructions + block->first_instruction + block->instruction_count - 1u;
                            u32 destination = terminator->targets[target_index].value;
                            BUSTER_TEST(arguments, branch->opcode == (architectures[architecture] == CPU_ARCH_AARCH64 ? MACHINE_A64_B : MACHINE_X64_JMP) && machine_ref_kind(branch->operands[0]) == MACHINE_REF_BLOCK &&
                                                   machine_ref_payload(branch->operands[0]) == destination);
                            u32 successors = 0;
                            for (u32 edge_index = 0; edge_index < selected.function.edge_count; edge_index += 1)
                            {
                                MachineEdge* edge = selected.function.edges + edge_index;
                                if (edge->source_block != block_index) continue;
                                successors += 1;
                                BUSTER_TEST(arguments, edge->destination_block == destination &&
                                                       edge->copy_count == selected.function.blocks[destination].parameter_count);
                            }
                            BUSTER_TEST(arguments, successors == 1);
                        }
                        else
                        {
                            u16 inline_opcode = architectures[architecture] == CPU_ARCH_AARCH64 ? MACHINE_A64_INLINE_ASSEMBLY
                                                                                                : MACHINE_X64_INLINE_ASSEMBLY;
                            u16 branch_opcode = architectures[architecture] == CPU_ARCH_AARCH64 ? MACHINE_A64_B : MACHINE_X64_JMP;
                            u32 assembly_row = UINT32_MAX;
                            for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                            {
                                if (selected.function.instructions[row].opcode == inline_opcode)
                                {
                                    assembly_row = row;
                                    break;
                                }
                            }
                            u32 source_block = UINT32_MAX;
                            for (u32 machine_block = 0; machine_block < selected.function.block_count; machine_block += 1)
                            {
                                MachineBlock* candidate = selected.function.blocks + machine_block;
                                if (assembly_row >= candidate->first_instruction && assembly_row - candidate->first_instruction < candidate->instruction_count)
                                {
                                    source_block = machine_block;
                                    break;
                                }
                            }
                            BUSTER_TEST(arguments, assembly_row != UINT32_MAX && source_block != UINT32_MAX);
                            if (assembly_row != UINT32_MAX && source_block != UINT32_MAX)
                            {
                                MachineInstruction* assembly_row_value = selected.function.instructions + assembly_row;
                                MachineInlineAssembly* descriptor = assembly_row_value->payload < selected.function.inline_assembly_count
                                                                        ? selected.function.inline_assemblies + assembly_row_value->payload
                                                                        : 0;
                                MachineBlock* source_block_info = selected.function.blocks + source_block;
                                u32 source_successors = 0;
                                for (u32 edge_index = 0; edge_index < selected.function.edge_count; edge_index += 1)
                                {
                                    source_successors += selected.function.edges[edge_index].source_block == source_block;
                                }
                                BUSTER_TEST(arguments, descriptor &&
                                                           (descriptor->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR) &&
                                                           descriptor->declared_successor_count == terminator->target_count &&
                                                           descriptor->successor_count >= descriptor->declared_successor_count &&
                                                           source_successors == descriptor->successor_count && source_block_info->instruction_count);
                                for (u32 successor = 0; successor < terminator->target_count; successor += 1)
                                {
                                    u32 continuation_block = source_block + 1u + successor;
                                    bool source_edge = false;
                                    u32 continuation_successors = 0;
                                    for (u32 edge_index = 0; edge_index < selected.function.edge_count; edge_index += 1)
                                    {
                                        MachineEdge* edge = selected.function.edges + edge_index;
                                        source_edge |= edge->source_block == source_block && edge->destination_block == continuation_block &&
                                                       !edge->copy_count;
                                        continuation_successors += edge->source_block == continuation_block;
                                    }
                                    BUSTER_TEST(arguments, source_edge);
                                    MachineBlock* continuation = selected.function.blocks + continuation_block;
                                    MachineInstruction* branch = selected.function.instructions + continuation->first_instruction + continuation->instruction_count - 1u;
                                    BUSTER_TEST(arguments, branch->opcode == branch_opcode && continuation_successors == 1);
                                }
                            }
                        }
                    }
                    BUSTER_TEST_RAW(arguments, assembly_blocks != 0, names[name]);
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_inline_hints(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 path = S8("tests/basic_c_inline_hints.c");
    ByteSlice input = file_read(arguments->arena, path, (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, input.length != 0);
    String8 names[] = {S8("hint_nop"), S8("hint_nop_clobbers"), S8("hint_spin"), S8("hint_spin_clobbers")};
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    String8 bytes[][2] = {{S8("\x90"), S8("\xf3\x90")}, {S8("\x1f\x20\x03\xd5"), S8("\x3f\x20\x03\xd5")}};
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
    {
        Target target = {.cpu_arch = architectures[architecture], .cpu_model = CPU_MODEL_BASELINE, .os = OPERATING_SYSTEM_LINUX};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, path, source, target,
                (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            for (u32 name = 0; program && name < BUSTER_ARRAY_LENGTH(names); name += 1)
            {
                IrFunction* function = machine_test_ir_function_find(program->modules, names[name]);
                BUSTER_TEST_RAW(arguments, function != 0, names[name]);
                if (function)
                {
                    MachineSelectResult selected;
                    MachineEncodeResult encoded = machine_test_encode(temporary.arena, program, function, target, &selected);
                    BUSTER_TEST_RAW(arguments, selected.supported && encoded.valid, names[name]);
                    if (selected.supported && encoded.valid)
                    {
                        u16 opcode = (u16)((architectures[architecture] == CPU_ARCH_X86_64
                                                ? MACHINE_X64_INLINE_EFFECTS_NONE
                                                : MACHINE_A64_INLINE_EFFECTS_NONE) +
                                           (name & 1u ? 3u : 0u));
                        String8 expected = bytes[architecture][name / 2];
                        u32 hint_count = 0;
                        for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                        {
                            if (selected.function.instructions[row].opcode == opcode)
                            {
                                hint_count += 1;
                                u32 offset = encoded.row_offsets[row];
                                BUSTER_TEST_RAW(arguments, (u64)offset + expected.length <= encoded.byte_count &&
                                    memcmp(encoded.bytes + offset, expected.pointer, expected.length) == 0, names[name]);
                            }
                        }
                        BUSTER_TEST_RAW(arguments, hint_count == 1, names[name]);
                        MachineOpcodeInfo const* info = machine_opcode_info(opcode);
                        u16 required = MACHINE_OPCODE_ATTRIBUTE_SIDE_EFFECTS |
                                       (name & 1u ? MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE : 0);
                        BUSTER_TEST(arguments, info && (info->attributes & required) == required &&
                            info->memory_effect == (name & 1u ? MACHINE_MEMORY_EFFECT_BARRIER : MACHINE_MEMORY_EFFECT_NONE) &&
                            info->clobber_mask == 0);
                    }
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_test_patch_aarch64_calls(CodegenModule* module)
{
    bool patched = !module->relocation_count || (module->relocations && module->entries && module->code.pointer);
    for (u32 index = 0; patched && index < module->relocation_count; index += 1)
    {
        CodegenModuleRelocation* relocation = module->relocations + index;
        bool found = false;
        if (codegen_module_relocation_valid(relocation) && relocation->source == CODEGEN_MODULE_RELOCATION_CODE &&
            relocation->kind == CODEGEN_MODULE_RELOCATION_AARCH64_CALL26 && !relocation->addend && !relocation->label_address &&
            !(relocation->offset & 3) && relocation->offset <= module->code.length && module->code.length - relocation->offset >= 4)
        {
            for (u32 entry = 0; !found && entry < module->entry_count; entry += 1)
            {
                CodegenModuleEntry* target = module->entries + entry;
                if (target->symbol.value == relocation->symbol.value && !(target->offset & 3) &&
                    target->offset <= module->code.length && module->code.length - target->offset >= 4)
                {
                    u32 instruction = 0;
                    u32 encoded = 0;
                    memcpy(&instruction, module->code.pointer + relocation->offset, sizeof(instruction));
                    s64 displacement = (s64)target->offset - (s64)relocation->offset;
                    found = a64_pc_relative_patch(A64_OPCODE_BL, instruction, displacement, &encoded);
                    if (found)
                    {
                        memcpy(module->code.pointer + relocation->offset, &encoded, sizeof(encoded));
                    }
                }
            }
        }
        patched = found;
    }
    return patched;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_aarch64_call_relocations(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u32 words[] = {UINT32_C(0x94000000), UINT32_C(0x94000000)};
    CodegenModuleEntry entries[] = {{.symbol = {.value = 1}, .offset = 4}, {.symbol = {.value = 2}, .offset = 0}};
    CodegenModuleRelocation relocations[] = {
        {.symbol = {.value = 1}, .kind = CODEGEN_MODULE_RELOCATION_AARCH64_CALL26},
        {.symbol = {.value = 2}, .offset = 4, .kind = CODEGEN_MODULE_RELOCATION_AARCH64_CALL26},
    };
    CodegenModule module = {.code = {.pointer = (u8*)words, .length = sizeof(words)}, .entries = entries, .entry_count = 2,
                            .relocations = relocations, .relocation_count = 2};
    BUSTER_TEST(arguments, machine_test_patch_aarch64_calls(&module));
    BUSTER_TEST(arguments, words[0] == UINT32_C(0x94000001) && words[1] == UINT32_C(0x97ffffff));
    for (u32 invalid = 0; invalid < 14; invalid += 1)
    {
        u32 instruction = UINT32_C(0x94000000);
        CodegenModuleEntry entry = entries[0];
        CodegenModuleRelocation relocation = relocations[0];
        CodegenModule rejected = {.code = {.pointer = (u8*)&instruction, .length = sizeof(instruction)},
                                  .entries = &entry, .entry_count = 1, .relocations = &relocation, .relocation_count = 1};
        entry.offset = 0;
        switch (invalid)
        {
            case 0: relocation.symbol.value = 3; break;
            case 1: relocation.offset = 1; break;
            case 2: relocation.offset = 4; break;
            case 3: entry.offset = 1; break;
            case 4: entry.offset = 4; break;
            case 5: relocation.addend = 4; break;
            case 6: relocation.source = CODEGEN_MODULE_RELOCATION_DATA; break;
            case 7: relocation.kind = CODEGEN_MODULE_RELOCATION_X86_64_PC32; break;
            case 8: instruction = UINT32_C(0x14000000); break;
            case 9: relocation.label_address = true; break;
            case 10: rejected.relocations = 0; break;
            case 11: rejected.entries = 0; break;
            case 12: rejected.code.pointer = 0; break;
            case 13: rejected.code.length = 3; break;
        }
        u32 before = instruction;
        BUSTER_TEST(arguments, !machine_test_patch_aarch64_calls(&rejected));
        BUSTER_TEST(arguments, instruction == before);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_inline_assembly_block_relocations(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    s64 displacement = 0;
    BUSTER_TEST(arguments, machine_x64_test_block_displacement(100, 7, 40, &displacement) && displacement == 67);
    BUSTER_TEST(arguments, !machine_x64_test_block_displacement(100, INT64_MIN, 40, &displacement));
    BUSTER_TEST(arguments, machine_a64_test_block_displacement(100, 7, 40, &displacement) && displacement == 67);
    BUSTER_TEST(arguments, !machine_a64_test_block_displacement(100, INT64_MIN, 40, &displacement));

    u32 words[2] = {0};
    BUSTER_TEST(arguments, machine_a64_test_expand_inline_short_branch(ASSEMBLY_RELOCATION_AARCH64_CONDBR19,
                                                                       UINT32_C(0x54000000), words));
    BUSTER_TEST(arguments, words[0] == UINT32_C(0x54000041) && words[1] == UINT32_C(0x14000000));
    BUSTER_TEST(arguments, machine_a64_test_expand_inline_short_branch(ASSEMBLY_RELOCATION_AARCH64_CONDBR19,
                                                                       UINT32_C(0x5400000e), words));
    BUSTER_TEST(arguments, words[0] == UINT32_C(0xd503201f) && words[1] == UINT32_C(0x14000000));
    BUSTER_TEST(arguments, machine_a64_test_expand_inline_short_branch(ASSEMBLY_RELOCATION_AARCH64_COMPAREBR19,
                                                                       UINT32_C(0x34000000), words));
    BUSTER_TEST(arguments, words[0] == UINT32_C(0x35000040) && words[1] == UINT32_C(0x14000000));
    BUSTER_TEST(arguments, machine_a64_test_expand_inline_short_branch(ASSEMBLY_RELOCATION_AARCH64_TESTBR14,
                                                                       UINT32_C(0x36000000), words));
    BUSTER_TEST(arguments, words[0] == UINT32_C(0x37000040) && words[1] == UINT32_C(0x14000000));
    BUSTER_TEST(arguments, !machine_a64_test_expand_inline_short_branch(ASSEMBLY_RELOCATION_AARCH64_BRANCH26,
                                                                        UINT32_C(0x14000000), words));
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_sysv_va_list_extent(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 source = S8("typedef __builtin_va_list List;"
        "int extent(int n, ...) { List ap; List copy; __builtin_va_start(ap, n);"
        " __builtin_va_copy(copy, ap); int v = __builtin_va_arg(copy, int);"
        " __builtin_va_end(copy); __builtin_va_end(ap); return v; }"
        "void finish(List* ap) { __builtin_va_end(*ap); }");
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_MACOS,
        OPERATING_SYSTEM_ANDROID, OPERATING_SYSTEM_IOS, OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_UEFI};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_BASELINE, .os = systems[system]};
        u32 bytes = system < 4 ? 24u : 8u;
        for (u32 form = 0; form < 2; form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("va-list-extent.c"), source, target,
                (CIRLowerOptions){.disable_direct_ssa = form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                BUSTER_TEST(arguments, module->function_count == 2);
                for (u32 index = 0; index < module->function_count; index += 1)
                {
                    IrFunction* function = module->functions + index;
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                    BUSTER_TEST_RAW(arguments, selected.supported, function->name);
                    if (selected.supported)
                    {
                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        bool copied = false;
                        for (u32 row_index = 0; row_index < selected.function.instruction_count; row_index += 1)
                        {
                            MachineInstruction* row = selected.function.instructions + row_index;
                            // Windows va_arg legitimately updates its cursor;
                            // a function containing only va_end must not do so.
                            if (string_equal(function->name, S8("finish")))
                            {
                                BUSTER_TEST(arguments, row->opcode != MACHINE_X64_STORE_PTR64);
                            }
                            if (row->opcode == MACHINE_X64_COPY_FRAME_FROM_PTR)
                            {
                                BUSTER_TEST(arguments, row->payload == bytes);
                                copied = true;
                            }
                            if (row->opcode == MACHINE_X64_STORE_FRAME64)
                            {
                                u32 slot = machine_ref_payload(row->operands[0]);
                                BUSTER_TEST(arguments, slot < selected.function.stack_slot_count);
                                if (slot < selected.function.stack_slot_count && selected.function.stack_slot_sizes[slot] == bytes)
                                {
                                    BUSTER_TEST(arguments, row->payload <= bytes - 8);
                                }
                            }
                        }
                        if (string_equal(function->name, S8("extent"))) { BUSTER_TEST(arguments, copied); }
                    }
                }
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
                }
                if (system < 4)
                {
                    // A synthetic private four-word result is no longer an
                    // admissible SysV VA_START/VA_COPY selection.
                    for (u32 type = 0; type < program->types.count; type += 1)
                    {
                        IrType* list = program->types.types + type;
                        if (list->kind == IR_TYPE_VA_LIST)
                        {
                            BUSTER_TEST(arguments, list->layout.size == 24);
                            list->layout.size = 32;
                        }
                    }
                    IrFunction* function = machine_test_ir_function_find(module, S8("extent"));
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        MachineSelectResult rejected = machine_select_canonical_function(temporary.arena, program, function, target);
                        BUSTER_TEST(arguments, !rejected.supported);
                    }
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_native_variadic(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/native_variadic.c"), (FileReadOptions){0});
    String8 source = string_format(arguments->arena, S8("#define BUSTER_MACHINE_VA_TEST 1\n{S8}"),
                                  (String8){.pointer = (char8*)input.pointer, .length = input.length});
    BUSTER_TEST(arguments, input.length != 0);
    String8 names[] = {S8("native_va_ints"), S8("native_va_floats"), S8("native_va_named"), S8("native_va_result"),
                       S8("native_va_small"), S8("native_va_indirect"), S8("native_va_hfa"), S8("native_va_hfa_overflow")};
    u32 named_bytes[] = {8, 16, 48, 16, 8, 8, 8, 64};
    Target targets[] = {{.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},
                        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_UEFI},
                        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
                        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS},
                        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX}};
    MachineOpcodeInfo const* save = machine_opcode_info(MACHINE_X64_WIN_VA_SAVE);
    u32 saved_registers[] = {MACHINE_X64_RCX, MACHINE_X64_RDX, MACHINE_X64_R8, MACHINE_X64_R9};
    BUSTER_TEST(arguments, save->operand_count == 4 && save->memory_effect == MACHINE_MEMORY_EFFECT_WRITE);
    for (u32 index = 0; index < 4; index += 1)
    {
        BUSTER_TEST(arguments, machine_opcode_fixed_register(save, index) == saved_registers[index]);
    }
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(targets); system += 1)
    {
        bool windows = system < 2;
        Target target = targets[system];
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            // This helper does not synthesize target predefines. Require the
            // guarded public-list cases explicitly for the ELF AArch64 target.
            String8 target_source = target.cpu_arch == CPU_ARCH_AARCH64
                ? string_format(temporary.arena, S8("#define BUSTER_MACHINE_VA_ELF_AARCH64 1\n{S8}"), source) : source;
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("native-variadic.c"), target_source, target,
                                                                     (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                {
                    IrFunction* function = machine_test_ir_function_find(module, names[name]);
                    BUSTER_TEST(arguments, function != 0);
                    if (function)
                    {
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                        BUSTER_TEST_RAW(arguments, selected.supported, names[name]);
                        if (selected.supported)
                        {
                            BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                            if (target.cpu_arch == CPU_ARCH_AARCH64)
                            {
                                u32 homes = 0;
                                for (u32 index = 0; index < selected.function.instruction_count; index += 1)
                                {
                                    MachineInstruction* row = selected.function.instructions + index;
                                    if (row->opcode == MACHINE_A64_VA_SAVE)
                                    {
                                        u32 slot = machine_ref_payload(row->operands[0]);
                                        u32 size = selected.function.stack_slot_sizes[slot];
                                        BUSTER_TEST(arguments, size == 192);
                                        selected.function.stack_slot_sizes[slot] = 191;
                                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                        selected.function.stack_slot_sizes[slot] = size;
                                        homes += 1;
                                    }
                                }
                                BUSTER_TEST(arguments, homes == 1);
                            }
                            if (windows)
                            {
                                u32 homes = 0;
                                u32 starts = 0;
                                for (u32 index = 0; index < selected.function.instruction_count; index += 1)
                                {
                                    MachineInstruction* row = selected.function.instructions + index;
                                    homes += row->opcode == MACHINE_X64_WIN_VA_SAVE;
                                    if (row->opcode == MACHINE_X64_LEA_INCOMING)
                                    {
                                        starts += 1;
                                        BUSTER_TEST(arguments, row->payload == named_bytes[name]);
                                    }
                                    BUSTER_TEST(arguments, row->opcode != MACHINE_X64_VA_ARG && row->opcode != MACHINE_X64_VA_SAVE);
                                }
                                BUSTER_TEST(arguments, homes == 1 && starts == 1);
                            }
                        }
                    }
                }
                if (target.cpu_arch == CPU_ARCH_AARCH64)
                {
                    String8 public_names[] = {S8("native_va_list_read"), S8("native_va_list_produce"), S8("native_va_list_named"),
                                              S8("native_va_list_value"), S8("native_va_list_pass_value"), S8("native_va_list_call_extended"), S8("native_va_hva_identity"), S8("native_va_list_named_vector")};
                    for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(public_names); name += 1)
                    {
                        IrFunction* function = machine_test_ir_function_find(module, public_names[name]);
                        BUSTER_TEST_RAW(arguments, function != 0, public_names[name]);
                        if (function)
                        {
                            MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                            BUSTER_TEST_RAW(arguments, selected.supported, public_names[name]);
                            if (selected.supported)
                            {
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                                if (name == 0)
                                {
                                    bool aligned_pair = false;
                                    bool floating = false;
                                    bool large_hfa = false;
                                    bool indirect = false;
                                    bool vector = false;
                                    for (u32 index = 0; index < selected.function.va_arg_count; index += 1)
                                    {
                                        MachineVaArg* value = selected.function.va_args + index;
                                        aligned_pair |= value->alignment == 16 && value->part_count == 2 && !value->parts[0].is_float;
                                        floating |= value->parts[0].is_float != 0;
                                        large_hfa |= value->size == 24 && value->part_count == 3 && value->parts[0].is_float;
                                        indirect |= value->size == 17 && value->stack_size == 8 && value->indirect;
                                        vector |= value->size == 32 && value->part_count == 2 && value->parts[0].size == 16;
                                    }
                                    BUSTER_TEST(arguments, aligned_pair && floating && large_hfa && indirect && vector);
                                }
                            }
                        }
                    }
                }
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
                    // Public AAPCS64 list helpers call other local functions.
                    // Resolve their checked BL relocations on every test host;
                    // unresolved or invalid rows must never reach JIT execution.
                    bool patched = generated.error == CODEGEN_ERROR_NONE && (target.cpu_arch == CPU_ARCH_AARCH64
                        ? machine_test_patch_aarch64_calls(&generated) : generated.relocation_count == 0);
                    BUSTER_TEST(arguments, patched);
#if (BUSTER_CPU_ARCH_X86_64 || (BUSTER_CPU_ARCH_AARCH64 && !BUSTER_WINDOWS)) && !BUSTER_SANITIZE
                    bool native_abi = BUSTER_WINDOWS ? windows : !windows;
                    bool native_arch = BUSTER_CPU_ARCH_X86_64 ? target.cpu_arch == CPU_ARCH_X86_64
                                                              : target.cpu_arch == CPU_ARCH_AARCH64 && BUSTER_LINUX;
                    if (native_abi && native_arch && generated.error == CODEGEN_ERROR_NONE && patched)
                    {
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            struct VaResult { s64 sum; s64 count; };
                            struct VaSmall1 { s8 value; };
                            struct VaSmall2 { s16 value; };
                            struct VaSmall4 { s32 value; };
                            struct VaSmall8 { s64 value; };
                            struct VaIndirect { s64 first; s64 second; };
                            typedef s64 VaInts(s32, ...);
                            typedef f64 VaFloats(f64, s32, ...);
                            typedef s64 VaNamed(s64, f64, s64, f64, s64, s32, ...);
                            typedef struct VaResult VaResultCall(s32, ...);
                            for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                            {
                                u32 offset = machine_test_module_offset(&generated, module, names[name]);
                                BUSTER_TEST(arguments, offset != UINT32_MAX);
                                if (offset != UINT32_MAX)
                                {
                                    void* address = (u8*)executable.address + offset;
                                    VaInts* integers = 0;
                                    memcpy(&integers, &address, sizeof(integers));
                                    if (name == 0)
                                    {
                                        BUSTER_TEST(arguments, integers(0) == 0);
                                        BUSTER_TEST(arguments, integers(7, 1ll, 2ll, 3ll, 4ll, 5ll, 6ll, 7ll) == 140);
                                    }
                                    else if (name == 1)
                                    {
                                        VaFloats* floats = 0;
                                        memcpy(&floats, &address, sizeof(floats));
                                        BUSTER_TEST(arguments, floats(1.5, 4, 2.5, 3.5, 4.5, 5.5) == 62.0);
                                        BUSTER_TEST(arguments, floats(1.5, 10, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0) == 394.5);
                                    }
                                    else if (name == 2)
                                    {
                                        VaNamed* named = 0;
                                        memcpy(&named, &address, sizeof(named));
                                        BUSTER_TEST(arguments, named(1ll, 2.0, 3ll, 4.0, 5ll, 5, 6ll, 7ll, 8ll, 9ll, 10ll) == 55);
                                    }
                                    else if (name == 3)
                                    {
                                        VaResultCall* aggregate = 0;
                                        memcpy(&aggregate, &address, sizeof(aggregate));
                                        struct VaResult actual = aggregate(5, 1ll, 2ll, 3ll, 4ll, 5ll);
                                        BUSTER_TEST(arguments, actual.sum == 15 && actual.count == 5);
                                    }
                                    else if (name == 4)
                                    {
                                        struct VaSmall1 a = {-3};
                                        struct VaSmall2 b = {-301};
                                        struct VaSmall4 c = {-70001};
                                        struct VaSmall8 d = {-0x123456789ll};
                                        BUSTER_TEST(arguments, integers(17, a, b, c, d, 99ll) == (17ll - 3 - 301 - 70001 - 0x123456789ll + 99));
                                    }
                                    else if (name == 5)
                                    {
                                        struct VaIndirect a = {2, 3};
                                        struct VaIndirect b = {5, 6};
                                        struct VaIndirect c = {7, 8};
                                        BUSTER_TEST(arguments, integers(1, a, 4ll, b, c, 9ll) == 144);
                                    }
                                    else
                                    {
                                        struct Hfa4 { f32 a; f32 b; f32 c; f32 d; } hfa4 = {1, 2, 3, 4};
                                        struct Hfa2 { f64 a; f64 b; } hfa2 = {5, 6};
                                        if (name == 6)
                                        {
                                            typedef f64 HfaCall(s32, ...);
                                            HfaCall* hfa = 0;
                                            memcpy(&hfa, &address, sizeof(hfa));
                                            BUSTER_TEST(arguments, hfa(1, hfa4, hfa2, 7.0) == 99.0);
                                        }
                                        else
                                        {
                                            typedef f64 HfaOverflow(f64, f64, f64, f64, f64, f64, f64, s32, ...);
                                            HfaOverflow* hfa = 0;
                                            memcpy(&hfa, &address, sizeof(hfa));
                                            BUSTER_TEST(arguments, hfa(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 1, hfa4, hfa2, 7.0) == 77.0);
                                        }
                                    }
                                }
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

// Every split transfer owns its frame range and names its physical ABI
// register. Invalid offsets must fail before placement or encoding.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_wide_vector_boundaries(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/basic_c_wide_vector_abi.c"), (FileReadOptions){0});
    BUSTER_TEST(arguments, input.length != 0);
    CpuModel models[] = {CPU_MODEL_BASELINE, CPU_MODEL_INTEL_HASWELL, CPU_MODEL_AMD_ZEN_5};
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_MACOS, OPERATING_SYSTEM_IOS};
    for (u32 combination = 0; combination < BUSTER_ARRAY_LENGTH(models) * BUSTER_ARRAY_LENGTH(systems); combination += 1)
    {
        u32 model = combination % BUSTER_ARRAY_LENGTH(models);
        u32 system = combination / BUSTER_ARRAY_LENGTH(models);
        u32 alignment = system && !model ? 16u : 32u;
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = models[model], .os = systems[system]};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("wide-vector-abi.c"),
                (String8){.pointer = (char8*)input.pointer, .length = input.length}, target,
                (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            u32 transfers = 0;
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                BUSTER_TEST(arguments, module->function_count == 5);
                for (u32 index = 0; index < module->function_count; index += 1)
                {
                    IrFunction* function = module->functions + index;
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                    BUSTER_TEST_RAW(arguments, selected.supported, function->name);
                    if (selected.supported)
                    {
                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        for (u32 va = 0; va < selected.function.va_arg_count; va += 1)
                        {
                            MachineVaArg* metadata = selected.function.va_args + va;
                            if (metadata->size == 32)
                            {
                                BUSTER_TEST(arguments, metadata->alignment == alignment && metadata->part_count == 1 && metadata->parts[0].is_memory);
                                metadata->alignment = 128;
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                metadata->alignment = alignment;
                                metadata->parts[0].is_memory = 0;
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                metadata->parts[0].is_memory = 1;
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                            }
                        }
                        for (u32 row_index = 0; row_index < selected.function.instruction_count; row_index += 1)
                        {
                            MachineInstruction* row = selected.function.instructions + row_index;
                            bool xmm = row->opcode == MACHINE_X64_LOAD_XMM_FRAME128 || row->opcode == MACHINE_X64_STORE_XMM_FRAME128;
                            bool ymm = row->opcode == MACHINE_X64_LOAD_YMM_FRAME256 || row->opcode == MACHINE_X64_STORE_YMM_FRAME256;
                            if (xmm || ymm)
                            {
                                transfers += 1;
                                BUSTER_TEST(arguments, (model == 0) == xmm);
                                BUSTER_TEST(arguments, machine_ref_kind(row->operands[0]) == MACHINE_REF_PHYSICAL_REGISTER);
                                u32 slot = machine_ref_payload(row->operands[1]);
                                u32 size = selected.function.stack_slot_sizes[slot];
                                u32 offset = row->payload;
                                row->payload = UINT32_MAX;
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                row->payload = offset;
                                selected.function.stack_slot_sizes[slot] = offset + (ymm ? 32u : 16u) - 1u;
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                selected.function.stack_slot_sizes[slot] = size;
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                            }
                        }
                    }
                }
            }
            BUSTER_TEST(arguments, transfers != 0);
            scratch_end(temporary);
        }
    }
    return result;
}

#if BUSTER_CPU_ARCH_X86_64 && BUSTER_COMPILER_CLANG && !BUSTER_SANITIZE
typedef unsigned __int128 MachineTestWin64Wide;
struct MachineTestWin64Big { unsigned long long words[5]; };
typedef MachineTestWin64Wide __attribute__((ms_abi)) MachineTestWin64Mix(MachineTestWin64Wide, double, MachineTestWin64Wide,
                                                                       unsigned long long, MachineTestWin64Wide, MachineTestWin64Wide);
typedef MachineTestWin64Wide __attribute__((ms_abi)) MachineTestWin64Variadic(int, ...);

BUSTER_GLOBAL_LOCAL MachineTestWin64Wide __attribute__((ms_abi)) machine_test_win64_host_mix(MachineTestWin64Wide a, double b,
    MachineTestWin64Wide c, unsigned long long d, MachineTestWin64Wide e, MachineTestWin64Wide f)
{
    return a + 2 * c + 3 * e + 4 * f + (unsigned long long)b + d;
}

BUSTER_GLOBAL_LOCAL MachineTestWin64Wide __attribute__((ms_abi)) machine_test_win64_host_variadic(int marker, ...)
{
    __builtin_ms_va_list cursor;
    __builtin_ms_va_start(cursor, marker);
    MachineTestWin64Wide a = __builtin_va_arg(cursor, MachineTestWin64Wide);
    struct MachineTestWin64Big b = __builtin_va_arg(cursor, struct MachineTestWin64Big);
    MachineTestWin64Wide c = __builtin_va_arg(cursor, MachineTestWin64Wide);
    struct MachineTestWin64Big d = __builtin_va_arg(cursor, struct MachineTestWin64Big);
    MachineTestWin64Wide e = __builtin_va_arg(cursor, MachineTestWin64Wide);
    unsigned long long tail = __builtin_va_arg(cursor, unsigned long long);
    __builtin_ms_va_end(cursor);
    MachineTestWin64Wide result = 2 * a + 2 * c + 3 * e + (unsigned long long)marker + tail;
    for (u32 index = 0; index < 5; index += 1) { result += (index + 1) * b.words[index] + (index + 6) * d.words[index]; }
    return result;
}
#endif

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_win64_wide(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/win64_wide.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, input.length != 0);
    OperatingSystem systems[] = {OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_UEFI};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_BASELINE, .os = systems[system]};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("win64-wide.c"), source, target,
                (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 index = 0; index < module->function_count; index += 1)
                {
                    IrFunction* function = module->functions + index;
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                    BUSTER_TEST_RAW(arguments, selected.supported, function->name);
                    if (selected.supported)
                    {
                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        u32 returns = 0;
                        for (u32 row_index = 0; row_index < selected.function.instruction_count; row_index += 1)
                        {
                            MachineInstruction* row = selected.function.instructions + row_index;
                            if (row->opcode == MACHINE_X64_LOAD_XMM0_FRAME128 || row->opcode == MACHINE_X64_STORE_XMM0_FRAME128)
                            {
                                returns += row->opcode == MACHINE_X64_LOAD_XMM0_FRAME128;
                                u32 slot = machine_ref_payload(row->operands[0]);
                                u32 size = selected.function.stack_slot_sizes[slot];
                                selected.function.stack_slot_sizes[slot] = 15;
                                BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                selected.function.stack_slot_sizes[slot] = size;
                            }
                        }
                        BUSTER_TEST(arguments, returns == 1);
                    }
                }
                // The direct backend does not implement wide variadic reads.
                for (u32 mode = CODEGEN_REGISTER_ALLOCATOR_MIR_STACK; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.function_count == 4 && generated.statistics.fallback_function_count == 0);
#if BUSTER_CPU_ARCH_X86_64 && BUSTER_COMPILER_CLANG && !BUSTER_SANITIZE
                    if (generated.error == CODEGEN_ERROR_NONE)
                    {
                        // Clang's ms_abi lets Linux/macOS hosts execute these
                        // Windows calling conventions without a PE loader.
                        // Each boundary crosses an independent host compiler.
                        BUSTER_TEST(arguments, generated.relocation_count == 0);
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            String8 names[] = {S8("win64_wide_mix"), S8("win64_wide_dispatch"), S8("win64_wide_variadic"),
                                               S8("win64_wide_variadic_dispatch")};
                            MachineTestWin64Wide value = ((MachineTestWin64Wide)UINT64_C(0x92345678abcdef01) << 64) |
                                                        UINT64_C(0x123456789abcdef0);
                            struct MachineTestWin64Big a = {{1, 2, 3, 4, 5}};
                            struct MachineTestWin64Big b = {{6, 7, 8, 9, 10}};
                            for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(names); name += 1)
                            {
                                u32 offset = machine_test_module_offset(&generated, module, names[name]);
                                BUSTER_TEST(arguments, offset != UINT32_MAX);
                                if (offset != UINT32_MAX)
                                {
                                    void* address = (u8*)executable.address + offset;
                                    MachineTestWin64Wide expected;
                                    MachineTestWin64Wide actual;
                                    if (name == 0)
                                    {
                                        MachineTestWin64Mix* call;
                                        memcpy(&call, &address, sizeof(call));
                                        expected = 10 * value + 42;
                                        actual = call(value, 9.0, value + 1, 13, value + 2, value + 3);
                                    }
                                    else if (name == 1)
                                    {
                                        typedef MachineTestWin64Wide __attribute__((ms_abi)) Dispatch(MachineTestWin64Mix*, MachineTestWin64Wide);
                                        Dispatch* call;
                                        memcpy(&call, &address, sizeof(call));
                                        expected = 11 * value + 42;
                                        actual = call(machine_test_win64_host_mix, value);
                                    }
                                    else if (name == 2)
                                    {
                                        MachineTestWin64Variadic* call;
                                        memcpy(&call, &address, sizeof(call));
                                        expected = 7 * value + 411;
                                        actual = call(7, value, a, value + 1, b, value + 2, 11ull);
                                    }
                                    else
                                    {
                                        typedef MachineTestWin64Wide __attribute__((ms_abi)) Dispatch(MachineTestWin64Variadic*, MachineTestWin64Wide);
                                        Dispatch* call;
                                        memcpy(&call, &address, sizeof(call));
                                        expected = 8 * value + 422;
                                        actual = call(machine_test_win64_host_variadic, value);
                                    }
                                    BUSTER_TEST_RAW(arguments, actual == expected, names[name]);
                                }
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

#if BUSTER_CPU_ARCH_X86_64 && BUSTER_COMPILER_CLANG && !BUSTER_SANITIZE
struct MachineTestWin64Aligned32 { _Alignas(32) unsigned long long words[4]; };
struct MachineTestWin64Aligned64 { _Alignas(64) unsigned long long words[8]; };
struct MachineTestWin64Aligned128 { _Alignas(128) unsigned long long words[16]; };
typedef unsigned long long __attribute__((ms_abi)) MachineTestWin64AlignedMix(struct MachineTestWin64Aligned32, double,
    struct MachineTestWin64Aligned64, unsigned long long, struct MachineTestWin64Aligned128, unsigned long long);
typedef unsigned long long __attribute__((ms_abi)) MachineTestWin64AlignedVariadic(int, ...);

BUSTER_GLOBAL_LOCAL unsigned long long __attribute__((ms_abi)) machine_test_win64_host_aligned_mix(
    volatile struct MachineTestWin64Aligned32 a, double b, volatile struct MachineTestWin64Aligned64 c,
    unsigned long long d, volatile struct MachineTestWin64Aligned128 e, unsigned long long tail)
{
    volatile u64 a_address = (u64)&a;
    volatile u64 c_address = (u64)&c;
    volatile u64 e_address = (u64)&e;
    u64 invalid_alignment = (a_address & 31) != 0 || (c_address & 63) != 0 || (e_address & 127) != 0;
    unsigned long long sum = (unsigned long long)b + d + tail;
    for (u32 index = 0; index < 4; index += 1) { sum += (index + 1) * a.words[index]; }
    for (u32 index = 0; index < 8; index += 1) { sum += (index + 5) * c.words[index]; }
    for (u32 index = 0; index < 16; index += 1) { sum += (index + 13) * e.words[index]; }
    a.words[0] = 0;
    c.words[7] = 0;
    e.words[15] = 0;
    return sum | (invalid_alignment << 63);
}

BUSTER_GLOBAL_LOCAL unsigned long long __attribute__((ms_abi)) machine_test_win64_host_aligned_variadic(int marker, ...)
{
    __builtin_ms_va_list cursor;
    __builtin_ms_va_start(cursor, marker);
    // Read the actual argument pointers before va_arg can copy into an aligned
    // local. This independently observes the caller's anonymous-copy storage.
    u64 a_address;
    memcpy(&a_address, cursor, sizeof(a_address));
    struct MachineTestWin64Aligned32 a = __builtin_va_arg(cursor, struct MachineTestWin64Aligned32);
    double b = __builtin_va_arg(cursor, double);
    u64 c_address;
    memcpy(&c_address, cursor, sizeof(c_address));
    struct MachineTestWin64Aligned64 c = __builtin_va_arg(cursor, struct MachineTestWin64Aligned64);
    unsigned long long d = __builtin_va_arg(cursor, unsigned long long);
    u64 e_address;
    memcpy(&e_address, cursor, sizeof(e_address));
    struct MachineTestWin64Aligned128 e = __builtin_va_arg(cursor, struct MachineTestWin64Aligned128);
    unsigned long long tail = __builtin_va_arg(cursor, unsigned long long);
    __builtin_ms_va_end(cursor);
    u64 invalid_alignment = (a_address & 31) != 0 || (c_address & 63) != 0 || (e_address & 127) != 0;
    unsigned long long sum = (unsigned long long)marker + (unsigned long long)b + d + tail + a.words[0] + a.words[3];
    for (u32 index = 0; index < 4; index += 1) { sum += (index + 1) * a.words[index]; }
    for (u32 index = 0; index < 8; index += 1) { sum += (index + 5) * c.words[index]; }
    for (u32 index = 0; index < 16; index += 1) { sum += (index + 13) * e.words[index]; }
    *(volatile u64*)a_address = 0;
    ((volatile u64*)c_address)[7] = 0;
    ((volatile u64*)e_address)[15] = 0;
    return sum | (invalid_alignment << 63);
}
#endif

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_win64_aligned(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/win64_aligned.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, input.length != 0);
    OperatingSystem systems[] = {OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_UEFI};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_BASELINE, .os = systems[system]};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            for (u32 variant = 0; variant < 2; variant += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                // Wide variadic reads remain unsupported by the direct oracle;
                // its fixed pair is an additional NONE interoperability gate.
                String8 variant_source = variant ? source : string_format(temporary.arena, S8("#define WIN64_ALIGNED_FIXED_ONLY 1\n{S8}"), source);
                IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("win64-aligned.c"), variant_source, target,
                    (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
                BUSTER_TEST(arguments, program && program->module_count == 1);
                if (program && program->module_count == 1)
                {
                    IrModule* module = program->modules;
                    u32 mode_begin = variant ? CODEGEN_REGISTER_ALLOCATOR_MIR_STACK : CODEGEN_REGISTER_ALLOCATOR_NONE;
                    u32 mode_end = variant ? CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT : CODEGEN_REGISTER_ALLOCATOR_MIR_STACK;
                    for (u32 mode = mode_begin; mode < mode_end; mode += 1)
                    {
                        CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                            (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                        BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                        BUSTER_TEST(arguments, generated.statistics.function_count == (variant ? 4u : 2u));
                        BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
#if BUSTER_CPU_ARCH_X86_64 && BUSTER_COMPILER_CLANG && !BUSTER_SANITIZE
                        if (generated.error == CODEGEN_ERROR_NONE)
                        {
                            BUSTER_TEST(arguments, generated.relocation_count == 0);
                            CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                            BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                            if (executable.address)
                            {
                                String8 names[] = {S8("win64_aligned_mix"), S8("win64_aligned_dispatch"), S8("win64_aligned_variadic"),
                                                   S8("win64_aligned_variadic_dispatch")};
                                for (u32 name = 0; name < (variant ? 4u : 2u); name += 1)
                                {
                                    u32 offset = machine_test_module_offset(&generated, module, names[name]);
                                    BUSTER_TEST(arguments, offset != UINT32_MAX);
                                    if (offset != UINT32_MAX)
                                    {
                                        void* address = (u8*)executable.address + offset;
                                        // Different live allocation sizes visit every sixteen-byte
                                        // residue modulo the strongest (128-byte) argument alignment.
                                        for (unsigned long long seed = 1; seed < 128; seed += 16)
                                        {
                                            struct MachineTestWin64Aligned32 a = {0};
                                            struct MachineTestWin64Aligned64 b = {0};
                                            struct MachineTestWin64Aligned128 c = {0};
                                            for (u32 index = 0; index < 4; index += 1) { a.words[index] = seed + index + 1; }
                                            for (u32 index = 0; index < 8; index += 1) { b.words[index] = seed + index + 5; }
                                            for (u32 index = 0; index < 16; index += 1) { c.words[index] = seed + index + 13; }
                                            unsigned long long expected;
                                            unsigned long long actual;
                                            if (name == 0)
                                            {
                                                MachineTestWin64AlignedMix* call;
                                                memcpy(&call, &address, sizeof(call));
                                                expected = 406 * seed + 7753;
                                                actual = call(a, 9.0, b, 13, c, 17);
                                            }
                                            else if (name == 1)
                                            {
                                                typedef unsigned long long __attribute__((ms_abi)) Dispatch(MachineTestWin64AlignedMix*, unsigned long long);
                                                Dispatch* call;
                                                memcpy(&call, &address, sizeof(call));
                                                expected = 409 * seed + 7850;
                                                actual = call(machine_test_win64_host_aligned_mix, seed);
                                            }
                                            else if (name == 2)
                                            {
                                                MachineTestWin64AlignedVariadic* call;
                                                memcpy(&call, &address, sizeof(call));
                                                expected = 408 * seed + 7765;
                                                actual = call(7, a, 9.0, b, 13ull, c, 17ull);
                                            }
                                            else
                                            {
                                                typedef unsigned long long __attribute__((ms_abi)) Dispatch(MachineTestWin64AlignedVariadic*, unsigned long long);
                                                Dispatch* call;
                                                memcpy(&call, &address, sizeof(call));
                                                expected = 411 * seed + 7806;
                                                actual = call(machine_test_win64_host_aligned_variadic, seed);
                                            }
                                            BUSTER_TEST_RAW(arguments, actual == expected, string_format(temporary.arena,
                                                S8("{S8} mode={u32} seed={u64} actual={u64} expected={u64}"), names[name], mode, (u64)seed, (u64)actual, (u64)expected));
                                            BUSTER_TEST(arguments, a.words[0] == seed + 1 && b.words[7] == seed + 12 && c.words[15] == seed + 28);
                                        }
                                    }
                                }
                            }
                            codegen_release_executable(executable);
                        }
#endif
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

#if BUSTER_CPU_ARCH_X86_64 && BUSTER_COMPILER_CLANG && !BUSTER_SANITIZE
#define MACHINE_TEST_WIN64_VECTOR_TARGET __attribute__((target("avx512f,avx512bw")))
typedef unsigned long long MachineTestWin64Vector __attribute__((vector_size(64)));
typedef MachineTestWin64Vector __attribute__((ms_abi)) MachineTestWin64VectorMix(MachineTestWin64Vector, double,
    MachineTestWin64Vector, unsigned long long, MachineTestWin64Vector, unsigned long long);
typedef MachineTestWin64Vector __attribute__((ms_abi)) MachineTestWin64VectorVariadic(MachineTestWin64Vector, int, ...);

BUSTER_GLOBAL_LOCAL MACHINE_TEST_WIN64_VECTOR_TARGET MachineTestWin64Vector __attribute__((ms_abi)) machine_test_win64_host_vector_mix(
    volatile MachineTestWin64Vector a, double b, volatile MachineTestWin64Vector c, unsigned long long d,
    volatile MachineTestWin64Vector e, unsigned long long tail)
{
    volatile u64 a_address = (u64)&a;
    volatile u64 c_address = (u64)&c;
    volatile u64 e_address = (u64)&e;
    MachineTestWin64Vector lane = {1, 2, 3, 4, 5, 6, 7, 8};
    MachineTestWin64Vector sum = a + c + c + e + e + e + lane;
    if (((a_address | c_address | e_address) & 63) != 0 || b != 9.0 || d != 13 || tail != 17)
    {
        sum ^= (MachineTestWin64Vector){1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63};
    }
    a = (MachineTestWin64Vector){0};
    c = (MachineTestWin64Vector){0};
    e = (MachineTestWin64Vector){0};
    return sum;
}

BUSTER_GLOBAL_LOCAL MACHINE_TEST_WIN64_VECTOR_TARGET MachineTestWin64Vector __attribute__((ms_abi)) machine_test_win64_host_vector_variadic(MachineTestWin64Vector named, int marker, ...)
{
    __builtin_ms_va_list cursor;
    __builtin_ms_va_start(cursor, marker);
    u64 a_address;
    memcpy(&a_address, cursor, sizeof(a_address));
    MachineTestWin64Vector a = __builtin_va_arg(cursor, MachineTestWin64Vector);
    double b = __builtin_va_arg(cursor, double);
    u64 c_address;
    memcpy(&c_address, cursor, sizeof(c_address));
    MachineTestWin64Vector c = __builtin_va_arg(cursor, MachineTestWin64Vector);
    unsigned long long d = __builtin_va_arg(cursor, unsigned long long);
    u64 e_address;
    memcpy(&e_address, cursor, sizeof(e_address));
    MachineTestWin64Vector e = __builtin_va_arg(cursor, MachineTestWin64Vector);
    __builtin_ms_va_end(cursor);
    MachineTestWin64Vector lane = {1, 2, 3, 4, 5, 6, 7, 8};
    MachineTestWin64Vector sum = a + a + c + c + e + e + e + named + lane;
    if (((a_address | c_address | e_address) & 63) != 0 || marker != 7 || b != 9.0 || d != 13)
    {
        sum ^= (MachineTestWin64Vector){1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63, 1ull << 63};
    }
    *(volatile MachineTestWin64Vector*)a_address = (MachineTestWin64Vector){0};
    *(volatile MachineTestWin64Vector*)c_address = (MachineTestWin64Vector){0};
    *(volatile MachineTestWin64Vector*)e_address = (MachineTestWin64Vector){0};
    return sum;
}

// Keep every host vector call in an explicitly AVX-512 function, so a baseline
// host build still compiles these tests with the same full-ZMM return ABI.
BUSTER_GLOBAL_LOCAL MACHINE_TEST_WIN64_VECTOR_TARGET UnitTestResult machine_test_win64_vector_execute(UnitTestArguments* arguments,
    CodegenModule* generated, IrModule* module, u32 mode, bool variadic)
{
    UnitTestResult result = {0};
    BUSTER_TEST(arguments, generated->relocation_count == 0);
    CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated->code});
    BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
    if (executable.address)
    {
        String8 names[] = {S8("win64_vector_mix"), S8("win64_vector_dispatch"), S8("win64_vector_variadic"), S8("win64_vector_variadic_dispatch")};
        for (u32 name = 0; name < (variadic ? 4u : 2u); name += 1)
        {
            u32 offset = machine_test_module_offset(generated, module, names[name]);
            BUSTER_TEST(arguments, offset != UINT32_MAX);
            if (offset != UINT32_MAX)
            {
                void* address = (u8*)executable.address + offset;
                for (unsigned long long seed = 1; seed < 128; seed += 16)
                {
                    MachineTestWin64Vector value = {0};
                    MachineTestWin64Vector lane = {1, 2, 3, 4, 5, 6, 7, 8};
                    for (u32 index = 0; index < 8; index += 1)
                    {
                        value[index] = UINT64_C(0xfedcba9876543210) + seed * UINT64_C(0x0102030405060708) + index * 1234567ull;
                    }
                    MachineTestWin64Vector actual;
                    u64 coefficient;
                    u64 bias = 0;
                    if (name == 0)
                    {
                        MachineTestWin64VectorMix* call;
                        memcpy(&call, &address, sizeof(call));
                        actual = call(value, 9.0, value + lane, 13, value + lane + lane, 17);
                        coefficient = 6;
                    }
                    else if (name == 1)
                    {
                        typedef MachineTestWin64Vector __attribute__((ms_abi)) Dispatch(MachineTestWin64VectorMix*, MachineTestWin64Vector);
                        Dispatch* call;
                        memcpy(&call, &address, sizeof(call));
                        actual = call(machine_test_win64_host_vector_mix, value);
                        coefficient = 9;
                    }
                    else if (name == 2)
                    {
                        MachineTestWin64VectorVariadic* call;
                        memcpy(&call, &address, sizeof(call));
                        actual = call(value, 7, value, 9.0, value + lane, 13ull, value + lane + lane);
                        coefficient = 8;
                    }
                    else
                    {
                        typedef MachineTestWin64Vector __attribute__((ms_abi)) Dispatch(MachineTestWin64VectorVariadic*, MachineTestWin64Vector, unsigned long long);
                        Dispatch* call;
                        memcpy(&call, &address, sizeof(call));
                        actual = call(machine_test_win64_host_vector_variadic, value, seed);
                        coefficient = 11;
                        bias = 56;
                    }
                    for (u32 index = 0; index < 8; index += 1)
                    {
                        u64 expected = coefficient * value[index] + ((name & 1) ? 12u : 9u) * (index + 1) + bias;
                        BUSTER_TEST_RAW(arguments, actual[index] == expected, string_format(arguments->arena,
                            S8("{S8} mode={u32} seed={u64} lane={u32} actual={u64} expected={u64}"), names[name], mode, (u64)seed, index, (u64)actual[index], expected));
                    }
                }
            }
        }
    }
    codegen_release_executable(executable);
    return result;
}
#undef MACHINE_TEST_WIN64_VECTOR_TARGET
#endif

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_win64_vector(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/win64_vector.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, input.length != 0);
    OperatingSystem systems[] = {OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_UEFI};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_AMD_ZEN_5, .os = systems[system]};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            for (u32 variant = 0; variant < 2; variant += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                String8 variant_source = variant ? source : string_format(temporary.arena, S8("#define WIN64_VECTOR_FIXED_ONLY 1\n{S8}"), source);
                IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("win64-vector.c"), variant_source, target,
                    (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
                BUSTER_TEST(arguments, program && program->module_count == 1);
                if (program && program->module_count == 1)
                {
                    IrModule* module = program->modules;
                    u32 mode_begin = variant ? CODEGEN_REGISTER_ALLOCATOR_MIR_STACK : CODEGEN_REGISTER_ALLOCATOR_NONE;
                    u32 mode_end = variant ? CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT : CODEGEN_REGISTER_ALLOCATOR_MIR_STACK;
                    for (u32 mode = mode_begin; mode < mode_end; mode += 1)
                    {
                        CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                            (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                        BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                        BUSTER_TEST(arguments, generated.statistics.function_count == (variant ? 4u : 2u));
                        BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
#if BUSTER_CPU_ARCH_X86_64 && BUSTER_COMPILER_CLANG && !BUSTER_SANITIZE
                        TargetCpuFeatures host = cpu_detect_features_x86_64();
                        if (generated.error == CODEGEN_ERROR_NONE && target_cpu_features_contains(host, TARGET_CPU_FEATURE_X86_AVX512F) &&
                            target_cpu_features_contains(host, TARGET_CPU_FEATURE_X86_AVX512BW))
                        {
                            UnitTestResult executed = machine_test_win64_vector_execute(arguments, &generated, module, mode, variant != 0);
                            result.test_count += executed.test_count;
                            result.succeeded_test_count += executed.succeeded_test_count;
                        }
#endif
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_native_aggregate(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/differential/native_aggregate.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    BUSTER_TEST(arguments, input.length != 0);
    OperatingSystem systems[] = {OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_UEFI, OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_MACOS};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        bool windows = system < 2;
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = systems[system]};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            CPreprocessResult tokens = c_preprocess(temporary.arena, source, (CPreprocessOptions){0});
            CParserResult syntax = c_parse_ast(temporary.arena, tokens);
            CIRLowerResult lowered = c_analyze_with_options(temporary.arena, S8("native-aggregate.c"), tokens, syntax, target,
                                                            (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, tokens.error_count == 0 && syntax.diagnostic_count == 0 && lowered.diagnostic_count == 0);
            IrProgram* program = lowered.program;
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                u32 definitions = 0;
                for (u32 index = 0; index < module->function_count; index += 1)
                {
                    IrFunction* function = module->functions + index;
                    if (function->state == IR_FUNCTION_DECLARATION) { continue; }
                    definitions += 1;
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                    BUSTER_TEST_RAW(arguments, selected.supported, function->name);
                    if (selected.supported)
                    {
                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        MachineStackPlacement placement = machine_stack_placement_build(temporary.arena, &selected.function);
                        BUSTER_TEST(arguments, placement.valid);
                        if (windows && string_equal(function->name, S8("native_aggregate_call_host")))
                        {
                            // The largest call needs 80 bytes of homes/stack
                            // pointers and 128 bytes of aligned value copies.
                            // Smaller calls reuse the same reservation.
                            BUSTER_TEST(arguments, selected.function.outgoing_bytes == 208);
                            u32 slot = selected.function.outgoing_slot;
                            BUSTER_TEST(arguments, slot < selected.function.stack_slot_count);
                            if (slot < selected.function.stack_slot_count)
                            {
                                BUSTER_TEST(arguments, selected.function.stack_slot_sizes[slot] == 208);
                                BUSTER_TEST(arguments, selected.function.stack_slot_alignments[slot] == 16);
                                for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                                {
                                    MachineInstruction* instruction = selected.function.instructions + row;
                                    if (instruction->opcode == MACHINE_X64_LEA_FRAME &&
                                        instruction->operands[1] == machine_ref_make(MACHINE_REF_STACK_SLOT, slot))
                                    {
                                        BUSTER_TEST(arguments, instruction->payload >= 32 && instruction->payload < 208 &&
                                                               (instruction->payload & 15) == 0);
                                    }
                                }
                            }
                        }
                    }
                }
                BUSTER_TEST(arguments, definitions == 5);
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                    BUSTER_TEST(arguments, generated.statistics.function_count == 5);
                    BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);

                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}


BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_f80(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 paths[] = {S8("tests/basic_c_f80_machine.c"), S8("tests/basic_c_va_arg_long_double.c"), S8("tests/basic_c_f80_u64.c")};
    Target targets[] = {{.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
                        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS}};
    for (u32 file = 0; file < BUSTER_ARRAY_LENGTH(paths); file += 1)
    {
        ByteSlice input = file_read(arguments->arena, paths[file], (FileReadOptions){0});
        String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
        BUSTER_TEST(arguments, source.length != 0);
        for (u32 target = 0; source.length && target < BUSTER_ARRAY_LENGTH(targets); target += 1)
        {
            for (u32 memory = 0; memory < 2; memory += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                IrProgram* program = machine_test_compile_c_with_options(temporary.arena, paths[file], source, targets[target],
                    (CIRLowerOptions){.disable_direct_ssa = memory != 0});
                BUSTER_TEST(arguments, program && program->module_count == 1);
                if (program && program->module_count == 1)
                {
                    IrModule* module = program->modules;
                    u32 operations = 0;
                    for (u32 index = 0; index < module->function_count; index += 1)
                    {
                        IrFunction* function = module->functions + index;
                        MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, targets[target]);
                        BUSTER_TEST(arguments, selected.supported);
                        if (selected.supported)
                        {
                            BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                            for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                            {
                                MachineInstruction* instruction = selected.function.instructions + row;
                                if (instruction->opcode >= MACHINE_X64_F80_BINARY && instruction->opcode <= MACHINE_X64_F80_RESULT_STORE)
                                {
                                    operations |= 1u << (instruction->opcode - MACHINE_X64_F80_BINARY);
                                    u32 payload = instruction->payload;
                                    instruction->payload = UINT32_MAX;
                                    BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_PAYLOAD);
                                    instruction->payload = payload;
                                }
                            }
                        }
                    }
                    BUSTER_TEST(arguments, file || operations == 0x3fu);
                    for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                    {
                        CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, targets[target],
                            (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                        BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE);
                        BUSTER_TEST(arguments, generated.statistics.fallback_function_count == 0);
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                        if (generated.error == CODEGEN_ERROR_NONE)
                        {
                            // Resolve only bounded local PC32 calls/addresses before
                            // copying into executable storage; external/data references
                            // fail the test without executing an unpatched module.
                            bool patched = true;
                            for (u32 relocation_index = 0; patched && relocation_index < generated.relocation_count; relocation_index += 1)
                            {
                                CodegenModuleRelocation* relocation = generated.relocations + relocation_index;
                                bool found = false;
                                if (codegen_module_relocation_valid(relocation) && relocation->source == CODEGEN_MODULE_RELOCATION_CODE &&
                                    relocation->kind == CODEGEN_MODULE_RELOCATION_X86_64_PC32 && !relocation->addend &&
                                    relocation->offset <= generated.code.length && generated.code.length - relocation->offset >= 4)
                                {
                                    for (u32 entry = 0; !found && entry < generated.entry_count; entry += 1)
                                    {
                                        if (generated.entries[entry].symbol.value == relocation->symbol.value)
                                        {
                                            s64 displacement = (s64)generated.entries[entry].offset - ((s64)relocation->offset + 4);
                                            found = displacement >= INT32_MIN && displacement <= INT32_MAX;
                                            if (found)
                                            {
                                                s32 encoded = (s32)displacement;
                                                memcpy(generated.code.pointer + relocation->offset, &encoded, sizeof(encoded));
                                            }
                                        }
                                    }
                                }
                                patched = found;
                            }
                            BUSTER_TEST(arguments, patched);
                            u32 offset = machine_test_module_offset(&generated, module, S8("main"));
                            BUSTER_TEST(arguments, offset != UINT32_MAX);
                            CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                            BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                            if (executable.address && offset != UINT32_MAX && patched)
                            {
                                void* address = (u8*)executable.address + offset;
                                int (*call)(void) = 0;
                                memcpy(&call, &address, sizeof(call));
                                BUSTER_TEST(arguments, call() == 0);
                            }
                            codegen_release_executable(executable);
                        }
#endif
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_predicate_source(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ByteSlice input = file_read(arguments->arena, S8("tests/basic_c_predicate_bank.c"), (FileReadOptions){0});
    BUSTER_TEST(arguments, input.length != 0);
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_MACOS, OPERATING_SYSTEM_UEFI};
    for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
    {
        Target target = {.cpu_arch = CPU_ARCH_X86_64, .cpu_model = CPU_MODEL_AMD_ZEN_5, .os = systems[system]};
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = scratch_begin(&arguments->arena, 1);
            IrProgram* program = machine_test_compile_c_with_options(temporary.arena, S8("predicate-bank.c"), source, target,
                (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 index = 0; index < module->function_count; index += 1)
                {
                    IrFunction* function = module->functions + index;
                    if (function->state == IR_FUNCTION_DECLARATION) continue;
                    MachineSelectResult selected = machine_select_canonical_function(temporary.arena, program, function, target);
                    BUSTER_TEST(arguments, selected.supported);
                    MachineSelectResult stack_selected = machine_select_validated_canonical_function(temporary.arena, program, function, target, false, false, false, 0);
                    BUSTER_TEST(arguments, stack_selected.supported && stack_selected.function.predicate_absence_certified);
                    if (stack_selected.supported)
                    {
                        BUSTER_TEST(arguments, machine_verify_function(&stack_selected.function).error == MACHINE_VERIFY_NONE);
                        for (u32 value = 0; value < stack_selected.function.virtual_register_count; value += 1)
                            BUSTER_TEST(arguments, stack_selected.function.virtual_registers[value].register_class != MACHINE_REGISTER_CLASS_MASK);
                        if (!memory_form && string_equal(function->name, S8("predicate_mask_chain")))
                        {
                            u32 legacy_compares = 0;
                            for (u32 row = 0; row < stack_selected.function.instruction_count; row += 1)
                                legacy_compares += stack_selected.function.instructions[row].opcode == MACHINE_X64_VPCMP_MASK;
                            BUSTER_TEST(arguments, legacy_compares == 3);
                        }
                    }
                    if (selected.supported)
                    {
                        BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
                        u32 bridges = 0;
                        u32 compares = 0;
                        u32 logic = 0;
                        u32 narrow_bridges = 0;
                        for (u32 row = 0; row < selected.function.instruction_count; row += 1)
                        {
                            MachineInstruction instruction = selected.function.instructions[row];
                            bridges += instruction.opcode == MACHINE_X64_KMOV_FROM_GENERAL || instruction.opcode == MACHINE_X64_KMOV_TO_GENERAL;
                            narrow_bridges += instruction.opcode == MACHINE_X64_KMOV_TO_GENERAL && instruction.payload == 16;
                            compares += instruction.opcode == MACHINE_X64_VPCMP_K;
                            logic += instruction.opcode == MACHINE_X64_KAND || instruction.opcode == MACHINE_X64_KOR;
                        }
                        if (!memory_form && string_equal(function->name, S8("predicate_mask_chain")))
                        {
                            BUSTER_TEST(arguments, bridges == 0 && compares == 3 && logic == 2);
                        }
                        if (string_equal(function->name, S8("predicate_word_boundary"))) BUSTER_TEST(arguments, narrow_bridges == 1);
                    }
                }
                for (u32 mode = 0; mode < CODEGEN_REGISTER_ALLOCATOR_MODE_COUNT; mode += 1)
                {
                    CodegenModule generated = codegen_generate_canonical_module(temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true});
                    BUSTER_TEST(arguments, generated.error == CODEGEN_ERROR_NONE && generated.statistics.fallback_function_count == 0);
                    // The driver records locations by default. The mask-only
                    // locals a, b and c name homeless predicate registers.
                    CodegenModule located = codegen_generate_canonical_module(temporary.arena, program, module, target,
                        (CodegenModuleOptions){.register_allocator = (u8)mode, .verify_invariants = true, .debug_info = true});
                    BUSTER_TEST(arguments, located.error == CODEGEN_ERROR_NONE && located.statistics.fallback_function_count == 0);
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                    TargetCpuFeatures features = cpu_detect_features_x86_64();
                    bool execute = system == 0 && target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512F) &&
                        target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512BW);
                    if (execute && generated.error == CODEGEN_ERROR_NONE)
                    {
                        CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = generated.code});
                        BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                        if (executable.address)
                        {
                            u32 offset = machine_test_module_offset(&generated, module, S8("predicate_mask_chain"));
                            u32 word_offset = machine_test_module_offset(&generated, module, S8("predicate_word_boundary"));
                            BUSTER_TEST(arguments, offset != UINT32_MAX && word_offset != UINT32_MAX);
                            if (offset != UINT32_MAX && word_offset != UINT32_MAX)
                            {
                                typedef void MaskChain(u8*, u8 const*);
                                typedef u64 WordMask(u8 const*);
                                MaskChain* chain = 0;
                                WordMask* word = 0;
                                void* address = (u8*)executable.address + offset;
                                memcpy(&chain, &address, sizeof(chain));
                                address = (u8*)executable.address + word_offset;
                                memcpy(&word, &address, sizeof(word));
                                u8 bytes[64];
                                u8 output[66];
                                for (u32 seed = 0; seed < 8; seed += 1)
                                {
                                    memset(output, 0xa5, sizeof(output));
                                    for (u32 lane = 0; lane < 64; lane += 1) bytes[lane] = (u8)((lane * 7u + seed) & 15u);
                                    chain(output + 1, bytes);
                                    BUSTER_TEST(arguments, output[0] == 0xa5 && output[65] == 0xa5);
                                    for (u32 lane = 0; lane < 64; lane += 1)
                                        BUSTER_TEST(arguments, output[lane + 1] == (bytes[lane] == 3 || bytes[lane] == 7 ? bytes[lane] : 0xa5));
                                    BUSTER_TEST(arguments, word(bytes) == UINT64_C(65535));
                                }
                            }
                        }
                        codegen_release_executable(executable);
                    }
#endif
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_predicate_widths(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u64 inputs[] = {0, 1, UINT64_MAX, UINT64_C(0x123456789abcdef0)};
    for (u32 width_index = 0; width_index < 4; width_index += 1)
    {
        u32 width = 8u << width_index;
        for (u32 input = 0; input < BUSTER_ARRAY_LENGTH(inputs); input += 1)
        {
            MachineVirtualRegister values[] = {
                {.register_class = MACHINE_REGISTER_CLASS_GENERAL, .definition_point = machine_point_make(0, MACHINE_POINT_AFTER)},
                {.register_class = MACHINE_REGISTER_CLASS_MASK, .definition_point = machine_point_make(1, MACHINE_POINT_AFTER)},
                {.register_class = MACHINE_REGISTER_CLASS_MASK, .definition_point = machine_point_make(2, MACHINE_POINT_AFTER)},
            };
            MachineRef refs[3];
            for (u32 value = 0; value < 3; value += 1) refs[value] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value);
            MachineInstruction rows[] = {
                {.opcode = MACHINE_X64_MOV_RI, .operands = {refs[0], machine_ref_make(MACHINE_REF_IMMEDIATE, 0)}},
                {.opcode = MACHINE_X64_KMOV_FROM_GENERAL, .payload = 64, .operands = {refs[1], refs[0]}},
                {.opcode = MACHINE_X64_KMOV, .payload = width, .operands = {refs[2], refs[1]}},
                {.opcode = MACHINE_X64_KMOV_TO_GENERAL, .payload = 64, .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), refs[2]}},
                {.opcode = MACHINE_X64_RET},
            };
            MachineBlock block = {.instruction_count = BUSTER_ARRAY_LENGTH(rows)};
            MachineFunction function = {.instructions = rows, .instruction_count = BUSTER_ARRAY_LENGTH(rows), .virtual_registers = values,
                .virtual_register_count = BUSTER_ARRAY_LENGTH(values), .blocks = &block, .block_count = 1, .immediates = inputs + input,
                .immediate_count = 1, .target = machine_target_x86_64()};
            BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_NONE);
            for (u32 mode = 0; mode < 3; mode += 1)
            {
                MachineStackPlacement placement = mode == 0 ? machine_stack_placement_build(arguments->arena, &function) :
                    mode == 1 ? machine_fast_placement_build(arguments->arena, &function) : machine_quality_placement_build(arguments->arena, &function);
                MachineEncodeResult encoded = machine_encode_x86_64(arguments->arena, &function, &placement);
                BUSTER_TEST(arguments, placement.valid && encoded.valid);
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                TargetCpuFeatures features = cpu_detect_features_x86_64();
                bool execute = target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512F) &&
                    target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512BW) && target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512DQ);
                if (execute && encoded.valid)
                {
                    CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = {.pointer = encoded.bytes, .length = encoded.byte_count}});
                    BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                    if (executable.address)
                    {
                        typedef u64 WidthCall(void);
                        WidthCall* call = 0;
                        memcpy(&call, &executable.address, sizeof(call));
                        u64 mask = width == 64 ? UINT64_MAX : (UINT64_C(1) << width) - 1u;
                        BUSTER_TEST(arguments, call() == (inputs[input] & mask));
                    }
                    codegen_release_executable(executable);
                }
#endif
            }
            rows[2].payload = 7;
            BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_PAYLOAD);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_predicate_edges(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    MachineVirtualRegister values[7] = {0};
    for (u32 value = 0; value < 7; value += 1)
        values[value] = (MachineVirtualRegister){.register_class = value < 2 ? MACHINE_REGISTER_CLASS_GENERAL : MACHINE_REGISTER_CLASS_MASK,
            .definition_point = value < 2 ? machine_point_make(value * 2u, MACHINE_POINT_AFTER) : value < 4 ? machine_point_make((value - 2u) * 2u + 1u, MACHINE_POINT_AFTER) : MACHINE_POINT_INVALID};
    MachineRef refs[7];
    for (u32 value = 0; value < 7; value += 1) refs[value] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value);
    MachineInstruction rows[] = {
        {.opcode = MACHINE_X64_MOV_RI, .operands = {refs[0], machine_ref_make(MACHINE_REF_IMMEDIATE, 0)}},
        {.opcode = MACHINE_X64_KMOV_FROM_GENERAL, .payload = 64, .operands = {refs[2], refs[0]}},
        {.opcode = MACHINE_X64_MOV_RI, .operands = {refs[1], machine_ref_make(MACHINE_REF_IMMEDIATE, 1)}},
        {.opcode = MACHINE_X64_KMOV_FROM_GENERAL, .payload = 64, .operands = {refs[3], refs[1]}},
        {.opcode = MACHINE_X64_JMP, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 1)}},
        {.opcode = MACHINE_X64_CMP64, .operands = {refs[0], refs[0]}},
        {.opcode = MACHINE_X64_JCC, .payload = MACHINE_X64_CONDITION_EQUAL,
            .operands = {machine_ref_make(MACHINE_REF_BLOCK, 2), machine_ref_make(MACHINE_REF_BLOCK, 1)}},
        {.opcode = MACHINE_X64_KMOV_TO_GENERAL, .payload = 64,
            .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), refs[6]}},
        {.opcode = MACHINE_X64_RET},
    };
    MachineBlock blocks[] = {{.first_instruction = 0, .instruction_count = 5},
        {.first_instruction = 5, .instruction_count = 2, .parameter_offset = 0, .parameter_count = 2},
        {.first_instruction = 7, .instruction_count = 2, .parameter_offset = 2, .parameter_count = 1}};
    MachineBlockParameter parameters[] = {{.virtual_register = 4}, {.virtual_register = 5}, {.virtual_register = 6}};
    MachineRef sources[] = {refs[2], refs[3], refs[5], refs[4], refs[4]};
    MachineEdge edges[] = {{.source_block = 0, .destination_block = 1, .copy_offset = 0, .copy_count = 2},
        {.source_block = 1, .destination_block = 1, .copy_offset = 2, .copy_count = 2},
        {.source_block = 1, .destination_block = 2, .copy_offset = 4, .copy_count = 1}};
    u64 immediates[] = {11, 22};
    MachineFunction function = {.instructions = rows, .instruction_count = BUSTER_ARRAY_LENGTH(rows), .virtual_registers = values,
        .virtual_register_count = BUSTER_ARRAY_LENGTH(values), .blocks = blocks, .block_count = BUSTER_ARRAY_LENGTH(blocks),
        .edges = edges, .edge_count = BUSTER_ARRAY_LENGTH(edges), .block_parameters = parameters, .block_parameter_count = BUSTER_ARRAY_LENGTH(parameters),
        .edge_copy_sources = sources, .edge_copy_source_count = BUSTER_ARRAY_LENGTH(sources), .immediates = immediates, .immediate_count = 2,
        .target = machine_target_x86_64()};
    BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_NONE);
    for (u32 variant = 0; variant < 3; variant += 1)
    {
        immediates[0] = variant == 0 ? 11 : variant == 1 ? 0 : UINT64_MAX;
        for (u32 mode = 0; mode < 3; mode += 1)
        {
            MachineStackPlacement placement = mode == 0 ? machine_stack_placement_build(arguments->arena, &function) :
                mode == 1 ? machine_fast_placement_build(arguments->arena, &function) : machine_quality_placement_build(arguments->arena, &function);
            MachineEncodeResult encoded = machine_encode_x86_64(arguments->arena, &function, &placement);
            BUSTER_TEST(arguments, placement.valid && encoded.valid);
            BUSTER_TEST(arguments, variant == 0 || (placement.rematerialize_count > 0 && placement.virtual_register_offsets[2] == MACHINE_VIRTUAL_REGISTER_NO_HOME));
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
            TargetCpuFeatures features = cpu_detect_features_x86_64();
            bool execute = target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512F) && target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512BW);
            if (execute && encoded.valid)
            {
                CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = {.pointer = encoded.bytes, .length = encoded.byte_count}});
                BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                if (executable.address)
                {
                    typedef u64 EdgeCall(void);
                    EdgeCall* call = 0;
                    memcpy(&call, &executable.address, sizeof(call));
                    BUSTER_TEST(arguments, call() == immediates[0]);
                }
                codegen_release_executable(executable);
            }
#endif
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_predicate_bank(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    BUSTER_TEST(arguments, MACHINE_TARGET_REGISTER_LIMIT == 48 && machine_target_x86_64()->register_count == 48);
    BUSTER_TEST(arguments, machine_target_x86_64()->predicate_allocatable_mask == 0xfe);
    MachineFunctionBuilder callee_builder = machine_function_builder_begin(arguments->arena);
    machine_builder_block_begin(&callee_builder);
    for (u32 reg = 1; reg < 8; reg += 1)
    {
        MachineRef ref = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_PREDICATE_REGISTER_BASE + reg);
        machine_builder_instruction(&callee_builder, (MachineInstruction){.opcode = MACHINE_X64_KXOR, .payload = 64, .operands = {ref, ref, ref}});
    }
    machine_builder_instruction(&callee_builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&callee_builder, (MachineBlock){0});
    MachineFunction callee = machine_function_builder_finish(arguments->arena, &callee_builder);
    callee.target = machine_target_x86_64();
    BUSTER_TEST(arguments, machine_verify_function(&callee).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement callee_placement = machine_fast_placement_build(arguments->arena, &callee);
    MachineEncodeResult callee_encoded = machine_encode_x86_64(arguments->arena, &callee, &callee_placement);
    BUSTER_TEST(arguments, callee_placement.valid && callee_encoded.valid);
    u64 callee_address = 0;
    CodegenExecutable callee_executable = {0};
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
    TargetCpuFeatures features = cpu_detect_features_x86_64();
    bool execute = target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512F) && target_cpu_features_contains(features, TARGET_CPU_FEATURE_X86_AVX512BW);
    if (execute && callee_encoded.valid)
    {
        callee_executable = codegen_make_executable((CodegenFunction){.code = {.pointer = callee_encoded.bytes, .length = callee_encoded.byte_count}});
        memcpy(&callee_address, &callee_executable.address, sizeof(callee_executable.address));
    }
#endif
    for (u32 with_call = 0; with_call < 4; with_call += 1)
    {
        MachineFunctionBuilder builder = machine_function_builder_begin(arguments->arena);
        machine_builder_block_begin(&builder);
        u32 predicates[12];
        u32 row = 0;
        for (u32 value = 0; value < 12; value += 1)
        {
            u32 integer = machine_builder_virtual_register(&builder, (MachineVirtualRegister){.register_class = MACHINE_REGISTER_CLASS_GENERAL,
                .definition_point = machine_point_make(row, MACHINE_POINT_AFTER)});
            machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_MOV_RI,
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, integer), machine_ref_make(MACHINE_REF_IMMEDIATE, value)}});
            row += 1;
            predicates[value] = machine_builder_virtual_register(&builder, (MachineVirtualRegister){.register_class = MACHINE_REGISTER_CLASS_MASK,
                .definition_point = machine_point_make(row, MACHINE_POINT_AFTER)});
            machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_KMOV_FROM_GENERAL, .payload = 64,
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, predicates[value]), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, integer)}});
            row += 1;
        }
        if (with_call == 1 || with_call == 3)
        {
            u32 callee_value = machine_builder_virtual_register(&builder, (MachineVirtualRegister){.register_class = MACHINE_REGISTER_CLASS_GENERAL,
                .definition_point = machine_point_make(row, MACHINE_POINT_AFTER)});
            machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_MOV_RI,
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, callee_value), machine_ref_make(MACHINE_REF_IMMEDIATE, 12)}});
            machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_CALL_INDIRECT,
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, callee_value)}});
            row += 2;
        }
        if (with_call == 2)
        {
            MachineRef fixed = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_PREDICATE_REGISTER_BASE + 1);
            machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_KXOR, .payload = 64, .operands = {fixed, fixed, fixed}});
            row += 1;
            u32 destination = machine_builder_virtual_register(&builder, (MachineVirtualRegister){.register_class = MACHINE_REGISTER_CLASS_MASK,
                .definition_point = machine_point_make(row++, MACHINE_POINT_AFTER)});
            machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_KAND, .payload = 64,
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, destination), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, predicates[0]), fixed}});
            predicates[0] = destination;
        }
        u32 combined = predicates[0];
        for (u32 index = 1; index < 12; index += 1)
        {
            u32 destination = machine_builder_virtual_register(&builder, (MachineVirtualRegister){.register_class = MACHINE_REGISTER_CLASS_MASK,
                .definition_point = machine_point_make(row++, MACHINE_POINT_AFTER)});
            machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_KOR, .payload = 64,
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, destination), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, combined),
                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, predicates[index])}});
            combined = destination;
        }
        machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_KMOV_TO_GENERAL, .payload = 64,
            .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, combined)}});
        machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
        machine_builder_block_end(&builder, (MachineBlock){0});
        MachineFunction function = machine_function_builder_finish(arguments->arena, &builder);
        function.target = machine_target_x86_64();
        function.immediate_count = 13;
        function.immediates = arena_allocate(arguments->arena, u64, 13);
        for (u32 index = 0; index < 12; index += 1) function.immediates[index] = UINT64_C(1) << index;
        if (with_call == 3) { function.immediates[0] = 0; function.immediates[1] = UINT64_MAX; }
        function.immediates[12] = callee_address;
        BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_NONE);
        for (u32 mode = 0; mode < 3; mode += 1)
        {
            MachineStackPlacement placement = mode == 0 ? machine_stack_placement_build(arguments->arena, &function) :
                mode == 1 ? machine_fast_placement_build(arguments->arena, &function) : machine_quality_placement_build(arguments->arena, &function);
            BUSTER_TEST(arguments, placement.valid);
            u8 occupied = 0;
            u32 predicate_spills = 0;
            u32 predicate_reloads = 0;
            u32 predicate_rematerializations = 0;
            for (u32 instruction = 0; instruction < function.instruction_count; instruction += 1)
            {
                MachineOpcodeInfo const* info = machine_opcode_info(function.instructions[instruction].opcode);
                for (u32 slot = 0; slot < info->operand_count; slot += 1)
                {
                    if (((info->operand_info[slot] >> MACHINE_OPERAND_CLASS_SHIFT) & 7u) == MACHINE_REGISTER_CLASS_MASK)
                    {
                        u32 reg = placement.operand_registers[(u64)instruction * 4 + slot];
                        BUSTER_TEST(arguments, reg > MACHINE_PREDICATE_REGISTER_BASE && reg < MACHINE_PREDICATE_REGISTER_BASE + 8);
                        occupied |= (u8)(1u << (reg - MACHINE_PREDICATE_REGISTER_BASE));
                    }
                }
            }
            for (u32 index = 0; index < placement.edit_count; index += 1)
            {
                MachineEdit edit = placement.edits[index];
                predicate_spills += edit.location >= MACHINE_PREDICATE_REGISTER_BASE && edit.kind == MACHINE_EDIT_SPILL;
                predicate_reloads += edit.location >= MACHINE_PREDICATE_REGISTER_BASE && edit.kind == MACHINE_EDIT_RELOAD;
                predicate_rematerializations += edit.location >= MACHINE_PREDICATE_REGISTER_BASE && edit.kind == MACHINE_EDIT_REMATERIALIZE;
            }
            BUSTER_TEST(arguments, mode == 0 || occupied == 0xfe);
            BUSTER_TEST(arguments, predicate_spills > 0 && predicate_reloads > 0);
            BUSTER_TEST(arguments, with_call != 3 || predicate_rematerializations >= 2);
            MachineEncodeResult encoded = machine_encode_x86_64(arguments->arena, &function, &placement);
            BUSTER_TEST_RAW(arguments, encoded.valid && encoded.byte_count > 0, string_format(arguments->arena, S8("predicate encode mode={u32} call={u32} bytes={u32}"), mode, with_call, encoded.byte_count));
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
            if (execute && encoded.valid && ((with_call != 1 && with_call != 3) || callee_address))
            {
                CodegenExecutable executable = codegen_make_executable((CodegenFunction){.code = {.pointer = encoded.bytes, .length = encoded.byte_count}});
                BUSTER_TEST(arguments, executable.error == CODEGEN_ERROR_NONE);
                if (executable.address)
                {
                    typedef u64 PredicateCall(void);
                    PredicateCall* call = 0;
                    memcpy(&call, &executable.address, sizeof(call));
                    BUSTER_TEST(arguments, call() == (with_call == 3 ? UINT64_MAX : with_call == 2 ? UINT64_C(4094) : UINT64_C(4095)));
                }
                codegen_release_executable(executable);
            }
#endif
        }
        function.instructions[1].operands[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_PREDICATE_REGISTER_BASE);
        BUSTER_TEST(arguments, machine_verify_function(&function).error != MACHINE_VERIFY_NONE);
    }
    codegen_release_executable(callee_executable);
    return result;
}

// Preserve the live value order while moving every value above a dead-ID gap.
// The pressure corpus has no value-bearing opcode payloads or VA_ARG side rows.
// Compare complete ordered placement and encoding, then reuse dirty scratch on
// another function/target. This catches stale pins and uninitialized span reads.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_quality_sparse_pins(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    bool benchmark = os_get_environment_variable(S8("BUSTER_QUALITY_SCRATCH_BENCH")).length != 0;
#if BUSTER_BENCH_ALLOCATIONS
    u64 observed_resets = 0;
#endif
    ByteSlice input = file_read(arguments->arena, S8("tests/basic_c_register_pressure.c"), (FileReadOptions){0});
    String8 source = {.pointer = (char8*)input.pointer, .length = input.length};
    Target targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_WINDOWS},
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS},
    };
    BUSTER_TEST(arguments, source.length != 0);
    for (u32 target_index = 0; source.length && target_index < BUSTER_ARRAY_LENGTH(targets); target_index += 1)
    {
        for (u32 memory_form = 0; memory_form < 2; memory_form += 1)
        {
            TemporalArena temporary = arena_begin_temporal(arguments->arena);
            Target target = targets[target_index];
            IrProgram* program = machine_test_compile_c_with_options(arguments->arena, S8("quality-sparse-pins.c"), source, target,
                (CIRLowerOptions){.disable_direct_ssa = memory_form != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
                {
                    IrFunction* ir_function = module->functions + function_index;
                    if (ir_function->state == IR_FUNCTION_DECLARATION) continue;
                    TemporalArena function_temporary = arena_begin_temporal(arguments->arena);
                    MachineSelectResult selected = machine_select_canonical_function(arguments->arena, program, ir_function, target);
                    BUSTER_TEST(arguments, selected.supported && !selected.function.va_arg_count);
                    if (selected.supported && !selected.function.va_arg_count)
                    {
                        MachineFunction* original = &selected.function;
#if BUSTER_BENCH_ALLOCATIONS
                        MachineQualityCensus reference_before = machine_quality_census_snapshot();
#endif
                        MachineStackPlacement reference = machine_quality_placement_build(arguments->arena, original);
#if BUSTER_BENCH_ALLOCATIONS
                        MachineQualityCensus reference_after = machine_quality_census_snapshot();
#endif
                        BUSTER_TEST(arguments, reference.valid);
                        MachineEncodeResult reference_code = target.cpu_arch == CPU_ARCH_X86_64
                            ? machine_encode_x86_64(arguments->arena, original, &reference)
                            : machine_encode_aarch64(arguments->arena, original, &reference);
                        BUSTER_TEST(arguments, reference_code.valid);
                        u32 gaps[] = {4096, 0, 65536};
                        bool measure = benchmark && target_index == 0 && memory_form == 0 &&
                            string_equal(ir_function->name, S8("wide_live_loop"));
                        for (u32 gap_index = 0; gap_index < (measure ? 3u : 2u); gap_index += 1)
                        {
                            TemporalArena variant_temporary = arena_begin_temporal(arguments->arena);
                            u32 gap = gaps[gap_index];
                            MachineFunction variant = *original;
                            variant.virtual_register_count += gap;
                            variant.virtual_registers = arena_allocate(arguments->arena, MachineVirtualRegister, variant.virtual_register_count);
                            for (u32 value = 0; value < gap; value += 1)
                            {
                                variant.virtual_registers[value] = (MachineVirtualRegister){
                                    .definition_point = MACHINE_POINT_INVALID, .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                    .typed_origin = IR_ID_UNDERLYING_INVALID};
                            }
                            memcpy(variant.virtual_registers + gap, original->virtual_registers,
                                   (u64)original->virtual_register_count * sizeof(MachineVirtualRegister));
                            variant.instructions = arena_allocate(arguments->arena, MachineInstruction, original->instruction_count);
                            memcpy(variant.instructions, original->instructions, (u64)original->instruction_count * sizeof(MachineInstruction));
                            for (u32 row = 0; row < variant.instruction_count; row += 1)
                            {
                                MachineInstruction* instruction = variant.instructions + row;
                                MachineOpcodeInfo const* info = machine_opcode_info(instruction->opcode);
                                for (u32 slot = 0; slot < info->operand_count; slot += 1)
                                {
                                    MachineRef ref = instruction->operands[slot];
                                    if (machine_ref_kind(ref) == MACHINE_REF_VIRTUAL_REGISTER)
                                        instruction->operands[slot] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, machine_ref_payload(ref) + gap);
                                }
                            }
                            variant.block_parameters = arena_allocate(arguments->arena, MachineBlockParameter, original->block_parameter_count);
                            for (u32 index = 0; index < original->block_parameter_count; index += 1)
                            {
                                variant.block_parameters[index] = original->block_parameters[index];
                                variant.block_parameters[index].virtual_register += gap;
                            }
                            variant.edge_copy_sources = arena_allocate(arguments->arena, MachineRef, original->edge_copy_source_count);
                            for (u32 index = 0; index < original->edge_copy_source_count; index += 1)
                            {
                                MachineRef ref = original->edge_copy_sources[index];
                                variant.edge_copy_sources[index] = machine_ref_kind(ref) == MACHINE_REF_VIRTUAL_REGISTER
                                    ? machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, machine_ref_payload(ref) + gap) : ref;
                            }
                            for (u32 repeat = 0; repeat < (measure ? 8u : 2u); repeat += 1)
                            {
                                TemporalArena placement_temporary = arena_begin_temporal(arguments->arena);
#if BUSTER_BENCH_ALLOCATIONS
                                MachineQualityCensus before = machine_quality_census_snapshot();
#endif
                                TimeDataType start = timestamp_take();
                                MachineStackPlacement placement = machine_quality_placement_build(arguments->arena, &variant);
                                u64 ns = timestamp_ns_between(start, timestamp_take());
                                u64 retained = arguments->arena->position - placement_temporary.position;
#if BUSTER_BENCH_ALLOCATIONS
                                MachineQualityCensus after = machine_quality_census_snapshot();
                                u64 assignments = after.whole_assignments - before.whole_assignments + after.split_assignments - before.split_assignments;
                                BUSTER_TEST(arguments, after.pin_span_write_bytes - before.pin_span_write_bytes == assignments * 2 * sizeof(u32));
                                BUSTER_TEST(arguments, after.pin_reset_values - before.pin_reset_values <= assignments);
                                observed_resets += after.pin_reset_values - before.pin_reset_values;
                                BUSTER_TEST(arguments, after.attempt_reset_bytes - before.attempt_reset_bytes ==
                                    reference_after.attempt_reset_bytes - reference_before.attempt_reset_bytes);
                                BUSTER_TEST(arguments, after.pin_mask_values - before.pin_mask_values == assignments);
#endif
                                BUSTER_TEST(arguments, placement.valid && placement.edit_count == reference.edit_count &&
                                    placement.frame_size == reference.frame_size && placement.callee_saved_mask == reference.callee_saved_mask &&
                                    placement.pinned_register_count == reference.pinned_register_count &&
                                    placement.split_register_count == reference.split_register_count &&
                                    placement.reload_count == reference.reload_count && placement.spill_count == reference.spill_count);
                                if (placement.valid && placement.edit_count == reference.edit_count)
                                {
                                    for (u32 edit_index = 0; edit_index < placement.edit_count; edit_index += 1)
                                    {
                                        MachineEdit left = reference.edits[edit_index];
                                        MachineEdit right = placement.edits[edit_index];
                                        if (right.kind == MACHINE_EDIT_SPILL || right.kind == MACHINE_EDIT_RELOAD) right.subject -= gap;
                                        BUSTER_TEST(arguments, left.point == right.point && left.kind == right.kind && left.flags == right.flags &&
                                            left.subject == right.subject && left.location == right.location);
                                    }
                                    BUSTER_TEST(arguments, memcmp(reference.operand_registers, placement.operand_registers,
                                        (u64)variant.instruction_count * 4) == 0);
                                    MachineEncodeResult encoded = target.cpu_arch == CPU_ARCH_X86_64
                                        ? machine_encode_x86_64(arguments->arena, &variant, &placement)
                                        : machine_encode_aarch64(arguments->arena, &variant, &placement);
                                    BUSTER_TEST(arguments, encoded.valid && encoded.byte_count == reference_code.byte_count);
                                    if (encoded.valid && encoded.byte_count == reference_code.byte_count)
                                        BUSTER_TEST(arguments, memcmp(encoded.bytes, reference_code.bytes, encoded.byte_count) == 0);
                                }
                                if (measure && repeat)
                                {
                                    string_print(S8("BENCH_QUALITY_SCRATCH gap={u32} values={u32} rows={u32} sample={u32} ns={u64} retained={u64} pins={u32}\n"),
                                        gap, variant.virtual_register_count, variant.instruction_count, repeat - 1, ns,
                                        retained, placement.pinned_register_count);
                                }
                                scratch_end(placement_temporary);
                            }
                            scratch_end(variant_temporary);
                        }
                    }
                    scratch_end(function_temporary);
                }
            }
            scratch_end(temporary);
        }
    }
#if BUSTER_BENCH_ALLOCATIONS
    BUSTER_TEST(arguments, observed_resets > 0);
#endif
    return result;
}

// Deterministic pseudo-random source for the differential fixtures. A fixed
// stream keeps a failure reproducible from the case index alone.
BUSTER_GLOBAL_LOCAL u32 machine_test_debug_random(u32* state, u32 bound)
{
    *state = *state * 1664525u + 1013904223u;
    return (*state >> 8) % bound;
}

// The indexed debug-value builder against the whole-array reference. The shapes
// below cover what the lookups replaced: values in zero, one, two and more
// virtual registers, promoted (mutable) places, parameters whose place is only
// an IR_OPCODE_ARGUMENT result, canonical locals past the place array, and
// place-less locals that emit one value per block.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_debug_values_differential(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    enum
    {
        CASE_COUNT = 48,
        VALUE_COUNT = 40,
        BLOCK_COUNT = 5,
        LOCAL_COUNT = 10,
        DEBUG_COUNT = 14,
        REGISTER_COUNT = 34,
    };
    IrField fields[] = {{.offset = 0}, {.offset = 8}};
    IrType types[] = {
        {.kind = IR_TYPE_INTEGER, .is_signed = true, .bit_width = 32, .layout = {.resolved = true, .size = 4, .alignment = 4}},
        {.kind = IR_TYPE_INTEGER, .is_signed = true, .bit_width = 64, .layout = {.resolved = true, .size = 8, .alignment = 8}},
        {.kind = IR_TYPE_STRUCT, .fields = fields, .field_count = 2, .layout = {.resolved = true, .size = 16, .alignment = 8}},
        {.kind = IR_TYPE_STRUCT, .fields = fields, .field_count = 2, .layout = {.resolved = true, .size = 32, .alignment = 8}},
    };
    IrProgram program = {.types = {.types = types, .count = BUSTER_ARRAY_LENGTH(types)}};
    u32 random_state = 0x9e3779b9u;
    for (u32 case_index = 0; case_index < CASE_COUNT; case_index += 1)
    {
        TemporalArena temporary = scratch_begin(&arguments->arena, 1);
        IrValue* values = arena_allocate(temporary.arena, IrValue, VALUE_COUNT);
        IrInstruction* instructions = arena_allocate(temporary.arena, IrInstruction, VALUE_COUNT);
        u64* immediates = arena_allocate(temporary.arena, u64, VALUE_COUNT);
        for (u32 index = 0; index < VALUE_COUNT; index += 1)
        {
            u32 shape = machine_test_debug_random(&random_state, 5u);
            u8 opcode = shape == 0 ? (u8)IR_OPCODE_LOCAL
                                   : shape == 1 ? (u8)IR_OPCODE_ARGUMENT
                                                : shape == 2 ? (u8)IR_OPCODE_CONSTANT_INTEGER : (u8)IR_OPCODE_ADDRESS_OF;
            immediates[index] = machine_test_debug_random(&random_state, DEBUG_COUNT + 2u);
            values[index] = (IrValue){.definition = {.value = index},
                                      .canonical_type = {.value = machine_test_debug_random(&random_state, BUSTER_ARRAY_LENGTH(types))}};
            instructions[index] = (IrInstruction){
                .opcode = opcode,
                .result = {.value = index},
                .canonical_local = {.value = machine_test_debug_random(&random_state, LOCAL_COUNT + 3u)},
                .immediates = immediates + index,
                .immediate_count = 1,
            };
        }
        IrCfgParameter* cfg_parameters = arena_allocate(temporary.arena, IrCfgParameter, BLOCK_COUNT * 2u);
        IrCfgBlock* cfg_blocks = arena_allocate(temporary.arena, IrCfgBlock, BLOCK_COUNT);
        IrBlock* blocks = arena_allocate(temporary.arena, IrBlock, BLOCK_COUNT);
        memset(blocks, 0, sizeof(*blocks) * BLOCK_COUNT);
        for (u32 block_index = 0; block_index < BLOCK_COUNT; block_index += 1)
        {
            IrValueId* local_values = arena_allocate(temporary.arena, IrValueId, LOCAL_COUNT);
            for (u32 local_index = 0; local_index < LOCAL_COUNT; local_index += 1)
            {
                u32 choice = machine_test_debug_random(&random_state, VALUE_COUNT + LOCAL_COUNT);
                local_values[local_index] = choice < VALUE_COUNT ? (IrValueId){.value = choice} : IR_VALUE_ID_INVALID;
            }
            blocks[block_index] = (IrBlock){
                .local_values = local_values,
                .first_instruction = {.value = block_index * (VALUE_COUNT / BLOCK_COUNT)},
                .id = {.value = block_index},
            };
            cfg_parameters[block_index * 2u] = (IrCfgParameter){
                .canonical_local = {.value = machine_test_debug_random(&random_state, LOCAL_COUNT + 3u)},
                .value = {.value = machine_test_debug_random(&random_state, VALUE_COUNT)},
            };
            cfg_parameters[block_index * 2u + 1u] = (IrCfgParameter){
                .canonical_local = {.value = machine_test_debug_random(&random_state, LOCAL_COUNT + 3u)},
                .value = {.value = machine_test_debug_random(&random_state, VALUE_COUNT)},
            };
            cfg_blocks[block_index] = (IrCfgBlock){
                .first_instruction = block_index * (VALUE_COUNT / BLOCK_COUNT),
                // A zero-instruction block contributes no debug value even when
                // it holds one for the local.
                .instruction_count = machine_test_debug_random(&random_state, 4u) ? VALUE_COUNT / BLOCK_COUNT : 0,
                .parameter_offset = block_index * 2u,
                .parameter_count = machine_test_debug_random(&random_state, 3u),
            };
        }
        IrPublishedCfg published = {
            .blocks = cfg_blocks,
            .parameters = cfg_parameters,
            .block_count = BLOCK_COUNT,
            .parameter_count = machine_test_debug_random(&random_state, BLOCK_COUNT * 2u + 1u),
        };
        IrDebugLocal* debug_locals = arena_allocate(temporary.arena, IrDebugLocal, DEBUG_COUNT);
        memset(debug_locals, 0, sizeof(*debug_locals) * DEBUG_COUNT);
        for (u32 debug_index = 0; debug_index < DEBUG_COUNT; debug_index += 1)
        {
            u32 identity = machine_test_debug_random(&random_state, LOCAL_COUNT + 4u);
            debug_locals[debug_index].id = identity < LOCAL_COUNT + 3u ? (IrLocalId){.value = identity} : IR_LOCAL_ID_INVALID;
            debug_locals[debug_index].is_parameter = machine_test_debug_random(&random_state, 2u) != 0;
            debug_locals[debug_index].type = (IrTypeId){.value = 0};
        }
        IrFunction function = {
            .instructions = instructions,
            .values = values,
            .blocks = blocks,
            .debug_locals = debug_locals,
            .published_cfg = &published,
            .instruction_count = VALUE_COUNT,
            .value_count = VALUE_COUNT,
            .block_count = BLOCK_COUNT,
            .local_count = LOCAL_COUNT,
            .debug_local_count = DEBUG_COUNT,
        };
        MachineVirtualRegister* virtual_registers = arena_allocate(temporary.arena, MachineVirtualRegister, REGISTER_COUNT);
        memset(virtual_registers, 0, sizeof(*virtual_registers) * REGISTER_COUNT);
        for (u32 register_index = 0; register_index < REGISTER_COUNT; register_index += 1)
        {
            // Crowd the origins so some values land in one register, some in
            // two, and some in more than the piece layout can describe.
            virtual_registers[register_index] = (MachineVirtualRegister){
                .definition_point = MACHINE_POINT_INVALID,
                .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                .flags = machine_test_debug_random(&random_state, 4u) ? 0 : MACHINE_VIRTUAL_REGISTER_FLAG_MUTABLE,
                .typed_origin = machine_test_debug_random(&random_state, VALUE_COUNT / 2u),
            };
        }
        u32* stack_slots = arena_allocate(temporary.arena, u32, VALUE_COUNT);
        u32* indirect_slots = arena_allocate(temporary.arena, u32, VALUE_COUNT);
        for (u32 index = 0; index < VALUE_COUNT; index += 1)
        {
            stack_slots[index] = machine_test_debug_random(&random_state, 3u) ? UINT32_MAX : index;
            indirect_slots[index] = machine_test_debug_random(&random_state, 5u) ? UINT32_MAX : index;
        }
        MachineFunction indexed = {.virtual_registers = virtual_registers, .virtual_register_count = REGISTER_COUNT};
        MachineFunction reference = indexed;
        bool indexed_built = machine_test_debug_values_build(temporary.arena, &program, &function, &indexed, stack_slots, indirect_slots);
        bool reference_built = machine_test_debug_values_build_dense(temporary.arena, &program, &function, &reference, stack_slots,
                                                                     indirect_slots);
        BUSTER_TEST(arguments, indexed_built == reference_built);
        BUSTER_TEST(arguments, indexed.debug_value_count == reference.debug_value_count);
        if (indexed_built && reference_built && indexed.debug_value_count == reference.debug_value_count)
        {
            bool same = true;
            for (u32 value_index = 0; value_index < indexed.debug_value_count; value_index += 1)
            {
                MachineDebugValue a = indexed.debug_values[value_index];
                MachineDebugValue b = reference.debug_values[value_index];
                same = same && a.local.value == b.local.value && a.first_instruction == b.first_instruction &&
                       a.instruction_count == b.instruction_count && a.kind == b.kind && a.piece_count == b.piece_count &&
                       a.value_size == b.value_size && a.constant == b.constant && a.pieces[0] == b.pieces[0] &&
                       a.pieces[1] == b.pieces[1] && a.piece_sizes[0] == b.piece_sizes[0] && a.piece_sizes[1] == b.piece_sizes[1];
            }
            BUSTER_TEST(arguments, same);
        }
        scratch_end(temporary);
    }
    return result;
}

// Exercise the accepted production scheduler path with one source mark per row.
// The independent leaves create excess pressure; the balanced consumers make
// a heavily permuted order strictly cheaper, so line-mark repair cannot be
// skipped by either scheduler gate.
BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_schedule_line_mark_repair(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u64 fixture_position = arguments->arena->position;
    enum { LEAF_COUNT = 256 };
    MachineFunctionBuilder builder = machine_function_builder_begin(arguments->arena);
    u32* values = arena_allocate(arguments->arena, u32, LEAF_COUNT);
    machine_builder_block_begin(&builder);
    for (u32 leaf = 0; leaf < LEAF_COUNT; leaf += 1)
    {
        u32 row = builder.instructions.total_count;
        u32 value = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
            .definition_point = machine_point_make(row, MACHINE_POINT_AFTER),
            .register_class = MACHINE_REGISTER_CLASS_GENERAL,
            .typed_origin = IR_ID_UNDERLYING_INVALID,
        });
        machine_builder_instruction(&builder, (MachineInstruction){
            .opcode = MACHINE_X64_MOV_RI,
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value), machine_ref_make(MACHINE_REF_IMMEDIATE, 0)},
        });
        values[leaf] = value;
    }
    for (u32 width = LEAF_COUNT; width > 1; width /= 2)
    {
        for (u32 pair = 0; pair < width / 2; pair += 1)
        {
            u32 row = builder.instructions.total_count;
            u32 value = machine_builder_virtual_register(&builder, (MachineVirtualRegister){
                .definition_point = machine_point_make(row, MACHINE_POINT_AFTER),
                .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                .typed_origin = IR_ID_UNDERLYING_INVALID,
            });
            machine_builder_instruction(&builder, (MachineInstruction){
                .opcode = MACHINE_X64_ADD64,
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[2 * pair]),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[2 * pair + 1])},
            });
            values[pair] = value;
        }
    }
    machine_builder_instruction(&builder, (MachineInstruction){
        .opcode = MACHINE_X64_MOV_RR,
        .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX),
                     machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[0])},
    });
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});

    MachineFunction function = machine_function_builder_finish(arguments->arena, &builder);
    function.target = machine_target_x86_64();
    function.immediates = arena_allocate(arguments->arena, u64, 1);
    function.immediates[0] = 1;
    function.immediate_count = 1;
    function.line_mark_count = function.instruction_count;
    function.line_marks = arena_allocate(arguments->arena, MachineLineMark, function.line_mark_count);
    for (u32 row = 0; row < function.instruction_count; row += 1)
    {
        function.line_marks[row] = (MachineLineMark){.row = row, .instruction = row};
    }
    BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_NONE);

    u64 output_position = arguments->arena->position;
    arena_allocate(arguments->arena, MachineInstruction, function.instruction_count);
    arena_allocate(arguments->arena, MachineVirtualRegister, function.virtual_register_count ? function.virtual_register_count : 1);
    arena_allocate(arguments->arena, MachineLineMark, function.line_mark_count ? function.line_mark_count : 1);
    u64 retained_position = arguments->arena->position;
    arena_set_position(arguments->arena, output_position);

    MachineScheduleResult scheduled = machine_schedule_function(arguments->arena, &function);
    BUSTER_TEST(arguments, arguments->arena->position == retained_position);
    u64 repeated_position = arguments->arena->position;
    arena_allocate(arguments->arena, MachineInstruction, function.instruction_count);
    arena_allocate(arguments->arena, MachineVirtualRegister, function.virtual_register_count ? function.virtual_register_count : 1);
    arena_allocate(arguments->arena, MachineLineMark, function.line_mark_count ? function.line_mark_count : 1);
    u64 repeated_retained_position = arguments->arena->position;
    arena_set_position(arguments->arena, repeated_position);
    MachineScheduleResult repeated = machine_schedule_function(arguments->arena, &function);
    BUSTER_TEST(arguments, arguments->arena->position == repeated_retained_position);
    BUSTER_TEST(arguments, scheduled.moved && repeated.moved);
    BUSTER_TEST(arguments, machine_verify_function(&scheduled.function).error == MACHINE_VERIFY_NONE);
    BUSTER_TEST(arguments, scheduled.function.line_mark_count == function.instruction_count);
    bool exact = scheduled.function.line_mark_count == function.instruction_count;
    bool input_untouched = true;
    u32 permuted = 0;
    for (u32 row = 0; row < function.instruction_count; row += 1)
    {
        input_untouched &= function.line_marks[row].row == row && function.line_marks[row].instruction == row;
        if (exact)
        {
            MachineLineMark mark = scheduled.function.line_marks[row];
            exact &= mark.row == row && mark.instruction < function.instruction_count;
            if (mark.instruction < function.instruction_count)
            {
                exact &= memcmp(scheduled.function.instructions + row, function.instructions + mark.instruction,
                                sizeof(MachineInstruction)) == 0;
                permuted += mark.instruction != row;
            }
        }
    }
    BUSTER_TEST(arguments, input_untouched);
    BUSTER_TEST(arguments, exact && permuted > function.instruction_count / 2);
    BUSTER_TEST(arguments, repeated.function.line_mark_count == scheduled.function.line_mark_count);
    if (repeated.function.line_mark_count == scheduled.function.line_mark_count)
    {
        BUSTER_TEST(arguments, memcmp(repeated.function.line_marks, scheduled.function.line_marks,
                                     scheduled.function.line_mark_count * sizeof(MachineLineMark)) == 0);
        BUSTER_TEST(arguments, memcmp(repeated.function.instructions, scheduled.function.instructions,
                                     scheduled.function.instruction_count * sizeof(MachineInstruction)) == 0);
    }
    arena_set_position(arguments->arena, fixture_position);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_debug_value_capacity(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    enum { LOCAL_COUNT = 64 };
    IrInstruction instructions[LOCAL_COUNT] = {0};
    IrValue values[LOCAL_COUNT] = {0};
    IrDebugLocal locals[LOCAL_COUNT] = {0};
    for (u32 index = 0; index < LOCAL_COUNT; index += 1)
    {
        instructions[index].opcode = IR_OPCODE_CONSTANT_INTEGER;
        instructions[index].result.value = index;
        instructions[index].canonical_local.value = index;
        values[index].definition.value = index;
        values[index].canonical_type = IR_TYPE_ID_INVALID;
        locals[index].id.value = index;
    }
    IrFunction function = {
        .instructions = instructions,
        .values = values,
        .debug_locals = locals,
        .instruction_count = LOCAL_COUNT,
        .value_count = LOCAL_COUNT,
        .local_count = LOCAL_COUNT,
        .debug_local_count = LOCAL_COUNT,
        // A loose local x block reservation used to allocate 166,400 bytes
        // even though every local below has one direct defining value.
        .block_count = LOCAL_COUNT,
    };
    IrProgram program = {0};
    MachineFunction machine_function = {0};
    TemporalArena temporary = scratch_begin(&arguments->arena, 1);
    u64 position = temporary.arena->position;
    bool built = machine_test_debug_values_build(temporary.arena, &program, &function, &machine_function, 0, 0);
    u64 retained = temporary.arena->position - position;
    BUSTER_TEST(arguments, built && machine_function.debug_value_count == LOCAL_COUNT && retained < BUSTER_KB(8));
    scratch_end(temporary);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_sparse_local_state(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 sources[] = {
        S8("unsigned long test(unsigned long n){volatile unsigned long observed=n;unsigned long x=n+3,y=n*7;"
           "if(n&1)x+=y;else y+=x;if(x<y)x=y+1;return x+y+observed;}"),
        S8("int test(int n){int x;if(n)goto use;return n;use:return x;}"),
        S8("typedef int V __attribute__((vector_size(16)));V test(V a,V b){V x=a;x+=b;return x;}")
    };
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX};
    for (u32 source = 0; source < BUSTER_ARRAY_LENGTH(sources); source += 1)
    {
        TemporalArena temporary = arena_begin_temporal(arguments->arena);
        IrProgram* program = machine_test_compile_c_with_options(arguments->arena, S8("sparse-locals.c"), sources[source], target,
                                                               (CIRLowerOptions){.disable_direct_ssa = true});
        if (BUSTER_REQUIRE(arguments, program && program->module_count))
        {
            program->disable_local_promotion = true;
            program->fast_passes = 0;
            IrValidationResult prepared = ir_prepare_canonical_module(program, program->modules, false);
            IrFunction* function = machine_test_ir_function_find(program->modules, S8("test"));
            if (BUSTER_REQUIRE(arguments, prepared.error == IR_VALIDATION_NONE && function && function->local_places))
            {
                MachineEncodeResult sparse = machine_test_encode(arguments->arena, program, function, target, 0);
                IrValueId* places = function->local_places;
                function->local_places = 0;
                MachineEncodeResult rows = machine_test_encode(arguments->arena, program, function, target, 0);
                function->local_places = places;
                BUSTER_TEST(arguments, sparse.valid && rows.valid && sparse.byte_count == rows.byte_count);
                if (sparse.valid && rows.valid && sparse.byte_count == rows.byte_count)
                {
                    BUSTER_TEST(arguments, memory_compare(sparse.bytes, rows.bytes, sparse.byte_count));
                }
            }
        }
        scratch_end(temporary);
    }
    return result;
}

enum
{
    MACHINE_TEST_SCHEDULE_TREE,
    MACHINE_TEST_SCHEDULE_DUPLICATE,
    MACHINE_TEST_SCHEDULE_READ_MODIFY,
    MACHINE_TEST_SCHEDULE_FANOUT,
};

BUSTER_GLOBAL_LOCAL u32 machine_test_schedule_value(MachineFunctionBuilder* builder, u32 flags)
{
    return machine_builder_virtual_register(builder, (MachineVirtualRegister){
        .definition_point = machine_point_make(builder->instructions.total_count, MACHINE_POINT_AFTER),
        .register_class = MACHINE_REGISTER_CLASS_GENERAL,
        .typed_origin = IR_ID_UNDERLYING_INVALID,
        .flags = (u8)flags,
    });
}

BUSTER_GLOBAL_LOCAL u32 machine_test_schedule_add(MachineFunctionBuilder* builder, u32 left, u32 right)
{
    u32 value = machine_test_schedule_value(builder, 0);
    machine_builder_instruction(builder, (MachineInstruction){
        .opcode = MACHINE_X64_ADD64,
        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left),
                     machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right)},
    });
    return value;
}

// 64 independent leaves reduced to one result, so source order carries
// excess pressure. DUPLICATE repeats one operand in each first-level row,
// READ_MODIFY negates each first-level value in place (a USE_DEFINE slot on
// a mutable value), and FANOUT gives leaf 0 `fanout` extra consumers, which
// puts it at fanout + 1 touches for the refresh cutoff.
BUSTER_GLOBAL_LOCAL MachineFunction machine_test_schedule_trace_function(Arena* arena, u32 shape, u32 fanout)
{
    enum { LEAF_COUNT = 64 };
    MachineFunctionBuilder builder = machine_function_builder_begin(arena);
    u32* values = arena_allocate(arena, u32, 2 * LEAF_COUNT);
    u32* leaves = values + LEAF_COUNT;
    machine_builder_block_begin(&builder);
    for (u32 leaf = 0; leaf < LEAF_COUNT; leaf += 1)
    {
        u32 value = machine_test_schedule_value(&builder, 0);
        machine_builder_instruction(&builder, (MachineInstruction){
            .opcode = MACHINE_X64_MOV_RI,
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value), machine_ref_make(MACHINE_REF_IMMEDIATE, 0)},
        });
        leaves[leaf] = value;
    }
    u32 count = 0;
    if (shape == MACHINE_TEST_SCHEDULE_FANOUT)
    {
        for (u32 index = 0; index < fanout; index += 1)
        {
            values[count] = machine_test_schedule_add(&builder, leaves[0], leaves[index + 1]);
            count += 1;
        }
        for (u32 leaf = fanout + 1; leaf < LEAF_COUNT; leaf += 1)
        {
            values[count] = leaves[leaf];
            count += 1;
        }
    }
    else
    {
        for (u32 pair = 0; pair < LEAF_COUNT / 2; pair += 1)
        {
            u32 value = 0;
            if (shape == MACHINE_TEST_SCHEDULE_READ_MODIFY)
            {
                value = machine_test_schedule_value(&builder, MACHINE_VIRTUAL_REGISTER_FLAG_MUTABLE);
                machine_builder_instruction(&builder, (MachineInstruction){
                    .opcode = MACHINE_X64_ADD64,
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value),
                                 machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, leaves[2 * pair]),
                                 machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, leaves[2 * pair + 1])},
                });
                machine_builder_instruction(&builder, (MachineInstruction){
                    .opcode = MACHINE_X64_NEG64,
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value)},
                });
            }
            else
            {
                value = machine_test_schedule_add(&builder, leaves[2 * pair], leaves[2 * pair + 1]);
                if (shape == MACHINE_TEST_SCHEDULE_DUPLICATE)
                {
                    value = machine_test_schedule_add(&builder, value, value);
                }
            }
            values[count] = value;
            count += 1;
        }
    }
    while (count > 1)
    {
        u32 next = 0;
        for (u32 index = 0; index + 1 < count; index += 2)
        {
            values[next] = machine_test_schedule_add(&builder, values[index], values[index + 1]);
            next += 1;
        }
        if (count & 1u)
        {
            values[next] = values[count - 1];
            next += 1;
        }
        count = next;
    }
    machine_builder_instruction(&builder, (MachineInstruction){
        .opcode = MACHINE_X64_MOV_RR,
        .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[0])},
    });
    machine_builder_instruction(&builder, (MachineInstruction){.opcode = MACHINE_X64_RET});
    machine_builder_block_end(&builder, (MachineBlock){0});
    MachineFunction function = machine_function_builder_finish(arena, &builder);
    function.target = machine_target_x86_64();
    function.immediates = arena_allocate(arena, u64, 1);
    function.immediates[0] = 1;
    function.immediate_count = 1;
    return function;
}

typedef struct MachineTestScheduleTraceSummary MachineTestScheduleTraceSummary;
struct MachineTestScheduleTraceSummary
{
    bool equivalent;
    bool moved;
    u32 event_count;
    u32 kind_counts[MACHINE_SCHEDULE_TRACE_GATE + 1];
    u32 refreshed_transitions;
    u32 capped_transitions;
    u32 maximum_touchers;
    bool gate_rejected;
    MachineScheduleTrace trace;
};

// Runs the production occurrence stream and the descriptor-decoding oracle on
// the same input and requires identical decision traces and output rows.
BUSTER_GLOBAL_LOCAL MachineTestScheduleTraceSummary machine_test_schedule_trace_compare(Arena* arena, MachineFunction* function, u32 capacity_limit)
{
    MachineTestScheduleTraceSummary summary = {0};
    u32 event_capacity = 64u * function->instruction_count + 1024u;
    MachineScheduleTrace traces[2] = {0};
    MachineScheduleResult results[2] = {0};
    for (u32 index = 0; index < 2; index += 1)
    {
        traces[index] = (MachineScheduleTrace){
            .events = arena_allocate(arena, MachineScheduleTraceEvent, event_capacity),
            .event_capacity = event_capacity,
            .entry_capacity_limit = capacity_limit,
            .reference = index == 1,
        };
        results[index] = machine_schedule_function_traced(arena, function, traces + index);
    }
    MachineScheduleResult plain = capacity_limit ? results[0] : machine_schedule_function(arena, function);
    summary.equivalent = traces[0].dropped == 0 && traces[1].dropped == 0 && traces[0].event_count == traces[1].event_count &&
                         memcmp(traces[0].events, traces[1].events, traces[0].event_count * sizeof(MachineScheduleTraceEvent)) == 0 &&
                         results[0].moved == results[1].moved && results[0].moved == plain.moved &&
                         memcmp(results[0].function.instructions, results[1].function.instructions,
                                function->instruction_count * sizeof(MachineInstruction)) == 0 &&
                         memcmp(results[0].function.instructions, plain.function.instructions,
                                function->instruction_count * sizeof(MachineInstruction)) == 0;
    summary.moved = results[0].moved;
    summary.event_count = traces[0].event_count;
    summary.trace = traces[0];
    for (u32 event_index = 0; event_index < traces[0].event_count; event_index += 1)
    {
        MachineScheduleTraceEvent event = traces[0].events[event_index];
        summary.kind_counts[event.kind] += 1;
        if (event.kind == MACHINE_SCHEDULE_TRACE_TRANSITION)
        {
            summary.refreshed_transitions += event.extra <= 16;
            summary.capped_transitions += event.extra > 16;
            summary.maximum_touchers = BUSTER_MAX(summary.maximum_touchers, event.extra);
        }
        summary.gate_rejected |= event.kind == MACHINE_SCHEDULE_TRACE_GATE && event.value >= (s32)event.extra;
    }
    return summary;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_schedule_trace_equivalence(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u64 fixture_position = arguments->arena->position;

    // Exhaustive opcode x slot projection: the row lanes are the scheduler's
    // role source, and a definition is DEFINE or USE_DEFINE.
    MachineOpcodeRow const* opcode_rows = machine_opcode_row_table();
    bool projection_exact = true;
    for (u16 opcode = 0; opcode < MACHINE_OPCODE_COUNT; opcode += 1)
    {
        MachineOpcodeInfo const* info = machine_opcode_info(opcode);
        MachineOpcodeRow row = opcode_rows[opcode];
        projection_exact &= row.operand_count == info->operand_count;
        for (u32 slot = 0; slot < MACHINE_INSTRUCTION_OPERAND_COUNT; slot += 1)
        {
            u32 role = slot < info->operand_count ? info->operand_info[slot] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u) : MACHINE_OPERAND_ROLE_NONE;
            u32 uses = (row.role_lanes >> (MACHINE_OPCODE_ROW_USE_SHIFT + slot)) & 1u;
            u32 define_only = (row.role_lanes >> (MACHINE_OPCODE_ROW_DEFINE_SHIFT + slot)) & 1u;
            u32 use_define = (row.role_lanes >> (MACHINE_OPCODE_ROW_USE_DEFINE_SHIFT + slot)) & 1u;
            projection_exact &= uses == (u32)(role == MACHINE_OPERAND_ROLE_USE || role == MACHINE_OPERAND_ROLE_USE_DEFINE);
            projection_exact &= (define_only | use_define) == (u32)(role == MACHINE_OPERAND_ROLE_DEFINE || role == MACHINE_OPERAND_ROLE_USE_DEFINE);
            projection_exact &= !(define_only && use_define);
        }
        projection_exact &= (row.role_lanes >> 12) == 0;
    }
    BUSTER_TEST(arguments, projection_exact);
    // The DEFINE plane alone misses read-modify-write definitions.
    BUSTER_TEST(arguments, opcode_rows[MACHINE_X64_NEG64].role_lanes == 0x101u);
    BUSTER_TEST(arguments, opcode_rows[MACHINE_X64_NEG32].role_lanes == 0x101u);

    MachineFunction tree = machine_test_schedule_trace_function(arguments->arena, MACHINE_TEST_SCHEDULE_TREE, 0);
    BUSTER_TEST(arguments, machine_verify_function(&tree).error == MACHINE_VERIFY_NONE);
    MachineTestScheduleTraceSummary tree_summary = machine_test_schedule_trace_compare(arguments->arena, &tree, 0);
    BUSTER_TEST(arguments, tree_summary.equivalent && tree_summary.moved);
    BUSTER_TEST(arguments, tree_summary.kind_counts[MACHINE_SCHEDULE_TRACE_READY] > 0);
    BUSTER_TEST(arguments, tree_summary.kind_counts[MACHINE_SCHEDULE_TRACE_SELECT] == tree.instruction_count);
    BUSTER_TEST(arguments, tree_summary.kind_counts[MACHINE_SCHEDULE_TRACE_GATE] == 1 && !tree_summary.gate_rejected);

    // Repeated operands count per occurrence. `u = t + t` becomes ready once
    // u is demanded and t is not: growth -1 + 2 = +1, where a distinct-value
    // set would compute 0 and bucket the unit differently.
    MachineFunction duplicate = machine_test_schedule_trace_function(arguments->arena, MACHINE_TEST_SCHEDULE_DUPLICATE, 0);
    BUSTER_TEST(arguments, machine_verify_function(&duplicate).error == MACHINE_VERIFY_NONE);
    MachineTestScheduleTraceSummary duplicate_summary = machine_test_schedule_trace_compare(arguments->arena, &duplicate, 0);
    BUSTER_TEST(arguments, duplicate_summary.equivalent && duplicate_summary.moved);
    u32 duplicate_pushes = 0;
    bool duplicate_growth = true;
    for (u32 event_index = 0; event_index < duplicate_summary.event_count; event_index += 1)
    {
        MachineScheduleTraceEvent event = duplicate_summary.trace.events[event_index];
        MachineInstruction const* row = duplicate.instructions + event.subject;
        if (event.kind == MACHINE_SCHEDULE_TRACE_PUSH && event.extra == 1 && row->opcode == MACHINE_X64_ADD64 &&
            row->operands[1] == row->operands[2])
        {
            duplicate_pushes += 1;
            duplicate_growth &= event.value == 1;
        }
    }
    BUSTER_TEST(arguments, duplicate_pushes == 32 && duplicate_growth);

    MachineFunction read_modify = machine_test_schedule_trace_function(arguments->arena, MACHINE_TEST_SCHEDULE_READ_MODIFY, 0);
    BUSTER_TEST(arguments, machine_verify_function(&read_modify).error == MACHINE_VERIFY_NONE);
    MachineTestScheduleTraceSummary read_modify_summary = machine_test_schedule_trace_compare(arguments->arena, &read_modify, 0);
    BUSTER_TEST(arguments, read_modify_summary.equivalent);
    BUSTER_TEST(arguments, read_modify_summary.kind_counts[MACHINE_SCHEDULE_TRACE_SELECT] == read_modify.instruction_count);

    // Leaf 0 has fanout + 1 touches: 16 still refreshes its touchers, 17 does
    // not. With two consumers, placing one makes leaf 0 demanded while its
    // sibling is ready, so the sibling is re-pushed and its first entry goes
    // stale.
    u32 stale = tree_summary.kind_counts[MACHINE_SCHEDULE_TRACE_STALE] + duplicate_summary.kind_counts[MACHINE_SCHEDULE_TRACE_STALE] +
                read_modify_summary.kind_counts[MACHINE_SCHEDULE_TRACE_STALE];
    u32 fanouts[] = {2, 15, 16};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(fanouts); index += 1)
    {
        MachineFunction fanout = machine_test_schedule_trace_function(arguments->arena, MACHINE_TEST_SCHEDULE_FANOUT, fanouts[index]);
        BUSTER_TEST(arguments, machine_verify_function(&fanout).error == MACHINE_VERIFY_NONE);
        MachineTestScheduleTraceSummary fanout_summary = machine_test_schedule_trace_compare(arguments->arena, &fanout, 0);
        BUSTER_TEST(arguments, fanout_summary.equivalent && fanout_summary.maximum_touchers == fanouts[index] + 1);
        BUSTER_TEST(arguments, fanouts[index] + 1 > 16 ? fanout_summary.capped_transitions > 0 : fanout_summary.capped_transitions == 0);
        BUSTER_TEST(arguments, fanouts[index] != 2 || fanout_summary.kind_counts[MACHINE_SCHEDULE_TRACE_STALE] > 0);
        stale += fanout_summary.kind_counts[MACHINE_SCHEDULE_TRACE_STALE];
    }

    // A queue that runs out of entries restores source order in both paths.
    MachineTestScheduleTraceSummary exhausted = machine_test_schedule_trace_compare(arguments->arena, &tree, 8);
    BUSTER_TEST(arguments, exhausted.equivalent && !exhausted.moved);
    BUSTER_TEST(arguments, exhausted.kind_counts[MACHINE_SCHEDULE_TRACE_OVERFLOW] == 1 &&
                               exhausted.kind_counts[MACHINE_SCHEDULE_TRACE_FALLBACK] == 1 &&
                               exhausted.kind_counts[MACHINE_SCHEDULE_TRACE_GATE] == 0);

    // Selected source functions on both targets, including schedules the
    // excess gate rejects.
    String8 sources[] = {S8("tests/basic_c_machine_alias.c"), S8("tests/basic_c_operations.c")};
    u32 compared = 0;
    u32 moved = 0;
    u32 rejected = 0;
    bool corpus_equivalent = true;
    for (u32 architecture = 0; architecture < 2; architecture += 1)
    {
        Target target = {.cpu_arch = architecture ? CPU_ARCH_AARCH64 : CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX};
        for (u32 source_index = 0; source_index < BUSTER_ARRAY_LENGTH(sources); source_index += 1)
        {
            ByteSlice source = file_read(arguments->arena, sources[source_index], (FileReadOptions){0});
            IrProgram* program = source.pointer ? machine_test_compile_c(arguments->arena, sources[source_index],
                (String8){.pointer = (char8*)source.pointer, .length = source.length}, target) : 0;
            BUSTER_TEST(arguments, program && program->module_count);
            for (u32 module_index = 0; program && module_index < program->module_count; module_index += 1)
            {
                IrModule* module = program->modules + module_index;
                for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
                {
                    u64 function_position = arguments->arena->position;
                    MachineSelectResult selected = machine_select_canonical_function(arguments->arena, program, module->functions + function_index, target);
                    if (selected.supported && selected.function.instruction_count)
                    {
                        MachineTestScheduleTraceSummary summary = machine_test_schedule_trace_compare(arguments->arena, &selected.function, 0);
                        corpus_equivalent &= summary.equivalent;
                        compared += summary.kind_counts[MACHINE_SCHEDULE_TRACE_BLOCK] != 0;
                        moved += summary.moved;
                        rejected += summary.gate_rejected;
                        stale += summary.kind_counts[MACHINE_SCHEDULE_TRACE_STALE];
                    }
                    arena_set_position(arguments->arena, function_position);
                }
            }
        }
    }
    arguments->show(arguments, S8("MACHINE_SCHEDULE_TRACE scheduled_functions={u32} moved={u32} gate_rejected={u32} stale={u32}\n"), compared, moved,
                    rejected, stale);
    BUSTER_TEST(arguments, corpus_equivalent && compared > 0 && moved > 0 && rejected > 0);
    // Entries superseded by a re-push, or left behind by a placed unit, are
    // rejected on pop.
    BUSTER_TEST(arguments, stale > 0);
    arena_set_position(arguments->arena, fixture_position);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult machine_test_constant_short_circuit(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    String8 source = S8("int dead_relational(void) { return 1 || (0 > (0 || 0) || 0); }\n"
                        "int dead_nonunit(void) { return 5 || (0 > (0 || 0) || 0); }\n"
                        "int dead_group(void) { return 1 || ((0 > (0 || 0)) || 0); }\n"
                        "int dead_and(void) { return 1 || (0 > (0 && 0) || 0); }\n"
                        "int dead_less(void) { return 1 || (0 < (0 || 0) || 0); }\n"
                        "int trailing_control(void) { return 1 || (0 > (0 || 0)); }\n"
                        "int equal_control(void) { return 1 || (0 == (0 || 0) || 0); }\n"
                        "int live_control(int a) { return a || (0 > (0 || 0) || 0); }\n");
    Target targets[] = {{.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
                        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX}};
    for (u32 target = 0; target < BUSTER_ARRAY_LENGTH(targets); target += 1)
    {
        for (u32 frontend = 0; frontend < 2; frontend += 1)
        {
            TemporalArena temporary = arena_begin_temporal(arguments->arena);
            IrProgram* program = machine_test_compile_c_with_options(arguments->arena, S8("constant-short-circuit.c"), source, targets[target],
                                                                     (CIRLowerOptions){.disable_direct_ssa = frontend != 0});
            BUSTER_TEST(arguments, program && program->module_count == 1);
            if (program && program->module_count == 1)
            {
                IrModule* module = program->modules;
                IrValidationResult prepared = ir_prepare_canonical_module(program, module, false);
                BUSTER_TEST(arguments, prepared.error == IR_VALIDATION_NONE && module->function_count == 8);
                for (u32 function_index = 0; prepared.error == IR_VALIDATION_NONE && function_index < module->function_count; function_index += 1)
                {
                    MachineSelectResult selected = machine_select_canonical_function(arguments->arena, program,
                                                                                       module->functions + function_index, targets[target]);
                    MachineVerifyResult verified = selected.supported ? machine_verify_function(&selected.function) : (MachineVerifyResult){0};
                    String8 description = string_format(arguments->arena, S8("constant short circuit target={u32} frontend={u32} function='{S8}' error={S8}"),
                                                        target, frontend, module->functions[function_index].name,
                                                        machine_verify_error_name(verified.error));
                    BUSTER_TEST_RAW(arguments, selected.supported && selected.selector_certified && verified.error == MACHINE_VERIFY_NONE, description);
                }
            }
            scratch_end(temporary);
        }
    }
    return result;
}

UnitTestResult machine_tests(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    BUSTER_TEST(arguments, machine_fast_close_live_ranges_test(arguments->arena));
    BUSTER_TEST_FIXTURE(arguments, machine_test_sparse_local_state);
    BUSTER_TEST_FIXTURE(arguments, machine_test_constant_short_circuit);
    BUSTER_TEST_FIXTURE(arguments, machine_test_schedule_line_mark_repair);
    BUSTER_TEST_FIXTURE(arguments, machine_test_schedule_trace_equivalence);
    BUSTER_TEST_FIXTURE(arguments, machine_test_debug_value_capacity);
    BUSTER_TEST_FIXTURE(arguments, machine_test_debug_values_differential);
    BUSTER_TEST_FIXTURE(arguments, machine_test_quality_sparse_pins);
    BUSTER_TEST_FIXTURE(arguments, machine_test_quality_traffic);
    BUSTER_TEST_FIXTURE(arguments, machine_test_predicate_widths);
    BUSTER_TEST_FIXTURE(arguments, machine_test_predicate_edges);
    BUSTER_TEST_FIXTURE(arguments, machine_test_predicate_source);
    BUSTER_TEST_FIXTURE(arguments, machine_test_predicate_bank);
    BUSTER_TEST_FIXTURE(arguments, machine_test_win64_wide);
    BUSTER_TEST_FIXTURE(arguments, machine_test_wide_vector_boundaries);
    BUSTER_TEST_FIXTURE(arguments, machine_test_win64_aligned);
    BUSTER_TEST_FIXTURE(arguments, machine_test_win64_vector);
    BUSTER_TEST_FIXTURE(arguments, machine_test_native_aggregate);
    BUSTER_TEST_FIXTURE(arguments, machine_test_f80);
    BUSTER_TEST_FIXTURE(arguments, machine_test_native_variadic);
    BUSTER_TEST_FIXTURE(arguments, machine_test_sysv_va_list_extent);
    BUSTER_TEST_FIXTURE(arguments, machine_test_aarch64_call_relocations);
    BUSTER_TEST_FIXTURE(arguments, machine_test_inline_assembly_block_relocations);
    BUSTER_TEST_FIXTURE(arguments, machine_test_cpu_queries);
    BUSTER_TEST_FIXTURE(arguments, machine_test_compiler_barrier);
    BUSTER_TEST_FIXTURE(arguments, machine_test_inline_assembly_fixed_register_alias);
    BUSTER_TEST_FIXTURE(arguments, machine_test_inline_assembly_fixed_register_overlap);
    BUSTER_TEST_FIXTURE(arguments, machine_test_x64_uefi_platform_variadic);
    BUSTER_TEST_FIXTURE(arguments, machine_test_a64_atomic_pair_updates);
    BUSTER_TEST_FIXTURE(arguments, machine_test_a64_large_aggregate_copy);
    BUSTER_TEST_FIXTURE(arguments, machine_test_inline_assembly_goto);
    BUSTER_TEST_FIXTURE(arguments, machine_test_inline_hints);
    BUSTER_TEST_FIXTURE(arguments, machine_test_clear_instruction_cache);
    BUSTER_TEST_FIXTURE(arguments, machine_test_unsigned_switch);
    BUSTER_TEST_FIXTURE(arguments, machine_test_disconnected_dominance);
    BUSTER_TEST_FIXTURE(arguments, machine_test_frame_storage_reuse);
    BUSTER_TEST_FIXTURE(arguments, machine_test_i128_block_parameters);
    BUSTER_TEST_FIXTURE(arguments, machine_test_pointer_block_parameters);
    BUSTER_TEST_FIXTURE(arguments, machine_test_parameter_edge_split);
    BUSTER_TEST_FIXTURE(arguments, machine_test_fast_edge_index);
    BUSTER_TEST_FIXTURE(arguments, machine_test_x64_dynamic_stack);
    BUSTER_TEST_FIXTURE(arguments, machine_test_x64_i128_complement);

    // Malformed publication inputs must fail before placement or encoding.
    MachineInstruction storage_rows[2] = {{.opcode = MACHINE_X64_MOV_RI}, {.opcode = MACHINE_X64_RET}};
    MachineVirtualRegister storage_register = {
        .definition_point = machine_point_make(0, MACHINE_POINT_AFTER),
        .register_class = MACHINE_REGISTER_CLASS_GENERAL,
    };
    MachineBlock storage_block = {.instruction_count = 2};
    MachineFunction storage_function = {
        .instructions = storage_rows, .instruction_count = 2,
        .virtual_registers = &storage_register, .virtual_register_count = 1,
        .blocks = &storage_block, .block_count = 1,
        .target = machine_target_x86_64(),
    };
    storage_rows[0].operands[0] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0);
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_IMMEDIATE, 0);
    storage_function.immediate_count = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_STORAGE);
    storage_rows[0].opcode = MACHINE_X64_LOAD_FRAME;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 0);
    storage_function.immediate_count = 0;
    storage_function.stack_slot_count = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_STORAGE);
    storage_rows[0].opcode = MACHINE_X64_MOV_RI;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_BLOCK, 0);
    storage_function.stack_slot_count = 0;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_KIND);
    storage_rows[0].opcode = MACHINE_X64_MOV_RR;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_TARGET_REGISTER_LIMIT);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_REFERENCE);

    u64 immediate = 19;
    u32 slot_size = 16;
    storage_function.immediates = &immediate;
    storage_function.immediate_count = 1;
    storage_function.stack_slot_sizes = &slot_size;
    storage_function.stack_slot_count = 1;
    storage_rows[0].opcode = MACHINE_X64_MOV_RI;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_IMMEDIATE, 0);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_IMMEDIATE, 1);
    MachineVerifyResult missing_immediate = machine_verify_function(&storage_function);
    BUSTER_TEST(arguments, missing_immediate.error == MACHINE_VERIFY_OPERAND_REFERENCE && missing_immediate.instruction == 0 && missing_immediate.operand == 1);
    storage_rows[0].opcode = MACHINE_X64_LOAD_FRAME;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 0);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 1);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_REFERENCE);
    storage_rows[0].opcode = MACHINE_X64_MOV_RI;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_IMMEDIATE, 0);

#define MACHINE_TEST_ABSENT_STORAGE(member, count_member) \
    do \
    { \
        MachineFunction absent = storage_function; \
        absent.member = 0; \
        absent.count_member = 1; \
        BUSTER_TEST(arguments, machine_verify_function(&absent).error == MACHINE_VERIFY_STORAGE); \
    } while (0)
    MACHINE_TEST_ABSENT_STORAGE(instructions, instruction_count);
    MACHINE_TEST_ABSENT_STORAGE(virtual_registers, virtual_register_count);
    MACHINE_TEST_ABSENT_STORAGE(blocks, block_count);
    MACHINE_TEST_ABSENT_STORAGE(edges, edge_count);
    MACHINE_TEST_ABSENT_STORAGE(block_parameters, block_parameter_count);
    MACHINE_TEST_ABSENT_STORAGE(edge_copy_sources, edge_copy_source_count);
    MACHINE_TEST_ABSENT_STORAGE(immediates, immediate_count);
    MACHINE_TEST_ABSENT_STORAGE(stack_slot_sizes, stack_slot_count);
    MACHINE_TEST_ABSENT_STORAGE(call_targets, call_target_count);
    MACHINE_TEST_ABSENT_STORAGE(switch_cases, switch_case_count);
    MACHINE_TEST_ABSENT_STORAGE(line_marks, line_mark_count);
    MACHINE_TEST_ABSENT_STORAGE(va_args, va_arg_count);
#undef MACHINE_TEST_ABSENT_STORAGE
    BUSTER_TEST(arguments, machine_verify_function(0).error == MACHINE_VERIFY_STORAGE);

    // A reference's own index may be in range while its opcode kind is wrong.
    MachineRefKind wrong_immediate_kinds[] = {MACHINE_REF_NONE, MACHINE_REF_BLOCK, MACHINE_REF_STACK_SLOT,
                                             MACHINE_REF_VIRTUAL_REGISTER, MACHINE_REF_PHYSICAL_REGISTER};
    for (u32 kind_index = 0; kind_index < BUSTER_ARRAY_LENGTH(wrong_immediate_kinds); kind_index += 1)
    {
        storage_rows[0].operands[1] = machine_ref_make(wrong_immediate_kinds[kind_index], 0);
        BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_KIND);
    }
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_IMMEDIATE, 0);
    storage_rows[0].operands[0] = machine_ref_make(MACHINE_REF_IMMEDIATE, 0);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_KIND);
    storage_rows[0].operands[0] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0);
    storage_register.register_class = MACHINE_REGISTER_CLASS_VECTOR;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_CLASS);
    storage_register.register_class = MACHINE_REGISTER_CLASS_GENERAL;
    storage_rows[0].opcode = MACHINE_X64_MOV_RR;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_ZMM0);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_CLASS);
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_ADDRESS, 0);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_REFERENCE);
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_EXTRA, 0);
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_REFERENCE);

    MachineTargetDescription const* physical_targets[] = {0, machine_target_x86_64(), machine_target_aarch64()};
    for (u32 target_index = 0; target_index < BUSTER_ARRAY_LENGTH(physical_targets); target_index += 1)
    {
        MachineTargetDescription const* target = physical_targets[target_index];
        storage_function.target = target;
        bool vector_target = target && target->vector_register_mask != 0;
        storage_register.register_class = vector_target ? MACHINE_REGISTER_CLASS_VECTOR : MACHINE_REGISTER_CLASS_GENERAL;
        storage_rows[0].opcode = vector_target ? MACHINE_X64_VMOV_RR : MACHINE_OPCODE_SKELETON_COPY;
        u32 limit = target ? target->register_count : MACHINE_TARGET_REGISTER_LIMIT;
        storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, limit - 1u);
        BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
        u32 invalid_registers[] = {limit, MACHINE_PREDICATE_REGISTER_BASE + MACHINE_PREDICATE_REGISTER_COUNT, MACHINE_REF_PAYLOAD_LIMIT - 1u};
        for (u32 invalid_index = 0; invalid_index < BUSTER_ARRAY_LENGTH(invalid_registers); invalid_index += 1)
        {
            storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, invalid_registers[invalid_index]);
            BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_OPERAND_REFERENCE);
        }
    }
    storage_function.target = machine_target_x86_64();
    storage_register.register_class = MACHINE_REGISTER_CLASS_GENERAL;
    storage_rows[0].opcode = MACHINE_X64_MOV_RI;
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_IMMEDIATE, 0);

    u32 slot_alignment = 16;
    storage_function.stack_slot_alignments = &slot_alignment;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    u32 invalid_alignments[] = {0, 3, 32};
    for (u32 alignment_index = 0; alignment_index < BUSTER_ARRAY_LENGTH(invalid_alignments); alignment_index += 1)
    {
        slot_alignment = invalid_alignments[alignment_index];
        BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    }
    storage_function.stack_slot_alignments = 0;
    storage_function.outgoing_bytes = 16;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    storage_function.outgoing_slot = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    storage_function.outgoing_slot = 0;
    storage_function.outgoing_bytes = 8;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    storage_function.outgoing_bytes = 0;

    // Width-16 x86 stores publish one sixteen-byte desired frame image.  The
    // payload carries the logical byte count (the upper seven bytes are
    // padding for payloads 9..15), while all three frame operands must name
    // that same image.  Keep malformed rows in this direct verifier fixture
    // so placement and encoding cannot accidentally become the first guard.
    MachineInstruction store16_rows[2] = {
        {
            .opcode = MACHINE_X64_ATOMIC_STORE16,
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, 0), machine_ref_make(MACHINE_REF_STACK_SLOT, 0),
                         machine_ref_make(MACHINE_REF_STACK_SLOT, 0), machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_R10)},
            .payload = 16,
        },
        {.opcode = MACHINE_X64_RET},
    };
    MachineBlock store16_block = {.instruction_count = 2};
    u32 store16_slot_sizes[2] = {16, 16};
    MachineFunction store16_function = {
        .instructions = store16_rows,
        .instruction_count = BUSTER_ARRAY_LENGTH(store16_rows),
        .virtual_registers = 0,
        .virtual_register_count = 0,
        .blocks = &store16_block,
        .block_count = 1,
        .stack_slot_sizes = store16_slot_sizes,
        .stack_slot_count = 1,
        .target = machine_target_x86_64(),
    };
    BUSTER_TEST(arguments, machine_verify_function(&store16_function).error == MACHINE_VERIFY_NONE);
    store16_rows[0].payload = 8;
    BUSTER_TEST(arguments, machine_verify_function(&store16_function).error == MACHINE_VERIFY_PAYLOAD);
    store16_rows[0].payload = 17;
    BUSTER_TEST(arguments, machine_verify_function(&store16_function).error == MACHINE_VERIFY_PAYLOAD);
    store16_rows[0].payload = 16;
    store16_slot_sizes[0] = 8;
    BUSTER_TEST(arguments, machine_verify_function(&store16_function).error == MACHINE_VERIFY_PAYLOAD);
    store16_slot_sizes[0] = 16;
    store16_function.stack_slot_count = 2;
    store16_rows[0].operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 1);
    BUSTER_TEST(arguments, machine_verify_function(&store16_function).error == MACHINE_VERIFY_PAYLOAD);
    store16_rows[0].operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 0);
    store16_rows[0].flags = 1;
    BUSTER_TEST(arguments, machine_verify_function(&store16_function).error == MACHINE_VERIFY_PAYLOAD);

    MachineSwitchCase switch_case = {.target_block = 0};
    storage_function.switch_cases = &switch_case;
    storage_function.switch_case_count = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    switch_case.target_block = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_EDGE_RANGE);
    storage_function.switch_case_count = 0;
    MachineLineMark line_marks[2] = {{.row = 0}, {.row = 2}};
    storage_function.line_marks = line_marks;
    storage_function.line_mark_count = 2;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    line_marks[1].row = 3;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    line_marks[0].row = 2;
    line_marks[1].row = 0;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    storage_function.line_mark_count = 0;

    // Every opcode whose payload becomes a relocation's target index shares
    // the same table contract, including TLS and symbol-address materialization.
    IrSymbolId call_target = {.value = 0};
    storage_function.call_targets = &call_target;
    storage_function.call_target_count = 1;
    u8 call_reference = MACHINE_SYMBOL_REFERENCE_PLT;
    storage_function.call_target_references = &call_reference;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    call_reference = MACHINE_SYMBOL_REFERENCE_COUNT;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    storage_function.call_target_references = 0;
    u16 symbol_opcodes[] = {MACHINE_X64_CALL_DIRECT, MACHINE_X64_LEA_SYMBOL, MACHINE_X64_LOAD_SYMBOL_GOT, MACHINE_X64_LEA_TLS,
                           MACHINE_X64_LEA_TLS_INITIAL_EXEC, MACHINE_X64_TLS_GENERAL_DYNAMIC,
                           MACHINE_A64_CALL_DIRECT, MACHINE_A64_LEA_SYMBOL, MACHINE_A64_LEA_TLS};
    for (u32 opcode_index = 0; opcode_index < BUSTER_ARRAY_LENGTH(symbol_opcodes); opcode_index += 1)
    {
        u16 opcode = symbol_opcodes[opcode_index];
        storage_rows[0] = (MachineInstruction){.opcode = opcode};
        bool has_result = machine_opcode_info(opcode)->operand_count != 0;
        storage_rows[0].operands[0] = has_result ? machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0) : MACHINE_REF_NONE_VALUE;
        storage_function.virtual_register_count = has_result ? 1u : 0u;
        BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
        storage_rows[0].payload = 1;
        BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    }
    storage_function.virtual_register_count = 1;
    storage_rows[0] = (MachineInstruction){
        .opcode = MACHINE_X64_VA_ARG,
        .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0)},
    };
    MachineVaArg va_arg = {
        .size = 8, .alignment = 8, .stack_size = 8, .part_count = 1,
        .parts = {{.size = 8}}, .scalar_size = 8,
    };
    storage_function.va_args = &va_arg;
    storage_function.va_arg_count = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    storage_rows[0].payload = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    storage_rows[0].payload = 0;
    va_arg.part_count = MACHINE_VA_ARG_PART_LIMIT + 1u;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.part_count = 1;
    va_arg.result_is_frame = 1;
    va_arg.result_slot = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.result_slot = 0;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    storage_rows[0].operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 0);
    storage_function.virtual_register_count = 0;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    va_arg.parts[0].value_offset = 16;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.parts[0].value_offset = 0;
    va_arg.parts[0].save_offset = 8;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.parts[0].save_offset = 0;
    // AArch64 reads a padded eightbyte for a smaller logical scalar/aggregate.
    storage_rows[0].opcode = MACHINE_A64_VA_ARG;
    storage_rows[0].operands[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_A64_X10);
    storage_function.target = machine_target_aarch64();
    va_arg.size = 3;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    // An indirect composite has an eight-byte argument image and an exact
    // larger destination; malformed metadata must not become a padded read.
    va_arg.size = 17;
    va_arg.indirect = 1;
    slot_size = 24;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    va_arg.stack_size = 24;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.stack_size = 8;
    va_arg.parts[0].is_float = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.parts[0].is_float = 0;
    va_arg.alignment = 16;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.alignment = 8;
    va_arg.indirect = 0;
    va_arg.size = 16;
    va_arg.stack_size = 16;
    va_arg.parts[0].size = 16;
    va_arg.parts[0].is_float = 1;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);
    va_arg.parts[0].is_float = 0;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_PAYLOAD);
    va_arg.parts[0].size = 8;
    // The SysV memory path can transport aggregates larger than two eightbytes.
    storage_rows[0].opcode = MACHINE_X64_VA_ARG;
    storage_rows[0].operands[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX);
    storage_function.target = machine_target_x86_64();
    va_arg.size = 24;
    va_arg.stack_size = 24;
    va_arg.parts[0].is_memory = 1;
    slot_size = 24;
    BUSTER_TEST(arguments, machine_verify_function(&storage_function).error == MACHINE_VERIFY_NONE);

    // Each target-file tail, inactive owners equal to the query, duplicate
    // owners, and all four SIMD tiles must agree with lane membership. The
    // empty mask deliberately permits a null row, as an empty contract does.
    BUSTER_TEST(arguments, machine_fast_owner_match_mask_test(0, 0, 0) == 0);
    BUSTER_TEST(arguments, !machine_fast_owner_contains_test(0, 0, 0));
    BUSTER_TEST(arguments, !machine_fast_owner_contains_test(0, 0, UINT32_MAX));
    u64 owner_page_size = os_get_page_size();
    u8* owner_pages = (u8*)os_reserve(0, owner_page_size * 2u, (ProtectionFlags){0}, (MapFlags){.priv = true, .anonymous = true, .no_reserve = true});
    BUSTER_TEST(arguments, owner_pages != 0);
    bool owner_page_committed = owner_pages && os_commit(owner_pages, owner_page_size, (ProtectionFlags){.read = true, .write = true}, false);
    BUSTER_TEST(arguments, owner_page_committed);
    for (u32 count = 1; owner_page_committed && count <= 64; count += 1)
    {
        // Exact logical rows end at an inaccessible page: vector loads over
        // a partial tile must not borrow padding from the next owner row.
        u32* owners = (u32*)(owner_pages + owner_page_size) - count;
        u64 valid = mask64_prefix(count);
        u64 masks[] = {valid, valid & UINT64_C(0x5555555555555555), valid & UINT64_C(0xffff0000ffff0000), valid & UINT64_C(0x8000800080008000)};
        for (u32 lane = 0; lane < count; lane += 1)
        {
            owners[lane] = lane % 7;
        }
        for (u32 mask_index = 0; mask_index < BUSTER_ARRAY_LENGTH(masks); mask_index += 1)
        {
            for (u32 value = 0; value <= 7; value += 1)
            {
                u64 expected = 0;
                for (u32 lane = 0; lane < count; lane += 1)
                {
                    if (owners[lane] == value && ((masks[mask_index] >> lane) & 1u))
                    {
                        expected |= UINT64_C(1) << lane;
                    }
                }
                BUSTER_TEST(arguments, machine_fast_owner_match_mask_test(owners, masks[mask_index], value) == expected);
                BUSTER_TEST(arguments, machine_fast_owner_contains_test(owners, masks[mask_index], value) == (expected != 0));
            }
        }
        // Unique high-bit owners cover late sparse hits and absent values,
        // independently of the duplicate-owner populations above.
        for (u32 lane = 0; lane < count; lane += 1)
        {
            owners[lane] = UINT32_C(0x80000000) + lane;
        }
        u32 queries[] = {owners[0], owners[count - 1u], UINT32_MAX};
        for (u32 mask_index = 0; mask_index < BUSTER_ARRAY_LENGTH(masks); mask_index += 1)
        {
            for (u32 query_index = 0; query_index < BUSTER_ARRAY_LENGTH(queries); query_index += 1)
            {
                bool expected = false;
                for (u32 lane = 0; lane < count; lane += 1)
                {
                    expected |= owners[lane] == queries[query_index] && ((masks[mask_index] >> lane) & 1u);
                }
                BUSTER_TEST(arguments, machine_fast_owner_contains_test(owners, masks[mask_index], queries[query_index]) == expected);
            }
        }
    }
    if (owner_pages)
    {
        BUSTER_TEST(arguments, os_unreserve(owner_pages, owner_page_size * 2u));
    }

    // Exercise the stateless FAST picker directly on both target register
    // files: preferred free, lowest nonpreferred free, dead-first eviction,
    // stable LRU tie order, and the nonzero-mask ctz guard (the no-free cases
    // also prove the picker never asks ctz to decode zero).
    u32 fast_picker_test_cases = machine_fast_picker_test_cases();
    BUSTER_TEST(arguments, fast_picker_test_cases & MACHINE_FAST_PICK_TEST_PREFERRED_FREE);
    BUSTER_TEST(arguments, fast_picker_test_cases & MACHINE_FAST_PICK_TEST_LOWEST_OTHER_FREE);
    BUSTER_TEST(arguments, fast_picker_test_cases & MACHINE_FAST_PICK_TEST_DEAD_FIRST);
    BUSTER_TEST(arguments, fast_picker_test_cases & MACHINE_FAST_PICK_TEST_LRU_ORDER);
    BUSTER_TEST(arguments, fast_picker_test_cases & MACHINE_FAST_PICK_TEST_CTZ_GUARD);

    MachineRef ref = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, MACHINE_REF_PAYLOAD_LIMIT - 1u);
    BUSTER_TEST(arguments, machine_ref_kind(ref) == MACHINE_REF_VIRTUAL_REGISTER);
    BUSTER_TEST(arguments, machine_ref_payload(ref) == MACHINE_REF_PAYLOAD_LIMIT - 1u);
    BUSTER_TEST(arguments, machine_ref_kind(MACHINE_REF_NONE_VALUE) == MACHINE_REF_NONE);
    BUSTER_TEST(arguments, machine_ref_payload(MACHINE_REF_NONE_VALUE) == 0);

    MachinePoint point = machine_point_make(MACHINE_POINT_INSTRUCTION_LIMIT - 1u, MACHINE_POINT_AFTER);
    BUSTER_TEST(arguments, machine_point_instruction(point) == MACHINE_POINT_INSTRUCTION_LIMIT - 1u);
    BUSTER_TEST(arguments, machine_point_phase(point) == MACHINE_POINT_AFTER);
    BUSTER_TEST(arguments, machine_point_phase(machine_point_make(7, MACHINE_POINT_BEFORE)) == MACHINE_POINT_BEFORE);
    // Phase order is the overlap contract: BEFORE < EARLY < NORMAL < AFTER
    // within one instruction, and the next instruction's BEFORE follows.
    BUSTER_TEST(arguments, machine_point_make(3, MACHINE_POINT_BEFORE) < machine_point_make(3, MACHINE_POINT_EARLY));
    BUSTER_TEST(arguments, machine_point_make(3, MACHINE_POINT_AFTER) < machine_point_make(4, MACHINE_POINT_BEFORE));

    // Frozen ordering contract from ebfdd117, before the opcode switches
    // were removed. Omitted opcodes belong to none of these three chains;
    // check the full domain so adding or dropping membership fails locally.
    // These are scheduler obligations, not a census of hardware memory or
    // vector instructions: explicit virtual vector dataflow needs no chain.
    BUSTER_CT_CHECK(MACHINE_OPCODE_COUNT == 306);
    u8 const schedule_memberships[MACHINE_OPCODE_COUNT] = {
        [MACHINE_X64_F80_BINARY] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_F80_NEGATE] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_F80_COMPARE] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_F80_CONVERT] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_F80_RESULT_LOAD] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_F80_RESULT_STORE] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VLOAD_PTR_K] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VSTORE_PTR_K] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VCOMPRESS_STORE_PTR_K] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_UMULH64] = 0, // Pure GPR dataflow; no implicit chain.
        [MACHINE_A64_CLZ32] = 0,
        [MACHINE_A64_CLZ64] = 0,
        [MACHINE_A64_RBIT32] = 0,
        [MACHINE_A64_RBIT64] = 0,
        [MACHINE_X64_TLS_WINDOWS] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_TLS_WINDOWS] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_TLS_DARWIN] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_TLS_DARWIN] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_COMPILER_BARRIER] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_COMPILER_BARRIER] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_NOP] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_PAUSE] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_NOP] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_YIELD] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_ASM_IDENTITY] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_ASM_IDENTITY] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_INLINE_ASSEMBLY] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_INLINE_ASSEMBLY] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_INLINE_EFFECTS_NONE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_INLINE_EFFECTS_MEMORY] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_INLINE_EFFECTS_FLAGS] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_INLINE_EFFECTS_MEMORY_FLAGS] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_INLINE_EFFECTS_NONE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_INLINE_EFFECTS_MEMORY] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_INLINE_EFFECTS_FLAGS] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_INLINE_EFFECTS_MEMORY_FLAGS] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_OPCODE_SKELETON_RETURN] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_CVT_U64_TO_F32] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_U64_TO_F64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_F32_TO_U64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_F64_TO_U64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_LOAD_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_FRAME8] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_FRAME16] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_FRAME32] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_FRAME64] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_LOAD_PTR8] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_LOAD_PTR16] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_LOAD_PTR32] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_LOAD_PTR64] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_PTR8] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_PTR16] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_PTR32] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_STORE_PTR64] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_JMP] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_JCC] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_RET] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_CPUID] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_XGETBV] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_WIN_VA_SAVE] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_CALL_DIRECT] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_TLS_GENERAL_DYNAMIC] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_SWITCH] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_COPY_FRAME_FROM_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_COPY_FRAME_FROM_PTR] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_COPY_PTR_FROM_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_FARITH] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_FCMP_SET] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_F32_TO_F64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_F64_TO_F32] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_I64_TO_F32] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_I64_TO_F64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_F32_TO_I64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_CVT_F64_TO_I64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_MOVQ_TO_XMM] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_MOVQ_FROM_XMM] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_LOAD_XMM0_FRAME128] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_STORE_XMM0_FRAME128] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_LOAD_XMM_FRAME128] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_STORE_XMM_FRAME128] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_LOAD_YMM_FRAME256] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_STORE_YMM_FRAME256] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_LOAD_INCOMING] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VA_SAVE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_VA_ARG] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_PUSH_FRAME] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_PUSH_REGISTER] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_SUB_RSP] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_ADD_RSP] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_STACK_ALLOCATE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_CALL_INDIRECT] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_ATOMIC_STORE_XCHG] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_ATOMIC_RMW] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_ATOMIC_CMPXCHG] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_ATOMIC_CMPXCHG16] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_ATOMIC_STORE16] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_ATOMIC_LOAD16] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_ATOMIC_RMW16] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_MFENCE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_INT3] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_UD2] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_X64_VLOAD_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VSTORE_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VLOAD_PTR] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VSTORE_PTR] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VLOAD_PTR_MASKED] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VSTORE_PTR_MASKED] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_X64_VCOMPRESS_STORE_PTR] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_LOAD_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_LOAD_FRAME32] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_FRAME8] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_FRAME16] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_FRAME32] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_FRAME64] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_LOAD_PTR8] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_LOAD_PTR16] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_LOAD_PTR32] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_LOAD_PTR64] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_PTR8] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_PTR16] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_PTR32] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_STORE_PTR64] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_COPY_FRAME_FROM_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_COPY_FRAME_FROM_PTR] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_COPY_PTR_FROM_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_B] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_BCC] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_RET] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_FMOV_TO_VEC] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_FMOV_FROM_VEC] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_BRK] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_UDF] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_READ_SP] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_WRITE_SP] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_CALL_DIRECT] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_CALL_INDIRECT] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_FARITH] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_FCMP_SET] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F32_TO_F64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F64_TO_F32] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F16_TO_F32] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F16_TO_F64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F32_TO_F16] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F64_TO_F16] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_I64_TO_F32] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_I64_TO_F64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F32_TO_I64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F64_TO_I64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_U64_TO_F32] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_U64_TO_F64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F32_TO_U64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_CVT_F64_TO_U64] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_LOAD_INCOMING] = MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_VA_SAVE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_VA_HOME_WINDOWS] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_VA_ARG] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_VLOAD_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_VSTORE_FRAME] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_VARITH] = MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_ATOMIC_LOAD] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_ATOMIC_STORE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_ATOMIC_LOAD_PAIR] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_ATOMIC_STORE_PAIR] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_ATOMIC_RMW_PAIR] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_ATOMIC_CAS_PAIR] = MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY,
        [MACHINE_A64_ATOMIC_RMW] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_ATOMIC_CAS] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_ATOMIC_FENCE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_CLEAR_INSTRUCTION_CACHE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_STACK_ALLOCATE] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_SWITCH] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_VLOAD_FRAME_SIZED] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_A64_VSTORE_FRAME_SIZED] = MACHINE_SCHEDULE_UNIT_MEMORY | MACHINE_SCHEDULE_UNIT_VECTOR,
        [MACHINE_X64_INDIRECT_BRANCH] = MACHINE_SCHEDULE_UNIT_BARRIER,
        [MACHINE_A64_INDIRECT_BRANCH] = MACHINE_SCHEDULE_UNIT_BARRIER,
    };
    MachineOpcodeRow const* opcode_rows = machine_opcode_row_table();
    for (u16 opcode = 0; opcode < MACHINE_OPCODE_COUNT; opcode += 1)
    {
        BUSTER_TEST(arguments, opcode_rows[opcode].schedule_flags == schedule_memberships[opcode]);
        // Whole-domain equivalence with the explicit constraint authority.
        // This also runs unchanged on the pre-removal table: a legacy-only
        // constraint would disagree with both the helper and its projection.
        MachineOpcodeInfo const* info = machine_opcode_info(opcode);
        // The frozen scheduler memberships independently cover every memory
        // opcode, including effect-only rows that never had the removed bit.
        bool expected_memory = (schedule_memberships[opcode] & MACHINE_SCHEDULE_UNIT_MEMORY) != 0;
        BUSTER_TEST(arguments, machine_opcode_is_memory(info) == expected_memory);
        BUSTER_TEST(arguments, (machine_opcode_memory_effect(info) != MACHINE_MEMORY_EFFECT_NONE) == expected_memory);
        BUSTER_TEST(arguments, opcode_rows[opcode].clobber_mask == info->clobber_mask);
        BUSTER_TEST(arguments, ((opcode_rows[opcode].flags & MACHINE_OPCODE_ROW_CLOBBERS) != 0) == (info->clobber_mask != 0));
        BUSTER_TEST(arguments, ((opcode_rows[opcode].flags & MACHINE_OPCODE_ROW_FLAGS_DEFINE) != 0) ==
                                   ((info->attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE) != 0));
        BUSTER_TEST(arguments, ((opcode_rows[opcode].flags & MACHINE_OPCODE_ROW_FLAGS_USE) != 0) ==
                                   ((info->attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_USE) != 0));
        bool constrained = info->tied_pair || info->early_clobber_mask || info->fixed_register_mask ||
                           (info->attributes & MACHINE_OPCODE_ATTRIBUTE_CONSTRAINED);
        BUSTER_TEST(arguments, machine_opcode_has_constraints(info) == constrained);
        BUSTER_TEST(arguments, ((opcode_rows[opcode].flags & MACHINE_OPCODE_ROW_CONSTRAINED) != 0) == constrained);
        for (u32 slot = 0; slot < BUSTER_ARRAY_LENGTH(info->fixed_registers); slot += 1)
        {
            u32 expected = (info->fixed_register_mask & (1u << slot)) ? info->fixed_registers[slot] : UINT32_MAX;
            BUSTER_TEST(arguments, machine_opcode_fixed_register(info, slot) == expected);
        }
    }

    // Aggregate transfers and incoming reads must be described by their
    // effects; the alias-order regression no longer supplies opcode exceptions.
    u16 const copy_memory_opcodes[] = {
        MACHINE_X64_COPY_FRAME_FROM_FRAME, MACHINE_X64_COPY_FRAME_FROM_PTR, MACHINE_X64_COPY_PTR_FROM_FRAME,
        MACHINE_A64_COPY_FRAME_FROM_FRAME, MACHINE_A64_COPY_FRAME_FROM_PTR, MACHINE_A64_COPY_PTR_FROM_FRAME,
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(copy_memory_opcodes); index += 1)
    {
        BUSTER_TEST(arguments, machine_opcode_memory_effect(machine_opcode_info(copy_memory_opcodes[index])) == MACHINE_MEMORY_EFFECT_READ_WRITE);
    }
    BUSTER_TEST(arguments, machine_opcode_memory_effect(machine_opcode_info(MACHINE_X64_LOAD_INCOMING)) == MACHINE_MEMORY_EFFECT_READ);
    BUSTER_TEST(arguments, machine_opcode_memory_effect(machine_opcode_info(MACHINE_A64_LOAD_INCOMING)) == MACHINE_MEMORY_EFFECT_READ);

    MachineOpcodeInfo memory_probe = {0};
    BUSTER_TEST(arguments, !machine_opcode_is_memory(0));
    BUSTER_TEST(arguments, !machine_opcode_is_memory(&memory_probe));
    // A side-effect barrier alone need not participate in the memory chain.
    memory_probe.attributes = MACHINE_OPCODE_ATTRIBUTE_SIDE_EFFECTS;
    BUSTER_TEST(arguments, !machine_opcode_is_memory(&memory_probe));
    for (u8 effect = MACHINE_MEMORY_EFFECT_READ; effect < MACHINE_MEMORY_EFFECT_COUNT; effect += 1)
    {
        memory_probe.memory_effect = effect;
        BUSTER_TEST(arguments, machine_opcode_is_memory(&memory_probe));
    }
    memory_probe.memory_effect = MACHINE_MEMORY_EFFECT_COUNT;
    BUSTER_TEST(arguments, !machine_opcode_is_memory(&memory_probe));
    memory_probe.memory_effect = UINT8_MAX;
    BUSTER_TEST(arguments, !machine_opcode_is_memory(&memory_probe));

    // The complete SHIFT/DIVIDE/MULTIPLY_HIGH family that formerly repeated
    // an RAX/RCX register set in addition to its two explicit slot bindings.
    u16 const fixed_pair_opcodes[] = {
        MACHINE_X64_SHL32, MACHINE_X64_SHL64, MACHINE_X64_SAR32, MACHINE_X64_SAR64, MACHINE_X64_SHR32, MACHINE_X64_SHR64,
        MACHINE_X64_SDIV32, MACHINE_X64_SDIV64, MACHINE_X64_UDIV32, MACHINE_X64_UDIV64,
        MACHINE_X64_SREM32, MACHINE_X64_SREM64, MACHINE_X64_UREM32, MACHINE_X64_UREM64, MACHINE_X64_MULH64,
    };
    BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(fixed_pair_opcodes) == 15);
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(fixed_pair_opcodes); index += 1)
    {
        MachineOpcodeInfo const* info = machine_opcode_info(fixed_pair_opcodes[index]);
        BUSTER_TEST(arguments, info->operand_count == 2 && info->fixed_register_mask == 3);
        BUSTER_TEST(arguments, machine_opcode_fixed_register(info, 0) == MACHINE_X64_RAX);
        BUSTER_TEST(arguments, machine_opcode_fixed_register(info, 1) == MACHINE_X64_RCX);
        BUSTER_TEST(arguments, machine_opcode_fixed_register(info, 2) == UINT32_MAX);
        BUSTER_TEST(arguments, machine_opcode_fixed_register(info, 3) == UINT32_MAX);
        BUSTER_TEST(arguments, (info->attributes & MACHINE_OPCODE_ATTRIBUTE_CONSTRAINED) != 0);
    }

    // These encoder sequences must retain scratch clobbers after removal
    // of the unused implicit-physical duplicate. Division and high multiply
    // write RDX; unsigned float conversions use RCX and two vector scratch
    // registers beyond their declared operands.
    u16 const rdx_clobber_opcodes[] = {
        MACHINE_X64_SDIV32, MACHINE_X64_SDIV64, MACHINE_X64_UDIV32, MACHINE_X64_UDIV64,
        MACHINE_X64_SREM32, MACHINE_X64_SREM64, MACHINE_X64_UREM32, MACHINE_X64_UREM64, MACHINE_X64_MULH64,
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(rdx_clobber_opcodes); index += 1)
    {
        BUSTER_TEST(arguments, machine_opcode_info(rdx_clobber_opcodes[index])->clobber_mask == (1ull << MACHINE_X64_RDX));
    }
    u16 const conversion_clobber_opcodes[] = {
        MACHINE_X64_CVT_U64_TO_F32, MACHINE_X64_CVT_U64_TO_F64, MACHINE_X64_CVT_F32_TO_U64, MACHINE_X64_CVT_F64_TO_U64,
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(conversion_clobber_opcodes); index += 1)
    {
        u64 expected = (1ull << MACHINE_X64_RCX) | (1ull << MACHINE_X64_ZMM0) | (1ull << MACHINE_X64_ZMM1);
        BUSTER_TEST(arguments, machine_opcode_info(conversion_clobber_opcodes[index])->clobber_mask == expected);
    }

    // A register byte has no meaning without its mask bit. In particular,
    // fixed RAX (register zero) is not the absence of an assignment.
    MachineOpcodeInfo fixed_probe = {0};
    BUSTER_TEST(arguments, !machine_opcode_has_constraints(&fixed_probe));
    for (u32 slot = 0; slot < BUSTER_ARRAY_LENGTH(fixed_probe.fixed_registers); slot += 1)
    {
        fixed_probe.fixed_registers[slot] = MACHINE_X64_RCX;
        BUSTER_TEST(arguments, machine_opcode_fixed_register(&fixed_probe, slot) == UINT32_MAX);
    }
    BUSTER_TEST(arguments, !machine_opcode_has_constraints(&fixed_probe));
    fixed_probe.fixed_register_mask = 1;
    fixed_probe.fixed_registers[0] = MACHINE_X64_RAX;
    BUSTER_TEST(arguments, machine_opcode_has_constraints(&fixed_probe));
    BUSTER_TEST(arguments, machine_opcode_fixed_register(&fixed_probe, 0) == MACHINE_X64_RAX);
    BUSTER_TEST(arguments, machine_opcode_fixed_register(&fixed_probe, 1) == UINT32_MAX);
    BUSTER_TEST(arguments, machine_opcode_fixed_register(&fixed_probe, 4) == UINT32_MAX);
    BUSTER_TEST(arguments, machine_opcode_fixed_register(&fixed_probe, UINT32_MAX) == UINT32_MAX);
    BUSTER_TEST(arguments, machine_opcode_fixed_register(0, 0) == UINT32_MAX);
    BUSTER_TEST(arguments, !machine_opcode_has_constraints(0));
    fixed_probe.fixed_register_mask = 0;
    fixed_probe.early_clobber_mask = 1;
    BUSTER_TEST(arguments, machine_opcode_has_constraints(&fixed_probe));
    fixed_probe.early_clobber_mask = 0;
    fixed_probe.attributes = MACHINE_OPCODE_ATTRIBUTE_CONSTRAINED;
    BUSTER_TEST(arguments, machine_opcode_has_constraints(&fixed_probe));
    fixed_probe.attributes = 0;
    fixed_probe.tied_pair = (u8)(1u | (2u << 4));
    BUSTER_TEST(arguments, machine_opcode_has_constraints(&fixed_probe));
    BUSTER_TEST(arguments, machine_opcode_fixed_register(&fixed_probe, 0) == UINT32_MAX);

    // Vector scratch membership is orthogonal to the load class. A frame
    // read in an implicit V register must participate in both chains.
    MachineOpcodeInfo const* vector_load_info = machine_opcode_info(MACHINE_A64_VLOAD_FRAME);
    BUSTER_TEST(arguments, machine_opcode_memory_effect(vector_load_info) == MACHINE_MEMORY_EFFECT_READ);
    BUSTER_TEST(arguments, vector_load_info && vector_load_info->implicit_vector_state);

    MachineOpcodeInfo const* copy_info = machine_opcode_info(MACHINE_OPCODE_SKELETON_COPY);
    BUSTER_TEST(arguments, copy_info && copy_info->operand_count == 2);
    BUSTER_TEST(arguments, copy_info && (copy_info->operand_info[0] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u)) == MACHINE_OPERAND_ROLE_DEFINE);
    BUSTER_TEST(arguments, copy_info && (copy_info->operand_info[1] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u)) == MACHINE_OPERAND_ROLE_USE);
    MachineOpcodeInfo const* return_info = machine_opcode_info(MACHINE_OPCODE_SKELETON_RETURN);
    BUSTER_TEST(arguments, return_info && (return_info->attributes & MACHINE_OPCODE_ATTRIBUTE_TERMINATOR));
    MachineOpcodeInfo const* stack_allocate_info = machine_opcode_info(MACHINE_X64_STACK_ALLOCATE);
    BUSTER_TEST(arguments, stack_allocate_info && (stack_allocate_info->attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE));
    MachineOpcodeInfo const* cmpxchg16_info = machine_opcode_info(MACHINE_X64_ATOMIC_CMPXCHG16);
    u64 cmpxchg16_fixed = (1ull << MACHINE_X64_RAX) | (1ull << MACHINE_X64_RDX) | (1ull << MACHINE_X64_RBX) | (1ull << MACHINE_X64_RCX);
    BUSTER_TEST(arguments, cmpxchg16_info && cmpxchg16_info->operand_count == 4);
    BUSTER_TEST(arguments, cmpxchg16_info && (cmpxchg16_info->operand_info[0] >> MACHINE_OPERAND_SHAPE_SHIFT) == MACHINE_OPERAND_SHAPE_FRAME &&
                                   (cmpxchg16_info->operand_info[1] >> MACHINE_OPERAND_SHAPE_SHIFT) == MACHINE_OPERAND_SHAPE_FRAME &&
                                   (cmpxchg16_info->operand_info[2] >> MACHINE_OPERAND_SHAPE_SHIFT) == MACHINE_OPERAND_SHAPE_FRAME &&
                                   (cmpxchg16_info->operand_info[3] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u)) == MACHINE_OPERAND_ROLE_USE);
    BUSTER_TEST(arguments, cmpxchg16_info && (cmpxchg16_info->attributes & MACHINE_OPCODE_ATTRIBUTE_CONSTRAINED) &&
                                   (cmpxchg16_info->attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE) &&
                                   cmpxchg16_info->clobber_mask == cmpxchg16_fixed);
    MachineOpcodeInfo const atomic_load16_info = *machine_opcode_info(MACHINE_X64_ATOMIC_LOAD16);
    BUSTER_TEST(arguments, atomic_load16_info.operand_count == 4 &&
                               (atomic_load16_info.attributes & MACHINE_OPCODE_ATTRIBUTE_CONSTRAINED) &&
                               (atomic_load16_info.attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE) &&
                               atomic_load16_info.clobber_mask == cmpxchg16_fixed &&
                               atomic_load16_info.memory_effect == MACHINE_MEMORY_EFFECT_ATOMIC);
    MachineOpcodeInfo const atomic_rmw16_info = *machine_opcode_info(MACHINE_X64_ATOMIC_RMW16);
    u64 atomic_rmw16_fixed = cmpxchg16_fixed | (1ull << MACHINE_X64_R8) | (1ull << MACHINE_X64_R9);
    BUSTER_TEST(arguments, atomic_rmw16_info.operand_count == 4 &&
                               (atomic_rmw16_info.attributes & MACHINE_OPCODE_ATTRIBUTE_CONSTRAINED) &&
                               (atomic_rmw16_info.attributes & MACHINE_OPCODE_ATTRIBUTE_FLAGS_DEFINE) &&
                               atomic_rmw16_info.clobber_mask == atomic_rmw16_fixed &&
                               atomic_rmw16_info.memory_effect == MACHINE_MEMORY_EFFECT_ATOMIC);
    BUSTER_TEST(arguments, machine_opcode_info(MACHINE_OPCODE_COUNT) == 0);

    for (u16 opcode = MACHINE_OPCODE_SKELETON_NOP; opcode < MACHINE_OPCODE_COUNT; opcode += 1)
    {
        MachineOpcodeInfo const* info = machine_opcode_info(opcode);
        for (u32 slot = 0; slot < info->operand_count; slot += 1)
        {
            u32 shape = info->operand_info[slot] >> MACHINE_OPERAND_SHAPE_SHIFT;
            BUSTER_TEST(arguments, shape > MACHINE_OPERAND_SHAPE_NONE && shape < MACHINE_OPERAND_SHAPE_COUNT);
        }
    }

    // A metadata-only CMPXCHG16B clobber must preserve RBX in every
    // placement mode, even though this fixture has no virtual value bound to
    // RBX. Its address is constrained to the ABI scratch (RSI on SysV and
    // R11 on Win64), and the encoder must retain the old value from RAX:RDX
    // in the result slot after the instruction.
    MachineFunction cmpxchg16_function = machine_test_build_cmpxchg16_function(arguments->arena);
    BUSTER_TEST(arguments, machine_verify_function(&cmpxchg16_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement cmpxchg16_mir = machine_stack_placement_build(arguments->arena, &cmpxchg16_function);
    MachineStackPlacement cmpxchg16_fast = machine_fast_placement_build(arguments->arena, &cmpxchg16_function);
    MachineStackPlacement cmpxchg16_quality = machine_quality_placement_build(arguments->arena, &cmpxchg16_function);
    u64 rbx_mask = 1ull << MACHINE_X64_RBX;
    BUSTER_TEST(arguments, cmpxchg16_mir.valid && cmpxchg16_fast.valid && cmpxchg16_quality.valid);
    BUSTER_TEST(arguments, (cmpxchg16_mir.callee_saved_mask & rbx_mask) && (cmpxchg16_fast.callee_saved_mask & rbx_mask) &&
                                   (cmpxchg16_quality.callee_saved_mask & rbx_mask));
    BUSTER_TEST(arguments, (cmpxchg16_mir.frame_size + 8 * ((cmpxchg16_mir.callee_saved_mask >> MACHINE_X64_RBX) & 1u)) % 16 == 0);
    BUSTER_TEST(arguments, (cmpxchg16_fast.frame_size + 8 * ((cmpxchg16_fast.callee_saved_mask >> MACHINE_X64_RBX) & 1u)) % 16 == 0);
    BUSTER_TEST(arguments, (cmpxchg16_quality.frame_size + 8 * ((cmpxchg16_quality.callee_saved_mask >> MACHINE_X64_RBX) & 1u)) % 16 == 0);
    // MIR_STACK must put every home below the callee-saved save area.  The
    // CMPXCHG16B fixture has no virtual registers, so check its selector
    // stack slots directly: slot zero must not alias [RBP-8], where the
    // generated prologue saves RBX.
    u32 cmpxchg16_push_area = 8;
    BUSTER_TEST(arguments, cmpxchg16_mir.stack_slot_offsets[0] > cmpxchg16_push_area &&
                               cmpxchg16_mir.stack_slot_offsets[1] > cmpxchg16_push_area &&
                               cmpxchg16_mir.stack_slot_offsets[2] > cmpxchg16_push_area);
    u32 cmpxchg16_row = 1;
    BUSTER_TEST(arguments, cmpxchg16_mir.operand_registers[cmpxchg16_row * 4 + 3] == MACHINE_X64_RSI &&
                                   cmpxchg16_fast.operand_registers[cmpxchg16_row * 4 + 3] == MACHINE_X64_RSI &&
                                   cmpxchg16_quality.operand_registers[cmpxchg16_row * 4 + 3] == MACHINE_X64_RSI);
    MachineFunction windows_cmpxchg16_function = machine_test_build_cmpxchg16_function(arguments->arena);
    windows_cmpxchg16_function.target = machine_target_x86_64_windows();
    MachineStackPlacement windows_cmpxchg16_placement = machine_stack_placement_build(arguments->arena, &windows_cmpxchg16_function);
    BUSTER_TEST(arguments, windows_cmpxchg16_placement.valid &&
                               windows_cmpxchg16_placement.operand_registers[cmpxchg16_row * 4 + 3] == MACHINE_X64_R11);
    MachineFunction windows_store16_function = machine_test_build_cmpxchg16_function(arguments->arena);
    windows_store16_function.target = machine_target_x86_64_windows();
    windows_store16_function.instructions[cmpxchg16_row].opcode = MACHINE_X64_ATOMIC_STORE16;
    windows_store16_function.instructions[cmpxchg16_row].payload = 16;
    MachineStackPlacement windows_store16_placement = machine_stack_placement_build(arguments->arena, &windows_store16_function);
    BUSTER_TEST(arguments, windows_store16_placement.valid &&
                               windows_store16_placement.operand_registers[cmpxchg16_row * 4 + 3] == MACHINE_X64_R11);
    MachineFunction windows_load16_function = machine_test_build_cmpxchg16_function(arguments->arena);
    windows_load16_function.target = machine_target_x86_64_windows();
    windows_load16_function.instructions[cmpxchg16_row].opcode = MACHINE_X64_ATOMIC_LOAD16;
    windows_load16_function.instructions[cmpxchg16_row].payload = 16;
    windows_load16_function.instructions[cmpxchg16_row].operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, 0);
    windows_load16_function.instructions[cmpxchg16_row].operands[2] = machine_ref_make(MACHINE_REF_STACK_SLOT, 0);
    BUSTER_TEST(arguments, machine_verify_function(&windows_load16_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement windows_load16_placement = machine_stack_placement_build(arguments->arena, &windows_load16_function);
    MachineEncodeResult windows_load16_encoded = windows_load16_placement.valid
                                                     ? machine_encode_x86_64(arguments->arena, &windows_load16_function, &windows_load16_placement)
                                                     : (MachineEncodeResult){0};
    BUSTER_TEST(arguments, windows_load16_encoded.valid &&
                               windows_load16_placement.operand_registers[cmpxchg16_row * 4 + 3] == MACHINE_X64_R11);
    MachineFunction windows_rmw16_function = machine_test_build_cmpxchg16_function(arguments->arena);
    windows_rmw16_function.target = machine_target_x86_64_windows();
    windows_rmw16_function.instructions[cmpxchg16_row].opcode = MACHINE_X64_ATOMIC_RMW16;
    windows_rmw16_function.instructions[cmpxchg16_row].payload = 16u | ((u32)IR_ATOMIC_EXCHANGE << 8);
    windows_rmw16_function.instructions[cmpxchg16_row].operands[2] = machine_ref_make(MACHINE_REF_STACK_SLOT, 1);
    BUSTER_TEST(arguments, machine_verify_function(&windows_rmw16_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement windows_rmw16_placement = machine_stack_placement_build(arguments->arena, &windows_rmw16_function);
    MachineEncodeResult windows_rmw16_encoded = windows_rmw16_placement.valid
                                                     ? machine_encode_x86_64(arguments->arena, &windows_rmw16_function, &windows_rmw16_placement)
                                                     : (MachineEncodeResult){0};
    BUSTER_TEST(arguments, windows_rmw16_encoded.valid &&
                               windows_rmw16_placement.operand_registers[cmpxchg16_row * 4 + 3] == MACHINE_X64_R11);
    for (u32 atomic_operation = 0; atomic_operation < IR_ATOMIC_OPERATION_COUNT; atomic_operation += 1)
    {
        MachineFunction rmw16_function = machine_test_build_cmpxchg16_function(arguments->arena);
        rmw16_function.instructions[cmpxchg16_row].opcode = MACHINE_X64_ATOMIC_RMW16;
        rmw16_function.instructions[cmpxchg16_row].payload = 16u | (atomic_operation << 8);
        rmw16_function.instructions[cmpxchg16_row].operands[2] = machine_ref_make(MACHINE_REF_STACK_SLOT, 1);
        MachineStackPlacement rmw16_placement = machine_fast_placement_build(arguments->arena, &rmw16_function);
        MachineEncodeResult rmw16_encoded = rmw16_placement.valid
                                                 ? machine_encode_x86_64(arguments->arena, &rmw16_function, &rmw16_placement)
                                                 : (MachineEncodeResult){0};
        BUSTER_TEST(arguments, machine_verify_function(&rmw16_function).error == MACHINE_VERIFY_NONE && rmw16_encoded.valid);
    }
    MachineFunction short_store16_function = machine_test_build_cmpxchg16_function(arguments->arena);
    short_store16_function.instructions[cmpxchg16_row].opcode = MACHINE_X64_ATOMIC_STORE16;
    short_store16_function.instructions[cmpxchg16_row].payload = 9;
    MachineStackPlacement short_store16_placement = machine_fast_placement_build(arguments->arena, &short_store16_function);
    MachineEncodeResult short_store16_encoded = short_store16_placement.valid
                                                    ? machine_encode_x86_64(arguments->arena, &short_store16_function, &short_store16_placement)
                                                    : (MachineEncodeResult){0};
    BUSTER_TEST(arguments, short_store16_encoded.valid);
    MachineEncodeResult cmpxchg16_encoded = machine_encode_x86_64(arguments->arena, &cmpxchg16_function, &cmpxchg16_fast);
    bool saw_cmpxchg16 = false;
    bool saw_result_store = false;
    for (u32 byte = 0; cmpxchg16_encoded.valid && byte + 5 <= cmpxchg16_encoded.byte_count; byte += 1)
    {
        if (cmpxchg16_encoded.bytes[byte] == 0xf0 && cmpxchg16_encoded.bytes[byte + 1] == 0x48 &&
            cmpxchg16_encoded.bytes[byte + 2] == 0x0f && cmpxchg16_encoded.bytes[byte + 3] == 0xc7 && cmpxchg16_encoded.bytes[byte + 4] == 0x0e)
        {
            saw_cmpxchg16 = true;
        }
        if (saw_cmpxchg16 && byte + 3 <= cmpxchg16_encoded.byte_count && cmpxchg16_encoded.bytes[byte] == 0x48 &&
            cmpxchg16_encoded.bytes[byte + 1] == 0x89 && cmpxchg16_encoded.bytes[byte + 2] == 0x85)
        {
            saw_result_store = true;
        }
    }
    BUSTER_TEST(arguments, cmpxchg16_encoded.valid && saw_cmpxchg16 && saw_result_store);
    // Recipe IDs are a packed, target-local policy namespace.  Keep this
    // contract independent from exact encoding, selection, and scheduling
    // tables, and audit every current opcode so a newly added row cannot
    // silently inherit NONE.
    MachineEmitRecipeId sample_recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 37;
    BUSTER_TEST(arguments, machine_emit_recipe_is_valid(sample_recipe));
    BUSTER_TEST(arguments, machine_emit_recipe_category(sample_recipe) == MACHINE_EMIT_RECIPE_CATEGORY_FAMILY);
    BUSTER_TEST(arguments, machine_emit_recipe_index(sample_recipe) == 37);
    BUSTER_TEST(arguments, machine_emit_recipe_category(MACHINE_EMIT_RECIPE_INVALID) == MACHINE_EMIT_RECIPE_CATEGORY_COUNT);
    BUSTER_TEST(arguments, !machine_emit_recipe_is_valid(MACHINE_EMIT_RECIPE_INVALID));
    BUSTER_TEST(arguments, SELECTION_PATTERN_ID_INVALID == (SelectionPatternId)UINT16_MAX);
    BUSTER_TEST(arguments, SCHEDULING_CLASS_ID_INVALID == (SchedulingClassId)UINT16_MAX);

    u32 recipe_counts[MACHINE_EMIT_RECIPE_CATEGORY_COUNT] = {0};
    bool recipe_indices_in_range = true;
    for (u16 opcode = 0; opcode < MACHINE_OPCODE_COUNT; opcode += 1)
    {
        MachineEmitRecipeId recipe = machine_opcode_emit_recipe(opcode);
        MachineEmitRecipeCategory category = machine_emit_recipe_category(recipe);
        MachineOpcodeInfo const* info = machine_opcode_info(opcode);
        recipe_indices_in_range &= info && machine_emit_recipe_is_valid(recipe);
        if (category < MACHINE_EMIT_RECIPE_CATEGORY_COUNT)
        {
            recipe_counts[category] += 1;
        }
    }
    BUSTER_TEST(arguments, recipe_indices_in_range);
    BUSTER_TEST(arguments, recipe_counts[MACHINE_EMIT_RECIPE_CATEGORY_NONE] == 4);
    BUSTER_TEST(arguments, recipe_counts[MACHINE_EMIT_RECIPE_CATEGORY_DIRECT] == 103);
    BUSTER_TEST(arguments, recipe_counts[MACHINE_EMIT_RECIPE_CATEGORY_FAMILY] == 66);
    BUSTER_TEST(arguments, recipe_counts[MACHINE_EMIT_RECIPE_CATEGORY_EXPANSION] == 133);
    BUSTER_TEST(arguments, machine_opcode_emit_recipe(MACHINE_OPCODE_COUNT) == MACHINE_EMIT_RECIPE_INVALID);

    // Equal recipe indices in different categories are distinct identities.
    // The move family also includes memory reads: a common mnemonic cannot
    // supply the effects already consumed by scheduling and placement.
    MachineEmitRecipeId register_move = machine_opcode_emit_recipe(MACHINE_X64_MOV_RR);
    MachineEmitRecipeId immediate_move = machine_opcode_emit_recipe(MACHINE_X64_MOV_RI);
    BUSTER_TEST(arguments, machine_emit_recipe_index(register_move) == machine_emit_recipe_index(immediate_move));
    BUSTER_TEST(arguments, register_move != immediate_move);
    BUSTER_TEST(arguments, machine_emit_recipe_category(register_move) == MACHINE_EMIT_RECIPE_CATEGORY_DIRECT);
    BUSTER_TEST(arguments, machine_emit_recipe_category(immediate_move) == MACHINE_EMIT_RECIPE_CATEGORY_FAMILY);
    BUSTER_TEST(arguments, machine_opcode_memory_effect(machine_opcode_info(MACHINE_X64_MOV_RR)) == MACHINE_MEMORY_EFFECT_NONE);
    BUSTER_TEST(arguments, machine_opcode_memory_effect(machine_opcode_info(MACHINE_X64_MOV_RI)) == MACHINE_MEMORY_EFFECT_NONE);
    BUSTER_TEST(arguments, machine_opcode_memory_effect(machine_opcode_info(MACHINE_X64_LOAD_FRAME)) == MACHINE_MEMORY_EFFECT_READ);
    BUSTER_TEST(arguments, (machine_opcode_row_table()[MACHINE_X64_LOAD_FRAME].schedule_flags & MACHINE_SCHEDULE_UNIT_MEMORY) != 0);
    BUSTER_TEST(arguments, (machine_opcode_row_table()[MACHINE_X64_MOV_RR].schedule_flags & MACHINE_SCHEDULE_UNIT_MEMORY) == 0);
    BUSTER_TEST(arguments, machine_x86_64_emit_registry_entry(machine_x86_64_emit_registry_count()) == 0);

    u32 x64_counts[MACHINE_EMIT_RECIPE_CATEGORY_COUNT] = {0};
    for (u16 opcode = MACHINE_X64_MOV_RI; opcode <= MACHINE_X64_ATOMIC_RMW16; opcode += 1)
    {
        x64_counts[machine_emit_recipe_category(machine_opcode_emit_recipe(opcode))] += 1;
    }
    BUSTER_TEST(arguments, x64_counts[MACHINE_EMIT_RECIPE_CATEGORY_DIRECT] == 47);
    BUSTER_TEST(arguments, x64_counts[MACHINE_EMIT_RECIPE_CATEGORY_FAMILY] == 50);
    BUSTER_TEST(arguments, x64_counts[MACHINE_EMIT_RECIPE_CATEGORY_EXPANSION] == 32);

    // The x86-64 producer registry is the Phase-0 census used to keep the
    // encoder switch and recipe projection from drifting independently.  It
    // is indexed by the contiguous opcode span, while rows remain grouped by
    // recipe category in the source registry for reviewability.
    u32 registry_count = machine_x86_64_emit_registry_count();
    BUSTER_TEST(arguments, registry_count == MACHINE_X86_64_EMIT_REGISTRY_COUNT);
    BUSTER_TEST(arguments, (u32)(MACHINE_X64_ATOMIC_RMW16 - MACHINE_X64_MOV_RI + 1) == registry_count);
    u32 registry_counts[MACHINE_EMIT_RECIPE_CATEGORY_COUNT] = {0};
    u32 registry_status_counts[MACHINE_X64_EMIT_PRODUCER_STATUS_COUNT] = {0};
    bool registry_entries_are_complete = true;
    bool registry_recipes_match = true;
    bool registry_statuses_are_valid = true;
    bool exact_rows_are_explicit = true;
    bool exact_rows_are_not_legacy = true;
    bool exact_rows_have_direct_indices = true;
    bool expansion_rows_are_policy = true;
    bool remaining_rows_are_not_legacy = true;
    for (u32 ordinal = 0; ordinal < registry_count; ordinal += 1)
    {
        MachineX64EmitRegistryEntry const* entry = machine_x86_64_emit_registry_entry(ordinal);
        MachineOpcode expected_opcode = (MachineOpcode)(MACHINE_X64_MOV_RI + ordinal);
        bool row_is_complete = entry && entry->opcode == expected_opcode && entry->producer_ordinal == ordinal;
        registry_entries_are_complete &= row_is_complete;
        if (row_is_complete)
        {
            MachineEmitRecipeCategory category = machine_emit_recipe_category(entry->recipe);
            MachineX64EmitProducerStatus status = (MachineX64EmitProducerStatus)entry->producer_status;
            bool status_is_valid = status < MACHINE_X64_EMIT_PRODUCER_STATUS_COUNT;
            // The direct cohort already migrated to exact-form recipes is
            // explicit here rather than inferred from the opcode span: the
            // x86 enum interleaves family and expansion rows between direct
            // rows.  Keeping the expected recipe index beside each cohort
            // catches a reordered row as well as a stale status token.
            // LOAD_INCOMING (direct index 42) uses an explicit machine-only
            // disp32 policy so its metadata projection preserves the legacy
            // spelling at every incoming-argument offset.
            bool expected_exact = false;
            bool expected_exact_sequence = false;
            MachineEmitRecipeCategory expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_NONE;
            u16 expected_exact_index = 0;
            if (entry->opcode == MACHINE_X64_MOV_RI || entry->opcode == MACHINE_X64_LEA_OFFSET || entry->opcode == MACHINE_X64_ADD64_IMM ||
                entry->opcode == MACHINE_X64_IMUL64_RRI || entry->opcode == MACHINE_X64_LOAD_FRAME ||
                (entry->opcode >= MACHINE_X64_STORE_FRAME8 && entry->opcode <= MACHINE_X64_STORE_FRAME64) ||
                (entry->opcode >= MACHINE_X64_LOAD_PTR8 && entry->opcode <= MACHINE_X64_LOAD_PTR64) ||
                (entry->opcode >= MACHINE_X64_STORE_PTR8 && entry->opcode <= MACHINE_X64_STORE_PTR64) ||
                entry->opcode == MACHINE_X64_LEA_FRAME)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_FAMILY;
                if (entry->opcode == MACHINE_X64_MOV_RI) expected_exact_index = 0;
                else if (entry->opcode == MACHINE_X64_LEA_OFFSET) expected_exact_index = 1;
                else if (entry->opcode == MACHINE_X64_ADD64_IMM) expected_exact_index = 2;
                else if (entry->opcode == MACHINE_X64_IMUL64_RRI) expected_exact_index = 3;
                else if (entry->opcode == MACHINE_X64_LOAD_FRAME) expected_exact_index = 4;
                else if (entry->opcode >= MACHINE_X64_STORE_FRAME8 && entry->opcode <= MACHINE_X64_STORE_FRAME64)
                    expected_exact_index = (u16)(5 + entry->opcode - MACHINE_X64_STORE_FRAME8);
                else if (entry->opcode >= MACHINE_X64_LOAD_PTR8 && entry->opcode <= MACHINE_X64_LOAD_PTR64)
                    expected_exact_index = (u16)(9 + entry->opcode - MACHINE_X64_LOAD_PTR8);
                else if (entry->opcode >= MACHINE_X64_STORE_PTR8 && entry->opcode <= MACHINE_X64_STORE_PTR64)
                    expected_exact_index = (u16)(13 + entry->opcode - MACHINE_X64_STORE_PTR8);
                else expected_exact_index = 17;
            }
            if (entry->opcode >= MACHINE_X64_MOV_RR && entry->opcode <= MACHINE_X64_NOT64)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = (u16)(entry->opcode - MACHINE_X64_MOV_RR);
            }
            else if (entry->opcode >= MACHINE_X64_BSF32 && entry->opcode <= MACHINE_X64_BSR64)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = (u16)(23 + (entry->opcode - MACHINE_X64_BSF32));
            }
            else if (entry->opcode >= MACHINE_X64_POPCNT32 && entry->opcode <= MACHINE_X64_POPCNT64)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = (u16)(27 + (entry->opcode - MACHINE_X64_POPCNT32));
            }
            else if (entry->opcode >= MACHINE_X64_CMP32 && entry->opcode <= MACHINE_X64_TEST_RR)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = (u16)(29 + (entry->opcode - MACHINE_X64_CMP32));
            }
            else if (entry->opcode == MACHINE_X64_JMP)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = 32;
            }
            else if (entry->opcode >= MACHINE_X64_SHL32 && entry->opcode <= MACHINE_X64_SHR64)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = (u16)(33 + (entry->opcode - MACHINE_X64_SHL32));
            }
            else if (entry->opcode == MACHINE_X64_LEA_SYMBOL)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = 39;
            }
            else if (entry->opcode >= MACHINE_X64_MOVQ_TO_XMM && entry->opcode <= MACHINE_X64_MOVQ_FROM_XMM)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = (u16)(40 + (entry->opcode - MACHINE_X64_MOVQ_TO_XMM));
            }
            else if (entry->opcode == MACHINE_X64_LOAD_INCOMING)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = 42;
            }
            else if (entry->opcode == MACHINE_X64_PUSH_REGISTER || entry->opcode == MACHINE_X64_ADD_RSP)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = entry->opcode == MACHINE_X64_PUSH_REGISTER ? 43 : 44;
            }
            else if (entry->opcode == MACHINE_X64_MFENCE || entry->opcode == MACHINE_X64_INT3)
            {
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_DIRECT;
                expected_exact_index = entry->opcode == MACHINE_X64_MFENCE ? 45 : 46;
            }
            else if (category == MACHINE_EMIT_RECIPE_CATEGORY_FAMILY)
            {
                u16 family_index = machine_emit_recipe_index(entry->recipe);
                expected_exact = true;
                expected_exact_category = MACHINE_EMIT_RECIPE_CATEGORY_FAMILY;
                expected_exact_index = family_index;
                expected_exact_sequence = (family_index >= 26 && family_index <= 31) || family_index == 35 ||
                                          (family_index >= 36 && family_index <= 45) || family_index == 47 || family_index == 48;
            }
            registry_statuses_are_valid &= status_is_valid;
            registry_recipes_match &= machine_emit_recipe_is_valid(entry->recipe);
            registry_recipes_match &= machine_opcode_emit_recipe((u16)entry->opcode) == entry->recipe;
            registry_recipes_match &= machine_x86_64_emit_registry_find(entry->opcode) == entry;
            bool status_is_exact = status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_FORM || status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_SEQUENCE;
            exact_rows_are_explicit &= expected_exact ? status_is_exact : !status_is_exact;
            if (expected_exact)
            {
                exact_rows_are_not_legacy &= status != MACHINE_X64_EMIT_PRODUCER_STATUS_LEGACY_RAW;
                exact_rows_have_direct_indices &= category == expected_exact_category && machine_emit_recipe_index(entry->recipe) == expected_exact_index;
                exact_rows_have_direct_indices &= expected_exact_sequence ? status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_SEQUENCE
                                                                           : status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_FORM;
            }
            if (category == MACHINE_EMIT_RECIPE_CATEGORY_EXPANSION)
            {
                expansion_rows_are_policy &= status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXPANSION_POLICY;
            }
            else if (category != MACHINE_EMIT_RECIPE_CATEGORY_EXPANSION)
            {
                remaining_rows_are_not_legacy &= status != MACHINE_X64_EMIT_PRODUCER_STATUS_LEGACY_RAW;
            }
            if (status_is_valid)
            {
                registry_status_counts[status] += 1;
            }
            if (category < MACHINE_EMIT_RECIPE_CATEGORY_COUNT)
            {
                registry_counts[category] += 1;
            }
        }
    }
    BUSTER_TEST(arguments, registry_entries_are_complete);
    BUSTER_TEST(arguments, registry_recipes_match);
    BUSTER_TEST(arguments, registry_statuses_are_valid);
    BUSTER_TEST(arguments, exact_rows_are_explicit);
    BUSTER_TEST(arguments, exact_rows_are_not_legacy);
    BUSTER_TEST(arguments, exact_rows_have_direct_indices);
    BUSTER_TEST(arguments, expansion_rows_are_policy);
    BUSTER_TEST(arguments, remaining_rows_are_not_legacy);
    BUSTER_TEST(arguments, registry_status_counts[MACHINE_X64_EMIT_PRODUCER_STATUS_LEGACY_RAW] == MACHINE_X86_64_EMIT_REGISTRY_LEGACY_RAW_COUNT);
    BUSTER_TEST(arguments, registry_status_counts[MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_FORM] == MACHINE_X86_64_EMIT_REGISTRY_EXACT_FORM_COUNT);
    BUSTER_TEST(arguments, registry_status_counts[MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_SEQUENCE] == MACHINE_X86_64_EMIT_REGISTRY_EXACT_SEQUENCE_COUNT);
    BUSTER_TEST(arguments, registry_status_counts[MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_FORM] +
                             registry_status_counts[MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_SEQUENCE] == MACHINE_X86_64_EMIT_REGISTRY_EXACT_COUNT);
    BUSTER_TEST(arguments, registry_status_counts[MACHINE_X64_EMIT_PRODUCER_STATUS_EXPANSION_POLICY] == MACHINE_X86_64_EMIT_REGISTRY_EXPANSION_POLICY_COUNT);
    BUSTER_TEST(arguments, registry_counts[MACHINE_EMIT_RECIPE_CATEGORY_DIRECT] == MACHINE_X86_64_EMIT_REGISTRY_DIRECT_COUNT);
    BUSTER_TEST(arguments, registry_counts[MACHINE_EMIT_RECIPE_CATEGORY_FAMILY] == MACHINE_X86_64_EMIT_REGISTRY_FAMILY_COUNT);
    BUSTER_TEST(arguments, registry_counts[MACHINE_EMIT_RECIPE_CATEGORY_EXPANSION] == MACHINE_X86_64_EMIT_REGISTRY_EXPANSION_COUNT);
    BUSTER_TEST(arguments, machine_x86_64_emit_registry_entry(registry_count) == 0);
    BUSTER_TEST(arguments, machine_x86_64_emit_registry_find(MACHINE_X64_MOV_RI - 1) == 0);
    BUSTER_TEST(arguments, machine_x86_64_emit_registry_find(MACHINE_X64_ATOMIC_RMW16 + 1) == 0);

    // Serial exact prewarm publishes one immutable row map for all workers.
    // Audit every row after publication: exact forms and sequences must have
    // every variant token valid, while expansion-policy rows must remain
    // deliberately non-exact so the machine layer cannot accidentally route
    // them through a stale one-form plan.
    MachineX64ExactMapAudit exact_map = machine_x86_64_exact_map_audit();
    BUSTER_TEST(arguments, exact_map.valid);
    BUSTER_TEST(arguments, exact_map.registry_rows == registry_count);
    BUSTER_TEST(arguments, exact_map.exact_rows == MACHINE_X86_64_EMIT_REGISTRY_EXACT_COUNT);
    BUSTER_TEST(arguments, exact_map.exact_plan_valid_rows == exact_map.exact_rows);
    BUSTER_TEST(arguments, exact_map.sequence_rows == MACHINE_X86_64_EMIT_REGISTRY_EXACT_SEQUENCE_COUNT);
    BUSTER_TEST(arguments, exact_map.sequence_variant_valid_rows == exact_map.sequence_rows);
    BUSTER_TEST(arguments, exact_map.expansion_rows == MACHINE_X86_64_EMIT_REGISTRY_EXPANSION_COUNT);
    BUSTER_TEST(arguments, exact_map.expansion_nonexact_rows == exact_map.expansion_rows);
    BUSTER_TEST(arguments, exact_map.dense_encoding_tables == 64);
    BUSTER_TEST(arguments, exact_map.immediate_patch_tables == 9);
    BUSTER_TEST(arguments, exact_map.memory_base_tables == 8);
    BUSTER_TEST(arguments, exact_map.displacement_patch_tables == 8);
    BUSTER_TEST(arguments, exact_map.variable_memory_encoding_tables == 9);
    // Every fixed-shape template row prewarm allots must be one the
    // metadata authority accepted; a refused row would silently keep the
    // slower metadata lane for its shape.
    BUSTER_TEST_RAW(arguments, exact_map.fixed_template_rows == 1466,
                    string_format(arguments->arena, S8("exact_map.fixed_template_rows == 1466 (rows: {u32})"), exact_map.fixed_template_rows));
    BUSTER_TEST_RAW(arguments, exact_map.fixed_template_invalid_rows == 0,
                    string_format(arguments->arena, S8("exact_map.fixed_template_invalid_rows == 0 (invalid: {u32})"), exact_map.fixed_template_invalid_rows));
    BUSTER_TEST_FIXTURE(arguments, machine_test_prepared_movabs);
    BUSTER_TEST_FIXTURE(arguments, machine_test_prepared_frame_chunk);
    MachineX64MetadataShapeCacheAudit metadata_shape_cache = machine_x86_64_metadata_shape_cache_audit();
    BUSTER_TEST(arguments, metadata_shape_cache.valid);
    // Atomic NAND adds the 8-, 16-, 32- and 64-bit NOT register shapes.
    BUSTER_TEST(arguments, metadata_shape_cache.prepared_rows == 267);
    BUSTER_TEST(arguments, metadata_shape_cache.invalid_rows == 0);

    // Canonical metadata authorities and neutral patch helpers are separate
    // records.  The source audit below validates their shape and ownership;
    // the strict zero-manual-producer assertion is enabled once the remaining
    // codegen/assembly migration lands.
    u32 authority_count = machine_x86_64_canonical_authority_site_count();
    u32 patch_count = machine_x86_64_neutral_patch_site_count();
    BUSTER_TEST(arguments, authority_count == MACHINE_X86_64_CANONICAL_AUTHORITY_SITE_COUNT);
    BUSTER_TEST(arguments, patch_count == MACHINE_X86_64_NEUTRAL_PATCH_SITE_COUNT);
    u32 authority_kind_counts[MACHINE_X64_CANONICAL_AUTHORITY_KIND_COUNT] = {0};
    u32 patch_class_counts[MACHINE_X64_NEUTRAL_PATCH_CLASS_COUNT] = {0};
    bool authority_records_are_well_formed = true;
    bool authority_records_are_unique = true;
    bool patch_records_are_well_formed = true;
    bool patch_records_are_unique = true;
    for (u32 site_index = 0; site_index < authority_count; site_index += 1)
    {
        MachineX64CanonicalAuthoritySite const* site = machine_x86_64_canonical_authority_site(site_index);
        bool site_is_well_formed = site && site->authority_kind < MACHINE_X64_CANONICAL_AUTHORITY_KIND_COUNT && site->source_file.length != 0 &&
                                   site->owner_symbol.length != 0 && string_ends_with_sequence(site->source_file, S8(".c"));
        authority_records_are_well_formed &= site_is_well_formed;
        if (site_is_well_formed)
        {
            authority_kind_counts[site->authority_kind] += 1;
            for (u32 previous_index = 0; previous_index < site_index; previous_index += 1)
            {
                MachineX64CanonicalAuthoritySite const* previous = machine_x86_64_canonical_authority_site(previous_index);
                authority_records_are_unique &= !previous || !string_equal(site->source_file, previous->source_file) ||
                                               !string_equal(site->owner_symbol, previous->owner_symbol);
            }
        }
    }
    for (u32 site_index = 0; site_index < patch_count; site_index += 1)
    {
        MachineX64NeutralPatchSite const* site = machine_x86_64_neutral_patch_site(site_index);
        bool site_is_well_formed = site && site->patch_class < MACHINE_X64_NEUTRAL_PATCH_CLASS_COUNT && site->source_file.length != 0 &&
                                   site->owner_symbol.length != 0 && string_ends_with_sequence(site->source_file, S8(".c"));
        patch_records_are_well_formed &= site_is_well_formed;
        if (site_is_well_formed)
        {
            patch_class_counts[site->patch_class] += 1;
            for (u32 previous_index = 0; previous_index < site_index; previous_index += 1)
            {
                MachineX64NeutralPatchSite const* previous = machine_x86_64_neutral_patch_site(previous_index);
                patch_records_are_unique &= !previous || !string_equal(site->source_file, previous->source_file) ||
                                            !string_equal(site->owner_symbol, previous->owner_symbol);
            }
        }
    }
    BUSTER_TEST(arguments, authority_records_are_well_formed && authority_records_are_unique);
    BUSTER_TEST(arguments, patch_records_are_well_formed && patch_records_are_unique);
    BUSTER_TEST(arguments, authority_kind_counts[MACHINE_X64_CANONICAL_AUTHORITY_METADATA_CHECKED] != 0);
    BUSTER_TEST(arguments, authority_kind_counts[MACHINE_X64_CANONICAL_AUTHORITY_METADATA_EXACT] != 0);
    BUSTER_TEST(arguments, patch_class_counts[MACHINE_X64_NEUTRAL_PATCH_RELOCATION] != 0);
    BUSTER_TEST(arguments, patch_class_counts[MACHINE_X64_NEUTRAL_PATCH_DISPLACEMENT] != 0);
    BUSTER_TEST(arguments, patch_class_counts[MACHINE_X64_NEUTRAL_PATCH_DATA] != 0);
    BUSTER_TEST(arguments, patch_class_counts[MACHINE_X64_NEUTRAL_PATCH_TARGET_PAYLOAD] != 0);
    // TLS is now a metadata-owned ABI recipe, not a neutral literal escape.
    BUSTER_TEST(arguments, patch_class_counts[MACHINE_X64_NEUTRAL_PATCH_FIXED_SEQUENCE] == 0);
    MachineX64SourceAudit source_audit = machine_test_x86_source_authority_audit(arguments->arena);
    // Packaged runtimes (notably Android) do not carry the repository source
    // tree, so the scanner cannot discover its five audit files there.  Keep
    // the authority gate strict whenever all sources are readable, while
    // treating an unavailable source tree as an inapplicable audit rather
    // than a producer violation.
    bool source_audit_available = source_audit.files_readable;
    BUSTER_TEST(arguments, !source_audit_available || source_audit.owners_found);
    BUSTER_TEST(arguments, !source_audit_available || source_audit.neutral_patch_count == patch_count);
    // This scanner checks named consumers and byte-writer calls, not every
    // literal array/opcode rewrite. The complete path inventory and remaining
    // migration boundaries live in docs/x86-64-encoding-authority.md.
    BUSTER_TEST(arguments, !source_audit_available || source_audit.forbidden_count == 0);

    u32 a64_counts[MACHINE_EMIT_RECIPE_CATEGORY_COUNT] = {0};
    for (u16 opcode = MACHINE_A64_MOV_RI; opcode <= MACHINE_A64_LEA_SYMBOL; opcode += 1)
    {
        a64_counts[machine_emit_recipe_category(machine_opcode_emit_recipe(opcode))] += 1;
    }
    // Appended zero-count rows retain all older serialized opcode numbers.
    for (u16 opcode = MACHINE_A64_CLZ32; opcode <= MACHINE_A64_RBIT64; opcode += 1)
    {
        a64_counts[machine_emit_recipe_category(machine_opcode_emit_recipe(opcode))] += 1;
    }
    for (u16 opcode = MACHINE_A64_ATOMIC_LOAD_PAIR; opcode <= MACHINE_A64_ATOMIC_CAS_PAIR; opcode += 1)
    {
        a64_counts[machine_emit_recipe_category(machine_opcode_emit_recipe(opcode))] += 1;
    }
    BUSTER_TEST(arguments, a64_counts[MACHINE_EMIT_RECIPE_CATEGORY_DIRECT] == 56);
    BUSTER_TEST(arguments, a64_counts[MACHINE_EMIT_RECIPE_CATEGORY_FAMILY] == 3);
    BUSTER_TEST(arguments, a64_counts[MACHINE_EMIT_RECIPE_CATEGORY_EXPANSION] == 23);

    MachineFunction function = machine_test_build_function(arguments->arena);
    BUSTER_TEST(arguments, function.instruction_count == 4);
    BUSTER_TEST(arguments, function.virtual_register_count == 2);
    BUSTER_TEST(arguments, function.block_count == 2);
    BUSTER_TEST(arguments, function.blocks[0].first_instruction == 0 && function.blocks[0].instruction_count == 2);
    BUSTER_TEST(arguments, function.blocks[1].first_instruction == 2 && function.blocks[1].instruction_count == 2);
    BUSTER_TEST(arguments, function.instructions[0].opcode == MACHINE_OPCODE_SKELETON_COPY);
    BUSTER_TEST(arguments, machine_verify_function(&function).error == MACHINE_VERIFY_NONE);

    // A one-chunk stream is already contiguous in the builder arena. Finish
    // must publish its live payload directly rather than copying it, while
    // retaining the ordinary row values and block layout.
    MachineFunctionBuilder alias_builder = machine_function_builder_begin(arguments->arena);
    u32 alias_parameter = machine_builder_virtual_register(&alias_builder, (MachineVirtualRegister){
                                                               .definition_point = MACHINE_POINT_INVALID,
                                                               .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                           });
    u32 alias_parameter_offset =
        machine_builder_block_parameter(&alias_builder, (MachineBlockParameter){.virtual_register = alias_parameter});
    machine_builder_block_begin(&alias_builder);
    machine_builder_instruction(&alias_builder, (MachineInstruction){.opcode = MACHINE_OPCODE_SKELETON_RETURN});
    machine_builder_block_end(&alias_builder, (MachineBlock){.parameter_offset = alias_parameter_offset, .parameter_count = 1});
    MachineBuilderChunk* alias_instruction_chunk = alias_builder.instructions.first;
    MachineBuilderChunk* alias_virtual_register_chunk = alias_builder.virtual_registers.first;
    MachineBuilderChunk* alias_block_chunk = alias_builder.blocks.first;
    MachineFunction alias_function = machine_function_builder_finish(arguments->arena, &alias_builder);
    BUSTER_TEST(arguments, alias_function.instructions == (MachineInstruction*)(alias_instruction_chunk + 1));
    BUSTER_TEST(arguments, alias_function.virtual_registers == (MachineVirtualRegister*)(alias_virtual_register_chunk + 1));
    BUSTER_TEST(arguments, alias_function.blocks == (MachineBlock*)(alias_block_chunk + 1));
    BUSTER_TEST(arguments, alias_function.instruction_count == 1 && alias_function.instructions[0].opcode == MACHINE_OPCODE_SKELETON_RETURN);
    BUSTER_TEST(arguments, machine_verify_function(&alias_function).error == MACHINE_VERIFY_NONE);

    // The chunked builder must survive chunk boundaries: enough rows to
    // spill across several 16 KiB chunks, flattened back in exact order.
    u32 large_count = 3000;
    MachineFunctionBuilder large_builder = machine_function_builder_begin(arguments->arena);
    machine_builder_block_begin(&large_builder);
    for (u32 index = 0; index < large_count - 1; index += 1)
    {
        machine_builder_instruction(&large_builder, (MachineInstruction){
                                                        .payload = index,
                                                        .opcode = MACHINE_OPCODE_SKELETON_NOP,
                                                    });
    }
    machine_builder_instruction(&large_builder, (MachineInstruction){
                                                    .payload = large_count - 1,
                                                    .opcode = MACHINE_OPCODE_SKELETON_RETURN,
                                                });
    machine_builder_block_end(&large_builder, (MachineBlock){0});
    MachineBuilderChunk* large_instruction_chunk = large_builder.instructions.first;
    MachineFunction large = machine_function_builder_finish(arguments->arena, &large_builder);
    BUSTER_TEST(arguments, large.instruction_count == large_count);
    BUSTER_TEST(arguments, large.instructions != (MachineInstruction*)(large_instruction_chunk + 1));
    bool payloads_ordered = true;
    for (u32 index = 0; index < large.instruction_count; index += 1)
    {
        payloads_ordered &= large.instructions[index].payload == index;
    }
    BUSTER_TEST(arguments, payloads_ordered);
    BUSTER_TEST(arguments, machine_verify_function(&large).error == MACHINE_VERIFY_NONE);

    // A caller may deliberately finish into a different arena and release
    // the builder arena immediately. That path must copy even a one-chunk
    // stream so the returned function owns only the finish arena.
    Arena* cross_builder_arena = arena_create((ArenaCreation){0});
    Arena* cross_function_arena = arena_create((ArenaCreation){0});
    MachineFunctionBuilder cross_builder = machine_function_builder_begin(cross_builder_arena);
    machine_builder_block_begin(&cross_builder);
    machine_builder_instruction(&cross_builder, (MachineInstruction){.payload = 17, .opcode = MACHINE_OPCODE_SKELETON_RETURN});
    machine_builder_block_end(&cross_builder, (MachineBlock){0});
    MachineBuilderChunk* cross_instruction_chunk = cross_builder.instructions.first;
    MachineFunction cross_function = machine_function_builder_finish(cross_function_arena, &cross_builder);
    MachineInstruction* cross_payload = (MachineInstruction*)(cross_instruction_chunk + 1);
    BUSTER_TEST(arguments, cross_function.instructions != cross_payload && cross_function.instructions[0].payload == 17);
    BUSTER_TEST(arguments, arena_destroy(cross_builder_arena, 1));
    BUSTER_TEST(arguments, cross_function.instructions[0].opcode == MACHINE_OPCODE_SKELETON_RETURN && cross_function.instructions[0].payload == 17);
    BUSTER_TEST(arguments, arena_destroy(cross_function_arena, 1));

    // Verifier rejections. Each case mutates a fresh valid function so a
    // single detected defect cannot mask another.
    MachineFunction bad_opcode = machine_test_build_function(arguments->arena);
    bad_opcode.instructions[0].opcode = MACHINE_OPCODE_INVALID;
    BUSTER_TEST(arguments, machine_verify_function(&bad_opcode).error == MACHINE_VERIFY_OPCODE);
    MachineFunction bad_opcode_range = machine_test_build_function(arguments->arena);
    bad_opcode_range.instructions[0].opcode = MACHINE_OPCODE_COUNT;
    BUSTER_TEST(arguments, machine_verify_function(&bad_opcode_range).error == MACHINE_VERIFY_OPCODE);

    u8 inline_bytes[] = {0x90};
    u32 inline_slot_sizes[] = {16};
    MachineInlineAssemblyOperand inline_operand = {
        .stack_slot = 0,
        .physical_register = MACHINE_X64_RAX,
        .byte_size = 8,
        .constraint_class = IR_INLINE_ASSEMBLY_CONSTRAINT_R,
        .flags = MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT,
    };
    MachineInlineAssembly inline_descriptor = {
        .source = S8("nop"),
        .bytes = {.pointer = inline_bytes, .length = sizeof(inline_bytes)},
        .clobber_mask = 1ull << MACHINE_X64_RAX,
        .operand_count = 1,
    };
    MachineInstruction inline_instructions[] = {
        {.opcode = MACHINE_X64_INLINE_ASSEMBLY},
        {.opcode = MACHINE_OPCODE_SKELETON_RETURN},
    };
    MachineBlock inline_blocks[] = {{.instruction_count = BUSTER_ARRAY_LENGTH(inline_instructions)}};
    MachineFunction inline_function = {
        .instructions = inline_instructions,
        .blocks = inline_blocks,
        .stack_slot_sizes = inline_slot_sizes,
        .inline_assemblies = &inline_descriptor,
        .inline_assembly_operands = &inline_operand,
        .target = machine_target_x86_64(),
        .instruction_count = BUSTER_ARRAY_LENGTH(inline_instructions),
        .block_count = BUSTER_ARRAY_LENGTH(inline_blocks),
        .stack_slot_count = BUSTER_ARRAY_LENGTH(inline_slot_sizes),
        .inline_assembly_count = 1,
        .inline_assembly_operand_count = 1,
    };
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_NONE);
    inline_descriptor.clobber_mask = 0;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_descriptor.clobber_mask = 1ull << MACHINE_X64_RAX;
    MachineOpcodeRow inline_row = machine_instruction_opcode_row(&inline_function, inline_instructions);
    BUSTER_TEST(arguments, inline_row.clobber_mask == inline_descriptor.clobber_mask &&
                               (inline_row.flags & MACHINE_OPCODE_ROW_CLOBBERS) != 0 &&
                               (inline_row.flags & MACHINE_OPCODE_ROW_TERMINATOR) == 0 &&
                               (inline_row.flags & MACHINE_OPCODE_ROW_FLAGS_DEFINE) == 0 &&
                               inline_row.schedule_flags == MACHINE_SCHEDULE_UNIT_BARRIER);
    inline_descriptor.effects = MACHINE_INLINE_ASSEMBLY_EFFECT_MEMORY | MACHINE_INLINE_ASSEMBLY_EFFECT_FLAGS |
                                MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR;
    inline_row = machine_instruction_opcode_row(&inline_function, inline_instructions);
    BUSTER_TEST(arguments, (inline_row.flags & MACHINE_OPCODE_ROW_TERMINATOR) != 0 &&
                               (inline_row.flags & MACHINE_OPCODE_ROW_FLAGS_DEFINE) != 0 &&
                               inline_row.schedule_flags == (MACHINE_SCHEDULE_UNIT_BARRIER | MACHINE_SCHEDULE_UNIT_MEMORY));
    inline_descriptor.effects = 0;
    inline_descriptor.first_operand = 1;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_descriptor.first_operand = 0;
    inline_operand.flags |= MACHINE_INLINE_ASSEMBLY_OPERAND_EARLY_CLOBBER;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_operand.flags = MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_MEMORY;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_operand.flags = MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT;
    inline_operand.physical_register = MACHINE_X64_ZMM0;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_operand.physical_register = MACHINE_X64_RAX;
    inline_descriptor.effects = MACHINE_INLINE_ASSEMBLY_EFFECT_X87_POP;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_descriptor.effects = 0;
    inline_slot_sizes[0] = 4;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_slot_sizes[0] = 16;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_NONE);
    inline_function.target = machine_target_x86_64_windows();
    inline_operand.physical_register = MACHINE_X64_ZMM6;
    inline_operand.constraint_class = IR_INLINE_ASSEMBLY_CONSTRAINT_X;
    inline_operand.flags = MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_VECTOR;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_descriptor.preserved_vector_slot = 0;
    inline_descriptor.clobber_mask = 1ull << MACHINE_X64_ZMM6;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_NONE);
    inline_descriptor.clobber_mask |= 1ull << MACHINE_X64_ZMM15;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_slot_sizes[0] = 32;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_NONE);
    inline_descriptor.preserved_vector_slot = 1;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_descriptor.preserved_vector_slot = 0;
    inline_slot_sizes[0] = 16;
    inline_function.target = machine_target_x86_64();
    inline_operand.physical_register = MACHINE_X64_RAX;
    inline_descriptor.clobber_mask = 0;
    inline_operand.constraint_class = IR_INLINE_ASSEMBLY_CONSTRAINT_T;
    inline_operand.flags = MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_X87_TOP;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_NONE);
    inline_descriptor.effects = MACHINE_INLINE_ASSEMBLY_EFFECT_X87_POP;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_NONE);
    inline_operand.flags |= MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);
    inline_operand.flags = MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_X87_BELOW;
    inline_operand.constraint_class = IR_INLINE_ASSEMBLY_CONSTRAINT_U;
    inline_descriptor.effects = 0;
    BUSTER_TEST(arguments, machine_verify_function(&inline_function).error == MACHINE_VERIFY_PAYLOAD);

    {
        u8 goto_bytes[] = {0xe9, 0, 0, 0, 0};
        MachineInlineAssemblyRelocation goto_relocation = {
            .offset = 1,
            .block = 2,
            .continuation_block = 3,
            .target_index = 1,
            .kind = ASSEMBLY_RELOCATION_X86_PC32,
            .is_block = true,
            .is_control = true,
        };
        MachineInlineAssembly goto_descriptor = {
            .bytes = {.pointer = goto_bytes, .length = sizeof(goto_bytes)},
            .relocation_count = 1,
            .effects = MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR,
            .successor_count = 3,
            .declared_successor_count = 2,
            .fallthrough_block = 1,
        };
        MachineInstruction goto_rows[] = {
            {.opcode = MACHINE_X64_INLINE_ASSEMBLY},
            {.opcode = MACHINE_OPCODE_SKELETON_RETURN},
            {.opcode = MACHINE_OPCODE_SKELETON_RETURN},
            {.opcode = MACHINE_X64_JMP, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 2)}},
        };
        MachineBlock goto_blocks[] = {
            {.first_instruction = 0, .instruction_count = 1},
            {.first_instruction = 1, .instruction_count = 1},
            {.first_instruction = 2, .instruction_count = 1},
            {.first_instruction = 3, .instruction_count = 1},
        };
        MachineEdge goto_edges[] = {
            {.source_block = 0, .destination_block = 1},
            {.source_block = 0, .destination_block = 2},
            {.source_block = 0, .destination_block = 3},
            {.source_block = 3, .destination_block = 2},
            {.source_block = 0, .destination_block = 0},
        };
        MachineFunction goto_function = {
            .instructions = goto_rows,
            .instruction_count = BUSTER_ARRAY_LENGTH(goto_rows),
            .blocks = goto_blocks,
            .block_count = BUSTER_ARRAY_LENGTH(goto_blocks),
            .edges = goto_edges,
            .edge_count = 4,
            .inline_assemblies = &goto_descriptor,
            .inline_assembly_count = 1,
            .inline_assembly_relocations = &goto_relocation,
            .inline_assembly_relocation_count = 1,
            .target = machine_target_x86_64(),
        };
        BUSTER_TEST(arguments, machine_verify_function(&goto_function).error == MACHINE_VERIFY_NONE);
        goto_bytes[0] = 0xe8;
        goto_relocation.is_control = false;
        goto_relocation.continuation_block = UINT32_MAX;
        goto_descriptor.successor_count = goto_descriptor.declared_successor_count;
        goto_function.edge_count = 2;
        BUSTER_TEST(arguments, machine_verify_function(&goto_function).error == MACHINE_VERIFY_PAYLOAD);
        u8 xbegin_bytes[] = {0xc7, 0xf8, 0, 0, 0, 0};
        goto_descriptor.bytes = (ByteSlice)BUSTER_ARRAY_TO_SLICE(xbegin_bytes);
        goto_relocation.offset = 2;
        BUSTER_TEST(arguments, machine_verify_function(&goto_function).error == MACHINE_VERIFY_PAYLOAD);
        goto_bytes[0] = 0xe9;
        goto_descriptor.bytes = (ByteSlice)BUSTER_ARRAY_TO_SLICE(goto_bytes);
        goto_relocation.offset = 1;
        goto_relocation.is_control = true;
        goto_relocation.continuation_block = 3;
        goto_descriptor.successor_count = 3;
        goto_function.edge_count = 4;
        BUSTER_TEST(arguments, machine_verify_function(&goto_function).error == MACHINE_VERIFY_NONE);
        goto_function.edge_count = 2;
        BUSTER_TEST(arguments, machine_verify_function(&goto_function).error == MACHINE_VERIFY_EDGE_RANGE);
        goto_function.edge_count = 5;
        BUSTER_TEST(arguments, machine_verify_function(&goto_function).error == MACHINE_VERIFY_EDGE_RANGE);
        goto_function.edge_count = 4;
        goto_descriptor.successor_count = 0;
        BUSTER_TEST(arguments, machine_verify_function(&goto_function).error == MACHINE_VERIFY_PAYLOAD);
    }

    MachineFunction early_terminator = machine_test_build_function(arguments->arena);
    early_terminator.instructions[0].opcode = MACHINE_OPCODE_SKELETON_RETURN;
    early_terminator.instructions[0].operands[0] = MACHINE_REF_NONE_VALUE;
    early_terminator.instructions[0].operands[1] = MACHINE_REF_NONE_VALUE;
    BUSTER_TEST(arguments, machine_verify_function(&early_terminator).error == MACHINE_VERIFY_TERMINATOR);
    MachineFunction missing_terminator = machine_test_build_function(arguments->arena);
    missing_terminator.instructions[3].opcode = MACHINE_OPCODE_SKELETON_NOP;
    BUSTER_TEST(arguments, machine_verify_function(&missing_terminator).error == MACHINE_VERIFY_TERMINATOR);

    MachineFunction bad_reference = machine_test_build_function(arguments->arena);
    bad_reference.instructions[0].operands[1] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bad_reference.virtual_register_count);
    MachineVerifyResult reference_result = machine_verify_function(&bad_reference);
    BUSTER_TEST(arguments, reference_result.error == MACHINE_VERIFY_OPERAND_REFERENCE && reference_result.operand == 1);

    MachineFunction dirty_slot = machine_test_build_function(arguments->arena);
    dirty_slot.instructions[0].operands[2] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 0);
    BUSTER_TEST(arguments, machine_verify_function(&dirty_slot).error == MACHINE_VERIFY_OPERAND_SLOT);

    MachineFunction bad_range = machine_test_build_function(arguments->arena);
    bad_range.blocks[1].first_instruction = 3;
    BUSTER_TEST(arguments, machine_verify_function(&bad_range).error == MACHINE_VERIFY_BLOCK_RANGE);
    MachineFunction uncovered = machine_test_build_function(arguments->arena);
    uncovered.blocks[1].instruction_count = 1;
    BUSTER_TEST(arguments, machine_verify_function(&uncovered).error != MACHINE_VERIFY_NONE);

    MachineFunction bad_definition = machine_test_build_function(arguments->arena);
    bad_definition.virtual_registers[1].definition_point = machine_point_make(function.instruction_count, MACHINE_POINT_AFTER);
    BUSTER_TEST(arguments, machine_verify_function(&bad_definition).error == MACHINE_VERIFY_VIRTUAL_REGISTER_DEFINITION);

    MachineFunction missing_definition = machine_test_build_function(arguments->arena);
    missing_definition.instructions[0].operands[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX);
    BUSTER_TEST(arguments,
                machine_verify_function(&missing_definition).error == MACHINE_VERIFY_VIRTUAL_REGISTER_MISSING_DEFINITION);

    MachineFunction duplicate_definition = machine_test_build_function(arguments->arena);
    duplicate_definition.instructions[2] = (MachineInstruction){
        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1),
                     machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)},
        .opcode = MACHINE_OPCODE_SKELETON_COPY,
    };
    BUSTER_TEST(arguments,
                machine_verify_function(&duplicate_definition).error == MACHINE_VERIFY_VIRTUAL_REGISTER_DUPLICATE_DEFINITION);

    MachineFunction explicit_mutable = machine_test_build_function(arguments->arena);
    explicit_mutable.instructions[2] = duplicate_definition.instructions[2];
    explicit_mutable.virtual_registers[1].flags |= MACHINE_VIRTUAL_REGISTER_FLAG_MUTABLE;
    MachineVerifyResult mutable_result = machine_verify_function(&explicit_mutable);
    BUSTER_TEST(arguments, mutable_result.error == MACHINE_VERIFY_NONE && mutable_result.mutable_virtual_register_count == 1);

    MachineFunction use_before_definition = machine_test_build_function(arguments->arena);
    use_before_definition.instructions[0].operands[1] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, 1);
    BUSTER_TEST(arguments,
                machine_verify_function(&use_before_definition).error == MACHINE_VERIFY_VIRTUAL_REGISTER_USE_BEFORE_DEFINITION);

    // Removed hint/recipe slots remain zero in structural replay v2. Reject
    // stale data instead of silently treating it as an allocation contract.
    MachineFunction stale_metadata = machine_test_build_function(arguments->arena);
    stale_metadata.virtual_registers[0].reserved_recipe = 1;
    BUSTER_TEST(arguments, machine_verify_function(&stale_metadata).error == MACHINE_VERIFY_VIRTUAL_REGISTER_DEFINITION);
    stale_metadata.virtual_registers[0].reserved_recipe = 0;
    stale_metadata.virtual_registers[0].reserved_hint = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX);
    BUSTER_TEST(arguments, machine_verify_function(&stale_metadata).error == MACHINE_VERIFY_VIRTUAL_REGISTER_DEFINITION);
    stale_metadata.virtual_registers[0].reserved_hint = 0;
    BUSTER_TEST(arguments, machine_verify_function(&stale_metadata).error == MACHINE_VERIFY_NONE);

    MachineFunction mismatched_definition_point = machine_test_build_function(arguments->arena);
    mismatched_definition_point.virtual_registers[1].definition_point = machine_point_make(1, MACHINE_POINT_AFTER);
    BUSTER_TEST(arguments,
                machine_verify_function(&mismatched_definition_point).error == MACHINE_VERIFY_VIRTUAL_REGISTER_DEFINITION_POINT);

    // Replay round-trip: byte-exact reconstruction, then hard rejection of
    // corrupted headers and truncated payloads.
    ByteSlice replay = machine_replay_serialize(arguments->arena, &function);
    MachineFunction replayed = {0};
    BUSTER_TEST(arguments, machine_replay_deserialize(arguments->arena, replay, &replayed));
    BUSTER_TEST(arguments, replayed.instruction_count == function.instruction_count);
    BUSTER_TEST(arguments, replayed.virtual_register_count == function.virtual_register_count);
    BUSTER_TEST(arguments, replayed.block_count == function.block_count);
    BUSTER_TEST(arguments,
                memcmp(replayed.instructions, function.instructions, function.instruction_count * sizeof(MachineInstruction)) == 0);
    BUSTER_TEST(arguments,
                memcmp(replayed.virtual_registers, function.virtual_registers, function.virtual_register_count * sizeof(MachineVirtualRegister)) == 0);
    BUSTER_TEST(arguments, memcmp(replayed.blocks, function.blocks, function.block_count * sizeof(MachineBlock)) == 0);
    BUSTER_TEST(arguments, machine_verify_function(&replayed).error == MACHINE_VERIFY_NONE);

    // CFG edge contracts and their parallel-copy source/parameter slices are
    // owned by the function and must survive the same replay round trip.
    MachineFunctionBuilder edge_builder = machine_function_builder_begin(arguments->arena);
    u32 edge_source_register = machine_builder_virtual_register(&edge_builder, (MachineVirtualRegister){
                                                                    .definition_point = MACHINE_POINT_INVALID,
                                                                    .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                    .typed_origin = IR_ID_UNDERLYING_INVALID,
                                                                });
    u32 edge_parameter_register = machine_builder_virtual_register(&edge_builder, (MachineVirtualRegister){
                                                                        .definition_point = MACHINE_POINT_INVALID,
                                                                        .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                        .typed_origin = IR_ID_UNDERLYING_INVALID,
                                                                    });
    u32 edge_source_parameter_offset =
        machine_builder_block_parameter(&edge_builder, (MachineBlockParameter){.virtual_register = edge_source_register});
    u32 edge_destination_parameter_offset =
        machine_builder_block_parameter(&edge_builder, (MachineBlockParameter){.virtual_register = edge_parameter_register});
    machine_builder_block_begin(&edge_builder);
    machine_builder_instruction(&edge_builder, (MachineInstruction){.opcode = MACHINE_OPCODE_SKELETON_RETURN});
    machine_builder_block_end(&edge_builder, (MachineBlock){
                                                       .successor_offset = 0,
                                                       .successor_count = 1,
                                                       .parameter_offset = edge_source_parameter_offset,
                                                       .parameter_count = 1,
                                                   });
    machine_builder_block_begin(&edge_builder);
    machine_builder_instruction(&edge_builder, (MachineInstruction){.opcode = MACHINE_OPCODE_SKELETON_RETURN});
    machine_builder_block_end(&edge_builder, (MachineBlock){
                                                       .predecessor_offset = 0,
                                                       .predecessor_count = 1,
                                                       .parameter_offset = edge_destination_parameter_offset,
                                                       .parameter_count = 1,
                                                   });
    MachineRef edge_source_ref = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, edge_source_register);
    u32 edge_copy_offset = machine_builder_edge_copy_source(&edge_builder, edge_source_ref);
    machine_builder_edge(&edge_builder, (MachineEdge){.source_block = 0, .destination_block = 1, .copy_offset = edge_copy_offset, .copy_count = 1});
    MachineFunction edge_function = machine_function_builder_finish(arguments->arena, &edge_builder);
    BUSTER_TEST(arguments, edge_function.edge_count == 1 && edge_function.block_parameter_count == 2 && edge_function.edge_copy_source_count == 1);
    BUSTER_TEST(arguments, machine_verify_function(&edge_function).error == MACHINE_VERIFY_NONE);

    u16 valid_edge_copy_count = edge_function.edges[0].copy_count;
    edge_function.edges[0].copy_count = 0;
    BUSTER_TEST(arguments, machine_verify_function(&edge_function).error == MACHINE_VERIFY_EDGE_COPY);
    edge_function.edges[0].copy_count = valid_edge_copy_count;

    MachineRef valid_edge_source = edge_function.edge_copy_sources[0];
    edge_function.edge_copy_sources[0] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, edge_parameter_register);
    BUSTER_TEST(arguments,
                machine_verify_function(&edge_function).error == MACHINE_VERIFY_VIRTUAL_REGISTER_USE_BEFORE_DEFINITION);
    edge_function.edge_copy_sources[0] = valid_edge_source;

    edge_function.edge_copy_sources[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_TARGET_REGISTER_LIMIT - 1u);
    BUSTER_TEST(arguments, machine_verify_function(&edge_function).error == MACHINE_VERIFY_NONE);
    edge_function.edge_copy_sources[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_TARGET_REGISTER_LIMIT);
    BUSTER_TEST(arguments, machine_verify_function(&edge_function).error == MACHINE_VERIFY_EDGE_COPY);
    edge_function.edge_copy_sources[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_REF_PAYLOAD_LIMIT - 1u);
    BUSTER_TEST(arguments, machine_verify_function(&edge_function).error == MACHINE_VERIFY_EDGE_COPY);
    edge_function.target = machine_target_x86_64();
    edge_function.edge_copy_sources[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_ZMM0);
    BUSTER_TEST(arguments, machine_verify_function(&edge_function).error == MACHINE_VERIFY_EDGE_COPY);
    edge_function.edge_copy_sources[0] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX);
    BUSTER_TEST(arguments, machine_verify_function(&edge_function).error == MACHINE_VERIFY_NONE);
    edge_function.target = 0;
    edge_function.edge_copy_sources[0] = valid_edge_source;

    ByteSlice edge_replay = machine_replay_serialize(arguments->arena, &edge_function);
    MachineFunction edge_replayed = {0};
    BUSTER_TEST(arguments, machine_replay_deserialize(arguments->arena, edge_replay, &edge_replayed));
    BUSTER_TEST(arguments, edge_replayed.edge_count == edge_function.edge_count && edge_replayed.block_parameter_count == edge_function.block_parameter_count &&
                              edge_replayed.edge_copy_source_count == edge_function.edge_copy_source_count);
    BUSTER_TEST(arguments, memcmp(edge_replayed.edges, edge_function.edges, edge_function.edge_count * sizeof(MachineEdge)) == 0 &&
                              memcmp(edge_replayed.block_parameters, edge_function.block_parameters,
                                     edge_function.block_parameter_count * sizeof(MachineBlockParameter)) == 0 &&
                              memcmp(edge_replayed.edge_copy_sources, edge_function.edge_copy_sources,
                                     edge_function.edge_copy_source_count * sizeof(MachineRef)) == 0);
    BUSTER_TEST(arguments, machine_verify_function(&edge_replayed).error == MACHINE_VERIFY_NONE);

    MachineFunction rejected = {0};
    ByteSlice truncated = replay;
    truncated.length -= 1;
    BUSTER_TEST(arguments, !machine_replay_deserialize(arguments->arena, truncated, &rejected));
    u8* corrupt_bytes = arena_allocate(arguments->arena, u8, replay.length);
    memcpy(corrupt_bytes, replay.pointer, replay.length);
    corrupt_bytes[0] ^= 0xff;
    BUSTER_TEST(arguments, !machine_replay_deserialize(arguments->arena, (ByteSlice){.pointer = corrupt_bytes, .length = replay.length}, &rejected));
    BUSTER_TEST(arguments, !machine_replay_deserialize(arguments->arena, (ByteSlice){0}, &rejected));

    // The transitional mutable classification is exercised through both
    // target selectors on the control-flow shapes that motivated it: local
    // reassignment across a diamond, a loop backedge, and a value live across
    // a call. Every published MIR value is still defined, and the verifier's
    // mutable count must agree with selector telemetry.
    String8 definition_contract_source = S8(
        "unsigned long mir_contract_sink(unsigned long value) { return value * 3 + 1; }\n"
        "unsigned long mir_contract(unsigned long n) {\n"
        "    unsigned long value = n + 1;\n"
        "    if (n & 1) value = 7; else value = 11;\n"
        "    unsigned long i = 0;\n"
        "    while (i < n) { value += i; if (value & 1) value ^= n; i += 1; }\n"
        "    value = mir_contract_sink(value);\n"
        "    return value + n;\n"
        "}\n");
    Target definition_contract_targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
    };
    for (u32 target_index = 0; target_index < BUSTER_ARRAY_LENGTH(definition_contract_targets); target_index += 1)
    {
        for (u32 reference = 0; reference < 2; reference += 1)
        {
            IrProgram* contract_program = machine_test_compile_c_with_options(arguments->arena, S8("machine-definition-contract.c"), definition_contract_source,
                                                           definition_contract_targets[target_index], (CIRLowerOptions){.disable_direct_ssa = reference != 0});
            BUSTER_TEST(arguments, contract_program && contract_program->module_count);
            if (!contract_program || !contract_program->module_count)
            {
                continue;
            }
            IrFunction* contract_function = machine_test_ir_function_find(contract_program->modules, S8("mir_contract"));
            BUSTER_TEST(arguments, contract_function != 0);
            if (!contract_function)
            {
                continue;
            }
            MachineSelectResult contract_selected =
                machine_select_canonical_function(arguments->arena, contract_program, contract_function, definition_contract_targets[target_index]);
            BUSTER_TEST(arguments, contract_selected.supported && contract_selected.selector_certified);
            if (!contract_selected.supported)
            {
                continue;
            }
            MachineVerifyResult contract_verified = machine_verify_function(&contract_selected.function);
            BUSTER_TEST(arguments, contract_verified.error == MACHINE_VERIFY_NONE);
            BUSTER_TEST(arguments, (contract_selected.mutable_virtual_register_count != 0) == (reference != 0));
            BUSTER_TEST(arguments,
                        contract_selected.mutable_virtual_register_count == contract_verified.mutable_virtual_register_count);
        }
    }

    // A ternary assignment defines its destination address before splitting
    // control flow. These valid cross-block uses used to fail verification:
    // selectors copied optional predecessor lists and published zero CFG edges.
    String8 bootstrap_edge_source = S8(
        "struct S { long value; };\n"
        "struct S bootstrap_edge(long value) { struct S result = {0}; result.value = value == -1 ? 0 : value; return result; }\n"
        "long bootstrap_switch(long n) { long value = 0; switch(n) { case 1: case 2: value = 7; break; default: value = 9; } return value; }\n");
    for (u32 target_index = 0; target_index < BUSTER_ARRAY_LENGTH(definition_contract_targets); target_index += 1)
    {
        IrProgram* edge_program = machine_test_compile_c(arguments->arena, S8("bootstrap-edges.c"), bootstrap_edge_source,
                                                        definition_contract_targets[target_index]);
        BUSTER_TEST(arguments, edge_program && edge_program->module_count);
        if (edge_program && edge_program->module_count)
        {
            for (u32 function_index = 0; function_index < edge_program->modules[0].function_count; function_index += 1)
            {
                IrFunction* source_function = edge_program->modules[0].functions + function_index;
                MachineSelectResult selected_edges = machine_select_canonical_function(arguments->arena, edge_program, source_function,
                                                                                        definition_contract_targets[target_index]);
                BUSTER_TEST(arguments, selected_edges.supported && selected_edges.selector_certified);
                if (selected_edges.supported)
                {
                    MachineFunction* selected_function = &selected_edges.function;
                    BUSTER_TEST(arguments, selected_function->edge_count != 0);
                    BUSTER_TEST(arguments, machine_verify_function(selected_function).error == MACHINE_VERIFY_NONE);
                    for (u32 source_index = 0; source_index < source_function->block_count; source_index += 1)
                    {
                        IrInstruction* terminator = source_function->instructions + source_function->blocks[source_index].last_instruction.value;
                        for (u32 target_index_in_block = 0; target_index_in_block < terminator->target_count; target_index_in_block += 1)
                        {
                            u32 found = 0;
                            for (u32 edge_index = 0; edge_index < selected_function->edge_count; edge_index += 1)
                            {
                                MachineEdge* edge = selected_function->edges + edge_index;
                                found += edge->source_block == source_index && edge->destination_block == terminator->targets[target_index_in_block].value;
                            }
                            BUSTER_TEST(arguments, found == 1);
                        }
                    }
                }
            }
        }
    }

    // Mode plumbing: the driver-facing enum and its report spelling.
    BUSTER_STRING_TEST(arguments, codegen_register_allocator_mode_string(CODEGEN_REGISTER_ALLOCATOR_NONE), S8("none"));
    BUSTER_STRING_TEST(arguments, codegen_register_allocator_mode_string(CODEGEN_REGISTER_ALLOCATOR_MIR_STACK), S8("mir-stack"));
    BUSTER_STRING_TEST(arguments, codegen_register_allocator_mode_string(CODEGEN_REGISTER_ALLOCATOR_FAST), S8("fast"));
    BUSTER_STRING_TEST(arguments, codegen_register_allocator_mode_string(CODEGEN_REGISTER_ALLOCATOR_QUALITY), S8("quality"));

    // The census counter primitive is tested even in ordinary builds. Failed
    // additions must not turn unavailable/overflowed work into a valid zero.
    {
        u64 starts[] = {0, 0, UINT64_MAX - 1, UINT64_MAX, UINT64_MAX - 1};
        u64 amounts[] = {0, UINT64_MAX, 1, 1, 2};
        bool expected[] = {true, true, true, false, false};
        for (u32 probe = 0; probe < BUSTER_ARRAY_LENGTH(starts); probe += 1)
        {
            u64 counter = starts[probe];
            bool added = machine_quality_census_try_add(&counter, amounts[probe]);
            BUSTER_TEST(arguments, added == expected[probe]);
            BUSTER_TEST(arguments, counter == (expected[probe] ? starts[probe] + amounts[probe] : starts[probe]));
        }
#if BUSTER_BENCH_ALLOCATIONS
        MachineQualityCensus before = machine_quality_census_snapshot();
        MachineFunction invalid = {0};
        MachineStackPlacement census_rejected = machine_quality_placement_build(arguments->arena, &invalid);
        MachineQualityCensus after = machine_quality_census_snapshot();
        BUSTER_TEST(arguments, !census_rejected.valid);
        BUSTER_TEST(arguments, after.functions - before.functions == 1);
        BUSTER_TEST(arguments, after.invalid_target_functions - before.invalid_target_functions == 1);
        BUSTER_TEST(arguments, after.prepassed_functions == before.prepassed_functions);
        BUSTER_TEST(arguments, after.candidate_region_cells == before.candidate_region_cells);
#endif
    }


    // Stage-9 scheduling. Thirty-two independent products all combined at
    // the end hold every intermediate live to the combine in source order —
    // more than the x86-64 register file — and sinking each product to its
    // first use removes the excess. The pass must keep the block partition
    // and the SSA def-before-use order, its output must satisfy the
    // structural verifier, and on this shape the scheduled FAST placement
    // must model strictly cheaper — that modeled improvement is the
    // acceptance discipline's whole basis for keeping a schedule. The
    // low-pressure function must come back unmoved: its excess is zero and
    // the pass gates itself out before building anything. Both selectors
    // promote the thirty-two locals into virtual registers, so the same
    // pressure shape schedules on AArch64 too — its file is 25 allocatable
    // registers against the 32 live products — and the acceptance
    // discipline must hold on both targets.
    {
        String8 schedule_source = S8("unsigned long tree32(unsigned long s) {\n"
                                     "    unsigned long c0 = (s + 1) * 3; unsigned long c1 = (s + 2) * 5;\n"
                                     "    unsigned long c2 = (s + 3) * 7; unsigned long c3 = (s + 4) * 11;\n"
                                     "    unsigned long c4 = (s + 5) * 13; unsigned long c5 = (s + 6) * 17;\n"
                                     "    unsigned long c6 = (s + 7) * 19; unsigned long c7 = (s + 8) * 23;\n"
                                     "    unsigned long c8 = (s + 9) * 29; unsigned long c9 = (s + 10) * 31;\n"
                                     "    unsigned long c10 = (s + 11) * 37; unsigned long c11 = (s + 12) * 41;\n"
                                     "    unsigned long c12 = (s + 13) * 43; unsigned long c13 = (s + 14) * 47;\n"
                                     "    unsigned long c14 = (s + 15) * 53; unsigned long c15 = (s + 16) * 59;\n"
                                     "    unsigned long c16 = (s + 17) * 61; unsigned long c17 = (s + 18) * 67;\n"
                                     "    unsigned long c18 = (s + 19) * 71; unsigned long c19 = (s + 20) * 73;\n"
                                     "    unsigned long c20 = (s + 21) * 79; unsigned long c21 = (s + 22) * 83;\n"
                                     "    unsigned long c22 = (s + 23) * 89; unsigned long c23 = (s + 24) * 97;\n"
                                     "    unsigned long c24 = (s + 25) * 101; unsigned long c25 = (s + 26) * 103;\n"
                                     "    unsigned long c26 = (s + 27) * 107; unsigned long c27 = (s + 28) * 109;\n"
                                     "    unsigned long c28 = (s + 29) * 113; unsigned long c29 = (s + 30) * 127;\n"
                                     "    unsigned long c30 = (s + 31) * 131; unsigned long c31 = (s + 32) * 137;\n"
                                     "    return (((c0 ^ c1) + (c2 ^ c3)) * ((c4 ^ c5) + (c6 ^ c7))) ^\n"
                                     "           (((c8 ^ c9) + (c10 ^ c11)) * ((c12 ^ c13) + (c14 ^ c15))) ^\n"
                                     "           (((c16 ^ c17) + (c18 ^ c19)) * ((c20 ^ c21) + (c22 ^ c23))) ^\n"
                                     "           (((c24 ^ c25) + (c26 ^ c27)) * ((c28 ^ c29) + (c30 ^ c31)));\n"
                                     "}\n"
                                     "unsigned long lean(unsigned long a, unsigned long b) { return a * 3 + b; }\n");
        Target schedule_targets[] = {
            {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
            {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
        };
        for (u32 target_index = 0; target_index < BUSTER_ARRAY_LENGTH(schedule_targets); target_index += 1)
        {
            IrProgram* schedule_program =
                machine_test_compile_c_with_options(arguments->arena, S8("machine-schedule.c"), schedule_source, schedule_targets[target_index],
                                                   (CIRLowerOptions){.disable_direct_ssa = true});
            BUSTER_TEST(arguments, schedule_program && schedule_program->module_count);
            if (!schedule_program || !schedule_program->module_count)
            {
                continue;
            }
            IrFunction* tree_function = machine_test_ir_function_find(schedule_program->modules, S8("tree32"));
            IrFunction* lean_function = machine_test_ir_function_find(schedule_program->modules, S8("lean"));
            BUSTER_TEST(arguments, tree_function && lean_function);
            if (!tree_function || !lean_function)
            {
                continue;
            }
            MachineSelectResult tree_selected =
                machine_select_canonical_function(arguments->arena, schedule_program, tree_function, schedule_targets[target_index]);
            MachineSelectResult lean_selected =
                machine_select_canonical_function(arguments->arena, schedule_program, lean_function, schedule_targets[target_index]);
            BUSTER_TEST(arguments, tree_selected.supported && lean_selected.supported);
            BUSTER_TEST(arguments, tree_selected.selector_certified && lean_selected.selector_certified);
            if (!tree_selected.supported || !lean_selected.supported)
            {
                continue;
            }
            MachineScheduleResult lean_scheduled = machine_schedule_function(arguments->arena, &lean_selected.function);
            BUSTER_TEST(arguments, !lean_scheduled.moved);
            MachineScheduleResult tree_scheduled = machine_schedule_function(arguments->arena, &tree_selected.function);
            BUSTER_TEST(arguments, tree_scheduled.moved);
            if (!tree_scheduled.moved)
            {
                continue;
            }
            BUSTER_TEST(arguments, machine_verify_function(&tree_scheduled.function).error == MACHINE_VERIFY_NONE);
            BUSTER_TEST(arguments, tree_scheduled.function.instruction_count == tree_selected.function.instruction_count);
            BUSTER_TEST(arguments, tree_scheduled.function.blocks == tree_selected.function.blocks);
            // The queue's clamped-growth priorities and sequence tie-breaks
            // must produce the same complete instruction order on replay.
            MachineScheduleResult tree_repeated = machine_schedule_function(arguments->arena, &tree_selected.function);
            BUSTER_TEST(arguments, tree_repeated.moved);
            BUSTER_TEST(arguments, tree_repeated.function.instruction_count == tree_scheduled.function.instruction_count);
            if (tree_repeated.function.instruction_count == tree_scheduled.function.instruction_count)
            {
                BUSTER_TEST(arguments, memcmp(tree_repeated.function.instructions, tree_scheduled.function.instructions,
                                             tree_scheduled.function.instruction_count * sizeof(MachineInstruction)) == 0);
            }
            // Single-definition values must still define above every use.
            u32 schedule_register_count = tree_scheduled.function.virtual_register_count;
            u32* schedule_definition_rows = arena_allocate(arguments->arena, u32, schedule_register_count);
            u32* schedule_definition_counts = arena_allocate(arguments->arena, u32, schedule_register_count);
            for (u32 register_index = 0; register_index < schedule_register_count; register_index += 1)
            {
                schedule_definition_rows[register_index] = 0;
                schedule_definition_counts[register_index] = 0;
            }
            for (u32 row = 0; row < tree_scheduled.function.instruction_count; row += 1)
            {
                MachineInstruction* instruction = tree_scheduled.function.instructions + row;
                MachineOpcodeInfo const* info = machine_opcode_info(instruction->opcode);
                for (u32 slot = 0; info && slot < info->operand_count; slot += 1)
                {
                    if (machine_ref_kind(instruction->operands[slot]) != MACHINE_REF_VIRTUAL_REGISTER)
                    {
                        continue;
                    }
                    u32 role = info->operand_info[slot] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u);
                    if (role == MACHINE_OPERAND_ROLE_DEFINE || role == MACHINE_OPERAND_ROLE_USE_DEFINE)
                    {
                        schedule_definition_rows[machine_ref_payload(instruction->operands[slot])] = row;
                        schedule_definition_counts[machine_ref_payload(instruction->operands[slot])] += 1;
                    }
                }
            }
            bool uses_follow_definitions = true;
            for (u32 row = 0; row < tree_scheduled.function.instruction_count; row += 1)
            {
                MachineInstruction* instruction = tree_scheduled.function.instructions + row;
                MachineOpcodeInfo const* info = machine_opcode_info(instruction->opcode);
                for (u32 slot = 0; info && slot < info->operand_count; slot += 1)
                {
                    if (machine_ref_kind(instruction->operands[slot]) != MACHINE_REF_VIRTUAL_REGISTER)
                    {
                        continue;
                    }
                    u32 virtual_register = machine_ref_payload(instruction->operands[slot]);
                    u32 role = info->operand_info[slot] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u);
                    if (role == MACHINE_OPERAND_ROLE_USE && schedule_definition_counts[virtual_register] == 1)
                    {
                        uses_follow_definitions &= schedule_definition_rows[virtual_register] <= row;
                    }
                }
            }
            BUSTER_TEST(arguments, uses_follow_definitions);
            MachineStackPlacement tree_base_placement = machine_fast_placement_build(arguments->arena, &tree_selected.function);
            MachineStackPlacement tree_scheduled_placement = machine_fast_placement_build(arguments->arena, &tree_scheduled.function);
            BUSTER_TEST(arguments, tree_base_placement.valid && tree_scheduled_placement.valid);
            BUSTER_TEST(arguments, tree_scheduled_placement.reload_count + tree_scheduled_placement.spill_count <
                                       tree_base_placement.reload_count + tree_base_placement.spill_count);
            // Exercise the opt-in verifier on the production QUALITY schedule,
            // in addition to directly validating the scheduling pass above.
            CodegenModule verified_schedule = codegen_generate_canonical_module(arguments->arena, schedule_program, schedule_program->modules,
                schedule_targets[target_index], (CodegenModuleOptions){.assume_validated = true, .verify_invariants = true,
                                                                       .register_allocator = CODEGEN_REGISTER_ALLOCATOR_QUALITY});
            BUSTER_TEST(arguments, verified_schedule.error == CODEGEN_ERROR_NONE);
            BUSTER_TEST(arguments, verified_schedule.statistics.verified_ir_module_count == 1);
            BUSTER_TEST(arguments, verified_schedule.statistics.verified_mir_function_count == 2);
            BUSTER_TEST(arguments, verified_schedule.statistics.verified_scheduled_function_count > 0);
            BUSTER_TEST(arguments, verified_schedule.statistics.verified_scheduled_function_count ==
                                   verified_schedule.statistics.allocator_scheduled_function_count);
        }
    }

    BUSTER_TEST_FIXTURE(arguments, machine_test_stack_aliases);

    // Stage 2: x86-64 selection, MIR_STACK placement, and encoding over the
    // scalar subset. Selection and encoding are host-independent; execution
    // requires a non-sanitized x86-64 host and runs the same functions
    // through the canonical NONE path as the differential oracle.
    Target machine_target = {
        .cpu_arch = CPU_ARCH_X86_64,
        .os = OPERATING_SYSTEM_LINUX,
    };
    machine_target.cpu_features_explicit = true;
    machine_target.cpu_features = target_cpu_features_add(target_cpu_features_effective(machine_target), TARGET_CPU_FEATURE_X86_CX16);
    String8 machine_c_source_head = S8("int add(int a, int b) { return a + b; }\n"
                                  "int mul(int a, int b) { return a * b; }\n"
                                  "long widen(int a, unsigned b) { return (long)a + (long)b; }\n"
                                  "int narrow(long v) { return (int)v; }\n"
                                  "int negate(int a) { return -a; }\n"
                                  "long bitnot(long a) { return ~a; }\n"
                                  "int lnot(int a) { return !a; }\n"
                                  "int less(int a, int b) { return a < b; }\n"
                                  "int uless(unsigned a, unsigned b) { return a < b; }\n"
                                  "int six(int a, int b, int c, int d, int e, int f) { return a + b + c + d + e + f; }\n"
                                  "long arr_lit(long a, long b) { long t[4] = {a, b, a + b, 5}; return t[0] * 1000 + t[1] * 100 + t[2] * 10 + t[3]; }\n"
                                  "struct KPair { long low; long high; };\n"
                                  "struct BF3 { unsigned r : 1; unsigned w : 1; unsigned x : 3; unsigned rest : 27; };\n"
                                  "long bits(long a, long b) { struct BF3 f = {.r = (unsigned)a & 1u, .w = (unsigned)b & 1u, .x = (unsigned)(a + b) & 7u, .rest = 0u}; return (long)(f.r * 100u + f.w * 10u + f.x); }\n"
                                                                    "static long kagg_take(struct KPair pair, long salt) { return pair.low * 3 + pair.high + salt; }\n"
                                  "long kagg(long a, long b) { struct KPair pair = {.low = a + 1, .high = b}; return kagg_take(pair, a) + pair.high; }\n"
                                  "int sum_to(int n) { int s = 0; int i = 1; while (i <= n) { s = s + i; i = i + 1; } return s; }\n"
                                  "long readp(long* p) { return *p; }\n"
                                  "void writep(int* p, int v) { *p = v; }\n"
                                  "int divide(int a, int b) { return a / b; }\n"
                                  "int srem(int a, int b) { return a % b; }\n"
                                  "unsigned long udiv(unsigned long a, unsigned long b) { return a / b; }\n"
                                  "int shl(int a, int b) { return a << b; }\n"
                                  "long sar(long a, int b) { return a >> b; }\n"
                                  "unsigned shr(unsigned a, int b) { return a >> b; }\n"
                                  "int with_call(int a, int b) { return divide(a, 2) + srem(b, 3); }\n"
                                  "int fadd(float a, float b) { return a + b > 1.0f; }\n"
                                  "int seven(int a, int b, int c, int d, int e, int f, int g) { return a + g; }\n"
                                  "long stack_mix(int a, int b, int c, int d, int e, int f, int g, long h) { return a + g * h; }\n"
                                  "long call_stack(long h) { return stack_mix(1, 2, 3, 4, 5, 6, 7, h); }\n"
                                  "double nine(double a, double b, double c, double d, double e, double f, double g, double h, double i) {\n"
                                  "    return a + i * b; }\n"
                                  "int indirect(int (*callee)(int, int), int a) { return callee(a, 2); }\n"
                                  "int call_indirect(int a) { int (*f)(int, int) = divide; return f(a, 3); }\n"
                                  "int aligned_local(int x) { _Alignas(16) long buffer[4]; buffer[0] = x; buffer[3] = x * 2; return (int)(buffer[0] + buffer[3]); }\n"
                                  "_Atomic int atomic_cell;\n"
                                  "int atomic_probe(int v) { return __c11_atomic_fetch_add(&atomic_cell, v, 5); }\n"
                                  "int atomic_ops(int v) { _Atomic int cell; _Atomic long wide; __c11_atomic_store(&cell, v, 5);\n"
                                  "    __c11_atomic_store(&wide, (long)v * 7, 5);\n"
                                  "    int old = __c11_atomic_fetch_add(&cell, 3, 5); old += __c11_atomic_fetch_and(&cell, 6, 5);\n"
                                  "    old += __c11_atomic_exchange(&cell, v * 2, 5); int expected = v * 2;\n"
                                  "    __c11_atomic_compare_exchange_strong(&cell, &expected, 9, 5, 5); __c11_atomic_thread_fence(5);\n"
                                  "    return old + __c11_atomic_load(&cell, 5) + expected + (int)__c11_atomic_fetch_sub(&wide, 2, 5); }\n"
                                  "int goto_probe(int v) { void* t = v ? &&a : &&b; goto *t; a: return 1; b: return 2; }\n"
                                  "typedef struct Big { long a; long b; long c; } Big;\n"
                                  "Big big_make(long a) { Big b; b.a = a; b.b = a * 2; b.c = a ^ 5; return b; }\n"
                                  "long big_sum(Big b) { return b.a + b.b + b.c; }\n"
                                  "long big_round(long a) { Big b = big_make(a); return big_sum(b) + b.c; }\n"
                                  "int counter;\n"
                                  "int bump(int by) { counter = counter + by; return counter; }\n"
                                  "int table[8];\n"
                                  "int table_get(int i) { return table[i]; }\n"
                                  "void table_set(int i, int v) { table[i] = v; }\n"
                                  "typedef struct Pair { int first; long second; } Pair;\n"
                                  "Pair pair;\n"
                                  "long pair_sum(void) { return pair.first + pair.second; }\n"
                                  "int locals_array(int n) { int a[4]; a[0] = n; a[1] = n + 1; a[2] = a[0] * a[1]; a[3] = a[2] - n; return a[3]; }\n"
                                  "int local_pair(int x) { Pair p; p.first = x; p.second = x * 2; return p.first + (int)p.second; }\n"
                                  "int pick(int k) { switch (k) { case 1: return 10; case 3: return 30; case 7: return 70; default: return -k; } }\n"
                                  // The union's zero literal covers one byte of forty-eight, so
                                  // a selection that skips the aggregate zero-fill returns
                                  // whatever the probe stack held (the state_push regression).
                                  "typedef union UTail { char head; long words[6]; } UTail;\n"
                                  "long union_tail(long a, long b) { UTail u; u = (UTail){0};\n"
                                  "    return u.words[1] + u.words[2] + u.words[3] + u.words[4] + u.words[5] + (a & 0) + (b & 0); }\n");
    String8 machine_c_source_tail = S8(
                                  "int nest2(int n) { int total = 0; for (int i = 0; i < n; i += 1) { for (int j = 0; j < n; j += 1) { total = total + i * j; } } return total; }\n"
                                  "long ucvt(long a, long b) { unsigned long u = ((unsigned long)a << 32) | 5u; double d = (double)u; unsigned long r = (unsigned long)d; float f = (float)(((unsigned long)b << 31) | 1u); return (long)(r >> 33) + (long)(f * 0.25f) + (long)(unsigned long)(double)((unsigned long)b | 3u); }\n"
                                  "int printf(const char* format, ...);\n"
                                  "int call_variadic(int a, long b) { return printf(\"%d %ld\", a, b); }\n"
                                  "typedef struct Span { char* data; unsigned long length; } Span;\n"
                                  "unsigned long span_length(Span s) { return s.length; }\n"
                                  "Span span_make(char* data, unsigned long length) { Span s; s.data = data; s.length = length; return s; }\n"
                                  "long span_round_trip(char* data, unsigned long length) {\n"
                                  "    Span s = span_make(data, length);\n"
                                  "    return (long)span_length(s) + (s.data == data ? 1 : 0);\n"
                                  "}\n"
                                  "typedef struct Single { long only; } Single;\n"
                                  "long single_round_trip(int a) { Single o; o.only = a * 3; Single copy = o; return copy.only; }\n"
                                  "int fmath(int a, int b) { double x = a; double y = b; double z = (x + y) * 0.5 - x / (y + 3.0); return (int)z; }\n"
                                  "int f32math(int a) { float x = (float)a; float y = x * 2.0f + 1.5f; return (int)(y - x); }\n"
                                  "int fcompare(int a, int b) { double x = a; double y = b;\n"
                                  "    return (x < y) + (x <= y) * 2 + (x == y) * 4 + (x != y) * 8 + (x > y) * 16 + (x >= y) * 32; }\n"
                                  "int fnegate(int a) { double x = a; return (int)-x; }\n"
                                  "int fnan(int a) { double n = a * 0.0; n = n / n; return (n == n) ? 1 : 0; }\n"
                                  "unsigned fuconv(unsigned a) { double x = a; return (unsigned)(x + 1.5); }\n"
                                  "double dadd(double a, double b) { return a + b; }\n"
                                  "double dmix(int a, double b, long c, double d) { return (double)a + b * (double)c - d; }\n"
                                  "float fhalf(float a, float b) { return (a - b) * 0.5f; }\n"
                                  "typedef struct DPair { double x; double y; } DPair;\n"
                                  "double dpair_sum(DPair p) { return p.x + p.y; }\n"
                                  "DPair dpair_make(double x, double y) { DPair p; p.x = x; p.y = y; return p; }\n"
                                  "typedef struct Tagged { long tag; double v; } Tagged;\n"
                                  "double tagged_get(Tagged t) { return t.tag ? t.v : -t.v; }\n"
                                  "double dcall(double a, double b) { DPair p = dpair_make(a, b); return dpair_sum(p) * dadd(a, b); }\n"
                                  "_Thread_local long tls_cell;\n"
                                  "long tls_bump(long by) { tls_cell = tls_cell + by; return tls_cell; }\n"
                                  "static long rv_take(const long* values, int count) { long s = 0; int i = 0; while (i < count) { s = s + values[i]; i = i + 1; } return s; }\n"
                                  "long rv_lit(long a, long b) { return rv_take((const long[]){a, b, a * b, 7}, 4); }\n"
                                  "static unsigned __int128 u128_idem(unsigned __int128 v) { return v; }\n"
                                  "unsigned __int128 u128_ferry(unsigned __int128 v) { return u128_idem(v); }\n"
                                  "int call_seventeen(int a) { return printf(\"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\",\n"
                                  "    a, a + 1, a + 2, a + 3, a + 4, a + 5, a + 6, a + 7, a + 8, a + 9, a + 10, a + 11, a + 12, a + 13, a + 14, a + 15); }\n");
    // A third fixture segment: `machine_c_source_tail` is already at the
    // C99 4095-byte string-literal limit, so new fixture text lands here
    // instead of growing it further.
    String8 machine_c_source_extra = S8(
                                  // The live-range-splitting shape: twenty-four values live from before
                                  // a call-free hot loop across a later call loop — past both
                                  // targets' register files. The calls foreclose the
                                  // caller-saved file over every whole interval and the
                                  // callee-saved file cannot hold them all, so the only
                                  // register residency left for the rest is a split to the
                                  // first loop. The pin candidate is the loop-body value
                                  // with the weighted in-loop traffic to pay for a
                                  // register: the variably modified declaration's stack
                                  // checkpoint, stored at the body's head and reloaded at
                                  // its tail. Loop bodies used to carry one whether or not
                                  // they allocated, and when that stopped this assertion
                                  // measured nothing; adding live values does not bring it
                                  // back, because candidacy is traffic and not pressure.
                                  "static unsigned long sp_mix(unsigned long v) { v ^= v >> 31; v *= 0x9e3779b97f4a7c15UL; v ^= v >> 27; return v; }\n"
                                  "unsigned long split_phase(unsigned long seed, unsigned long rounds) {\n"
                                  "    unsigned long k0 = seed + 1; unsigned long k1 = seed + 2; unsigned long k2 = seed + 3; unsigned long k3 = seed + 4;\n"
                                  "    unsigned long k4 = seed + 5; unsigned long k5 = seed + 6; unsigned long k6 = seed + 7; unsigned long k7 = seed + 8;\n"
                                  "    unsigned long k8 = seed + 9; unsigned long k9 = seed + 10; unsigned long k10 = seed + 11; unsigned long k11 = seed + 12;\n"
                                  "    unsigned long k12 = seed + 13; unsigned long k13 = seed + 14; unsigned long k14 = seed + 15; unsigned long k15 = seed + 16;\n"
                                  "    unsigned long k16 = seed + 17; unsigned long k17 = seed + 18; unsigned long k18 = seed + 19; unsigned long k19 = seed + 20;\n"
                                  "    unsigned long k20 = seed + 21; unsigned long k21 = seed + 22; unsigned long k22 = seed + 23; unsigned long k23 = seed + 24;\n"
                                  "    unsigned long acc = seed;\n"
                                  "    for (unsigned long round = 0; round < rounds; round += 1) {\n"
                                  "        acc += k0 ^ (acc << 1); acc += k1 ^ (acc << 2); acc += k2 ^ (acc << 3); acc += k3 ^ (acc << 4);\n"
                                  "        acc += k4 ^ (acc << 5); acc += k5 ^ (acc << 6); acc += k6 ^ (acc << 7); acc += k7 ^ (acc << 1);\n"
                                  "        acc += k8 ^ (acc << 2); acc += k9 ^ (acc << 3); acc += k10 ^ (acc << 4); acc += k11 ^ (acc << 5);\n"
                                  "        acc += k12 ^ (acc << 6); acc += k13 ^ (acc << 7); acc += k14 ^ (acc << 1); acc += k15 ^ (acc << 2);\n"
                                  "        acc += k16 ^ (acc << 3); acc += k17 ^ (acc << 4); acc += k18 ^ (acc << 5); acc += k19 ^ (acc << 6);\n"
                                  "        acc += k20 ^ (acc << 7); acc += k21 ^ (acc << 1); acc += k22 ^ (acc << 2); acc += k23 ^ (acc << 3);\n"
                                  "        unsigned long lane[(rounds & 3) + 1]; lane[rounds & 3] = acc; acc += lane[rounds & 3];\n"
                                  "    }\n"
                                  "    for (unsigned long round = 0; round < rounds; round += 1) { acc += sp_mix(acc ^ k0 ^ k23); }\n"
                                  "    return acc ^ k1 ^ k2 ^ k3 ^ k4 ^ k5 ^ k6 ^ k7 ^ k8 ^ k9 ^ k10 ^ k11 ^ k12 ^ k13 ^ k14 ^ k15 ^ k16 ^ k17 ^ k18 ^ k19 ^\n"
                                  "           k20 ^ k21 ^ k22;\n"
                                  "}\n"
                                  "static int vla_consume(const int* values, int count, int a, int b, int c, int d, int e) { return values[0] + values[count - 1] + a + e; }\n"
                                  "int vla_sum(int seed, int count) { int n = (count & 2047) + 1; int total = 0; for (int i = 0; i < 2; i += 1) { int values[n]; values[0] = seed + i; values[n - 1] = seed + count + i; total += vla_consume(values, n, seed, i, 1, 2, 3); } return total; }\n"
                                  "typedef __int128 MachineWideSigned;\n"
                                  "typedef unsigned __int128 MachineWideUnsigned;\n"
                                  "unsigned long u128_to_u64(MachineWideUnsigned v) { return (unsigned long)v; }\n"
                                  "long i128_to_i64(MachineWideSigned v) { return (long)v; }\n"
                                  "MachineWideUnsigned u64_to_u128(unsigned long v) { return (MachineWideUnsigned)v; }\n"
                                  "MachineWideSigned i64_to_i128(long v) { return (MachineWideSigned)v; }\n"
                                  "int variadic_named(int first, ...) { return first; }\n"
                                  "int variadic_named_caller(int first) { return variadic_named(first, 22, 3.5); }\n"
                                  "long stack_tail(long a, long b, long c, long d, long e, long f, long g, long h, long i, long j) { return a * 2 + b + c + d + e + f + g + h + i * 3 + j * 5; }\n"
                                  "long call_stack_tail(long x) { return stack_tail(x, 2, 3, 4, 5, 6, 7, 8, x + 9, 10); }\n"
                                  // A parameter written with array syntax carries a bound whose
                                  // arithmetic is emitted between the parameter homes, so the entry
                                  // block is not a contiguous run of them. Both shapes take a fourth
                                  // integer argument, which System V passes in RCX -- the register
                                  // that bound multiply uses. `vla_param` is the same shape with a
                                  // genuine runtime bound, where the arithmetic cannot be folded away.
                                  "long arr_param(unsigned char slots[2], long a, long b, long c) {\n"
                                  "    return slots[0] * 1000 + a * 100 + b * 10 + c; }\n"
                                  "long vla_param(long n, unsigned char slots[n], long b, long c) {\n"
                                  "    return slots[n - 1] * 1000 + n * 100 + b * 10 + c; }\n");
    String8 machine_c_source_i128 = S8(
                                  "MachineWideSigned i8_to_i128(signed char v) { return (MachineWideSigned)v; }\n"
                                  "MachineWideUnsigned u8_to_u128(unsigned char v) { return (MachineWideUnsigned)v; }\n"
                                  "MachineWideSigned i16_to_i128(short v) { return (MachineWideSigned)v; }\n"
                                  "MachineWideUnsigned u16_to_u128(unsigned short v) { return (MachineWideUnsigned)v; }\n"
                                  "MachineWideSigned i32_to_i128(int v) { return (MachineWideSigned)v; }\n"
                                  "MachineWideUnsigned u32_to_u128(unsigned int v) { return (MachineWideUnsigned)v; }\n"
                                  "MachineWideUnsigned i128_reinterpret(MachineWideSigned v) { return (MachineWideUnsigned)v; }\n"
                                  "MachineWideUnsigned u128_shr0(MachineWideUnsigned v) { return v >> 0; }\n"
                                  "MachineWideUnsigned u128_shr1(MachineWideUnsigned v) { return v >> 1; }\n"
                                  "MachineWideUnsigned u128_shr63(MachineWideUnsigned v) { return v >> 63; }\n"
                                  "MachineWideUnsigned u128_shr64(MachineWideUnsigned v) { return v >> 64; }\n"
                                  "MachineWideUnsigned u128_shr65(MachineWideUnsigned v) { return v >> 65; }\n"
                                  "MachineWideUnsigned u128_shr127(MachineWideUnsigned v) { return v >> 127; }\n");
    String8 machine_c_source_variadic = S8(
                                  "#if defined(__x86_64__)\n"
                                  "typedef __builtin_va_list va_list;\n"
                                  "long variadic_observe(int first, ...) { va_list arguments; long total = first; __builtin_va_start(arguments, first);\n"
                                  "    total += __builtin_va_arg(arguments, int); total += __builtin_va_arg(arguments, int);\n"
                                  "    total += __builtin_va_arg(arguments, int); total += __builtin_va_arg(arguments, int);\n"
                                  "    total += __builtin_va_arg(arguments, int); total += __builtin_va_arg(arguments, int);\n"
                                  "    total += __builtin_va_arg(arguments, int);\n"
                                  "    total += (long)__builtin_va_arg(arguments, double); total += (long)__builtin_va_arg(arguments, double);\n"
                                  "    total += (long)__builtin_va_arg(arguments, double); total += (long)__builtin_va_arg(arguments, double);\n"
                                  "    total += (long)__builtin_va_arg(arguments, double); total += (long)__builtin_va_arg(arguments, double);\n"
                                  "    total += (long)__builtin_va_arg(arguments, double); total += (long)__builtin_va_arg(arguments, double);\n"
                                  "    total += (long)__builtin_va_arg(arguments, double); __builtin_va_end(arguments); return total; }\n"
                                  "long variadic_observe_caller(int first) { return variadic_observe(first, 1, 2, 3, 4, 5, 6, 7,\n"
                                  "    1.25, 2.25, 3.25, 4.25, 5.25, 6.25, 7.25, 8.25, 9.25); }\n"
                                  "int atomic_cmpxchg16(_Atomic unsigned __int128* cell, unsigned __int128 expected, unsigned __int128 desired) {\n"
                                  "    int result = __c11_atomic_compare_exchange_strong(cell, &expected, desired, 5, 5);\n"
                                  "    return result;\n"
                                  "}\n"
                                  "void atomic_store16(_Atomic unsigned __int128* cell, unsigned __int128 desired) {\n"
                                  "    __c11_atomic_store(cell, desired, 5);\n"
                                  "}\n"
                                  "unsigned __int128 atomic_load16(_Atomic unsigned __int128* cell) {\n"
                                  "    return __c11_atomic_load(cell, 5);\n"
                                  "}\n"
                                  "unsigned __int128 atomic_exchange16(_Atomic unsigned __int128* cell, unsigned __int128 desired) {\n"
                                  "    return __c11_atomic_exchange(cell, desired, 5);\n"
                                  "}\n"
                                  "int atomic_cmpxchg16_after_call(_Atomic unsigned __int128* cell, unsigned __int128 expected, unsigned __int128 desired) {\n"
                                  "    int result = __c11_atomic_compare_exchange_strong(cell, &expected, desired, 5, 5);\n"
                                  "    return result + variadic_named(0);\n"
                                  "}\n"
                                  "int variadic_unsupported_first(int first, ...) { __asm__ volatile(\"\" : : \"a\"(first));\n"
                                  "    va_list arguments; __builtin_va_start(arguments, first); return __builtin_va_arg(arguments, int); }\n"
                                  "#endif\n");
    // The AArch64 variadic segment, appended only to the stage-11 source:
    // the alias preserves the builtin va_list identity. Eleven anonymous
    // parts against eight registers exercise both the register path and
    // the overflow tail of the public ELF AAPCS64 representation.
    String8 machine_c_source_a64_variadic = S8(
                                  "typedef __builtin_va_list va_list;\n"
                                  "long vsum(int count, ...) { va_list arguments; long total = 0; __builtin_va_start(arguments, count);\n"
                                  "    for (int index = 0; index < count; index += 1) { total += __builtin_va_arg(arguments, long); }\n"
                                  "    __builtin_va_end(arguments); return total; }\n"
                                  "long vsum_caller(long a, long b) { return vsum(11, a, b, a + b, (long)1, (long)2, (long)3, (long)4,\n"
                                  "    (long)5, (long)6, (long)7, a - b); }\n"
                                  "typedef float MachineV4 __attribute__((vector_size(16)));\n"
                                  "MachineV4 vec_pass(MachineV4 value) { return value; }\n"
                                  "typedef struct MachineBig3 { long a; long b; long c; } MachineBig3;\n"
                                  "long big_take(MachineBig3 value, long salt) { return value.a * 3 + value.c + salt; }\n"
                                  "typedef struct MachineFPair { double left; double right; } MachineFPair;\n"
                                  "double fpair_tail(double a, double b, double c, double d, double e, double f, double g, double h,\n"
                                  "    MachineFPair tail) { return a + b + c + d + e + f + g + h + tail.left * 2 + tail.right; }\n"
                                  "typedef struct MachinePair2 { long low; long high; } MachinePair2;\n"
                                  "long pair_spill(long a, long b, long c, long d, long e, long f, long g, MachinePair2 tail) {\n"
                                  "    return a + b + c + d + e + f + g + tail.low * 5 + tail.high; }\n"
                                  "long aligned_spot(long x) { _Alignas(64) long cells[8]; cells[0] = x; cells[7] = x * 3;\n"
                                  "    return cells[0] + cells[7] + (((long)(unsigned long)&cells[0]) & 63); }\n"
                                  "typedef int MachineVLit __attribute__((vector_size(16)));\n"
                                  "MachineVLit vlit_make(int a, int b) { return (MachineVLit){ a, b, a + b, a - b }; }\n"
                                  "MachineVLit vquad_add(MachineVLit left, MachineVLit right) { return left + right; }\n"
                                  "typedef float MachineVF4 __attribute__((vector_size(16)));\n"
                                  "MachineVF4 vf4_scale(MachineVF4 value, MachineVF4 scale) { return value * scale; }\n"
                                  "unsigned long amix(unsigned long start, unsigned long delta) { _Atomic unsigned long cell = start;\n"
                                  "    unsigned long added = __c11_atomic_fetch_add(&cell, delta, __ATOMIC_ACQ_REL);\n"
                                  "    unsigned long swapped = __c11_atomic_exchange(&cell, added ^ delta, __ATOMIC_SEQ_CST);\n"
                                  "    unsigned long expected = added ^ delta;\n"
                                  "    unsigned long won = (unsigned long)__c11_atomic_compare_exchange_strong(&cell, &expected, swapped + 3, __ATOMIC_SEQ_CST, __ATOMIC_ACQUIRE);\n"
                                  "    __c11_atomic_thread_fence(__ATOMIC_SEQ_CST);\n"
                                  "    __c11_atomic_store(&cell, swapped - added, __ATOMIC_RELEASE);\n"
                                  "    return added * 3 + swapped + won + __c11_atomic_load(&cell, __ATOMIC_ACQUIRE); }\n"
                                  "long vla_fill(long count) { long lanes = (count & 7) + 1; long cells[lanes];\n"
                                  "    for (long i = 0; i < lanes; i += 1) { cells[i] = i * 3 + count; }\n"
                                  "    long total = 0;\n"
                                  "    for (long i = 0; i < lanes; i += 1) { total += cells[i]; }\n"
                                  "    return total; }\n"
                                  "long pick4(long value) { switch (value & 3) {\n"
                                  "    case 0: return value * 3;\n"
                                  "    case 1: return value - 7;\n"
                                  "    case 2: return value ^ 0x55;\n"
                                  "    default: return value + 11; } }\n"
                                  "typedef unsigned char MachineV8 __attribute__((vector_size(8)));\n"
                                  "MachineV8 v8_pass(MachineV8 value) { return value; }\n"
                                  "typedef unsigned char MachineV2 __attribute__((vector_size(2)));\n"
                                  "MachineV2 v2_make(int a) { return (MachineV2){ (unsigned char)a, (unsigned char)(a + 3) }; }\n"
                                  // A 128-bit multiply stays outside the AArch64 machine subset
                                  // (no UMULH row), so this is the corpus's deliberate fallback
                                  // witness: the module-wiring assertion below needs at least one
                                  // counted function now that the pair signatures, memory,
                                  // constant shifts, carry arithmetic, and comparisons select.
                                  "unsigned __int128 a64_i128_multiply(unsigned __int128 a, unsigned __int128 b) { return a * b; }\n");
    // Kept separate from the already-near-limit AArch64 source segment so
    // the host translation unit stays within C99's 4095-byte string-literal
    // guarantee.
    String8 machine_c_source_a64_atomic = S8(
                                  "typedef struct MachineAtomicPair { unsigned long low; unsigned long high; } MachineAtomicPair;\n"
                                  "unsigned long atomic_pair_round(unsigned long low, unsigned long high) { _Atomic MachineAtomicPair cell;\n"
                                  "    MachineAtomicPair value = { low, high }; __c11_atomic_store(&cell, value, __ATOMIC_RELEASE);\n"
                                  "    MachineAtomicPair loaded = __c11_atomic_load(&cell, __ATOMIC_ACQUIRE); return loaded.low ^ loaded.high; }\n"
                                  "struct __attribute__((packed)) MachineAtomicNine { unsigned long low; unsigned char high; };\n"
                                  "unsigned long atomic_nine_round(unsigned long low, unsigned long high) { _Atomic struct MachineAtomicNine cell;\n"
                                  "    struct MachineAtomicNine value = { low, (unsigned char)high }; __c11_atomic_store(&cell, value, __ATOMIC_SEQ_CST);\n"
                                  "    struct MachineAtomicNine loaded = __c11_atomic_load(&cell, __ATOMIC_SEQ_CST); unsigned char* bytes = (unsigned char*)&cell;\n"
                                  "    unsigned long padding = 0; for (int index = 9; index < 16; index += 1) { padding |= bytes[index]; }\n"
                                  "    return loaded.low ^ loaded.high ^ (padding << 8); }\n");
    String8 machine_c_source_base =
        string_format(arguments->arena, S8("{S8}{S8}{S8}"), machine_c_source_head, machine_c_source_tail, machine_c_source_extra);
    String8 machine_c_source_stage11 = string_format(arguments->arena, S8("{S8}{S8}{S8}"), machine_c_source_base,
                                                      machine_c_source_a64_variadic, machine_c_source_a64_atomic);
    String8 machine_c_source = string_format(arguments->arena, S8("{S8}{S8}{S8}{S8}{S8}"), machine_c_source_head, machine_c_source_tail,
                                              machine_c_source_extra, machine_c_source_i128, machine_c_source_variadic);
    IrProgram* machine_program = machine_test_compile_c(arguments->arena, S8("machine-stage2.c"), machine_c_source, machine_target);
    BUSTER_TEST(arguments, machine_program != 0);
    if (machine_program && machine_program->module_count)
    {
        IrModule* machine_module = machine_program->modules;
        // The whole-module NONE oracle: identical IR through the canonical
        // path, executed at each function's entry offset.
        CodegenModule none_module = codegen_generate_canonical_module(arguments->arena, machine_program, machine_module, machine_target,
                                                                      (CodegenModuleOptions){0});
        BUSTER_TEST(arguments, none_module.error == CODEGEN_ERROR_NONE);
        String8 supported_names[] = {
            S8_INITIALIZER("add"), S8_INITIALIZER("mul"), S8_INITIALIZER("widen"), S8_INITIALIZER("narrow"),
            S8_INITIALIZER("negate"), S8_INITIALIZER("bitnot"), S8_INITIALIZER("lnot"), S8_INITIALIZER("less"),
            S8_INITIALIZER("uless"), S8_INITIALIZER("six"), S8_INITIALIZER("kagg"), S8_INITIALIZER("arr_lit"), S8_INITIALIZER("bits"), S8_INITIALIZER("ucvt"), S8_INITIALIZER("sum_to"), S8_INITIALIZER("readp"),
            S8_INITIALIZER("writep"), S8_INITIALIZER("divide"), S8_INITIALIZER("srem"), S8_INITIALIZER("udiv"),
            S8_INITIALIZER("shl"), S8_INITIALIZER("sar"), S8_INITIALIZER("shr"), S8_INITIALIZER("bump"),
            S8_INITIALIZER("table_get"), S8_INITIALIZER("table_set"), S8_INITIALIZER("pair_sum"),
            S8_INITIALIZER("locals_array"), S8_INITIALIZER("local_pair"), S8_INITIALIZER("pick"),
            S8_INITIALIZER("aligned_local"), S8_INITIALIZER("span_length"), S8_INITIALIZER("span_make"), S8_INITIALIZER("span_round_trip"),
            S8_INITIALIZER("single_round_trip"), S8_INITIALIZER("fmath"), S8_INITIALIZER("f32math"),
            S8_INITIALIZER("fcompare"), S8_INITIALIZER("fnegate"), S8_INITIALIZER("fnan"), S8_INITIALIZER("fuconv"),
            S8_INITIALIZER("union_tail"),
        };
        MachineEncodeResult machine_encoded[BUSTER_ARRAY_LENGTH(supported_names)] = {0};
        for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(supported_names); name_index += 1)
        {
            IrFunction* ir_function = machine_test_ir_function_find(machine_module, supported_names[name_index]);
            BUSTER_TEST(arguments, ir_function != 0);
            if (!ir_function)
            {
                continue;
            }
            MachineSelectResult selected = {0};
            machine_encoded[name_index] = machine_test_encode(arguments->arena, machine_program, ir_function, machine_target, &selected);
            BUSTER_TEST_RAW(arguments, selected.supported,
                            string_format(arguments->arena, S8("select {S8} failed at opcode {u32}"), supported_names[name_index],
                                          (u32)selected.failed_opcode));
            BUSTER_TEST(arguments, selected.machine_instructions >= selected.selected_typed_instructions / 4);
            BUSTER_TEST_RAW(arguments, machine_encoded[name_index].valid, supported_names[name_index]);
            BUSTER_TEST_RAW(arguments, machine_encoded[name_index].byte_count > 8, supported_names[name_index]);
            // The prologue shape is fixed: push rbp; mov rbp, rsp.
            BUSTER_TEST(arguments, !machine_encoded[name_index].valid ||
                                       (machine_encoded[name_index].bytes[0] == 0x55 && machine_encoded[name_index].bytes[1] == 0x48 &&
                                        machine_encoded[name_index].bytes[2] == 0x89 && machine_encoded[name_index].bytes[3] == 0xe5));
        }
        // Placement statistics: MIR_STACK round-trips every operand, so a
        // selected function with arithmetic must report both reloads and
        // spills, bounded by four per instruction.
        IrFunction* add_function = machine_test_ir_function_find(machine_module, S8("add"));
        if (add_function)
        {
            MachineSelectResult add_selected = machine_select_canonical_function(arguments->arena, machine_program, add_function, machine_target);
            BUSTER_TEST(arguments, add_selected.supported);
            bool saw_ssa_alu = false;
            bool ssa_alu_well_formed = true;
            for (u32 row_index = 0; add_selected.supported && row_index < add_selected.function.instruction_count; row_index += 1)
            {
                MachineInstruction* row = add_selected.function.instructions + row_index;
                bool is_ssa_alu = row->opcode == MACHINE_X64_ADD32 || row->opcode == MACHINE_X64_ADD64 || row->opcode == MACHINE_X64_SUB32 ||
                                  row->opcode == MACHINE_X64_SUB64 || row->opcode == MACHINE_X64_AND32 || row->opcode == MACHINE_X64_AND64 ||
                                  row->opcode == MACHINE_X64_OR32 || row->opcode == MACHINE_X64_OR64 || row->opcode == MACHINE_X64_XOR32 ||
                                  row->opcode == MACHINE_X64_XOR64 || row->opcode == MACHINE_X64_IMUL32 || row->opcode == MACHINE_X64_IMUL64;
                if (!is_ssa_alu)
                {
                    continue;
                }
                saw_ssa_alu = true;
                MachineOpcodeInfo const* info = machine_opcode_info(row->opcode);
                ssa_alu_well_formed &= info && info->operand_count == 3 && machine_opcode_operand_is_tied(info, 0, 1);
                ssa_alu_well_formed &= machine_ref_kind(row->operands[0]) == MACHINE_REF_VIRTUAL_REGISTER &&
                                       machine_ref_kind(row->operands[1]) == MACHINE_REF_VIRTUAL_REGISTER &&
                                       machine_ref_kind(row->operands[2]) == MACHINE_REF_VIRTUAL_REGISTER;
            }
            BUSTER_TEST(arguments, saw_ssa_alu && ssa_alu_well_formed);
            MachineStackPlacement add_placement = machine_stack_placement_build(arguments->arena, &add_selected.function);
            BUSTER_TEST(arguments, add_placement.valid);
            BUSTER_TEST(arguments, add_placement.reload_count > 0 && add_placement.spill_count > 0);
            BUSTER_TEST(arguments, add_placement.reload_count + add_placement.spill_count <= add_selected.function.instruction_count * 4);
            BUSTER_TEST(arguments, add_placement.frame_size % 16 == 0);
        }
        // Direct calls select into fixed-register argument copies plus a
        // relocated call row; float signatures are the current explicit
        // unsupported representative.
        IrFunction* call_function = machine_test_ir_function_find(machine_module, S8("with_call"));
        BUSTER_TEST(arguments, call_function != 0);
        if (call_function)
        {
            MachineSelectResult call_selected = machine_select_canonical_function(arguments->arena, machine_program, call_function, machine_target);
            BUSTER_TEST(arguments, call_selected.supported);
            BUSTER_TEST(arguments, call_selected.function.call_target_count >= 2);
        }
        IrFunction* float_function = machine_test_ir_function_find(machine_module, S8("fadd"));
        BUSTER_TEST(arguments, float_function != 0);
        if (float_function)
        {
            MachineSelectResult float_selected = machine_select_canonical_function(arguments->arena, machine_program, float_function, machine_target);
            BUSTER_TEST(arguments, float_selected.supported);
        }
        // Stack arguments now select; dynamic stack allocation stays the
        // explicit unsupported representative.
        IrFunction* seven_function = machine_test_ir_function_find(machine_module, S8("seven"));
        BUSTER_TEST(arguments, seven_function != 0);
        if (seven_function)
        {
            MachineSelectResult seven_selected = machine_select_canonical_function(arguments->arena, machine_program, seven_function, machine_target);
            BUSTER_TEST(arguments, seven_selected.supported);
        }
        // A variable-length local must stay on the machine path: the
        // dynamic allocation row pins its runtime size in RCX, probes the
        // pages, and returns the aligned pointer in RAX. The call while the
        // VLA is live proves the stack checkpoint and outgoing argument rows
        // remain ordered by the scheduler barriers.
        IrFunction* vla_function = machine_test_ir_function_find(machine_module, S8("vla_sum"));
        BUSTER_TEST(arguments, vla_function != 0);
        if (vla_function)
        {
            MachineSelectResult vla_selected = machine_select_canonical_function(arguments->arena, machine_program, vla_function, machine_target);
            BUSTER_TEST_RAW(arguments, vla_selected.supported,
                            string_format(arguments->arena, S8("vla select failed at opcode {u32}"), (u32)vla_selected.failed_opcode));
            if (vla_selected.supported)
            {
                bool saw_allocate = false;
                bool saw_save = false;
                bool saw_restore = false;
                for (u32 row_index = 0; row_index < vla_selected.function.instruction_count; row_index += 1)
                {
                    MachineInstruction* row = vla_selected.function.instructions + row_index;
                    saw_allocate |= row->opcode == MACHINE_X64_STACK_ALLOCATE;
                    saw_save |= row->opcode == MACHINE_X64_MOV_RR && machine_ref_kind(row->operands[1]) == MACHINE_REF_PHYSICAL_REGISTER &&
                                machine_ref_payload(row->operands[1]) == MACHINE_X64_RSP;
                    saw_restore |= row->opcode == MACHINE_X64_MOV_RR && machine_ref_kind(row->operands[0]) == MACHINE_REF_PHYSICAL_REGISTER &&
                                   machine_ref_payload(row->operands[0]) == MACHINE_X64_RSP;
                }
                BUSTER_TEST(arguments, saw_allocate && saw_save && saw_restore);
                BUSTER_TEST(arguments, machine_verify_function(&vla_selected.function).error == MACHINE_VERIFY_NONE);
                MachineStackPlacement vla_placement = machine_stack_placement_build(arguments->arena, &vla_selected.function);
                BUSTER_TEST(arguments, vla_placement.valid);
                MachineEncodeResult vla_encoded = machine_encode_x86_64(arguments->arena, &vla_selected.function, &vla_placement);
                BUSTER_TEST(arguments, vla_encoded.valid && vla_encoded.byte_count > 32);
            }
        }
        IrFunction* indirect_function = machine_test_ir_function_find(machine_module, S8("indirect"));
        BUSTER_TEST(arguments, indirect_function != 0);
        if (indirect_function)
        {
            MachineSelectResult indirect_selected = machine_select_canonical_function(arguments->arena, machine_program, indirect_function, machine_target);
            BUSTER_TEST(arguments, indirect_selected.supported);
        }
        // Atomics now select; computed goto stays the explicit unsupported
        // representative.
        IrFunction* atomic_function = machine_test_ir_function_find(machine_module, S8("atomic_probe"));
        BUSTER_TEST(arguments, atomic_function != 0);
        if (atomic_function)
        {
            MachineSelectResult atomic_selected = machine_select_canonical_function(arguments->arena, machine_program, atomic_function, machine_target);
            BUSTER_TEST(arguments, atomic_selected.supported);
        }
        IrFunction* atomic_cmpxchg16_function = machine_test_ir_function_find(machine_module, S8("atomic_cmpxchg16"));
        BUSTER_TEST(arguments, atomic_cmpxchg16_function != 0);
        if (atomic_cmpxchg16_function)
        {
            MachineSelectResult atomic_cmpxchg16_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_cmpxchg16_function, machine_target);
            BUSTER_TEST_RAW(arguments, atomic_cmpxchg16_selected.supported,
                            string_format(arguments->arena, S8("select atomic_cmpxchg16 failed at opcode {u32}"),
                                          (u32)atomic_cmpxchg16_selected.failed_opcode));
            if (atomic_cmpxchg16_selected.supported)
            {
                bool saw_cmpxchg16_row = false;
                for (u32 row_index = 0; row_index < atomic_cmpxchg16_selected.function.instruction_count; row_index += 1)
                {
                    saw_cmpxchg16_row |= atomic_cmpxchg16_selected.function.instructions[row_index].opcode == MACHINE_X64_ATOMIC_CMPXCHG16;
                }
                BUSTER_TEST(arguments, saw_cmpxchg16_row);
            }
            // The boolean shortcut is valid only for the frontend's
            // observed == expected comparison.  Mutate that RHS to the
            // unrelated desired i128 value and require the generic selector to
            // lower a real i128 equality instead of reusing the atomic success
            // flag.  It used to prove that by refusing; since the x86-64
            // selector picked up the i128 binary subset (#811) the generic
            // path answers it, so the proof is now in the rows: that path
            // differences the halves with a pair of XOR64s, which the shortcut
            // -- a single move out of the success register -- never emits.
            IrInstruction* atomic_ir = 0;
            IrInstruction* atomic_observed_compare = 0;
            for (u32 instruction_index = 0; instruction_index < atomic_cmpxchg16_function->instruction_count; instruction_index += 1)
            {
                IrInstruction* instruction = atomic_cmpxchg16_function->instructions + instruction_index;
                if (!atomic_ir && instruction->opcode == IR_OPCODE_ATOMIC_COMPARE_EXCHANGE && instruction->operand_count >= 3)
                {
                    atomic_ir = instruction;
                }
            }
            if (atomic_ir)
            {
                for (u32 instruction_index = 0; instruction_index < atomic_cmpxchg16_function->instruction_count; instruction_index += 1)
                {
                    IrInstruction* instruction = atomic_cmpxchg16_function->instructions + instruction_index;
                    if (instruction->opcode == IR_OPCODE_BINARY && instruction->operand_count >= 2 &&
                        instruction->binary_operation == IR_BINARY_INTEGER_EQUAL &&
                        instruction->operands[0].value == atomic_ir->result.value)
                    {
                        atomic_observed_compare = instruction;
                        break;
                    }
                }
            }
            BUSTER_TEST(arguments, atomic_ir && atomic_observed_compare && atomic_ir->operands[1].value != atomic_ir->operands[2].value);
            if (atomic_ir && atomic_observed_compare && atomic_ir->operands[1].value != atomic_ir->operands[2].value)
            {
                IrValueId expected_operand = atomic_observed_compare->operands[1];
                u32 shortcut_difference_rows = 0;
                for (u32 row_index = 0; atomic_cmpxchg16_selected.supported && row_index < atomic_cmpxchg16_selected.function.instruction_count;
                     row_index += 1)
                {
                    shortcut_difference_rows += atomic_cmpxchg16_selected.function.instructions[row_index].opcode == MACHINE_X64_XOR64;
                }
                atomic_observed_compare->operands[1] = atomic_ir->operands[2];
                MachineSelectResult unrelated_i128_selected =
                    machine_select_canonical_function(arguments->arena, machine_program, atomic_cmpxchg16_function, machine_target);
                BUSTER_TEST(arguments, unrelated_i128_selected.supported);
                u32 unrelated_difference_rows = 0;
                for (u32 row_index = 0; unrelated_i128_selected.supported && row_index < unrelated_i128_selected.function.instruction_count; row_index += 1)
                {
                    unrelated_difference_rows += unrelated_i128_selected.function.instructions[row_index].opcode == MACHINE_X64_XOR64;
                }
                BUSTER_TEST(arguments, unrelated_difference_rows > shortcut_difference_rows);
                atomic_observed_compare->operands[1] = expected_operand;
            }
            Target no_cx16_target = machine_target;
            no_cx16_target.cpu_features_explicit = true;
            no_cx16_target.cpu_features = target_cpu_features_remove(target_cpu_features_effective(machine_target), TARGET_CPU_FEATURE_X86_CX16);
            MachineSelectResult no_cx16_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_cmpxchg16_function, no_cx16_target);
            BUSTER_TEST(arguments, !no_cx16_selected.supported);
        }
        IrFunction* atomic_store16_ir_function = machine_test_ir_function_find(machine_module, S8("atomic_store16"));
        BUSTER_TEST(arguments, atomic_store16_ir_function != 0);
        if (atomic_store16_ir_function)
        {
            MachineSelectResult atomic_store16_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_store16_ir_function, machine_target);
            BUSTER_TEST_RAW(arguments, atomic_store16_selected.supported,
                            string_format(arguments->arena, S8("select atomic_store16 failed at opcode {u32}"),
                                          (u32)atomic_store16_selected.failed_opcode));
            if (atomic_store16_selected.supported)
            {
                bool saw_store16_row = false;
                for (u32 row_index = 0; row_index < atomic_store16_selected.function.instruction_count; row_index += 1)
                {
                    MachineInstruction* row = atomic_store16_selected.function.instructions + row_index;
                    if (row->opcode == MACHINE_X64_ATOMIC_STORE16)
                    {
                        saw_store16_row = true;
                        MachineOpcodeInfo const* info = machine_opcode_info(row->opcode);
                        BUSTER_TEST(arguments, row->payload == 16 && info->operand_count == 4 &&
                                                   info->memory_effect == MACHINE_MEMORY_EFFECT_ATOMIC &&
                                                   (info->attributes & MACHINE_OPCODE_ATTRIBUTE_CONSTRAINED) &&
                                                   info->clobber_mask == ((1ull << MACHINE_X64_RAX) | (1ull << MACHINE_X64_RDX) |
                                                                          (1ull << MACHINE_X64_RBX) | (1ull << MACHINE_X64_RCX)));
                    }
                }
                BUSTER_TEST(arguments, saw_store16_row);
                BUSTER_TEST(arguments, machine_verify_function(&atomic_store16_selected.function).error == MACHINE_VERIFY_NONE);
                MachineStackPlacement atomic_store16_placement =
                    machine_stack_placement_build(arguments->arena, &atomic_store16_selected.function);
                BUSTER_TEST(arguments, atomic_store16_placement.valid &&
                                           (atomic_store16_placement.callee_saved_mask & (1ull << MACHINE_X64_RBX)));
                if (atomic_store16_placement.valid)
                {
                    MachineEncodeResult atomic_store16_encoded =
                        machine_encode_x86_64(arguments->arena, &atomic_store16_selected.function, &atomic_store16_placement);
                    bool saw_cmpxchg16_bytes = false;
                    for (u32 byte_index = 0; byte_index + 3 < atomic_store16_encoded.byte_count; byte_index += 1)
                    {
                        saw_cmpxchg16_bytes |= atomic_store16_encoded.bytes[byte_index] == 0xf0 &&
                                               atomic_store16_encoded.bytes[byte_index + 1] == 0x48 &&
                                               atomic_store16_encoded.bytes[byte_index + 2] == 0x0f &&
                                               atomic_store16_encoded.bytes[byte_index + 3] == 0xc7;
                    }
                    BUSTER_TEST(arguments, atomic_store16_encoded.valid && saw_cmpxchg16_bytes);
                }
            }
            Target no_cx16_store_target = machine_target;
            no_cx16_store_target.cpu_features_explicit = true;
            no_cx16_store_target.cpu_features =
                target_cpu_features_remove(target_cpu_features_effective(machine_target), TARGET_CPU_FEATURE_X86_CX16);
            MachineSelectResult no_cx16_store_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_store16_ir_function, no_cx16_store_target);
            BUSTER_TEST(arguments, !no_cx16_store_selected.supported);
        }
        IrFunction* atomic_load16_ir_function = machine_test_ir_function_find(machine_module, S8("atomic_load16"));
        BUSTER_TEST(arguments, atomic_load16_ir_function != 0);
        if (atomic_load16_ir_function)
        {
            MachineSelectResult atomic_load16_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_load16_ir_function, machine_target);
            BUSTER_TEST_RAW(arguments, atomic_load16_selected.supported,
                            string_format(arguments->arena, S8("select atomic_load16 failed at opcode {u32}"),
                                          (u32)atomic_load16_selected.failed_opcode));
            bool saw_load16_row = false;
            for (u32 row_index = 0; atomic_load16_selected.supported && row_index < atomic_load16_selected.function.instruction_count; row_index += 1)
            {
                MachineInstruction* row = atomic_load16_selected.function.instructions + row_index;
                if (row->opcode == MACHINE_X64_ATOMIC_LOAD16)
                {
                    saw_load16_row = true;
                    BUSTER_TEST(arguments, row->payload == 16 && machine_opcode_info(row->opcode)->memory_effect == MACHINE_MEMORY_EFFECT_ATOMIC);
                }
            }
            BUSTER_TEST(arguments, saw_load16_row);
            BUSTER_TEST(arguments, machine_verify_function(&atomic_load16_selected.function).error == MACHINE_VERIFY_NONE);
            Target no_cx16_load_target = machine_target;
            no_cx16_load_target.cpu_features_explicit = true;
            no_cx16_load_target.cpu_features =
                target_cpu_features_remove(target_cpu_features_effective(machine_target), TARGET_CPU_FEATURE_X86_CX16);
            MachineSelectResult no_cx16_load_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_load16_ir_function, no_cx16_load_target);
            BUSTER_TEST(arguments, !no_cx16_load_selected.supported);
        }
        IrFunction* atomic_exchange16_ir_function = machine_test_ir_function_find(machine_module, S8("atomic_exchange16"));
        BUSTER_TEST(arguments, atomic_exchange16_ir_function != 0);
        if (atomic_exchange16_ir_function)
        {
            MachineSelectResult atomic_exchange16_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_exchange16_ir_function, machine_target);
            BUSTER_TEST_RAW(arguments, atomic_exchange16_selected.supported,
                            string_format(arguments->arena, S8("select atomic_exchange16 failed at opcode {u32}"),
                                          (u32)atomic_exchange16_selected.failed_opcode));
            bool saw_exchange16_row = false;
            for (u32 row_index = 0; atomic_exchange16_selected.supported && row_index < atomic_exchange16_selected.function.instruction_count;
                 row_index += 1)
            {
                MachineInstruction* row = atomic_exchange16_selected.function.instructions + row_index;
                if (row->opcode == MACHINE_X64_ATOMIC_RMW16)
                {
                    saw_exchange16_row = true;
                    BUSTER_TEST(arguments, row->payload == (16u | ((u32)IR_ATOMIC_EXCHANGE << 8)) &&
                                               machine_opcode_info(row->opcode)->memory_effect == MACHINE_MEMORY_EFFECT_ATOMIC);
                }
            }
            BUSTER_TEST(arguments, saw_exchange16_row);
            BUSTER_TEST(arguments, machine_verify_function(&atomic_exchange16_selected.function).error == MACHINE_VERIFY_NONE);
            Target no_cx16_exchange_target = machine_target;
            no_cx16_exchange_target.cpu_features_explicit = true;
            no_cx16_exchange_target.cpu_features =
                target_cpu_features_remove(target_cpu_features_effective(machine_target), TARGET_CPU_FEATURE_X86_CX16);
            MachineSelectResult no_cx16_exchange_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_exchange16_ir_function, no_cx16_exchange_target);
            BUSTER_TEST(arguments, !no_cx16_exchange_selected.supported);
        }
        IrFunction* atomic_cmpxchg16_call_function = machine_test_ir_function_find(machine_module, S8("atomic_cmpxchg16_after_call"));
        BUSTER_TEST(arguments, atomic_cmpxchg16_call_function != 0);
        if (atomic_cmpxchg16_call_function)
        {
            MachineSelectResult atomic_cmpxchg16_call_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_cmpxchg16_call_function, machine_target);
            BUSTER_TEST_RAW(arguments, atomic_cmpxchg16_call_selected.supported,
                            string_format(arguments->arena, S8("select atomic_cmpxchg16_after_call failed at opcode {u32}"),
                                          (u32)atomic_cmpxchg16_call_selected.failed_opcode));
            if (atomic_cmpxchg16_call_selected.supported)
            {
                MachineStackPlacement call_placement = machine_stack_placement_build(arguments->arena, &atomic_cmpxchg16_call_selected.function);
                u32 call_push_count = 0;
                for (u32 physical_register = 0; physical_register < machine_target_x86_64()->register_count; physical_register += 1)
                {
                    call_push_count += (u32)((call_placement.callee_saved_mask >> physical_register) & 1u);
                }
                BUSTER_TEST(arguments, call_placement.valid && (call_placement.callee_saved_mask & rbx_mask) &&
                                               (call_placement.frame_size + 8 * call_push_count) % 16 == 0);
            }
        }
        // Execute the canonical and machine forms against a deliberately
        // sixteen-byte-aligned object.  The first call succeeds and returns
        // true; the second observes the changed old value and returns false,
        // exercising both CMPXCHG16B result paths and its RBX save/restore.
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
        if (atomic_cmpxchg16_function)
        {
            typedef int MachineTestAtomicCmpxchg16(_Atomic unsigned __int128*, unsigned __int128, unsigned __int128);
            u32 atomic_none_offset = machine_test_module_offset(&none_module, machine_module, S8("atomic_cmpxchg16"));
            MachineSelectResult atomic_machine_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_cmpxchg16_function, machine_target);
            MachineStackPlacement atomic_machine_placement = machine_stack_placement_build(arguments->arena, &atomic_machine_selected.function);
            MachineEncodeResult atomic_machine_encoded = atomic_machine_selected.supported
                                                             ? machine_encode_x86_64(arguments->arena, &atomic_machine_selected.function,
                                                                                     &atomic_machine_placement)
                                                             : (MachineEncodeResult){0};
            CodegenExecutable atomic_none_executable = codegen_make_executable((CodegenFunction){.code = none_module.code});
            CodegenExecutable atomic_machine_executable = codegen_make_executable((CodegenFunction){
                .code = {.pointer = atomic_machine_encoded.bytes, .length = atomic_machine_encoded.byte_count}});
            BUSTER_TEST(arguments, atomic_none_offset != UINT32_MAX && atomic_machine_encoded.valid &&
                                       atomic_none_executable.error == CODEGEN_ERROR_NONE && atomic_machine_executable.error == CODEGEN_ERROR_NONE);
            if (atomic_none_offset != UINT32_MAX && atomic_machine_executable.address && atomic_none_executable.address)
            {
                MachineTestAtomicCmpxchg16* atomic_none_call = 0;
                MachineTestAtomicCmpxchg16* atomic_machine_call = 0;
                void* atomic_none_address = (u8*)atomic_none_executable.address + atomic_none_offset;
                void* atomic_machine_address = atomic_machine_executable.address;
                memcpy(&atomic_none_call, &atomic_none_address, sizeof(atomic_none_call));
                memcpy(&atomic_machine_call, &atomic_machine_address, sizeof(atomic_machine_call));
                _Alignas(16) unsigned __int128 atomic_cell_none = ((unsigned __int128)UINT64_C(0x1111222233334444) << 64) | UINT64_C(0x5555666677778888);
                _Alignas(16) unsigned __int128 atomic_cell_machine = atomic_cell_none;
                unsigned __int128 atomic_expected = atomic_cell_none;
                unsigned __int128 atomic_desired = ((unsigned __int128)UINT64_C(0xaaaabbbbccccdddd) << 64) | UINT64_C(0xeeeeffff00001111);
                int atomic_none_first = atomic_none_call((_Atomic unsigned __int128*)&atomic_cell_none, atomic_expected, atomic_desired);
                int atomic_machine_first = atomic_machine_call((_Atomic unsigned __int128*)&atomic_cell_machine, atomic_expected, atomic_desired);
                int atomic_none_second = atomic_none_call((_Atomic unsigned __int128*)&atomic_cell_none, atomic_expected, atomic_expected);
                int atomic_machine_second = atomic_machine_call((_Atomic unsigned __int128*)&atomic_cell_machine, atomic_expected, atomic_expected);
                BUSTER_TEST(arguments, atomic_none_first == atomic_machine_first && atomic_none_second == atomic_machine_second && atomic_none_first && !atomic_none_second &&
                                           atomic_cell_none == atomic_cell_machine);
            }
            codegen_release_executable(atomic_machine_executable);
            codegen_release_executable(atomic_none_executable);
        }
        if (atomic_store16_ir_function)
        {
            typedef void MachineTestAtomicStore16(_Atomic unsigned __int128*, unsigned __int128);
            u32 atomic_store16_none_offset = machine_test_module_offset(&none_module, machine_module, S8("atomic_store16"));
            MachineSelectResult atomic_store16_machine_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_store16_ir_function, machine_target);
            MachineStackPlacement atomic_store16_machine_placement =
                atomic_store16_machine_selected.supported
                    ? machine_stack_placement_build(arguments->arena, &atomic_store16_machine_selected.function)
                    : (MachineStackPlacement){0};
            MachineEncodeResult atomic_store16_machine_encoded =
                atomic_store16_machine_selected.supported && atomic_store16_machine_placement.valid
                    ? machine_encode_x86_64(arguments->arena, &atomic_store16_machine_selected.function, &atomic_store16_machine_placement)
                    : (MachineEncodeResult){0};
            CodegenExecutable atomic_store16_none_executable = codegen_make_executable((CodegenFunction){.code = none_module.code});
            CodegenExecutable atomic_store16_machine_executable = codegen_make_executable((CodegenFunction){
                .code = {.pointer = atomic_store16_machine_encoded.bytes, .length = atomic_store16_machine_encoded.byte_count}});
            BUSTER_TEST(arguments, atomic_store16_none_offset != UINT32_MAX && atomic_store16_machine_encoded.valid &&
                                       atomic_store16_none_executable.error == CODEGEN_ERROR_NONE &&
                                       atomic_store16_machine_executable.error == CODEGEN_ERROR_NONE);
            if (atomic_store16_none_offset != UINT32_MAX && atomic_store16_machine_executable.address && atomic_store16_none_executable.address)
            {
                MachineTestAtomicStore16* atomic_store16_none_call = 0;
                MachineTestAtomicStore16* atomic_store16_machine_call = 0;
                void* atomic_store16_none_address = (u8*)atomic_store16_none_executable.address + atomic_store16_none_offset;
                void* atomic_store16_machine_address = atomic_store16_machine_executable.address;
                memcpy(&atomic_store16_none_call, &atomic_store16_none_address, sizeof(atomic_store16_none_call));
                memcpy(&atomic_store16_machine_call, &atomic_store16_machine_address, sizeof(atomic_store16_machine_call));
                _Alignas(16) unsigned __int128 atomic_store16_cell_none = 0;
                _Alignas(16) unsigned __int128 atomic_store16_cell_machine = 0;
                unsigned __int128 atomic_store16_value = ((unsigned __int128)UINT64_C(0xaaaabbbbccccdddd) << 64) |
                                                          UINT64_C(0xeeeeffff00001111);
                atomic_store16_none_call((_Atomic unsigned __int128*)&atomic_store16_cell_none, atomic_store16_value);
                atomic_store16_machine_call((_Atomic unsigned __int128*)&atomic_store16_cell_machine, atomic_store16_value);
                BUSTER_TEST(arguments, atomic_store16_cell_none == atomic_store16_value && atomic_store16_cell_machine == atomic_store16_value &&
                                           atomic_store16_cell_none == atomic_store16_cell_machine);

                // A fresh invocation starts with a zero expected pair.  The
                // second store therefore takes the CMPXCHG16B failure edge,
                // imports the current pair into RAX:RDX, and succeeds on its
                // retry rather than spinning on the stale zero expectation.
                unsigned __int128 atomic_store16_second_value = ((unsigned __int128)UINT64_C(0x123456789abcdef0) << 64) |
                                                                 UINT64_C(0x0fedcba987654321);
                atomic_store16_none_call((_Atomic unsigned __int128*)&atomic_store16_cell_none, atomic_store16_second_value);
                atomic_store16_machine_call((_Atomic unsigned __int128*)&atomic_store16_cell_machine, atomic_store16_second_value);
                BUSTER_TEST(arguments, atomic_store16_cell_none == atomic_store16_second_value &&
                                           atomic_store16_cell_machine == atomic_store16_second_value &&
                                           atomic_store16_cell_none == atomic_store16_cell_machine);

                // Exercise every short logical width accepted by the row.
                // The source value deliberately has nonzero bytes throughout
                // its high eightbyte, so the executed encoder must clear the
                // padding bytes rather than merely report encoded.valid.
                u32 atomic_store16_row_index = UINT32_MAX;
                for (u32 row_index = 0; row_index < atomic_store16_machine_selected.function.instruction_count; row_index += 1)
                {
                    if (atomic_store16_machine_selected.function.instructions[row_index].opcode == MACHINE_X64_ATOMIC_STORE16)
                    {
                        atomic_store16_row_index = row_index;
                        break;
                    }
                }
                if (atomic_store16_row_index != UINT32_MAX)
                {
                    MachineInstruction* atomic_store16_row = atomic_store16_machine_selected.function.instructions + atomic_store16_row_index;
                    for (u32 short_size = 9; short_size <= 15; short_size += 1)
                    {
                        atomic_store16_row->payload = short_size;
                        MachineEncodeResult atomic_store16_short_encoded =
                            machine_encode_x86_64(arguments->arena, &atomic_store16_machine_selected.function,
                                                  &atomic_store16_machine_placement);
                        CodegenExecutable atomic_store16_short_executable = codegen_make_executable((CodegenFunction){
                            .code = {.pointer = atomic_store16_short_encoded.bytes, .length = atomic_store16_short_encoded.byte_count}});
                        _Alignas(16) unsigned char atomic_store16_short_cell[16] = {0};
                        bool atomic_store16_short_bytes_match = atomic_store16_short_encoded.valid &&
                                                                atomic_store16_short_executable.error == CODEGEN_ERROR_NONE &&
                                                                atomic_store16_short_executable.address;
                        if (atomic_store16_short_bytes_match)
                        {
                            MachineTestAtomicStore16* atomic_store16_short_call = 0;
                            void* atomic_store16_short_address = atomic_store16_short_executable.address;
                            memcpy(&atomic_store16_short_call, &atomic_store16_short_address, sizeof(atomic_store16_short_call));
                            atomic_store16_short_call((_Atomic unsigned __int128*)atomic_store16_short_cell, atomic_store16_value);
                            for (u32 byte_index = 0; byte_index < 16; byte_index += 1)
                            {
                                unsigned char expected_byte = byte_index < short_size
                                    ? (unsigned char)(atomic_store16_value >> (byte_index * 8u))
                                    : 0;
                                atomic_store16_short_bytes_match &= atomic_store16_short_cell[byte_index] == expected_byte;
                            }
                        }
                        BUSTER_TEST(arguments, atomic_store16_short_bytes_match);
                        codegen_release_executable(atomic_store16_short_executable);
                    }
                    atomic_store16_row->payload = 16;
                }
            }
            codegen_release_executable(atomic_store16_machine_executable);
            codegen_release_executable(atomic_store16_none_executable);
        }
        if (atomic_load16_ir_function)
        {
            typedef unsigned __int128 MachineTestAtomicLoad16(_Atomic unsigned __int128*);
            u32 atomic_load16_none_offset = machine_test_module_offset(&none_module, machine_module, S8("atomic_load16"));
            MachineSelectResult atomic_load16_machine_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_load16_ir_function, machine_target);
            MachineStackPlacement atomic_load16_machine_placement = atomic_load16_machine_selected.supported
                                                                         ? machine_stack_placement_build(arguments->arena,
                                                                                                         &atomic_load16_machine_selected.function)
                                                                         : (MachineStackPlacement){0};
            MachineEncodeResult atomic_load16_machine_encoded =
                atomic_load16_machine_selected.supported && atomic_load16_machine_placement.valid
                    ? machine_encode_x86_64(arguments->arena, &atomic_load16_machine_selected.function,
                                             &atomic_load16_machine_placement)
                    : (MachineEncodeResult){0};
            CodegenExecutable atomic_load16_none_executable = codegen_make_executable((CodegenFunction){.code = none_module.code});
            CodegenExecutable atomic_load16_machine_executable = codegen_make_executable((CodegenFunction){
                .code = {.pointer = atomic_load16_machine_encoded.bytes, .length = atomic_load16_machine_encoded.byte_count}});
            BUSTER_TEST(arguments, atomic_load16_none_offset != UINT32_MAX && atomic_load16_machine_encoded.valid &&
                                       atomic_load16_none_executable.error == CODEGEN_ERROR_NONE &&
                                       atomic_load16_machine_executable.error == CODEGEN_ERROR_NONE);
            if (atomic_load16_none_offset != UINT32_MAX && atomic_load16_machine_executable.address && atomic_load16_none_executable.address)
            {
                MachineTestAtomicLoad16* atomic_load16_none_call = 0;
                MachineTestAtomicLoad16* atomic_load16_machine_call = 0;
                void* atomic_load16_none_address = (u8*)atomic_load16_none_executable.address + atomic_load16_none_offset;
                void* atomic_load16_machine_address = atomic_load16_machine_executable.address;
                memcpy(&atomic_load16_none_call, &atomic_load16_none_address, sizeof(atomic_load16_none_call));
                memcpy(&atomic_load16_machine_call, &atomic_load16_machine_address, sizeof(atomic_load16_machine_call));
                unsigned __int128 atomic_load16_value = ((unsigned __int128)UINT64_C(0x8899aabbccddeeff) << 64) |
                                                         UINT64_C(0x0011223344556677);
                _Alignas(16) unsigned __int128 atomic_load16_cell_none = atomic_load16_value;
                _Alignas(16) unsigned __int128 atomic_load16_cell_machine = atomic_load16_value;
                unsigned __int128 atomic_load16_none_result =
                    atomic_load16_none_call((_Atomic unsigned __int128*)&atomic_load16_cell_none);
                unsigned __int128 atomic_load16_machine_result =
                    atomic_load16_machine_call((_Atomic unsigned __int128*)&atomic_load16_cell_machine);
                BUSTER_TEST(arguments, atomic_load16_none_result == atomic_load16_machine_result &&
                                           atomic_load16_machine_result == atomic_load16_value &&
                                           atomic_load16_cell_none == atomic_load16_cell_machine &&
                                           atomic_load16_cell_machine == atomic_load16_value);
            }
            codegen_release_executable(atomic_load16_machine_executable);
            codegen_release_executable(atomic_load16_none_executable);
        }
        if (atomic_exchange16_ir_function)
        {
            typedef unsigned __int128 MachineTestAtomicExchange16(_Atomic unsigned __int128*, unsigned __int128);
            u32 atomic_exchange16_none_offset = machine_test_module_offset(&none_module, machine_module, S8("atomic_exchange16"));
            MachineSelectResult atomic_exchange16_machine_selected =
                machine_select_canonical_function(arguments->arena, machine_program, atomic_exchange16_ir_function, machine_target);
            MachineStackPlacement atomic_exchange16_machine_placement = atomic_exchange16_machine_selected.supported
                                                                           ? machine_stack_placement_build(arguments->arena,
                                                                                                           &atomic_exchange16_machine_selected.function)
                                                                           : (MachineStackPlacement){0};
            MachineEncodeResult atomic_exchange16_machine_encoded =
                atomic_exchange16_machine_selected.supported && atomic_exchange16_machine_placement.valid
                    ? machine_encode_x86_64(arguments->arena, &atomic_exchange16_machine_selected.function,
                                             &atomic_exchange16_machine_placement)
                    : (MachineEncodeResult){0};
            CodegenExecutable atomic_exchange16_none_executable = codegen_make_executable((CodegenFunction){.code = none_module.code});
            CodegenExecutable atomic_exchange16_machine_executable = codegen_make_executable((CodegenFunction){
                .code = {.pointer = atomic_exchange16_machine_encoded.bytes, .length = atomic_exchange16_machine_encoded.byte_count}});
            BUSTER_TEST(arguments, atomic_exchange16_none_offset != UINT32_MAX && atomic_exchange16_machine_encoded.valid &&
                                       atomic_exchange16_none_executable.error == CODEGEN_ERROR_NONE &&
                                       atomic_exchange16_machine_executable.error == CODEGEN_ERROR_NONE);
            if (atomic_exchange16_none_offset != UINT32_MAX && atomic_exchange16_machine_executable.address &&
                atomic_exchange16_none_executable.address)
            {
                MachineTestAtomicExchange16* atomic_exchange16_none_call = 0;
                MachineTestAtomicExchange16* atomic_exchange16_machine_call = 0;
                void* atomic_exchange16_none_address = (u8*)atomic_exchange16_none_executable.address + atomic_exchange16_none_offset;
                void* atomic_exchange16_machine_address = atomic_exchange16_machine_executable.address;
                memcpy(&atomic_exchange16_none_call, &atomic_exchange16_none_address, sizeof(atomic_exchange16_none_call));
                memcpy(&atomic_exchange16_machine_call, &atomic_exchange16_machine_address, sizeof(atomic_exchange16_machine_call));
                unsigned __int128 atomic_exchange16_initial = ((unsigned __int128)UINT64_C(0x1111222233334444) << 64) |
                                                               UINT64_C(0x5555666677778888);
                unsigned __int128 atomic_exchange16_desired = ((unsigned __int128)UINT64_C(0xaaaabbbbccccdddd) << 64) |
                                                               UINT64_C(0xeeeeffff00001111);
                _Alignas(16) unsigned __int128 atomic_exchange16_cell_none = atomic_exchange16_initial;
                _Alignas(16) unsigned __int128 atomic_exchange16_cell_machine = atomic_exchange16_initial;
                unsigned __int128 atomic_exchange16_none_first =
                    atomic_exchange16_none_call((_Atomic unsigned __int128*)&atomic_exchange16_cell_none, atomic_exchange16_desired);
                unsigned __int128 atomic_exchange16_machine_first =
                    atomic_exchange16_machine_call((_Atomic unsigned __int128*)&atomic_exchange16_cell_machine, atomic_exchange16_desired);
                unsigned __int128 atomic_exchange16_second_desired = ((unsigned __int128)UINT64_C(0x123456789abcdef0) << 64) |
                                                                       UINT64_C(0x0fedcba987654321);
                unsigned __int128 atomic_exchange16_none_second =
                    atomic_exchange16_none_call((_Atomic unsigned __int128*)&atomic_exchange16_cell_none, atomic_exchange16_second_desired);
                unsigned __int128 atomic_exchange16_machine_second =
                    atomic_exchange16_machine_call((_Atomic unsigned __int128*)&atomic_exchange16_cell_machine, atomic_exchange16_second_desired);
                BUSTER_TEST(arguments, atomic_exchange16_none_first == atomic_exchange16_machine_first &&
                                           atomic_exchange16_none_first == atomic_exchange16_initial &&
                                           atomic_exchange16_none_second == atomic_exchange16_machine_second &&
                                           atomic_exchange16_none_second == atomic_exchange16_desired &&
                                           atomic_exchange16_cell_none == atomic_exchange16_second_desired &&
                                           atomic_exchange16_cell_machine == atomic_exchange16_second_desired &&
                                           atomic_exchange16_cell_none == atomic_exchange16_cell_machine);
            }
            codegen_release_executable(atomic_exchange16_machine_executable);
            codegen_release_executable(atomic_exchange16_none_executable);
        }
#endif
        IrFunction* goto_function = machine_test_ir_function_find(machine_module, S8("goto_probe"));
        BUSTER_TEST(arguments, goto_function != 0);
        if (goto_function)
        {
            MachineSelectResult goto_selected = machine_select_canonical_function(arguments->arena, machine_program, goto_function, machine_target);
            BUSTER_TEST(arguments, goto_selected.supported);
            if (goto_selected.supported)
            {
                MachineStackPlacement goto_placement = machine_stack_placement_build(arguments->arena, &goto_selected.function);
                MachineEncodeResult goto_encoded = machine_encode_x86_64(arguments->arena, &goto_selected.function, &goto_placement);
                BUSTER_TEST(arguments, goto_placement.valid);
                BUSTER_TEST(arguments, goto_encoded.valid && goto_encoded.byte_count != 0);
            }
        }
        // Computed-goto census: each shape below keeps the complete IR target
        // set on the machine terminator and exercises a different label-value
        // provenance path (forward/backward, conditional, array storage,
        // switch selection, and a label address without an indirect branch).
        // The same fixture is selected, verified, placed, and encoded on both
        // backends; the module then runs through NONE/MIR_STACK/FAST/QUALITY
        // so every allocator sees the same successor population.
        String8 label_fixture_source = S8(
            "int labels_one(int v) { void* p = v ? &&one : &&two; goto *p; one: return 1; two: return 2; }\n"
            "int labels_three(int v) { void* p; if (v < 0) p = &&neg; else if (v) p = &&pos; else p = &&zero; goto *p; neg: return -1; pos: return 1; zero: return 0; }\n"
            "int labels_four(int v) { void* p = &&a; if (v == 1) p = &&b; if (v == 2) p = &&c; if (v == 3) p = &&d; goto *p; a: return 10; b: return 11; c: return 12; d: return 13; }\n"
            "int labels_loop(int v) { void* p = &&loop; loop: if (v-- > 0) goto *p; return v; }\n"
            "int labels_forward(int v) { void* p = &&done; if (v) goto *p; return 9; done: return 7; }\n"
            "int labels_array(int v) { void* p[2] = {&&zero, &&one}; goto *p[v & 1]; zero: return 0; one: return 1; }\n"
            "int labels_switch(int v) { void* p; switch (v & 3) { case 0: p = &&a; break; case 1: p = &&b; break; case 2: p = &&c; break; default: p = &&d; break; } goto *p; a: return 20; b: return 21; c: return 22; d: return 23; }\n"
            "int labels_conditional(int v) { goto *(v ? &&yes : &&no); yes: return 1; no: return 0; }\n"
            "int labels_address_only(int v) { void* p = &&target; return p == &&target ? v : 0; target: return 1; }\n"
            "int labels_compare(int v) { void* p = &&target; if (p == &&target) goto *p; target: return v; }\n");
        IrProgram* label_fixture_program = machine_test_compile_c(arguments->arena, S8("machine-label-fixtures.c"), label_fixture_source, machine_target);
        BUSTER_TEST(arguments, label_fixture_program && label_fixture_program->module_count);
        if (label_fixture_program && label_fixture_program->module_count)
        {
            IrModule* label_fixture_module = label_fixture_program->modules;
            String8 label_fixture_names[] = {
                S8_INITIALIZER("labels_one"), S8_INITIALIZER("labels_three"), S8_INITIALIZER("labels_four"),
                S8_INITIALIZER("labels_loop"), S8_INITIALIZER("labels_forward"), S8_INITIALIZER("labels_array"),
                S8_INITIALIZER("labels_switch"), S8_INITIALIZER("labels_conditional"), S8_INITIALIZER("labels_address_only"),
                S8_INITIALIZER("labels_compare"),
            };
            u32 fixture_label_rows = 0;
            u32 fixture_indirect_rows = 0;
            for (u32 fixture_index = 0; fixture_index < BUSTER_ARRAY_LENGTH(label_fixture_names); fixture_index += 1)
            {
                IrFunction* fixture_function = machine_test_ir_function_find(label_fixture_module, label_fixture_names[fixture_index]);
                BUSTER_TEST(arguments, fixture_function != 0);
                if (!fixture_function)
                {
                    continue;
                }
                MachineSelectResult fixture_selected =
                    machine_select_canonical_function(arguments->arena, label_fixture_program, fixture_function, machine_target);
                BUSTER_TEST_RAW(arguments, fixture_selected.supported && fixture_selected.selector_certified,
                                string_format(arguments->arena, S8("label fixture {S8} select opcode {u32}"), label_fixture_names[fixture_index],
                                              (u32)fixture_selected.failed_opcode));
                if (!fixture_selected.supported)
                {
                    continue;
                }
                BUSTER_TEST(arguments, machine_verify_function(&fixture_selected.function).error == MACHINE_VERIFY_NONE);
                MachineOpcode fixture_label_opcode = machine_target.cpu_arch == CPU_ARCH_AARCH64 ? MACHINE_A64_LEA_BLOCK : MACHINE_X64_LEA_BLOCK;
                MachineOpcode fixture_indirect_opcode =
                    machine_target.cpu_arch == CPU_ARCH_AARCH64 ? MACHINE_A64_INDIRECT_BRANCH : MACHINE_X64_INDIRECT_BRANCH;
                for (u32 row_index = 0; row_index < fixture_selected.function.instruction_count; row_index += 1)
                {
                    MachineInstruction* row = fixture_selected.function.instructions + row_index;
                    if (row->opcode == fixture_label_opcode)
                    {
                        fixture_label_rows += 1;
                        BUSTER_TEST(arguments, row->payload < fixture_selected.function.block_count);
                    }
                    if (row->opcode != fixture_indirect_opcode)
                    {
                        continue;
                    }
                    fixture_indirect_rows += 1;
                    BUSTER_TEST(arguments, row->flags != 0 && row->payload <= fixture_selected.function.switch_case_count &&
                                               row->flags <= fixture_selected.function.switch_case_count - row->payload);
                    u32 owner_block = UINT32_MAX;
                    for (u32 block_index = 0; block_index < fixture_selected.function.block_count; block_index += 1)
                    {
                        MachineBlock* block = fixture_selected.function.blocks + block_index;
                        if (row_index >= block->first_instruction && row_index < block->first_instruction + block->instruction_count)
                        {
                            owner_block = block_index;
                            break;
                        }
                    }
                    BUSTER_TEST(arguments, owner_block != UINT32_MAX);
                    for (u32 case_index = 0; owner_block != UINT32_MAX && case_index < row->flags; case_index += 1)
                    {
                        u32 target_block = fixture_selected.function.switch_cases[row->payload + case_index].target_block;
                        bool edge_found = false;
                        for (u32 edge_index = 0; edge_index < fixture_selected.function.edge_count; edge_index += 1)
                        {
                            MachineEdge* edge = fixture_selected.function.edges + edge_index;
                            edge_found |= edge->source_block == owner_block && edge->destination_block == target_block;
                        }
                        BUSTER_TEST(arguments, edge_found);
                    }
                }
                MachineStackPlacement fixture_stack = machine_stack_placement_build(arguments->arena, &fixture_selected.function);
                BUSTER_TEST(arguments, fixture_stack.valid);
                MachineEncodeResult fixture_encoded = machine_target.cpu_arch == CPU_ARCH_AARCH64
                                                           ? machine_encode_aarch64(arguments->arena, &fixture_selected.function, &fixture_stack)
                                                           : machine_encode_x86_64(arguments->arena, &fixture_selected.function, &fixture_stack);
                BUSTER_TEST_RAW(arguments, fixture_encoded.valid && fixture_encoded.byte_count != 0,
                                string_format(arguments->arena, S8("label fixture {S8} encode"), label_fixture_names[fixture_index]));
            }
            BUSTER_TEST(arguments, fixture_label_rows >= BUSTER_ARRAY_LENGTH(label_fixture_names));
            BUSTER_TEST(arguments, fixture_indirect_rows >= BUSTER_ARRAY_LENGTH(label_fixture_names) - 1);
            CodegenRegisterAllocatorMode fixture_modes[] = {
                CODEGEN_REGISTER_ALLOCATOR_NONE,
                CODEGEN_REGISTER_ALLOCATOR_MIR_STACK,
                CODEGEN_REGISTER_ALLOCATOR_FAST,
                CODEGEN_REGISTER_ALLOCATOR_QUALITY,
            };
            for (u32 mode_index = 0; mode_index < BUSTER_ARRAY_LENGTH(fixture_modes); mode_index += 1)
            {
                CodegenModule fixture_module = codegen_generate_canonical_module(
                    arguments->arena, label_fixture_program, label_fixture_module, machine_target,
                    (CodegenModuleOptions){.register_allocator = (u8)fixture_modes[mode_index]});
                BUSTER_TEST_RAW(arguments, fixture_module.error == CODEGEN_ERROR_NONE && fixture_module.statistics.fallback_function_count == 0,
                                string_format(arguments->arena, S8("label fixture mode {S8} fallback {u32}"),
                                              codegen_register_allocator_mode_string(fixture_modes[mode_index]),
                                              fixture_module.statistics.fallback_function_count));
                BUSTER_TEST(arguments, fixture_module.relocation_count == 0);
            }
        }
        Target label_fixture_a64_target = {
            .cpu_arch = CPU_ARCH_AARCH64,
            .os = OPERATING_SYSTEM_LINUX,
        };
        IrProgram* label_fixture_a64_program =
            machine_test_compile_c(arguments->arena, S8("machine-label-fixtures-a64.c"), label_fixture_source, label_fixture_a64_target);
        BUSTER_TEST(arguments, label_fixture_a64_program && label_fixture_a64_program->module_count);
        if (label_fixture_a64_program && label_fixture_a64_program->module_count)
        {
            IrModule* label_fixture_a64_module = label_fixture_a64_program->modules;
            String8 label_fixture_a64_names[] = {
                S8_INITIALIZER("labels_one"), S8_INITIALIZER("labels_three"), S8_INITIALIZER("labels_four"),
                S8_INITIALIZER("labels_loop"), S8_INITIALIZER("labels_forward"), S8_INITIALIZER("labels_array"),
                S8_INITIALIZER("labels_switch"), S8_INITIALIZER("labels_conditional"), S8_INITIALIZER("labels_address_only"),
                S8_INITIALIZER("labels_compare"),
            };
            u32 a64_label_rows = 0;
            u32 a64_indirect_rows = 0;
            for (u32 fixture_index = 0; fixture_index < BUSTER_ARRAY_LENGTH(label_fixture_a64_names); fixture_index += 1)
            {
                IrFunction* fixture_function = machine_test_ir_function_find(label_fixture_a64_module, label_fixture_a64_names[fixture_index]);
                BUSTER_TEST(arguments, fixture_function != 0);
                if (!fixture_function)
                {
                    continue;
                }
                MachineSelectResult fixture_selected =
                    machine_select_canonical_function(arguments->arena, label_fixture_a64_program, fixture_function, label_fixture_a64_target);
                BUSTER_TEST_RAW(arguments, fixture_selected.supported && fixture_selected.selector_certified,
                                string_format(arguments->arena, S8("a64 label fixture {S8} select opcode {u32}"),
                                              label_fixture_a64_names[fixture_index], (u32)fixture_selected.failed_opcode));
                if (!fixture_selected.supported)
                {
                    continue;
                }
                BUSTER_TEST(arguments, machine_verify_function(&fixture_selected.function).error == MACHINE_VERIFY_NONE);
                for (u32 row_index = 0; row_index < fixture_selected.function.instruction_count; row_index += 1)
                {
                    MachineInstruction* row = fixture_selected.function.instructions + row_index;
                    if (row->opcode == MACHINE_A64_LEA_BLOCK)
                    {
                        a64_label_rows += 1;
                        BUSTER_TEST(arguments, row->payload < fixture_selected.function.block_count);
                    }
                    if (row->opcode != MACHINE_A64_INDIRECT_BRANCH)
                    {
                        continue;
                    }
                    a64_indirect_rows += 1;
                    BUSTER_TEST(arguments, row->flags != 0 && row->payload <= fixture_selected.function.switch_case_count &&
                                               row->flags <= fixture_selected.function.switch_case_count - row->payload);
                    u32 owner_block = UINT32_MAX;
                    for (u32 block_index = 0; block_index < fixture_selected.function.block_count; block_index += 1)
                    {
                        MachineBlock* block = fixture_selected.function.blocks + block_index;
                        if (row_index >= block->first_instruction && row_index < block->first_instruction + block->instruction_count)
                        {
                            owner_block = block_index;
                            break;
                        }
                    }
                    for (u32 case_index = 0; owner_block != UINT32_MAX && case_index < row->flags; case_index += 1)
                    {
                        u32 target_block = fixture_selected.function.switch_cases[row->payload + case_index].target_block;
                        bool edge_found = false;
                        for (u32 edge_index = 0; edge_index < fixture_selected.function.edge_count; edge_index += 1)
                        {
                            MachineEdge* edge = fixture_selected.function.edges + edge_index;
                            edge_found |= edge->source_block == owner_block && edge->destination_block == target_block;
                        }
                        BUSTER_TEST(arguments, edge_found);
                    }
                }
                MachineStackPlacement fixture_stack = machine_stack_placement_build(arguments->arena, &fixture_selected.function);
                BUSTER_TEST(arguments, fixture_stack.valid);
                MachineEncodeResult fixture_encoded = machine_encode_aarch64(arguments->arena, &fixture_selected.function, &fixture_stack);
                BUSTER_TEST_RAW(arguments, fixture_encoded.valid && fixture_encoded.byte_count != 0,
                                string_format(arguments->arena, S8("a64 label fixture {S8} encode"), label_fixture_a64_names[fixture_index]));
            }
            BUSTER_TEST(arguments, a64_label_rows >= BUSTER_ARRAY_LENGTH(label_fixture_a64_names));
            BUSTER_TEST(arguments, a64_indirect_rows >= BUSTER_ARRAY_LENGTH(label_fixture_a64_names) - 1);
            CodegenRegisterAllocatorMode fixture_modes[] = {
                CODEGEN_REGISTER_ALLOCATOR_NONE,
                CODEGEN_REGISTER_ALLOCATOR_MIR_STACK,
                CODEGEN_REGISTER_ALLOCATOR_FAST,
                CODEGEN_REGISTER_ALLOCATOR_QUALITY,
            };
            for (u32 mode_index = 0; mode_index < BUSTER_ARRAY_LENGTH(fixture_modes); mode_index += 1)
            {
                CodegenModule fixture_module = codegen_generate_canonical_module(
                    arguments->arena, label_fixture_a64_program, label_fixture_a64_module, label_fixture_a64_target,
                    (CodegenModuleOptions){.register_allocator = (u8)fixture_modes[mode_index]});
                BUSTER_TEST_RAW(arguments, fixture_module.error == CODEGEN_ERROR_NONE && fixture_module.statistics.fallback_function_count == 0,
                                string_format(arguments->arena, S8("a64 label fixture mode {S8} fallback {u32}"),
                                              codegen_register_allocator_mode_string(fixture_modes[mode_index]),
                                              fixture_module.statistics.fallback_function_count));
                BUSTER_TEST(arguments, fixture_module.relocation_count == 0);
            }
        }
        // Variadic direct calls select (AL zero, register-only integer
        // arguments); execution is proven by the linked soak because the
        // extern callee cannot resolve in a raw code copy.
        IrFunction* variadic_function = machine_test_ir_function_find(machine_module, S8("call_variadic"));
        BUSTER_TEST(arguments, variadic_function != 0);
        if (variadic_function)
        {
            MachineSelectResult variadic_selected = machine_select_canonical_function(arguments->arena, machine_program, variadic_function, machine_target);
            BUSTER_TEST(arguments, variadic_selected.supported);
        }
        IrFunction* variadic_named_function = machine_test_ir_function_find(machine_module, S8("variadic_named"));
        IrFunction* variadic_named_caller_function = machine_test_ir_function_find(machine_module, S8("variadic_named_caller"));
        IrFunction* variadic_observe_function = machine_test_ir_function_find(machine_module, S8("variadic_observe"));
        IrFunction* variadic_observe_caller_function = machine_test_ir_function_find(machine_module, S8("variadic_observe_caller"));
        IrFunction* variadic_unsupported_first_function = machine_test_ir_function_find(machine_module, S8("variadic_unsupported_first"));
        BUSTER_TEST(arguments, variadic_named_function && variadic_named_caller_function && variadic_observe_function &&
                                   variadic_observe_caller_function && variadic_unsupported_first_function);
        if (variadic_named_function && variadic_named_caller_function && variadic_observe_function && variadic_observe_caller_function &&
            variadic_unsupported_first_function)
        {
            MachineSelectResult variadic_named_selected =
                machine_select_canonical_function(arguments->arena, machine_program, variadic_named_function, machine_target);
            MachineSelectResult variadic_named_caller_selected =
                machine_select_canonical_function(arguments->arena, machine_program, variadic_named_caller_function, machine_target);
            MachineSelectResult variadic_observe_selected =
                machine_select_canonical_function(arguments->arena, machine_program, variadic_observe_function, machine_target);
            MachineSelectResult variadic_observe_caller_selected =
                machine_select_canonical_function(arguments->arena, machine_program, variadic_observe_caller_function, machine_target);
            MachineSelectResult variadic_unsupported_first_selected =
                machine_select_canonical_function(arguments->arena, machine_program, variadic_unsupported_first_function, machine_target);
            BUSTER_TEST(arguments, variadic_named_selected.supported && variadic_named_caller_selected.supported &&
                                       variadic_observe_caller_selected.supported);
            // SysV variadic bodies are now selected by the machine path.  The
            // selector emits one entry save row and carries every VA_ARG's
            // ABI classification in the function side table; VA_START itself
            // is lowered to ordinary frame stores and therefore is no longer
            // the first unsupported opcode.
            BUSTER_TEST(arguments, variadic_observe_selected.supported);
            if (variadic_observe_selected.supported)
            {
                u32 va_save_rows = 0;
                u32 va_arg_rows = 0;
                for (u32 instruction_index = 0; instruction_index < variadic_observe_selected.function.instruction_count; instruction_index += 1)
                {
                    MachineInstruction* machine_instruction = variadic_observe_selected.function.instructions + instruction_index;
                    if (machine_instruction->opcode == MACHINE_X64_VA_SAVE)
                    {
                        va_save_rows += 1;
                    }
                    else if (machine_instruction->opcode == MACHINE_X64_VA_ARG)
                    {
                        va_arg_rows += 1;
                        BUSTER_TEST(arguments, machine_instruction->payload < variadic_observe_selected.function.va_arg_count);
                        if (machine_instruction->payload < variadic_observe_selected.function.va_arg_count)
                        {
                            MachineVaArg* metadata = variadic_observe_selected.function.va_args + machine_instruction->payload;
                            BUSTER_TEST(arguments, metadata->part_count == 1 && !metadata->result_is_frame);
                            BUSTER_TEST(arguments, metadata->parts[0].is_memory == 0);
                            // The scalar result is the constrained fixed RCX
                            // operand, while the list pointer is fixed RAX.
                            BUSTER_TEST(arguments, machine_ref_kind(machine_instruction->operands[0]) == MACHINE_REF_VIRTUAL_REGISTER);
                            BUSTER_TEST(arguments, machine_ref_kind(machine_instruction->operands[1]) == MACHINE_REF_VIRTUAL_REGISTER);
                        }
                    }
                }
                BUSTER_TEST(arguments, va_save_rows == 1);
                BUSTER_TEST(arguments, va_arg_rows == variadic_observe_selected.function.va_arg_count && va_arg_rows == 16);
            }
            // A SysV-lowered va_list has the wrong layout for Windows.
            // Refuse this mixed-target IR instead of treating it as a pointer.
            Target windows_machine_target = machine_target;
            windows_machine_target.os = OPERATING_SYSTEM_WINDOWS;
            MachineSelectResult windows_variadic_selected =
                machine_select_canonical_function(arguments->arena, machine_program, variadic_observe_function, windows_machine_target);
            BUSTER_TEST(arguments, !windows_variadic_selected.supported);
            BUSTER_TEST(arguments, variadic_unsupported_first_selected.supported);
            if (variadic_unsupported_first_selected.supported)
            {
                BUSTER_TEST(arguments, machine_verify_function(&variadic_unsupported_first_selected.function).error == MACHINE_VERIFY_NONE);
            }
        }
        // The lifted non-vector gaps: a thread-local address (ELF local-exec
        // fs sequence), an rvalue compound-literal array base, a variadic
        // call past sixteen arguments, and 128-bit integers ferried through
        // calls as the two-eightbyte pair. Their relocations or link-only
        // callees keep execution with the full-unity soak, where every one
        // of these shapes runs in the compiler's own hot path.
        String8 lifted_gap_names[] = {
            S8_INITIALIZER("tls_bump"),
            S8_INITIALIZER("rv_lit"),
            S8_INITIALIZER("u128_ferry"),
            S8_INITIALIZER("call_seventeen"),
            S8_INITIALIZER("i8_to_i128"),
            S8_INITIALIZER("u8_to_u128"),
            S8_INITIALIZER("i16_to_i128"),
            S8_INITIALIZER("u16_to_u128"),
            S8_INITIALIZER("i32_to_i128"),
            S8_INITIALIZER("u32_to_u128"),
            S8_INITIALIZER("i128_reinterpret"),
            S8_INITIALIZER("u128_shr0"),
            S8_INITIALIZER("u128_shr1"),
            S8_INITIALIZER("u128_shr63"),
            S8_INITIALIZER("u128_shr64"),
            S8_INITIALIZER("u128_shr65"),
            S8_INITIALIZER("u128_shr127"),
        };
        for (u32 lifted_index = 0; lifted_index < BUSTER_ARRAY_LENGTH(lifted_gap_names); lifted_index += 1)
        {
            IrFunction* lifted_function = machine_test_ir_function_find(machine_module, lifted_gap_names[lifted_index]);
            BUSTER_TEST(arguments, lifted_function != 0);
            if (lifted_function)
            {
                MachineSelectResult lifted_selected = machine_select_canonical_function(arguments->arena, machine_program, lifted_function, machine_target);
                BUSTER_TEST_RAW(arguments, lifted_selected.supported,
                                string_format(arguments->arena, S8("select {S8} failed at opcode {u32}"), lifted_gap_names[lifted_index],
                                              (u32)lifted_selected.failed_opcode));
            }
        }
        String8 i128_machine_names[] = {
            S8_INITIALIZER("i8_to_i128"), S8_INITIALIZER("u8_to_u128"), S8_INITIALIZER("i16_to_i128"), S8_INITIALIZER("u16_to_u128"),
            S8_INITIALIZER("i32_to_i128"), S8_INITIALIZER("u32_to_u128"), S8_INITIALIZER("i128_reinterpret"), S8_INITIALIZER("u128_shr0"),
            S8_INITIALIZER("u128_shr1"), S8_INITIALIZER("u128_shr63"), S8_INITIALIZER("u128_shr64"), S8_INITIALIZER("u128_shr65"),
            S8_INITIALIZER("u128_shr127"),
        };
        for (u32 i128_index = 0; i128_index < BUSTER_ARRAY_LENGTH(i128_machine_names); i128_index += 1)
        {
            IrFunction* i128_function = machine_test_ir_function_find(machine_module, i128_machine_names[i128_index]);
            BUSTER_TEST(arguments, i128_function != 0);
            if (!i128_function)
            {
                continue;
            }
            MachineSelectResult i128_selected = machine_select_canonical_function(arguments->arena, machine_program, i128_function, machine_target);
            BUSTER_TEST_RAW(arguments, i128_selected.supported,
                            string_format(arguments->arena, S8("select {S8} failed at opcode {u32}"), i128_machine_names[i128_index],
                                          (u32)i128_selected.failed_opcode));
            if (i128_selected.supported)
            {
                bool saw_copy16 = false;
                bool saw_shift = false;
                bool saw_or = false;
                bool saw_high_load = false;
                bool saw_low_store = false;
                bool saw_high_store = false;
                bool saw_zero = false;
                for (u32 row_index = 0; row_index < i128_selected.function.instruction_count; row_index += 1)
                {
                    MachineInstruction* row = i128_selected.function.instructions + row_index;
                    saw_copy16 |= row->opcode == MACHINE_X64_COPY_FRAME_FROM_FRAME && row->payload == 16;
                    saw_shift |= row->opcode == MACHINE_X64_SHR64;
                    saw_or |= row->opcode == MACHINE_X64_OR64;
                    saw_high_load |= row->opcode == MACHINE_X64_LOAD_FRAME && row->payload == 8;
                    saw_low_store |= row->opcode == MACHINE_X64_STORE_FRAME64 && row->payload == 0;
                    saw_high_store |= row->opcode == MACHINE_X64_STORE_FRAME64 && row->payload == 8;
                    saw_zero |= row->opcode == MACHINE_X64_MOV_RI && machine_ref_kind(row->operands[1]) == MACHINE_REF_IMMEDIATE &&
                                machine_ref_payload(row->operands[1]) < i128_selected.function.immediate_count &&
                                i128_selected.function.immediates[machine_ref_payload(row->operands[1])] == 0;
                }
                if (i128_index == 6 || i128_index == 7)
                {
                    BUSTER_TEST(arguments, saw_copy16);
                }
                if (i128_index >= 8 && i128_index != 10)
                {
                    BUSTER_TEST_RAW(arguments, saw_shift,
                                    string_format(arguments->arena, S8("{S8} missing shift"), i128_machine_names[i128_index]));
                }
                if (i128_index == 10)
                {
                    BUSTER_TEST_RAW(arguments, saw_high_load, S8("u128_shr64 missing high load"));
                    BUSTER_TEST_RAW(arguments, saw_low_store, S8("u128_shr64 missing low store"));
                    BUSTER_TEST_RAW(arguments, saw_high_store, S8("u128_shr64 missing high store"));
                    BUSTER_TEST_RAW(arguments, saw_zero, S8("u128_shr64 missing zero"));
                }
                if (i128_index == 8 || i128_index == 9)
                {
                    BUSTER_TEST(arguments, saw_or);
                }
                MachineStackPlacement i128_placement = machine_stack_placement_build(arguments->arena, &i128_selected.function);
                BUSTER_TEST(arguments, i128_placement.valid);
                MachineEncodeResult i128_encoded = machine_encode_x86_64(arguments->arena, &i128_selected.function, &i128_placement);
                BUSTER_TEST(arguments, i128_encoded.valid && i128_encoded.byte_count > 8);
            }
        }
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
        // i128/u128 casts use the same two-eightbyte frame representation as
        // the ABI's integer aggregate pair.  Exercise every signedness
        // direction through the machine bytes and compare against the
        // canonical NONE entry, including a negative signed widening and an
        // unsigned value whose low half has its top bit set.
        {
            typedef unsigned __int128 MachineTestCallU128(u64);
            typedef __int128 MachineTestCallI128(s64);
            typedef u64 MachineTestCallU64(unsigned __int128);
            typedef s64 MachineTestCallI64(__int128);
            String8 cast_names[] = {
                S8_INITIALIZER("u128_to_u64"), S8_INITIALIZER("i128_to_i64"), S8_INITIALIZER("u64_to_u128"), S8_INITIALIZER("i64_to_i128"),
            };
            CodegenExecutable cast_none_module_executable = codegen_make_executable((CodegenFunction){
                .code = none_module.code,
            });
            BUSTER_TEST(arguments, cast_none_module_executable.error == CODEGEN_ERROR_NONE);
            for (u32 cast_index = 0; cast_index < BUSTER_ARRAY_LENGTH(cast_names); cast_index += 1)
            {
                IrFunction* cast_function = machine_test_ir_function_find(machine_module, cast_names[cast_index]);
                BUSTER_TEST(arguments, cast_function != 0);
                if (!cast_function)
                {
                    continue;
                }
                MachineSelectResult cast_selected = {0};
                MachineEncodeResult cast_machine = machine_test_encode(arguments->arena, machine_program, cast_function, machine_target, &cast_selected);
                BUSTER_TEST_RAW(arguments, cast_selected.supported,
                                string_format(arguments->arena, S8("select {S8} failed at opcode {u32}"), cast_names[cast_index],
                                              (u32)cast_selected.failed_opcode));
                BUSTER_TEST(arguments, cast_machine.valid);
                u32 cast_none_offset = machine_test_module_offset(&none_module, machine_module, cast_names[cast_index]);
                BUSTER_TEST(arguments, cast_none_offset != UINT32_MAX);
                CodegenExecutable cast_machine_executable = codegen_make_executable((CodegenFunction){
                    .code = {.pointer = cast_machine.bytes, .length = cast_machine.byte_count},
                });
                BUSTER_TEST(arguments, cast_machine_executable.error == CODEGEN_ERROR_NONE);
                if (cast_none_offset == UINT32_MAX || !cast_machine_executable.address || !cast_none_module_executable.address)
                {
                    codegen_release_executable(cast_machine_executable);
                    continue;
                }
                void* cast_none_address = (u8*)cast_none_module_executable.address + cast_none_offset;
                void* cast_machine_address = cast_machine_executable.address;
                bool cast_equal = true;
                if (cast_index == 0)
                {
                    MachineTestCallU64* none_call = 0;
                    MachineTestCallU64* machine_call = 0;
                    memcpy(&none_call, &cast_none_address, sizeof(none_call));
                    memcpy(&machine_call, &cast_machine_address, sizeof(machine_call));
                    unsigned __int128 value = ((unsigned __int128)UINT64_C(0x8000000000000001) << 64) | UINT64_C(0xdeadbeefcafebabe);
                    cast_equal = none_call(value) == machine_call(value);
                }
                else if (cast_index == 1)
                {
                    MachineTestCallI64* none_call = 0;
                    MachineTestCallI64* machine_call = 0;
                    memcpy(&none_call, &cast_none_address, sizeof(none_call));
                    memcpy(&machine_call, &cast_machine_address, sizeof(machine_call));
                    __int128 value = -((__int128)1 << 100) - 5;
                    cast_equal = none_call(value) == machine_call(value);
                }
                else if (cast_index == 2)
                {
                    MachineTestCallU128* none_call = 0;
                    MachineTestCallU128* machine_call = 0;
                    memcpy(&none_call, &cast_none_address, sizeof(none_call));
                    memcpy(&machine_call, &cast_machine_address, sizeof(machine_call));
                    u64 value = UINT64_C(0x8000000000000001);
                    unsigned __int128 none_value = none_call(value);
                    unsigned __int128 machine_value = machine_call(value);
                    cast_equal = none_value == machine_value;
                    BUSTER_TEST(arguments, (u64)(machine_value >> 64) == 0);
                }
                else
                {
                    MachineTestCallI128* none_call = 0;
                    MachineTestCallI128* machine_call = 0;
                    memcpy(&none_call, &cast_none_address, sizeof(none_call));
                    memcpy(&machine_call, &cast_machine_address, sizeof(machine_call));
                    s64 value = -1;
                    __int128 none_value = none_call(value);
                    __int128 machine_value = machine_call(value);
                    cast_equal = none_value == machine_value;
                    BUSTER_TEST(arguments, (u64)((unsigned __int128)machine_value >> 64) == UINT64_MAX);
                    value = INT64_MIN;
                    none_value = none_call(value);
                    machine_value = machine_call(value);
                    cast_equal &= none_value == machine_value;
                    BUSTER_TEST(arguments, (u64)((unsigned __int128)machine_value >> 64) == UINT64_MAX);
                }
                BUSTER_TEST_RAW(arguments, cast_equal, cast_names[cast_index]);
                codegen_release_executable(cast_machine_executable);
            }
            codegen_release_executable(cast_none_module_executable);
        }
        {
            typedef __int128 MachineTestCallI8ToI128(signed char);
            typedef unsigned __int128 MachineTestCallU8ToU128(unsigned char);
            typedef __int128 MachineTestCallI16ToI128(short);
            typedef unsigned __int128 MachineTestCallU16ToU128(unsigned short);
            typedef __int128 MachineTestCallI32ToI128(int);
            typedef unsigned __int128 MachineTestCallU32ToU128(unsigned int);
            typedef unsigned __int128 MachineTestCallI128Reinterpret(__int128);
            typedef unsigned __int128 MachineTestCallU128Shift(unsigned __int128);
            String8 widening_names[] = {
                S8_INITIALIZER("i8_to_i128"), S8_INITIALIZER("u8_to_u128"), S8_INITIALIZER("i16_to_i128"), S8_INITIALIZER("u16_to_u128"),
                S8_INITIALIZER("i32_to_i128"), S8_INITIALIZER("u32_to_u128"), S8_INITIALIZER("i128_reinterpret"),
            };
            CodegenExecutable widening_none_executable = codegen_make_executable((CodegenFunction){.code = none_module.code});
            BUSTER_TEST(arguments, widening_none_executable.error == CODEGEN_ERROR_NONE);
            for (u32 widening_index = 0; widening_index < BUSTER_ARRAY_LENGTH(widening_names); widening_index += 1)
            {
                IrFunction* widening_function = machine_test_ir_function_find(machine_module, widening_names[widening_index]);
                BUSTER_TEST(arguments, widening_function != 0);
                if (!widening_function)
                {
                    continue;
                }
                MachineSelectResult widening_selected = {0};
                MachineEncodeResult widening_machine = machine_test_encode(arguments->arena, machine_program, widening_function, machine_target, &widening_selected);
                BUSTER_TEST(arguments, widening_selected.supported && widening_machine.valid);
                u32 none_offset = machine_test_module_offset(&none_module, machine_module, widening_names[widening_index]);
                BUSTER_TEST(arguments, none_offset != UINT32_MAX);
                CodegenExecutable widening_machine_executable = codegen_make_executable((CodegenFunction){
                    .code = {.pointer = widening_machine.bytes, .length = widening_machine.byte_count},
                });
                BUSTER_TEST(arguments, widening_machine_executable.error == CODEGEN_ERROR_NONE);
                if (none_offset == UINT32_MAX || !widening_machine_executable.address || !widening_none_executable.address)
                {
                    codegen_release_executable(widening_machine_executable);
                    continue;
                }
                void* none_address = (u8*)widening_none_executable.address + none_offset;
                void* machine_address = widening_machine_executable.address;
                bool equal = true;
                if (widening_index == 0)
                {
                    MachineTestCallI8ToI128* none_call = 0;
                    MachineTestCallI8ToI128* machine_call = 0;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    signed char values[] = {INT8_MIN, -1, 0, 1, INT8_MAX};
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                }
                else if (widening_index == 1)
                {
                    MachineTestCallU8ToU128* none_call = 0;
                    MachineTestCallU8ToU128* machine_call = 0;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    unsigned char values[] = {0, 1, 127, 128, UINT8_MAX};
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                }
                else if (widening_index == 2)
                {
                    MachineTestCallI16ToI128* none_call = 0;
                    MachineTestCallI16ToI128* machine_call = 0;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    short values[] = {INT16_MIN, -1, 0, 1, INT16_MAX};
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                }
                else if (widening_index == 3)
                {
                    MachineTestCallU16ToU128* none_call = 0;
                    MachineTestCallU16ToU128* machine_call = 0;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    unsigned short values[] = {0, 1, 32767, 32768, UINT16_MAX};
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                }
                else if (widening_index == 4)
                {
                    MachineTestCallI32ToI128* none_call = 0;
                    MachineTestCallI32ToI128* machine_call = 0;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    int values[] = {INT32_MIN, -1, 0, 1, INT32_MAX};
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                }
                else if (widening_index == 5)
                {
                    MachineTestCallU32ToU128* none_call = 0;
                    MachineTestCallU32ToU128* machine_call = 0;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    unsigned int values[] = {0, 1, UINT32_C(0x7fffffff), UINT32_C(0x80000000), UINT32_MAX};
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                }
                else
                {
                    MachineTestCallI128Reinterpret* none_call = 0;
                    MachineTestCallI128Reinterpret* machine_call = 0;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    __int128 values[] = {0, -1, -((__int128)1 << 126) - ((__int128)1 << 125)};
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                }
                BUSTER_TEST_RAW(arguments, equal, widening_names[widening_index]);
                codegen_release_executable(widening_machine_executable);
            }
            codegen_release_executable(widening_none_executable);

            String8 shift_names[] = {
                S8_INITIALIZER("u128_shr0"), S8_INITIALIZER("u128_shr1"), S8_INITIALIZER("u128_shr63"), S8_INITIALIZER("u128_shr64"),
                S8_INITIALIZER("u128_shr65"), S8_INITIALIZER("u128_shr127"),
            };
            for (u32 shift_index = 0; shift_index < BUSTER_ARRAY_LENGTH(shift_names); shift_index += 1)
            {
                IrFunction* shift_function = machine_test_ir_function_find(machine_module, shift_names[shift_index]);
                BUSTER_TEST(arguments, shift_function != 0);
                if (!shift_function)
                {
                    continue;
                }
                MachineSelectResult shift_selected = {0};
                MachineEncodeResult shift_machine = machine_test_encode(arguments->arena, machine_program, shift_function, machine_target, &shift_selected);
                BUSTER_TEST(arguments, shift_selected.supported && shift_machine.valid);
                u32 none_offset = machine_test_module_offset(&none_module, machine_module, shift_names[shift_index]);
                BUSTER_TEST(arguments, none_offset != UINT32_MAX);
                CodegenExecutable shift_none_executable = codegen_make_executable((CodegenFunction){.code = none_module.code});
                CodegenExecutable shift_machine_executable = codegen_make_executable((CodegenFunction){
                    .code = {.pointer = shift_machine.bytes, .length = shift_machine.byte_count},
                });
                BUSTER_TEST(arguments, shift_none_executable.error == CODEGEN_ERROR_NONE && shift_machine_executable.error == CODEGEN_ERROR_NONE);
                if (none_offset != UINT32_MAX && shift_none_executable.address && shift_machine_executable.address)
                {
                    MachineTestCallU128Shift* none_call = 0;
                    MachineTestCallU128Shift* machine_call = 0;
                    void* none_address = (u8*)shift_none_executable.address + none_offset;
                    void* machine_address = shift_machine_executable.address;
                    memcpy(&none_call, &none_address, sizeof(none_call));
                    memcpy(&machine_call, &machine_address, sizeof(machine_call));
                    unsigned __int128 values[] = {
                        0,
                        1,
                        UINT64_MAX,
                        ((unsigned __int128)UINT64_C(0x8000000000000001) << 64) | UINT64_C(0xdeadbeefcafebabe),
                        (unsigned __int128)UINT64_MAX << 64,
                    };
                    bool equal = true;
                    for (u32 value_index = 0; value_index < BUSTER_ARRAY_LENGTH(values); value_index += 1) equal &= none_call(values[value_index]) == machine_call(values[value_index]);
                    BUSTER_TEST_RAW(arguments, equal, shift_names[shift_index]);
                }
                codegen_release_executable(shift_machine_executable);
                codegen_release_executable(shift_none_executable);
            }
        }
#endif
        // Live-range splitting: split_phase must take at least one split — a value
        // register-resident for the first loop only, installed on the
        // entering edges and stored back at the landing pad — and the
        // placement must survive the pin verifier, since a degraded
        // placement reports zero splits. The traffic bound holds the
        // whole-placement acceptance to its meaning.
        IrFunction* split_function = machine_test_ir_function_find(machine_module, S8("split_phase"));
        BUSTER_TEST(arguments, split_function != 0);
        if (split_function)
        {
            MachineSelectResult split_selected = machine_select_canonical_function(arguments->arena, machine_program, split_function, machine_target);
            BUSTER_TEST(arguments, split_selected.supported);
            if (split_selected.supported)
            {
#if BUSTER_BENCH_ALLOCATIONS
                MachineQualityCensus census_before = machine_quality_census_snapshot();
#endif
                MachineStackPlacement split_quality = machine_quality_placement_build(arguments->arena, &split_selected.function);
#if BUSTER_BENCH_ALLOCATIONS
                MachineQualityCensus census_after = machine_quality_census_snapshot();
                MachineQualityCensus census = {0};
#define BUSTER_QUALITY_DELTA(name) census.name = census_after.name - census_before.name;
                BUSTER_QUALITY_CENSUS_FIELDS(BUSTER_QUALITY_DELTA)
#undef BUSTER_QUALITY_DELTA
                BUSTER_TEST(arguments, census.functions == 1 && census.prepassed_functions == 1);
                BUSTER_TEST(arguments, census.global_values == split_selected.function.virtual_register_count);
                BUSTER_TEST(arguments, census.local_values > 0 && census.local_values <= census.global_values);
                BUSTER_TEST(arguments, census.local_values_zero_functions + census.local_values_small_functions +
                                       census.local_values_tiled_functions + census.local_values_large_functions == 1);
                BUSTER_TEST(arguments, census.candidates > 0 && census.merged_regions > 0);
                BUSTER_TEST(arguments, census.closure_value_tests == census.global_values * census.merged_regions);
                BUSTER_TEST(arguments, census.closure_intersections <= census.closure_value_tests);
                BUSTER_TEST(arguments, census.region_values_zero_regions + census.region_values_small_regions +
                                       census.region_values_tiled_regions + census.region_values_large_regions == census.merged_regions);
                BUSTER_TEST(arguments, census.candidate_region_cells == census.candidates * census.merged_regions);
                BUSTER_TEST(arguments, census.candidate_region_nonzero_cells > 0 &&
                                       census.candidate_region_nonzero_cells <= census.candidate_region_cells);
                BUSTER_TEST(arguments, census.candidate_region_clear_bytes == census.candidates * 2 * sizeof(u32));
                BUSTER_TEST(arguments, census.initial_value_clear_bytes == census.global_values * (sizeof(MachineQualityTraffic) + 2 * sizeof(u32)));
                BUSTER_TEST(arguments, census.region_table_zero_functions + census.region_table_sparse_functions +
                                       census.region_table_mixed_functions + census.region_table_dense_functions == 1);
                BUSTER_TEST(arguments, census.heap_restore_bytes == census.heap_snapshot_bytes * census.attempts);
                BUSTER_TEST(arguments, census.region_selection_cells == census.selected_regions);
                BUSTER_TEST(arguments, census.selected_regions <= census.region_selection_passes);
                BUSTER_TEST(arguments, census.placement_probes <= census.attempts);
                BUSTER_TEST(arguments, census.accepted_placements == 1);
                // Reused dirty scratch must give identical counters and ordered
                // placement output. Compare initialized fields/arrays, not padding.
                MachineStackPlacement repeated = machine_quality_placement_build(arguments->arena, &split_selected.function);
                MachineQualityCensus census_repeated = machine_quality_census_snapshot();
#define BUSTER_QUALITY_REPEAT(name) BUSTER_TEST(arguments, census_repeated.name - census_after.name == census.name);
                BUSTER_QUALITY_CENSUS_FIELDS(BUSTER_QUALITY_REPEAT)
#undef BUSTER_QUALITY_REPEAT
                BUSTER_TEST(arguments, repeated.valid && repeated.edit_count == split_quality.edit_count &&
                                       repeated.frame_size == split_quality.frame_size && repeated.callee_saved_mask == split_quality.callee_saved_mask &&
                                       repeated.pinned_register_count == split_quality.pinned_register_count &&
                                       repeated.split_register_count == split_quality.split_register_count);
                if (repeated.valid && split_quality.valid && repeated.edit_count == split_quality.edit_count)
                {
                    for (u32 edit_index = 0; edit_index < repeated.edit_count; edit_index += 1)
                    {
                        MachineEdit left = split_quality.edits[edit_index];
                        MachineEdit right = repeated.edits[edit_index];
                        BUSTER_TEST(arguments, left.point == right.point && left.kind == right.kind && left.flags == right.flags &&
                                               left.subject == right.subject && left.location == right.location);
                    }
                    for (u64 slot = 0; slot < (u64)split_selected.function.instruction_count * 4; slot += 1)
                    {
                        BUSTER_TEST(arguments, split_quality.operand_registers[slot] == repeated.operand_registers[slot]);
                    }
                }
#endif
                MachineStackPlacement split_fast = machine_fast_placement_build(arguments->arena, &split_selected.function);
                BUSTER_TEST(arguments, split_quality.valid && split_fast.valid);
                BUSTER_TEST_RAW(arguments, split_quality.split_register_count + split_quality.pinned_register_count >= 1,
                                string_format(arguments->arena, S8("split_phase splits {u32} pins {u32}"), split_quality.split_register_count,
                                              split_quality.pinned_register_count));
                BUSTER_TEST(arguments, split_quality.reload_count + split_quality.spill_count < split_fast.reload_count + split_fast.spill_count);
            }
        }
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
        CodegenExecutable none_executable = codegen_make_executable((CodegenFunction){
            .code = none_module.code,
        });
        BUSTER_TEST(arguments, none_executable.error == CODEGEN_ERROR_NONE);
        typedef s64 MachineTestCall2(s64, s64);
        typedef s64 MachineTestCall6(s64, s64, s64, s64, s64, s64);
        for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(supported_names) && none_executable.address; name_index += 1)
        {
            if (!machine_encoded[name_index].valid)
            {
                continue;
            }
            // Functions touching global storage cannot execute from a raw
            // code copy: their data relocations only resolve at link time.
            // The full-unity soak is their execution proof.
            bool touches_globals = string_equal(supported_names[name_index], S8("bump")) ||
                                   string_equal(supported_names[name_index], S8("table_get")) ||
                                   string_equal(supported_names[name_index], S8("table_set")) ||
                                   string_equal(supported_names[name_index], S8("pair_sum"));
            // Call-containing functions execute only through the module
            // differential, where their call relocations resolve.
            bool contains_calls = string_equal(supported_names[name_index], S8("span_round_trip")) ||
                                  string_equal(supported_names[name_index], S8("kagg")) ||
                                  string_equal(supported_names[name_index], S8("vla_sum"));
            if (touches_globals || contains_calls)
            {
                continue;
            }
            IrFunction* ir_function = machine_test_ir_function_find(machine_module, supported_names[name_index]);
            u32 none_offset = UINT32_MAX;
            for (u32 entry_index = 0; entry_index < none_module.entry_count; entry_index += 1)
            {
                if (ir_function && none_module.entries[entry_index].symbol.value == ir_function->symbol.value)
                {
                    none_offset = none_module.entries[entry_index].offset;
                    break;
                }
            }
            BUSTER_TEST(arguments, none_offset != UINT32_MAX);
            CodegenExecutable machine_executable = codegen_make_executable((CodegenFunction){
                .code = {.pointer = machine_encoded[name_index].bytes, .length = machine_encoded[name_index].byte_count},
            });
            BUSTER_TEST(arguments, machine_executable.error == CODEGEN_ERROR_NONE);
            if (none_offset == UINT32_MAX || !machine_executable.address)
            {
                continue;
            }
            bool is_writep = string_equal(supported_names[name_index], S8("writep"));
            bool is_readp = string_equal(supported_names[name_index], S8("readp"));
            bool is_six = string_equal(supported_names[name_index], S8("six"));
            bool is_loop = string_equal(supported_names[name_index], S8("sum_to"));
            // Functions declared to return `long` promise all sixty-four
            // result bits; `int` returns compare only the low thirty-two,
            // because the canonical and machine paths may legitimately leave
            // different stale upper bits in RAX.
            bool wide_result = string_equal(supported_names[name_index], S8("widen")) ||
                               string_equal(supported_names[name_index], S8("bitnot")) ||
                               string_equal(supported_names[name_index], S8("sar")) ||
                               string_equal(supported_names[name_index], S8("udiv")) ||
                               string_equal(supported_names[name_index], S8("union_tail")) || is_readp;
            bool is_division = string_equal(supported_names[name_index], S8("divide")) ||
                               string_equal(supported_names[name_index], S8("srem")) ||
                               string_equal(supported_names[name_index], S8("udiv"));
            s64 probe_arguments[][2] = {
                {0, 0}, {1, 2}, {-1, 5}, {123456789, -987654321}, {-2147483647, 2147483647}, {40, 2}, {7, -7},
            };
            bool all_equal = true;
            for (u32 probe_index = 0; probe_index < BUSTER_ARRAY_LENGTH(probe_arguments); probe_index += 1)
            {
                s64 left = probe_arguments[probe_index][0];
                s64 right = probe_arguments[probe_index][1];
                if (is_loop)
                {
                    // Keep iteration counts test-sized.
                    left &= 63;
                }
                if (is_division)
                {
                    // Never probe a zero divisor; odd divisors also keep the
                    // signed INT_MIN/-1 overflow case out of the grid.
                    right |= 1;
                }
                void* none_address = (u8*)none_executable.address + none_offset;
                void* machine_address = machine_executable.address;
                MachineTestCall2* none_call = 0;
                MachineTestCall2* machine_call = 0;
                memcpy(&none_call, &none_address, sizeof(none_call));
                memcpy(&machine_call, &machine_address, sizeof(machine_call));
                if (is_writep)
                {
                    s32 none_cell = 0;
                    s32 machine_cell = 0;
                    none_call((s64)(u64)&none_cell, right);
                    machine_call((s64)(u64)&machine_cell, right);
                    all_equal &= none_cell == machine_cell;
                }
                else if (is_readp)
                {
                    s64 cell = left * 3 + right;
                    all_equal &= none_call((s64)(u64)&cell, 0) == machine_call((s64)(u64)&cell, 0);
                }
                else if (is_six)
                {
                    MachineTestCall6* none_call6 = 0;
                    MachineTestCall6* machine_call6 = 0;
                    memcpy(&none_call6, &none_address, sizeof(none_call6));
                    memcpy(&machine_call6, &machine_address, sizeof(machine_call6));
                    s32 none_result = (s32)none_call6(left, right, left + 1, right + 1, left - 2, right - 2);
                    s32 machine_result = (s32)machine_call6(left, right, left + 1, right + 1, left - 2, right - 2);
                    BUSTER_TEST_RAW(arguments, none_result == machine_result,
                                    string_format(arguments->arena, S8("six none={u64} machine={u64}"), (u64)(u32)none_result, (u64)(u32)machine_result));
                    all_equal &= none_result == machine_result;
                }
                else if (wide_result)
                {
                    all_equal &= none_call(left, right) == machine_call(left, right);
                }
                else
                {
                    s64 none_value = none_call(left, right);
                    s64 machine_value = machine_call(left, right);
                    all_equal &= (s32)none_value == (s32)machine_value;
                }
            }
            BUSTER_TEST_RAW(arguments, all_equal, supported_names[name_index]);
            codegen_release_executable(machine_executable);
        }
        codegen_release_executable(none_executable);
#endif
        // Stage 3 wiring: the same module generated under MIR_STACK routes
        // every eligible function through the machine path and counts the
        // rest as explicit fallbacks; the canonical NONE module is the
        // execution oracle for both kinds.
        CodegenModule mir_module = codegen_generate_canonical_module(arguments->arena, machine_program, machine_module, machine_target,
                                                                     (CodegenModuleOptions){
                                                                         .register_allocator = CODEGEN_REGISTER_ALLOCATOR_MIR_STACK,
                                                                     });
        BUSTER_TEST(arguments, mir_module.error == CODEGEN_ERROR_NONE);
        BUSTER_TEST(arguments, mir_module.statistics.exact_attempts >= 1);
        BUSTER_TEST(arguments, mir_module.statistics.exact_successes == mir_module.statistics.exact_attempts);
        BUSTER_TEST(arguments, mir_module.statistics.exact_failures == 0);
        BUSTER_TEST(arguments, none_module.statistics.fallback_function_count == 0);
        BUSTER_TEST_RAW(arguments, mir_module.statistics.fallback_function_count == 0,
                        string_format(arguments->arena, S8("mir fallbacks {u32}"), mir_module.statistics.fallback_function_count));
        IrFunction* mir_add_function = machine_test_ir_function_find(machine_module, S8("add"));
        if (mir_add_function)
        {
            CodegenFunctionDescriptor* mir_add_descriptor = 0;
            for (u32 descriptor_index = 0; descriptor_index < mir_module.function_count; descriptor_index += 1)
            {
                if (mir_module.functions[descriptor_index].symbol.value == mir_add_function->symbol.value)
                {
                    mir_add_descriptor = mir_module.functions + descriptor_index;
                    break;
                }
            }
            BUSTER_TEST(arguments, mir_add_descriptor != 0);
            BUSTER_TEST(arguments, mir_add_descriptor && mir_add_descriptor->code_size > 8);
            BUSTER_TEST(arguments, mir_add_descriptor && mir_add_descriptor->unwind_action_count >= 2 &&
                                       mir_add_descriptor->unwind_actions[0].kind == CODEGEN_UNWIND_ACTION_PUSH_REGISTER);
            // Frameless prologues stop after the frame-pointer setup; framed
            // ones add a chunked subtract (imm8 or imm32) and a probe touch.
            BUSTER_TEST(arguments, mir_add_descriptor &&
                                       (mir_add_descriptor->prolog_size == 4 || mir_add_descriptor->prolog_size == 12 || mir_add_descriptor->prolog_size == 15));
        }
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
        // Both modules resolve their internal direct-call relocations the
        // way the linker would, so machine-to-machine calls execute; this
        // must happen before the executable copies are taken.
        for (u32 relocation_index = 0; relocation_index < none_module.relocation_count + mir_module.relocation_count; relocation_index += 1)
        {
            CodegenModule* patched = relocation_index < none_module.relocation_count ? &none_module : &mir_module;
            u32 local_index = relocation_index < none_module.relocation_count ? relocation_index : relocation_index - none_module.relocation_count;
            CodegenModuleRelocation* relocation = patched->relocations + local_index;
            BUSTER_TEST(arguments, codegen_module_relocation_valid(relocation));
            if (relocation->source != CODEGEN_MODULE_RELOCATION_CODE || codegen_module_relocation_kind_is_absolute(relocation->kind))
            {
                continue;
            }
            for (u32 entry_index = 0; entry_index < patched->entry_count; entry_index += 1)
            {
                if (patched->entries[entry_index].symbol.value == relocation->symbol.value)
                {
                    u32 displacement = patched->entries[entry_index].offset - (relocation->offset + 4);
                    memcpy(patched->code.pointer + relocation->offset, &displacement, sizeof(displacement));
                    break;
                }
            }
        }
        CodegenExecutable none_module_executable = codegen_make_executable((CodegenFunction){
            .code = none_module.code,
        });
        CodegenExecutable mir_module_executable = codegen_make_executable((CodegenFunction){
            .code = mir_module.code,
        });
        BUSTER_TEST(arguments, none_module_executable.error == CODEGEN_ERROR_NONE && mir_module_executable.error == CODEGEN_ERROR_NONE);
        String8 module_names[] = {
            S8_INITIALIZER("add"), S8_INITIALIZER("mul"), S8_INITIALIZER("widen"), S8_INITIALIZER("narrow"),
            S8_INITIALIZER("negate"), S8_INITIALIZER("bitnot"), S8_INITIALIZER("lnot"), S8_INITIALIZER("less"),
            S8_INITIALIZER("uless"), S8_INITIALIZER("sum_to"), S8_INITIALIZER("divide"), S8_INITIALIZER("with_call"),
            S8_INITIALIZER("locals_array"), S8_INITIALIZER("local_pair"), S8_INITIALIZER("pick"),
            S8_INITIALIZER("aligned_local"), S8_INITIALIZER("span_round_trip"), S8_INITIALIZER("single_round_trip"), S8_INITIALIZER("fmath"),
            S8_INITIALIZER("fcompare"), S8_INITIALIZER("fnan"), S8_INITIALIZER("call_stack"), S8_INITIALIZER("big_round"),
            S8_INITIALIZER("call_indirect"), S8_INITIALIZER("atomic_ops"), S8_INITIALIZER("kagg"), S8_INITIALIZER("vla_sum"),
            S8_INITIALIZER("variadic_named"), S8_INITIALIZER("variadic_named_caller"), S8_INITIALIZER("variadic_observe_caller"),
        };
        typedef s64 MachineTestModuleCall2(s64, s64);
        for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(module_names) && none_module_executable.address && mir_module_executable.address;
             name_index += 1)
        {
            IrFunction* module_function = machine_test_ir_function_find(machine_module, module_names[name_index]);
            u32 none_offset = UINT32_MAX;
            u32 mir_offset = UINT32_MAX;
            for (u32 entry_index = 0; module_function && entry_index < none_module.entry_count; entry_index += 1)
            {
                if (none_module.entries[entry_index].symbol.value == module_function->symbol.value)
                {
                    none_offset = none_module.entries[entry_index].offset;
                }
            }
            for (u32 entry_index = 0; module_function && entry_index < mir_module.entry_count; entry_index += 1)
            {
                if (mir_module.entries[entry_index].symbol.value == module_function->symbol.value)
                {
                    mir_offset = mir_module.entries[entry_index].offset;
                }
            }
            BUSTER_TEST(arguments, none_offset != UINT32_MAX && mir_offset != UINT32_MAX);
            if (none_offset == UINT32_MAX || mir_offset == UINT32_MAX)
            {
                continue;
            }
            bool module_wide = string_equal(module_names[name_index], S8("widen")) || string_equal(module_names[name_index], S8("bitnot"));
            bool module_loop = string_equal(module_names[name_index], S8("sum_to"));
            s64 module_probes[][2] = {
                {5, 3}, {-7, 9}, {0, 1}, {2147483646, -2},
            };
            bool module_equal = true;
            for (u32 probe_index = 0; probe_index < BUSTER_ARRAY_LENGTH(module_probes); probe_index += 1)
            {
                s64 left = module_probes[probe_index][0];
                s64 right = module_probes[probe_index][1];
                if (module_loop)
                {
                    left &= 63;
                }
                void* none_address = (u8*)none_module_executable.address + none_offset;
                void* mir_address = (u8*)mir_module_executable.address + mir_offset;
                MachineTestModuleCall2* none_call = 0;
                MachineTestModuleCall2* mir_call = 0;
                memcpy(&none_call, &none_address, sizeof(none_call));
                memcpy(&mir_call, &mir_address, sizeof(mir_call));
                if (module_wide)
                {
                    module_equal &= none_call(left, right) == mir_call(left, right);
                }
                else
                {
                    module_equal &= (s32)none_call(left, right) == (s32)mir_call(left, right);
                }
            }
            BUSTER_TEST_RAW(arguments, module_equal, module_names[name_index]);
        }
        // Splitting executing differential: the QUALITY module carries the
        // split placement of split_phase — the entry installs, the span
        // itself, and the landing-pad stores — against the canonical
        // oracle, including a zero-round probe where the installs and
        // stores run but neither loop body does.
        CodegenModule quality_module = codegen_generate_canonical_module(arguments->arena, machine_program, machine_module, machine_target,
                                                                         (CodegenModuleOptions){
                                                                             .register_allocator = CODEGEN_REGISTER_ALLOCATOR_QUALITY,
                                                                         });
        BUSTER_TEST(arguments, quality_module.error == CODEGEN_ERROR_NONE);
        BUSTER_TEST(arguments, quality_module.statistics.exact_attempts >= 1);
        BUSTER_TEST(arguments, quality_module.statistics.exact_successes == quality_module.statistics.exact_attempts);
        BUSTER_TEST(arguments, quality_module.statistics.exact_failures == 0);
        for (u32 relocation_index = 0; relocation_index < quality_module.relocation_count; relocation_index += 1)
        {
            CodegenModuleRelocation* relocation = quality_module.relocations + relocation_index;
            BUSTER_TEST(arguments, codegen_module_relocation_valid(relocation));
            if (relocation->source != CODEGEN_MODULE_RELOCATION_CODE || codegen_module_relocation_kind_is_absolute(relocation->kind))
            {
                continue;
            }
            for (u32 entry_index = 0; entry_index < quality_module.entry_count; entry_index += 1)
            {
                if (quality_module.entries[entry_index].symbol.value == relocation->symbol.value)
                {
                    u32 displacement = quality_module.entries[entry_index].offset - (relocation->offset + 4);
                    memcpy(quality_module.code.pointer + relocation->offset, &displacement, sizeof(displacement));
                    break;
                }
            }
        }
        CodegenExecutable quality_module_executable = codegen_make_executable((CodegenFunction){
            .code = quality_module.code,
        });
        BUSTER_TEST(arguments, quality_module_executable.error == CODEGEN_ERROR_NONE);
        u32 split_none_offset = machine_test_module_offset(&none_module, machine_module, S8("split_phase"));
        u32 split_quality_offset = machine_test_module_offset(&quality_module, machine_module, S8("split_phase"));
        BUSTER_TEST(arguments, split_none_offset != UINT32_MAX && split_quality_offset != UINT32_MAX);
        if (none_module_executable.address && quality_module_executable.address && split_none_offset != UINT32_MAX &&
            split_quality_offset != UINT32_MAX)
        {
            typedef u64 MachineTestSplitCall(u64, u64);
            void* split_none_address = (u8*)none_module_executable.address + split_none_offset;
            void* split_quality_address = (u8*)quality_module_executable.address + split_quality_offset;
            MachineTestSplitCall* split_none_call = 0;
            MachineTestSplitCall* split_quality_call = 0;
            memcpy(&split_none_call, &split_none_address, sizeof(split_none_call));
            memcpy(&split_quality_call, &split_quality_address, sizeof(split_quality_call));
            u64 split_probes[][2] = {
                {0x9e3779b97f4a7c15ull, 12}, {5, 7}, {0xffffffffffffffffull, 3}, {123456789, 0}, {0, 1},
            };
            for (u32 probe_index = 0; probe_index < BUSTER_ARRAY_LENGTH(split_probes); probe_index += 1)
            {
                u64 none_result = split_none_call(split_probes[probe_index][0], split_probes[probe_index][1]);
                u64 quality_result = split_quality_call(split_probes[probe_index][0], split_probes[probe_index][1]);
                BUSTER_TEST_RAW(arguments, none_result == quality_result,
                                string_format(arguments->arena, S8("split_phase probe {u64} none {u64} quality {u64}"), split_probes[probe_index][1],
                                              none_result, quality_result));
            }
        }
        codegen_release_executable(quality_module_executable);
        // Float-signature shapes need typed callers: XMM scalars, mixed
        // integer/float argument sequences, all-float and mixed aggregates,
        // aggregate float returns, and machine-to-machine float calls.
        if (none_module_executable.address && mir_module_executable.address)
        {
            typedef double MachineTestCallD2(double, double);
            typedef double MachineTestCallDMix(int, double, long, double);
            typedef float MachineTestCallF2(float, float);
            typedef struct MachineTestDPair
            {
                double x;
                double y;
            } MachineTestDPair;
            typedef double MachineTestCallDPairSum(MachineTestDPair);
            typedef MachineTestDPair MachineTestCallDPairMake(double, double);
            typedef struct MachineTestTagged
            {
                s64 tag;
                double v;
            } MachineTestTagged;
            typedef double MachineTestCallTagged(MachineTestTagged);
            typedef int MachineTestCallI7(int, int, int, int, int, int, int);
            typedef s64 MachineTestCallStackMix(int, int, int, int, int, int, int, s64);
            typedef double MachineTestCallD9(double, double, double, double, double, double, double, double, double);
            String8 float_names[] = {
                S8_INITIALIZER("dadd"), S8_INITIALIZER("dmix"), S8_INITIALIZER("fhalf"), S8_INITIALIZER("dpair_sum"),
                S8_INITIALIZER("dpair_make"), S8_INITIALIZER("tagged_get"), S8_INITIALIZER("dcall"),
                S8_INITIALIZER("seven"), S8_INITIALIZER("stack_mix"), S8_INITIALIZER("nine"),
            };
            void* none_addresses[BUSTER_ARRAY_LENGTH(float_names)];
            void* mir_addresses[BUSTER_ARRAY_LENGTH(float_names)];
            bool float_offsets_found = true;
            for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(float_names); name_index += 1)
            {
                u32 none_offset = machine_test_module_offset(&none_module, machine_module, float_names[name_index]);
                u32 mir_offset = machine_test_module_offset(&mir_module, machine_module, float_names[name_index]);
                float_offsets_found &= none_offset != UINT32_MAX && mir_offset != UINT32_MAX;
                none_addresses[name_index] = none_offset != UINT32_MAX ? (u8*)none_module_executable.address + none_offset : 0;
                mir_addresses[name_index] = mir_offset != UINT32_MAX ? (u8*)mir_module_executable.address + mir_offset : 0;
            }
            BUSTER_TEST(arguments, float_offsets_found);
            if (float_offsets_found)
            {
                MachineTestCallD2* none_dadd;
                MachineTestCallD2* mir_dadd;
                MachineTestCallDMix* none_dmix;
                MachineTestCallDMix* mir_dmix;
                MachineTestCallF2* none_fhalf;
                MachineTestCallF2* mir_fhalf;
                MachineTestCallDPairSum* none_dpair_sum;
                MachineTestCallDPairSum* mir_dpair_sum;
                MachineTestCallDPairMake* none_dpair_make;
                MachineTestCallDPairMake* mir_dpair_make;
                MachineTestCallTagged* none_tagged;
                MachineTestCallTagged* mir_tagged;
                MachineTestCallD2* none_dcall;
                MachineTestCallD2* mir_dcall;
                memcpy(&none_dadd, none_addresses + 0, sizeof(none_dadd));
                memcpy(&mir_dadd, mir_addresses + 0, sizeof(mir_dadd));
                memcpy(&none_dmix, none_addresses + 1, sizeof(none_dmix));
                memcpy(&mir_dmix, mir_addresses + 1, sizeof(mir_dmix));
                memcpy(&none_fhalf, none_addresses + 2, sizeof(none_fhalf));
                memcpy(&mir_fhalf, mir_addresses + 2, sizeof(mir_fhalf));
                memcpy(&none_dpair_sum, none_addresses + 3, sizeof(none_dpair_sum));
                memcpy(&mir_dpair_sum, mir_addresses + 3, sizeof(mir_dpair_sum));
                memcpy(&none_dpair_make, none_addresses + 4, sizeof(none_dpair_make));
                memcpy(&mir_dpair_make, mir_addresses + 4, sizeof(mir_dpair_make));
                memcpy(&none_tagged, none_addresses + 5, sizeof(none_tagged));
                memcpy(&mir_tagged, mir_addresses + 5, sizeof(mir_tagged));
                memcpy(&none_dcall, none_addresses + 6, sizeof(none_dcall));
                memcpy(&mir_dcall, mir_addresses + 6, sizeof(mir_dcall));
                BUSTER_TEST(arguments, none_dadd(1.5, 2.25) == mir_dadd(1.5, 2.25));
                BUSTER_TEST(arguments, none_dadd(-0.125, 1e100) == mir_dadd(-0.125, 1e100));
                BUSTER_TEST(arguments, none_dmix(3, 1.5, -2, 0.25) == mir_dmix(3, 1.5, -2, 0.25));
                BUSTER_TEST(arguments, none_fhalf(7.5f, 2.5f) == mir_fhalf(7.5f, 2.5f));
                MachineTestDPair pair_probe = {3.5, -4.25};
                BUSTER_TEST(arguments, none_dpair_sum(pair_probe) == mir_dpair_sum(pair_probe));
                MachineTestDPair none_made = none_dpair_make(1.25, -8.5);
                MachineTestDPair mir_made = mir_dpair_make(1.25, -8.5);
                BUSTER_TEST(arguments, none_made.x == mir_made.x && none_made.y == mir_made.y);
                MachineTestTagged tagged_probe = {7, 9.5};
                MachineTestTagged tagged_zero = {0, 2.5};
                BUSTER_TEST(arguments, none_tagged(tagged_probe) == mir_tagged(tagged_probe));
                BUSTER_TEST(arguments, none_tagged(tagged_zero) == mir_tagged(tagged_zero));
                BUSTER_TEST(arguments, none_dcall(2.5, 4.0) == mir_dcall(2.5, 4.0));
                MachineTestCallI7* none_seven;
                MachineTestCallI7* mir_seven;
                MachineTestCallStackMix* none_stack_mix;
                MachineTestCallStackMix* mir_stack_mix;
                MachineTestCallD9* none_nine;
                MachineTestCallD9* mir_nine;
                memcpy(&none_seven, none_addresses + 7, sizeof(none_seven));
                memcpy(&mir_seven, mir_addresses + 7, sizeof(mir_seven));
                memcpy(&none_stack_mix, none_addresses + 8, sizeof(none_stack_mix));
                memcpy(&mir_stack_mix, mir_addresses + 8, sizeof(mir_stack_mix));
                memcpy(&none_nine, none_addresses + 9, sizeof(none_nine));
                memcpy(&mir_nine, mir_addresses + 9, sizeof(mir_nine));
                BUSTER_TEST(arguments, none_seven(1, 2, 3, 4, 5, 6, 70) == mir_seven(1, 2, 3, 4, 5, 6, 70));
                BUSTER_TEST(arguments, none_stack_mix(1, 2, 3, 4, 5, 6, 7, -11) == mir_stack_mix(1, 2, 3, 4, 5, 6, 7, -11));
                BUSTER_TEST(arguments,
                            none_nine(1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, -0.25) == mir_nine(1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, -0.25));
                typedef struct MachineTestBig
                {
                    s64 a;
                    s64 b;
                    s64 c;
                } MachineTestBig;
                typedef MachineTestBig MachineTestCallBigMake(s64);
                typedef s64 MachineTestCallBigSum(MachineTestBig);
                u32 none_big_make_offset = machine_test_module_offset(&none_module, machine_module, S8("big_make"));
                u32 mir_big_make_offset = machine_test_module_offset(&mir_module, machine_module, S8("big_make"));
                u32 none_big_sum_offset = machine_test_module_offset(&none_module, machine_module, S8("big_sum"));
                u32 mir_big_sum_offset = machine_test_module_offset(&mir_module, machine_module, S8("big_sum"));
                BUSTER_TEST(arguments, none_big_make_offset != UINT32_MAX && mir_big_make_offset != UINT32_MAX &&
                                           none_big_sum_offset != UINT32_MAX && mir_big_sum_offset != UINT32_MAX);
                if (none_big_make_offset != UINT32_MAX && mir_big_make_offset != UINT32_MAX && none_big_sum_offset != UINT32_MAX &&
                    mir_big_sum_offset != UINT32_MAX)
                {
                    MachineTestCallBigMake* none_big_make;
                    MachineTestCallBigMake* mir_big_make;
                    MachineTestCallBigSum* none_big_sum;
                    MachineTestCallBigSum* mir_big_sum;
                    void* none_big_make_address = (u8*)none_module_executable.address + none_big_make_offset;
                    void* mir_big_make_address = (u8*)mir_module_executable.address + mir_big_make_offset;
                    void* none_big_sum_address = (u8*)none_module_executable.address + none_big_sum_offset;
                    void* mir_big_sum_address = (u8*)mir_module_executable.address + mir_big_sum_offset;
                    memcpy(&none_big_make, &none_big_make_address, sizeof(none_big_make));
                    memcpy(&mir_big_make, &mir_big_make_address, sizeof(mir_big_make));
                    memcpy(&none_big_sum, &none_big_sum_address, sizeof(none_big_sum));
                    memcpy(&mir_big_sum, &mir_big_sum_address, sizeof(mir_big_sum));
                    MachineTestBig none_big = none_big_make(37);
                    MachineTestBig mir_big = mir_big_make(37);
                    BUSTER_TEST(arguments, none_big.a == mir_big.a && none_big.b == mir_big.b && none_big.c == mir_big.c);
                    BUSTER_TEST(arguments, none_big_sum(none_big) == mir_big_sum(mir_big));
                }
            }
        }
        // The fast allocator is a drop-in placement replacement: the same
        // module through FAST must behave identically to the oracle while
        // producing strictly less slot traffic than MIR_STACK.
        CodegenModule fast_module = codegen_generate_canonical_module(arguments->arena, machine_program, machine_module, machine_target,
                                                                      (CodegenModuleOptions){
                                                                          .register_allocator = CODEGEN_REGISTER_ALLOCATOR_FAST,
                                                                      });
        BUSTER_TEST(arguments, fast_module.error == CODEGEN_ERROR_NONE);
        BUSTER_TEST(arguments, fast_module.statistics.exact_attempts >= 1);
        BUSTER_TEST(arguments, fast_module.statistics.exact_successes == fast_module.statistics.exact_attempts);
        BUSTER_TEST(arguments, fast_module.statistics.exact_failures == 0);
        BUSTER_TEST(arguments, fast_module.statistics.fallback_function_count == mir_module.statistics.fallback_function_count);
        for (u32 relocation_index = 0; relocation_index < fast_module.relocation_count; relocation_index += 1)
        {
            CodegenModuleRelocation* relocation = fast_module.relocations + relocation_index;
            BUSTER_TEST(arguments, codegen_module_relocation_valid(relocation));
            if (relocation->source != CODEGEN_MODULE_RELOCATION_CODE || codegen_module_relocation_kind_is_absolute(relocation->kind))
            {
                continue;
            }
            for (u32 entry_index = 0; entry_index < fast_module.entry_count; entry_index += 1)
            {
                if (fast_module.entries[entry_index].symbol.value == relocation->symbol.value)
                {
                    u32 displacement = fast_module.entries[entry_index].offset - (relocation->offset + 4);
                    memcpy(fast_module.code.pointer + relocation->offset, &displacement, sizeof(displacement));
                    break;
                }
            }
        }
        CodegenExecutable fast_module_executable = codegen_make_executable((CodegenFunction){
            .code = fast_module.code,
        });
        BUSTER_TEST(arguments, fast_module_executable.error == CODEGEN_ERROR_NONE);
        for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(module_names) && none_module_executable.address && fast_module_executable.address;
             name_index += 1)
        {
            u32 none_offset = machine_test_module_offset(&none_module, machine_module, module_names[name_index]);
            u32 fast_offset = machine_test_module_offset(&fast_module, machine_module, module_names[name_index]);
            BUSTER_TEST(arguments, none_offset != UINT32_MAX && fast_offset != UINT32_MAX);
            if (none_offset == UINT32_MAX || fast_offset == UINT32_MAX)
            {
                continue;
            }
            bool fast_wide = string_equal(module_names[name_index], S8("widen")) || string_equal(module_names[name_index], S8("bitnot"));
            bool fast_loop = string_equal(module_names[name_index], S8("sum_to"));
            s64 fast_probes[][2] = {
                {6, 2}, {-9, 13}, {0, 1},
            };
            bool fast_equal = true;
            for (u32 probe_index = 0; probe_index < BUSTER_ARRAY_LENGTH(fast_probes); probe_index += 1)
            {
                s64 left = fast_probes[probe_index][0];
                s64 right = fast_probes[probe_index][1];
                if (fast_loop)
                {
                    left &= 63;
                }
                void* none_address = (u8*)none_module_executable.address + none_offset;
                void* fast_address = (u8*)fast_module_executable.address + fast_offset;
                MachineTestModuleCall2* none_call = 0;
                MachineTestModuleCall2* fast_call = 0;
                memcpy(&none_call, &none_address, sizeof(none_call));
                memcpy(&fast_call, &fast_address, sizeof(fast_call));
                if (fast_wide)
                {
                    fast_equal &= none_call(left, right) == fast_call(left, right);
                }
                else
                {
                    fast_equal &= (s32)none_call(left, right) == (s32)fast_call(left, right);
                }
            }
            BUSTER_TEST_RAW(arguments, fast_equal, module_names[name_index]);
        }
        // Six register arguments exercise the entry captures: an eager pick
        // must not clobber an incoming argument register before its own
        // capture reads it.
        if (none_module_executable.address && fast_module_executable.address)
        {
            u32 none_offset = machine_test_module_offset(&none_module, machine_module, S8("six"));
            u32 fast_offset = machine_test_module_offset(&fast_module, machine_module, S8("six"));
            BUSTER_TEST(arguments, none_offset != UINT32_MAX && fast_offset != UINT32_MAX);
            if (none_offset != UINT32_MAX && fast_offset != UINT32_MAX)
            {
                void* none_address = (u8*)none_module_executable.address + none_offset;
                void* fast_address = (u8*)fast_module_executable.address + fast_offset;
                MachineTestCall6* none_call6 = 0;
                MachineTestCall6* fast_call6 = 0;
                memcpy(&none_call6, &none_address, sizeof(none_call6));
                memcpy(&fast_call6, &fast_address, sizeof(fast_call6));
                s32 none_result = (s32)none_call6(1, 20, 300, 4000, 50000, 600000);
                s32 fast_result = (s32)fast_call6(1, 20, 300, 4000, 50000, 600000);
                BUSTER_TEST_RAW(arguments, none_result == fast_result,
                                string_format(arguments->arena, S8("fast six none={u64} fast={u64}"), (u64)(u32)none_result, (u64)(u32)fast_result));
            }
        }
        // The canonical emitter's own entry captures. An array-syntax
        // parameter puts its bound arithmetic between the parameter homes,
        // and that multiply takes RAX and RCX, so a NONE-emitted body that
        // homes RCX afterwards reads the multiplier instead of its fourth
        // argument. Both shapes are checked against the value the C says, not
        // only against each other: NONE is the differential oracle everywhere
        // else here, so a wrong oracle has to be caught absolutely.
        if (none_module_executable.address && fast_module_executable.address)
        {
            typedef s64 MachineTestArrayParamCall(unsigned char const*, s64, s64, s64);
            typedef s64 MachineTestVlaParamCall(s64, unsigned char const*, s64, s64);
            unsigned char entry_capture_slots[2] = {7, 8};
            u32 none_array_offset = machine_test_module_offset(&none_module, machine_module, S8("arr_param"));
            u32 fast_array_offset = machine_test_module_offset(&fast_module, machine_module, S8("arr_param"));
            u32 none_vla_offset = machine_test_module_offset(&none_module, machine_module, S8("vla_param"));
            u32 fast_vla_offset = machine_test_module_offset(&fast_module, machine_module, S8("vla_param"));
            BUSTER_TEST(arguments, none_array_offset != UINT32_MAX && fast_array_offset != UINT32_MAX && none_vla_offset != UINT32_MAX &&
                                       fast_vla_offset != UINT32_MAX);
            if (none_array_offset != UINT32_MAX && fast_array_offset != UINT32_MAX)
            {
                void* none_address = (u8*)none_module_executable.address + none_array_offset;
                void* fast_address = (u8*)fast_module_executable.address + fast_array_offset;
                MachineTestArrayParamCall* none_array_call = 0;
                MachineTestArrayParamCall* fast_array_call = 0;
                memcpy(&none_array_call, &none_address, sizeof(none_array_call));
                memcpy(&fast_array_call, &fast_address, sizeof(fast_array_call));
                s64 none_array_result = none_array_call(entry_capture_slots, 2, 3, 4);
                s64 fast_array_result = fast_array_call(entry_capture_slots, 2, 3, 4);
                BUSTER_TEST_RAW(arguments, none_array_result == 7234 && fast_array_result == 7234,
                                string_format(arguments->arena, S8("arr_param none={s64} fast={s64} want 7234"), none_array_result,
                                              fast_array_result));
            }
            if (none_vla_offset != UINT32_MAX && fast_vla_offset != UINT32_MAX)
            {
                void* none_address = (u8*)none_module_executable.address + none_vla_offset;
                void* fast_address = (u8*)fast_module_executable.address + fast_vla_offset;
                MachineTestVlaParamCall* none_vla_call = 0;
                MachineTestVlaParamCall* fast_vla_call = 0;
                memcpy(&none_vla_call, &none_address, sizeof(none_vla_call));
                memcpy(&fast_vla_call, &fast_address, sizeof(fast_vla_call));
                s64 none_vla_result = none_vla_call(2, entry_capture_slots, 3, 4);
                s64 fast_vla_result = fast_vla_call(2, entry_capture_slots, 3, 4);
                BUSTER_TEST_RAW(arguments, none_vla_result == 8234 && fast_vla_result == 8234,
                                string_format(arguments->arena, S8("vla_param none={s64} fast={s64} want 8234"), none_vla_result, fast_vla_result));
            }
        }
        codegen_release_executable(fast_module_executable);
        // The loop-heavy body must see strictly fewer reloads and spills
        // under the fast allocator than under the everything-in-slots mode.
        IrFunction* traffic_function = machine_test_ir_function_find(machine_module, S8("sum_to"));
        if (traffic_function)
        {
            MachineSelectResult traffic_selected = machine_select_canonical_function(arguments->arena, machine_program, traffic_function, machine_target);
            BUSTER_TEST(arguments, traffic_selected.supported);
            if (traffic_selected.supported)
            {
                MachineStackPlacement stack_placement = machine_stack_placement_build(arguments->arena, &traffic_selected.function);
                MachineStackPlacement fast_placement = machine_fast_placement_build(arguments->arena, &traffic_selected.function);
                BUSTER_TEST(arguments, stack_placement.valid && fast_placement.valid);
                BUSTER_TEST_RAW(arguments,
                                fast_placement.reload_count + fast_placement.spill_count <
                                    stack_placement.reload_count + stack_placement.spill_count,
                                string_format(arguments->arena, S8("fast traffic {u32}+{u32} vs stack {u32}+{u32}"), fast_placement.reload_count,
                                              fast_placement.spill_count, stack_placement.reload_count, stack_placement.spill_count));
                // Coalescing must survive: copies whose source dies land on
                // the source register and encode to nothing, so the fast
                // encoding stays strictly smaller than the stack one.
                // QUALITY must be at least as correct and never spill more
                // than the local scan it is built on.
                MachineStackPlacement quality_placement = machine_quality_placement_build(arguments->arena, &traffic_selected.function);
                BUSTER_TEST(arguments, quality_placement.valid);
                BUSTER_TEST_RAW(arguments,
                                quality_placement.reload_count + quality_placement.spill_count <=
                                    stack_placement.reload_count + stack_placement.spill_count,
                                string_format(arguments->arena, S8("quality traffic {u32}+{u32} vs stack {u32}+{u32}"), quality_placement.reload_count,
                                              quality_placement.spill_count, stack_placement.reload_count, stack_placement.spill_count));
                MachineEncodeResult stack_encoded = machine_encode_x86_64(arguments->arena, &traffic_selected.function, &stack_placement);
                MachineEncodeResult fast_encoded = machine_encode_x86_64(arguments->arena, &traffic_selected.function, &fast_placement);
                BUSTER_TEST(arguments, stack_encoded.valid && fast_encoded.valid);
                BUSTER_TEST_RAW(arguments, fast_encoded.byte_count < stack_encoded.byte_count,
                                string_format(arguments->arena, S8("fast bytes {u32} vs stack {u32}"), fast_encoded.byte_count, stack_encoded.byte_count));
                // Frequency classes, stamped on QUALITY's way into the pin
                // economics: sum_to's single while loop is one depth-1
                // region below a depth-0 entry.
                machine_function_stamp_frequency_classes(&traffic_selected.function);
                u16 traffic_maximum_class = 0;
                for (u32 block_index = 0; block_index < traffic_selected.function.block_count; block_index += 1)
                {
                    traffic_maximum_class = BUSTER_MAX(traffic_maximum_class, traffic_selected.function.blocks[block_index].frequency_class);
                }
                BUSTER_TEST(arguments, traffic_selected.function.blocks[0].frequency_class == 0);
                BUSTER_TEST_RAW(arguments, traffic_maximum_class == 1,
                                string_format(arguments->arena, S8("sum_to maximum frequency class {u64}"), (u64)traffic_maximum_class));
            }
        }
        // The nested pair reaches depth 2 — the classes count covering
        // backward-edge spans, not merely loop membership.
        IrFunction* nest_function = machine_test_ir_function_find(machine_module, S8("nest2"));
        BUSTER_TEST(arguments, nest_function != 0);
        if (nest_function)
        {
            MachineSelectResult nest_selected = machine_select_canonical_function(arguments->arena, machine_program, nest_function, machine_target);
            BUSTER_TEST(arguments, nest_selected.supported);
            if (nest_selected.supported)
            {
                machine_function_stamp_frequency_classes(&nest_selected.function);
                u16 nest_maximum_class = 0;
                for (u32 block_index = 0; block_index < nest_selected.function.block_count; block_index += 1)
                {
                    nest_maximum_class = BUSTER_MAX(nest_maximum_class, nest_selected.function.blocks[block_index].frequency_class);
                }
                BUSTER_TEST(arguments, nest_selected.function.blocks[0].frequency_class == 0);
                BUSTER_TEST_RAW(arguments, nest_maximum_class == 2,
                                string_format(arguments->arena, S8("nest2 maximum frequency class {u64}"), (u64)nest_maximum_class));
            }
        }
        codegen_release_executable(none_module_executable);
        codegen_release_executable(mir_module_executable);
#endif
    }

    // DIRECT exact-form smoke: MFENCE and INT3 have no visible operands, so
    // one tiny function exercises selection-independent placement and the
    // metadata-backed encoder path.  Keep this separate from the recipe
    // census above; the census owns registry counts, while this checks bytes.
    MachineFunction exact_barrier_function = machine_test_build_exact_barrier_function(arguments->arena);
    BUSTER_TEST(arguments, machine_verify_function(&exact_barrier_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement exact_barrier_placement = machine_fast_placement_build(arguments->arena, &exact_barrier_function);
    BUSTER_TEST(arguments, exact_barrier_placement.valid);
    MachineEncodeResult exact_barrier_encoded = machine_encode_x86_64(arguments->arena, &exact_barrier_function, &exact_barrier_placement);
    u32 exact_barrier_mfence_count = 0;
    u32 exact_barrier_int3_count = 0;
    for (u32 byte_index = 0; exact_barrier_encoded.valid && byte_index < exact_barrier_encoded.byte_count; byte_index += 1)
    {
        if (byte_index + 3 <= exact_barrier_encoded.byte_count && exact_barrier_encoded.bytes[byte_index] == 0x0f &&
            exact_barrier_encoded.bytes[byte_index + 1] == 0xae && exact_barrier_encoded.bytes[byte_index + 2] == 0xf0)
        {
            exact_barrier_mfence_count += 1;
        }
        if (exact_barrier_encoded.bytes[byte_index] == 0xcc)
        {
            exact_barrier_int3_count += 1;
        }
    }
    BUSTER_TEST(arguments, exact_barrier_encoded.valid && exact_barrier_mfence_count == 1 && exact_barrier_int3_count == 1);
    BUSTER_TEST(arguments, exact_barrier_encoded.exact_attempts == 2);
    BUSTER_TEST(arguments, exact_barrier_encoded.exact_successes == 2);
    BUSTER_TEST(arguments, exact_barrier_encoded.exact_failures == 0);
    BUSTER_TEST(arguments, exact_barrier_encoded.exact_attempts ==
                                   exact_barrier_encoded.exact_successes + exact_barrier_encoded.exact_failures);

    MachineFunction exact_register_function = machine_test_build_exact_register_function(arguments->arena);
    BUSTER_TEST(arguments, machine_verify_function(&exact_register_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement exact_register_placement = machine_stack_placement_build(arguments->arena, &exact_register_function);
    BUSTER_TEST(arguments, exact_register_placement.valid && exact_register_placement.edit_count == 0);
    MachineEncodeResult exact_register_encoded =
        machine_encode_x86_64(arguments->arena, &exact_register_function, &exact_register_placement);
    bool exact_register_offsets_monotonic = exact_register_encoded.valid && exact_register_encoded.row_offsets[0] == 4;
    for (u32 row_index = 1; row_index < exact_register_function.instruction_count && exact_register_offsets_monotonic; row_index += 1)
    {
        exact_register_offsets_monotonic &= exact_register_encoded.row_offsets[row_index] > exact_register_encoded.row_offsets[row_index - 1];
    }
    // Check asymmetric low/extended encodings at representative widths and
    // operand orientations. These bytes are the old switch's canonical
    // spellings, so this catches a projection that happens to succeed in
    // metadata but reverses RM/REG or drops a REX bit.
    bool exact_register_asymmetric_bytes = exact_register_encoded.valid;
    bool exact_register_mov64_bytes = false;
    bool exact_register_add32_bytes = false;
    bool exact_register_add64_bytes = false;
    bool exact_register_bsf32_bytes = false;
    bool exact_register_bsf64_bytes = false;
    bool exact_register_test64_bytes = false;
    if (exact_register_asymmetric_bytes)
    {
        u32 mov64 = exact_register_encoded.row_offsets[0];
        u32 add32 = exact_register_encoded.row_offsets[7];
        u32 add64 = exact_register_encoded.row_offsets[8];
        u32 bsf32 = exact_register_encoded.row_offsets[23];
        u32 bsf64 = exact_register_encoded.row_offsets[24];
        u32 test64 = exact_register_encoded.row_offsets[29];
        exact_register_mov64_bytes = exact_register_encoded.bytes[mov64 + 0] == 0x4c && exact_register_encoded.bytes[mov64 + 1] == 0x89 &&
                                     exact_register_encoded.bytes[mov64 + 2] == 0xc8;
        exact_register_add32_bytes = exact_register_encoded.bytes[add32 + 0] == 0x44 && exact_register_encoded.bytes[add32 + 1] == 0x01 &&
                                     exact_register_encoded.bytes[add32 + 2] == 0xc8;
        exact_register_add64_bytes = exact_register_encoded.bytes[add64 + 0] == 0x49 && exact_register_encoded.bytes[add64 + 1] == 0x01 &&
                                     exact_register_encoded.bytes[add64 + 2] == 0xc1;
        exact_register_bsf32_bytes = exact_register_encoded.bytes[bsf32 + 0] == 0x41 && exact_register_encoded.bytes[bsf32 + 1] == 0x0f &&
                                     exact_register_encoded.bytes[bsf32 + 2] == 0xbc && exact_register_encoded.bytes[bsf32 + 3] == 0xc1;
        exact_register_bsf64_bytes = exact_register_encoded.bytes[bsf64 + 0] == 0x4c && exact_register_encoded.bytes[bsf64 + 1] == 0x0f &&
                                     exact_register_encoded.bytes[bsf64 + 2] == 0xbc && exact_register_encoded.bytes[bsf64 + 3] == 0xc8;
        exact_register_test64_bytes = exact_register_encoded.bytes[test64 + 0] == 0x4c && exact_register_encoded.bytes[test64 + 1] == 0x85 &&
                                      exact_register_encoded.bytes[test64 + 2] == 0xc8;
        exact_register_asymmetric_bytes = exact_register_mov64_bytes && exact_register_add32_bytes && exact_register_add64_bytes &&
                                          exact_register_bsf32_bytes && exact_register_bsf64_bytes && exact_register_test64_bytes;
    }
    BUSTER_TEST(arguments, exact_register_encoded.valid && exact_register_offsets_monotonic);
    BUSTER_TEST(arguments, exact_register_mov64_bytes);
    BUSTER_TEST(arguments, exact_register_add32_bytes);
    BUSTER_TEST(arguments, exact_register_add64_bytes);
    BUSTER_TEST(arguments, exact_register_bsf32_bytes);
    BUSTER_TEST(arguments, exact_register_bsf64_bytes);
    BUSTER_TEST(arguments, exact_register_test64_bytes);
    BUSTER_TEST(arguments, exact_register_asymmetric_bytes);
    BUSTER_TEST(arguments, exact_register_encoded.exact_attempts == 30);
    BUSTER_TEST(arguments, exact_register_encoded.exact_successes == 30);
    BUSTER_TEST(arguments, exact_register_encoded.exact_failures == 0);
    BUSTER_TEST(arguments, exact_register_encoded.exact_attempts ==
                                   exact_register_encoded.exact_successes + exact_register_encoded.exact_failures);

    MachineFunction exact_second_function = machine_test_build_exact_second_register_function(arguments->arena);
    BUSTER_TEST(arguments, machine_verify_function(&exact_second_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement exact_second_placement = machine_stack_placement_build(arguments->arena, &exact_second_function);
    BUSTER_TEST(arguments, exact_second_placement.valid && exact_second_placement.edit_count == 0);
    MachineEncodeResult exact_second_encoded = machine_encode_x86_64(arguments->arena, &exact_second_function, &exact_second_placement);
    bool exact_second_offsets_monotonic = exact_second_encoded.valid && exact_second_encoded.row_offsets[0] == 4;
    for (u32 row_index = 1; row_index < exact_second_function.instruction_count && exact_second_offsets_monotonic; row_index += 1)
    {
        exact_second_offsets_monotonic &= exact_second_encoded.row_offsets[row_index] > exact_second_encoded.row_offsets[row_index - 1];
    }
    bool exact_second_bytes = exact_second_encoded.valid;
    if (exact_second_bytes)
    {
        u32 popcnt32 = exact_second_encoded.row_offsets[0];
        u32 popcnt64 = exact_second_encoded.row_offsets[1];
        u32 shl32 = exact_second_encoded.row_offsets[2];
        u32 shl64 = exact_second_encoded.row_offsets[3];
        u32 movq_to = exact_second_encoded.row_offsets[8];
        u32 movq_from = exact_second_encoded.row_offsets[9];
        u32 push = exact_second_encoded.row_offsets[10];
        u32 add_rsp = exact_second_encoded.row_offsets[11];
        exact_second_bytes &= exact_second_encoded.bytes[popcnt32 + 0] == 0xf3 && exact_second_encoded.bytes[popcnt32 + 1] == 0x41 &&
                              exact_second_encoded.bytes[popcnt32 + 2] == 0x0f && exact_second_encoded.bytes[popcnt32 + 3] == 0xb8 &&
                              exact_second_encoded.bytes[popcnt32 + 4] == 0xc1;
        exact_second_bytes &= exact_second_encoded.bytes[popcnt64 + 0] == 0xf3 && exact_second_encoded.bytes[popcnt64 + 1] == 0x4c &&
                              exact_second_encoded.bytes[popcnt64 + 2] == 0x0f && exact_second_encoded.bytes[popcnt64 + 3] == 0xb8 &&
                              exact_second_encoded.bytes[popcnt64 + 4] == 0xc8;
        exact_second_bytes &= exact_second_encoded.bytes[shl32 + 0] == 0xd3 && exact_second_encoded.bytes[shl32 + 1] == 0xe0;
        exact_second_bytes &= exact_second_encoded.bytes[shl64 + 0] == 0x48 && exact_second_encoded.bytes[shl64 + 1] == 0xd3 &&
                              exact_second_encoded.bytes[shl64 + 2] == 0xe0;
        exact_second_bytes &= exact_second_encoded.bytes[movq_to + 0] == 0x66 && exact_second_encoded.bytes[movq_to + 1] == 0x49 &&
                              exact_second_encoded.bytes[movq_to + 2] == 0x0f && exact_second_encoded.bytes[movq_to + 3] == 0x6e &&
                              exact_second_encoded.bytes[movq_to + 4] == 0xc1;
        exact_second_bytes &= exact_second_encoded.bytes[movq_from + 0] == 0x66 && exact_second_encoded.bytes[movq_from + 1] == 0x48 &&
                              exact_second_encoded.bytes[movq_from + 2] == 0x0f && exact_second_encoded.bytes[movq_from + 3] == 0x7e &&
                              exact_second_encoded.bytes[movq_from + 4] == 0xc8;
        exact_second_bytes &= exact_second_encoded.bytes[push + 0] == 0x41 && exact_second_encoded.bytes[push + 1] == 0x51;
        exact_second_bytes &= exact_second_encoded.bytes[add_rsp + 0] == 0x48 && exact_second_encoded.bytes[add_rsp + 1] == 0x81 &&
                              exact_second_encoded.bytes[add_rsp + 2] == 0xc4 && exact_second_encoded.bytes[add_rsp + 3] == 0x10 &&
                              exact_second_encoded.bytes[add_rsp + 4] == 0x00 && exact_second_encoded.bytes[add_rsp + 5] == 0x00 &&
                              exact_second_encoded.bytes[add_rsp + 6] == 0x00;
    }
    BUSTER_TEST(arguments, exact_second_encoded.valid && exact_second_offsets_monotonic);
    BUSTER_TEST(arguments, exact_second_bytes);
    BUSTER_TEST(arguments, exact_second_encoded.exact_attempts == 12);
    BUSTER_TEST(arguments, exact_second_encoded.exact_successes == 12);
    BUSTER_TEST(arguments, exact_second_encoded.exact_failures == 0);
    BUSTER_TEST(arguments, exact_second_encoded.exact_attempts ==
                                   exact_second_encoded.exact_successes + exact_second_encoded.exact_failures);

    MachineFunction exact_load_incoming_function = machine_test_build_exact_load_incoming_function(arguments->arena);
    BUSTER_TEST(arguments, machine_verify_function(&exact_load_incoming_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement exact_load_incoming_placement =
        machine_stack_placement_build(arguments->arena, &exact_load_incoming_function);
    BUSTER_TEST(arguments, exact_load_incoming_placement.valid && exact_load_incoming_placement.edit_count == 0);
    MachineEncodeResult exact_load_incoming_encoded =
        machine_encode_x86_64(arguments->arena, &exact_load_incoming_function, &exact_load_incoming_placement);
    bool exact_load_incoming_bytes = exact_load_incoming_encoded.valid;
    if (exact_load_incoming_bytes)
    {
        u32 rax_load = exact_load_incoming_encoded.row_offsets[0];
        u32 r9_load = exact_load_incoming_encoded.row_offsets[1];
        u32 r10_load = exact_load_incoming_encoded.row_offsets[2];
        // All three rows retain the old seven-byte [RBP+disp32] spelling,
        // including the offsets that metadata would otherwise relax to
        // disp8.  The final two rows also verify REX.R for extended regs.
        exact_load_incoming_bytes &= exact_load_incoming_encoded.bytes[rax_load + 0] == 0x48 &&
                                     exact_load_incoming_encoded.bytes[rax_load + 1] == 0x8b &&
                                     exact_load_incoming_encoded.bytes[rax_load + 2] == 0x85 &&
                                     exact_load_incoming_encoded.bytes[rax_load + 3] == 0x10 &&
                                     exact_load_incoming_encoded.bytes[rax_load + 4] == 0x00 &&
                                     exact_load_incoming_encoded.bytes[rax_load + 5] == 0x00 &&
                                     exact_load_incoming_encoded.bytes[rax_load + 6] == 0x00;
        exact_load_incoming_bytes &= exact_load_incoming_encoded.bytes[r9_load + 0] == 0x4c &&
                                     exact_load_incoming_encoded.bytes[r9_load + 1] == 0x8b &&
                                     exact_load_incoming_encoded.bytes[r9_load + 2] == 0x8d &&
                                     exact_load_incoming_encoded.bytes[r9_load + 3] == 0x80 &&
                                     exact_load_incoming_encoded.bytes[r9_load + 4] == 0x00 &&
                                     exact_load_incoming_encoded.bytes[r9_load + 5] == 0x00 &&
                                     exact_load_incoming_encoded.bytes[r9_load + 6] == 0x00;
        exact_load_incoming_bytes &= exact_load_incoming_encoded.bytes[r10_load + 0] == 0x4c &&
                                     exact_load_incoming_encoded.bytes[r10_load + 1] == 0x8b &&
                                     exact_load_incoming_encoded.bytes[r10_load + 2] == 0x95 &&
                                     exact_load_incoming_encoded.bytes[r10_load + 3] == 0x90 &&
                                     exact_load_incoming_encoded.bytes[r10_load + 4] == 0x00 &&
                                     exact_load_incoming_encoded.bytes[r10_load + 5] == 0x00 &&
                                     exact_load_incoming_encoded.bytes[r10_load + 6] == 0x00;
    }
    BUSTER_TEST(arguments, exact_load_incoming_encoded.valid && exact_load_incoming_bytes);
    BUSTER_TEST(arguments, exact_load_incoming_encoded.exact_attempts == 3);
    BUSTER_TEST(arguments, exact_load_incoming_encoded.exact_successes == 3);
    BUSTER_TEST(arguments, exact_load_incoming_encoded.exact_failures == 0);
    BUSTER_TEST(arguments, exact_load_incoming_encoded.exact_attempts ==
                                   exact_load_incoming_encoded.exact_successes + exact_load_incoming_encoded.exact_failures);

    MachineFunction exact_relative_function = machine_test_build_exact_relative_function(arguments->arena);
    BUSTER_TEST(arguments, machine_verify_function(&exact_relative_function).error == MACHINE_VERIFY_NONE);
    MachineStackPlacement exact_relative_placement = machine_stack_placement_build(arguments->arena, &exact_relative_function);
    BUSTER_TEST(arguments, exact_relative_placement.valid && exact_relative_placement.edit_count == 0);
    MachineEncodeResult exact_relative_encoded =
        machine_encode_x86_64(arguments->arena, &exact_relative_function, &exact_relative_placement);
    bool exact_relative_bytes = exact_relative_encoded.valid && exact_relative_encoded.byte_count >= 29;
    bool exact_relative_sites = exact_relative_encoded.valid && exact_relative_encoded.call_site_count == 2;
    if (exact_relative_bytes)
    {
        u32 forward_jmp = exact_relative_encoded.row_offsets[0];
        u32 extended_lea = exact_relative_encoded.row_offsets[1];
        u32 low_lea = exact_relative_encoded.row_offsets[3];
        u32 backward_jmp = exact_relative_encoded.row_offsets[4];
        // The branch fields are patched from the neutral E9+rel32 bytes;
        // derive both displacements from the final block offsets so the test
        // remains valid if RET's epilogue policy changes.
        u32 forward_displacement = exact_relative_encoded.block_offsets[2] - (forward_jmp + 5);
        u32 backward_displacement = exact_relative_encoded.block_offsets[1] - (backward_jmp + 5);
        exact_relative_bytes &= exact_relative_encoded.bytes[forward_jmp + 0] == 0xe9 &&
                               memcmp(exact_relative_encoded.bytes + forward_jmp + 1, &forward_displacement, sizeof(forward_displacement)) == 0;
        exact_relative_bytes &= exact_relative_encoded.bytes[extended_lea + 0] == 0x4c &&
                               exact_relative_encoded.bytes[extended_lea + 1] == 0x8d &&
                               exact_relative_encoded.bytes[extended_lea + 2] == 0x05 &&
                               exact_relative_encoded.bytes[extended_lea + 3] == 0x00 &&
                               exact_relative_encoded.bytes[extended_lea + 4] == 0x00 &&
                               exact_relative_encoded.bytes[extended_lea + 5] == 0x00 &&
                               exact_relative_encoded.bytes[extended_lea + 6] == 0x00;
        exact_relative_bytes &= exact_relative_encoded.bytes[low_lea + 0] == 0x48 &&
                               exact_relative_encoded.bytes[low_lea + 1] == 0x8d &&
                               exact_relative_encoded.bytes[low_lea + 2] == 0x05 &&
                               exact_relative_encoded.bytes[low_lea + 3] == 0x00 &&
                               exact_relative_encoded.bytes[low_lea + 4] == 0x00 &&
                               exact_relative_encoded.bytes[low_lea + 5] == 0x00 &&
                               exact_relative_encoded.bytes[low_lea + 6] == 0x00;
        exact_relative_bytes &= exact_relative_encoded.bytes[backward_jmp + 0] == 0xe9 &&
                               memcmp(exact_relative_encoded.bytes + backward_jmp + 1, &backward_displacement, sizeof(backward_displacement)) == 0;
    }
    if (exact_relative_sites)
    {
        exact_relative_sites &= exact_relative_encoded.call_sites[0].code_offset == exact_relative_encoded.row_offsets[1] + 3 &&
                               exact_relative_encoded.call_sites[0].target == 1 &&
                               exact_relative_encoded.call_sites[1].code_offset == exact_relative_encoded.row_offsets[3] + 3 &&
                               exact_relative_encoded.call_sites[1].target == 0;
    }
    BUSTER_TEST(arguments, exact_relative_encoded.valid && exact_relative_bytes);
    BUSTER_TEST(arguments, exact_relative_sites);
    BUSTER_TEST(arguments, exact_relative_encoded.exact_attempts == 4);
    BUSTER_TEST(arguments, exact_relative_encoded.exact_successes == 4);
    BUSTER_TEST(arguments, exact_relative_encoded.exact_failures == 0);
    BUSTER_TEST(arguments, exact_relative_encoded.exact_attempts ==
                                   exact_relative_encoded.exact_successes + exact_relative_encoded.exact_failures);

    // The original baseline vector-load refusal now selects an exact frame
    // copy. Keep its source identity and require a strict MIR module.
    Target machine_vector_fallback_target = {
        .cpu_arch = CPU_ARCH_X86_64,
        .cpu_model = CPU_MODEL_BASELINE,
        .os = OPERATING_SYSTEM_LINUX,
    };
    String8 machine_vector_fallback_source =
        S8("typedef unsigned char V64 __attribute__((vector_size(64)));\n"
           "unsigned char load_first(const V64* value) {\n"
           "    V64 loaded = *value;\n"
           "    return ((const unsigned char*)&loaded)[0];\n"
           "}\n");
    IrProgram* machine_vector_fallback_program =
        machine_test_compile_c(arguments->arena, S8("machine-vector-load-fallback.c"), machine_vector_fallback_source,
                               machine_vector_fallback_target);
    BUSTER_TEST(arguments, machine_vector_fallback_program != 0);
    if (machine_vector_fallback_program && machine_vector_fallback_program->module_count)
    {
        IrModule* machine_vector_fallback_ir_module = machine_vector_fallback_program->modules;
        IrFunction* machine_vector_fallback_function =
            machine_test_ir_function_find(machine_vector_fallback_ir_module, S8("load_first"));
        BUSTER_TEST(arguments, machine_vector_fallback_function != 0);
        if (machine_vector_fallback_function)
        {
            MachineSelectResult machine_vector_fallback_selected = machine_select_canonical_function(
                arguments->arena, machine_vector_fallback_program, machine_vector_fallback_function, machine_vector_fallback_target);
            BUSTER_TEST(arguments, machine_vector_fallback_selected.supported);
            BUSTER_TEST(arguments, machine_vector_fallback_selected.failed_opcode == IR_OPCODE_COUNT);
        }
        CodegenModule machine_vector_fallback_module = codegen_generate_canonical_module(
            arguments->arena, machine_vector_fallback_program, machine_vector_fallback_ir_module, machine_vector_fallback_target,
            (CodegenModuleOptions){
                .register_allocator = CODEGEN_REGISTER_ALLOCATOR_FAST,
                .verify_invariants = true,
            });
        BUSTER_TEST(arguments, machine_vector_fallback_module.error == CODEGEN_ERROR_NONE);
        BUSTER_TEST(arguments, machine_vector_fallback_module.statistics.fallback_function_count == 0);
        BUSTER_TEST(arguments, machine_vector_fallback_module.statistics.fallback_opcode_counts[IR_OPCODE_LOAD] == 0);
        BUSTER_TEST(arguments, machine_vector_fallback_module.statistics.fallback_reason_counts[CODEGEN_FALLBACK_OPCODE] == 0);
    }

    // Stage 10: the 512-bit vector subset. The corpus fixes a znver5 Linux
    // target, which carries every feature the vocabulary needs, so
    // selection, verification, placement, and encoding run on every host;
    // the executing differential additionally requires the host's own
    // cpuid to carry the features, since the canonical NONE oracle emits
    // the same AVX-512 instructions the machine rows do.
    Target machine_vector_target = {
        .cpu_arch = CPU_ARCH_X86_64,
        .cpu_model = CPU_MODEL_AMD_ZEN_5,
        .os = OPERATING_SYSTEM_LINUX,
    };
    String8 machine_vector_source_head =
        S8("typedef unsigned char u8;\n"
           "typedef unsigned long long u64;\n"
           "typedef u8 V64 __attribute__((vector_size(64)));\n"
           "u64 vclassify(const u8* data, u64 valid) {\n"
           "    V64 chunk = __builtin_buster_simd_load_masked(data, valid);\n"
           "    V64 lower = chunk | __builtin_buster_simd_splat_byte(0x20);\n"
           "    V64 shifted = lower - __builtin_buster_simd_splat_byte(97);\n"
           "    u64 alpha = __builtin_buster_simd_less_byte(shifted, __builtin_buster_simd_splat_byte(26));\n"
           "    u64 under = __builtin_buster_simd_equal_byte(chunk, __builtin_buster_simd_splat_byte(95));\n"
           "    u64 high = __builtin_buster_simd_sign_byte(chunk);\n"
           "    u64 bits = __builtin_buster_simd_test_byte(chunk, __builtin_buster_simd_splat_byte(0x40));\n"
           "    return (alpha | under) ^ (high * 3) ^ bits ^ (u64)__builtin_popcountll(alpha);\n"
           "}\n"
           "u64 vtable(const u8* low, const u8* high, const u8* indices, u64 mask) {\n"
           "    V64 low_v = __builtin_buster_simd_load(low);\n"
           "    V64 high_v = __builtin_buster_simd_load(high);\n"
           "    V64 index_v = __builtin_buster_simd_load(indices);\n"
           "    V64 permuted = __builtin_buster_simd_permute2_byte(mask, low_v, index_v, high_v);\n"
           "    V64 packed = __builtin_buster_simd_compress_byte(mask, permuted);\n"
           "    V64 wide = __builtin_buster_simd_widen_byte(packed, 1);\n"
           "    V64 shifted = __builtin_buster_simd_shift_left_word(wide, 5);\n"
           "    V64 mixed = __builtin_buster_simd_ternary_word(packed, shifted, wide, 0xd8);\n"
           "    return __builtin_buster_simd_sign_byte(mixed) ^ __builtin_buster_simd_test_byte(shifted, __builtin_buster_simd_splat_byte(0x80)) ^\n"
           "           __builtin_buster_simd_equal_byte(packed, __builtin_buster_simd_splat_byte(0));\n"
           "}\n"
           "void vstores(u8* out, const u8* in, u64 mask) {\n"
           "    V64 first = __builtin_buster_simd_load(in);\n"
           "    __builtin_buster_simd_store(out, first + __builtin_buster_simd_splat_byte(1));\n"
           "    __builtin_buster_simd_store_masked(out + 64, mask, first ^ __builtin_buster_simd_load(in + 64));\n"
           "    __builtin_buster_simd_compress_store_byte(out + 128, mask, first);\n"
           "}\n");
    String8 machine_vector_source_tail =
        S8("u64 vspill(const u8* data, u64 rounds) {\n"
           "    V64 a0 = __builtin_buster_simd_load(data + 64 * 0);\n"
           "    V64 a1 = __builtin_buster_simd_load(data + 64 * 1);\n"
           "    V64 a2 = __builtin_buster_simd_load(data + 64 * 2);\n"
           "    V64 a3 = __builtin_buster_simd_load(data + 64 * 3);\n"
           "    V64 a4 = __builtin_buster_simd_load(data + 64 * 4);\n"
           "    V64 a5 = __builtin_buster_simd_load(data + 64 * 5);\n"
           "    V64 a6 = __builtin_buster_simd_load(data + 64 * 6);\n"
           "    V64 a7 = __builtin_buster_simd_load(data + 64 * 7);\n"
           "    V64 a8 = __builtin_buster_simd_load(data + 64 * 8);\n"
           "    V64 a9 = __builtin_buster_simd_load(data + 64 * 9);\n"
           "    V64 a10 = __builtin_buster_simd_load(data + 64 * 10);\n"
           "    V64 a11 = __builtin_buster_simd_load(data + 64 * 11);\n"
           "    V64 a12 = __builtin_buster_simd_load(data + 64 * 12);\n"
           "    V64 a13 = __builtin_buster_simd_load(data + 64 * 13);\n"
           "    V64 a14 = __builtin_buster_simd_load(data + 64 * 14);\n"
           "    V64 a15 = __builtin_buster_simd_load(data + 64 * 15);\n"
           "    V64 a16 = __builtin_buster_simd_load(data + 64 * 16);\n"
           "    V64 a17 = __builtin_buster_simd_load(data + 64 * 17);\n"
           "    for (u64 round = 0; round < rounds; round += 1) {\n"
           "        a0 = a0 + (a1 ^ a17);\n"
           "        a1 = a1 + (a2 ^ a0);\n"
           "        a2 = a2 + (a3 ^ a1);\n"
           "        a3 = a3 + (a4 ^ a2);\n"
           "        a4 = a4 + (a5 ^ a3);\n"
           "        a5 = a5 + (a6 ^ a4);\n"
           "        a6 = a6 + (a7 ^ a5);\n"
           "        a7 = a7 + (a8 ^ a6);\n"
           "        a8 = a8 + (a9 ^ a7);\n"
           "        a9 = a9 + (a10 ^ a8);\n"
           "        a10 = a10 + (a11 ^ a9);\n"
           "        a11 = a11 + (a12 ^ a10);\n"
           "        a12 = a12 + (a13 ^ a11);\n"
           "        a13 = a13 + (a14 ^ a12);\n"
           "        a14 = a14 + (a15 ^ a13);\n"
           "        a15 = a15 + (a16 ^ a14);\n"
           "        a16 = a16 + (a17 ^ a15);\n"
           "        a17 = a17 + (a0 ^ a16);\n"
           "    }\n"
           "    V64 combined = a0 ^ a1 ^ a2 ^ a3 ^ a4 ^ a5 ^ a6 ^ a7 ^ a8 ^ a9 ^ a10 ^ a11 ^ a12 ^ a13 ^ a14 ^ a15 ^ a16 ^ a17;\n"
           "    return __builtin_buster_simd_sign_byte(combined) ^ __builtin_buster_simd_test_byte(a0 & a9, __builtin_buster_simd_splat_byte(0x11));\n"
           "}\n"
           "u64 vhelp(u64 x) { x ^= x >> 33; x *= 0xff51afd7ed558ccdUL; return x ^ (x >> 29); }\n"
           "u64 vcalls(const u8* data, u64 rounds) {\n"
           "    V64 b0 = __builtin_buster_simd_load(data + 64 * 0);\n"
           "    V64 b1 = __builtin_buster_simd_load(data + 64 * 1);\n"
           "    V64 b2 = __builtin_buster_simd_load(data + 64 * 2);\n"
           "    V64 b3 = __builtin_buster_simd_load(data + 64 * 3);\n"
           "    u64 total = 0;\n"
           "    for (u64 round = 0; round < rounds; round += 1) {\n"
           "        total += vhelp(total ^ round);\n"
           "        V64 salt = __builtin_buster_simd_splat_byte((u8)total);\n"
           "        b0 = b0 + (salt ^ b3);\n"
           "        b1 = b1 + (salt ^ b0);\n"
           "        b2 = b2 + (salt ^ b1);\n"
           "        b3 = b3 + (salt ^ b2);\n"
           "    }\n"
           "    return total ^ __builtin_buster_simd_sign_byte(b0 ^ b1 ^ b2 ^ b3);\n"
           "}\n"
           // 64-bit lanes: vpaddq/vpsubq are the vocabulary's only EVEX.W1
           // rows, and their W0 encodings #UD on real hardware, so this body
           // is the differential that keeps both the machine wide bit and
           // the canonical oracle's W1 forms honest.
           "typedef u64 Q8 __attribute__((vector_size(64)));\n"
           "u64 vqarith(const u8* data, u64 rounds) {\n"
           "    const Q8* row = (const Q8*)(const void*)data;\n"
           "    Q8 accumulator = row[0];\n"
           "    Q8 step = row[1];\n"
           "    Q8 bias = row[2];\n"
           "    for (u64 round = 0; round < rounds; round += 1) {\n"
           "        accumulator = (accumulator + step) - bias;\n"
           "        accumulator = accumulator + (step ^ bias);\n"
           "        accumulator = accumulator - (step & bias);\n"
           "    }\n"
           "    u64 out[8];\n"
           "    *(Q8*)(void*)out = accumulator;\n"
           "    return out[0] ^ out[1] ^ out[2] ^ out[3] ^ out[4] ^ out[5] ^ out[6] ^ out[7];\n"
           "}\n"
           // A union with a vector member is a 64-byte-aligned local: the
           // machine path mirrors the canonical over-aligned frame shape
           // (padded slot, runtime-aligned pointer), and the returned
           // low address bits assert the alignment actually holds.
           "typedef union Lanes { V64 vector; u8 bytes[64]; u64 words[8]; } Lanes;\n"
           "u64 vunion(const u8* data, u64 salt) {\n"
           "    Lanes lanes;\n"
           "    lanes.vector = __builtin_buster_simd_load(data);\n"
           "    lanes.words[0] += salt;\n"
           "    lanes.bytes[63] = (u8)salt;\n"
           "    u64 misalignment = (u64)&lanes & 63;\n"
           "    return lanes.words[0] ^ lanes.words[7] ^ __builtin_buster_simd_sign_byte(lanes.vector) ^ misalignment;\n"
           "}\n");
    // The System V vector ABI: 64-byte values crossing call boundaries in
    // ZMM registers — parameters, returns, the mixed integer/vector
    // signature, and the ninth argument that overflows to the caller's
    // 64-aligned stack eightbytes. vabi drives them all from one
    // u64-returning wrapper so the differential below can execute it
    // through the scalar calling shape it already uses.
    String8 machine_vector_source_abi =
        S8("V64 vident(V64 v) { return v; }\n"
           "V64 vmix(u64 salt, V64 a, u64 salt2, V64 b) {\n"
           "    return a + (b ^ __builtin_buster_simd_splat_byte((u8)(salt + salt2)));\n"
           "}\n"
           "V64 vninth(V64 a, V64 b, V64 c, V64 d, V64 e, V64 f, V64 g, V64 h, V64 i) {\n"
           "    return a + (h ^ i);\n"
           "}\n"
           "u64 vabi(const u8* data, u64 mask) {\n"
           "    V64 first = __builtin_buster_simd_load(data);\n"
           "    V64 second = __builtin_buster_simd_load(data + 64);\n"
           "    V64 ident = vident(first);\n"
           "    V64 mixed = vmix(mask, ident, mask >> 7, second);\n"
           "    V64 nine = vninth(first, second, ident, mixed, first, second, ident, mixed, first ^ second);\n"
           "    return __builtin_buster_simd_sign_byte(nine) ^\n"
           "           __builtin_buster_simd_test_byte(mixed, __builtin_buster_simd_splat_byte(0x21)) ^\n"
           "           __builtin_buster_simd_equal_byte(vident(nine), nine);\n"
           "}\n");
    String8 machine_vector_source =
        string_format(arguments->arena, S8("{S8}{S8}{S8}"), machine_vector_source_head, machine_vector_source_tail, machine_vector_source_abi);
    IrProgram* machine_vector_program = machine_test_compile_c(arguments->arena, S8("machine-stage10.c"), machine_vector_source, machine_vector_target);
    BUSTER_TEST(arguments, machine_vector_program != 0);
    if (machine_vector_program && machine_vector_program->module_count)
    {
        IrModule* machine_vector_module = machine_vector_program->modules;
        String8 vector_names[] = {
            S8_INITIALIZER("vclassify"), S8_INITIALIZER("vtable"), S8_INITIALIZER("vstores"),
            S8_INITIALIZER("vspill"),    S8_INITIALIZER("vcalls"), S8_INITIALIZER("vhelp"),
            S8_INITIALIZER("vident"),    S8_INITIALIZER("vmix"),   S8_INITIALIZER("vninth"),
            S8_INITIALIZER("vabi"),      S8_INITIALIZER("vqarith"), S8_INITIALIZER("vunion"),
        };
        for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(vector_names); name_index += 1)
        {
            IrFunction* ir_function = machine_test_ir_function_find(machine_vector_module, vector_names[name_index]);
            BUSTER_TEST(arguments, ir_function != 0);
            if (!ir_function)
            {
                continue;
            }
            MachineSelectResult selected = machine_select_canonical_function(arguments->arena, machine_vector_program, ir_function, machine_vector_target);
            BUSTER_TEST_RAW(arguments, selected.supported,
                            string_format(arguments->arena, S8("vector select {S8} failed at opcode {u32}"), vector_names[name_index],
                                          (u32)selected.failed_opcode));
            if (!selected.supported)
            {
                continue;
            }
            BUSTER_TEST(arguments, machine_verify_function(&selected.function).error == MACHINE_VERIFY_NONE);
            MachineStackPlacement vector_stack = machine_stack_placement_build(arguments->arena, &selected.function);
            MachineStackPlacement vector_fast = machine_fast_placement_build(arguments->arena, &selected.function);
            MachineStackPlacement vector_quality = machine_quality_placement_build(arguments->arena, &selected.function);
            BUSTER_TEST(arguments, vector_stack.valid && vector_fast.valid && vector_quality.valid);
            MachineEncodeResult stack_encoded = machine_encode_x86_64(arguments->arena, &selected.function, &vector_stack);
            MachineEncodeResult fast_encoded = machine_encode_x86_64(arguments->arena, &selected.function, &vector_fast);
            MachineEncodeResult quality_encoded = machine_encode_x86_64(arguments->arena, &selected.function, &vector_quality);
            BUSTER_TEST(arguments, stack_encoded.valid && fast_encoded.valid && quality_encoded.valid);
            // Eighteen live vectors against the thirty-two-register file:
            // every accumulator fits, so the scan must keep the vector
            // working set fully register-resident — any vector-class edit
            // here means the widened file is not actually being allocated.
            // The scalar traffic stays: the loop-carried counters conform
            // at the loop head and the frontend's stack save/restore
            // bracket round-trips through RSP exactly as before.
            if (string_equal(vector_names[name_index], S8("vspill")))
            {
                // Keep the original mutable-local pressure census independent
                // of SSA edge copies. The direct-SSA selection and execution
                // checks above/below continue to use machine_vector_program.
                IrProgram* pressure_program = machine_test_compile_c_with_options(arguments->arena, S8("vector-pressure-reference.c"),
                    machine_vector_source, machine_vector_target, (CIRLowerOptions){.disable_direct_ssa = true});
                BUSTER_TEST(arguments, pressure_program && pressure_program->module_count);
                if (!pressure_program || !pressure_program->module_count)
                {
                    continue;
                }
                IrFunction* pressure_function = machine_test_ir_function_find(pressure_program->modules, S8("vspill"));
                BUSTER_TEST(arguments, pressure_function != 0);
                if (!pressure_function)
                {
                    continue;
                }
                selected = machine_select_canonical_function(arguments->arena, pressure_program, pressure_function, machine_vector_target);
                BUSTER_TEST(arguments, selected.supported);
                if (!selected.supported)
                {
                    continue;
                }
                vector_fast = machine_fast_placement_build(arguments->arena, &selected.function);
                BUSTER_TEST(arguments, vector_fast.valid);
                u32 fast_vector_edits = 0;
                for (u32 edit_index = 0; edit_index < vector_fast.edit_count; edit_index += 1)
                {
                    MachineEdit* edit = vector_fast.edits + edit_index;
                    fast_vector_edits += (edit->kind == MACHINE_EDIT_SPILL || edit->kind == MACHINE_EDIT_RELOAD) &&
                                         selected.function.virtual_registers[edit->subject].register_class == MACHINE_REGISTER_CLASS_VECTOR;
                }
                BUSTER_TEST_RAW(arguments, fast_vector_edits == 0,
                                string_format(arguments->arena, S8("vector-class edits fast {u32} (spills {u32} reloads {u32} stack {u32})"),
                                              fast_vector_edits, vector_fast.spill_count, vector_fast.reload_count, vector_stack.spill_count));
                // Eighteen accumulators cannot fit in ZMM0-15 alone, so a
                // fully resident placement is proof the scan handed out the
                // high file; the executing differential below is what then
                // proves the encoder's EVEX extension bits reproduce the
                // canonical results on an AVX-512 host.
                bool fast_reaches_high_file = false;
                for (u64 register_scan = 0; register_scan < (u64)selected.function.instruction_count * 4; register_scan += 1)
                {
                    fast_reaches_high_file |=
                        vector_fast.operand_registers[register_scan] != UINT8_MAX && vector_fast.operand_registers[register_scan] >= MACHINE_X64_ZMM16;
                }
                BUSTER_TEST(arguments, fast_reaches_high_file);
            }
        }
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
        // Executing differential: all four modes over the same module, on
        // hosts whose cpuid carries the vocabulary.
        TargetCpuFeatures machine_vector_host = cpu_detect_features_x86_64();
        bool machine_vector_host_ready =
            target_cpu_features_contains(machine_vector_host, TARGET_CPU_FEATURE_X86_AVX512F) &&
            target_cpu_features_contains(machine_vector_host, TARGET_CPU_FEATURE_X86_AVX512BW) &&
            target_cpu_features_contains(machine_vector_host, TARGET_CPU_FEATURE_X86_AVX512VBMI) &&
            target_cpu_features_contains(machine_vector_host, TARGET_CPU_FEATURE_X86_AVX512VBMI2);
        if (machine_vector_host_ready)
        {
            CodegenRegisterAllocatorMode vector_modes[] = {
                CODEGEN_REGISTER_ALLOCATOR_NONE,
                CODEGEN_REGISTER_ALLOCATOR_MIR_STACK,
                CODEGEN_REGISTER_ALLOCATOR_FAST,
                CODEGEN_REGISTER_ALLOCATOR_QUALITY,
            };
            CodegenModule vector_modules[BUSTER_ARRAY_LENGTH(vector_modes)] = {0};
            CodegenExecutable vector_executables[BUSTER_ARRAY_LENGTH(vector_modes)] = {0};
            bool vector_modules_ready = true;
            for (u32 mode_index = 0; mode_index < BUSTER_ARRAY_LENGTH(vector_modes); mode_index += 1)
            {
                vector_modules[mode_index] = codegen_generate_canonical_module(arguments->arena, machine_vector_program, machine_vector_module,
                                                                              machine_vector_target,
                                                                              (CodegenModuleOptions){
                                                                                  .register_allocator = (u8)vector_modes[mode_index],
                                                                              });
                BUSTER_TEST(arguments, vector_modules[mode_index].error == CODEGEN_ERROR_NONE);
                BUSTER_TEST(arguments, vector_modules[mode_index].statistics.fallback_function_count == 0);
                for (u32 relocation_index = 0; relocation_index < vector_modules[mode_index].relocation_count; relocation_index += 1)
                {
                    CodegenModuleRelocation* relocation = vector_modules[mode_index].relocations + relocation_index;
                    BUSTER_TEST(arguments, codegen_module_relocation_valid(relocation));
                    if (relocation->source != CODEGEN_MODULE_RELOCATION_CODE || codegen_module_relocation_kind_is_absolute(relocation->kind))
                    {
                        continue;
                    }
                    for (u32 entry_index = 0; entry_index < vector_modules[mode_index].entry_count; entry_index += 1)
                    {
                        if (vector_modules[mode_index].entries[entry_index].symbol.value == relocation->symbol.value)
                        {
                            u32 displacement = vector_modules[mode_index].entries[entry_index].offset - (relocation->offset + 4);
                            memcpy(vector_modules[mode_index].code.pointer + relocation->offset, &displacement, sizeof(displacement));
                            break;
                        }
                    }
                }
                vector_executables[mode_index] = codegen_make_executable((CodegenFunction){
                    .code = vector_modules[mode_index].code,
                });
                BUSTER_TEST(arguments, vector_executables[mode_index].error == CODEGEN_ERROR_NONE);
                vector_modules_ready &= vector_executables[mode_index].error == CODEGEN_ERROR_NONE && vector_executables[mode_index].address != 0;
            }
            u8 vector_probe_bytes[64 * 18];
            u64 vector_probe_state = 0x9e3779b97f4a7c15ull;
            for (u32 byte_index = 0; byte_index < BUSTER_ARRAY_LENGTH(vector_probe_bytes); byte_index += 1)
            {
                vector_probe_state = vector_probe_state * 6364136223846793005ull + 1442695040888963407ull;
                vector_probe_bytes[byte_index] = (u8)(vector_probe_state >> 56);
            }
            typedef u64 MachineTestVectorCall(u8 const*, u64);
            typedef u64 MachineTestVectorTable(u8 const*, u8 const*, u8 const*, u64);
            typedef void MachineTestVectorStores(u8*, u8 const*, u64);
            u64 vector_mask_probes[] = {~0ull, 0x00ffff0000ffff00ull, 1ull, 0x8000000000000001ull};
            for (u32 mode_index = 1; mode_index < BUSTER_ARRAY_LENGTH(vector_modes) && vector_modules_ready; mode_index += 1)
            {
                for (u32 probe_index = 0; probe_index < BUSTER_ARRAY_LENGTH(vector_mask_probes); probe_index += 1)
                {
                    u64 probe_mask = vector_mask_probes[probe_index];
                    String8 call_names[] = {S8_INITIALIZER("vclassify"), S8_INITIALIZER("vspill"),   S8_INITIALIZER("vcalls"),
                                            S8_INITIALIZER("vabi"),      S8_INITIALIZER("vqarith"), S8_INITIALIZER("vunion")};
                    for (u32 call_index = 0; call_index < BUSTER_ARRAY_LENGTH(call_names); call_index += 1)
                    {
                        u32 none_offset = machine_test_module_offset(&vector_modules[0], machine_vector_module, call_names[call_index]);
                        u32 mode_offset = machine_test_module_offset(&vector_modules[mode_index], machine_vector_module, call_names[call_index]);
                        BUSTER_TEST(arguments, none_offset != UINT32_MAX && mode_offset != UINT32_MAX);
                        if (none_offset == UINT32_MAX || mode_offset == UINT32_MAX)
                        {
                            continue;
                        }
                        void* none_address = (u8*)vector_executables[0].address + none_offset;
                        void* mode_address = (u8*)vector_executables[mode_index].address + mode_offset;
                        MachineTestVectorCall* none_call = 0;
                        MachineTestVectorCall* mode_call = 0;
                        memcpy(&none_call, &none_address, sizeof(none_call));
                        memcpy(&mode_call, &mode_address, sizeof(mode_call));
                        // vclassify consumes the mask as lane validity and
                        // vabi as a salt, so both take it raw; the loop
                        // bodies consume it as a round count, clamped so the
                        // differential stays fast.
                        bool mask_shaped = call_index == 0 || call_index == 3;
                        u64 argument = mask_shaped ? probe_mask : (probe_mask & 15ull) + 3ull;
                        u64 none_result = none_call(vector_probe_bytes, argument);
                        u64 mode_result = mode_call(vector_probe_bytes, argument);
                        BUSTER_TEST_RAW(arguments, none_result == mode_result,
                                        string_format(arguments->arena, S8("vector {S8} mode {u32} mask {u64} none {u64} got {u64}"),
                                                      call_names[call_index], (u32)vector_modes[mode_index], probe_mask, none_result, mode_result));
                    }
                    u32 none_table_offset = machine_test_module_offset(&vector_modules[0], machine_vector_module, S8("vtable"));
                    u32 mode_table_offset = machine_test_module_offset(&vector_modules[mode_index], machine_vector_module, S8("vtable"));
                    if (none_table_offset != UINT32_MAX && mode_table_offset != UINT32_MAX)
                    {
                        void* none_address = (u8*)vector_executables[0].address + none_table_offset;
                        void* mode_address = (u8*)vector_executables[mode_index].address + mode_table_offset;
                        MachineTestVectorTable* none_table = 0;
                        MachineTestVectorTable* mode_table = 0;
                        memcpy(&none_table, &none_address, sizeof(none_table));
                        memcpy(&mode_table, &mode_address, sizeof(mode_table));
                        u64 none_result = none_table(vector_probe_bytes, vector_probe_bytes + 64, vector_probe_bytes + 128, probe_mask);
                        u64 mode_result = mode_table(vector_probe_bytes, vector_probe_bytes + 64, vector_probe_bytes + 128, probe_mask);
                        BUSTER_TEST_RAW(arguments, none_result == mode_result,
                                        string_format(arguments->arena, S8("vector vtable mode {u32} mask {u64} none {u64} got {u64}"),
                                                      (u32)vector_modes[mode_index], probe_mask, none_result, mode_result));
                    }
                    u32 none_store_offset = machine_test_module_offset(&vector_modules[0], machine_vector_module, S8("vstores"));
                    u32 mode_store_offset = machine_test_module_offset(&vector_modules[mode_index], machine_vector_module, S8("vstores"));
                    if (none_store_offset != UINT32_MAX && mode_store_offset != UINT32_MAX)
                    {
                        u8 none_out[192];
                        u8 mode_out[192];
                        memset(none_out, 0xa5, sizeof(none_out));
                        memset(mode_out, 0xa5, sizeof(mode_out));
                        void* none_address = (u8*)vector_executables[0].address + none_store_offset;
                        void* mode_address = (u8*)vector_executables[mode_index].address + mode_store_offset;
                        MachineTestVectorStores* none_store = 0;
                        MachineTestVectorStores* mode_store = 0;
                        memcpy(&none_store, &none_address, sizeof(none_store));
                        memcpy(&mode_store, &mode_address, sizeof(mode_store));
                        none_store(none_out, vector_probe_bytes, probe_mask);
                        mode_store(mode_out, vector_probe_bytes, probe_mask);
                        BUSTER_TEST_RAW(arguments, memcmp(none_out, mode_out, sizeof(none_out)) == 0,
                                        string_format(arguments->arena, S8("vector vstores mode {u32} mask {u64}"), (u32)vector_modes[mode_index],
                                                      probe_mask));
                    }
                }
            }
            for (u32 mode_index = 0; mode_index < BUSTER_ARRAY_LENGTH(vector_modes); mode_index += 1)
            {
                codegen_release_executable(vector_executables[mode_index]);
            }
        }
#endif
    }

    // Stage 11: AArch64 selection, MIR_STACK placement, and encoding over
    // the scalar integer subset — plus the AAPCS64 shape coverage: a
    // two-part register aggregate parameter (kagg_take) and an indirect
    // result through X8 (big_make) — on the same C corpus with a fixed
    // aarch64-linux target so the machine path exercises on every host.
    // Execution requires a non-sanitized AArch64 host; the subset's
    // register-argument scalar signatures place identically under AAPCS64
    // and the Darwin convention, so the Linux-target bytes execute
    // natively on both.
    Target machine_a64_target = {
        .cpu_arch = CPU_ARCH_AARCH64,
        .os = OPERATING_SYSTEM_LINUX,
    };
    // The following memory and scalar cases enter through the exact helpers
    // used by the machine encoder. None may fall back to packed audit data.
    buster_aarch64_metadata_test_reset_packed_access_counter();

    // Differential coverage for the generated unsigned memory wrapper used
    // by frame and aggregate-copy emission. Each form is checked at offset
    // zero and at the architectural imm12 limit, with the old hand-encoded
    // words retained as an independent byte oracle. The frame helper's large
    // offset path is also checked: its materialize/add prefix stays intact
    // and only the final unsigned memory word comes from metadata.
    static struct
    {
        u32 size;
        bool store;
        char const* name;
    } const a64_memory_forms[] = {
        {1, false, "LDRBBui"},
        {2, false, "LDRHHui"},
        {4, false, "LDRWui"},
        {8, false, "LDRXui"},
        {1, true, "STRBBui"},
        {2, true, "STRHHui"},
        {4, true, "STRWui"},
        {8, true, "STRXui"},
    };
    for (u32 form_index = 0; form_index < BUSTER_ARRAY_LENGTH(a64_memory_forms); form_index += 1)
    {
        u32 size = a64_memory_forms[form_index].size;
        bool store = a64_memory_forms[form_index].store;
        u32 base = store ? (size == 1   ? UINT32_C(0x39000000)
                              : size == 2 ? UINT32_C(0x79000000)
                              : size == 4 ? UINT32_C(0xb9000000)
                                          : UINT32_C(0xf9000000))
                         : (size == 1   ? UINT32_C(0x39400000)
                              : size == 2 ? UINT32_C(0x79400000)
                              : size == 4 ? UINT32_C(0xb9400000)
                                          : UINT32_C(0xf9400000));
        u32 offsets[] = {0, 4095u * size};
        for (u32 offset_index = 0; offset_index < BUSTER_ARRAY_LENGTH(offsets); offset_index += 1)
        {
            u32 bytes[4] = {0};
            u32 byte_count = 0;
            bool error = false;
            bool emitted = machine_a64_test_emit_unsigned_memory((u8*)bytes, sizeof(bytes), 17, 28, offsets[offset_index], size, store, false,
                                                                   &byte_count, &error);
            u32 expected = base | (17u) | (28u << 5) | ((offsets[offset_index] / size) << 10);
            BUSTER_TEST_RAW(arguments, emitted && !error && byte_count == 4 && bytes[0] == expected,
                            string_format(arguments->arena, S8("a64 generated {S8} offset {u32}"), a64_memory_forms[form_index].name,
                                          offsets[offset_index]));
        }
        // A large aggregate copy can reach both out-of-range and unaligned
        // sized tails. Pin all expanded forms independently, not only whether
        // a module produced bytes. Small aligned addresses above remain exact.
        u32 expanded_offsets[] = {1, 4096u * size};
        for (u32 expanded = size == 1 ? 1u : 0u; expanded < BUSTER_ARRAY_LENGTH(expanded_offsets); expanded += 1)
        {
            u32 bytes[4] = {0};
            u32 byte_count = 0;
            bool error = false;
            u32 offset = expanded_offsets[expanded];
            BUSTER_TEST(arguments, machine_a64_test_emit_unsigned_memory((u8*)bytes, sizeof(bytes), 17, 28, offset, size, store, false,
                                                                         &byte_count, &error) && !error && byte_count == 12);
            BUSTER_TEST(arguments, bytes[0] == (UINT32_C(0xd2800010) | (offset << 5)) &&
                                   bytes[1] == UINT32_C(0x8b100390) && bytes[2] == (base | (16u << 5) | 17u));
        }
        // Invalid transfer widths/register ids and destructive address-scratch
        // aliases stay errors, with no published prefix.
        u32 invalid[][4] = {{17, 28, 0, 3}, {32, 28, 0, size}, {17, 32, 0, size},
                            {17, 16, 4096u * size, size}, {17, 31, 4096u * size, size}};
        for (u32 bad = 0; bad < BUSTER_ARRAY_LENGTH(invalid); bad += 1)
        {
            u32 bytes[4] = {0};
            u32 byte_count = 0;
            bool error = false;
            BUSTER_TEST(arguments, !machine_a64_test_emit_unsigned_memory((u8*)bytes, sizeof(bytes), invalid[bad][0], invalid[bad][1],
                invalid[bad][2], invalid[bad][3], store, false, &byte_count, &error) && error && byte_count == 0);
        }
        if (store)
        {
            u32 bytes[4] = {0};
            u32 byte_count = 0;
            bool error = false;
            BUSTER_TEST(arguments, !machine_a64_test_emit_unsigned_memory((u8*)bytes, sizeof(bytes), 16, 28, 4096u * size, size,
                true, false, &byte_count, &error) && error && byte_count == 0);
        }
    }
    {
        u32 bytes[16] = {0};
        u32 byte_count = 0;
        bool error = false;
        BUSTER_TEST(arguments, machine_a64_test_emit_unsigned_memory((u8*)bytes, sizeof(bytes), 17, 0, 32768, 8, true, true, &byte_count, &error) &&
                                  !error && byte_count == 12);
        u32 words[3] = {0};
        memcpy(words, bytes, sizeof(words));
        BUSTER_TEST(arguments, words[0] == UINT32_C(0xd2900010) && words[1] == UINT32_C(0x8b100390) && words[2] == UINT32_C(0xf9000211));
    }
    // Literal words for every non-memory generated production row. These
    // cases enter through the real MachineOpcode mapping, with distinct
    // registers and nonzero immediates so a swapped semantic field changes
    // the oracle rather than merely reproducing a symmetric raw-layout test.
    static struct
    {
        u16 opcode;
        u32 operand0;
        u32 operand1;
        u32 operand2;
        u32 payload;
        u32 expected[2];
        u8 expected_count;
        char const* name;
    } const generated_machine_cases[] = {
        {MACHINE_A64_MOV_RR, 3, 5, 0, 0, {UINT32_C(0xaa0503e3)}, 1, "MOV_RR"},
        {MACHINE_A64_MOV32_RR, 3, 5, 0, 0, {UINT32_C(0x2a0503e3)}, 1, "MOV32_RR"},
        {MACHINE_A64_SXTB, 3, 5, 0, 0, {UINT32_C(0x93401ca3)}, 1, "SXTB"},
        {MACHINE_A64_SXTH, 3, 5, 0, 0, {UINT32_C(0x93403ca3)}, 1, "SXTH"},
        {MACHINE_A64_SXTW, 3, 5, 0, 0, {UINT32_C(0x93407ca3)}, 1, "SXTW"},
        {MACHINE_A64_UXTB, 3, 5, 0, 0, {UINT32_C(0x53001ca3)}, 1, "UXTB"},
        {MACHINE_A64_UXTH, 3, 5, 0, 0, {UINT32_C(0x53003ca3)}, 1, "UXTH"},
        {MACHINE_A64_ADD32, 3, 5, 7, 0, {UINT32_C(0x0b0700a3)}, 1, "ADD32"},
        {MACHINE_A64_ADD64, 3, 5, 7, 0, {UINT32_C(0x8b0700a3)}, 1, "ADD64"},
        {MACHINE_A64_SUB32, 3, 5, 7, 0, {UINT32_C(0x4b0700a3)}, 1, "SUB32"},
        {MACHINE_A64_SUB64, 3, 5, 7, 0, {UINT32_C(0xcb0700a3)}, 1, "SUB64"},
        {MACHINE_A64_AND32, 3, 5, 7, 0, {UINT32_C(0x0a0700a3)}, 1, "AND32"},
        {MACHINE_A64_AND64, 3, 5, 7, 0, {UINT32_C(0x8a0700a3)}, 1, "AND64"},
        {MACHINE_A64_ORR32, 3, 5, 7, 0, {UINT32_C(0x2a0700a3)}, 1, "ORR32"},
        {MACHINE_A64_ORR64, 3, 5, 7, 0, {UINT32_C(0xaa0700a3)}, 1, "ORR64"},
        {MACHINE_A64_EOR32, 3, 5, 7, 0, {UINT32_C(0x4a0700a3)}, 1, "EOR32"},
        {MACHINE_A64_EOR64, 3, 5, 7, 0, {UINT32_C(0xca0700a3)}, 1, "EOR64"},
        {MACHINE_A64_MUL32, 3, 5, 7, 0, {UINT32_C(0x1b077ca3)}, 1, "MUL32"},
        {MACHINE_A64_MUL64, 3, 5, 7, 0, {UINT32_C(0x9b077ca3)}, 1, "MUL64"},
        {MACHINE_A64_SDIV32, 3, 5, 7, 0, {UINT32_C(0x1ac70ca3)}, 1, "SDIV32"},
        {MACHINE_A64_SDIV64, 3, 5, 7, 0, {UINT32_C(0x9ac70ca3)}, 1, "SDIV64"},
        {MACHINE_A64_UDIV32, 3, 5, 7, 0, {UINT32_C(0x1ac708a3)}, 1, "UDIV32"},
        {MACHINE_A64_UDIV64, 3, 5, 7, 0, {UINT32_C(0x9ac708a3)}, 1, "UDIV64"},
        {MACHINE_A64_SREM32, 3, 5, 7, 0, {UINT32_C(0x1ac70ca3), UINT32_C(0x1b079463)}, 2, "SREM32"},
        {MACHINE_A64_SREM64, 3, 5, 7, 0, {UINT32_C(0x9ac70ca3), UINT32_C(0x9b079463)}, 2, "SREM64"},
        {MACHINE_A64_UREM32, 3, 5, 7, 0, {UINT32_C(0x1ac708a3), UINT32_C(0x1b079463)}, 2, "UREM32"},
        {MACHINE_A64_UREM64, 3, 5, 7, 0, {UINT32_C(0x9ac708a3), UINT32_C(0x9b079463)}, 2, "UREM64"},
        {MACHINE_A64_LSL32, 3, 5, 7, 0, {UINT32_C(0x1ac720a3)}, 1, "LSL32"},
        {MACHINE_A64_LSL64, 3, 5, 7, 0, {UINT32_C(0x9ac720a3)}, 1, "LSL64"},
        {MACHINE_A64_ASR32, 3, 5, 7, 0, {UINT32_C(0x1ac728a3)}, 1, "ASR32"},
        {MACHINE_A64_ASR64, 3, 5, 7, 0, {UINT32_C(0x9ac728a3)}, 1, "ASR64"},
        {MACHINE_A64_LSR32, 3, 5, 7, 0, {UINT32_C(0x1ac724a3)}, 1, "LSR32"},
        {MACHINE_A64_LSR64, 3, 5, 7, 0, {UINT32_C(0x9ac724a3)}, 1, "LSR64"},
        {MACHINE_A64_NEG32, 3, 5, 0, 0, {UINT32_C(0x4b0503e3)}, 1, "NEG32"},
        {MACHINE_A64_NEG64, 3, 5, 0, 0, {UINT32_C(0xcb0503e3)}, 1, "NEG64"},
        {MACHINE_A64_NOT32, 3, 5, 0, 0, {UINT32_C(0x2a2503e3)}, 1, "NOT32"},
        {MACHINE_A64_NOT64, 3, 5, 0, 0, {UINT32_C(0xaa2503e3)}, 1, "NOT64"},
        // Independent Clang integrated-assembler words, including register 31.
        {MACHINE_A64_CLZ32, 3, 5, 0, 0, {UINT32_C(0x5ac010a3)}, 1, "CLZ32"},
        {MACHINE_A64_CLZ64, 3, 5, 0, 0, {UINT32_C(0xdac010a3)}, 1, "CLZ64"},
        {MACHINE_A64_RBIT32, 3, 5, 0, 0, {UINT32_C(0x5ac000a3)}, 1, "RBIT32"},
        {MACHINE_A64_RBIT64, 3, 5, 0, 0, {UINT32_C(0xdac000a3)}, 1, "RBIT64"},
        {MACHINE_A64_CLZ32, 17, 31, 0, 0, {UINT32_C(0x5ac013f1)}, 1, "CLZ32 ZR"},
        {MACHINE_A64_CLZ64, 17, 31, 0, 0, {UINT32_C(0xdac013f1)}, 1, "CLZ64 ZR"},
        {MACHINE_A64_RBIT32, 17, 31, 0, 0, {UINT32_C(0x5ac003f1)}, 1, "RBIT32 ZR"},
        {MACHINE_A64_RBIT64, 17, 31, 0, 0, {UINT32_C(0xdac003f1)}, 1, "RBIT64 ZR"},
        {MACHINE_A64_CMP32, 5, 7, 0, 0, {UINT32_C(0x6b0700bf)}, 1, "CMP32"},
        {MACHINE_A64_CMP64, 5, 7, 0, 0, {UINT32_C(0xeb0700bf)}, 1, "CMP64"},
        {MACHINE_A64_CMP_ZERO, 5, 0, 0, 0, {UINT32_C(0xf10000bf)}, 1, "CMP_ZERO"},
        {MACHINE_A64_CSET, 3, 0, 0, 5, {UINT32_C(0x1a9f47e3)}, 1, "CSET"},
        {MACHINE_A64_FMOV_TO_VEC, 5, 0, 0, 3, {UINT32_C(0x9e6700a3)}, 1, "FMOV_TO_VEC"},
        {MACHINE_A64_FMOV_FROM_VEC, 3, 0, 0, 5, {UINT32_C(0x9e6600a3)}, 1, "FMOV_FROM_VEC"},
        {MACHINE_A64_READ_SP, 3, 0, 0, 7, {UINT32_C(0x91001fe3)}, 1, "READ_SP"},
        {MACHINE_A64_WRITE_SP, 5, 0, 0, 7, {UINT32_C(0x91001cbf)}, 1, "WRITE_SP"},
        {MACHINE_A64_RET, 0, 0, 0, 0, {UINT32_C(0xd65f03c0)}, 1, "RET"},
    };
    for (u32 case_index = 0; case_index < BUSTER_ARRAY_LENGTH(generated_machine_cases); case_index += 1)
    {
        u8 bytes[8] = {0};
        u32 byte_count = 0;
        bool error = false;
        bool emitted = machine_a64_test_emit_generated_opcode((u8*)bytes, sizeof(bytes), generated_machine_cases[case_index].opcode,
                                                               generated_machine_cases[case_index].operand0,
                                                               generated_machine_cases[case_index].operand1,
                                                               generated_machine_cases[case_index].operand2,
                                                               generated_machine_cases[case_index].payload, &byte_count, &error);
        BUSTER_TEST_RAW(arguments,
                        emitted && !error && byte_count == generated_machine_cases[case_index].expected_count * sizeof(u32) &&
                            memcmp(bytes, generated_machine_cases[case_index].expected, byte_count) == 0,
                        string_format(arguments->arena, S8("a64 generated machine opcode {S8}"), generated_machine_cases[case_index].name));
    }
    BUSTER_TEST(arguments, buster_aarch64_metadata_test_packed_access_count() == 0);
    // Branch-relaxation seam coverage.  These probes keep the sparse-layout
    // acceptance checks independent of a giant byte buffer: the fixed long
    // transfer handles every aligned signed delta, while the classifier pins
    // the direct/short/long decisions at both architectural boundaries.
    {
        s64 long_deltas[] = {
            -4,
            0,
            4,
            INT64_C(0x12345678),
            -INT64_C(0x12345678),
            INT64_MIN,
            INT64_MAX - 3,
        };
        for (u32 delta_index = 0; delta_index < BUSTER_ARRAY_LENGTH(long_deltas); delta_index += 1)
        {
            u8 bytes[28] = {0};
            u32 byte_count = 0;
            bool emitted = machine_a64_test_emit_long_branch(bytes, sizeof(bytes), long_deltas[delta_index], &byte_count);
            BUSTER_TEST(arguments, emitted && byte_count == 28);
            u32 words[7] = {0};
            memcpy(words, bytes, sizeof(words));
            BUSTER_TEST(arguments, words[0] == UINT32_C(0x10000010) && words[5] == UINT32_C(0x8b110210) && words[6] == UINT32_C(0xd61f0200));
            u64 reconstructed = ((u64)(words[1] >> 5) & UINT64_C(0xffff)) | (((u64)(words[2] >> 5) & UINT64_C(0xffff)) << 16) |
                                (((u64)(words[3] >> 5) & UINT64_C(0xffff)) << 32) | (((u64)(words[4] >> 5) & UINT64_C(0xffff)) << 48);
            BUSTER_TEST(arguments, reconstructed == (u64)long_deltas[delta_index]);
            u8 repeat[28] = {0};
            u32 repeat_count = 0;
            BUSTER_TEST(arguments, machine_a64_test_emit_long_branch(repeat, sizeof(repeat), long_deltas[delta_index], &repeat_count) && repeat_count == byte_count &&
                                      memcmp(repeat, bytes, sizeof(bytes)) == 0);
        }
        u8 bytes[28] = {0};
        u32 byte_count = 0;
        BUSTER_TEST(arguments, !machine_a64_test_emit_long_branch(bytes, 27, 0, &byte_count));
        BUSTER_TEST(arguments, !machine_a64_test_emit_long_branch(bytes, sizeof(bytes), 2, &byte_count));
    }
    {
        s64 b_min = -INT64_C(134217728);
        s64 b_max = INT64_C(134217724);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B, 0, b_min) == 0);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B, 0, b_max) == 0);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B, 0, b_min - 4) == 2);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B, 0, b_max + 4) == 2);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B, 0, 2) == UINT8_MAX);

        s64 bcc_min = -INT64_C(1048576);
        s64 bcc_max = INT64_C(1048572);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, bcc_min) == 0);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, bcc_max) == 0);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, bcc_min - 4) == 1);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, bcc_max + 4) == 1);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, b_min + 4) == 1);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, b_max + 4) == 1);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, b_min) == 2);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, b_max + 8) == 2);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 14, bcc_max) == 0);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 14, bcc_max + 4) == UINT8_MAX);
        BUSTER_TEST(arguments, machine_a64_test_branch_relaxation_tier(A64_OPCODE_B_COND, 0, 2) == UINT8_MAX);
    }
    {
        // Two interacting edges force a genuine convergence sequence without
        // allocating their 200 MiB virtual layout.  The first BCC starts in
        // the medium tier, its fallthrough B is at the adjacent word, and a
        // later long B insertion shifts the BCC target across B's upper
        // boundary, upgrading it atomically to inverse-cond + long transfer.
        u32 sparse_code_size = 200100000u;
        MachineA64TestSparseFixup sparse_fixups[] = {
            {.source_offset = 1000000u,
             .target_offset = 135217728u,
             .row_offset = 1000000u,
             .call_offset = 1000016u,
             .epilog_offset = 1000020u,
             .opcode = A64_OPCODE_B_COND,
             .condition = 0},
            {.source_offset = 1000004u,
             .target_offset = 1200000u,
             .row_offset = 1000004u,
             .call_offset = 1000024u,
             .epilog_offset = 1000028u,
             .opcode = A64_OPCODE_B,
             .condition = 0xff},
            {.source_offset = 50000000u,
             .target_offset = 200000000u,
             .row_offset = 50000000u,
             .call_offset = 50000016u,
             .epilog_offset = 50000020u,
             .opcode = A64_OPCODE_B,
             .condition = 0xff},
        };
        MachineA64TestSparseFixup sparse_repeat[BUSTER_ARRAY_LENGTH(sparse_fixups)];
        memcpy(sparse_repeat, sparse_fixups, sizeof(sparse_fixups));
        u32 sparse_final_size = 0;
        u32 sparse_repeat_size = 0;
        bool sparse_valid = machine_a64_test_relax_sparse(arguments->arena, sparse_code_size, sparse_fixups,
                                                           BUSTER_ARRAY_LENGTH(sparse_fixups), &sparse_final_size);
        bool sparse_repeat_valid = machine_a64_test_relax_sparse(arguments->arena, sparse_code_size, sparse_repeat,
                                                                  BUSTER_ARRAY_LENGTH(sparse_repeat), &sparse_repeat_size);
        BUSTER_TEST(arguments, sparse_valid && sparse_repeat_valid && sparse_final_size == sparse_code_size + 52u && sparse_repeat_size == sparse_final_size);
        BUSTER_TEST(arguments, memcmp(sparse_fixups, sparse_repeat, sizeof(sparse_fixups)) == 0);
        BUSTER_TEST(arguments, sparse_fixups[0].tier == 2 && sparse_fixups[1].tier == 0 && sparse_fixups[2].tier == 2);
        // BCC source remains at P, while its fallthrough B moves from P+4
        // past the 32-byte long conditional expansion. The later B source
        // and all targets/call/epilog/row metadata move by the same checked
        // insertions used by production.
        BUSTER_TEST(arguments, sparse_fixups[0].source_offset == 1000000u && sparse_fixups[0].target_offset == 135217780u);
        BUSTER_TEST(arguments, sparse_fixups[1].source_offset == 1000032u && sparse_fixups[1].target_offset == 1200028u);
        BUSTER_TEST(arguments, sparse_fixups[2].source_offset == 50000028u && sparse_fixups[2].target_offset == 200000052u);
        BUSTER_TEST(arguments, sparse_fixups[1].row_offset == 1000032u && sparse_fixups[1].call_offset == 1000052u &&
                                  sparse_fixups[1].epilog_offset == 1000056u);
        BUSTER_TEST(arguments, sparse_fixups[2].row_offset == 50000028u && sparse_fixups[2].call_offset == 50000068u &&
                                  sparse_fixups[2].epilog_offset == 50000072u);

        MachineA64TestSparseFixup overflow_fixup = {
            .source_offset = UINT32_MAX - 7u,
            .target_offset = 0,
            .row_offset = UINT32_MAX - 7u,
            .call_offset = UINT32_MAX - 7u,
            .epilog_offset = UINT32_MAX - 7u,
            .opcode = A64_OPCODE_B,
            .condition = 0xff,
        };
        u32 overflow_size = 0;
        BUSTER_TEST(arguments, !machine_a64_test_relax_sparse(arguments->arena, UINT32_MAX - 3u, &overflow_fixup, 1, &overflow_size));
        MachineA64TestSparseFixup malformed_fixup = overflow_fixup;
        malformed_fixup.source_offset = 2;
        BUSTER_TEST(arguments, !machine_a64_test_relax_sparse(arguments->arena, 64, &malformed_fixup, 1, &overflow_size));
    }
    IrProgram* machine_a64_program = machine_test_compile_c(arguments->arena, S8("machine-stage11.c"), machine_c_source_stage11, machine_a64_target);
    BUSTER_TEST(arguments, machine_a64_program != 0);
    if (machine_a64_program && machine_a64_program->module_count)
    {
        IrModule* machine_a64_module = machine_a64_program->modules;
        CodegenModule a64_none_module = codegen_generate_canonical_module(arguments->arena, machine_a64_program, machine_a64_module, machine_a64_target,
                                                                          (CodegenModuleOptions){0});
        BUSTER_TEST(arguments, a64_none_module.error == CODEGEN_ERROR_NONE);
        String8 a64_supported_names[] = {
            S8_INITIALIZER("add"),     S8_INITIALIZER("mul"),    S8_INITIALIZER("widen"),  S8_INITIALIZER("narrow"),
            S8_INITIALIZER("negate"),  S8_INITIALIZER("bitnot"), S8_INITIALIZER("lnot"),   S8_INITIALIZER("less"),
            S8_INITIALIZER("uless"),   S8_INITIALIZER("six"),    S8_INITIALIZER("seven"),  S8_INITIALIZER("sum_to"),
            S8_INITIALIZER("readp"),   S8_INITIALIZER("writep"), S8_INITIALIZER("divide"), S8_INITIALIZER("srem"),
            S8_INITIALIZER("udiv"),    S8_INITIALIZER("shl"),    S8_INITIALIZER("sar"),    S8_INITIALIZER("shr"),
            S8_INITIALIZER("local_pair"), S8_INITIALIZER("kagg_take"), S8_INITIALIZER("big_make"),
            S8_INITIALIZER("arr_lit"), S8_INITIALIZER("bits"), S8_INITIALIZER("union_tail"), S8_INITIALIZER("locals_array"),
            S8_INITIALIZER("fmath"), S8_INITIALIZER("f32math"), S8_INITIALIZER("fcompare"), S8_INITIALIZER("fnegate"),
            S8_INITIALIZER("fnan"), S8_INITIALIZER("fuconv"), S8_INITIALIZER("ucvt"), S8_INITIALIZER("stack_tail"),
            S8_INITIALIZER("vsum"), S8_INITIALIZER("vec_pass"), S8_INITIALIZER("big_take"),
            S8_INITIALIZER("fpair_tail"), S8_INITIALIZER("pair_spill"),
            S8_INITIALIZER("aligned_local"), S8_INITIALIZER("aligned_spot"), S8_INITIALIZER("vlit_make"),
            S8_INITIALIZER("vquad_add"), S8_INITIALIZER("vf4_scale"), S8_INITIALIZER("amix"),
            S8_INITIALIZER("atomic_pair_round"), S8_INITIALIZER("atomic_nine_round"),
            S8_INITIALIZER("vla_fill"), S8_INITIALIZER("pick4"), S8_INITIALIZER("v8_pass"), S8_INITIALIZER("v2_make"),
        };
        MachineEncodeResult a64_encoded[BUSTER_ARRAY_LENGTH(a64_supported_names)] = {0};
        for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(a64_supported_names); name_index += 1)
        {
            IrFunction* ir_function = machine_test_ir_function_find(machine_a64_module, a64_supported_names[name_index]);
            BUSTER_TEST(arguments, ir_function != 0);
            if (!ir_function)
            {
                continue;
            }
            MachineSelectResult selected = {0};
            a64_encoded[name_index] = machine_test_encode(arguments->arena, machine_a64_program, ir_function, machine_a64_target, &selected);
            BUSTER_TEST_RAW(arguments, selected.supported,
                            string_format(arguments->arena, S8("a64 select {S8} failed at opcode {u32}"), a64_supported_names[name_index],
                                          (u32)selected.failed_opcode));
            BUSTER_TEST(arguments, a64_encoded[name_index].valid);
            BUSTER_TEST(arguments, a64_encoded[name_index].byte_count > 16 && a64_encoded[name_index].byte_count % 4 == 0);
            if (!a64_encoded[name_index].valid)
            {
                continue;
            }
            // The prologue shape is fixed: stp x29, x30, [sp, #-16]!;
            // mov x29, sp.
            u32 first_word = 0;
            u32 second_word = 0;
            memcpy(&first_word, a64_encoded[name_index].bytes, sizeof(first_word));
            memcpy(&second_word, a64_encoded[name_index].bytes + 4, sizeof(second_word));
            BUSTER_TEST(arguments, first_word == 0xa9bf7bfd && second_word == 0x910003fd);
            // Every return emits one recorded epilogue.
            BUSTER_TEST(arguments, a64_encoded[name_index].epilog_count >= 1);
        }
        // Placement over the AArch64 rows: the shared MIR_STACK builder
        // consumes the target description the selector stamped.
        IrFunction* a64_add_function = machine_test_ir_function_find(machine_a64_module, S8("add"));
        if (a64_add_function)
        {
            MachineSelectResult a64_add_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_add_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_add_selected.supported);
            BUSTER_TEST(arguments, a64_add_selected.function.target == machine_target_aarch64());
            MachineStackPlacement a64_add_placement = machine_stack_placement_build(arguments->arena, &a64_add_selected.function);
            BUSTER_TEST(arguments, a64_add_placement.valid);
            BUSTER_TEST(arguments, a64_add_placement.reload_count > 0 && a64_add_placement.spill_count > 0);
            BUSTER_TEST(arguments, a64_add_placement.frame_size % 16 == 0);
        }
        IrFunction* a64_srem_function = machine_test_ir_function_find(machine_a64_module, S8("srem"));
        if (a64_srem_function)
        {
            MachineSelectResult a64_srem_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_srem_function, machine_a64_target);
            bool saw_divide = false;
            bool saw_multiply = false;
            bool saw_subtract = false;
            bool saw_remainder_pseudo = false;
            bool one_definition_each = true;
            u32* definition_counts = a64_srem_selected.supported
                                          ? arena_allocate(arguments->arena, u32, a64_srem_selected.function.virtual_register_count ?
                                                                                     a64_srem_selected.function.virtual_register_count
                                                                                                                           : 1)
                                          : 0;
            for (u32 register_index = 0; definition_counts && register_index < a64_srem_selected.function.virtual_register_count; register_index += 1)
            {
                definition_counts[register_index] = 0;
            }
            for (u32 row_index = 0; a64_srem_selected.supported && row_index < a64_srem_selected.function.instruction_count; row_index += 1)
            {
                MachineInstruction* row = a64_srem_selected.function.instructions + row_index;
                u16 opcode = row->opcode;
                saw_divide |= opcode == MACHINE_A64_SDIV32 || opcode == MACHINE_A64_SDIV64 || opcode == MACHINE_A64_UDIV32 || opcode == MACHINE_A64_UDIV64;
                saw_multiply |= opcode == MACHINE_A64_MUL32 || opcode == MACHINE_A64_MUL64;
                saw_subtract |= opcode == MACHINE_A64_SUB32 || opcode == MACHINE_A64_SUB64;
                saw_remainder_pseudo |= opcode == MACHINE_A64_SREM32 || opcode == MACHINE_A64_SREM64 || opcode == MACHINE_A64_UREM32 || opcode == MACHINE_A64_UREM64;
                MachineOpcodeInfo const* info = machine_opcode_info(opcode);
                for (u32 slot = 0; info && slot < info->operand_count; slot += 1)
                {
                    MachineRef operand_ref = row->operands[slot];
                    u32 role = info->operand_info[slot] & ((1u << MACHINE_OPERAND_ROLE_BITS) - 1u);
                    if (definition_counts && machine_ref_kind(operand_ref) == MACHINE_REF_VIRTUAL_REGISTER &&
                        (role == MACHINE_OPERAND_ROLE_DEFINE || role == MACHINE_OPERAND_ROLE_USE_DEFINE))
                    {
                        u32 register_index = machine_ref_payload(operand_ref);
                        if (register_index < a64_srem_selected.function.virtual_register_count)
                        {
                            definition_counts[register_index] += 1;
                            one_definition_each &= definition_counts[register_index] == 1;
                        }
                    }
                }
            }
            BUSTER_TEST(arguments, a64_srem_selected.supported && saw_divide && saw_multiply && saw_subtract && !saw_remainder_pseudo && one_definition_each);
        }
        // Callee-saved encoding: a value pinned to X27 for its whole
        // lifetime forces the prologue save at the top of the frame area
        // and the epilogue restore, which nothing in the C corpus's
        // two-instruction lifetimes otherwise exercises.
        IrFunction* a64_pin_function = machine_test_ir_function_find(machine_a64_module, S8("add"));
        if (a64_pin_function)
        {
            MachineSelectResult a64_pin_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_pin_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_pin_selected.supported);
            if (a64_pin_selected.supported && a64_pin_selected.function.virtual_register_count)
            {
                u32* forced_pins = arena_allocate(arguments->arena, u32, a64_pin_selected.function.virtual_register_count);
                for (u32 register_index = 0; register_index < a64_pin_selected.function.virtual_register_count; register_index += 1)
                {
                    forced_pins[register_index] = UINT32_MAX;
                }
                forced_pins[0] = MACHINE_A64_X27;
                MachineStackPlacement a64_pinned_placement =
                    machine_fast_placement_build_pinned(arguments->arena, &a64_pin_selected.function, forced_pins, 1u << MACHINE_A64_X27, 0, 0, 0, 0, 0, 0, 0);
                BUSTER_TEST(arguments, a64_pinned_placement.valid);
                BUSTER_TEST(arguments, (a64_pinned_placement.callee_saved_mask >> MACHINE_A64_X27) & 1u);
                MachineEncodeResult a64_pinned_encoded = machine_encode_aarch64(arguments->arena, &a64_pin_selected.function, &a64_pinned_placement);
                BUSTER_TEST(arguments, a64_pinned_encoded.valid);
                if (a64_pinned_encoded.valid)
                {
                    // The save is one scaled str of x27 against SP; its
                    // exact offset rides at the top of the frame area.
                    u32 a64_pin_area = a64_pinned_placement.frame_size + 8;
                    u32 save_word = 0xf90003e0u | (((a64_pin_area - 8) / 8) << 10) | ((u32)MACHINE_A64_SP << 5) | MACHINE_A64_X27;
                    u32 restore_word = 0xf94003e0u | (((a64_pin_area - 8) / 8) << 10) | ((u32)MACHINE_A64_SP << 5) | MACHINE_A64_X27;
                    bool save_found = false;
                    bool restore_found = false;
                    for (u32 byte_offset = 0; byte_offset + 4 <= a64_pinned_encoded.byte_count; byte_offset += 4)
                    {
                        u32 word = 0;
                        memcpy(&word, a64_pinned_encoded.bytes + byte_offset, sizeof(word));
                        save_found |= word == save_word;
                        restore_found |= word == restore_word;
                    }
                    BUSTER_TEST(arguments, save_found && restore_found);
#if BUSTER_CPU_ARCH_AARCH64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
                    CodegenExecutable a64_pinned_executable = codegen_make_executable((CodegenFunction){
                        .code = {.pointer = a64_pinned_encoded.bytes, .length = a64_pinned_encoded.byte_count},
                    });
                    BUSTER_TEST(arguments, a64_pinned_executable.error == CODEGEN_ERROR_NONE);
                    if (a64_pinned_executable.address)
                    {
                        typedef s64 MachineTestA64Pinned(s64, s64);
                        MachineTestA64Pinned* pinned_call = 0;
                        memcpy(&pinned_call, &a64_pinned_executable.address, sizeof(pinned_call));
                        BUSTER_TEST(arguments, (s32)pinned_call(19, 23) == 42);
                        codegen_release_executable(a64_pinned_executable);
                    }
#endif
                }
            }
        }
        // Splitting on the second target: the split machinery is
        // target-parameterized and split_phase must select and place
        // cleanly under the AArch64 file. No split can fire here yet —
        // the AArch64 selector does not promote scalar locals the way
        // stage 10i taught the x86-64 one, so the loop values stay
        // frame-resident and QUALITY sees no candidates; when promotion
        // reaches this selector, this block should tighten to the x86-64
        // assertion.
        IrFunction* a64_split_function = machine_test_ir_function_find(machine_a64_module, S8("split_phase"));
        BUSTER_TEST(arguments, a64_split_function != 0);
        if (a64_split_function)
        {
            MachineSelectResult a64_split_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_split_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_split_selected.supported);
            if (a64_split_selected.supported)
            {
                MachineStackPlacement a64_split_quality = machine_quality_placement_build(arguments->arena, &a64_split_selected.function);
                BUSTER_TEST(arguments, a64_split_quality.valid);
            }
        }
        // Direct calls select into fixed-register argument copies plus a
        // relocated call row; float signatures are the current explicit
        // unsupported representative.
        IrFunction* a64_call_function = machine_test_ir_function_find(machine_a64_module, S8("with_call"));
        BUSTER_TEST(arguments, a64_call_function != 0);
        if (a64_call_function)
        {
            MachineSelectResult a64_call_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_call_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_call_selected.supported);
            BUSTER_TEST(arguments, a64_call_selected.function.call_target_count >= 2);
        }
        // Float bodies now select through the FARITH/FCMP rows; label
        // addresses are the current explicit unsupported representative.
        IrFunction* a64_float_function = machine_test_ir_function_find(machine_a64_module, S8("fadd"));
        BUSTER_TEST(arguments, a64_float_function != 0);
        if (a64_float_function)
        {
            MachineSelectResult a64_float_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_float_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_float_selected.supported);
        }
        IrFunction* a64_goto_function = machine_test_ir_function_find(machine_a64_module, S8("goto_probe"));
        BUSTER_TEST(arguments, a64_goto_function != 0);
        if (a64_goto_function)
        {
            MachineSelectResult a64_goto_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_goto_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_goto_selected.supported);
            if (a64_goto_selected.supported)
            {
                MachineStackPlacement a64_goto_placement = machine_stack_placement_build(arguments->arena, &a64_goto_selected.function);
                MachineEncodeResult a64_goto_encoded =
                    machine_encode_aarch64(arguments->arena, &a64_goto_selected.function, &a64_goto_placement);
                BUSTER_TEST(arguments, a64_goto_placement.valid && a64_goto_encoded.valid && a64_goto_encoded.byte_count != 0);
            }
        }
        // An aggregate literal built and passed onward: kagg's call keeps it
        // out of the raw-copy execution list, so it is asserted as selection
        // coverage like with_call.
        IrFunction* a64_kagg_function = machine_test_ir_function_find(machine_a64_module, S8("kagg"));
        BUSTER_TEST(arguments, a64_kagg_function != 0);
        if (a64_kagg_function)
        {
            MachineSelectResult a64_kagg_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_kagg_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_kagg_selected.supported);
        }
        // Stack-argument callers: call_stack_tail spills the ninth and tenth
        // long into the outgoing area, and nine spills its ninth double —
        // both call-bearing or float-signatured, so selection coverage only.
        IrFunction* a64_stack_caller_function = machine_test_ir_function_find(machine_a64_module, S8("call_stack_tail"));
        BUSTER_TEST(arguments, a64_stack_caller_function != 0);
        if (a64_stack_caller_function)
        {
            MachineSelectResult a64_stack_caller_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_stack_caller_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_stack_caller_selected.supported);
            BUSTER_TEST(arguments, a64_stack_caller_selected.function.outgoing_bytes == 16);
        }
        IrFunction* a64_nine_function = machine_test_ir_function_find(machine_a64_module, S8("nine"));
        BUSTER_TEST(arguments, a64_nine_function != 0);
        if (a64_nine_function)
        {
            MachineSelectResult a64_nine_selected =
                machine_select_canonical_function(arguments->arena, machine_a64_program, a64_nine_function, machine_a64_target);
            BUSTER_TEST(arguments, a64_nine_selected.supported);
        }
        // Sixteen-byte atomic loads and stores stay slot-backed and select
        // into their exclusive-pair rows. The packed nine-byte case pins
        // promoted-padding masking as well as the sequential acquire/release
        // strengths; the full pair covers ordinary acquire/release.
        String8 a64_atomic_pair_names[] = {S8("atomic_pair_round"), S8("atomic_nine_round")};
        u32 a64_atomic_pair_sizes[] = {16, 9};
        u32 a64_atomic_store_flags[] = {MACHINE_A64_ATOMIC_PAIR_RELEASE,
                                        MACHINE_A64_ATOMIC_PAIR_ACQUIRE | MACHINE_A64_ATOMIC_PAIR_RELEASE};
        u32 a64_atomic_load_flags[] = {MACHINE_A64_ATOMIC_PAIR_ACQUIRE,
                                       MACHINE_A64_ATOMIC_PAIR_ACQUIRE | MACHINE_A64_ATOMIC_PAIR_RELEASE};
        for (u32 atomic_index = 0; atomic_index < BUSTER_ARRAY_LENGTH(a64_atomic_pair_names); atomic_index += 1)
        {
            IrFunction* atomic_function = machine_test_ir_function_find(machine_a64_module, a64_atomic_pair_names[atomic_index]);
            BUSTER_TEST(arguments, atomic_function != 0);
            if (atomic_function)
            {
                MachineSelectResult atomic_selected =
                    machine_select_canonical_function(arguments->arena, machine_a64_program, atomic_function, machine_a64_target);
                u32 load_rows = 0;
                u32 store_rows = 0;
                bool payloads_match = true;
                for (u32 row_index = 0; atomic_selected.supported && row_index < atomic_selected.function.instruction_count; row_index += 1)
                {
                    MachineInstruction* row = atomic_selected.function.instructions + row_index;
                    if (row->opcode == MACHINE_A64_ATOMIC_LOAD_PAIR)
                    {
                        load_rows += 1;
                        payloads_match &= row->payload == (a64_atomic_pair_sizes[atomic_index] | a64_atomic_load_flags[atomic_index]);
                    }
                    else if (row->opcode == MACHINE_A64_ATOMIC_STORE_PAIR)
                    {
                        store_rows += 1;
                        payloads_match &= row->payload == (a64_atomic_pair_sizes[atomic_index] | a64_atomic_store_flags[atomic_index]);
                    }
                }
                BUSTER_TEST_RAW(arguments, atomic_selected.supported,
                                string_format(arguments->arena, S8("a64 pair select {S8} failed at opcode {u32}"),
                                              a64_atomic_pair_names[atomic_index], (u32)atomic_selected.failed_opcode));
                BUSTER_TEST(arguments, load_rows == 1 && store_rows == 1 && payloads_match);
                BUSTER_TEST(arguments, machine_verify_function(&atomic_selected.function).error == MACHINE_VERIFY_NONE);
                MachineStackPlacement atomic_placement = machine_stack_placement_build(arguments->arena, &atomic_selected.function);
                MachineEncodeResult atomic_encoded = atomic_placement.valid
                                                         ? machine_encode_aarch64(arguments->arena, &atomic_selected.function, &atomic_placement)
                                                         : (MachineEncodeResult){0};
                BUSTER_TEST(arguments, atomic_placement.valid && atomic_encoded.valid && atomic_encoded.byte_count > 32);
                bool saw_pair_load = false;
                bool saw_pair_store = false;
                u32 expected_load = (a64_atomic_load_flags[atomic_index] ? UINT32_C(0xc87f8000) : UINT32_C(0xc87f0000)) |
                                    (MACHINE_A64_X14 << 10) | (MACHINE_A64_X10 << 5) | MACHINE_A64_X9;
                u32 expected_store_load = (a64_atomic_store_flags[atomic_index] & MACHINE_A64_ATOMIC_PAIR_ACQUIRE ? UINT32_C(0xc87f8000)
                                                                                                                  : UINT32_C(0xc87f0000)) |
                                          (MACHINE_A64_X14 << 10) | (MACHINE_A64_X10 << 5) | MACHINE_A64_X9;
                u32 expected_read_back = (a64_atomic_load_flags[atomic_index] & MACHINE_A64_ATOMIC_PAIR_RELEASE ? UINT32_C(0xc8208000)
                                                                                                               : UINT32_C(0xc8200000)) |
                                         (MACHINE_A64_X13 << 16) | (MACHINE_A64_X14 << 10) | (MACHINE_A64_X10 << 5) | MACHINE_A64_X9;
                u32 expected_store = (a64_atomic_store_flags[atomic_index] & MACHINE_A64_ATOMIC_PAIR_RELEASE ? UINT32_C(0xc8208000)
                                                                                                             : UINT32_C(0xc8200000)) |
                                     (MACHINE_A64_X13 << 16) | (MACHINE_A64_X12 << 10) | (MACHINE_A64_X10 << 5) | MACHINE_A64_X11;
                u32 expected_retry = UINT32_C(0x35ffffcd);
                for (u32 byte_offset = 0; atomic_encoded.valid && byte_offset + 3 * sizeof(u32) <= atomic_encoded.byte_count;
                     byte_offset += sizeof(u32))
                {
                    u32 word = 0;
                    u32 next_word = 0;
                    u32 retry_word = 0;
                    memcpy(&word, atomic_encoded.bytes + byte_offset, sizeof(word));
                    memcpy(&next_word, atomic_encoded.bytes + byte_offset + sizeof(u32), sizeof(next_word));
                    memcpy(&retry_word, atomic_encoded.bytes + byte_offset + 2 * sizeof(u32), sizeof(retry_word));
                    saw_pair_load |= word == expected_load && next_word == expected_read_back && retry_word == expected_retry;
                    saw_pair_store |= word == expected_store_load && next_word == expected_store && retry_word == expected_retry;
                }
                BUSTER_TEST(arguments, saw_pair_load && saw_pair_store);
            }
        }
        // Every function in this module now uses the AArch64 machine path.
        CodegenModule a64_mir_module = codegen_generate_canonical_module(arguments->arena, machine_a64_program, machine_a64_module, machine_a64_target,
                                                                         (CodegenModuleOptions){
                                                                             .register_allocator = CODEGEN_REGISTER_ALLOCATOR_MIR_STACK,
                                                                         });
        BUSTER_TEST(arguments, a64_mir_module.error == CODEGEN_ERROR_NONE);
        BUSTER_TEST(arguments, a64_none_module.statistics.fallback_function_count == 0);
        BUSTER_TEST(arguments, a64_mir_module.statistics.fallback_function_count == 0);
        IrFunction* a64_mir_add = machine_test_ir_function_find(machine_a64_module, S8("add"));
        if (a64_mir_add)
        {
            CodegenFunctionDescriptor* a64_add_descriptor = 0;
            for (u32 descriptor_index = 0; descriptor_index < a64_mir_module.function_count; descriptor_index += 1)
            {
                if (a64_mir_module.functions[descriptor_index].symbol.value == a64_mir_add->symbol.value)
                {
                    a64_add_descriptor = a64_mir_module.functions + descriptor_index;
                    break;
                }
            }
            BUSTER_TEST(arguments, a64_add_descriptor != 0);
            BUSTER_TEST(arguments, a64_add_descriptor && a64_add_descriptor->code_size > 16);
            // The machine prologue's actions mirror the canonical AArch64
            // shape: the frame-pointer pair's allocation first, the x28
            // save last, and one recorded epilogue per return.
            BUSTER_TEST(arguments, a64_add_descriptor && a64_add_descriptor->unwind_action_count >= 5 &&
                                       a64_add_descriptor->unwind_actions[0].kind == CODEGEN_UNWIND_ACTION_ALLOCATE_STACK &&
                                       a64_add_descriptor->unwind_actions[0].value == 16);
            BUSTER_TEST(arguments, a64_add_descriptor && a64_add_descriptor->epilog_count >= 1);
            BUSTER_TEST(arguments, a64_add_descriptor && a64_add_descriptor->prolog_size >= 24 && a64_add_descriptor->prolog_size % 4 == 0);
        }
#if BUSTER_CPU_ARCH_AARCH64 && !BUSTER_WINDOWS && !BUSTER_SANITIZE
        // Native execution differential: the canonical NONE module is the
        // oracle at each function's entry offset. Only call-free,
        // global-free functions execute from raw code copies.
        CodegenExecutable a64_none_executable = codegen_make_executable((CodegenFunction){
            .code = a64_none_module.code,
        });
        BUSTER_TEST(arguments, a64_none_executable.error == CODEGEN_ERROR_NONE);
        typedef s64 MachineTestA64Call2(s64, s64);
        typedef s64 MachineTestA64Call7(s64, s64, s64, s64, s64, s64, s64);
        typedef s64 MachineTestA64Call3(s64, s64, s64);
        typedef s64 MachineTestA64Call10(s64, s64, s64, s64, s64, s64, s64, s64, s64, s64);
        // Matches the corpus Big layout; returned through the X8 hidden
        // pointer, which the host compiler stages for a struct-returning
        // call — identical under AAPCS64 and the Darwin convention.
        typedef struct MachineTestA64Big
        {
            s64 a;
            s64 b;
            s64 c;
        } MachineTestA64Big;
        typedef MachineTestA64Big MachineTestA64CallBig(s64);
        // Sixteen-byte short vectors ride V0 in and out under AAPCS64 and
        // the Darwin convention alike.
        typedef float MachineTestA64V4 __attribute__((vector_size(16)));
        typedef MachineTestA64V4 MachineTestA64CallV4(MachineTestA64V4);
        // The literal-constructing form: two integer arguments in, the
        // sixteen-byte vector result out through V0, so the vector ARRAY
        // path executes with scalar-only incoming registers.
        typedef s32 MachineTestA64VLit __attribute__((vector_size(16)));
        typedef MachineTestA64VLit MachineTestA64CallVLit(s32, s32);
        // The arithmetic forms: two sixteen-byte vectors in V0/V1, the
        // result out through V0, so the VARITH chunk rows execute between
        // the entry captures and the return load on both conventions.
        typedef MachineTestA64VLit MachineTestA64CallVQuad(MachineTestA64VLit, MachineTestA64VLit);
        typedef MachineTestA64V4 MachineTestA64CallVF4(MachineTestA64V4, MachineTestA64V4);
        // Sub-sixteen-byte short vectors ride the low bytes of V0 in and
        // out under AAPCS64 and the Darwin convention alike, so the sized
        // V transfers execute natively on either host.
        typedef u8 MachineTestA64V8 __attribute__((vector_size(8)));
        typedef MachineTestA64V8 MachineTestA64CallV8(MachineTestA64V8);
        typedef u8 MachineTestA64V2 __attribute__((vector_size(2)));
        typedef MachineTestA64V2 MachineTestA64CallV2(s32);
        // Matches the corpus MachineBig3 layout: a twenty-four-byte
        // composite passes indirectly behind a caller-side copy that the
        // host compiler stages, identically under both conventions.
        typedef struct MachineTestA64Big3
        {
            s64 a;
            s64 b;
            s64 c;
        } MachineTestA64Big3;
        typedef s64 MachineTestA64CallBig3(MachineTestA64Big3, s64);
        // Stack-passed aggregate shapes with nothing after them, so the
        // subset's open-file quirks never diverge from the host compiler's
        // conventions: the HFA lands at the stack base once V0-V7 are
        // full, and the two-part pair lands there once X0-X6 leave one
        // integer register short.
        typedef struct MachineTestA64FPair
        {
            double left;
            double right;
        } MachineTestA64FPair;
        typedef double MachineTestA64CallFPairTail(double, double, double, double, double, double, double, double, MachineTestA64FPair);
        typedef struct MachineTestA64Pair2
        {
            s64 low;
            s64 high;
        } MachineTestA64Pair2;
        typedef s64 MachineTestA64CallPairSpill(s64, s64, s64, s64, s64, s64, s64, MachineTestA64Pair2);
        for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(a64_supported_names) && a64_none_executable.address; name_index += 1)
        {
            if (!a64_encoded[name_index].valid)
            {
                continue;
            }
            IrFunction* ir_function = machine_test_ir_function_find(machine_a64_module, a64_supported_names[name_index]);
            u32 none_offset = UINT32_MAX;
            for (u32 entry_index = 0; entry_index < a64_none_module.entry_count; entry_index += 1)
            {
                if (ir_function && a64_none_module.entries[entry_index].symbol.value == ir_function->symbol.value)
                {
                    none_offset = a64_none_module.entries[entry_index].offset;
                    break;
                }
            }
            BUSTER_TEST(arguments, none_offset != UINT32_MAX);
            CodegenExecutable a64_machine_executable = codegen_make_executable((CodegenFunction){
                .code = {.pointer = a64_encoded[name_index].bytes, .length = a64_encoded[name_index].byte_count},
            });
            BUSTER_TEST(arguments, a64_machine_executable.error == CODEGEN_ERROR_NONE);
            if (none_offset == UINT32_MAX || !a64_machine_executable.address)
            {
                continue;
            }
            // The shape-bearing signatures need their real calling forms:
            // kagg_take's two-part aggregate arrives as two integer
            // registers plus the salt in the third, and big_make returns
            // through the X8 hidden pointer the caller must provide — a
            // raw two-argument call would hand it garbage.
            bool is_pair_take = string_equal(a64_supported_names[name_index], S8("kagg_take"));
            bool is_indirect_make = string_equal(a64_supported_names[name_index], S8("big_make"));
            bool is_writep = string_equal(a64_supported_names[name_index], S8("writep"));
            bool is_readp = string_equal(a64_supported_names[name_index], S8("readp"));
            bool is_many = string_equal(a64_supported_names[name_index], S8("six")) || string_equal(a64_supported_names[name_index], S8("seven"));
            bool is_stack_tail = string_equal(a64_supported_names[name_index], S8("stack_tail"));
            bool is_vsum = string_equal(a64_supported_names[name_index], S8("vsum"));
            bool is_vec_pass = string_equal(a64_supported_names[name_index], S8("vec_pass"));
            bool is_vlit_make = string_equal(a64_supported_names[name_index], S8("vlit_make"));
            bool is_vquad_add = string_equal(a64_supported_names[name_index], S8("vquad_add"));
            bool is_vf4_scale = string_equal(a64_supported_names[name_index], S8("vf4_scale"));
            bool is_v8_pass = string_equal(a64_supported_names[name_index], S8("v8_pass"));
            bool is_v2_make = string_equal(a64_supported_names[name_index], S8("v2_make"));
            bool is_big_take = string_equal(a64_supported_names[name_index], S8("big_take"));
            bool is_fpair_tail = string_equal(a64_supported_names[name_index], S8("fpair_tail"));
            bool is_pair_spill = string_equal(a64_supported_names[name_index], S8("pair_spill"));
            bool is_loop = string_equal(a64_supported_names[name_index], S8("sum_to"));
            bool wide_result = string_equal(a64_supported_names[name_index], S8("widen")) ||
                               string_equal(a64_supported_names[name_index], S8("bitnot")) ||
                               string_equal(a64_supported_names[name_index], S8("sar")) ||
                               string_equal(a64_supported_names[name_index], S8("arr_lit")) ||
                               string_equal(a64_supported_names[name_index], S8("bits")) ||
                               string_equal(a64_supported_names[name_index], S8("union_tail")) ||
                               string_equal(a64_supported_names[name_index], S8("ucvt")) ||
                               string_equal(a64_supported_names[name_index], S8("udiv")) ||
                               string_equal(a64_supported_names[name_index], S8("aligned_spot")) ||
                               string_equal(a64_supported_names[name_index], S8("amix")) ||
                               string_equal(a64_supported_names[name_index], S8("atomic_pair_round")) ||
                               string_equal(a64_supported_names[name_index], S8("atomic_nine_round")) ||
                               string_equal(a64_supported_names[name_index], S8("vla_fill")) ||
                               string_equal(a64_supported_names[name_index], S8("pick4")) || is_readp;
            bool is_division = string_equal(a64_supported_names[name_index], S8("divide")) ||
                               string_equal(a64_supported_names[name_index], S8("srem")) ||
                               string_equal(a64_supported_names[name_index], S8("udiv"));
            s64 probe_arguments[][2] = {
                {0, 0}, {1, 2}, {-1, 5}, {123456789, -987654321}, {-2147483647, 2147483647}, {40, 2}, {7, -7},
            };
            bool all_equal = true;
            for (u32 probe_index = 0; probe_index < BUSTER_ARRAY_LENGTH(probe_arguments); probe_index += 1)
            {
                s64 left = probe_arguments[probe_index][0];
                s64 right = probe_arguments[probe_index][1];
                if (is_loop)
                {
                    left &= 63;
                }
                if (is_division)
                {
                    right |= 1;
                }
                void* none_address = (u8*)a64_none_executable.address + none_offset;
                void* machine_address = a64_machine_executable.address;
                MachineTestA64Call2* none_call = 0;
                MachineTestA64Call2* machine_call = 0;
                memcpy(&none_call, &none_address, sizeof(none_call));
                memcpy(&machine_call, &machine_address, sizeof(machine_call));
                if (is_pair_take)
                {
                    MachineTestA64Call3* none_call3 = 0;
                    MachineTestA64Call3* machine_call3 = 0;
                    memcpy(&none_call3, &none_address, sizeof(none_call3));
                    memcpy(&machine_call3, &machine_address, sizeof(machine_call3));
                    all_equal &= none_call3(left, right, left ^ right) == machine_call3(left, right, left ^ right);
                }
                else if (is_indirect_make)
                {
                    MachineTestA64CallBig* none_call_big = 0;
                    MachineTestA64CallBig* machine_call_big = 0;
                    memcpy(&none_call_big, &none_address, sizeof(none_call_big));
                    memcpy(&machine_call_big, &machine_address, sizeof(machine_call_big));
                    MachineTestA64Big none_big = none_call_big(left);
                    MachineTestA64Big machine_big = machine_call_big(left);
                    all_equal &= none_big.a == machine_big.a && none_big.b == machine_big.b && none_big.c == machine_big.c;
                }
                else if (is_writep)
                {
                    s32 none_cell = 0;
                    s32 machine_cell = 0;
                    none_call((s64)(u64)&none_cell, right);
                    machine_call((s64)(u64)&machine_cell, right);
                    all_equal &= none_cell == machine_cell;
                }
                else if (is_readp)
                {
                    s64 cell = left * 3 + right;
                    all_equal &= none_call((s64)(u64)&cell, 0) == machine_call((s64)(u64)&cell, 0);
                }
                else if (is_many)
                {
                    MachineTestA64Call7* none_call7 = 0;
                    MachineTestA64Call7* machine_call7 = 0;
                    memcpy(&none_call7, &none_address, sizeof(none_call7));
                    memcpy(&machine_call7, &machine_address, sizeof(machine_call7));
                    s32 none_result = (s32)none_call7(left, right, left + 1, right + 1, left - 2, right - 2, left + 3);
                    s32 machine_result = (s32)machine_call7(left, right, left + 1, right + 1, left - 2, right - 2, left + 3);
                    all_equal &= none_result == machine_result;
                }
                else if (is_stack_tail)
                {
                    // Ten arguments: the ninth and tenth travel through the
                    // caller's outgoing stack area on AAPCS64.
                    MachineTestA64Call10* none_call10 = 0;
                    MachineTestA64Call10* machine_call10 = 0;
                    memcpy(&none_call10, &none_address, sizeof(none_call10));
                    memcpy(&machine_call10, &machine_address, sizeof(machine_call10));
                    all_equal &= none_call10(left, right, left + 1, right + 1, left - 2, right - 2, left + 3, right + 3, left ^ right, right - left) ==
                                 machine_call10(left, right, left + 1, right + 1, left - 2, right - 2, left + 3, right + 3, left ^ right, right - left);
                }
                else if (is_vsum)
                {
                    // The variadic body driven through a non-variadic
                    // seven-register call form: the anonymous parts sit in
                    // X1-X6 under both AAPCS64 and the Darwin convention
                    // precisely because the host compiler does not know
                    // the callee is variadic, so the register path of the
                    // public ELF va_list executes on either host. This is
                    // not Darwin list interoperability; the full overflow
                    // and cross-compiler lists stay with the differential.
                    MachineTestA64Call7* none_call7 = 0;
                    MachineTestA64Call7* machine_call7 = 0;
                    memcpy(&none_call7, &none_address, sizeof(none_call7));
                    memcpy(&machine_call7, &machine_address, sizeof(machine_call7));
                    all_equal &= none_call7(6, left, right, left + 1, right - 2, left ^ right, right - left) ==
                                 machine_call7(6, left, right, left + 1, right - 2, left ^ right, right - left);
                }
                else if (is_vec_pass)
                {
                    MachineTestA64CallV4* none_callv = 0;
                    MachineTestA64CallV4* machine_callv = 0;
                    memcpy(&none_callv, &none_address, sizeof(none_callv));
                    memcpy(&machine_callv, &machine_address, sizeof(machine_callv));
                    MachineTestA64V4 vector_probe = {(float)left, (float)right, (float)(left + 1), (float)(right - 3)};
                    MachineTestA64V4 none_vector = none_callv(vector_probe);
                    MachineTestA64V4 machine_vector = machine_callv(vector_probe);
                    for (u32 lane = 0; lane < 4; lane += 1)
                    {
                        all_equal &= none_vector[lane] == machine_vector[lane];
                    }
                }
                else if (is_vlit_make)
                {
                    MachineTestA64CallVLit* none_callvl = 0;
                    MachineTestA64CallVLit* machine_callvl = 0;
                    memcpy(&none_callvl, &none_address, sizeof(none_callvl));
                    memcpy(&machine_callvl, &machine_address, sizeof(machine_callvl));
                    MachineTestA64VLit none_vector = none_callvl((s32)left, (s32)right);
                    MachineTestA64VLit machine_vector = machine_callvl((s32)left, (s32)right);
                    for (u32 lane = 0; lane < 4; lane += 1)
                    {
                        all_equal &= none_vector[lane] == machine_vector[lane];
                    }
                }
                else if (is_vquad_add)
                {
                    MachineTestA64CallVQuad* none_callvq = 0;
                    MachineTestA64CallVQuad* machine_callvq = 0;
                    memcpy(&none_callvq, &none_address, sizeof(none_callvq));
                    memcpy(&machine_callvq, &machine_address, sizeof(machine_callvq));
                    MachineTestA64VLit left_probe = {(s32)left, (s32)right, (s32)(left + 7), (s32)(right - 9)};
                    MachineTestA64VLit right_probe = {(s32)(right * 3), (s32)(left ^ right), (s32)left, (s32)(right + 1)};
                    MachineTestA64VLit none_vector = none_callvq(left_probe, right_probe);
                    MachineTestA64VLit machine_vector = machine_callvq(left_probe, right_probe);
                    for (u32 lane = 0; lane < 4; lane += 1)
                    {
                        all_equal &= none_vector[lane] == machine_vector[lane];
                    }
                }
                else if (is_vf4_scale)
                {
                    MachineTestA64CallVF4* none_callvf = 0;
                    MachineTestA64CallVF4* machine_callvf = 0;
                    memcpy(&none_callvf, &none_address, sizeof(none_callvf));
                    memcpy(&machine_callvf, &machine_address, sizeof(machine_callvf));
                    MachineTestA64V4 value_probe = {(float)left, (float)right, (float)(left + 2), (float)(right - 5)};
                    MachineTestA64V4 scale_probe = {2.0f, -0.5f, (float)right, 1.25f};
                    MachineTestA64V4 none_vector = none_callvf(value_probe, scale_probe);
                    MachineTestA64V4 machine_vector = machine_callvf(value_probe, scale_probe);
                    for (u32 lane = 0; lane < 4; lane += 1)
                    {
                        all_equal &= none_vector[lane] == machine_vector[lane];
                    }
                }
                else if (is_v8_pass)
                {
                    MachineTestA64CallV8* none_callv8 = 0;
                    MachineTestA64CallV8* machine_callv8 = 0;
                    memcpy(&none_callv8, &none_address, sizeof(none_callv8));
                    memcpy(&machine_callv8, &machine_address, sizeof(machine_callv8));
                    MachineTestA64V8 probe_vector = {(u8)left, (u8)right, (u8)(left + 1), (u8)(right + 2), (u8)(left ^ right), 7, 8, (u8)(right - left)};
                    MachineTestA64V8 none_vector = none_callv8(probe_vector);
                    MachineTestA64V8 machine_vector = machine_callv8(probe_vector);
                    for (u32 lane = 0; lane < 8; lane += 1)
                    {
                        all_equal &= none_vector[lane] == machine_vector[lane];
                    }
                }
                else if (is_v2_make)
                {
                    MachineTestA64CallV2* none_callv2 = 0;
                    MachineTestA64CallV2* machine_callv2 = 0;
                    memcpy(&none_callv2, &none_address, sizeof(none_callv2));
                    memcpy(&machine_callv2, &machine_address, sizeof(machine_callv2));
                    MachineTestA64V2 none_vector = none_callv2((s32)left);
                    MachineTestA64V2 machine_vector = machine_callv2((s32)left);
                    for (u32 lane = 0; lane < 2; lane += 1)
                    {
                        all_equal &= none_vector[lane] == machine_vector[lane];
                    }
                }
                else if (is_big_take)
                {
                    MachineTestA64CallBig3* none_call_big3 = 0;
                    MachineTestA64CallBig3* machine_call_big3 = 0;
                    memcpy(&none_call_big3, &none_address, sizeof(none_call_big3));
                    memcpy(&machine_call_big3, &machine_address, sizeof(machine_call_big3));
                    MachineTestA64Big3 big_probe = {left, right, left ^ right};
                    all_equal &= none_call_big3(big_probe, right - left) == machine_call_big3(big_probe, right - left);
                }
                else if (is_fpair_tail)
                {
                    MachineTestA64CallFPairTail* none_call_fpair = 0;
                    MachineTestA64CallFPairTail* machine_call_fpair = 0;
                    memcpy(&none_call_fpair, &none_address, sizeof(none_call_fpair));
                    memcpy(&machine_call_fpair, &machine_address, sizeof(machine_call_fpair));
                    MachineTestA64FPair fpair_probe = {(double)left, (double)right};
                    all_equal &= none_call_fpair(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, fpair_probe) ==
                                 machine_call_fpair(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, fpair_probe);
                }
                else if (is_pair_spill)
                {
                    MachineTestA64CallPairSpill* none_call_pair = 0;
                    MachineTestA64CallPairSpill* machine_call_pair = 0;
                    memcpy(&none_call_pair, &none_address, sizeof(none_call_pair));
                    memcpy(&machine_call_pair, &machine_address, sizeof(machine_call_pair));
                    MachineTestA64Pair2 pair_probe = {left, right};
                    all_equal &= none_call_pair(1, 2, 3, 4, 5, 6, 7, pair_probe) == machine_call_pair(1, 2, 3, 4, 5, 6, 7, pair_probe);
                }
                else if (wide_result)
                {
                    all_equal &= none_call(left, right) == machine_call(left, right);
                }
                else
                {
                    all_equal &= (s32)none_call(left, right) == (s32)machine_call(left, right);
                }
            }
            BUSTER_TEST_RAW(arguments, all_equal, a64_supported_names[name_index]);
            codegen_release_executable(a64_machine_executable);
        }
        codegen_release_executable(a64_none_executable);
#endif
    }

    return result;
}
#endif
