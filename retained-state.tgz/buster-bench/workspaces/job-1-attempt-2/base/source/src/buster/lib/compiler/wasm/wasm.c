#include <buster/lib/compiler/wasm/wasm_internal.h>

// wasm_emit owns direct WebAssembly output for Memory64 freestanding and
// wasm32 WASI Preview 1. wasm64_emit keeps the original Memory64 API. Both
// consume canonical IR; all temporary vectors and encoded bytes belong to
// the caller supplied arena. wasm64_prepare_wasi_imports reserves command
// imports before definitions, and wasm64_fe_emit_wasi_start writes the adapter.
// Local aggregate snapshots use private shadow-stack slots. Their SSA locals
// carry slot addresses; loads copy immediately, so later stores cannot change
// an earlier value. Function ABIs and block parameters remain scalar-only.

// Linear-memory layout policy: static data starts one 64 KiB region above
// address zero. Its aligned end is the initial pointer and inclusive lower
// bound of a 64 KiB upward-growing shadow stack; stack_limit is exclusive.
// The equal data-base and stack-size values are coincidence, not one constant.
enum
{
    WASM64_DATA_BASE = 0x10000,
    WASM64_STACK_SIZE = 0x10000,
};

#define WASM64_MAX_MEMORY_PAGES (UINT64_C(1) << 48)

typedef enum Wasm64ValType
{
    WASM64_VALTYPE_INVALID = 0,
    WASM64_VALTYPE_I32 = 0x7f,
    WASM64_VALTYPE_I64 = 0x7e,
    WASM64_VALTYPE_F32 = 0x7d,
    WASM64_VALTYPE_F64 = 0x7c,
} Wasm64ValType;

typedef struct Wasm64Buffer Wasm64Buffer;
struct Wasm64Buffer
{
    Arena* arena;
    u8* data;
    u64 length;
    u64 capacity;
};

typedef struct Wasm64Signature Wasm64Signature;
struct Wasm64Signature
{
    Wasm64ValType* params;
    u32 param_count;
    Wasm64ValType result;
    bool has_result;
    u32 type_index;
};

typedef enum Wasm64SyntheticFunction
{
    WASM64_SYNTHETIC_FUNCTION_NONE,
    WASM64_SYNTHETIC_FUNCTION_WASI_PROC_EXIT,
    WASM64_SYNTHETIC_FUNCTION_WASI_ARGS_SIZES_GET,
    WASM64_SYNTHETIC_FUNCTION_WASI_ARGS_GET,
    WASM64_SYNTHETIC_FUNCTION_WASI_ENVIRON_SIZES_GET,
    WASM64_SYNTHETIC_FUNCTION_WASI_ENVIRON_GET,
    WASM64_SYNTHETIC_FUNCTION_WASI_START,
    WASM64_SYNTHETIC_FUNCTION_COUNT,
} Wasm64SyntheticFunction;

typedef struct Wasm64FunctionRecord Wasm64FunctionRecord;
struct Wasm64FunctionRecord
{
    IrFunction* function;
    IrSymbol* symbol;
    String8 import_module;
    String8 import_name;
    String8 export_name;
    Wasm64Signature signature;
    u32 function_index;
    u32 defined_index;
    Wasm64SyntheticFunction synthetic;
    bool imported;
    bool exported;
};

typedef struct Wasm64DataRecord Wasm64DataRecord;
struct Wasm64DataRecord
{
    IrGlobal* global;
    IrSymbol* symbol;
    u8* bytes;
    u64 size;
    u64 offset;
    u32 module_index;
    bool has_bytes;
};

typedef struct Wasm64StringRecord Wasm64StringRecord;
struct Wasm64StringRecord
{
    IrFunction* function;
    IrInstructionId instruction;
    String8 literal;
    u64 offset;
};

typedef struct Wasm64Context Wasm64Context;
struct Wasm64Context
{
    Arena* arena;
    IrProgram* program;
    IrModule* modules;
    u32 module_count;
    Wasm64Options options;
    Wasm64Error error;
    Wasm64Stats stats;
    Wasm64Buffer data_bytes;
    Wasm64Buffer type_payload;
    Wasm64Buffer import_payload;
    Wasm64Buffer function_payload;
    Wasm64Buffer memory_payload;
    Wasm64Buffer global_payload;
    Wasm64Buffer export_payload;
    Wasm64Buffer code_payload;
    Wasm64Buffer data_payload;
    Wasm64Signature* signatures;
    u32 signature_count;
    u32 signature_capacity;
    Wasm64FunctionRecord* functions;
    u32 function_count;
    u32 function_capacity;
    Wasm64DataRecord* data_records;
    u32 data_count;
    u32 data_capacity;
    Wasm64StringRecord* strings;
    u32 string_count;
    u32 string_capacity;
    u32* symbol_function_indices;
    u32* symbol_data_indices;
    u8* symbol_seen;
    u64 data_cursor;
    u64 stack_base;
    u64 stack_limit;
    u32 stack_global_index;
    u32 stack_limit_global_index;
    u32 memory_export_count;
    u32 wasi_main_function_index;
    u32 wasi_start_function_index;
    u32 wasi_proc_exit_function_index;
    u32 wasi_args_sizes_get_function_index;
    u32 wasi_args_get_function_index;
    u32 wasi_environ_sizes_get_function_index;
    u32 wasi_environ_get_function_index;
    IrSymbolId wasi_main_symbol;
    u8 wasi_main_parameter_count;
    bool wasi_main_has_result;
};

typedef struct Wasm64FunctionEmitter Wasm64FunctionEmitter;
struct Wasm64FunctionEmitter
{
    Wasm64Context* context;
    IrFunction* function;
    Wasm64FunctionRecord* record;
    Wasm64Buffer body;
    u32* value_locals;
    u8* value_types;
    u32* value_offsets;
    u32* parameter_locals;
    u32 pc_local;
    u32 fp_local;
    u32 sp_local;
    u32 scratch_local;
    u32 temp_base;
    u32* block_temp_bases;
    u8* local_types;
    u32 local_count;
    u32 extra_local_count;
    u32 frame_size;
};

static String8 wasm64_s8(char8 const* pointer)
{
    String8 result = {0};
    result.pointer = (char8*)pointer;
    while (pointer[result.length])
    {
        result.length += 1;
    }
    return result;
}

static bool wasm64_string_equal(String8 a, String8 b)
{
    return a.length == b.length && (!a.length || memory_compare(a.pointer, b.pointer, a.length));
}

static bool wasm64_string_has_hash(String8 value, u64* hash_index)
{
    for (u64 index = 0; index < value.length; index += 1)
    {
        if (value.pointer[index] == '#')
        {
            if (hash_index)
            {
                *hash_index = index;
            }
            return true;
        }
    }
    return false;
}

static String8 wasm64_string_slice(String8 value, u64 start, u64 end)
{
    if (start > value.length)
    {
        start = value.length;
    }
    if (end > value.length)
    {
        end = value.length;
    }
    if (end < start)
    {
        end = start;
    }
    return (String8){.pointer = value.pointer + start, .length = end - start};
}

static void wasm64_buffer_init(Wasm64Buffer* buffer, Arena* arena)
{
    *buffer = (Wasm64Buffer){.arena = arena};
}

static void wasm64_buffer_reserve(Wasm64Buffer* buffer, u64 additional)
{
    if (additional <= buffer->capacity - buffer->length)
    {
        return;
    }
    u64 required = buffer->length + additional;
    u64 capacity = buffer->capacity ? buffer->capacity : 256;
    while (capacity < required)
    {
        u64 next = capacity * 2;
        if (next < capacity || next > ARENA_MAX_RESERVATION)
        {
            capacity = required;
            break;
        }
        capacity = next;
    }
    u8* data = (u8*)arena_allocate_bytes(buffer->arena, capacity, 1);
    if (buffer->length)
    {
        memcpy(data, buffer->data, (size_t)buffer->length);
    }
    buffer->data = data;
    buffer->capacity = capacity;
}

static void wasm64_buffer_u8(Wasm64Buffer* buffer, u8 value)
{
    wasm64_buffer_reserve(buffer, 1);
    buffer->data[buffer->length] = value;
    buffer->length += 1;
}

static void wasm64_buffer_bytes(Wasm64Buffer* buffer, u8 const* data, u64 length)
{
    if (!length)
    {
        return;
    }
    wasm64_buffer_reserve(buffer, length);
    memcpy(buffer->data + buffer->length, data, (size_t)length);
    buffer->length += length;
}

static void wasm64_buffer_u32_leb(Wasm64Buffer* buffer, u32 value)
{
    do
    {
        u8 byte = (u8)(value & 0x7f);
        value >>= 7;
        if (value)
        {
            byte |= 0x80;
        }
        wasm64_buffer_u8(buffer, byte);
    } while (value);
}

static void wasm64_buffer_u64_leb(Wasm64Buffer* buffer, u64 value)
{
    do
    {
        u8 byte = (u8)(value & 0x7f);
        value >>= 7;
        if (value)
        {
            byte |= 0x80;
        }
        wasm64_buffer_u8(buffer, byte);
    } while (value);
}

static void wasm64_buffer_s32_leb(Wasm64Buffer* buffer, s32 value)
{
    bool more = true;
    while (more)
    {
        u8 byte = (u8)(value & 0x7f);
        value >>= 7;
        bool sign = (byte & 0x40) != 0;
        more = !((value == 0 && !sign) || (value == -1 && sign));
        if (more)
        {
            byte |= 0x80;
        }
        wasm64_buffer_u8(buffer, byte);
    }
}

static void wasm64_buffer_s64_leb(Wasm64Buffer* buffer, s64 value)
{
    bool more = true;
    while (more)
    {
        u8 byte = (u8)(value & 0x7f);
        value >>= 7;
        bool sign = (byte & 0x40) != 0;
        more = !((value == 0 && !sign) || (value == -1 && sign));
        if (more)
        {
            byte |= 0x80;
        }
        wasm64_buffer_u8(buffer, byte);
    }
}

static void wasm64_buffer_string(Wasm64Buffer* buffer, String8 value)
{
    // Wasm names are u32-length byte strings.  Rejecting a >4 GiB name is
    // handled by the caller's bounded source arenas; the cast is safe for all
    // legal compiler strings.
    wasm64_buffer_u32_leb(buffer, (u32)value.length);
    wasm64_buffer_bytes(buffer, (u8*)value.pointer, value.length);
}

static void wasm64_buffer_f32(Wasm64Buffer* buffer, u32 bits)
{
    wasm64_buffer_u8(buffer, (u8)(bits & 0xff));
    wasm64_buffer_u8(buffer, (u8)((bits >> 8) & 0xff));
    wasm64_buffer_u8(buffer, (u8)((bits >> 16) & 0xff));
    wasm64_buffer_u8(buffer, (u8)((bits >> 24) & 0xff));
}

static void wasm64_buffer_f64(Wasm64Buffer* buffer, u64 bits)
{
    for (u32 byte_index = 0; byte_index < 8; byte_index += 1)
    {
        wasm64_buffer_u8(buffer, (u8)(bits >> (byte_index * 8)));
    }
}

static void wasm64_buffer_u64_fixed(Wasm64Buffer* buffer, u64 value, u32 byte_count)
{
    for (u32 byte_index = 0; byte_index < byte_count; byte_index += 1)
    {
        wasm64_buffer_u8(buffer, (u8)(value >> (byte_index * 8)));
    }
}

static bool wasm64_u64_add(u64 left, u64 right, u64* sum)
{
    bool result = left <= UINT64_MAX - right;
    if (result)
    {
        *sum = left + right;
    }
    return result;
}

static bool wasm64_align_cursor(u64* cursor, u64 alignment)
{
    bool result = alignment && !(alignment & (alignment - 1));
    u64 aligned = 0;
    if (result)
    {
        result = wasm64_u64_add(*cursor, alignment - 1, &aligned);
    }
    if (result)
    {
        *cursor = aligned & ~(alignment - 1);
    }
    return result;
}

static void wasm64_fail(Wasm64Context* context, Wasm64ErrorCode code, String8 message, IrFunction* function, IrBlock* block,
                        IrInstruction* instruction, IrSymbolId symbol)
{
    if (context->error.code != WASM64_ERROR_NONE)
    {
        return;
    }
    context->error.code = code;
    context->error.message = message;
    context->error.diagnostic = message;
    context->error.function = function ? function->id : IR_FUNCTION_ID_INVALID;
    context->error.block = block ? block->id : IR_BLOCK_ID_INVALID;
    context->error.instruction = instruction && function ? ir_instruction_self_id(function, instruction) : IR_INSTRUCTION_ID_INVALID;
    context->error.symbol = symbol;
    context->error.opcode = instruction ? instruction->opcode : IR_OPCODE_COUNT;
}

static bool wasm64_failed(Wasm64Context* context)
{
    return context->error.code != WASM64_ERROR_NONE;
}

static void wasm64_vec_reserve(Arena* arena, void** pointer, u32* capacity, u32 count, u32 element_size)
{
    if (count <= *capacity)
    {
        return;
    }
    u32 new_capacity = *capacity ? *capacity : 16;
    while (new_capacity < count)
    {
        u32 next = new_capacity * 2;
        if (next < new_capacity || next > UINT32_MAX / element_size)
        {
            new_capacity = count;
            break;
        }
        new_capacity = next;
    }
    void* next = arena_allocate_bytes(arena, (u64)new_capacity * element_size, BUSTER_ALIGN_OF(u64));
    if (*pointer && *capacity)
    {
        memcpy(next, *pointer, (size_t)((u64)*capacity * element_size));
    }
    *pointer = next;
    *capacity = new_capacity;
}

static IrType* wasm64_type(Wasm64Context* context, IrTypeId id)
{
    return ir_type_from_id(&context->program->types, id);
}

static IrSymbol* wasm64_symbol(Wasm64Context* context, IrSymbolId id)
{
    return ir_symbol_from_id(&context->program->symbols, id);
}

static bool wasm64_is_memory64(Wasm64Context* context)
{
    return context->options.pointer_size == 8;
}

static u32 wasm64_pointer_size(Wasm64Context* context)
{
    return wasm64_is_memory64(context) ? 8 : 4;
}

static Wasm64ValType wasm64_pointer_valtype(Wasm64Context* context)
{
    return wasm64_is_memory64(context) ? WASM64_VALTYPE_I64 : WASM64_VALTYPE_I32;
}

static bool wasm64_type_is_scalar(IrType* type)
{
    return type && (type->kind == IR_TYPE_BOOLEAN || type->kind == IR_TYPE_INTEGER || type->kind == IR_TYPE_FLOAT || type->kind == IR_TYPE_POINTER ||
                    type->kind == IR_TYPE_ENUM);
}

BUSTER_GLOBAL_LOCAL bool wasm64_type_is_local_aggregate(IrType* type)
{
    return type && !type->is_atomic && type->layout.resolved && type->layout.size &&
           (type->kind == IR_TYPE_ARRAY || type->kind == IR_TYPE_STRUCT || type->kind == IR_TYPE_UNION);
}

static bool wasm64_type_is_pointer(IrType* type)
{
    return type && type->kind == IR_TYPE_POINTER;
}

static u32 wasm64_integer_bits(IrType* type)
{
    u32 result;
    if (!type)
    {
        result = 0;
    }
    else if (type->kind == IR_TYPE_BOOLEAN)
    {
        result = 1;
    }
    else if (type->kind == IR_TYPE_ENUM)
    {
        result = type->layout.size <= 4 ? 32 : 64;
    }
    else
    {
        result = type->bit_width;
    }

    return result;
}

static bool wasm64_valtype_for_type(Wasm64Context* context, IrType* type, bool place, Wasm64ValType* result)
{
    if (place || wasm64_type_is_pointer(type))
    {
        if (result)
        {
            *result = wasm64_pointer_valtype(context);
        }
        return true;
    }
    if (!type)
    {
        return false;
    }
    switch (type->kind)
    {
    case IR_TYPE_BOOLEAN:
    case IR_TYPE_INTEGER:
        if (!type->bit_width || type->bit_width <= 32)
        {
            if (result)
            {
                *result = WASM64_VALTYPE_I32;
            }
            return true;
        }
        if (type->bit_width <= 64)
        {
            if (result)
            {
                *result = WASM64_VALTYPE_I64;
            }
            return true;
        }
        return false;
    case IR_TYPE_ENUM:
        if (type->layout.size <= 4)
        {
            if (result)
            {
                *result = WASM64_VALTYPE_I32;
            }
            return true;
        }
        if (type->layout.size <= 8)
        {
            if (result)
            {
                *result = WASM64_VALTYPE_I64;
            }
            return true;
        }
        return false;
    case IR_TYPE_FLOAT:
        if (type->bit_width == 32)
        {
            if (result)
            {
                *result = WASM64_VALTYPE_F32;
            }
            return true;
        }
        if (type->bit_width == 64)
        {
            if (result)
            {
                *result = WASM64_VALTYPE_F64;
            }
            return true;
        }
        return false;
    default:
        return false;
    }
}

static bool wasm64_type_is_integer(IrType* type)
{
    return type && (type->kind == IR_TYPE_INTEGER || type->kind == IR_TYPE_BOOLEAN || type->kind == IR_TYPE_ENUM);
}

static bool wasm64_type_is_float(IrType* type)
{
    return type && type->kind == IR_TYPE_FLOAT;
}

static u32 wasm64_type_size(IrType* type)
{
    return type && type->layout.resolved && type->layout.size <= UINT32_MAX ? (u32)type->layout.size : 0;
}

static u32 wasm64_log2_alignment(u32 alignment)
{
    u32 result = 0;
    while (alignment > 1)
    {
        alignment >>= 1;
        result += 1;
    }
    return result;
}

static bool wasm64_signature_equal(Wasm64Signature* a, Wasm64Signature* b)
{
    bool result = a->param_count == b->param_count && a->has_result == b->has_result && (!a->has_result || a->result == b->result) &&
                  (!a->param_count || (a->params && b->params));
    for (u32 index = 0; result && index < a->param_count; index += 1)
    {
        result = a->params[index] == b->params[index];
    }
    return result;
}

static u32 wasm64_signature_add(Wasm64Context* context, Wasm64Signature signature)
{
    for (u32 index = 0; index < context->signature_count; index += 1)
    {
        if (wasm64_signature_equal(context->signatures + index, &signature))
        {
            return context->signatures[index].type_index;
        }
    }
    wasm64_vec_reserve(context->arena, (void**)&context->signatures, &context->signature_capacity, context->signature_count + 1,
                       sizeof(*context->signatures));
    signature.type_index = context->signature_count;
    context->signatures[context->signature_count] = signature;
    context->signature_count += 1;
    return signature.type_index;
}

static bool wasm64_function_signature(Wasm64Context* context, IrTypeId function_type_id, Wasm64Signature* result, IrFunction* function,
                                      IrSymbolId symbol)
{
    IrType* function_type = wasm64_type(context, function_type_id);
    if (!function_type || function_type->kind != IR_TYPE_FUNCTION)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("Wasm function signature is not canonical"), function, 0, 0, symbol);
        return false;
    }
    if (function_type->is_variadic)
    {
        wasm64_fail(context, WASM64_ERROR_VARIADIC, wasm64_s8("variadic functions are not supported by WebAssembly"), function, 0, 0, symbol);
        return false;
    }
    Wasm64Signature signature = {0};
    signature.param_count = function_type->parameter_count;
    if (signature.param_count)
    {
        signature.params = arena_allocate(context->arena, Wasm64ValType, signature.param_count);
    }
    for (u32 index = 0; index < signature.param_count; index += 1)
    {
        IrType* parameter_type = wasm64_type(context, function_type->parameter_types[index]);
        if (!wasm64_valtype_for_type(context, parameter_type, false, signature.params + index))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("aggregate or unsupported parameter ABI in WebAssembly function"),
                        function, 0, 0, symbol);
            return false;
        }
    }
    IrType* return_type = wasm64_type(context, function_type->return_type);
    if (!return_type)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("missing WebAssembly return type"), function, 0, 0, symbol);
        return false;
    }
    if (return_type->kind != IR_TYPE_VOID)
    {
        if (!wasm64_valtype_for_type(context, return_type, false, &signature.result))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("aggregate or unsupported result ABI in WebAssembly function"),
                        function, 0, 0, symbol);
            return false;
        }
        signature.has_result = true;
    }
    *result = signature;
    return true;
}

static IrTypeId wasm64_function_type_from_symbol(Wasm64Context* context, IrSymbol* symbol)
{
    IrType* symbol_type = symbol ? wasm64_type(context, symbol->type) : 0;
    if (symbol_type && symbol_type->kind == IR_TYPE_POINTER)
    {
        symbol_type = wasm64_type(context, symbol_type->element_type);
    }
    return symbol_type && symbol_type->kind == IR_TYPE_FUNCTION ? symbol_type->id : IR_TYPE_ID_INVALID;
}

static bool wasm64_symbol_is_function_definition(Wasm64Context* context, IrSymbolId symbol_id, IrFunction** function_out, u32* module_out)
{
    if (context->program && symbol_id.value < context->program->symbols.count)
    {
        for (u32 module_index = 0; module_index < context->module_count; module_index += 1)
        {
            IrModule* module = context->modules + module_index;
            for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
            {
                IrFunction* function = module->functions + function_index;
                if (function->symbol.value == symbol_id.value && function->state == IR_FUNCTION_LOWERED)
                {
                    if (function_out)
                    {
                        *function_out = function;
                    }
                    if (module_out)
                    {
                        *module_out = module_index;
                    }
                    return true;
                }
            }
        }
    }

    return false;
}

static String8 wasm64_import_module(String8 link_name)
{
    u64 hash = 0;
    String8 result;
    if (wasm64_string_has_hash(link_name, &hash))
    {
        result = wasm64_string_slice(link_name, 0, hash);
    }
    else
    {
        result = wasm64_s8("env");
    }

    return result;
}

static String8 wasm64_import_name(String8 link_name, String8 fallback)
{
    u64 hash = 0;
    String8 result;
    if (wasm64_string_has_hash(link_name, &hash))
    {
        result = wasm64_string_slice(link_name, hash + 1, link_name.length);
    }
    else
    {
        result = link_name.length ? link_name : fallback;
    }

    return result;
}

static Wasm64FunctionRecord* wasm64_function_record_for_symbol(Wasm64Context* context, IrSymbolId symbol)
{
    Wasm64FunctionRecord* result;
    if (symbol.value == IR_ID_UNDERLYING_INVALID || symbol.value >= context->program->symbols.count || !context->symbol_function_indices)
    {
        result = 0;
    }
    else
    {
        u32 index = context->symbol_function_indices[symbol.value];
        result = index == UINT32_MAX || index >= context->function_count ? 0 : context->functions + index;
    }

    return result;
}

static Wasm64DataRecord* wasm64_data_record_for_symbol(Wasm64Context* context, IrSymbolId symbol)
{
    Wasm64DataRecord* result;
    if (symbol.value == IR_ID_UNDERLYING_INVALID || symbol.value >= context->program->symbols.count || !context->symbol_data_indices)
    {
        result = 0;
    }
    else
    {
        u32 index = context->symbol_data_indices[symbol.value];
        result = index == UINT32_MAX || index >= context->data_count ? 0 : context->data_records + index;
    }

    return result;
}

static bool wasm64_add_function_record(Wasm64Context* context, IrFunction* function, IrSymbol* symbol, bool imported)
{
    Wasm64Signature signature = {0};
    IrTypeId type_id = function ? function->canonical_type : wasm64_function_type_from_symbol(context, symbol);
    if (type_id.value == IR_ID_UNDERLYING_INVALID || !wasm64_function_signature(context, type_id, &signature, function, symbol ? symbol->id : IR_SYMBOL_ID_INVALID))
    {
        return false;
    }
    signature.type_index = wasm64_signature_add(context, signature);
    wasm64_vec_reserve(context->arena, (void**)&context->functions, &context->function_capacity, context->function_count + 1,
                       sizeof(*context->functions));
    Wasm64FunctionRecord* record = context->functions + context->function_count;
    *record = (Wasm64FunctionRecord){.function = function, .symbol = symbol, .signature = signature, .imported = imported, .defined_index = UINT32_MAX};
    record->function_index = context->function_count;
    record->exported = !imported && context->options.export_functions && symbol && symbol->linkage != IR_LINKAGE_INTERNAL;
    if (symbol && symbol->id.value < context->program->symbols.count)
    {
        if (context->symbol_function_indices[symbol->id.value] != UINT32_MAX)
        {
            Wasm64FunctionRecord* previous = context->functions + context->symbol_function_indices[symbol->id.value];
            if (previous->function != function || previous->imported != imported || !wasm64_signature_equal(&previous->signature, &signature))
            {
                wasm64_fail(context, WASM64_ERROR_DUPLICATE_SYMBOL, wasm64_s8("duplicate or incompatible Wasm function symbol"), function, 0, 0, symbol->id);
                return false;
            }
            return true;
        }
        context->symbol_function_indices[symbol->id.value] = context->function_count;
    }
    context->function_count += 1;
    return true;
}

static String8 wasm64_symbol_external_name(IrSymbol* symbol)
{
    String8 result = {0};
    if (symbol)
    {
        String8 link_name = symbol->link_name.length ? symbol->link_name : symbol->name;
        u64 hash = 0;
        result = wasm64_string_has_hash(link_name, &hash) ? wasm64_string_slice(link_name, hash + 1, link_name.length) : link_name;
    }
    return result;
}

static IrFunction* wasm64_find_defined_function(Wasm64Context* context, String8 name, IrSymbol** symbol_out)
{
    IrFunction* result = 0;
    IrSymbol* result_symbol = 0;
    for (u32 module_index = 0; module_index < context->module_count && !wasm64_failed(context); module_index += 1)
    {
        IrModule* module = context->modules + module_index;
        for (u32 function_index = 0; function_index < module->function_count && !wasm64_failed(context); function_index += 1)
        {
            IrFunction* function = module->functions + function_index;
            if (function->state != IR_FUNCTION_LOWERED)
            {
                continue;
            }
            IrSymbol* symbol = wasm64_symbol(context, function->symbol);
            if (!symbol || !wasm64_string_equal(wasm64_symbol_external_name(symbol), name))
            {
                continue;
            }
            if (result && result != function)
            {
                wasm64_fail(context, WASM64_ERROR_DUPLICATE_SYMBOL, wasm64_s8("duplicate WebAssembly entry point"), function, 0, 0, symbol->id);
                result = 0;
                result_symbol = 0;
            }
            else
            {
                result = function;
                result_symbol = symbol;
            }
        }
    }
    if (symbol_out)
    {
        *symbol_out = result_symbol;
    }
    return result;
}

static bool wasm64_add_synthetic_function(Wasm64Context* context, Wasm64SyntheticFunction synthetic, Wasm64ValType const* params,
                                          u32 param_count, bool has_result, Wasm64ValType result_type, bool imported, String8 import_name,
                                          String8 export_name, u32* function_index_out)
{
    Wasm64Signature signature = {
        .param_count = param_count,
        .has_result = has_result,
        .result = result_type,
    };
    if (param_count)
    {
        signature.params = arena_allocate(context->arena, Wasm64ValType, param_count);
        memcpy(signature.params, params, sizeof(*params) * param_count);
    }
    signature.type_index = wasm64_signature_add(context, signature);
    bool reused = false;
    bool valid = true;
    if (imported)
    {
        String8 module_name = wasm64_s8("wasi_snapshot_preview1");
        for (u32 index = 0; index < context->function_count && !reused && valid; index += 1)
        {
            Wasm64FunctionRecord* existing = context->functions + index;
            if (!existing->imported)
            {
                continue;
            }
            IrSymbol* existing_symbol = existing->symbol;
            String8 link_name = existing_symbol && existing_symbol->link_name.length
                                    ? existing_symbol->link_name
                                    : existing_symbol ? existing_symbol->name : (String8){0};
            String8 existing_module = existing->import_module.length ? existing->import_module : wasm64_import_module(link_name);
            String8 existing_name = existing->import_name.length
                                        ? existing->import_name
                                        : wasm64_import_name(link_name, existing_symbol ? existing_symbol->name : (String8){0});
            if (!wasm64_string_equal(existing_module, module_name) || !wasm64_string_equal(existing_name, import_name))
            {
                continue;
            }
            if (!wasm64_signature_equal(&existing->signature, &signature))
            {
                wasm64_fail(context, WASM64_ERROR_DUPLICATE_SYMBOL,
                            wasm64_s8("WASI import declaration has an incompatible function signature"), 0, 0, 0,
                            existing_symbol ? existing_symbol->id : IR_SYMBOL_ID_INVALID);
                valid = false;
            }
            else
            {
                if (function_index_out)
                {
                    *function_index_out = existing->function_index;
                }
                reused = true;
            }
        }
    }
    if (valid && !reused)
    {
        wasm64_vec_reserve(context->arena, (void**)&context->functions, &context->function_capacity, context->function_count + 1,
                           sizeof(*context->functions));
        Wasm64FunctionRecord* record = context->functions + context->function_count;
        *record = (Wasm64FunctionRecord){
            .import_module = imported ? wasm64_s8("wasi_snapshot_preview1") : (String8){0},
            .import_name = import_name,
            .export_name = export_name,
            .signature = signature,
            .function_index = context->function_count,
            .defined_index = UINT32_MAX,
            .synthetic = synthetic,
            .imported = imported,
            .exported = export_name.length != 0,
        };
        if (function_index_out)
        {
            *function_index_out = record->function_index;
        }
        context->function_count += 1;
    }
    return valid;
}

static bool wasm64_validate_wasi_main(Wasm64Context* context, IrFunction* function, IrSymbol* symbol)
{
    IrType* function_type = function ? wasm64_type(context, function->canonical_type) : 0;
    IrType* return_type = function_type && function_type->kind == IR_TYPE_FUNCTION ? wasm64_type(context, function_type->return_type) : 0;
    bool valid = function_type && function_type->kind == IR_TYPE_FUNCTION;
    if (!valid)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("WASI main has no canonical function type"), function, 0, 0,
                    symbol ? symbol->id : IR_SYMBOL_ID_INVALID);
    }
    else if (!return_type || (return_type->kind != IR_TYPE_VOID &&
                              !(wasm64_type_is_integer(return_type) && wasm64_integer_bits(return_type) <= 32)))
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("WASI main must return void or a 32-bit integer"), function, 0, 0,
                    symbol ? symbol->id : IR_SYMBOL_ID_INVALID);
        valid = false;
    }
    else if (function_type->parameter_count != 0 && function_type->parameter_count != 2 && function_type->parameter_count != 3)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE,
                    wasm64_s8("WASI main must have signature main(void), main(argc, argv), or main(argc, argv, envp)"), function, 0, 0,
                    symbol ? symbol->id : IR_SYMBOL_ID_INVALID);
        valid = false;
    }
    else if (function_type->parameter_count)
    {
        IrType* argc_type = wasm64_type(context, function_type->parameter_types[0]);
        IrType* argv_type = wasm64_type(context, function_type->parameter_types[1]);
        IrType* envp_type = function_type->parameter_count == 3 ? wasm64_type(context, function_type->parameter_types[2]) : 0;
        if (!argc_type || !wasm64_type_is_integer(argc_type) || wasm64_integer_bits(argc_type) > 32 || !argv_type ||
            argv_type->kind != IR_TYPE_POINTER || (envp_type && envp_type->kind != IR_TYPE_POINTER))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE,
                        wasm64_s8("WASI main arguments must be a 32-bit argc followed by pointer-valued argv and optional envp"), function, 0, 0,
                        symbol ? symbol->id : IR_SYMBOL_ID_INVALID);
            valid = false;
        }
    }
    if (valid)
    {
        context->wasi_main_symbol = symbol->id;
        context->wasi_main_parameter_count = (u8)function_type->parameter_count;
        context->wasi_main_has_result = return_type->kind != IR_TYPE_VOID;
    }
    return valid;
}

static bool wasm64_prepare_wasi_imports(Wasm64Context* context)
{
    bool valid = true;
    if (context->options.environment == WASM_ENVIRONMENT_WASI_PREVIEW1 && context->options.synthesize_start)
    {
        IrSymbol* explicit_start_symbol = 0;
        IrFunction* explicit_start = wasm64_find_defined_function(context, wasm64_s8("_start"), &explicit_start_symbol);
        valid = !wasm64_failed(context);
        if (valid && explicit_start)
        {
            IrType* type = wasm64_type(context, explicit_start->canonical_type);
            IrType* return_type = type && type->kind == IR_TYPE_FUNCTION ? wasm64_type(context, type->return_type) : 0;
            valid = type && type->kind == IR_TYPE_FUNCTION && !type->parameter_count && return_type && return_type->kind == IR_TYPE_VOID;
            if (!valid)
            {
                wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("WASI _start must have signature void _start(void)"), explicit_start, 0, 0,
                            explicit_start_symbol ? explicit_start_symbol->id : IR_SYMBOL_ID_INVALID);
            }
        }
        else if (valid)
        {
            IrSymbol* main_symbol = 0;
            IrFunction* main_function = wasm64_find_defined_function(context, wasm64_s8("main"), &main_symbol);
            valid = main_function && main_symbol && !wasm64_failed(context);
            if (!valid && !wasm64_failed(context))
            {
                wasm64_fail(context, WASM64_ERROR_UNRESOLVED_SYMBOL,
                            wasm64_s8("WASI command output requires main or an explicit void _start(void)"), 0, 0, 0, IR_SYMBOL_ID_INVALID);
            }
            if (valid)
            {
                valid = wasm64_validate_wasi_main(context, main_function, main_symbol);
            }
            if (valid)
            {
                Wasm64ValType pointer = wasm64_pointer_valtype(context);
                Wasm64ValType proc_exit_params[] = {WASM64_VALTYPE_I32};
                valid = wasm64_add_synthetic_function(context, WASM64_SYNTHETIC_FUNCTION_WASI_PROC_EXIT, proc_exit_params, 1, false,
                                                      WASM64_VALTYPE_INVALID, true, wasm64_s8("proc_exit"), (String8){0},
                                                      &context->wasi_proc_exit_function_index);
                if (valid && context->wasi_main_parameter_count)
                {
                    Wasm64ValType pair_params[] = {pointer, pointer};
                    valid = wasm64_add_synthetic_function(context, WASM64_SYNTHETIC_FUNCTION_WASI_ARGS_SIZES_GET, pair_params, 2, true,
                                                          WASM64_VALTYPE_I32, true, wasm64_s8("args_sizes_get"), (String8){0},
                                                          &context->wasi_args_sizes_get_function_index) &&
                            wasm64_add_synthetic_function(context, WASM64_SYNTHETIC_FUNCTION_WASI_ARGS_GET, pair_params, 2, true,
                                                          WASM64_VALTYPE_I32, true, wasm64_s8("args_get"), (String8){0},
                                                          &context->wasi_args_get_function_index);
                }
                if (valid && context->wasi_main_parameter_count == 3)
                {
                    Wasm64ValType pair_params[] = {pointer, pointer};
                    valid = wasm64_add_synthetic_function(context, WASM64_SYNTHETIC_FUNCTION_WASI_ENVIRON_SIZES_GET, pair_params, 2, true,
                                                          WASM64_VALTYPE_I32, true, wasm64_s8("environ_sizes_get"), (String8){0},
                                                          &context->wasi_environ_sizes_get_function_index) &&
                            wasm64_add_synthetic_function(context, WASM64_SYNTHETIC_FUNCTION_WASI_ENVIRON_GET, pair_params, 2, true,
                                                          WASM64_VALTYPE_I32, true, wasm64_s8("environ_get"), (String8){0},
                                                          &context->wasi_environ_get_function_index);
                }
            }
        }
    }
    return valid && !wasm64_failed(context);
}

static bool wasm64_symbol_is_called(Wasm64Context* context, IrSymbolId symbol_id)
{
    for (u32 module_index = 0; module_index < context->module_count; module_index += 1)
    {
        IrModule* module = context->modules + module_index;
        for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
        {
            IrFunction* function = module->functions + function_index;
            for (u32 instruction_index = 0; instruction_index < function->instruction_count; instruction_index += 1)
            {
                IrInstruction* instruction = function->instructions + instruction_index;
                if (instruction->opcode == IR_OPCODE_CALL && instruction->symbol.value == symbol_id.value)
                {
                    return true;
                }
            }
        }
    }
    return false;
}

static bool wasm64_collect_functions(Wasm64Context* context)
{
    u32 symbol_count = context->program->symbols.count;
    context->symbol_function_indices = arena_allocate(context->arena, u32, symbol_count ? symbol_count : 1);
    context->symbol_seen = arena_allocate(context->arena, u8, symbol_count ? symbol_count : 1);
    for (u32 symbol_index = 0; symbol_index < symbol_count; symbol_index += 1)
    {
        context->symbol_function_indices[symbol_index] = UINT32_MAX;
        context->symbol_seen[symbol_index] = 0;
    }

    // Imports occupy the first function indices. Walk symbol ids, which are
    // stable across module emission, and retain only symbols used by the IR or
    // explicitly declared as imports/externals.
    for (u32 symbol_index = 0; symbol_index < symbol_count; symbol_index += 1)
    {
        IrSymbol* symbol = context->program->symbols.symbols + symbol_index;
        if (symbol->kind != IR_SYMBOL_FUNCTION || wasm64_symbol_is_function_definition(context, symbol->id, 0, 0))
        {
            continue;
        }
        bool needed = symbol->linkage == IR_LINKAGE_IMPORT || symbol->linkage == IR_LINKAGE_EXTERNAL || wasm64_symbol_is_called(context, symbol->id);
        if (!needed)
        {
            continue;
        }
        if (!wasm64_add_function_record(context, 0, symbol, true))
        {
            return false;
        }
    }

    // The command adapter's Preview 1 imports must also precede every defined
    // function because WebAssembly function indices are import-first.
    if (!wasm64_prepare_wasi_imports(context))
    {
        return false;
    }

    for (u32 module_index = 0; module_index < context->module_count; module_index += 1)
    {
        IrModule* module = context->modules + module_index;
        for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
        {
            IrFunction* function = module->functions + function_index;
            if (function->state == IR_FUNCTION_DECLARATION)
            {
                continue;
            }
            if (function->state != IR_FUNCTION_LOWERED)
            {
                if (function->state == IR_FUNCTION_REJECTED)
                {
                    wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("IR function was rejected before WebAssembly emission"), function, 0,
                                0, function->symbol);
                    return false;
                }
                continue;
            }
            IrSymbol* symbol = wasm64_symbol(context, function->symbol);
            if (!symbol || symbol->kind != IR_SYMBOL_FUNCTION)
            {
                wasm64_fail(context, WASM64_ERROR_INVALID_ARGUMENT, wasm64_s8("lowered WebAssembly function has no function symbol"), function, 0,
                            0, function->symbol);
                return false;
            }
            if (!wasm64_add_function_record(context, function, symbol, false))
            {
                return false;
            }
            Wasm64FunctionRecord* record = wasm64_function_record_for_symbol(context, symbol->id);
            String8 external_name = wasm64_symbol_external_name(symbol);
            if (record && wasm64_string_equal(external_name, wasm64_s8("_start")) &&
                context->options.environment == WASM_ENVIRONMENT_WASI_PREVIEW1)
            {
                // A WASI command entry point is part of the ABI even when the
                // source-level declaration was given internal linkage.
                record->exported = true;
                record->export_name = wasm64_s8("_start");
                context->wasi_start_function_index = record->function_index;
            }
        }
    }

    if (context->wasi_main_symbol.value != IR_ID_UNDERLYING_INVALID)
    {
        Wasm64FunctionRecord* main_record = wasm64_function_record_for_symbol(context, context->wasi_main_symbol);
        if (!main_record || main_record->imported)
        {
            wasm64_fail(context, WASM64_ERROR_UNRESOLVED_SYMBOL, wasm64_s8("WASI main was not emitted as a defined function"), 0, 0, 0,
                        context->wasi_main_symbol);
            return false;
        }
        context->wasi_main_function_index = main_record->function_index;

        if (!wasm64_add_synthetic_function(context, WASM64_SYNTHETIC_FUNCTION_WASI_START, 0, 0, false, WASM64_VALTYPE_INVALID, false,
                                           (String8){0}, wasm64_s8("_start"), &context->wasi_start_function_index))
        {
            return false;
        }
    }

    context->stats.function_count = context->function_count;
    context->stats.import_count = 0;
    context->stats.defined_function_count = 0;
    for (u32 index = 0; index < context->function_count; index += 1)
    {
        Wasm64FunctionRecord* record = context->functions + index;
        if (record->imported)
        {
            context->stats.import_count += 1;
        }
        else
        {
            record->defined_index = context->stats.defined_function_count;
            context->stats.defined_function_count += 1;
        }
    }
    return !wasm64_failed(context);
}

static bool wasm64_global_initializer_bytes(Wasm64Context* context, IrGlobal* global, IrType* type, u8** bytes_out, u64* size_out)
{
    u64 size = type && type->layout.resolved ? type->layout.size : 0;
    if (size > ARENA_MAX_RESERVATION)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("WebAssembly global is too large"), 0, 0, 0, global->symbol);
        return false;
    }
    u8* bytes = size ? arena_allocate(context->arena, u8, size) : 0;
    if (size)
    {
        memset(bytes, 0, (size_t)size);
    }
    switch (global->initializer_kind)
    {
    case IR_GLOBAL_INITIALIZER_ZERO:
        break;
    case IR_GLOBAL_INITIALIZER_BYTES:
        if (global->bytes.length != size || (size && !global->bytes.pointer))
        {
            wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("invalid WebAssembly global byte initializer"), 0, 0, 0, global->symbol);
            return false;
        }
        if (size)
        {
            memcpy(bytes, global->bytes.pointer, (size_t)size);
        }
        break;
    case IR_GLOBAL_INITIALIZER_INTEGER:
    case IR_GLOBAL_INITIALIZER_FLOAT:
        if (size > sizeof(u64))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("wide global initializer ABI is unsupported by WebAssembly"), 0, 0, 0,
                        global->symbol);
            return false;
        }
        {
            u64 bits = global->initializer_bits;
            if (global->initializer_is_negative)
            {
                bits = 0 - bits;
            }
            wasm64_buffer_u64_fixed(&(Wasm64Buffer){.arena = context->arena, .data = bytes, .capacity = size, .length = 0}, bits, (u32)size);
        }
        break;
    case IR_GLOBAL_INITIALIZER_SYMBOL_ADDRESS:
        if (size < wasm64_pointer_size(context))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("pointer global is smaller than the target WebAssembly address"), 0, 0, 0,
                        global->symbol);
            return false;
        }
        break;
    case IR_GLOBAL_INITIALIZER_NONE:
    case IR_GLOBAL_INITIALIZER_COUNT:
        wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("missing WebAssembly global initializer"), 0, 0, 0, global->symbol);
        return false;
    }
    *bytes_out = bytes;
    *size_out = size;
    return true;
}

static bool wasm64_data_add_global(Wasm64Context* context, IrGlobal* global, u32 module_index)
{
    IrSymbol* symbol = wasm64_symbol(context, global->symbol);
    IrType* type = wasm64_type(context, global->type);
    if (!symbol || symbol->kind != IR_SYMBOL_DATA || !type || !type->layout.resolved || symbol->id.value >= context->program->symbols.count)
    {
        wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("invalid WebAssembly global symbol or type"), 0, 0, 0, global->symbol);
        return false;
    }
    if (symbol->is_thread_local || global->is_thread_local)
    {
        wasm64_fail(context, WASM64_ERROR_TLS, wasm64_s8("TLS globals are not supported by WebAssembly"), 0, 0, 0, global->symbol);
        return false;
    }
    if (context->symbol_data_indices[global->symbol.value] != UINT32_MAX)
    {
        wasm64_fail(context, WASM64_ERROR_DUPLICATE_SYMBOL, wasm64_s8("duplicate WebAssembly data symbol"), 0, 0, 0, global->symbol);
        return false;
    }
    u8* bytes = 0;
    u64 size = 0;
    if (!wasm64_global_initializer_bytes(context, global, type, &bytes, &size))
    {
        return false;
    }
    u64 alignment = global->alignment ? global->alignment : type->layout.alignment;
    if (!wasm64_align_cursor(&context->data_cursor, alignment))
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("Wasm64 static-data alignment overflow"), 0, 0, 0, global->symbol);
        return false;
    }
    u64 data_end = 0;
    if (!wasm64_u64_add(context->data_cursor, size, &data_end))
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("Wasm64 static-data size overflow"), 0, 0, 0, global->symbol);
        return false;
    }
    Wasm64DataRecord record = {.global = global, .symbol = symbol, .bytes = bytes, .size = size, .offset = context->data_cursor, .module_index = module_index,
                               .has_bytes = false};
    if (size && (global->initializer_kind != IR_GLOBAL_INITIALIZER_ZERO || global->relocation_count))
    {
        record.has_bytes = true;
    }
    context->data_cursor = data_end;
    wasm64_vec_reserve(context->arena, (void**)&context->data_records, &context->data_capacity, context->data_count + 1, sizeof(*context->data_records));
    context->data_records[context->data_count] = record;
    context->symbol_data_indices[global->symbol.value] = context->data_count;
    context->data_count += 1;
    return true;
}

static bool wasm64_collect_data(Wasm64Context* context)
{
    u32 symbol_count = context->program->symbols.count;
    context->symbol_data_indices = arena_allocate(context->arena, u32, symbol_count ? symbol_count : 1);
    for (u32 symbol_index = 0; symbol_index < symbol_count; symbol_index += 1)
    {
        context->symbol_data_indices[symbol_index] = UINT32_MAX;
    }
    context->data_cursor = WASM64_DATA_BASE;
    for (u32 module_index = 0; module_index < context->module_count; module_index += 1)
    {
        IrModule* module = context->modules + module_index;
        for (u32 global_index = 0; global_index < module->global_count; global_index += 1)
        {
            if (!wasm64_data_add_global(context, module->globals + global_index, module_index))
            {
                return false;
            }
        }
    }
    // String literals are static read-only bytes.  They receive deterministic
    // source-order offsets and a trailing NUL, which also makes C string
    // constants safe when handed to an imported function.
    for (u32 module_index = 0; module_index < context->module_count; module_index += 1)
    {
        IrModule* module = context->modules + module_index;
        for (u32 function_index = 0; function_index < module->function_count; function_index += 1)
        {
            IrFunction* function = module->functions + function_index;
            for (u32 instruction_index = 0; instruction_index < function->instruction_count; instruction_index += 1)
            {
                IrInstruction* instruction = function->instructions + instruction_index;
                if (instruction->opcode != IR_OPCODE_CONSTANT_STRING)
                {
                    continue;
                }
                IrType* type = wasm64_type(context, instruction->canonical_type);
                if (!type || type->kind != IR_TYPE_POINTER)
                {
                    wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("string aggregate ABI is unsupported by WebAssembly"), function,
                                0, instruction, IR_SYMBOL_ID_INVALID);
                    return false;
                }
                String8 literal = ir_instruction_extra(function, ir_instruction_self_id(function, instruction)).literal;
                u64 string_size = 0;
                u64 string_end = 0;
                if (!wasm64_u64_add(literal.length, 1, &string_size) || !wasm64_u64_add(context->data_cursor, string_size, &string_end))
                {
                    wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("Wasm64 string-data size overflow"), function, 0, instruction,
                                IR_SYMBOL_ID_INVALID);
                    return false;
                }
                Wasm64StringRecord record = {.function = function, .instruction = ir_instruction_self_id(function, instruction), .literal = literal, .offset = context->data_cursor};
                context->data_cursor = string_end;
                wasm64_vec_reserve(context->arena, (void**)&context->strings, &context->string_capacity, context->string_count + 1, sizeof(*context->strings));
                context->strings[context->string_count] = record;
                context->string_count += 1;
            }
        }
    }
    if (!wasm64_align_cursor(&context->data_cursor, 16) || !wasm64_u64_add(context->data_cursor, WASM64_STACK_SIZE, &context->stack_limit))
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("WebAssembly memory layout overflow"), 0, 0, 0, IR_SYMBOL_ID_INVALID);
        return false;
    }
    if (!wasm64_is_memory64(context) && context->stack_limit > UINT32_MAX)
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("Wasm32 static data and stack exceed addressable memory"), 0, 0, 0,
                    IR_SYMBOL_ID_INVALID);
        return false;
    }
    context->stack_base = context->data_cursor;
    context->stats.static_data_bytes = context->data_cursor;
    context->stats.stack_lower_bound = context->stack_base;
    context->stats.stack_upper_bound = context->stack_limit;
    return true;
}

static bool wasm64_apply_data_relocation(Wasm64Context* context, Wasm64DataRecord* record, IrSymbolId symbol, u64 offset, s64 addend,
                                         bool is_label_address)
{
    u32 pointer_size = wasm64_pointer_size(context);
    if (is_label_address)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("label-address relocations are unsupported by WebAssembly"), 0, 0, 0, symbol);
        return false;
    }
    Wasm64DataRecord* target = wasm64_data_record_for_symbol(context, symbol);
    if (!target)
    {
        IrSymbol* target_symbol = wasm64_symbol(context, symbol);
        if (target_symbol && target_symbol->kind == IR_SYMBOL_FUNCTION)
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("function-address relocations are unsupported by WebAssembly"), 0, 0, 0,
                        symbol);
        }
        else
        {
            wasm64_fail(context, WASM64_ERROR_UNRESOLVED_SYMBOL, wasm64_s8("unresolved WebAssembly data relocation"), 0, 0, 0, symbol);
        }
        return false;
    }
    if (!record->bytes || offset > record->size || pointer_size > record->size - offset)
    {
        wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("invalid WebAssembly data relocation offset"), 0, 0, 0, record->symbol->id);
        return false;
    }
    u64 value = target->offset;
    if (addend >= 0)
    {
        if (value > UINT64_MAX - (u64)addend)
        {
            wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("WebAssembly data relocation overflow"), 0, 0, 0, symbol);
            return false;
        }
        value += (u64)addend;
    }
    else
    {
        u64 magnitude = (u64)(-(addend + 1)) + 1;
        if (value < magnitude)
        {
            wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("WebAssembly data relocation underflow"), 0, 0, 0, symbol);
            return false;
        }
        value -= magnitude;
    }
    if (pointer_size == 4 && value > UINT32_MAX)
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("Wasm32 data relocation exceeds the 32-bit address space"), 0, 0, 0, symbol);
        return false;
    }
    wasm64_buffer_u64_fixed(&(Wasm64Buffer){.arena = context->arena, .data = record->bytes + offset, .capacity = pointer_size, .length = 0}, value,
                            pointer_size);
    record->has_bytes = true;
    return true;
}

static bool wasm64_apply_data_relocations(Wasm64Context* context)
{
    for (u32 record_index = 0; record_index < context->data_count; record_index += 1)
    {
        Wasm64DataRecord* record = context->data_records + record_index;
        IrGlobal* global = record->global;
        if (global->initializer_kind == IR_GLOBAL_INITIALIZER_SYMBOL_ADDRESS &&
            !wasm64_apply_data_relocation(context, record, global->initializer_symbol, 0, global->initializer_addend, false))
        {
            return false;
        }
        for (u32 relocation_index = 0; relocation_index < global->relocation_count; relocation_index += 1)
        {
            IrGlobalRelocation* relocation = global->relocations + relocation_index;
            if (!wasm64_apply_data_relocation(context, record, relocation->symbol, relocation->offset, relocation->addend,
                                              relocation->is_label_address))
            {
                return false;
            }
        }
    }
    return true;
}

static bool wasm64_build_type_payload(Wasm64Context* context)
{
    wasm64_buffer_u32_leb(&context->type_payload, context->signature_count);
    for (u32 index = 0; index < context->signature_count; index += 1)
    {
        Wasm64Signature* signature = context->signatures + index;
        wasm64_buffer_u8(&context->type_payload, 0x60);
        wasm64_buffer_u32_leb(&context->type_payload, signature->param_count);
        for (u32 parameter_index = 0; parameter_index < signature->param_count; parameter_index += 1)
        {
            wasm64_buffer_u8(&context->type_payload, (u8)signature->params[parameter_index]);
        }
        wasm64_buffer_u32_leb(&context->type_payload, signature->has_result ? 1 : 0);
        if (signature->has_result)
        {
            wasm64_buffer_u8(&context->type_payload, (u8)signature->result);
        }
    }
    context->stats.type_count = context->signature_count;
    return true;
}

static bool wasm64_build_import_payload(Wasm64Context* context)
{
    u32 import_count = context->stats.import_count;
    wasm64_buffer_u32_leb(&context->import_payload, import_count);
    for (u32 index = 0; index < context->function_count; index += 1)
    {
        Wasm64FunctionRecord* record = context->functions + index;
        if (!record->imported)
        {
            continue;
        }
        IrSymbol* symbol = record->symbol;
        String8 link_name = symbol && symbol->link_name.length ? symbol->link_name : symbol ? symbol->name : (String8){0};
        String8 module_name = record->import_module.length ? record->import_module : wasm64_import_module(link_name);
        String8 import_name = record->import_name.length ? record->import_name : wasm64_import_name(link_name, symbol ? symbol->name : (String8){0});
        wasm64_buffer_string(&context->import_payload, module_name);
        wasm64_buffer_string(&context->import_payload, import_name);
        wasm64_buffer_u8(&context->import_payload, 0x00); // function import
        wasm64_buffer_u32_leb(&context->import_payload, record->signature.type_index);
    }
    return true;
}

static bool wasm64_build_function_payload(Wasm64Context* context)
{
    wasm64_buffer_u32_leb(&context->function_payload, context->stats.defined_function_count);
    for (u32 index = 0; index < context->function_count; index += 1)
    {
        Wasm64FunctionRecord* record = context->functions + index;
        if (!record->imported)
        {
            wasm64_buffer_u32_leb(&context->function_payload, record->signature.type_index);
        }
    }
    return true;
}

static bool wasm64_memory_page_count_is_valid(u64 pages)
{
    return pages <= WASM64_MAX_MEMORY_PAGES;
}

static bool wasm64_pages_for_bytes(u64 bytes, u64* pages)
{
    u64 const page_size = 65536;
    u64 result_pages = bytes / page_size + (bytes % page_size != 0);
    bool result = wasm64_memory_page_count_is_valid(result_pages);
    if (result)
    {
        *pages = result_pages;
    }
    return result;
}

#if BUSTER_INCLUDE_TESTS
Wasm64CheckedArithmeticProbe wasm64_test_checked_arithmetic(void)
{
    Wasm64CheckedArithmeticProbe result = {0};
    u64 value = UINT64_MAX - 7;
    result.alignment_overflow_rejected = !wasm64_align_cursor(&value, 16);
    result.frame_addition_overflow_rejected = !wasm64_u64_add(UINT64_MAX - 15, 16, &value);
    result.maximum_byte_count_rounded_up = wasm64_pages_for_bytes(UINT64_MAX, &value) && value == WASM64_MAX_MEMORY_PAGES;
    result.excessive_page_count_rejected = !wasm64_memory_page_count_is_valid(WASM64_MAX_MEMORY_PAGES + 1);
    return result;
}
#endif

static bool wasm64_build_memory_payload(Wasm64Context* context)
{
    u64 minimum = 0;
    if (!wasm64_pages_for_bytes(context->stack_limit, &minimum) || !wasm64_memory_page_count_is_valid(context->options.initial_pages) ||
        !wasm64_memory_page_count_is_valid(context->options.maximum_pages))
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("Wasm64 memory page count exceeds the Memory64 limit"), 0, 0, 0,
                    IR_SYMBOL_ID_INVALID);
        return false;
    }
    if (context->options.initial_pages > minimum)
    {
        minimum = context->options.initial_pages;
    }
    u64 maximum = context->options.maximum_pages;
    if (maximum && maximum < minimum)
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("WebAssembly memory maximum is smaller than its minimum"), 0, 0, 0, IR_SYMBOL_ID_INVALID);
        return false;
    }
    bool memory64 = wasm64_is_memory64(context);
    if (!memory64 && (minimum > 65536 || maximum > 65536))
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("Wasm32 memory exceeds the 4 GiB linear-memory limit"), 0, 0, 0,
                    IR_SYMBOL_ID_INVALID);
        return false;
    }
    context->stats.memory64 = memory64;
    context->stats.memory_min_pages = minimum;
    context->stats.memory_max_pages = maximum;
    wasm64_buffer_u32_leb(&context->memory_payload, 1);
    if (memory64)
    {
        wasm64_buffer_u8(&context->memory_payload, maximum ? 0x05 : 0x04); // maximum + memory64, or memory64 alone
        wasm64_buffer_u64_leb(&context->memory_payload, minimum);
        if (maximum)
        {
            wasm64_buffer_u64_leb(&context->memory_payload, maximum);
        }
    }
    else
    {
        wasm64_buffer_u8(&context->memory_payload, maximum ? 0x01 : 0x00);
        wasm64_buffer_u32_leb(&context->memory_payload, (u32)minimum);
        if (maximum)
        {
            wasm64_buffer_u32_leb(&context->memory_payload, (u32)maximum);
        }
    }
    return true;
}

static String8 wasm64_function_export_name(Wasm64FunctionRecord* record)
{
    String8 result = {0};
    if (record->export_name.length)
    {
        result = record->export_name;
    }
    else if (record->symbol)
    {
        String8 link_name = record->symbol->link_name.length ? record->symbol->link_name : record->symbol->name;
        u64 hash = 0;
        result = wasm64_string_has_hash(link_name, &hash) ? wasm64_string_slice(link_name, hash + 1, link_name.length) : link_name;
    }
    return result;
}

static bool wasm64_build_global_payload(Wasm64Context* context)
{
    // WASI startup may grow memory to hold host-sized arguments. Its second
    // mutable global tracks the new stack limit for generated functions.
    bool wasi = context->options.environment == WASM_ENVIRONMENT_WASI_PREVIEW1;
    wasm64_buffer_u32_leb(&context->global_payload, wasi ? 2 : 1);
    wasm64_buffer_u8(&context->global_payload, (u8)wasm64_pointer_valtype(context));
    wasm64_buffer_u8(&context->global_payload, 0x01); // mutable
    if (wasm64_is_memory64(context))
    {
        wasm64_buffer_u8(&context->global_payload, 0x42);
        wasm64_buffer_s64_leb(&context->global_payload, (s64)context->stack_base);
    }
    else
    {
        wasm64_buffer_u8(&context->global_payload, 0x41);
        wasm64_buffer_s32_leb(&context->global_payload, (s32)(u32)context->stack_base);
    }
    wasm64_buffer_u8(&context->global_payload, 0x0b);
    context->stack_global_index = 0;
    context->stack_limit_global_index = 1;
    if (wasi)
    {
        wasm64_buffer_u8(&context->global_payload, WASM64_VALTYPE_I32);
        wasm64_buffer_u8(&context->global_payload, 0x01); // mutable
        wasm64_buffer_u8(&context->global_payload, 0x41); // i32.const
        wasm64_buffer_s32_leb(&context->global_payload, (s32)(u32)context->stack_limit);
        wasm64_buffer_u8(&context->global_payload, 0x0b);
    }
    context->stats.global_count = wasi ? 2 : 1;
    return true;
}

static bool wasm64_build_export_payload(Wasm64Context* context)
{
    String8 memory_name = context->options.memory_export_name.length ? context->options.memory_export_name : wasm64_s8("memory");
    u32 export_count = context->options.export_memory ? 1 : 0;
    for (u32 index = 0; index < context->function_count; index += 1)
    {
        Wasm64FunctionRecord* record = context->functions + index;
        if (record->exported)
        {
            export_count += 1;
        }
    }
    wasm64_buffer_u32_leb(&context->export_payload, export_count);
    if (context->options.export_memory)
    {
        wasm64_buffer_string(&context->export_payload, memory_name);
        wasm64_buffer_u8(&context->export_payload, 0x02); // memory
        wasm64_buffer_u32_leb(&context->export_payload, 0);
    }
    u32 emitted = 0;
    for (u32 index = 0; index < context->function_count; index += 1)
    {
        Wasm64FunctionRecord* record = context->functions + index;
        if (!record->exported)
        {
            continue;
        }
        String8 name = wasm64_function_export_name(record);
        if (!name.length || (context->options.export_memory && wasm64_string_equal(name, memory_name)))
        {
            wasm64_fail(context, WASM64_ERROR_DUPLICATE_SYMBOL, wasm64_s8("empty or reserved WebAssembly export name"), record->function, 0, 0,
                        record->symbol ? record->symbol->id : IR_SYMBOL_ID_INVALID);
            return false;
        }
        // Export names must be unique.  A duplicate is an error rather than a
        // silently replaced entry, which would make link order observable.
        for (u32 previous = 0; previous < index; previous += 1)
        {
            Wasm64FunctionRecord* prior = context->functions + previous;
            if (prior->exported && wasm64_string_equal(name, wasm64_function_export_name(prior)))
            {
                wasm64_fail(context, WASM64_ERROR_DUPLICATE_SYMBOL, wasm64_s8("duplicate WebAssembly export name"), record->function, 0, 0,
                            record->symbol ? record->symbol->id : IR_SYMBOL_ID_INVALID);
                return false;
            }
        }
        wasm64_buffer_string(&context->export_payload, name);
        wasm64_buffer_u8(&context->export_payload, 0x00); // function
        wasm64_buffer_u32_leb(&context->export_payload, record->function_index);
        emitted += 1;
    }
    context->stats.export_count = emitted + (context->options.export_memory ? 1 : 0);
    return true;
}

static void wasm64_fe_u8(Wasm64FunctionEmitter* emitter, u8 value)
{
    wasm64_buffer_u8(&emitter->body, value);
}

static void wasm64_fe_u32(Wasm64FunctionEmitter* emitter, u32 value)
{
    wasm64_buffer_u32_leb(&emitter->body, value);
}

static void wasm64_fe_i64(Wasm64FunctionEmitter* emitter, s64 value)
{
    wasm64_buffer_s64_leb(&emitter->body, value);
}

static void wasm64_fe_i32(Wasm64FunctionEmitter* emitter, s32 value)
{
    wasm64_buffer_s32_leb(&emitter->body, value);
}

static void wasm64_fe_local_get(Wasm64FunctionEmitter* emitter, u32 local)
{
    wasm64_fe_u8(emitter, 0x20);
    wasm64_fe_u32(emitter, local);
}

static void wasm64_fe_local_set(Wasm64FunctionEmitter* emitter, u32 local)
{
    wasm64_fe_u8(emitter, 0x21);
    wasm64_fe_u32(emitter, local);
}

static void wasm64_fe_local_tee(Wasm64FunctionEmitter* emitter, u32 local)
{
    wasm64_fe_u8(emitter, 0x22);
    wasm64_fe_u32(emitter, local);
}

static void wasm64_fe_i32_const(Wasm64FunctionEmitter* emitter, s32 value)
{
    wasm64_fe_u8(emitter, 0x41);
    wasm64_fe_i32(emitter, value);
}

static void wasm64_fe_i64_const(Wasm64FunctionEmitter* emitter, s64 value)
{
    wasm64_fe_u8(emitter, 0x42);
    wasm64_fe_i64(emitter, value);
}

static void wasm64_fe_pointer_const(Wasm64FunctionEmitter* emitter, u64 value)
{
    if (wasm64_is_memory64(emitter->context))
    {
        wasm64_fe_i64_const(emitter, (s64)value);
    }
    else
    {
        wasm64_fe_i32_const(emitter, (s32)(u32)value);
    }
}

static void wasm64_fe_pointer_add(Wasm64FunctionEmitter* emitter)
{
    wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x7c : 0x6a);
}

static void wasm64_fe_pointer_multiply(Wasm64FunctionEmitter* emitter)
{
    wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x7e : 0x6c);
}

static void wasm64_fe_pointer_and(Wasm64FunctionEmitter* emitter)
{
    wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x83 : 0x71);
}

static void wasm64_fe_f32_const(Wasm64FunctionEmitter* emitter, u32 bits)
{
    wasm64_fe_u8(emitter, 0x43);
    wasm64_buffer_f32(&emitter->body, bits);
}

static void wasm64_fe_f64_const(Wasm64FunctionEmitter* emitter, u64 bits)
{
    wasm64_fe_u8(emitter, 0x44);
    wasm64_buffer_f64(&emitter->body, bits);
}

static void wasm64_fe_global_get(Wasm64FunctionEmitter* emitter, u32 global)
{
    wasm64_fe_u8(emitter, 0x23);
    wasm64_fe_u32(emitter, global);
}

static void wasm64_fe_global_set(Wasm64FunctionEmitter* emitter, u32 global)
{
    wasm64_fe_u8(emitter, 0x24);
    wasm64_fe_u32(emitter, global);
}

static void wasm64_fe_emit_memarg(Wasm64FunctionEmitter* emitter, u32 alignment, u64 offset)
{
    wasm64_fe_u32(emitter, alignment);
    wasm64_buffer_u64_leb(&emitter->body, offset);
}

static IrType* wasm64_fe_value_ir_type(Wasm64FunctionEmitter* emitter, IrValueId value_id)
{
    IrType* result;
    if (value_id.value >= emitter->function->value_count)
    {
        result = 0;
    }
    else
    {
        result = wasm64_type(emitter->context, emitter->function->values[value_id.value].canonical_type);
    }

    return result;
}

static void wasm64_fe_integer_normalize(Wasm64FunctionEmitter* emitter, IrType* type, bool signed_value)
{
    if (type && wasm64_type_is_integer(type))
    {
        u32 bits = wasm64_integer_bits(type);
        Wasm64ValType valtype = 0;
        wasm64_valtype_for_type(emitter->context, type, false, &valtype);
        if (type->kind == IR_TYPE_BOOLEAN)
        {
            wasm64_fe_u8(emitter, valtype == WASM64_VALTYPE_I64 ? 0x50 : 0x45); // eqz
            wasm64_fe_u8(emitter, valtype == WASM64_VALTYPE_I64 ? 0x45 : 0x45);
            // The two eqz operations turn a non-zero scalar into one for both
            // widths.  For i64 the first opcode above was intentionally replaced
            // below by the canonical i64.eqz sequence.
            return;
        }
        if (valtype == WASM64_VALTYPE_I32)
        {
            if (bits >= 32)
            {
                return;
            }
            if (signed_value)
            {
                if (bits == 8)
                {
                    wasm64_fe_u8(emitter, 0xc0); // i32.extend8_s
                }
                else if (bits == 16)
                {
                    wasm64_fe_u8(emitter, 0xc1); // i32.extend16_s
                }
                else
                {
                    wasm64_fe_i32_const(emitter, (s32)(32 - bits));
                    wasm64_fe_u8(emitter, 0x74); // shl
                    wasm64_fe_i32_const(emitter, (s32)(32 - bits));
                    wasm64_fe_u8(emitter, 0x75); // shr_s
                }
            }
            else
            {
                wasm64_fe_i32_const(emitter, (s32)((UINT32_C(1) << bits) - 1));
                wasm64_fe_u8(emitter, 0x71); // and
            }
        }
        else if (valtype == WASM64_VALTYPE_I64)
        {
            if (bits < 64)
            {
                if (signed_value)
                {
                    wasm64_fe_i64_const(emitter, (s64)(64 - bits));
                    wasm64_fe_u8(emitter, 0x86); // i64.shl
                    wasm64_fe_i64_const(emitter, (s64)(64 - bits));
                    wasm64_fe_u8(emitter, 0x87); // i64.shr_s
                }
                else
                {
                    u64 mask = bits == 64 ? UINT64_MAX : ((UINT64_C(1) << bits) - 1);
                    wasm64_fe_i64_const(emitter, (s64)mask);
                    wasm64_fe_u8(emitter, 0x83); // i64.and
                }
            }
        }
    }
}

static void wasm64_fe_emit_value(Wasm64FunctionEmitter* emitter, IrValueId value_id)
{
    wasm64_fe_local_get(emitter, emitter->value_locals[value_id.value]);
}

static void wasm64_fe_emit_integer_value(Wasm64FunctionEmitter* emitter, IrValueId value_id, bool signed_value)
{
    wasm64_fe_emit_value(emitter, value_id);
    wasm64_fe_integer_normalize(emitter, wasm64_fe_value_ir_type(emitter, value_id), signed_value);
}

static void wasm64_fe_emit_result_set(Wasm64FunctionEmitter* emitter, IrInstruction* instruction, bool normalize_integer, bool signed_value)
{
    if (instruction->result.value == IR_ID_UNDERLYING_INVALID)
    {
        return;
    }
    if (normalize_integer)
    {
        wasm64_fe_integer_normalize(emitter, wasm64_type(emitter->context, instruction->canonical_type), signed_value);
    }
    wasm64_fe_local_set(emitter, emitter->value_locals[instruction->result.value]);
}

static void wasm64_fe_load(Wasm64FunctionEmitter* emitter, IrType* type)
{
    u32 size = wasm64_type_size(type);
    // A stronger object alignment is not a legal memory-op alignment immediate.
    u32 alignment = type && type->layout.alignment ? wasm64_log2_alignment(BUSTER_MIN(type->layout.alignment, BUSTER_MIN(size, 8u))) : 0;
    if (type && (type->kind == IR_TYPE_POINTER || type->kind == IR_TYPE_FUNCTION))
    {
        wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x29 : 0x28);
        wasm64_fe_emit_memarg(emitter, alignment, 0);
    }
    else if (type && type->kind == IR_TYPE_FLOAT)
    {
        wasm64_fe_u8(emitter, type->bit_width == 32 ? 0x2a : 0x2b);
        wasm64_fe_emit_memarg(emitter, alignment, 0);
    }
    else if (type && wasm64_type_is_integer(type))
    {
        Wasm64ValType valtype = 0;
        wasm64_valtype_for_type(emitter->context, type, false, &valtype);
        bool sign = type->kind == IR_TYPE_INTEGER && type->is_signed;
        if (valtype == WASM64_VALTYPE_I64)
        {
            wasm64_fe_u8(emitter, 0x29);
        }
        else if (size <= 1)
        {
            wasm64_fe_u8(emitter, sign ? 0x2c : 0x2d); // i32.load8_s/u
        }
        else if (size <= 2)
        {
            wasm64_fe_u8(emitter, sign ? 0x2e : 0x2f); // i32.load16_s/u
        }
        else
        {
            wasm64_fe_u8(emitter, sign ? 0x28 : 0x28); // i32.load (zero/sign same width)
        }
        wasm64_fe_emit_memarg(emitter, alignment, 0);
    }
}

static void wasm64_fe_store(Wasm64FunctionEmitter* emitter, IrType* type)
{
    u32 size = wasm64_type_size(type);
    // A stronger object alignment is not a legal memory-op alignment immediate.
    u32 alignment = type && type->layout.alignment ? wasm64_log2_alignment(BUSTER_MIN(type->layout.alignment, BUSTER_MIN(size, 8u))) : 0;
    if (type && (type->kind == IR_TYPE_POINTER || type->kind == IR_TYPE_FUNCTION))
    {
        wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x37 : 0x36);
        wasm64_fe_emit_memarg(emitter, alignment, 0);
    }
    else if (type && type->kind == IR_TYPE_FLOAT)
    {
        wasm64_fe_u8(emitter, type->bit_width == 32 ? 0x38 : 0x39);
        wasm64_fe_emit_memarg(emitter, alignment, 0);
    }
    else if (type && wasm64_type_is_integer(type))
    {
        Wasm64ValType valtype = 0;
        wasm64_valtype_for_type(emitter->context, type, false, &valtype);
        if (valtype == WASM64_VALTYPE_I64)
        {
            if (size <= 1)
            {
                wasm64_fe_u8(emitter, 0x3c); // i64.store8
            }
            else if (size <= 2)
            {
                wasm64_fe_u8(emitter, 0x3d); // i64.store16
            }
            else if (size <= 4)
            {
                wasm64_fe_u8(emitter, 0x3e); // i64.store32
            }
            else
            {
                wasm64_fe_u8(emitter, 0x37);
            }
        }
        else if (size <= 1)
        {
            wasm64_fe_u8(emitter, 0x3a); // i32.store8
        }
        else if (size <= 2)
        {
            wasm64_fe_u8(emitter, 0x3b); // i32.store16
        }
        else
        {
            wasm64_fe_u8(emitter, 0x36); // i32.store
        }
        wasm64_fe_emit_memarg(emitter, alignment, 0);
    }
}

static void wasm64_fe_emit_binary_opcode(Wasm64FunctionEmitter* emitter, IrBinaryOperation operation, IrType* type)
{
    bool is_float = wasm64_type_is_float(type);
    bool is_i64 = false;
    if (type)
    {
        Wasm64ValType valtype = 0;
        wasm64_valtype_for_type(emitter->context, type, false, &valtype);
        is_i64 = valtype == WASM64_VALTYPE_I64;
    }
    u8 opcode = 0;
    if (is_float)
    {
        bool is_f64 = type->bit_width == 64;
        switch (operation)
        {
        case IR_BINARY_FLOAT_ADD: opcode = is_f64 ? 0xa0 : 0x92; break;
        case IR_BINARY_FLOAT_SUBTRACT: opcode = is_f64 ? 0xa1 : 0x93; break;
        case IR_BINARY_FLOAT_MULTIPLY: opcode = is_f64 ? 0xa2 : 0x94; break;
        case IR_BINARY_FLOAT_DIVIDE: opcode = is_f64 ? 0xa3 : 0x95; break;
        case IR_BINARY_FLOAT_EQUAL: opcode = is_f64 ? 0x61 : 0x5b; break;
        case IR_BINARY_FLOAT_NOT_EQUAL: opcode = is_f64 ? 0x62 : 0x5c; break;
        case IR_BINARY_FLOAT_LESS: opcode = is_f64 ? 0x63 : 0x5d; break;
        case IR_BINARY_FLOAT_GREATER: opcode = is_f64 ? 0x64 : 0x5e; break;
        case IR_BINARY_FLOAT_LESS_EQUAL: opcode = is_f64 ? 0x65 : 0x5f; break;
        case IR_BINARY_FLOAT_GREATER_EQUAL: opcode = is_f64 ? 0x66 : 0x60; break;
        default: break;
        }
    }
    else
    {
        u8 base = is_i64 ? 0x7c : 0x6a;
        switch (operation)
        {
        case IR_BINARY_INTEGER_ADD: opcode = base; break;
        case IR_BINARY_INTEGER_SUBTRACT: opcode = base + 1; break;
        case IR_BINARY_INTEGER_MULTIPLY: opcode = base + 2; break;
        case IR_BINARY_SIGNED_DIVIDE: opcode = base + 3; break;
        case IR_BINARY_UNSIGNED_DIVIDE: opcode = base + 4; break;
        case IR_BINARY_SIGNED_REMAINDER: opcode = base + 5; break;
        case IR_BINARY_UNSIGNED_REMAINDER: opcode = base + 6; break;
        case IR_BINARY_SHIFT_LEFT: opcode = base + 10; break;
        case IR_BINARY_SIGNED_SHIFT_RIGHT: opcode = base + 11; break;
        case IR_BINARY_UNSIGNED_SHIFT_RIGHT: opcode = base + 12; break;
        case IR_BINARY_INTEGER_BITWISE_AND: opcode = base + 7; break;
        case IR_BINARY_INTEGER_BITWISE_OR: opcode = base + 8; break;
        case IR_BINARY_INTEGER_BITWISE_XOR: opcode = base + 9; break;
        case IR_BINARY_INTEGER_EQUAL: opcode = is_i64 ? 0x51 : 0x46; break;
        case IR_BINARY_INTEGER_NOT_EQUAL: opcode = is_i64 ? 0x52 : 0x47; break;
        case IR_BINARY_SIGNED_LESS: opcode = is_i64 ? 0x53 : 0x48; break;
        case IR_BINARY_UNSIGNED_LESS: opcode = is_i64 ? 0x54 : 0x49; break;
        case IR_BINARY_SIGNED_GREATER: opcode = is_i64 ? 0x55 : 0x4a; break;
        case IR_BINARY_UNSIGNED_GREATER: opcode = is_i64 ? 0x56 : 0x4b; break;
        case IR_BINARY_SIGNED_LESS_EQUAL: opcode = is_i64 ? 0x57 : 0x4c; break;
        case IR_BINARY_UNSIGNED_LESS_EQUAL: opcode = is_i64 ? 0x58 : 0x4d; break;
        case IR_BINARY_SIGNED_GREATER_EQUAL: opcode = is_i64 ? 0x59 : 0x4e; break;
        case IR_BINARY_UNSIGNED_GREATER_EQUAL: opcode = is_i64 ? 0x5a : 0x4f; break;
        case IR_BINARY_POINTER_EQUAL: opcode = is_i64 ? 0x51 : 0x46; break;
        case IR_BINARY_POINTER_NOT_EQUAL: opcode = is_i64 ? 0x52 : 0x47; break;
        case IR_BINARY_BOOLEAN_AND: opcode = 0x71; break;
        case IR_BINARY_BOOLEAN_OR: opcode = 0x72; break;
        case IR_BINARY_BOOLEAN_EQUAL: opcode = 0x46; break;
        case IR_BINARY_BOOLEAN_NOT_EQUAL: opcode = 0x47; break;
        default: break;
        }
    }
    if (!opcode)
    {
        wasm64_fail(emitter->context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("unsupported scalar WebAssembly binary operation"), emitter->function, 0, 0,
                    IR_SYMBOL_ID_INVALID);
        return;
    }
    wasm64_fe_u8(emitter, opcode);
}

static void wasm64_fe_emit_unary_opcode(Wasm64FunctionEmitter* emitter, IrUnaryOperation operation, IrType* type)
{
    Wasm64ValType valtype = 0;
    wasm64_valtype_for_type(emitter->context, type, false, &valtype);
    bool is_i64 = valtype == WASM64_VALTYPE_I64;
    u8 opcode = 0;
    switch (operation)
    {
    case IR_UNARY_INTEGER_COUNT_LEADING_ZEROS: opcode = is_i64 ? 0x79 : 0x67; break;
    case IR_UNARY_INTEGER_COUNT_TRAILING_ZEROS: opcode = is_i64 ? 0x7a : 0x68; break;
    case IR_UNARY_INTEGER_POPULATION_COUNT: opcode = is_i64 ? 0x7b : 0x69; break;
    default: break;
    }
    if (opcode)
    {
        wasm64_fe_u8(emitter, opcode);
    }
}

static void wasm64_fe_emit_parallel_copy(Wasm64FunctionEmitter* emitter, IrBlock* predecessor, IrBlock* target)
{
    u32 parameter_count = target ? target->parameter_count : 0;
    if (parameter_count)
    {
        IrPublishedCfg const* cfg = emitter->function->published_cfg;
        IrCfgEdge const* edge = ir_function_cfg_edge(emitter->function, predecessor->id, target->id);
        if (!edge)
        {
            wasm64_fail(emitter->context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("missing WebAssembly block-parameter incoming value"), emitter->function,
                        target, 0, IR_SYMBOL_ID_INVALID);
        }
        else
        {
            IrCfgBlock const* block = cfg->blocks + target->id.value;
            for (u32 index = 0; index < parameter_count; index += 1)
            {
                wasm64_fe_emit_value(emitter, cfg->arguments[edge->argument_offset + index]);
                wasm64_fe_local_set(emitter, emitter->block_temp_bases[target->id.value] + index);
            }
            for (u32 index = 0; index < parameter_count; index += 1)
            {
                IrCfgParameter const* parameter = cfg->parameters + block->parameter_offset + index;
                wasm64_fe_local_get(emitter, emitter->block_temp_bases[target->id.value] + index);
                wasm64_fe_local_set(emitter, emitter->value_locals[parameter->value.value]);
            }
        }
    }
}

static Wasm64StringRecord* wasm64_string_record_find(Wasm64Context* context, IrFunction* function, IrInstructionId instruction)
{
    for (u32 index = 0; index < context->string_count; index += 1)
    {
        Wasm64StringRecord* record = context->strings + index;
        if (record->function == function && record->instruction.value == instruction.value)
        {
            return record;
        }
    }
    return 0;
}

static void wasm64_fe_emit_cast(Wasm64FunctionEmitter* emitter, IrInstruction* instruction, IrType* source, IrType* destination)
{
    Wasm64ValType source_type = 0;
    Wasm64ValType destination_type = 0;
    bool source_place = false;
    bool destination_place = false;
    if (instruction->operands[0].value < emitter->function->value_count)
    {
        source_place = emitter->function->values[instruction->operands[0].value].category == IR_VALUE_PLACE;
    }
    if (!wasm64_valtype_for_type(emitter->context, source, source_place, &source_type) || !wasm64_valtype_for_type(emitter->context, destination, destination_place, &destination_type))
    {
        wasm64_fail(emitter->context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("unsupported WebAssembly cast shape"), emitter->function, 0,
                    instruction, IR_SYMBOL_ID_INVALID);
        return;
    }
    bool source_integer = wasm64_type_is_integer(source) || source->kind == IR_TYPE_POINTER;
    bool destination_integer = wasm64_type_is_integer(destination) || destination->kind == IR_TYPE_POINTER;
    bool source_float = wasm64_type_is_float(source);
    bool destination_float = wasm64_type_is_float(destination);
    if (source_integer)
    {
        wasm64_fe_emit_integer_value(emitter, instruction->operands[0], source->kind == IR_TYPE_INTEGER && source->is_signed);
    }
    else
    {
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
    }
    if (source_type != destination_type || instruction->conversion_operation != IR_CONVERSION_IDENTITY)
    {
        if (source_integer && destination_integer)
        {
            if (source_type == WASM64_VALTYPE_I32 && destination_type == WASM64_VALTYPE_I64)
            {
                wasm64_fe_u8(emitter, source->kind == IR_TYPE_INTEGER && source->is_signed ? 0xac : 0xad);
            }
            else if (source_type == WASM64_VALTYPE_I64 && destination_type == WASM64_VALTYPE_I32)
            {
                wasm64_fe_u8(emitter, 0xa7);
            }
            wasm64_fe_integer_normalize(emitter, destination, destination->kind == IR_TYPE_INTEGER && destination->is_signed);
            return;
        }
        if (source_integer && destination_float)
        {
            if (destination_type == WASM64_VALTYPE_F32)
            {
                wasm64_fe_u8(emitter, source_type == WASM64_VALTYPE_I64 ? (source->kind == IR_TYPE_INTEGER && source->is_signed ? 0xb4 : 0xb5)
                                                                         : (source->kind == IR_TYPE_INTEGER && source->is_signed ? 0xb2 : 0xb3));
            }
            else
            {
                wasm64_fe_u8(emitter, source_type == WASM64_VALTYPE_I64 ? (source->kind == IR_TYPE_INTEGER && source->is_signed ? 0xb9 : 0xba)
                                                                         : (source->kind == IR_TYPE_INTEGER && source->is_signed ? 0xb7 : 0xb8));
            }
            return;
        }
        if (source_float && destination_integer)
        {
            if (destination_type == WASM64_VALTYPE_I32)
            {
                wasm64_fe_u8(emitter, source_type == WASM64_VALTYPE_F32 ? (destination->kind == IR_TYPE_INTEGER && destination->is_signed ? 0xa8 : 0xa9)
                                                                         : (destination->kind == IR_TYPE_INTEGER && destination->is_signed ? 0xaa : 0xab));
            }
            else
            {
                wasm64_fe_u8(emitter, source_type == WASM64_VALTYPE_F32 ? (destination->kind == IR_TYPE_INTEGER && destination->is_signed ? 0xae : 0xaf)
                                                                         : (destination->kind == IR_TYPE_INTEGER && destination->is_signed ? 0xb0 : 0xb1));
            }
            wasm64_fe_integer_normalize(emitter, destination, destination->kind == IR_TYPE_INTEGER && destination->is_signed);
            return;
        }
        if (source_float && destination_float)
        {
            if (source_type == WASM64_VALTYPE_F32 && destination_type == WASM64_VALTYPE_F64)
            {
                wasm64_fe_u8(emitter, 0xbb);
            }
            else if (source_type == WASM64_VALTYPE_F64 && destination_type == WASM64_VALTYPE_F32)
            {
                wasm64_fe_u8(emitter, 0xb6);
            }
            return;
        }
        if (instruction->conversion_operation == IR_CONVERSION_INTEGER_REINTERPRET || instruction->conversion_operation == IR_CONVERSION_POINTER_REINTERPRET)
        {
            if (source_type == WASM64_VALTYPE_I32 && destination_type == WASM64_VALTYPE_F32)
            {
                wasm64_fe_u8(emitter, 0xbe);
            }
            else if (source_type == WASM64_VALTYPE_F32 && destination_type == WASM64_VALTYPE_I32)
            {
                wasm64_fe_u8(emitter, 0xbc);
            }
            else if (source_type == WASM64_VALTYPE_I64 && destination_type == WASM64_VALTYPE_F64)
            {
                wasm64_fe_u8(emitter, 0xbf);
            }
            else if (source_type == WASM64_VALTYPE_F64 && destination_type == WASM64_VALTYPE_I64)
            {
                wasm64_fe_u8(emitter, 0xbd);
            }
            else if (source_type != destination_type)
            {
                wasm64_fail(emitter->context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("invalid Wasm64 reinterpret cast"), emitter->function, 0,
                            instruction, IR_SYMBOL_ID_INVALID);
            }
            return;
        }
        wasm64_fail(emitter->context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("unsupported Wasm64 conversion"), emitter->function, 0, instruction,
                    IR_SYMBOL_ID_INVALID);
    }
}

static u32 wasm64_fe_count_block_parameters(IrFunction* function)
{
    u32 count = 0;
    for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
    {
        count += function->blocks[block_index].parameter_count;
    }
    return count;
}

static bool wasm64_fe_initialize(Wasm64FunctionEmitter* emitter, Wasm64Context* context, Wasm64FunctionRecord* record)
{
    IrFunction* function = record->function;
    *emitter = (Wasm64FunctionEmitter){.context = context, .function = function, .record = record};
    wasm64_buffer_init(&emitter->body, context->arena);
    emitter->value_locals = arena_allocate(context->arena, u32, function->value_count ? function->value_count : 1);
    emitter->value_types = arena_allocate(context->arena, u8, function->value_count ? function->value_count : 1);
    emitter->value_offsets = arena_allocate(context->arena, u32, function->value_count ? function->value_count : 1);
    for (u32 value_index = 0; value_index < function->value_count; value_index += 1)
    {
        emitter->value_locals[value_index] = record->signature.param_count + value_index;
        emitter->value_offsets[value_index] = UINT32_MAX;
        IrValue* value = function->values + value_index;
        IrType* type = wasm64_type(context, value->canonical_type);
        Wasm64ValType valtype = 0;
        // A direct callee is represented as an SSA value by canonical IR, but
        // the call encoding consumes its symbol index rather than a runtime
        // operand.  Reserve an inert scalar local for that value so direct
        // calls do not look like aggregate ABI traffic.
        if (type && type->kind == IR_TYPE_FUNCTION)
        {
            valtype = wasm64_pointer_valtype(context);
        }
        else if (wasm64_type_is_local_aggregate(type))
        {
            valtype = wasm64_pointer_valtype(context);
        }
        else if (!wasm64_valtype_for_type(context, type, value->category == IR_VALUE_PLACE, &valtype))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("aggregate WebAssembly SSA value is unsupported"), function, 0, 0,
                        IR_SYMBOL_ID_INVALID);
            return false;
        }
        emitter->value_types[value_index] = (u8)valtype;
    }

    u64 frame_cursor = 0;
    for (u32 instruction_index = 0; instruction_index < function->instruction_count; instruction_index += 1)
    {
        IrInstruction* instruction = function->instructions + instruction_index;
        if (instruction->result.value == IR_ID_UNDERLYING_INVALID)
        {
            continue;
        }
        IrType* type = wasm64_type(context, instruction->canonical_type);
        bool snapshot = function->values[instruction->result.value].category == IR_VALUE_VALUE && wasm64_type_is_local_aggregate(type);
        if (instruction->opcode != IR_OPCODE_LOCAL && !snapshot)
        {
            continue;
        }
        u64 size = type && type->layout.resolved ? type->layout.size : 0;
        u64 alignment = type && type->layout.alignment ? type->layout.alignment : 1;
        if (!size || size > UINT32_MAX || alignment > UINT32_MAX || alignment == 0 || alignment > (UINT64_C(1) << 31) ||
            (snapshot && alignment > 16))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("invalid WebAssembly local frame layout"), function, 0, instruction, IR_SYMBOL_ID_INVALID);
            return false;
        }
        if (!wasm64_align_cursor(&frame_cursor, alignment))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("Wasm64 local-frame alignment overflow"), function, 0, instruction,
                        IR_SYMBOL_ID_INVALID);
            return false;
        }
        if (frame_cursor > UINT32_MAX - size)
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("WebAssembly local frame exceeds 32-bit offset"), function, 0, instruction,
                        IR_SYMBOL_ID_INVALID);
            return false;
        }
        emitter->value_offsets[instruction->result.value] = (u32)frame_cursor;
        frame_cursor += size;
    }
    if (!wasm64_align_cursor(&frame_cursor, 16) || frame_cursor > UINT32_MAX)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("WebAssembly local frame exceeds 32-bit offset"), function, 0, 0, IR_SYMBOL_ID_INVALID);
        return false;
    }
    emitter->frame_size = (u32)frame_cursor;
    u32 temp_count = wasm64_fe_count_block_parameters(function);
    emitter->pc_local = record->signature.param_count + function->value_count;
    emitter->fp_local = emitter->pc_local + 1;
    emitter->sp_local = emitter->fp_local + 1;
    emitter->scratch_local = emitter->sp_local + 1;
    emitter->temp_base = emitter->scratch_local + 1;
    emitter->extra_local_count = 4 + temp_count;
    emitter->local_count = record->signature.param_count + function->value_count + emitter->extra_local_count;
    u32 declared_local_count = function->value_count + emitter->extra_local_count;
    emitter->local_types = arena_allocate(context->arena, u8, declared_local_count ? declared_local_count : 1);
    if (function->value_count)
    {
        memcpy(emitter->local_types, emitter->value_types, function->value_count);
    }
    u32 local_type_index = function->value_count;
    emitter->local_types[local_type_index++] = WASM64_VALTYPE_I32;
    emitter->local_types[local_type_index++] = (u8)wasm64_pointer_valtype(context);
    emitter->local_types[local_type_index++] = (u8)wasm64_pointer_valtype(context);
    emitter->local_types[local_type_index++] = (u8)wasm64_pointer_valtype(context);
    emitter->block_temp_bases = arena_allocate(context->arena, u32, function->block_count);
    for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
    {
        // Temporary local types are declared in block order, not one reusable
        // untyped tile: different joins can carry different scalar types.
        emitter->block_temp_bases[block_index] = record->signature.param_count + local_type_index;
        IrCfgBlock const* published_block = function->published_cfg->blocks + block_index;
        for (u32 parameter_index = 0; parameter_index < published_block->parameter_count; parameter_index += 1)
        {
            IrCfgParameter const* parameter = function->published_cfg->parameters + published_block->parameter_offset + parameter_index;
            Wasm64ValType type = 0;
            IrType* parameter_type = wasm64_type(context, parameter->canonical_type);
            if (!wasm64_valtype_for_type(context, parameter_type, function->values[parameter->value.value].category == IR_VALUE_PLACE, &type))
            {
                wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("aggregate WebAssembly block parameter is unsupported"), function,
                            function->blocks + block_index, 0, IR_SYMBOL_ID_INVALID);
                return false;
            }
            emitter->local_types[local_type_index++] = (u8)type;
        }
    }
    return true;
}

static void wasm64_fe_emit_stack_trap_if(Wasm64FunctionEmitter* emitter)
{
    wasm64_fe_u8(emitter, 0x04); // if
    wasm64_fe_u8(emitter, 0x40);
    // Restore this function's entry pointer before the deliberate trap.
    wasm64_fe_local_get(emitter, emitter->fp_local);
    wasm64_fe_global_set(emitter, emitter->context->stack_global_index);
    wasm64_fe_u8(emitter, 0x00); // unreachable
    wasm64_fe_u8(emitter, 0x0b); // end if
}

static void wasm64_fe_emit_stack_bounds_check(Wasm64FunctionEmitter* emitter, u32 local)
{
    wasm64_fe_local_get(emitter, local);
    wasm64_fe_pointer_const(emitter, emitter->context->stack_base);
    wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x54 : 0x49); // unsigned less
    wasm64_fe_emit_stack_trap_if(emitter);
    wasm64_fe_local_get(emitter, local);
    if (emitter->context->options.environment == WASM_ENVIRONMENT_WASI_PREVIEW1)
    {
        wasm64_fe_global_get(emitter, emitter->context->stack_limit_global_index);
    }
    else
    {
        wasm64_fe_pointer_const(emitter, emitter->context->stack_limit);
    }
    wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x56 : 0x4b); // unsigned greater
    wasm64_fe_emit_stack_trap_if(emitter);
}

static void wasm64_fe_emit_prologue(Wasm64FunctionEmitter* emitter)
{
    wasm64_fe_global_get(emitter, emitter->context->stack_global_index);
    wasm64_fe_local_set(emitter, emitter->fp_local);
    wasm64_fe_emit_stack_bounds_check(emitter, emitter->fp_local);
    wasm64_fe_local_get(emitter, emitter->fp_local);
    wasm64_fe_pointer_const(emitter, emitter->frame_size);
    wasm64_fe_pointer_add(emitter);
    wasm64_fe_local_set(emitter, emitter->sp_local);
    wasm64_fe_local_get(emitter, emitter->sp_local);
    wasm64_fe_local_get(emitter, emitter->fp_local);
    wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x54 : 0x49); // addition wrapped
    wasm64_fe_emit_stack_trap_if(emitter);
    wasm64_fe_emit_stack_bounds_check(emitter, emitter->sp_local);
    wasm64_fe_local_get(emitter, emitter->sp_local);
    wasm64_fe_global_set(emitter, emitter->context->stack_global_index);
    for (u32 index = 0; index < emitter->function->value_count; index += 1)
    {
        if (emitter->value_offsets[index] != UINT32_MAX && emitter->function->values[index].category == IR_VALUE_VALUE)
        {
            wasm64_fe_local_get(emitter, emitter->fp_local);
            wasm64_fe_pointer_const(emitter, emitter->value_offsets[index]);
            wasm64_fe_pointer_add(emitter);
            wasm64_fe_local_set(emitter, emitter->value_locals[index]);
        }
    }
    wasm64_fe_i32_const(emitter, (s32)emitter->function->entry.value);
    wasm64_fe_local_set(emitter, emitter->pc_local);
}

static void wasm64_fe_emit_stack_allocate(Wasm64FunctionEmitter* emitter, IrInstruction* instruction)
{
    u64 alignment = instruction->immediate_count == 1 ? instruction->immediates[0] : 1;
    bool valid = alignment && !(alignment & (alignment - 1)) && alignment <= UINT32_MAX;
    if (!valid)
    {
        wasm64_fail(emitter->context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("invalid WebAssembly dynamic stack alignment"), emitter->function, 0, instruction,
                    IR_SYMBOL_ID_INVALID);
    }
    if (valid)
    {
        wasm64_fe_emit_stack_bounds_check(emitter, emitter->sp_local);
        wasm64_fe_local_get(emitter, emitter->sp_local);
        wasm64_fe_pointer_const(emitter, alignment - 1);
        wasm64_fe_pointer_add(emitter);
        wasm64_fe_local_set(emitter, emitter->scratch_local);
        wasm64_fe_local_get(emitter, emitter->scratch_local);
        wasm64_fe_local_get(emitter, emitter->sp_local);
        wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x54 : 0x49); // alignment addition wrapped
        wasm64_fe_emit_stack_trap_if(emitter);
        wasm64_fe_local_get(emitter, emitter->scratch_local);
        wasm64_fe_pointer_const(emitter, ~(alignment - 1));
        wasm64_fe_pointer_and(emitter);
        wasm64_fe_local_set(emitter, emitter->scratch_local);
        wasm64_fe_emit_stack_bounds_check(emitter, emitter->scratch_local);
        wasm64_fe_local_get(emitter, emitter->scratch_local);
        wasm64_fe_local_set(emitter, emitter->value_locals[instruction->result.value]);
        wasm64_fe_local_get(emitter, emitter->scratch_local);
        IrType* size_type = wasm64_fe_value_ir_type(emitter, instruction->operands[0]);
        Wasm64ValType size_valtype = 0;
        wasm64_valtype_for_type(emitter->context, size_type, false, &size_valtype);
        if (!wasm64_is_memory64(emitter->context) && size_valtype == WASM64_VALTYPE_I64)
        {
            wasm64_fe_emit_value(emitter, instruction->operands[0]);
            wasm64_fe_i64_const(emitter, UINT32_MAX);
            wasm64_fe_u8(emitter, 0x56); // i64.gt_u
            wasm64_fe_emit_stack_trap_if(emitter);
        }
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        if (wasm64_is_memory64(emitter->context) && size_valtype == WASM64_VALTYPE_I32)
        {
            wasm64_fe_u8(emitter, 0xad); // i64.extend_i32_u
        }
        else if (!wasm64_is_memory64(emitter->context) && size_valtype == WASM64_VALTYPE_I64)
        {
            wasm64_fe_u8(emitter, 0xa7); // i32.wrap_i64
        }
        wasm64_fe_pointer_add(emitter);
        wasm64_fe_local_set(emitter, emitter->sp_local);
        wasm64_fe_local_get(emitter, emitter->sp_local);
        wasm64_fe_local_get(emitter, emitter->scratch_local);
        wasm64_fe_u8(emitter, wasm64_is_memory64(emitter->context) ? 0x54 : 0x49); // allocation addition wrapped
        wasm64_fe_emit_stack_trap_if(emitter);
        wasm64_fe_emit_stack_bounds_check(emitter, emitter->sp_local);
        wasm64_fe_local_get(emitter, emitter->sp_local);
        wasm64_fe_global_set(emitter, emitter->context->stack_global_index);
    }
}

static void wasm64_fe_emit_address_add(Wasm64FunctionEmitter* emitter, u64 offset)
{
    if (offset)
    {
        wasm64_fe_pointer_const(emitter, offset);
        wasm64_fe_pointer_add(emitter);
    }
}

BUSTER_GLOBAL_LOCAL void wasm64_fe_copy_bytes(Wasm64FunctionEmitter* emitter, u64 size)
{
    // Bulk memory uses the memory's address width for all three operands.
    wasm64_fe_pointer_const(emitter, size);
    wasm64_fe_u8(emitter, 0xfc);
    wasm64_fe_u32(emitter, 10); // memory.copy
    wasm64_fe_u32(emitter, 0);
    wasm64_fe_u32(emitter, 0);
}

BUSTER_GLOBAL_LOCAL void wasm64_fe_emit_aggregate(Wasm64FunctionEmitter* emitter, IrBlock* block, IrInstruction* instruction, IrType* type)
{
    bool valid = wasm64_type_is_local_aggregate(type);
    if (valid)
    {
        // Initialize private padding as well as members. This has no external
        // volatile accesses, and keeps partially populated unions deterministic.
        wasm64_fe_emit_value(emitter, instruction->result);
        wasm64_fe_i32_const(emitter, 0);
        wasm64_fe_pointer_const(emitter, type->layout.size);
        wasm64_fe_u8(emitter, 0xfc);
        wasm64_fe_u32(emitter, 11); // memory.fill
        wasm64_fe_u32(emitter, 0);
    }
    for (u32 index = 0; valid && index < instruction->operand_count; index += 1)
    {
        IrValueId operand = instruction->operands[index];
        IrType* operand_type = wasm64_fe_value_ir_type(emitter, operand);
        u64 offset = 0;
        valid = operand_type && operand_type->layout.resolved &&
                emitter->function->values[operand.value].category == IR_VALUE_VALUE &&
                (wasm64_type_is_scalar(operand_type) || wasm64_type_is_local_aggregate(operand_type));
        if (valid && instruction->opcode == IR_OPCODE_AGGREGATE)
        {
            u64 field_index = instruction->immediates[index];
            valid = field_index < type->field_count && !type->fields[field_index].is_bit_field;
            if (valid)
            {
                offset = type->fields[field_index].offset;
            }
        }
        else if (valid)
        {
            valid = operand_type->layout.size <= UINT64_MAX / (index ? index : 1);
            if (valid)
            {
                offset = (u64)index * operand_type->layout.size;
            }
        }
        valid = valid && offset <= type->layout.size && operand_type->layout.size <= type->layout.size - offset;
        if (valid)
        {
            wasm64_fe_emit_value(emitter, instruction->result);
            wasm64_fe_emit_address_add(emitter, offset);
            wasm64_fe_emit_value(emitter, operand);
            if (wasm64_type_is_local_aggregate(operand_type))
            {
                wasm64_fe_copy_bytes(emitter, operand_type->layout.size);
            }
            else
            {
                wasm64_fe_store(emitter, operand_type);
            }
        }
    }
    if (!valid)
    {
        wasm64_fail(emitter->context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI,
                    wasm64_s8("unsupported Wasm64 local aggregate construction or member layout"), emitter->function, block, instruction,
                    IR_SYMBOL_ID_INVALID);
    }
}

static IrBlock* wasm64_fe_block(Wasm64FunctionEmitter* emitter, IrBlockId id)
{
    return id.value < emitter->function->block_count ? emitter->function->blocks + id.value : 0;
}

static void wasm64_fe_emit_integer_constant(Wasm64FunctionEmitter* emitter, IrInstruction* instruction, IrType* type)
{
    u64 bits = instruction->immediate_count ? instruction->immediates[0] : 0;
    if (instruction->immediate_is_negative)
    {
        bits = 0 - bits;
    }
    Wasm64ValType valtype = 0;
    wasm64_valtype_for_type(emitter->context, type, false, &valtype);
    if (valtype == WASM64_VALTYPE_I64)
    {
        wasm64_fe_i64_const(emitter, (s64)bits);
    }
    else
    {
        wasm64_fe_i32_const(emitter, (s32)(u32)bits);
    }
    wasm64_fe_integer_normalize(emitter, type, type && type->kind == IR_TYPE_INTEGER && type->is_signed);
}

static void wasm64_fe_emit_return(Wasm64FunctionEmitter* emitter, IrInstruction* instruction)
{
    bool has_value = instruction->operand_count == 1;
    wasm64_fe_local_get(emitter, emitter->fp_local);
    wasm64_fe_global_set(emitter, emitter->context->stack_global_index);
    if (has_value)
    {
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
    }
    wasm64_fe_u8(emitter, 0x0f); // return
}

static void wasm64_fe_emit_call(Wasm64FunctionEmitter* emitter, IrInstruction* instruction)
{
    if (!instruction->operand_count)
    {
        wasm64_fail(emitter->context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("WebAssembly call has no callee"), emitter->function, 0, instruction,
                    instruction->symbol);
        return;
    }
    IrValue* callee_value = emitter->function->values + instruction->operands[0].value;
    IrType* callee_type = wasm64_type(emitter->context, callee_value->canonical_type);
    bool indirect = callee_type && callee_type->kind == IR_TYPE_POINTER;
    if (indirect)
    {
        wasm64_fail(emitter->context, WASM64_ERROR_INDIRECT_CALL, wasm64_s8("indirect calls are unsupported by WebAssembly"), emitter->function, 0,
                    instruction, instruction->symbol);
        return;
    }
    Wasm64FunctionRecord* record = wasm64_function_record_for_symbol(emitter->context, instruction->symbol);
    if (!record)
    {
        wasm64_fail(emitter->context, WASM64_ERROR_UNRESOLVED_SYMBOL, wasm64_s8("unresolved direct WebAssembly call"), emitter->function, 0, instruction,
                    instruction->symbol);
        return;
    }
    // Wasm types every call by the callee's own declared signature, so a call
    // that carries a signature of its own cannot be encoded: that is what a
    // pre-C23 `()` declaration produces, since it names no parameters and each
    // call site supplies them (see IrType.is_unprototyped).
    if (instruction->operand_count - 1 != record->signature.param_count)
    {
        wasm64_fail(emitter->context, WASM64_ERROR_VARIADIC,
                    wasm64_s8("a call whose arguments the callee's declaration does not describe is unsupported by Wasm64"), emitter->function, 0,
                    instruction, instruction->symbol);
        return;
    }
    for (u32 argument_index = 1; argument_index < instruction->operand_count; argument_index += 1)
    {
        wasm64_fe_emit_value(emitter, instruction->operands[argument_index]);
    }
    wasm64_fe_u8(emitter, 0x10);
    wasm64_fe_u32(emitter, record->function_index);
    if (instruction->result.value != IR_ID_UNDERLYING_INVALID)
    {
        wasm64_fe_local_set(emitter, emitter->value_locals[instruction->result.value]);
    }
}

static void wasm64_fe_emit_switch(Wasm64FunctionEmitter* emitter, IrBlock* predecessor, IrInstruction* instruction)
{
    IrType* switched_type = wasm64_fe_value_ir_type(emitter, instruction->operands[0]);
    Wasm64ValType valtype = 0;
    wasm64_valtype_for_type(emitter->context, switched_type, false, &valtype);
    for (u32 case_index = 0; case_index < instruction->immediate_count; case_index += 1)
    {
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        if (valtype == WASM64_VALTYPE_I64)
        {
            wasm64_fe_i64_const(emitter, (s64)instruction->immediates[case_index]);
            wasm64_fe_u8(emitter, 0x51); // i64.eq
        }
        else
        {
            wasm64_fe_i32_const(emitter, (s32)(u32)instruction->immediates[case_index]);
            wasm64_fe_u8(emitter, 0x46); // i32.eq
        }
        wasm64_fe_u8(emitter, 0x04); // if
        wasm64_fe_u8(emitter, 0x40); // empty block type
        IrBlock* target = wasm64_fe_block(emitter, instruction->targets[case_index]);
        if (target)
        {
            wasm64_fe_emit_parallel_copy(emitter, predecessor, target);
            wasm64_fe_i32_const(emitter, (s32)target->id.value);
            wasm64_fe_local_set(emitter, emitter->pc_local);
            wasm64_fe_u8(emitter, 0x0c); // br to dispatch loop (if + loop)
            wasm64_fe_u32(emitter, 2);
        }
        wasm64_fe_u8(emitter, 0x0b); // end if
    }
    if (instruction->target_count)
    {
        IrBlock* target = wasm64_fe_block(emitter, instruction->targets[instruction->target_count - 1]);
        if (target)
        {
            wasm64_fe_emit_parallel_copy(emitter, predecessor, target);
            wasm64_fe_i32_const(emitter, (s32)target->id.value);
            wasm64_fe_local_set(emitter, emitter->pc_local);
        }
    }
    wasm64_fe_u8(emitter, 0x0c);
    wasm64_fe_u32(emitter, 1);
}

static void wasm64_fe_emit_instruction(Wasm64FunctionEmitter* emitter, IrBlock* block, IrInstruction* instruction)
{
    Wasm64Context* context = emitter->context;
    IrType* type = wasm64_type(context, instruction->canonical_type);
    if (!type)
    {
        wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("missing canonical WebAssembly instruction type"), emitter->function, block, instruction,
                    IR_SYMBOL_ID_INVALID);
        return;
    }
    switch (instruction->opcode)
    {
    case IR_OPCODE_ARGUMENT:
    {
        if (instruction->immediate_count != 1 || instruction->immediates[0] >= emitter->record->signature.param_count)
        {
            wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("invalid WebAssembly argument index"), emitter->function, block, instruction,
                        IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_local_get(emitter, (u32)instruction->immediates[0]);
        wasm64_fe_local_set(emitter, emitter->value_locals[instruction->result.value]);
    }
    break;
    case IR_OPCODE_LOCAL:
    {
        u32 offset = emitter->value_offsets[instruction->result.value];
        if (offset == UINT32_MAX)
        {
            wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("missing WebAssembly local frame offset"), emitter->function, block, instruction,
                        IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_local_get(emitter, emitter->fp_local);
        wasm64_fe_emit_address_add(emitter, offset);
        wasm64_fe_local_set(emitter, emitter->value_locals[instruction->result.value]);
    }
    break;
    case IR_OPCODE_STACK_ALLOCATE:
        wasm64_fe_emit_stack_allocate(emitter, instruction);
        break;
    case IR_OPCODE_STACK_SAVE:
        wasm64_fe_local_get(emitter, emitter->sp_local);
        wasm64_fe_local_set(emitter, emitter->value_locals[instruction->result.value]);
        break;
    case IR_OPCODE_STACK_RESTORE:
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        wasm64_fe_local_set(emitter, emitter->scratch_local);
        wasm64_fe_local_get(emitter, emitter->scratch_local);
        wasm64_fe_local_get(emitter, emitter->fp_local);
        wasm64_fe_pointer_const(emitter, emitter->frame_size);
        wasm64_fe_pointer_add(emitter);
        wasm64_fe_u8(emitter, wasm64_is_memory64(context) ? 0x54 : 0x49); // never restore into the fixed frame
        wasm64_fe_emit_stack_trap_if(emitter);
        wasm64_fe_emit_stack_bounds_check(emitter, emitter->scratch_local);
        wasm64_fe_local_get(emitter, emitter->scratch_local);
        wasm64_fe_local_tee(emitter, emitter->sp_local);
        wasm64_fe_global_set(emitter, context->stack_global_index);
        break;
    case IR_OPCODE_GLOBAL:
    {
        Wasm64DataRecord* record = wasm64_data_record_for_symbol(context, instruction->symbol);
        if (!record)
        {
            wasm64_fail(context, WASM64_ERROR_UNRESOLVED_SYMBOL, wasm64_s8("unresolved WebAssembly global"), emitter->function, block, instruction,
                        instruction->symbol);
            return;
        }
        wasm64_fe_pointer_const(emitter, record->offset);
        wasm64_fe_local_set(emitter, emitter->value_locals[instruction->result.value]);
    }
    break;
    case IR_OPCODE_LOAD:
    {
        if (wasm64_type_is_local_aggregate(type))
        {
            wasm64_fe_emit_value(emitter, instruction->result);
            wasm64_fe_emit_value(emitter, instruction->operands[0]);
            wasm64_fe_copy_bytes(emitter, type->layout.size);
        }
        else
        {
            wasm64_fe_emit_value(emitter, instruction->operands[0]);
            wasm64_fe_load(emitter, type);
            wasm64_fe_emit_result_set(emitter, instruction, wasm64_type_is_integer(type), type->kind == IR_TYPE_INTEGER && type->is_signed);
        }
    }
    break;
    case IR_OPCODE_STORE:
    {
        IrType* stored_type = wasm64_fe_value_ir_type(emitter, instruction->operands[1]);
        if (wasm64_type_is_local_aggregate(stored_type))
        {
            wasm64_fe_emit_value(emitter, instruction->operands[0]);
            wasm64_fe_emit_value(emitter, instruction->operands[1]);
            wasm64_fe_copy_bytes(emitter, stored_type->layout.size);
            break;
        }
        if (!stored_type || !wasm64_type_is_scalar(stored_type))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("aggregate WebAssembly store is unsupported"), emitter->function, block,
                        instruction, IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        wasm64_fe_emit_value(emitter, instruction->operands[1]);
        wasm64_fe_store(emitter, stored_type);
    }
    break;
    case IR_OPCODE_CONSTANT_INTEGER:
    case IR_OPCODE_ENUM:
        wasm64_fe_emit_integer_constant(emitter, instruction, type);
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
        break;
    case IR_OPCODE_CONSTANT_FLOAT:
        if (type->bit_width == 32)
        {
            wasm64_fe_f32_const(emitter, (u32)instruction->immediates[0]);
        }
        else if (type->bit_width == 64)
        {
            wasm64_fe_f64_const(emitter, instruction->immediates[0]);
        }
        else
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("unsupported WebAssembly float width"), emitter->function, block, instruction,
                        IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
        break;
    case IR_OPCODE_CONSTANT_STRING:
    {
        Wasm64StringRecord* record = wasm64_string_record_find(context, emitter->function, ir_instruction_self_id(emitter->function, instruction));
        if (!record)
        {
            wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("missing WebAssembly string data record"), emitter->function, block, instruction,
                        IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_pointer_const(emitter, record->offset);
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
    }
    break;
    case IR_OPCODE_UNDEFINED:
        if (wasm64_type_is_float(type))
        {
            if (type->bit_width == 32)
            {
                wasm64_fe_f32_const(emitter, 0);
            }
            else
            {
                wasm64_fe_f64_const(emitter, 0);
            }
        }
        else if (type->kind == IR_TYPE_POINTER || type->kind == IR_TYPE_INTEGER || type->kind == IR_TYPE_BOOLEAN || type->kind == IR_TYPE_ENUM)
        {
            Wasm64ValType undefined_type = 0;
            wasm64_valtype_for_type(context, type, false, &undefined_type);
            if (undefined_type == WASM64_VALTYPE_I64)
            {
                wasm64_fe_i64_const(emitter, 0);
            }
            else
            {
                wasm64_fe_i32_const(emitter, 0);
            }
        }
        else
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("aggregate WebAssembly undefined value is unsupported"), emitter->function,
                        block, instruction, IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
        break;
    case IR_OPCODE_FUNCTION:
    {
        Wasm64FunctionRecord* record = wasm64_function_record_for_symbol(context, instruction->symbol);
        if (!record)
        {
            wasm64_fail(context, WASM64_ERROR_UNRESOLVED_SYMBOL, wasm64_s8("unresolved WebAssembly function reference"), emitter->function, block, instruction,
                        instruction->symbol);
            return;
        }
        // Function values cannot be called indirectly; the numeric marker is
        // retained only for diagnostics and for frontends that carry an unused
        // function reference alongside a direct call.
        wasm64_fe_pointer_const(emitter, record->function_index);
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
    }
    break;
    case IR_OPCODE_LENGTH:
    {
        IrValue* operand = emitter->function->values + instruction->operands[0].value;
        IrType* iterable = wasm64_type(context, operand->canonical_type);
        if (!iterable || (iterable->kind != IR_TYPE_ARRAY && iterable->kind != IR_TYPE_VECTOR))
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("dynamic WebAssembly slice/range length is unsupported"), emitter->function,
                        block, instruction, IR_SYMBOL_ID_INVALID);
            return;
        }
        Wasm64ValType length_type = 0;
        wasm64_valtype_for_type(context, type, false, &length_type);
        if (length_type == WASM64_VALTYPE_I64)
        {
            wasm64_fe_i64_const(emitter, (s64)iterable->element_count);
        }
        else
        {
            wasm64_fe_i32_const(emitter, (s32)(u32)iterable->element_count);
        }
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
    }
    break;
    case IR_OPCODE_INDEX:
    {
        IrType* base = wasm64_fe_value_ir_type(emitter, instruction->operands[0]);
        IrType* element = base ? wasm64_type(context, base->element_type) : 0;
        if (!element || !element->layout.resolved)
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("invalid WebAssembly index element type"), emitter->function, block, instruction,
                        IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        wasm64_fe_emit_value(emitter, instruction->operands[1]);
        IrType* index_type = wasm64_fe_value_ir_type(emitter, instruction->operands[1]);
        Wasm64ValType index_valtype = 0;
        wasm64_valtype_for_type(context, index_type, false, &index_valtype);
        if (wasm64_is_memory64(context) && index_valtype == WASM64_VALTYPE_I32)
        {
            wasm64_fe_u8(emitter, 0xad); // i64.extend_i32_u
        }
        else if (!wasm64_is_memory64(context) && index_valtype == WASM64_VALTYPE_I64)
        {
            wasm64_fe_u8(emitter, 0xa7); // i32.wrap_i64
        }
        wasm64_fe_pointer_const(emitter, element->layout.size);
        wasm64_fe_pointer_multiply(emitter);
        wasm64_fe_pointer_add(emitter);
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
    }
    break;
    case IR_OPCODE_FIELD:
    {
        IrType* base = wasm64_fe_value_ir_type(emitter, instruction->operands[0]);
        u64 field_index = instruction->immediate_count ? instruction->immediates[0] : UINT64_MAX;
        if (!base || (base->kind != IR_TYPE_STRUCT && base->kind != IR_TYPE_UNION) || field_index >= base->field_count)
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("invalid WebAssembly field address"), emitter->function, block, instruction,
                        IR_SYMBOL_ID_INVALID);
            return;
        }
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        wasm64_fe_emit_address_add(emitter, base->fields[field_index].offset);
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
    }
    break;
    case IR_OPCODE_ADDRESS_OF:
    case IR_OPCODE_DEREFERENCE:
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
        break;
    case IR_OPCODE_CAST:
        wasm64_fe_emit_cast(emitter, instruction, wasm64_fe_value_ir_type(emitter, instruction->operands[0]), type);
        wasm64_fe_emit_result_set(emitter, instruction, false, false);
        break;
    case IR_OPCODE_UNARY:
    {
        IrType* operand_type = wasm64_fe_value_ir_type(emitter, instruction->operands[0]);
        if (instruction->unary_operation == IR_UNARY_INTEGER_NEGATE || instruction->unary_operation == IR_UNARY_INTEGER_BITWISE_NOT ||
            instruction->unary_operation == IR_UNARY_INTEGER_COUNT_LEADING_ZEROS || instruction->unary_operation == IR_UNARY_INTEGER_COUNT_TRAILING_ZEROS ||
            instruction->unary_operation == IR_UNARY_INTEGER_POPULATION_COUNT)
        {
            wasm64_fe_emit_integer_value(emitter, instruction->operands[0], operand_type && operand_type->kind == IR_TYPE_INTEGER && operand_type->is_signed);
            if (instruction->unary_operation == IR_UNARY_INTEGER_NEGATE)
            {
                if (wasm64_integer_bits(type) > 32)
                {
                    wasm64_fe_i64_const(emitter, -1);
                    wasm64_fe_u8(emitter, 0x7e); // i64.mul
                }
                else
                {
                    wasm64_fe_i32_const(emitter, -1);
                    wasm64_fe_u8(emitter, 0x6c); // i32.mul
                }
            }
            else if (instruction->unary_operation == IR_UNARY_INTEGER_BITWISE_NOT)
            {
                if (wasm64_integer_bits(type) > 32)
                {
                    wasm64_fe_i64_const(emitter, -1);
                }
                else
                {
                    wasm64_fe_i32_const(emitter, -1);
                }
                wasm64_fe_emit_binary_opcode(emitter, IR_BINARY_INTEGER_BITWISE_XOR, type);
            }
            else
            {
                wasm64_fe_emit_unary_opcode(emitter, instruction->unary_operation, type);
            }
            wasm64_fe_emit_result_set(emitter, instruction, true, type->kind == IR_TYPE_INTEGER && type->is_signed);
        }
        else if (instruction->unary_operation == IR_UNARY_FLOAT_NEGATE)
        {
            // f32/f64 neg have opcodes 0x8c/0x9a; a zero subtraction is
            // equivalent and keeps the opcode table compact.
            wasm64_fe_emit_value(emitter, instruction->operands[0]);
            if (type->bit_width == 32)
            {
                wasm64_fe_u8(emitter, 0x8c);
            }
            else
            {
                wasm64_fe_u8(emitter, 0x9a);
            }
            wasm64_fe_emit_result_set(emitter, instruction, false, false);
        }
        else if (instruction->unary_operation == IR_UNARY_BOOLEAN_NOT)
        {
            wasm64_fe_emit_value(emitter, instruction->operands[0]);
            wasm64_fe_u8(emitter, 0x45);
            wasm64_fe_emit_result_set(emitter, instruction, false, false);
        }
        else
        {
            wasm64_fail(context, WASM64_ERROR_SIMD, wasm64_s8("vector/SIMD unary operation is unsupported by WebAssembly"), emitter->function, block,
                        instruction, IR_SYMBOL_ID_INVALID);
        }
    }
    break;
    case IR_OPCODE_BINARY:
    {
        IrType* operand_type = wasm64_fe_value_ir_type(emitter, instruction->operands[0]);
        IrBinaryOperation operation = instruction->binary_operation;
        bool integer = wasm64_type_is_integer(operand_type) || (operand_type && operand_type->kind == IR_TYPE_POINTER);
        bool signed_value = operand_type && operand_type->kind == IR_TYPE_INTEGER && operand_type->is_signed;
        if (operation == IR_BINARY_RANGE)
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("range aggregate is unsupported by WebAssembly"), emitter->function, block,
                        instruction, IR_SYMBOL_ID_INVALID);
            return;
        }
        if (integer)
        {
            wasm64_fe_emit_integer_value(emitter, instruction->operands[0], signed_value);
            wasm64_fe_emit_integer_value(emitter, instruction->operands[1], signed_value);
        }
        else
        {
            wasm64_fe_emit_value(emitter, instruction->operands[0]);
            wasm64_fe_emit_value(emitter, instruction->operands[1]);
        }
        wasm64_fe_emit_binary_opcode(emitter, operation, operand_type);
        wasm64_fe_emit_result_set(emitter, instruction, integer && operation <= IR_BINARY_INTEGER_BITWISE_XOR,
                                  signed_value && (operation == IR_BINARY_INTEGER_ADD || operation == IR_BINARY_INTEGER_SUBTRACT || operation == IR_BINARY_INTEGER_MULTIPLY ||
                                                   operation == IR_BINARY_SIGNED_DIVIDE || operation == IR_BINARY_SIGNED_REMAINDER || operation == IR_BINARY_SIGNED_SHIFT_RIGHT));
    }
    break;
    case IR_OPCODE_CALL:
        wasm64_fe_emit_call(emitter, instruction);
        break;
    case IR_OPCODE_BRANCH:
    {
        IrBlock* target = wasm64_fe_block(emitter, instruction->targets[0]);
        if (target)
        {
            wasm64_fe_emit_parallel_copy(emitter, block, target);
            wasm64_fe_i32_const(emitter, (s32)target->id.value);
            wasm64_fe_local_set(emitter, emitter->pc_local);
        }
        wasm64_fe_u8(emitter, 0x0c);
        wasm64_fe_u32(emitter, 1);
    }
    break;
    case IR_OPCODE_BRANCH_IF:
    {
        wasm64_fe_emit_value(emitter, instruction->operands[0]);
        wasm64_fe_u8(emitter, 0x04);
        wasm64_fe_u8(emitter, 0x40);
        IrBlock* true_target = wasm64_fe_block(emitter, instruction->targets[0]);
        if (true_target)
        {
            wasm64_fe_emit_parallel_copy(emitter, block, true_target);
            wasm64_fe_i32_const(emitter, (s32)true_target->id.value);
            wasm64_fe_local_set(emitter, emitter->pc_local);
        }
        wasm64_fe_u8(emitter, 0x05); // else
        IrBlock* false_target = wasm64_fe_block(emitter, instruction->targets[1]);
        if (false_target)
        {
            wasm64_fe_emit_parallel_copy(emitter, block, false_target);
            wasm64_fe_i32_const(emitter, (s32)false_target->id.value);
            wasm64_fe_local_set(emitter, emitter->pc_local);
        }
        wasm64_fe_u8(emitter, 0x0b); // end if
        wasm64_fe_u8(emitter, 0x0c);
        wasm64_fe_u32(emitter, 1);
    }
    break;
    case IR_OPCODE_SWITCH:
        wasm64_fe_emit_switch(emitter, block, instruction);
        break;
    case IR_OPCODE_RETURN:
        wasm64_fe_emit_return(emitter, instruction);
        break;
    case IR_OPCODE_UNREACHABLE:
        wasm64_fe_u8(emitter, 0x00);
        break;
    case IR_OPCODE_DEBUG_TRAP:
        wasm64_fe_u8(emitter, 0x00);
        break;
    case IR_OPCODE_REVERSE:
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI, wasm64_s8("aggregate reverse is unsupported by WebAssembly"), emitter->function, block,
                    instruction, IR_SYMBOL_ID_INVALID);
        break;
    case IR_OPCODE_ARRAY:
    case IR_OPCODE_AGGREGATE:
        wasm64_fe_emit_aggregate(emitter, block, instruction, type);
        break;
    case IR_OPCODE_SLICE:
    case IR_OPCODE_VA_START:
    case IR_OPCODE_VA_COPY:
    case IR_OPCODE_VA_END:
    case IR_OPCODE_VA_ARG:
        wasm64_fail(context, instruction->opcode >= IR_OPCODE_VA_START && instruction->opcode <= IR_OPCODE_VA_ARG ? WASM64_ERROR_VARIADIC
                                                                                                                     : WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI,
                    wasm64_s8("aggregate or variadic WebAssembly operation is unsupported"), emitter->function, block, instruction, IR_SYMBOL_ID_INVALID);
        break;
    case IR_OPCODE_ATOMIC_LOAD:
    case IR_OPCODE_ATOMIC_STORE:
    case IR_OPCODE_ATOMIC_READ_MODIFY_WRITE:
    case IR_OPCODE_ATOMIC_COMPARE_EXCHANGE:
    case IR_OPCODE_ATOMIC_FENCE:
        wasm64_fail(context, WASM64_ERROR_ATOMIC, wasm64_s8("atomic operations are unsupported by WebAssembly"), emitter->function, block, instruction,
                    IR_SYMBOL_ID_INVALID);
        break;
    case IR_OPCODE_SIMD:
        wasm64_fail(context, WASM64_ERROR_SIMD, wasm64_s8("exact SIMD intrinsics are unsupported by Wasm64; select an explicit source fallback"), emitter->function, block, instruction,
                    IR_SYMBOL_ID_INVALID);
        break;
    case IR_OPCODE_INLINE_ASSEMBLY:
        wasm64_fail(context, WASM64_ERROR_INLINE_ASSEMBLY, wasm64_s8("inline assembly is unsupported by WebAssembly"), emitter->function, block, instruction,
                    IR_SYMBOL_ID_INVALID);
        break;
    case IR_OPCODE_LABEL_ADDRESS:
    case IR_OPCODE_INDIRECT_BRANCH:
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("label control flow is unsupported by WebAssembly"), emitter->function, block,
                    instruction, IR_SYMBOL_ID_INVALID);
        break;
    case IR_OPCODE_CLEAR_INSTRUCTION_CACHE:
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("instruction-cache operations are unsupported by WebAssembly"), emitter->function,
                    block, instruction, IR_SYMBOL_ID_INVALID);
        break;
    case IR_OPCODE_COUNT:
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_INSTRUCTION, wasm64_s8("invalid WebAssembly opcode"), emitter->function, block, instruction,
                    IR_SYMBOL_ID_INVALID);
        break;
    }
}

static void wasm64_fe_call_index(Wasm64FunctionEmitter* emitter, u32 function_index)
{
    wasm64_fe_u8(emitter, 0x10);
    wasm64_fe_u32(emitter, function_index);
}

static void wasm64_fe_i32_load(Wasm64FunctionEmitter* emitter, u64 offset)
{
    wasm64_fe_u8(emitter, 0x28);
    wasm64_fe_emit_memarg(emitter, 2, offset);
}

static void wasm64_fe_i32_store(Wasm64FunctionEmitter* emitter, u64 offset)
{
    wasm64_fe_u8(emitter, 0x36);
    wasm64_fe_emit_memarg(emitter, 2, offset);
}

static void wasm64_fe_emit_wasi_checked_call(Wasm64FunctionEmitter* emitter, u32 function_index, u32 status_local)
{
    wasm64_fe_call_index(emitter, function_index);
    wasm64_fe_local_tee(emitter, status_local);
    wasm64_fe_u8(emitter, 0x04); // if status != 0
    wasm64_fe_u8(emitter, 0x40);
    wasm64_fe_local_get(emitter, status_local);
    wasm64_fe_call_index(emitter, emitter->context->wasi_proc_exit_function_index);
    wasm64_fe_u8(emitter, 0x00); // proc_exit must not return
    wasm64_fe_u8(emitter, 0x0b);
}

// Consume an i32 condition and terminate the command before arithmetic can
// wrap an address or a pointer-table byte count supplied by the host.
static void wasm64_fe_emit_wasi_abort_if(Wasm64FunctionEmitter* emitter)
{
    wasm64_fe_u8(emitter, 0x04); // if
    wasm64_fe_u8(emitter, 0x40);
    wasm64_fe_i32_const(emitter, 1);
    wasm64_fe_call_index(emitter, emitter->context->wasi_proc_exit_function_index);
    wasm64_fe_u8(emitter, 0x00); // proc_exit must not return
    wasm64_fe_u8(emitter, 0x0b);
}

static bool wasm64_fe_emit_wasi_start(Wasm64Context* context, Wasm64FunctionRecord* record)
{
    enum
    {
        WASI_LOCAL_BASE,
        WASI_LOCAL_ARGC,
        WASI_LOCAL_ARGV_BYTES,
        WASI_LOCAL_ENVC,
        WASI_LOCAL_ENV_BYTES,
        WASI_LOCAL_CURSOR,
        WASI_LOCAL_ARGV,
        WASI_LOCAL_ARGV_BUFFER,
        WASI_LOCAL_ENVP,
        WASI_LOCAL_ENV_BUFFER,
        WASI_LOCAL_STATUS,
        WASI_LOCAL_REQUIRED_PAGES,
        WASI_LOCAL_CURRENT_PAGES,
        WASI_LOCAL_COUNT,
    };

    bool valid = !wasm64_is_memory64(context) && context->options.environment == WASM_ENVIRONMENT_WASI_PREVIEW1 &&
                 context->wasi_main_function_index != UINT32_MAX && context->wasi_proc_exit_function_index != UINT32_MAX;
    if (!valid)
    {
        wasm64_fail(context, WASM64_ERROR_ENCODING, wasm64_s8("invalid WASI command adapter state"), 0, 0, 0, IR_SYMBOL_ID_INVALID);
    }
    if (valid)
    {
        Wasm64FunctionEmitter emitter = {.context = context, .record = record};
        wasm64_buffer_init(&emitter.body, context->arena);

        // All Preview 1 command ABI values are wasm32 addresses or 32-bit sizes.
        wasm64_buffer_u32_leb(&emitter.body, 1);
        wasm64_buffer_u32_leb(&emitter.body, WASI_LOCAL_COUNT);
        wasm64_buffer_u8(&emitter.body, WASM64_VALTYPE_I32);

        wasm64_fe_global_get(&emitter, context->stack_global_index);
        wasm64_fe_local_set(&emitter, WASI_LOCAL_BASE);

        if (context->wasi_main_parameter_count)
        {
            // args_sizes_get(&argc, &argv_buffer_size)
            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_i32_const(&emitter, 4);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_emit_wasi_checked_call(&emitter, context->wasi_args_sizes_get_function_index, WASI_LOCAL_STATUS);

            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_i32_load(&emitter, 0);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ARGC);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_i32_load(&emitter, 4);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ARGV_BYTES);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGC);
            wasm64_fe_i32_const(&emitter, (s32)(UINT32_MAX / 4 - 1));
            wasm64_fe_u8(&emitter, 0x4b); // i32.gt_u: (argc + 1) * 4 would wrap
            wasm64_fe_emit_wasi_abort_if(&emitter);
        }

        if (context->wasi_main_parameter_count == 3)
        {
            // environ_sizes_get(&envc, &environment_buffer_size)
            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_i32_const(&emitter, 8);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_i32_const(&emitter, 12);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_emit_wasi_checked_call(&emitter, context->wasi_environ_sizes_get_function_index, WASI_LOCAL_STATUS);

            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_i32_load(&emitter, 8);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ENVC);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
            wasm64_fe_i32_load(&emitter, 12);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ENV_BYTES);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENVC);
            wasm64_fe_i32_const(&emitter, (s32)(UINT32_MAX / 4 - 1));
            wasm64_fe_u8(&emitter, 0x4b); // i32.gt_u: (envc + 1) * 4 would wrap
            wasm64_fe_emit_wasi_abort_if(&emitter);
        }

        // The four size fields occupy the first 16 bytes. argv follows, including
        // its conventional null sentinel, then the packed argument strings.
        wasm64_fe_local_get(&emitter, WASI_LOCAL_BASE);
        wasm64_fe_i32_const(&emitter, 16);
        wasm64_fe_u8(&emitter, 0x6a); // i32.add
        wasm64_fe_local_set(&emitter, WASI_LOCAL_CURSOR);

        if (context->wasi_main_parameter_count)
        {
            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ARGV);

            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGC);
            wasm64_fe_i32_const(&emitter, 1);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_i32_const(&emitter, 4);
            wasm64_fe_u8(&emitter, 0x6c); // i32.mul
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_local_tee(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ARGV_BUFFER);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGV);
            wasm64_fe_u8(&emitter, 0x49); // i32.lt_u: table address wrapped
            wasm64_fe_emit_wasi_abort_if(&emitter);

            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGV_BYTES);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_local_set(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGV_BUFFER);
            wasm64_fe_u8(&emitter, 0x49); // i32.lt_u: argument bytes wrapped
            wasm64_fe_emit_wasi_abort_if(&emitter);
        }

        if (context->wasi_main_parameter_count == 3)
        {
            // Align the environment pointer table independently of the packed
            // argument bytes that precede it.
            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_i32_const(&emitter, -4);
            wasm64_fe_u8(&emitter, 0x4b); // i32.gt_u: cursor + 3 would wrap
            wasm64_fe_emit_wasi_abort_if(&emitter);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_i32_const(&emitter, 3);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_i32_const(&emitter, -4);
            wasm64_fe_u8(&emitter, 0x71); // i32.and
            wasm64_fe_local_tee(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ENVP);

            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENVC);
            wasm64_fe_i32_const(&emitter, 1);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_i32_const(&emitter, 4);
            wasm64_fe_u8(&emitter, 0x6c); // i32.mul
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_local_tee(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_set(&emitter, WASI_LOCAL_ENV_BUFFER);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENVP);
            wasm64_fe_u8(&emitter, 0x49); // i32.lt_u: table address wrapped
            wasm64_fe_emit_wasi_abort_if(&emitter);

            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENV_BYTES);
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_local_set(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENV_BUFFER);
            wasm64_fe_u8(&emitter, 0x49); // i32.lt_u: environment bytes wrapped
            wasm64_fe_emit_wasi_abort_if(&emitter);
        }

        // Keep the compiler's normal function-frame invariant for main and any
        // callees by publishing a 16-byte-aligned stack pointer above the adapter.
        wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
        wasm64_fe_i32_const(&emitter, -16);
        wasm64_fe_u8(&emitter, 0x4b); // i32.gt_u: cursor + 15 would wrap
        wasm64_fe_emit_wasi_abort_if(&emitter);
        wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
        wasm64_fe_i32_const(&emitter, 15);
        wasm64_fe_u8(&emitter, 0x6a); // i32.add
        wasm64_fe_i32_const(&emitter, -16);
        wasm64_fe_u8(&emitter, 0x71); // i32.and
        wasm64_fe_local_tee(&emitter, WASI_LOCAL_CURSOR);

        wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
        wasm64_fe_i32_const(&emitter, (s32)(UINT32_MAX - WASM64_STACK_SIZE));
        wasm64_fe_u8(&emitter, 0x4b); // i32.gt_u: reserve a representable 64 KiB stack limit
        wasm64_fe_emit_wasi_abort_if(&emitter);

        // The static module minimum only reserves a modest initial stack window.
        // Command arguments and environment strings are host-sized, so grow
        // memory before asking Preview 1 to populate the tables.  Compute
        // ceil(cursor / 64 KiB) without an overflowing cursor + 65535 addition,
        // then retain one complete page for main's upward-growing stack frame.
        wasm64_fe_i32_const(&emitter, 16);
        wasm64_fe_u8(&emitter, 0x76); // i32.shr_u
        wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
        wasm64_fe_i32_const(&emitter, 65535);
        wasm64_fe_u8(&emitter, 0x71); // i32.and
        wasm64_fe_u8(&emitter, 0x45); // i32.eqz
        wasm64_fe_u8(&emitter, 0x45); // non-zero low bits => one extra page
        wasm64_fe_u8(&emitter, 0x6a); // i32.add
        wasm64_fe_i32_const(&emitter, 1);
        wasm64_fe_u8(&emitter, 0x6a); // i32.add: reserve one stack page
        wasm64_fe_local_set(&emitter, WASI_LOCAL_REQUIRED_PAGES);

        wasm64_fe_u8(&emitter, 0x3f); // memory.size
        wasm64_fe_u8(&emitter, 0x00); // memory index 0
        wasm64_fe_local_tee(&emitter, WASI_LOCAL_CURRENT_PAGES);
        wasm64_fe_local_get(&emitter, WASI_LOCAL_REQUIRED_PAGES);
        wasm64_fe_u8(&emitter, 0x49); // current_pages < required_pages (unsigned)
        wasm64_fe_u8(&emitter, 0x04); // if
        wasm64_fe_u8(&emitter, 0x40);
        wasm64_fe_local_get(&emitter, WASI_LOCAL_REQUIRED_PAGES);
        wasm64_fe_local_get(&emitter, WASI_LOCAL_CURRENT_PAGES);
        wasm64_fe_u8(&emitter, 0x6b); // i32.sub
        wasm64_fe_u8(&emitter, 0x40); // memory.grow
        wasm64_fe_u8(&emitter, 0x00); // memory index 0
        wasm64_fe_i32_const(&emitter, -1);
        wasm64_fe_u8(&emitter, 0x46); // i32.eq
        wasm64_fe_u8(&emitter, 0x04); // if growth failed
        wasm64_fe_u8(&emitter, 0x40);
        wasm64_fe_i32_const(&emitter, 1);
        wasm64_fe_call_index(&emitter, context->wasi_proc_exit_function_index);
        wasm64_fe_u8(&emitter, 0x00); // proc_exit must not return
        wasm64_fe_u8(&emitter, 0x0b);
        wasm64_fe_u8(&emitter, 0x0b);

        wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
        wasm64_fe_i32_const(&emitter, WASM64_STACK_SIZE);
        wasm64_fe_u8(&emitter, 0x6a); // i32.add, checked above
        wasm64_fe_global_set(&emitter, context->stack_limit_global_index);
        wasm64_fe_local_get(&emitter, WASI_LOCAL_CURSOR);
        wasm64_fe_global_set(&emitter, context->stack_global_index);

        if (context->wasi_main_parameter_count)
        {
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGV);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGV_BUFFER);
            wasm64_fe_emit_wasi_checked_call(&emitter, context->wasi_args_get_function_index, WASI_LOCAL_STATUS);

            // args_get writes argc entries; C main additionally expects argv[argc]
            // to be null.
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGV);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGC);
            wasm64_fe_i32_const(&emitter, 4);
            wasm64_fe_u8(&emitter, 0x6c); // i32.mul
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_i32_const(&emitter, 0);
            wasm64_fe_i32_store(&emitter, 0);
        }

        if (context->wasi_main_parameter_count == 3)
        {
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENVP);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENV_BUFFER);
            wasm64_fe_emit_wasi_checked_call(&emitter, context->wasi_environ_get_function_index, WASI_LOCAL_STATUS);

            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENVP);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENVC);
            wasm64_fe_i32_const(&emitter, 4);
            wasm64_fe_u8(&emitter, 0x6c); // i32.mul
            wasm64_fe_u8(&emitter, 0x6a); // i32.add
            wasm64_fe_i32_const(&emitter, 0);
            wasm64_fe_i32_store(&emitter, 0);
        }

        if (context->wasi_main_parameter_count)
        {
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGC);
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ARGV);
        }
        if (context->wasi_main_parameter_count == 3)
        {
            wasm64_fe_local_get(&emitter, WASI_LOCAL_ENVP);
        }
        wasm64_fe_call_index(&emitter, context->wasi_main_function_index);
        if (!context->wasi_main_has_result)
        {
            wasm64_fe_i32_const(&emitter, 0);
        }
        wasm64_fe_call_index(&emitter, context->wasi_proc_exit_function_index);
        wasm64_fe_u8(&emitter, 0x00); // proc_exit must not return
        wasm64_fe_u8(&emitter, 0x0b); // end function body

        wasm64_buffer_u32_leb(&context->code_payload, (u32)emitter.body.length);
        wasm64_buffer_bytes(&context->code_payload, emitter.body.data, emitter.body.length);
        context->stats.code_bytes += emitter.body.length;
    }
    return valid && !wasm64_failed(context);
}

static bool wasm64_fe_emit_function(Wasm64Context* context, Wasm64FunctionRecord* record)
{
    Wasm64FunctionEmitter emitter = {0};
    if (!wasm64_fe_initialize(&emitter, context, record))
    {
        return false;
    }
    // Local declarations are grouped by valtype as required by the Wasm
    // binary format.  Parameters are part of the function type and therefore
    // do not appear here; every SSA value and frame/control temporary is an
    // explicit local.
    u32 group_count = 0;
    u32 declared_local_count = emitter.local_count - record->signature.param_count;
    for (u32 index = 0; index < declared_local_count;)
    {
        u8 type = emitter.local_types[index];
        u32 end = index + 1;
        while (end < declared_local_count && emitter.local_types[end] == type)
        {
            end += 1;
        }
        group_count += 1;
        index = end;
    }
    wasm64_buffer_u32_leb(&emitter.body, group_count);
    for (u32 index = 0; index < declared_local_count;)
    {
        u8 type = emitter.local_types[index];
        u32 end = index + 1;
        while (end < declared_local_count && emitter.local_types[end] == type)
        {
            end += 1;
        }
        wasm64_buffer_u32_leb(&emitter.body, end - index);
        wasm64_buffer_u8(&emitter.body, type);
        index = end;
    }

    wasm64_fe_emit_prologue(&emitter);
    wasm64_fe_u8(&emitter, 0x02); // block $exit
    wasm64_fe_u8(&emitter, 0x40);
    wasm64_fe_u8(&emitter, 0x03); // loop $dispatch
    wasm64_fe_u8(&emitter, 0x40);
    for (u32 block_index = 0; block_index < emitter.function->block_count; block_index += 1)
    {
        IrBlock* block = emitter.function->blocks + block_index;
        wasm64_fe_local_get(&emitter, emitter.pc_local);
        wasm64_fe_i32_const(&emitter, (s32)block->id.value);
        wasm64_fe_u8(&emitter, 0x46); // i32.eq
        wasm64_fe_u8(&emitter, 0x04); // if
        wasm64_fe_u8(&emitter, 0x40);
        IrInstructionId instruction_id = block->first_instruction;
        while (instruction_id.value != IR_ID_UNDERLYING_INVALID && !wasm64_failed(context))
        {
            if (instruction_id.value >= emitter.function->instruction_count)
            {
                wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("WebAssembly block instruction out of range"), emitter.function, block, 0,
                            IR_SYMBOL_ID_INVALID);
                break;
            }
            IrInstruction* instruction = emitter.function->instructions + instruction_id.value;
            wasm64_fe_emit_instruction(&emitter, block, instruction);
            instruction_id.value = instruction_id.value == block->last_instruction.value ? IR_ID_UNDERLYING_INVALID : instruction_id.value + 1;
        }
        wasm64_fe_u8(&emitter, 0x0b); // end if
    }
    wasm64_fe_u8(&emitter, 0x0c); // no matching block: leave dispatcher
    wasm64_fe_u32(&emitter, 1);
    wasm64_fe_u8(&emitter, 0x0b); // end loop
    wasm64_fe_u8(&emitter, 0x0b); // end block
    // Every valid source return emits an explicit Wasm `return`.  Mark the
    // dispatcher fallthrough unreachable so result-producing functions also
    // validate when the structured block itself has the empty block type.
    wasm64_fe_u8(&emitter, 0x00); // unreachable
    wasm64_fe_u8(&emitter, 0x0b); // end function body

    wasm64_buffer_u32_leb(&context->code_payload, (u32)emitter.body.length);
    wasm64_buffer_bytes(&context->code_payload, emitter.body.data, emitter.body.length);
    context->stats.code_bytes += emitter.body.length;
    return !wasm64_failed(context);
}

static bool wasm64_build_code_payload(Wasm64Context* context)
{
    wasm64_buffer_u32_leb(&context->code_payload, context->stats.defined_function_count);
    for (u32 index = 0; index < context->function_count; index += 1)
    {
        Wasm64FunctionRecord* record = context->functions + index;
        if (record->imported)
        {
            continue;
        }
        bool emitted = record->synthetic == WASM64_SYNTHETIC_FUNCTION_WASI_START ? wasm64_fe_emit_wasi_start(context, record)
                                                                                 : wasm64_fe_emit_function(context, record);
        if (!emitted)
        {
            return false;
        }
    }
    return true;
}

static bool wasm64_build_data_payload(Wasm64Context* context)
{
    u32 segment_count = 0;
    for (u32 index = 0; index < context->data_count; index += 1)
    {
        if (context->data_records[index].has_bytes)
        {
            segment_count += 1;
        }
    }
    for (u32 index = 0; index < context->string_count; index += 1)
    {
        segment_count += 1;
    }
    wasm64_buffer_u32_leb(&context->data_payload, segment_count);
    for (u32 index = 0; index < context->data_count; index += 1)
    {
        Wasm64DataRecord* record = context->data_records + index;
        if (!record->has_bytes)
        {
            continue;
        }
        wasm64_buffer_u32_leb(&context->data_payload, 0); // active, memory 0 implicit
        if (wasm64_is_memory64(context))
        {
            wasm64_buffer_u8(&context->data_payload, 0x42);
            wasm64_buffer_s64_leb(&context->data_payload, (s64)record->offset);
        }
        else
        {
            wasm64_buffer_u8(&context->data_payload, 0x41);
            wasm64_buffer_s32_leb(&context->data_payload, (s32)(u32)record->offset);
        }
        wasm64_buffer_u8(&context->data_payload, 0x0b);
        wasm64_buffer_u32_leb(&context->data_payload, (u32)record->size);
        wasm64_buffer_bytes(&context->data_payload, record->bytes, record->size);
    }
    for (u32 index = 0; index < context->string_count; index += 1)
    {
        Wasm64StringRecord* record = context->strings + index;
        wasm64_buffer_u32_leb(&context->data_payload, 0);
        if (wasm64_is_memory64(context))
        {
            wasm64_buffer_u8(&context->data_payload, 0x42);
            wasm64_buffer_s64_leb(&context->data_payload, (s64)record->offset);
        }
        else
        {
            wasm64_buffer_u8(&context->data_payload, 0x41);
            wasm64_buffer_s32_leb(&context->data_payload, (s32)(u32)record->offset);
        }
        wasm64_buffer_u8(&context->data_payload, 0x0b);
        wasm64_buffer_u32_leb(&context->data_payload, (u32)(record->literal.length + 1));
        wasm64_buffer_bytes(&context->data_payload, (u8*)record->literal.pointer, record->literal.length);
        wasm64_buffer_u8(&context->data_payload, 0);
    }
    context->stats.data_segment_count = segment_count;
    return true;
}

static void wasm64_append_section(Wasm64Buffer* output, u8 id, Wasm64Buffer* payload)
{
    if (!payload->length)
    {
        return;
    }
    wasm64_buffer_u8(output, id);
    wasm64_buffer_u32_leb(output, (u32)payload->length);
    wasm64_buffer_bytes(output, payload->data, payload->length);
}

static bool wasm64_build_module(Wasm64Context* context, ByteSlice* output)
{
    Wasm64Buffer result = {0};
    wasm64_buffer_init(&result, context->arena);
    wasm64_buffer_u8(&result, 0x00);
    wasm64_buffer_u8(&result, 0x61);
    wasm64_buffer_u8(&result, 0x73);
    wasm64_buffer_u8(&result, 0x6d);
    wasm64_buffer_u8(&result, 0x01);
    wasm64_buffer_u8(&result, 0x00);
    wasm64_buffer_u8(&result, 0x00);
    wasm64_buffer_u8(&result, 0x00);
    wasm64_append_section(&result, 1, &context->type_payload);
    wasm64_append_section(&result, 2, &context->import_payload);
    wasm64_append_section(&result, 3, &context->function_payload);
    wasm64_append_section(&result, 5, &context->memory_payload);
    wasm64_append_section(&result, 6, &context->global_payload);
    wasm64_append_section(&result, 7, &context->export_payload);
    wasm64_append_section(&result, 10, &context->code_payload);
    wasm64_append_section(&result, 11, &context->data_payload);
    *output = (ByteSlice){.pointer = result.data, .length = result.length};
    context->stats.binary_bytes = result.length;
    return true;
}

static void wasm64_context_initialize(Wasm64Context* context, Arena* arena, IrProgram* program, IrModule* modules, u32 module_count,
                                      Wasm64Options options)
{
    if (!options.pointer_size && program &&
        (program->data_layout.pointer.size == 4 || program->data_layout.pointer.size == 8))
    {
        options.pointer_size = (u8)program->data_layout.pointer.size;
    }
    *context = (Wasm64Context){.arena = arena, .program = program, .modules = modules, .module_count = module_count, .options = options};
    context->error = (Wasm64Error){.code = WASM64_ERROR_NONE,
                                   .function = IR_FUNCTION_ID_INVALID,
                                   .block = IR_BLOCK_ID_INVALID,
                                   .instruction = IR_INSTRUCTION_ID_INVALID,
                                   .symbol = IR_SYMBOL_ID_INVALID,
                                   .opcode = IR_OPCODE_COUNT};
    context->stats = (Wasm64Stats){.memory64 = options.pointer_size == 8,
                                   .wasi_preview1 = options.environment == WASM_ENVIRONMENT_WASI_PREVIEW1,
                                   .deterministic = options.deterministic,
                                   .module_count = module_count};
    context->wasi_main_function_index = UINT32_MAX;
    context->wasi_start_function_index = UINT32_MAX;
    context->wasi_proc_exit_function_index = UINT32_MAX;
    context->wasi_args_sizes_get_function_index = UINT32_MAX;
    context->wasi_args_get_function_index = UINT32_MAX;
    context->wasi_environ_sizes_get_function_index = UINT32_MAX;
    context->wasi_environ_get_function_index = UINT32_MAX;
    context->wasi_main_symbol = IR_SYMBOL_ID_INVALID;
    wasm64_buffer_init(&context->type_payload, arena);
    wasm64_buffer_init(&context->import_payload, arena);
    wasm64_buffer_init(&context->function_payload, arena);
    wasm64_buffer_init(&context->memory_payload, arena);
    wasm64_buffer_init(&context->global_payload, arena);
    wasm64_buffer_init(&context->export_payload, arena);
    wasm64_buffer_init(&context->code_payload, arena);
    wasm64_buffer_init(&context->data_payload, arena);
}

static bool wasm64_validate_inputs(Wasm64Context* context)
{
    if (!context->arena || !context->program || (!context->modules && context->module_count))
    {
        wasm64_fail(context, WASM64_ERROR_INVALID_ARGUMENT, wasm64_s8("invalid WebAssembly emitter input"), 0, 0, 0, IR_SYMBOL_ID_INVALID);
        return false;
    }
    if (context->options.pointer_size != 4 && context->options.pointer_size != 8)
    {
        wasm64_fail(context, WASM64_ERROR_INVALID_ARGUMENT, wasm64_s8("WebAssembly pointer size must be 4 or 8 bytes"), 0, 0, 0,
                    IR_SYMBOL_ID_INVALID);
        return false;
    }
    if (context->options.environment >= WASM_ENVIRONMENT_COUNT)
    {
        wasm64_fail(context, WASM64_ERROR_INVALID_ARGUMENT, wasm64_s8("invalid WebAssembly execution environment"), 0, 0, 0,
                    IR_SYMBOL_ID_INVALID);
        return false;
    }
    if (context->options.environment == WASM_ENVIRONMENT_WASI_PREVIEW1)
    {
        String8 memory_name = context->options.memory_export_name.length ? context->options.memory_export_name : wasm64_s8("memory");
        if (context->options.pointer_size != 4)
        {
            wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE, wasm64_s8("WASI Preview 1 currently requires wasm32"), 0, 0, 0,
                        IR_SYMBOL_ID_INVALID);
            return false;
        }
        if (!context->options.export_memory || !wasm64_string_equal(memory_name, wasm64_s8("memory")))
        {
            wasm64_fail(context, WASM64_ERROR_INVALID_ARGUMENT,
                        wasm64_s8("WASI Preview 1 requires the default exported memory named 'memory'"), 0, 0, 0, IR_SYMBOL_ID_INVALID);
            return false;
        }
    }
    if (context->program->data_layout.pointer.size &&
        context->program->data_layout.pointer.size != context->options.pointer_size)
    {
        wasm64_fail(context, WASM64_ERROR_UNSUPPORTED_TYPE,
                    wasm64_s8("WebAssembly emitter pointer width does not match the canonical IR data layout"), 0, 0, 0,
                    IR_SYMBOL_ID_INVALID);
        return false;
    }
    for (u32 module_index = 0; module_index < context->module_count; module_index += 1)
    {
        IrModule* module = context->modules + module_index;
        IrValidationResult validation = ir_prepare_canonical_module(context->program, module, false);
        if (validation.error != IR_VALIDATION_NONE)
        {
            IrFunction* function = validation.function.value < module->function_count ? module->functions + validation.function.value : 0;
            IrBlock* block = function && validation.block.value < function->block_count ? function->blocks + validation.block.value : 0;
            IrInstruction* instruction = function && validation.instruction.value < function->instruction_count
                                             ? function->instructions + validation.instruction.value
                                             : 0;
            wasm64_fail(context, WASM64_ERROR_IR_VALIDATION, wasm64_s8("canonical IR validation failed before WebAssembly emission"), function,
                        block, instruction, IR_SYMBOL_ID_INVALID);
            return false;
        }
    }
    return true;
}

static WasmArtifact wasm_emit_internal(Arena* arena, IrProgram* program, IrModule* modules, u32 module_count, WasmOptions options)
{
    Wasm64Context context = {0};
    wasm64_context_initialize(&context, arena, program, modules, module_count, options);
    ByteSlice bytes = {0};
    bool valid = wasm64_validate_inputs(&context);
    if (valid)
    {
        valid = wasm64_collect_functions(&context);
    }
    if (valid)
    {
        valid = wasm64_collect_data(&context);
    }
    if (valid)
    {
        valid = wasm64_apply_data_relocations(&context);
    }
    if (valid)
    {
        valid = wasm64_build_type_payload(&context) && wasm64_build_import_payload(&context) && wasm64_build_function_payload(&context) &&
                wasm64_build_memory_payload(&context) && wasm64_build_global_payload(&context) && wasm64_build_export_payload(&context) &&
                wasm64_build_code_payload(&context) && wasm64_build_data_payload(&context);
    }
    if (valid && !wasm64_failed(&context))
    {
        valid = wasm64_build_module(&context, &bytes);
    }
    if (!valid && context.error.code == WASM64_ERROR_NONE)
    {
        wasm64_fail(&context, WASM64_ERROR_ENCODING, wasm64_s8("WebAssembly module encoding failed"), 0, 0, 0, IR_SYMBOL_ID_INVALID);
    }
    WasmArtifact artifact = {
        .bytes = valid && !wasm64_failed(&context) ? bytes : (ByteSlice){0},
        .wasm = valid && !wasm64_failed(&context) ? bytes : (ByteSlice){0},
        .binary = valid && !wasm64_failed(&context) ? bytes : (ByteSlice){0},
        .error = context.error,
        .stats = context.stats,
        .success = valid && !wasm64_failed(&context),
    };
    return artifact;
}

WasmArtifact wasm_emit(Arena* arena, IrProgram* program, IrModule* modules, u32 module_count, WasmOptions options)
{
    return wasm_emit_internal(arena, program, modules, module_count, options);
}

WasmArtifact wasm_emit_program(Arena* arena, IrProgram* program, WasmOptions options)
{
    return program ? wasm_emit_internal(arena, program, program->modules, program->module_count, options)
                   : wasm_emit_internal(arena, 0, 0, 0, options);
}

bool wasm_artifact_is_valid(WasmArtifact artifact)
{
    return artifact.success && artifact.error.code == WASM64_ERROR_NONE && artifact.bytes.pointer && artifact.bytes.length >= 8;
}

String8 wasm_error_code_name(WasmErrorCode code)
{
    return wasm64_error_code_name(code);
}

Wasm64Artifact wasm64_emit_with_options(Arena* arena, IrProgram* program, IrModule* modules, u32 module_count, Wasm64Options options)
{
    // Preserve the original API contract even for callers that zero-initialize
    // an options structure compiled against the former Memory64-only header.
    options.environment = WASM_ENVIRONMENT_FREESTANDING;
    options.pointer_size = 8;
    options.synthesize_start = false;
    return wasm_emit_internal(arena, program, modules, module_count, options);
}

Wasm64Artifact wasm64_emit(Arena* arena, IrProgram* program, IrModule* modules, u32 module_count)
{
    Wasm64Options options = WASM64_OPTIONS_DEFAULT;
    return wasm64_emit_with_options(arena, program, modules, module_count, options);
}

Wasm64Artifact wasm64_emit_program(Arena* arena, IrProgram* program)
{
    if (!program)
    {
        Wasm64Options options = WASM64_OPTIONS_DEFAULT;
        return wasm64_emit_with_options(arena, 0, 0, 0, options);
    }
    return wasm64_emit(arena, program, program->modules, program->module_count);
}

bool wasm64_artifact_is_valid(Wasm64Artifact artifact)
{
    return wasm_artifact_is_valid(artifact);
}

String8 wasm64_error_code_name(Wasm64ErrorCode code)
{
    switch (code)
    {
    case WASM64_ERROR_NONE: return wasm64_s8("none");
    case WASM64_ERROR_INVALID_ARGUMENT: return wasm64_s8("invalid_argument");
    case WASM64_ERROR_IR_VALIDATION: return wasm64_s8("ir_validation");
    case WASM64_ERROR_UNSUPPORTED_TYPE: return wasm64_s8("unsupported_type");
    case WASM64_ERROR_UNSUPPORTED_AGGREGATE_ABI: return wasm64_s8("unsupported_aggregate_abi");
    case WASM64_ERROR_VARIADIC: return wasm64_s8("variadic");
    case WASM64_ERROR_INDIRECT_CALL: return wasm64_s8("indirect_call");
    case WASM64_ERROR_ATOMIC: return wasm64_s8("atomic");
    case WASM64_ERROR_SIMD: return wasm64_s8("simd");
    case WASM64_ERROR_INLINE_ASSEMBLY: return wasm64_s8("inline_assembly");
    case WASM64_ERROR_TLS: return wasm64_s8("tls");
    case WASM64_ERROR_UNSUPPORTED_INSTRUCTION: return wasm64_s8("unsupported_instruction");
    case WASM64_ERROR_UNRESOLVED_SYMBOL: return wasm64_s8("unresolved_symbol");
    case WASM64_ERROR_DUPLICATE_SYMBOL: return wasm64_s8("duplicate_symbol");
    case WASM64_ERROR_ENCODING: return wasm64_s8("encoding");
    case WASM64_ERROR_COUNT: break;
    }
    return wasm64_s8("unknown");
}
