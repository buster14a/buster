#include <buster/tests/compiler/object/object_test.h>
#include <buster/lib/compiler/assembly/aarch64_encoding.h>
#include <buster/lib/compiler/object/object_internal.h>
#include <buster/lib/compiler/pdb/pdb.h>
#include <buster/lib/time.h>
#include <buster/lib/file.h>
#if BUSTER_INCLUDE_TESTS

BUSTER_GLOBAL_LOCAL bool object_bytes_contain(ByteSlice bytes, String8 value)
{
    if (value.length <= bytes.length)
    {
        for (u64 index = 0; index + value.length <= bytes.length; index += 1)
        {
            if (memcmp(bytes.pointer + index, value.pointer, value.length) == 0)
            {
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool object_test_eh_frame_record_start(ByteSlice bytes, u64 field_offset, u64* record_start)
{
    if (!record_start || (bytes.length && !bytes.pointer) || field_offset > bytes.length || sizeof(u32) > bytes.length - field_offset)
    {
        return false;
    }
    u64 offset = 0;
    while (offset < bytes.length)
    {
        u64 remaining = bytes.length - offset;
        if (remaining < sizeof(u32))
        {
            return false;
        }
        u32 length32 = 0;
        memcpy(&length32, bytes.pointer + offset, sizeof(length32));
        if (!length32)
        {
            return false;
        }
        u64 header_size = sizeof(u32);
        u64 payload_size = length32;
        if (length32 == UINT32_MAX)
        {
            header_size = sizeof(u32) + sizeof(u64);
            if (remaining < header_size)
            {
                return false;
            }
            memcpy(&payload_size, bytes.pointer + offset + sizeof(u32), sizeof(payload_size));
        }
        if (header_size > remaining || payload_size > remaining - header_size)
        {
            return false;
        }
        u64 end = offset + header_size + payload_size;
        if (field_offset >= offset && field_offset < end && sizeof(u32) <= end - field_offset)
        {
            *record_start = offset;
            return true;
        }
        offset = end;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool object_test_mach_compact_section_rewrite(ByteSlice bytes)
{
    u64 section = 32 + 72 + (u64)OBJECT_SECTION_READ_ONLY_DATA * 80;
    u32 magic = 0;
    u32 command = 0;
    if (bytes.length >= 36)
    {
        memcpy(&magic, bytes.pointer, sizeof(magic));
        memcpy(&command, bytes.pointer + 32, sizeof(command));
    }
    bool result;
    if (bytes.length < section + 80 || magic != 0xfeedfacf || command != 0x19)
    {
        result = false;
    }
    else
    {
        memset(bytes.pointer + section, 0, 32);
        memcpy(bytes.pointer + section, "__compact_unwind", sizeof("__compact_unwind") - 1);
        memcpy(bytes.pointer + section + 16, "__LD", sizeof("__LD") - 1);
        u32 flags = 0x020000;
        memcpy(bytes.pointer + section + 64, &flags, sizeof(flags));
        result = true;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL void object_test_write_u16(ByteSlice bytes, u64 offset, u16 value)
{
    if (offset <= bytes.length && sizeof(value) <= bytes.length - offset)
    {
        memcpy(bytes.pointer + offset, &value, sizeof(value));
    }
}

BUSTER_GLOBAL_LOCAL void object_test_write_u32(ByteSlice bytes, u64 offset, u32 value)
{
    if (offset <= bytes.length && sizeof(value) <= bytes.length - offset)
    {
        memcpy(bytes.pointer + offset, &value, sizeof(value));
    }
}

BUSTER_GLOBAL_LOCAL void object_test_write_u64(ByteSlice bytes, u64 offset, u64 value)
{
    if (offset <= bytes.length && sizeof(value) <= bytes.length - offset)
    {
        memcpy(bytes.pointer + offset, &value, sizeof(value));
    }
}

BUSTER_GLOBAL_LOCAL bool object_test_coff_section_characteristics(ByteSlice bytes, u32 section_index, u32* characteristics)
{
    u16 section_count = 0;
    bool result = false;
    if (bytes.pointer && characteristics && bytes.length >= 20)
    {
        memcpy(&section_count, bytes.pointer + 2, sizeof(section_count));
        u64 section = 20 + (u64)section_index * 40;
        if (section_index < section_count && section <= bytes.length && 40 <= bytes.length - section)
        {
            memcpy(characteristics, bytes.pointer + section + 36, sizeof(*characteristics));
            result = true;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool object_test_coff_named_section(ByteSlice bytes, String8 name, u32* raw_offset, u32* relocation_offset,
                                                         u16* relocation_count, u32* characteristics)
{
    u16 section_count = 0;
    if (!bytes.pointer || !raw_offset || !relocation_offset || !relocation_count || name.length > 8 || bytes.length < 20)
    {
        return false;
    }
    memcpy(&section_count, bytes.pointer + 2, sizeof(section_count));
    if ((u64)section_count * 40 > bytes.length - 20)
    {
        return false;
    }
    for (u16 index = 0; index < section_count; index += 1)
    {
        u64 section = 20 + (u64)index * 40;
        if (memcmp(bytes.pointer + section, name.pointer, name.length) == 0 &&
            (name.length == 8 || bytes.pointer[section + name.length] == 0))
        {
            memcpy(raw_offset, bytes.pointer + section + 20, sizeof(*raw_offset));
            memcpy(relocation_offset, bytes.pointer + section + 24, sizeof(*relocation_offset));
            memcpy(relocation_count, bytes.pointer + section + 32, sizeof(*relocation_count));
            if (characteristics)
            {
                memcpy(characteristics, bytes.pointer + section + 36, sizeof(*characteristics));
            }
            return *raw_offset <= bytes.length && *relocation_offset <= bytes.length &&
                   (u64)*relocation_count * 10 <= bytes.length - *relocation_offset;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL u64 object_test_elf_symbol_offset(ByteSlice bytes, u32 symbol_index)
{
    if (bytes.pointer && bytes.length >= 64)
    {
        u64 section_table = 0;
        u16 section_count = 0;
        memcpy(&section_table, bytes.pointer + 40, sizeof(section_table));
        memcpy(&section_count, bytes.pointer + 60, sizeof(section_count));
        if (section_table <= bytes.length && (u64)section_count * 64 <= bytes.length - section_table)
        {
            for (u16 section_index = 0; section_index < section_count; section_index += 1)
            {
                u64 section = section_table + (u64)section_index * 64;
                u32 section_type = 0;
                u64 symbol_offset = 0;
                u64 symbol_size = 0;
                memcpy(&section_type, bytes.pointer + section + 4, sizeof(section_type));
                memcpy(&symbol_offset, bytes.pointer + section + 24, sizeof(symbol_offset));
                memcpy(&symbol_size, bytes.pointer + section + 32, sizeof(symbol_size));
                if (section_type != 2 || symbol_size % 24 || symbol_index >= symbol_size / 24 || symbol_offset > bytes.length ||
                    symbol_size > bytes.length - symbol_offset)
                {
                    continue;
                }
                u64 symbol = symbol_offset + (u64)symbol_index * 24;
                if (symbol > bytes.length || 24 > bytes.length - symbol)
                {
                    return UINT64_MAX;
                }
                return symbol;
            }
        }
    }

    return UINT64_MAX;
}

BUSTER_GLOBAL_LOCAL bool object_test_elf_symbol_type(ByteSlice bytes, String8 name, u8* type)
{
    bool result = false;
    if (bytes.pointer && type && bytes.length >= 64)
    {
        u64 section_table = 0;
        u16 section_count = 0;
        memcpy(&section_table, bytes.pointer + 40, sizeof(section_table));
        memcpy(&section_count, bytes.pointer + 60, sizeof(section_count));
        if (section_table <= bytes.length && (u64)section_count * 64 <= bytes.length - section_table)
        {
            for (u16 section_index = 0; !result && section_index < section_count; section_index += 1)
            {
                u64 section = section_table + (u64)section_index * 64;
                u32 section_type = 0;
                u32 string_section_index = 0;
                u64 symbol_offset = 0;
                u64 symbol_size = 0;
                u64 symbol_entry_size = 0;
                memcpy(&section_type, bytes.pointer + section + 4, sizeof(section_type));
                memcpy(&symbol_offset, bytes.pointer + section + 24, sizeof(symbol_offset));
                memcpy(&symbol_size, bytes.pointer + section + 32, sizeof(symbol_size));
                memcpy(&string_section_index, bytes.pointer + section + 40, sizeof(string_section_index));
                memcpy(&symbol_entry_size, bytes.pointer + section + 56, sizeof(symbol_entry_size));
                if (section_type == 2 && string_section_index < section_count && symbol_entry_size == 24 && symbol_size % 24 == 0 &&
                    symbol_offset <= bytes.length && symbol_size <= bytes.length - symbol_offset)
                {
                    u64 string_section = section_table + (u64)string_section_index * 64;
                    u64 string_offset = 0;
                    u64 string_size = 0;
                    memcpy(&string_offset, bytes.pointer + string_section + 24, sizeof(string_offset));
                    memcpy(&string_size, bytes.pointer + string_section + 32, sizeof(string_size));
                    if (string_offset <= bytes.length && string_size <= bytes.length - string_offset)
                    {
                        for (u64 symbol_index = 0; !result && symbol_index < symbol_size / 24; symbol_index += 1)
                        {
                            u64 symbol = symbol_offset + symbol_index * 24;
                            u32 symbol_name_offset = 0;
                            memcpy(&symbol_name_offset, bytes.pointer + symbol, sizeof(symbol_name_offset));
                            if (symbol_name_offset <= string_size && name.length < string_size - symbol_name_offset &&
                                memcmp(bytes.pointer + string_offset + symbol_name_offset, name.pointer, name.length) == 0 &&
                                bytes.pointer[string_offset + symbol_name_offset + name.length] == 0)
                            {
                                *type = bytes.pointer[symbol + 4] & 0x0f;
                                result = true;
                            }
                        }
                    }
                }
            }
        }
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool object_test_elf_relocation_offsets(ByteSlice bytes, u64* relocation_section, u64* target_data)
{
    if (bytes.pointer && relocation_section && target_data && bytes.length >= 64)
    {
        u64 section_table = 0;
        u16 section_count = 0;
        memcpy(&section_table, bytes.pointer + 40, sizeof(section_table));
        memcpy(&section_count, bytes.pointer + 60, sizeof(section_count));
        if (section_table <= bytes.length && (u64)section_count * 64 <= bytes.length - section_table)
        {
            for (u16 section_index = 0; section_index < section_count; section_index += 1)
            {
                u64 section = section_table + (u64)section_index * 64;
                u32 section_type = 0;
                u32 target_index = 0;
                memcpy(&section_type, bytes.pointer + section + 4, sizeof(section_type));
                memcpy(&target_index, bytes.pointer + section + 44, sizeof(target_index));
                if (section_type != 4 || target_index >= section_count)
                {
                    continue;
                }
                u64 target_section = section_table + (u64)target_index * 64;
                memcpy(target_data, bytes.pointer + target_section + 24, sizeof(*target_data));
                if (*target_data > bytes.length)
                {
                    return false;
                }
                *relocation_section = section;
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL bool object_test_mach_text_offsets(ByteSlice bytes, u32* raw_offset, u32* relocation_offset, u32* relocation_count)
{
    u64 section = 32 + 72;
    u32 magic = 0;
    u32 command = 0;
    if (!bytes.pointer || !raw_offset || !relocation_offset || !relocation_count || bytes.length < section + 80)
    {
        return false;
    }
    memcpy(&magic, bytes.pointer, sizeof(magic));
    memcpy(&command, bytes.pointer + 32, sizeof(command));
    if (magic != UINT32_C(0xfeedfacf) || command != 0x19)
    {
        return false;
    }
    memcpy(raw_offset, bytes.pointer + section + 48, sizeof(*raw_offset));
    memcpy(relocation_offset, bytes.pointer + section + 56, sizeof(*relocation_offset));
    memcpy(relocation_count, bytes.pointer + section + 60, sizeof(*relocation_count));
    return *raw_offset <= bytes.length && *relocation_offset <= bytes.length && (u64)*relocation_count * 8 <= bytes.length - *relocation_offset;
}

BUSTER_GLOBAL_LOCAL bool object_test_mach_section_offsets(ByteSlice bytes, u32 section_index, u32* raw_offset, u32* relocation_offset,
                                                          u32* relocation_count)
{
    u64 section = 32 + 72 + (u64)section_index * 80;
    if (!bytes.pointer || !raw_offset || !relocation_offset || !relocation_count || bytes.length < section + 80)
    {
        return false;
    }
    u32 magic = 0;
    u32 command = 0;
    u32 section_count = 0;
    memcpy(&magic, bytes.pointer, sizeof(magic));
    memcpy(&command, bytes.pointer + 32, sizeof(command));
    memcpy(&section_count, bytes.pointer + 32 + 64, sizeof(section_count));
    if (magic != UINT32_C(0xfeedfacf) || command != 0x19 || section_index >= section_count)
    {
        return false;
    }
    memcpy(raw_offset, bytes.pointer + section + 48, sizeof(*raw_offset));
    memcpy(relocation_offset, bytes.pointer + section + 56, sizeof(*relocation_offset));
    memcpy(relocation_count, bytes.pointer + section + 60, sizeof(*relocation_count));
    return *raw_offset <= bytes.length && *relocation_offset <= bytes.length && (u64)*relocation_count * 8 <= bytes.length - *relocation_offset;
}

BUSTER_GLOBAL_LOCAL u64 object_test_mach_symbol_offset(ByteSlice bytes, u32 symbol_index)
{
    if (bytes.pointer && bytes.length >= 32)
    {
        u32 command_count = 0;
        u32 commands_size = 0;
        memcpy(&command_count, bytes.pointer + 16, sizeof(command_count));
        memcpy(&commands_size, bytes.pointer + 20, sizeof(commands_size));
        u64 command = 32;
        u64 command_end = command + commands_size;
        if (command_end >= command && command_end <= bytes.length)
        {
            for (u32 command_index = 0; command_index < command_count && command < command_end; command_index += 1)
            {
                u32 kind = 0;
                u32 size = 0;
                if (command_end - command < 8)
                {
                    return UINT64_MAX;
                }
                memcpy(&kind, bytes.pointer + command, sizeof(kind));
                memcpy(&size, bytes.pointer + command + 4, sizeof(size));
                if (size < 8 || size > command_end - command)
                {
                    return UINT64_MAX;
                }
                if (kind == 2 && size >= 24)
                {
                    u32 symbol_offset = 0;
                    u32 symbol_count = 0;
                    memcpy(&symbol_offset, bytes.pointer + command + 8, sizeof(symbol_offset));
                    memcpy(&symbol_count, bytes.pointer + command + 12, sizeof(symbol_count));
                    u64 record = symbol_offset + (u64)symbol_index * 16;
                    if (symbol_index < symbol_count && record >= symbol_offset && record <= bytes.length && 16 <= bytes.length - record)
                    {
                        return record;
                    }
                    return UINT64_MAX;
                }
                command += size;
            }
        }
    }

    return UINT64_MAX;
}

BUSTER_GLOBAL_LOCAL ByteSlice object_test_archive(Arena* arena, ByteSlice member, bool bsd_name)
{
    String8 name = S8("member-name.o");
    u64 member_size = member.length + (bsd_name ? name.length : 0);
    u64 total_size = 8 + 60 + member_size + (member_size & 1);
    u8* bytes = arena_allocate(arena, u8, total_size);
    memset(bytes, ' ', total_size);
    memcpy(bytes, "!<arch>\n", 8);
    u8* header = bytes + 8;
    if (bsd_name)
    {
        memcpy(header, "#1/13", 5);
    }
    else
    {
        memcpy(header, "member.o/", 9);
    }
    u64 decimal = member_size;
    for (u32 index = 0; index < 10; index += 1)
    {
        header[57 - index] = (u8)('0' + decimal % 10);
        decimal /= 10;
    }
    header[58] = '`';
    header[59] = '\n';
    u8* payload = header + 60;
    if (bsd_name)
    {
        memcpy(payload, name.pointer, name.length);
        payload += name.length;
    }
    memcpy(payload, member.pointer, member.length);
    if (member_size & 1)
    {
        bytes[68 + member_size] = '\n';
    }
    return (ByteSlice){.pointer = bytes, .length = total_size};
}

BUSTER_GLOBAL_LOCAL void object_test_archive_write_size(u8* header, u64 size)
{
    for (u32 index = 0; index < 10; index += 1)
    {
        header[57 - index] = (u8)('0' + size % 10);
        size /= 10;
    }
}

BUSTER_GLOBAL_LOCAL ByteSlice object_test_archive_long_name(Arena* arena, ByteSlice member)
{
    String8 long_name = S8("long-member-name.o/\n");
    u64 table_size = long_name.length;
    u64 object_size = member.length;
    u64 total_size = 8 + 60 + table_size + (table_size & 1) + 60 + object_size + (object_size & 1);
    u8* bytes = arena_allocate(arena, u8, total_size);
    memset(bytes, ' ', total_size);
    memcpy(bytes, "!<arch>\n", 8);

    u8* table_header = bytes + 8;
    memcpy(table_header, "//", 2);
    object_test_archive_write_size(table_header, table_size);
    table_header[58] = '`';
    table_header[59] = '\n';
    memcpy(table_header + 60, long_name.pointer, long_name.length);
    if (table_size & 1)
    {
        table_header[60 + table_size] = '\n';
    }
    u64 object_header_offset = 8 + 60 + table_size + (table_size & 1);
    u8* object_header = bytes + object_header_offset;
    memcpy(object_header, "/0", 2);
    object_test_archive_write_size(object_header, object_size);
    object_header[58] = '`';
    object_header[59] = '\n';
    memcpy(object_header + 60, member.pointer, member.length);
    if (object_size & 1)
    {
        object_header[60 + object_size] = '\n';
    }
    return (ByteSlice){.pointer = bytes, .length = total_size};
}

BUSTER_GLOBAL_LOCAL ByteSlice object_test_archive_ecsymbols(Arena* arena, ByteSlice member, String8 metadata_name)
{
    u8 metadata[] = {0xe0, 0x01, 0, 0};
    u64 metadata_size = sizeof(metadata);
    u64 total_size = 8 + 60 + metadata_size + (metadata_size & 1) + 60 + member.length + (member.length & 1);
    u8* bytes = arena_allocate(arena, u8, total_size);
    memset(bytes, ' ', total_size);
    memcpy(bytes, "!<arch>\n", 8);
    u8* metadata_header = bytes + 8;
    memcpy(metadata_header, metadata_name.pointer, metadata_name.length);
    object_test_archive_write_size(metadata_header, metadata_size);
    metadata_header[58] = '`';
    metadata_header[59] = '\n';
    memcpy(metadata_header + 60, metadata, metadata_size);
    u8* object_header = metadata_header + 60 + metadata_size + (metadata_size & 1);
    memcpy(object_header, "member.o/", 9);
    object_test_archive_write_size(object_header, member.length);
    object_header[58] = '`';
    object_header[59] = '\n';
    memcpy(object_header + 60, member.pointer, member.length);
    if (member.length & 1)
    {
        object_header[60 + member.length] = '\n';
    }
    return (ByteSlice){.pointer = bytes, .length = total_size};
}


// A COFF object built by hand, because COMDAT is the one input shape
// object_write cannot produce: the writer merges sections by kind, so it has
// no way to give a constant its own IMAGE_SCN_LNK_COMDAT section.  Four
// sections cover the reader's three answers — a plain section, a selectany
// COMDAT, a NODUPLICATES COMDAT, and a COMDAT whose section symbol is missing
// entirely so its selection is never published.
enum
{
    OBJECT_TEST_COFF_HEADER_SIZE = 20,
    OBJECT_TEST_COFF_SECTION_SIZE = 40,
    OBJECT_TEST_COFF_SYMBOL_SIZE = 18,
    OBJECT_TEST_COFF_SECTION_COUNT = 4,
    OBJECT_TEST_COFF_SYMBOL_COUNT = 8,
    OBJECT_TEST_COFF_SECTION_DATA = 4,
    OBJECT_TEST_COFF_SECTION_LINK_NRELOC_OVFL = 0x01000000,
};

BUSTER_GLOBAL_LOCAL void object_test_coff_write_u16(u8* bytes, u64 offset, u16 value)
{
    memcpy(bytes + offset, &value, sizeof(value));
}

BUSTER_GLOBAL_LOCAL void object_test_coff_write_u32(u8* bytes, u64 offset, u32 value)
{
    memcpy(bytes + offset, &value, sizeof(value));
}

BUSTER_GLOBAL_LOCAL void object_test_coff_write_name(u8* bytes, u64 offset, String8 name)
{
    memcpy(bytes + offset, name.pointer, name.length);
}

BUSTER_GLOBAL_LOCAL void object_test_coff_section(u8* bytes, u32 section_index, String8 name, u32 raw_offset, u32 characteristics)
{
    u64 section = OBJECT_TEST_COFF_HEADER_SIZE + (u64)section_index * OBJECT_TEST_COFF_SECTION_SIZE;
    object_test_coff_write_name(bytes, section, name);
    object_test_coff_write_u32(bytes, section + 16, OBJECT_TEST_COFF_SECTION_DATA);
    object_test_coff_write_u32(bytes, section + 20, raw_offset);
    object_test_coff_write_u32(bytes, section + 36, characteristics);
}

BUSTER_GLOBAL_LOCAL void object_test_coff_symbol(u8* bytes, u64 symbol_table, u32 symbol_index, String8 name, s16 section_number, u8 storage,
                                                 u8 auxiliary_count)
{
    u64 symbol = symbol_table + (u64)symbol_index * OBJECT_TEST_COFF_SYMBOL_SIZE;
    object_test_coff_write_name(bytes, symbol, name);
    object_test_coff_write_u16(bytes, symbol + 12, (u16)section_number);
    bytes[symbol + 16] = storage;
    bytes[symbol + 17] = auxiliary_count;
}

// Auxiliary Format 5: the section definition whose Selection byte is the whole
// point of the COMDAT model.
BUSTER_GLOBAL_LOCAL void object_test_coff_section_definition(u8* bytes, u64 symbol_table, u32 symbol_index, u8 selection)
{
    u64 auxiliary = symbol_table + (u64)symbol_index * OBJECT_TEST_COFF_SYMBOL_SIZE;
    object_test_coff_write_u32(bytes, auxiliary, OBJECT_TEST_COFF_SECTION_DATA);
    bytes[auxiliary + 14] = selection;
}

BUSTER_GLOBAL_LOCAL ByteSlice object_test_coff_comdat_object(Arena* arena)
{
    u64 section_data = OBJECT_TEST_COFF_HEADER_SIZE + (u64)OBJECT_TEST_COFF_SECTION_COUNT * OBJECT_TEST_COFF_SECTION_SIZE;
    u64 symbol_table = section_data + (u64)OBJECT_TEST_COFF_SECTION_COUNT * OBJECT_TEST_COFF_SECTION_DATA;
    u64 string_table = symbol_table + (u64)OBJECT_TEST_COFF_SYMBOL_COUNT * OBJECT_TEST_COFF_SYMBOL_SIZE;
    u64 length = string_table + 4;
    u8* bytes = arena_allocate(arena, u8, length);
    memset(bytes, 0, length);
    object_test_coff_write_u16(bytes, 0, 0x8664);
    object_test_coff_write_u16(bytes, 2, OBJECT_TEST_COFF_SECTION_COUNT);
    object_test_coff_write_u32(bytes, 8, (u32)symbol_table);
    object_test_coff_write_u32(bytes, 12, OBJECT_TEST_COFF_SYMBOL_COUNT);
    // IMAGE_SCN_ALIGN_4BYTES throughout; CNT_CODE/EXECUTE/READ for .text and
    // CNT_INITIALIZED_DATA/READ plus IMAGE_SCN_LNK_COMDAT for the constants.
    u32 text_characteristics = 0x60300020;
    u32 comdat_characteristics = 0x40301040;
    object_test_coff_section(bytes, 0, S8(".text"), (u32)section_data, text_characteristics);
    object_test_coff_section(bytes, 1, S8(".rdata"), (u32)section_data + 4, comdat_characteristics);
    object_test_coff_section(bytes, 2, S8(".rdata"), (u32)section_data + 8, comdat_characteristics);
    object_test_coff_section(bytes, 3, S8(".rdata"), (u32)section_data + 12, comdat_characteristics);
    object_test_coff_symbol(bytes, symbol_table, 0, S8("plain"), 1, 2, 0);
    object_test_coff_symbol(bytes, symbol_table, 1, S8(".rdata"), 2, 3, 1);
    object_test_coff_section_definition(bytes, symbol_table, 2, 2);
    object_test_coff_symbol(bytes, symbol_table, 3, S8("any_one"), 2, 2, 0);
    object_test_coff_symbol(bytes, symbol_table, 4, S8(".rdata"), 3, 3, 1);
    object_test_coff_section_definition(bytes, symbol_table, 5, 1);
    object_test_coff_symbol(bytes, symbol_table, 6, S8("strict1"), 3, 2, 0);
    object_test_coff_symbol(bytes, symbol_table, 7, S8("pending"), 4, 2, 0);
    object_test_coff_write_u32(bytes, string_table, 4);

    return (ByteSlice){.pointer = bytes, .length = length};
}

BUSTER_GLOBAL_LOCAL ByteSlice object_test_coff_relocation_count_object(Arena* arena, CpuArch architecture, u32 relocation_count)
{
    bool relocation_overflow = relocation_count > UINT16_MAX;
    u64 section_data_offset = OBJECT_TEST_COFF_HEADER_SIZE + OBJECT_TEST_COFF_SECTION_SIZE;
    u64 raw_size = (u64)relocation_count * sizeof(u64);
    u64 relocation_offset = section_data_offset + raw_size;
    u64 symbol_table = relocation_offset + ((u64)relocation_count + relocation_overflow) * 10;
    u64 string_table = symbol_table + OBJECT_TEST_COFF_SYMBOL_SIZE;
    u64 length = string_table + 4;
    u8* bytes = arena_allocate(arena, u8, length);
    memset(bytes, 0, length);
    object_test_coff_write_u16(bytes, 0, architecture == CPU_ARCH_AARCH64 ? 0xaa64 : 0x8664);
    object_test_coff_write_u16(bytes, 2, 1);
    object_test_coff_write_u32(bytes, 8, (u32)symbol_table);
    object_test_coff_write_u32(bytes, 12, 1);
    object_test_coff_write_name(bytes, OBJECT_TEST_COFF_HEADER_SIZE, S8(".data"));
    object_test_coff_write_u32(bytes, OBJECT_TEST_COFF_HEADER_SIZE + 16, (u32)raw_size);
    object_test_coff_write_u32(bytes, OBJECT_TEST_COFF_HEADER_SIZE + 20, (u32)section_data_offset);
    object_test_coff_write_u32(bytes, OBJECT_TEST_COFF_HEADER_SIZE + 24, (u32)relocation_offset);
    object_test_coff_write_u16(bytes, OBJECT_TEST_COFF_HEADER_SIZE + 32,
                               (u16)(relocation_overflow ? UINT16_MAX : relocation_count));
    object_test_coff_write_u32(bytes, OBJECT_TEST_COFF_HEADER_SIZE + 36,
                               0xc0300040 | (relocation_overflow ? OBJECT_TEST_COFF_SECTION_LINK_NRELOC_OVFL : 0));
    if (relocation_overflow)
    {
        object_test_coff_write_u32(bytes, relocation_offset, relocation_count + 1u);
    }
    for (u32 relocation_index = 0; relocation_index < relocation_count; relocation_index += 1)
    {
        u64 data_offset = section_data_offset + (u64)relocation_index * sizeof(u64);
        u64 relocation = relocation_offset + (relocation_overflow ? 10 : 0) + (u64)relocation_index * 10;
        s64 addend = relocation_index == 0 ? -17 : relocation_index + 1 == relocation_count ? 23 : 0;
        memcpy(bytes + data_offset, &addend, sizeof(addend));
        object_test_coff_write_u32(bytes, relocation, (u32)((u64)relocation_index * sizeof(u64)));
        object_test_coff_write_u32(bytes, relocation + 4, 0);
        object_test_coff_write_u16(bytes, relocation + 8, architecture == CPU_ARCH_AARCH64 ? 0x000e : 0x0001);
    }
    object_test_coff_symbol(bytes, symbol_table, 0, S8("external"), 0, 2, 0);
    object_test_coff_write_u32(bytes, string_table, 4);

    return (ByteSlice){.pointer = bytes, .length = length};
}

// A format-equivalent subset of the VC 14.44 stdio object: each COMDAT owns
// its own `.debug$S` C13 contribution, while the object owns one logical
// CodeView stream. The reader has to retain one C13 signature, concatenate
// the contribution payloads, and rebase the later contribution's relocation.
BUSTER_GLOBAL_LOCAL ByteSlice object_test_coff_repeated_codeview_object(Arena* arena, CpuArch architecture)
{
    enum
    {
        SECTION_COUNT = 5,
        SECTION_HEADERS_SIZE = 20 + SECTION_COUNT * 40,
        TEXT_SIZE = 4,
        PRIMARY_SYMBOLS_SIZE = 24,
        SECONDARY_SYMBOLS_SIZE = 16,
        TYPES_SIZE = 8,
        RELOCATION_SIZE = 10,
        SYMBOL_SIZE = 18,
    };
    u64 raw_offset = SECTION_HEADERS_SIZE;
    u64 relocation_offset = raw_offset + TEXT_SIZE + PRIMARY_SYMBOLS_SIZE + SECONDARY_SYMBOLS_SIZE + 2 * TYPES_SIZE;
    u64 symbol_offset = relocation_offset + RELOCATION_SIZE;
    u64 string_offset = symbol_offset + SYMBOL_SIZE;
    u64 length = string_offset + 4;
    u8* bytes = arena_allocate(arena, u8, length);
    memset(bytes, 0, length);
    object_test_coff_write_u16(bytes, 0, architecture == CPU_ARCH_AARCH64 ? 0xaa64 : 0x8664);
    object_test_coff_write_u16(bytes, 2, SECTION_COUNT);
    object_test_coff_write_u32(bytes, 8, (u32)symbol_offset);
    object_test_coff_write_u32(bytes, 12, 1);

    u32 text_characteristics = 0x60300020;
    u32 debug_characteristics = 0x42100040;
    u64 text_section = 20;
    u64 primary_symbols_section = text_section + 40;
    u64 secondary_symbols_section = primary_symbols_section + 40;
    u64 first_types_section = secondary_symbols_section + 40;
    u64 second_types_section = first_types_section + 40;
    object_test_coff_write_name(bytes, text_section, S8(".text"));
    object_test_coff_write_u32(bytes, text_section + 16, TEXT_SIZE);
    object_test_coff_write_u32(bytes, text_section + 20, (u32)raw_offset);
    object_test_coff_write_u32(bytes, text_section + 36, text_characteristics);
    object_test_coff_write_name(bytes, primary_symbols_section, S8(".debug$S"));
    object_test_coff_write_u32(bytes, primary_symbols_section + 16, PRIMARY_SYMBOLS_SIZE);
    object_test_coff_write_u32(bytes, primary_symbols_section + 20, (u32)(raw_offset + TEXT_SIZE));
    object_test_coff_write_u32(bytes, primary_symbols_section + 36, debug_characteristics);
    object_test_coff_write_name(bytes, secondary_symbols_section, S8(".debug$S"));
    object_test_coff_write_u32(bytes, secondary_symbols_section + 16, SECONDARY_SYMBOLS_SIZE);
    object_test_coff_write_u32(bytes, secondary_symbols_section + 20, (u32)(raw_offset + TEXT_SIZE + PRIMARY_SYMBOLS_SIZE));
    object_test_coff_write_u32(bytes, secondary_symbols_section + 24, (u32)relocation_offset);
    object_test_coff_write_u16(bytes, secondary_symbols_section + 32, 1);
    object_test_coff_write_u32(bytes, secondary_symbols_section + 36, debug_characteristics);
    object_test_coff_write_name(bytes, first_types_section, S8(".debug$T"));
    object_test_coff_write_u32(bytes, first_types_section + 16, TYPES_SIZE);
    object_test_coff_write_u32(bytes, first_types_section + 20, (u32)(raw_offset + TEXT_SIZE + PRIMARY_SYMBOLS_SIZE + SECONDARY_SYMBOLS_SIZE));
    object_test_coff_write_u32(bytes, first_types_section + 36, debug_characteristics);
    object_test_coff_write_name(bytes, second_types_section, S8(".debug$T"));
    object_test_coff_write_u32(bytes, second_types_section + 16, TYPES_SIZE);
    object_test_coff_write_u32(bytes, second_types_section + 20,
                               (u32)(raw_offset + TEXT_SIZE + PRIMARY_SYMBOLS_SIZE + SECONDARY_SYMBOLS_SIZE + TYPES_SIZE));
    object_test_coff_write_u32(bytes, second_types_section + 36, debug_characteristics);

    u64 primary = raw_offset + TEXT_SIZE;
    object_test_coff_write_u32(bytes, primary, 4);
    object_test_coff_write_u32(bytes, primary + 4, 0xf3);
    object_test_coff_write_u32(bytes, primary + 8, 1);
    object_test_coff_write_u32(bytes, primary + 16, 0xf4);
    object_test_coff_write_u32(bytes, primary + 20, 0);
    u64 secondary = primary + PRIMARY_SYMBOLS_SIZE;
    object_test_coff_write_u32(bytes, secondary, 4);
    object_test_coff_write_u32(bytes, secondary + 4, 0xf1);
    object_test_coff_write_u32(bytes, secondary + 8, 4);
    object_test_coff_write_u16(bytes, secondary + 12, 2);
    object_test_coff_write_u16(bytes, secondary + 14, 0x9999);
    u64 first_types = secondary + SECONDARY_SYMBOLS_SIZE;
    object_test_coff_write_u32(bytes, first_types, 4);
    object_test_coff_write_u16(bytes, first_types + 4, 2);
    object_test_coff_write_u16(bytes, first_types + 6, 0x9998);
    u64 second_types = first_types + TYPES_SIZE;
    object_test_coff_write_u32(bytes, second_types, 4);
    object_test_coff_write_u16(bytes, second_types + 4, 2);
    object_test_coff_write_u16(bytes, second_types + 6, 0x9997);

    object_test_coff_write_u32(bytes, relocation_offset, 12);
    object_test_coff_write_u32(bytes, relocation_offset + 4, 0);
    object_test_coff_write_u16(bytes, relocation_offset + 8, architecture == CPU_ARCH_AARCH64 ? 0x000d : 0x000a);
    object_test_coff_symbol(bytes, symbol_offset, 0, S8("callee"), 1, 2, 0);
    object_test_coff_write_u16(bytes, symbol_offset + 14, 0x20);
    object_test_coff_write_u32(bytes, string_offset, 4);
    return (ByteSlice){.pointer = bytes, .length = length};
}

// Exact instruction and relocation bytes from the VC14.44 ARM64 stdio
// archive, reduced to one `.text` contribution and its data definition.
// Keeping the fixture hand-built makes its COFF type numbers independent of
// this implementation's writer.
enum
{
    OBJECT_TEST_ARM64_COFF_SECTION_HEADERS_END = 100,
    OBJECT_TEST_ARM64_COFF_TEXT_OFFSET = 100,
    OBJECT_TEST_ARM64_COFF_DATA_OFFSET = 112,
    OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET = 116,
    OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET = 136,
};

BUSTER_GLOBAL_LOCAL ByteSlice object_test_coff_arm64_page_object(Arena* arena, String8 symbol_name, u32 first_word, u32 second_word,
                                                                  u16 second_relocation_type)
{
    u32 string_size = symbol_name.length > 8 ? (u32)(4 + symbol_name.length + 1) : 4;
    u64 string_offset = OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 18;
    u64 length = string_offset + string_size;
    u8* bytes = arena_allocate(arena, u8, length);
    memset(bytes, 0, length);
    object_test_coff_write_u16(bytes, 0, 0xaa64);
    object_test_coff_write_u16(bytes, 2, 2);
    object_test_coff_write_u32(bytes, 8, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET);
    object_test_coff_write_u32(bytes, 12, 1);

    object_test_coff_write_name(bytes, 20, S8(".text"));
    object_test_coff_write_u32(bytes, 20 + 16, 12);
    object_test_coff_write_u32(bytes, 20 + 20, OBJECT_TEST_ARM64_COFF_TEXT_OFFSET);
    object_test_coff_write_u32(bytes, 20 + 24, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET);
    object_test_coff_write_u16(bytes, 20 + 32, 2);
    object_test_coff_write_u32(bytes, 20 + 36, 0x60300020);
    object_test_coff_write_name(bytes, 60, S8(".data"));
    object_test_coff_write_u32(bytes, 60 + 16, 4);
    object_test_coff_write_u32(bytes, 60 + 20, OBJECT_TEST_ARM64_COFF_DATA_OFFSET);
    object_test_coff_write_u32(bytes, 60 + 36, 0xc0300040);

    object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_TEXT_OFFSET, first_word);
    object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_TEXT_OFFSET + 4, second_word);
    object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_TEXT_OFFSET + 8, 0xd65f03c0);
    object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET, 0);
    object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET + 4, 0);
    object_test_coff_write_u16(bytes, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET + 8, 0x0004);
    object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET + 10, 4);
    object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET + 14, 0);
    object_test_coff_write_u16(bytes, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET + 18, second_relocation_type);

    if (symbol_name.length <= 8)
    {
        object_test_coff_write_name(bytes, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET, symbol_name);
    }
    else
    {
        object_test_coff_write_u32(bytes, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 4, 4);
        memcpy(bytes + string_offset + 4, symbol_name.pointer, symbol_name.length);
    }
    object_test_coff_write_u16(bytes, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 12, 2);
    bytes[OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 16] = 2;
    object_test_coff_write_u32(bytes, string_offset, string_size);
    return (ByteSlice){.pointer = bytes, .length = length};
}

// Sweep every remaining-capacity boundary of a valid object, not only the
// first allocation. Reuse one real, fully committed arena and narrow its
// logical limit; the small sentinel immediately beyond that limit is never
// available to the reader. Restore the actual mapping sizes before destruction.
BUSTER_GLOBAL_LOCAL UnitTestResult object_test_elf_arena_capacities(UnitTestArguments* arguments, ByteSlice bytes, Target target)
{
    UnitTestResult result = {0};
    enum { OBJECT_TEST_READER_ARENA_SIZE = 16384, OBJECT_TEST_READER_SENTINEL_SIZE = 16 };
    Arena* arena = arena_create((ArenaCreation){
        .reserved_size = OBJECT_TEST_READER_ARENA_SIZE,
        .initial_size = OBJECT_TEST_READER_ARENA_SIZE,
        .granularity = 1,
        .flags = {.no_pool = 1},
    });
    BUSTER_TEST(arguments, arena != 0);
    if (arena)
    {
        u64 reserved_size = arena->reserved_size;
        u64 os_position = arena->os_position;
        u64 start_padding[] = {0, 1, 7};
        for (u32 run = 0; run < BUSTER_ARRAY_LENGTH(start_padding); run += 1)
        {
            u64 start = arena_minimum_position + start_padding[run];
            arena_set_position(arena, start);
            ObjectFile reference = object_read(arena, bytes, target);
            u64 required = arena->position;
            BUSTER_TEST(arguments, reference.error == OBJECT_ERROR_NONE);
            BUSTER_TEST(arguments, required > start && required <= reserved_size - OBJECT_TEST_READER_SENTINEL_SIZE);
            if (reference.error == OBJECT_ERROR_NONE && required > start && required <= reserved_size - OBJECT_TEST_READER_SENTINEL_SIZE)
            {
                for (u64 capacity = start; capacity <= required; capacity += 1)
                {
                    arena_set_position(arena, start);
                    arena->reserved_size = capacity;
                    arena->os_position = capacity;
                    u8* sentinel = (u8*)arena + capacity;
                    memset(sentinel, 0xa5, OBJECT_TEST_READER_SENTINEL_SIZE);
                    ObjectFile decoded = object_read(arena, bytes, target);
                    BUSTER_TEST(arguments, arena->position <= capacity);
                    BUSTER_TEST(arguments, decoded.error == (capacity == required ? OBJECT_ERROR_NONE : OBJECT_ERROR_INVALID_INPUT));
                    for (u32 byte = 0; byte < OBJECT_TEST_READER_SENTINEL_SIZE; byte += 1)
                    {
                        BUSTER_TEST(arguments, sentinel[byte] == 0xa5);
                    }
                    if (decoded.error == OBJECT_ERROR_NONE)
                    {
                        BUSTER_TEST(arguments, decoded.section_count == reference.section_count);
                        BUSTER_TEST(arguments, decoded.symbol_count == reference.symbol_count);
                        BUSTER_TEST(arguments, decoded.relocation_count == reference.relocation_count);
                        BUSTER_TEST(arguments, arena->position == required);
                    }
                    arena->reserved_size = reserved_size;
                    arena->os_position = os_position;
                }
            }
        }
        BUSTER_TEST(arguments, arena_destroy(arena, 1));
    }
    return result;
}

// Generated printer populations and exact-output oracles. The optional
// BUSTER_OBJECT_ASSEMBLY_BENCH replay times only object_print_assembly,
// including index construction and cleanup; ordinary tests never time-gate.
BUSTER_GLOBAL_LOCAL ObjectFile object_test_assembly_population(Arena* arena, u32 count, u32 order)
{
    ObjectFile object = {.target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
                         .section_count = 2, .symbol_count = count * 2 + 1, .relocation_count = count * 2};
    object.sections = arena_allocate_zeroed(arena, ObjectSection, 2);
    object.symbols = arena_allocate_zeroed(arena, ObjectSymbol, object.symbol_count);
    object.relocations = arena_allocate_zeroed(arena, ObjectRelocation, object.relocation_count);
    object.sections[0] = (ObjectSection){.kind = OBJECT_SECTION_TEXT, .data = {.pointer = arena_allocate_zeroed(arena, u8, (u64)count * 6),
                                                                          .length = (u64)count * 6}};
    object.sections[1] = (ObjectSection){.kind = OBJECT_SECTION_DATA, .data = {.pointer = arena_allocate_zeroed(arena, u8, (u64)count * 8),
                                                                          .length = (u64)count * 8}};
    object.symbols[count * 2] = (ObjectSymbol){.name = S8("external"), .section = OBJECT_SECTION_UNDEFINED};
    for (u32 index = 0; index < count; index += 1)
    {
        u32 slot = order == 1 ? count - index - 1 : order == 2 ? (index * 4051u) % count : index;
        object.sections[0].data.pointer[(u64)slot * 6] = 0xe8;
        object.sections[0].data.pointer[(u64)slot * 6 + 5] = 0xc3;
        object.symbols[index * 2] = (ObjectSymbol){.name = string_format(arena, S8("function_{u32}"), slot),
                                                  .section = 0, .value = (u64)slot * 6, .size = 6, .kind = OBJECT_SYMBOL_FUNCTION};
        object.symbols[index * 2 + 1] = (ObjectSymbol){.name = string_format(arena, S8("pointer_{u32}"), slot),
                                                      .section = 1, .value = (u64)slot * 8, .size = 8, .kind = OBJECT_SYMBOL_DATA};
        object.relocations[index * 2] = (ObjectRelocation){.section = 0, .offset = (u64)slot * 6 + 1,
                                                           .symbol = count * 2, .kind = OBJECT_RELOCATION_X86_64_PC32, .addend = -4};
        object.relocations[index * 2 + 1] = (ObjectRelocation){.section = 1, .offset = (u64)slot * 8,
                                                               .symbol = index * 2, .kind = OBJECT_RELOCATION_ABSOLUTE64};
    }
    return object;
}

BUSTER_GLOBAL_LOCAL UnitTestResult object_test_assembly_index_order(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u8 bytes[16] = {0};
    ObjectSection sections[] = {
        {.kind = OBJECT_SECTION_DATA, .data = {.pointer = bytes, .length = sizeof(bytes)}},
        {.kind = OBJECT_SECTION_READ_ONLY_DATA},
        {.kind = OBJECT_SECTION_ZERO, .virtual_size = 3},
        {.kind = OBJECT_SECTION_TEXT},
    };
    ObjectSymbol symbols[] = {
        {.name = S8("end"), .section = 0, .value = 16, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("external"), .section = OBJECT_SECTION_UNDEFINED},
        {.name = S8("second"), .section = 0, .value = 8, .size = 8, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("empty"), .section = 1, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("first"), .section = 0, .size = 8, .kind = OBJECT_SYMBOL_DATA, .global = true},
        {.name = S8("alias"), .section = 0, .size = 8, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("zero"), .section = 2, .size = 3, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("ignored"), .section = 100, .kind = OBJECT_SYMBOL_DATA},
    };
    ObjectRelocation relocations[] = {
        {.section = 0, .offset = 8, .symbol = 4, .kind = OBJECT_RELOCATION_ABSOLUTE64, .addend = 3},
        {.section = 0, .offset = 0, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        {.section = 0, .offset = 0, .symbol = 2, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        {.section = 100, .symbol = 7, .kind = OBJECT_RELOCATION_ABSOLUTE64},
    };
    ObjectFile object = {.target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
                         .sections = sections, .section_count = BUSTER_ARRAY_LENGTH(sections),
                         .symbols = symbols, .symbol_count = BUSTER_ARRAY_LENGTH(symbols),
                         .relocations = relocations, .relocation_count = BUSTER_ARRAY_LENGTH(relocations)};
    ObjectSymbol symbols_before[BUSTER_ARRAY_LENGTH(symbols)];
    ObjectRelocation relocations_before[BUSTER_ARRAY_LENGTH(relocations)];
    memcpy(symbols_before, symbols, sizeof(symbols));
    memcpy(relocations_before, relocations, sizeof(relocations));
    String8 expected = S8("\t.intel_syntax noprefix\n\t.extern external\n\t.section .data\n"
                          "\t.globl first\n\t.type first, @object\nfirst:\n\t.type alias, @object\nalias:\n"
                          "\t.quad \"external\"\n\t.type second, @object\nsecond:\n\t.quad \"first\" + 3\n"
                          "\t.type end, @object\nend:\n\t.size end, 0\n\t.size second, 8\n\t.size first, 8\n\t.size alias, 8\n"
                          "\t.section .rodata\n\t.type empty, @object\nempty:\n\t.size empty, 0\n"
                          "\t.section .bss,\"aw\",@nobits\n\t.type zero, @object\nzero:\n\t.zero 3\n\t.size zero, 3\n");
    BUSTER_TEST(arguments, object_assembly_test_index_queries(arguments->arena, &object));
    String8 assembly = object_print_assembly(arguments->arena, &object);
    BUSTER_STRING_TEST(arguments, assembly, expected);
    BUSTER_TEST(arguments, memcmp(symbols, symbols_before, sizeof(symbols)) == 0);
    BUSTER_TEST(arguments, memcmp(relocations, relocations_before, sizeof(relocations)) == 0);
    BUSTER_STRING_TEST(arguments, object_print_assembly(arguments->arena, &object), expected);
    // One section per entry catches cross-section cursor leakage and empty gaps.
    ObjectSection many_sections[67] = {0};
    ObjectSymbol many_symbols[33] = {0};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(many_symbols); index += 1)
    {
        u32 section = 2 * (32 - index);
        many_sections[section].kind = OBJECT_SECTION_DATA;
        many_symbols[index] = (ObjectSymbol){.name = string_format(arguments->arena, S8("section_{u32}"), section),
                                             .section = section, .kind = OBJECT_SYMBOL_DATA};
    }
    object.sections = many_sections;
    object.section_count = BUSTER_ARRAY_LENGTH(many_sections);
    object.symbols = many_symbols;
    object.symbol_count = BUSTER_ARRAY_LENGTH(many_symbols);
    object.relocation_count = 0;
    assembly = object_print_assembly(arguments->arena, &object);
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(many_symbols); index += 1)
    {
        String8 label = string_format(arguments->arena, S8("section_{u32}:\n"), index * 2);
        BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(assembly), label));
    }
    object.symbol_count = 0;
    BUSTER_STRING_TEST(arguments, object_print_assembly(arguments->arena, &object), S8("\t.intel_syntax noprefix\n"));
    // Literal targets are deliberately queried backward, forward, then
    // backward again while preparing the AArch64 section's internal labels.
    u32 literal_words[] = {0, 0, UINT32_C(0x58ffffc0), UINT32_C(0x58000021), 0, 0, UINT32_C(0x58ffffc2)};
    ObjectSection literal_section = {.kind = OBJECT_SECTION_TEXT, .data = (ByteSlice){.pointer = (u8*)literal_words, .length = sizeof(literal_words)}};
    ObjectSymbol literal_symbol = {.name = S8("external"), .section = OBJECT_SECTION_UNDEFINED};
    ObjectRelocation literal_relocations[] = {
        {.offset = 16, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64, .addend = 7},
        {.offset = 0, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
    };
    object = (ObjectFile){.target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
                          .sections = &literal_section, .section_count = 1, .symbols = &literal_symbol, .symbol_count = 1,
                          .relocations = literal_relocations, .relocation_count = BUSTER_ARRAY_LENGTH(literal_relocations)};
    expected = S8("\t.extern external\n\t.text\n.Lbuster_0_0:\n\t.quad external\n"
                  "\tldr x0, .Lbuster_0_0\n\tldr x1, .Lbuster_0_16\n.Lbuster_0_16:\n\t.quad external + 7\n"
                  "\tldr x2, .Lbuster_0_16\n");
    BUSTER_TEST(arguments, object_assembly_test_index_queries(arguments->arena, &object));
    BUSTER_STRING_TEST(arguments, object_print_assembly(arguments->arena, &object), expected);
    literal_relocations[0].offset = 24;
    BUSTER_TEST(arguments, object_print_assembly(arguments->arena, &object).length == 0);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult object_test_assembly_scaling(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    bool benchmark = os_get_environment_variable(S8("BUSTER_OBJECT_ASSEMBLY_BENCH")).length != 0;
    u32 counts[] = {0, 1, 8, 17, 64, 1024, 2048, 4096, 8192};
    for (u32 population = 0; population < BUSTER_ARRAY_LENGTH(counts); population += 1)
    {
        u32 count = counts[population];
        if (!benchmark && count > 64) continue;
        for (u32 order = 0; order < 3; order += 1)
        {
            TemporalArena temporary = arena_begin_temporal(arguments->arena);
            ObjectFile object = object_test_assembly_population(arguments->arena, count, order);
            BUSTER_TEST(arguments, object_assembly_test_index_queries(arguments->arena, &object));
            Arena* output = arena_create((ArenaCreation){.reserved_size = BUSTER_MB(64)});
            u64 first_hash = 0;
            for (u32 iteration = 0; iteration < (benchmark ? 8u : 2u); iteration += 1)
            {
                u64 position = output->position;
                TimeDataType start = timestamp_take();
                String8 assembly = object_print_assembly(output, &object);
                u64 ns = timestamp_ns_between(start, timestamp_take());
                if (BUSTER_REQUIRE(arguments, assembly.pointer && assembly.length > 0))
                {
                    u64 hash = UINT64_C(14695981039346656037);
                    for (u64 byte = 0; byte < assembly.length; byte += 1)
                    {
                        hash = (hash ^ assembly.pointer[byte]) * UINT64_C(1099511628211);
                    }
                    if (!iteration)
                    {
                        first_hash = hash;
                        String8 directory = os_get_environment_variable(S8("BUSTER_OBJECT_ASSEMBLY_OUTPUT"));
                        if (benchmark && directory.length)
                        {
                            String8 path = string_format(arguments->arena, S8("{S8}/assembly_{u32}_{u32}.s"), directory, count, order);
                            path = string_duplicate_arena(arguments->arena, path, true);
                            BUSTER_TEST(arguments, file_write(path, BUSTER_SLICE_TO_BYTE_SLICE(assembly)));
                        }
                    }
                    BUSTER_TEST(arguments, hash == first_hash);
                    if (benchmark && iteration)
                    {
                        string_print(S8("BENCH_OBJECT_ASSEMBLY count={u32} symbols={u32} relocations={u32} order={u32} iteration={u32} ns={u64} bytes={u64} "
                                        "retained={u64} peak={u64} hash={u64}\n"),
                                     count, object.symbol_count, object.relocation_count, order, iteration, ns, assembly.length, output->position - position,
                                     arena_dirty_position(output) - position, hash);
                    }
                }
                arena_set_position(output, position);
            }
            arena_destroy(output, 1);
            scratch_end(temporary);
        }
    }
    return result;
}

// COFF carries in-memory section alignment in IMAGE_SCN_ALIGN_* rather than
// in PointerToRawData. Read the bytes directly so the writer test does not
// certify its output through object_read's matching decoder.
BUSTER_GLOBAL_LOCAL UnitTestResult object_test_coff_section_alignment(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    TemporalArena temporary = scratch_begin(&arguments->arena, 1);
    u8 data[] = {1, 2, 3, 4};
    ObjectSectionKind kinds[] = {OBJECT_SECTION_TEXT, OBJECT_SECTION_READ_ONLY_DATA, OBJECT_SECTION_DATA, OBJECT_SECTION_ZERO};
    u32 section_flags[] = {0x60000020, 0x40000040, 0xc0000040, 0xc0000080};
    u32 alignments[] = {1, 2, 4, 8, 16, 32, 64, 4096, 8192};
    u32 alignment_characteristics[] = {0x00100000, 0x00200000, 0x00300000, 0x00400000, 0x00500000,
                                       0x00600000, 0x00700000, 0x00d00000, 0x00e00000};
    for (u32 kind_index = 0; kind_index < BUSTER_ARRAY_LENGTH(kinds); kind_index += 1)
    {
        for (u32 alignment_index = 0; alignment_index < BUSTER_ARRAY_LENGTH(alignments); alignment_index += 1)
        {
            u32 alignment = alignments[alignment_index];
            ObjectSection section = {
                .name = object_section_name_for_kind(kinds[kind_index]),
                .data = kinds[kind_index] == OBJECT_SECTION_ZERO ? (ByteSlice){0} : (ByteSlice)BUSTER_ARRAY_TO_SLICE(data),
                .virtual_size = sizeof(data),
                .kind = kinds[kind_index],
                .alignment = alignment,
            };
            ObjectFile object = {
                .target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},
                .sections = &section,
                .section_count = 1,
            };
            ObjectArtifact artifact = object_write(temporary.arena, &object, OBJECT_FORMAT_COFF);
            BUSTER_TEST_RAW(arguments, artifact.error == OBJECT_ERROR_NONE, S8("COFF alignment writer rejected a representable alignment"));
            if (BUSTER_REQUIRE(arguments, artifact.error == OBJECT_ERROR_NONE && artifact.bytes.pointer && artifact.bytes.length >= 60))
            {
                u32 characteristics = 0;
                BUSTER_TEST(arguments, object_test_coff_section_characteristics(artifact.bytes, 0, &characteristics));
                BUSTER_TEST(arguments, (characteristics & 0x00f00000) == alignment_characteristics[alignment_index]);
                BUSTER_TEST(arguments, (characteristics & ~(u32)0x00f00000) == section_flags[kind_index]);
                if (kinds[kind_index] != OBJECT_SECTION_ZERO)
                {
                    u32 raw_offset = 0;
                    memcpy(&raw_offset, artifact.bytes.pointer + 40, sizeof(raw_offset));
                    BUSTER_TEST(arguments, raw_offset == 60);
                }
                if (alignment == 64)
                {
                    ObjectFile restored = object_read(temporary.arena, artifact.bytes, object.target);
                    BUSTER_TEST(arguments, restored.error == OBJECT_ERROR_NONE && restored.sections &&
                                               restored.sections[kinds[kind_index]].alignment == alignment);
                }
            }
            arena_set_position(temporary.arena, temporary.position);
        }
    }

    ObjectSectionKind default_kinds[] = {
        OBJECT_SECTION_TEXT, OBJECT_SECTION_READ_ONLY_DATA, OBJECT_SECTION_DATA, OBJECT_SECTION_ZERO,
        OBJECT_SECTION_INIT_ARRAY, OBJECT_SECTION_FINI_ARRAY, OBJECT_SECTION_UNWIND,
        OBJECT_SECTION_WINDOWS_PDATA, OBJECT_SECTION_WINDOWS_XDATA, OBJECT_SECTION_DEBUG_INFO,
    };
    u32 default_alignments[] = {16, 16, 16, 16, 8, 8, 8, 4, 4, 1};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(default_kinds); index += 1)
    {
        ObjectSection section = {
            .name = object_section_name_for_kind(default_kinds[index]),
            .data = object_section_kind_is_zero_fill(default_kinds[index]) ? (ByteSlice){0} : (ByteSlice)BUSTER_ARRAY_TO_SLICE(data),
            .virtual_size = sizeof(data),
            .kind = default_kinds[index],
            .alignment = 0,
        };
        ObjectFile object = {
            .target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},
            .sections = &section,
            .section_count = 1,
        };
        ObjectArtifact artifact = object_write(temporary.arena, &object, OBJECT_FORMAT_COFF);
        BUSTER_TEST_RAW(arguments, artifact.error == OBJECT_ERROR_NONE, S8("COFF default section alignment was rejected"));
        if (BUSTER_REQUIRE(arguments, artifact.error == OBJECT_ERROR_NONE && artifact.bytes.pointer && artifact.bytes.length >= 60))
        {
            u32 characteristics = 0;
            u32 alignment = default_alignments[index];
            u32 code = 1;
            while (alignment > 1)
            {
                alignment >>= 1;
                code += 1;
            }
            BUSTER_TEST(arguments, object_section_default_alignment(default_kinds[index]) == default_alignments[index]);
            BUSTER_TEST(arguments, object_test_coff_section_characteristics(artifact.bytes, 0, &characteristics));
            BUSTER_TEST(arguments, (characteristics & 0x00f00000) == (code << 20));
        }
        arena_set_position(temporary.arena, temporary.position);
    }

    ObjectSectionKind stronger_kinds[] = {OBJECT_SECTION_INIT_ARRAY, OBJECT_SECTION_FINI_ARRAY, OBJECT_SECTION_UNWIND};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(stronger_kinds); index += 1)
    {
        ObjectSection section = {
            .name = object_section_name_for_kind(stronger_kinds[index]),
            .data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(data),
            .kind = stronger_kinds[index],
            .alignment = 64,
        };
        ObjectFile object = {
            .target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},
            .sections = &section,
            .section_count = 1,
        };
        ObjectArtifact artifact = object_write(temporary.arena, &object, OBJECT_FORMAT_COFF);
        BUSTER_TEST(arguments, artifact.error == OBJECT_ERROR_NONE);
        if (BUSTER_REQUIRE(arguments, artifact.error == OBJECT_ERROR_NONE && artifact.bytes.pointer && artifact.bytes.length >= 60))
        {
            u32 characteristics = 0;
            BUSTER_TEST(arguments, object_test_coff_section_characteristics(artifact.bytes, 0, &characteristics));
            BUSTER_TEST(arguments, (characteristics & 0x00f00000) == 0x00700000);
        }
        arena_set_position(temporary.arena, temporary.position);
    }

    ObjectSection unsupported_section = {
        .name = S8(".data"),
        .data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(data),
        .kind = OBJECT_SECTION_DATA,
        .alignment = 16384,
    };
    ObjectFile unsupported_object = {
        .target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},
        .sections = &unsupported_section,
        .section_count = 1,
    };
    ObjectArtifact unsupported = object_write(temporary.arena, &unsupported_object, OBJECT_FORMAT_COFF);
    BUSTER_TEST(arguments, unsupported.error == OBJECT_ERROR_UNSUPPORTED_ALIGNMENT && !unsupported.bytes.pointer && !unsupported.bytes.length);
    scratch_end(temporary);
    return result;
}

// Independent section names force the reader to recognize each DWARF 5
// family. The object layer preserves bytes and relocations without decoding DIEs.
BUSTER_GLOBAL_LOCAL UnitTestResult object_test_dwarf5_sections(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    ObjectSectionKind kinds[] = {
        OBJECT_SECTION_DEBUG_ADDR, OBJECT_SECTION_DEBUG_STR_OFFSETS, OBJECT_SECTION_DEBUG_LINE_STR,
        OBJECT_SECTION_DEBUG_RNGLISTS, OBJECT_SECTION_DEBUG_LOCLISTS,
    };
    String8 names[] = {S8(".debug_addr"), S8(".debug_str_offsets"), S8(".debug_line_str"), S8(".debug_rnglists"), S8(".debug_loclists")};
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
    {
        TemporalArena temporary = scratch_begin(&arguments->arena, 1);
        ObjectSection sections[OBJECT_SECTION_COUNT] = {0};
        ObjectSymbol symbols[BUSTER_ARRAY_LENGTH(kinds)] = {0};
        ObjectRelocation relocations[BUSTER_ARRAY_LENGTH(kinds)] = {0};
        u8 payload[16] = {12, 0, 0, 0, 5, 0, 8, 0};
        u8 references[8 * BUSTER_ARRAY_LENGTH(kinds)] = {0};
        for (u32 kind = 0; kind < OBJECT_SECTION_COUNT; kind += 1)
        {
            sections[kind] = (ObjectSection){.name = object_section_name_for_kind((ObjectSectionKind)kind), .kind = (ObjectSectionKind)kind, .alignment = 1};
        }
        sections[OBJECT_SECTION_DEBUG_INFO].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(references);
        sections[OBJECT_SECTION_DEBUG_INFO].virtual_size = sizeof(references);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(kinds); index += 1)
        {
            ObjectSectionKind kind = kinds[index];
            BUSTER_TEST(arguments, object_section_kind_is_debug(kind));
            BUSTER_STRING_TEST(arguments, object_section_name_for_kind(kind), names[index]);
            BUSTER_TEST(arguments, object_section_default_alignment(kind) == 1);
            sections[kind].name = names[index];
            sections[kind].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(payload);
            sections[kind].virtual_size = sizeof(payload);
            symbols[index] = (ObjectSymbol){.name = names[index], .section = (u32)kind, .value = 8};
            relocations[index] = (ObjectRelocation){.section = OBJECT_SECTION_DEBUG_INFO, .symbol = index, .offset = (u64)index * 8,
                                                   .kind = index & 1 ? OBJECT_RELOCATION_ABSOLUTE32 : OBJECT_RELOCATION_ABSOLUTE64, .addend = 1};
        }
        ObjectFile object = {.target = {.cpu_arch = architectures[architecture], .os = OPERATING_SYSTEM_LINUX},
                             .sections = sections, .section_count = OBJECT_SECTION_COUNT,
                             .symbols = symbols, .symbol_count = BUSTER_ARRAY_LENGTH(symbols),
                             .relocations = relocations, .relocation_count = BUSTER_ARRAY_LENGTH(relocations)};
        ObjectArtifact artifact = object_write(temporary.arena, &object, OBJECT_FORMAT_ELF64);
        BUSTER_TEST(arguments, artifact.error == OBJECT_ERROR_NONE);
        ObjectFile restored = object_read(temporary.arena, artifact.bytes, object.target);
        if (BUSTER_REQUIRE(arguments, restored.error == OBJECT_ERROR_NONE))
        {
            BUSTER_TEST(arguments, restored.relocation_count == BUSTER_ARRAY_LENGTH(relocations));
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(kinds); index += 1)
            {
                ByteSlice data = restored.sections[kinds[index]].data;
                BUSTER_TEST(arguments, data.length == sizeof(payload) && memcmp(data.pointer, payload, sizeof(payload)) == 0);
            }
            for (u32 index = 0; index < restored.relocation_count; index += 1)
            {
                ObjectRelocation relocation = restored.relocations[index];
                BUSTER_TEST(arguments, relocation.symbol < restored.symbol_count && index < BUSTER_ARRAY_LENGTH(relocations));
                if (relocation.symbol < restored.symbol_count && index < BUSTER_ARRAY_LENGTH(relocations))
                {
                    BUSTER_TEST(arguments, relocation.section == OBJECT_SECTION_DEBUG_INFO && relocation.offset == (u64)index * 8 &&
                                           relocation.kind == relocations[index].kind && relocation.addend == 1);
                    BUSTER_TEST(arguments, restored.symbols[relocation.symbol].section == (u32)kinds[index] && restored.symbols[relocation.symbol].value == 8);
                }
            }
        }
        // A valid ELF section outside the supported vocabulary must be named
        // when a retained debug contribution references it.
        sections[OBJECT_SECTION_DEBUG_ADDR].name = S8(".debug_future");
        ObjectArtifact future = object_write(temporary.arena, &object, OBJECT_FORMAT_ELF64);
        BUSTER_TEST(arguments, future.error == OBJECT_ERROR_NONE);
        ObjectFile unsupported = object_read(temporary.arena, future.bytes, object.target);
        BUSTER_TEST(arguments, unsupported.error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        BUSTER_STRING_TEST(arguments, unsupported.diagnostic, S8("ELF relocation references unsupported section .debug_future"));
        scratch_end(temporary);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult object_test_writer_alignment_capacity(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    TemporalArena temporary = scratch_begin(&arguments->arena, 1);
    ObjectSectionKind section_kinds[] = {
        OBJECT_SECTION_TEXT,
        OBJECT_SECTION_READ_ONLY_DATA,
        OBJECT_SECTION_DATA,
        OBJECT_SECTION_DEBUG_LOC,
        OBJECT_SECTION_DEBUG_INFO,
        OBJECT_SECTION_DEBUG_ABBREV,
        OBJECT_SECTION_DEBUG_LINE,
        OBJECT_SECTION_ZERO,
        OBJECT_SECTION_DEBUG_STR,
    };
    u32 alignments[] = {32768, 16, 4096, 16384, 65536, 32768, 65536, 65536, 1};
    u64 payload_sizes[] = {1, 1, 8, 1, 1, 1, 1, 0, 1};
    u64 virtual_sizes[] = {1, 1, 8, 1, 1, 1, 1, BUSTER_MB(2), 1};
    u8 payloads[BUSTER_ARRAY_LENGTH(section_kinds)][8] = {
        {0xc3}, {0x19}, {0, 0, 0, 0, 0, 0, 0, 0}, {0x31}, {0x42}, {0x53}, {0x64}, {0}, {0x75},
    };
    ObjectSection sections[BUSTER_ARRAY_LENGTH(section_kinds)] = {0};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(section_kinds); index += 1)
    {
        sections[index] = (ObjectSection){
            .name = object_section_name_for_kind(section_kinds[index]),
            .data = {.pointer = payloads[index], .length = payload_sizes[index]},
            .virtual_size = virtual_sizes[index],
            .kind = section_kinds[index],
            .alignment = alignments[index],
        };
    }
    ObjectSymbol symbols[] = {
        {.name = S8("aligned_text"), .size = 1, .section = 0, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
        {.name = S8("aligned_data"), .size = 8, .section = 2, .kind = OBJECT_SYMBOL_DATA, .global = true},
    };
    ObjectRelocation relocation = {
        .offset = 0,
        .section = 2,
        .symbol = 0,
        .kind = OBJECT_RELOCATION_ABSOLUTE64,
    };
    ObjectFile source = {
        .sections = sections,
        .symbols = symbols,
        .relocations = &relocation,
        .section_count = BUSTER_ARRAY_LENGTH(sections),
        .symbol_count = BUSTER_ARRAY_LENGTH(symbols),
        .relocation_count = 1,
    };
    ObjectFormat formats[] = {OBJECT_FORMAT_ELF64, OBJECT_FORMAT_MACH_O64};
    Target targets[] = {
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS},
    };
    u8 single_byte_payload = 0xc3;
    ObjectSection single_section = {
        .name = S8(".text"),
        .data = {.pointer = &single_byte_payload, .length = 1},
        .virtual_size = 1,
        .kind = OBJECT_SECTION_TEXT,
    };
    ObjectFile single_object = {
        .sections = &single_section,
        .section_count = 1,
    };
    u32 single_alignments[] = {1, 16, 16384, 32768, 65536};
    for (u32 format_index = 0; format_index < BUSTER_ARRAY_LENGTH(formats); format_index += 1)
    {
        single_object.target = targets[format_index];
        for (u32 alignment_index = 0; alignment_index < BUSTER_ARRAY_LENGTH(single_alignments); alignment_index += 1)
        {
            TemporalArena single_scope = arena_begin_temporal(temporary.arena);
            single_section.alignment = single_alignments[alignment_index];
            ObjectArtifact single = object_write(temporary.arena, &single_object, formats[format_index]);
            bool layout_valid = single.error == OBJECT_ERROR_NONE && single.bytes.pointer;
            u64 file_offset = 0;
            u64 file_size = 0;
            if (layout_valid && formats[format_index] == OBJECT_FORMAT_ELF64 && single.bytes.length >= 64)
            {
                u64 section_table = 0;
                u16 section_count = 0;
                u64 section_alignment = 0;
                memcpy(&section_table, single.bytes.pointer + 40, sizeof(section_table));
                memcpy(&section_count, single.bytes.pointer + 60, sizeof(section_count));
                layout_valid = section_table <= single.bytes.length &&
                               (u64)section_count * 64 <= single.bytes.length - section_table && section_count > 1;
                if (layout_valid)
                {
                    u64 header = section_table + 64;
                    memcpy(&file_offset, single.bytes.pointer + header + 24, sizeof(file_offset));
                    memcpy(&file_size, single.bytes.pointer + header + 32, sizeof(file_size));
                    memcpy(&section_alignment, single.bytes.pointer + header + 48, sizeof(section_alignment));
                    layout_valid = section_alignment == single_alignments[alignment_index] &&
                                   file_offset % single_alignments[alignment_index] == 0 && file_size == 1 &&
                                   file_offset <= single.bytes.length && file_size <= single.bytes.length - file_offset;
                }
            }
            else if (layout_valid && formats[format_index] == OBJECT_FORMAT_MACH_O64 && single.bytes.length >= 184)
            {
                u32 magic = 0;
                u32 command = 0;
                u32 segment_size = 0;
                u32 section_count = 0;
                u32 file_offset32 = 0;
                u32 alignment_exponent = 0;
                memcpy(&magic, single.bytes.pointer, sizeof(magic));
                memcpy(&command, single.bytes.pointer + 32, sizeof(command));
                memcpy(&segment_size, single.bytes.pointer + 36, sizeof(segment_size));
                memcpy(&section_count, single.bytes.pointer + 32 + 64, sizeof(section_count));
                u64 header = 32 + 72;
                memcpy(&file_size, single.bytes.pointer + header + 40, sizeof(file_size));
                memcpy(&file_offset32, single.bytes.pointer + header + 48, sizeof(file_offset32));
                memcpy(&alignment_exponent, single.bytes.pointer + header + 52, sizeof(alignment_exponent));
                u32 expected_exponent = 0;
                for (u32 alignment = single_alignments[alignment_index]; alignment > 1; alignment >>= 1)
                {
                    expected_exponent += 1;
                }
                file_offset = file_offset32;
                layout_valid = magic == UINT32_C(0xfeedfacf) && command == 0x19 && segment_size == 152 && section_count == 1 &&
                               alignment_exponent == expected_exponent && file_offset % single_alignments[alignment_index] == 0 &&
                               file_size == 1 && file_offset <= single.bytes.length && file_size <= single.bytes.length - file_offset;
            }
            else
            {
                layout_valid = false;
            }
            if (layout_valid)
            {
                layout_valid = single.bytes.pointer[file_offset] == single_byte_payload;
            }
            BUSTER_TEST(arguments, layout_valid);
            arena_set_position(temporary.arena, single_scope.position);
        }
    }
    for (u32 format_index = 0; format_index < BUSTER_ARRAY_LENGTH(formats); format_index += 1)
    {
        TemporalArena format_scope = arena_begin_temporal(temporary.arena);
        ObjectFile object = source;
        object.target = targets[format_index];
        ObjectArtifact artifact = object_write(temporary.arena, &object, formats[format_index]);
        bool artifact_valid = artifact.error == OBJECT_ERROR_NONE && artifact.bytes.pointer && artifact.bytes.length >= 64;
        BUSTER_TEST(arguments, artifact_valid);
        bool all_sections_valid = artifact_valid;
        if (artifact_valid && formats[format_index] == OBJECT_FORMAT_ELF64)
        {
            u64 section_table = 0;
            u16 section_count = 0;
            memcpy(&section_table, artifact.bytes.pointer + 40, sizeof(section_table));
            memcpy(&section_count, artifact.bytes.pointer + 60, sizeof(section_count));
            bool section_table_valid = section_table <= artifact.bytes.length &&
                                       (u64)section_count * 64 <= artifact.bytes.length - section_table &&
                                       section_count > (u16)BUSTER_ARRAY_LENGTH(section_kinds);
            BUSTER_TEST(arguments, section_table_valid);
            all_sections_valid = section_table_valid;
            for (u32 index = 0; section_table_valid && index < BUSTER_ARRAY_LENGTH(section_kinds); index += 1)
            {
                u64 header = section_table + (u64)(index + 1) * 64;
                u64 file_offset = 0;
                u64 file_size = 0;
                u64 alignment = 0;
                u32 section_type = 0;
                memcpy(&section_type, artifact.bytes.pointer + header + 4, sizeof(section_type));
                memcpy(&file_offset, artifact.bytes.pointer + header + 24, sizeof(file_offset));
                memcpy(&file_size, artifact.bytes.pointer + header + 32, sizeof(file_size));
                memcpy(&alignment, artifact.bytes.pointer + header + 48, sizeof(alignment));
                bool zero_fill = object_section_kind_is_zero_fill(section_kinds[index]);
                u64 expected_size = zero_fill ? virtual_sizes[index] : payload_sizes[index];
                bool file_extent_valid = file_offset <= artifact.bytes.length &&
                                         (zero_fill || file_size <= artifact.bytes.length - file_offset);
                bool section_valid = alignment == alignments[index] && file_offset % alignment == 0 && file_size == expected_size &&
                                     file_extent_valid && (!zero_fill || section_type == 8);
                BUSTER_TEST(arguments, section_valid);
                if (section_valid && !zero_fill)
                {
                    BUSTER_TEST(arguments, memcmp(artifact.bytes.pointer + file_offset, payloads[index], payload_sizes[index]) == 0);
                }
                all_sections_valid = all_sections_valid && section_valid;
            }
        }
        else if (artifact_valid && formats[format_index] == OBJECT_FORMAT_MACH_O64)
        {
            u32 magic = 0;
            u32 command = 0;
            u32 segment_size = 0;
            u32 section_count = 0;
            memcpy(&magic, artifact.bytes.pointer, sizeof(magic));
            memcpy(&command, artifact.bytes.pointer + 32, sizeof(command));
            memcpy(&segment_size, artifact.bytes.pointer + 36, sizeof(segment_size));
            memcpy(&section_count, artifact.bytes.pointer + 32 + 64, sizeof(section_count));
            u64 section_bytes = (u64)section_count * 80;
            bool section_table_valid = magic == UINT32_C(0xfeedfacf) && command == 0x19 &&
                                       section_count == BUSTER_ARRAY_LENGTH(section_kinds) &&
                                       segment_size == 72 + section_bytes && segment_size <= artifact.bytes.length - 32;
            BUSTER_TEST(arguments, section_table_valid);
            all_sections_valid = section_table_valid;
            for (u32 index = 0; section_table_valid && index < BUSTER_ARRAY_LENGTH(section_kinds); index += 1)
            {
                u64 header = 32 + 72 + (u64)index * 80;
                u64 file_size = 0;
                u32 file_offset = 0;
                u32 alignment_exponent = 0;
                u32 section_flags = 0;
                memcpy(&file_size, artifact.bytes.pointer + header + 40, sizeof(file_size));
                memcpy(&file_offset, artifact.bytes.pointer + header + 48, sizeof(file_offset));
                memcpy(&alignment_exponent, artifact.bytes.pointer + header + 52, sizeof(alignment_exponent));
                memcpy(&section_flags, artifact.bytes.pointer + header + 64, sizeof(section_flags));
                u32 expected_exponent = 0;
                for (u32 alignment = alignments[index]; alignment > 1; alignment >>= 1)
                {
                    expected_exponent += 1;
                }
                bool zero_fill = object_section_kind_is_zero_fill(section_kinds[index]);
                u64 expected_size = zero_fill ? virtual_sizes[index] : payload_sizes[index];
                bool file_extent_valid = file_offset <= artifact.bytes.length &&
                                         (zero_fill || file_size <= artifact.bytes.length - file_offset);
                bool section_valid = alignment_exponent == expected_exponent && file_offset % alignments[index] == 0 &&
                                     file_size == expected_size && file_extent_valid &&
                                     (!zero_fill || (section_flags & 0xff) == 1);
                BUSTER_TEST(arguments, section_valid);
                if (section_valid && !zero_fill)
                {
                    BUSTER_TEST(arguments, memcmp(artifact.bytes.pointer + file_offset, payloads[index], payload_sizes[index]) == 0);
                }
                all_sections_valid = all_sections_valid && section_valid;
            }
        }
        BUSTER_TEST(arguments, all_sections_valid);
        ObjectFile restored = {0};
        if (artifact_valid)
        {
            restored = object_read(temporary.arena, artifact.bytes, object.target);
        }
        bool roundtrip_ready = restored.error == OBJECT_ERROR_NONE && restored.sections && restored.symbols && restored.relocations &&
                               restored.section_count > OBJECT_SECTION_ZERO && restored.symbol_count == BUSTER_ARRAY_LENGTH(symbols) &&
                               restored.relocation_count == 1;
        if (BUSTER_REQUIRE(arguments, roundtrip_ready))
        {
            bool text_symbol_valid = false;
            bool data_symbol_valid = false;
            for (u32 symbol = 0; symbol < restored.symbol_count; symbol += 1)
            {
                ObjectSymbol* restored_symbol = restored.symbols + symbol;
                if (string_equal(restored_symbol->name, S8("aligned_text")))
                {
                    text_symbol_valid = restored_symbol->section == OBJECT_SECTION_TEXT && restored_symbol->kind == OBJECT_SYMBOL_FUNCTION &&
                                        (formats[format_index] != OBJECT_FORMAT_ELF64 || restored_symbol->size == 1);
                }
                else if (string_equal(restored_symbol->name, S8("aligned_data")))
                {
                    data_symbol_valid = restored_symbol->section == OBJECT_SECTION_DATA && restored_symbol->kind == OBJECT_SYMBOL_DATA &&
                                        (formats[format_index] != OBJECT_FORMAT_ELF64 || restored_symbol->size == 8);
                }
            }
            BUSTER_TEST(arguments, text_symbol_valid && data_symbol_valid);
            ByteSlice restored_text = restored.sections[OBJECT_SECTION_TEXT].data;
            ByteSlice restored_data = restored.sections[OBJECT_SECTION_DATA].data;
            ByteSlice restored_zero = restored.sections[OBJECT_SECTION_ZERO].data;
            bool payloads_valid = restored_text.length == payload_sizes[0] && restored_text.pointer &&
                                  memcmp(restored_text.pointer, payloads[0], payload_sizes[0]) == 0 &&
                                  restored_data.length == payload_sizes[2] && restored_data.pointer &&
                                  memcmp(restored_data.pointer, payloads[2], payload_sizes[2]) == 0 && !restored_zero.length &&
                                  restored.sections[OBJECT_SECTION_ZERO].virtual_size == BUSTER_MB(2);
            BUSTER_TEST(arguments, payloads_valid);
            ObjectRelocation* restored_relocation = restored.relocations;
            bool relocation_valid = restored_relocation[0].kind == OBJECT_RELOCATION_ABSOLUTE64 && restored_relocation[0].offset == 0 &&
                                   restored_relocation[0].addend == 0 && restored_relocation[0].section < restored.section_count &&
                                   restored.sections[restored_relocation[0].section].kind == OBJECT_SECTION_DATA &&
                                   restored_relocation[0].symbol < restored.symbol_count &&
                                   string_equal(restored.symbols[restored_relocation[0].symbol].name, S8("aligned_text"));
            BUSTER_TEST(arguments, relocation_valid);
        }
        ByteSlice artifact_snapshot = {0};
        if (artifact_valid)
        {
            artifact_snapshot = (ByteSlice){
                .pointer = arena_allocate(temporary.arena, u8, artifact.bytes.length),
                .length = artifact.bytes.length,
            };
            memcpy(artifact_snapshot.pointer, artifact.bytes.pointer, artifact.bytes.length);
        }
        u8 overflow_byte = 0;
        ObjectSection oversized_section = {
            .name = S8(".text"),
            .data = {.pointer = &overflow_byte, .length = UINT64_MAX},
            .kind = OBJECT_SECTION_TEXT,
            .alignment = 32768,
        };
        ObjectFile oversized = {
            .sections = &oversized_section,
            .target = object.target,
            .section_count = 1,
        };
        ObjectArtifact failed = object_write(temporary.arena, &oversized, formats[format_index]);
        BUSTER_TEST(arguments, failed.error == OBJECT_ERROR_CAPACITY && !failed.bytes.pointer && !failed.bytes.length);
        bool prior_artifact_unchanged = artifact_valid && artifact_snapshot.pointer &&
                                        artifact_snapshot.length == artifact.bytes.length &&
                                        memcmp(artifact_snapshot.pointer, artifact.bytes.pointer, artifact.bytes.length) == 0;
        BUSTER_TEST(arguments, prior_artifact_unchanged);
        BUSTER_TEST(arguments, artifact_valid && artifact.bytes.length < BUSTER_MB(1));
        arena_set_position(temporary.arena, format_scope.position);
    }
    scratch_end(temporary);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult object_test_elf_thread_local_symbol_identity(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
    {
        Target target = {.cpu_arch = architectures[architecture], .os = OPERATING_SYSTEM_LINUX};
        u8 x86_text[] = {0xc3};
        u8 aarch64_text[] = {0xc0, 0x03, 0x5f, 0xd6};
        ByteSlice text = architectures[architecture] == CPU_ARCH_AARCH64 ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(aarch64_text)
                                                                         : (ByteSlice)BUSTER_ARRAY_TO_SLICE(x86_text);
        u8 data[] = {1, 2, 3, 4};
        ObjectSection sections[OBJECT_SECTION_COUNT] = {0};
        for (u32 kind = 0; kind < OBJECT_SECTION_COUNT; kind += 1)
        {
            sections[kind] = (ObjectSection){
                .name = object_section_name_for_kind((ObjectSectionKind)kind),
                .kind = (ObjectSectionKind)kind,
                .alignment = object_section_default_alignment((ObjectSectionKind)kind),
            };
        }
        sections[OBJECT_SECTION_TEXT].data = text;
        sections[OBJECT_SECTION_TEXT].virtual_size = text.length;
        sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(data);
        sections[OBJECT_SECTION_DATA].virtual_size = sizeof(data);
        sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(data);
        sections[OBJECT_SECTION_THREAD_LOCAL_DATA].virtual_size = sizeof(data);
        sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size = sizeof(data);
        ObjectSymbol symbols[] = {
            {.name = S8("undefined_tls"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true,
             .thread_local_state = OBJECT_SYMBOL_THREAD_LOCAL_YES},
            {.name = S8("undefined_data"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true,
             .thread_local_state = OBJECT_SYMBOL_THREAD_LOCAL_NO},
            {.name = S8("undefined_function"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_FUNCTION, .global = true,
             .thread_local_state = OBJECT_SYMBOL_THREAD_LOCAL_NO},
            {.name = S8("defined_data"), .size = sizeof(data), .section = OBJECT_SECTION_DATA, .kind = OBJECT_SYMBOL_DATA, .global = true},
            {.name = S8("defined_function"), .size = text.length, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
            {.name = S8("defined_tls_data"), .size = sizeof(data), .section = OBJECT_SECTION_THREAD_LOCAL_DATA, .kind = OBJECT_SYMBOL_DATA, .global = true},
            {.name = S8("defined_tls_zero"), .size = sizeof(data), .section = OBJECT_SECTION_THREAD_LOCAL_ZERO, .kind = OBJECT_SYMBOL_DATA, .global = true},
        };
        ObjectFile object = {
            .target = target,
            .sections = sections,
            .symbols = symbols,
            .section_count = OBJECT_SECTION_COUNT,
            .symbol_count = BUSTER_ARRAY_LENGTH(symbols),
        };
        ObjectArtifact artifact = object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64);
        BUSTER_TEST(arguments, artifact.error == OBJECT_ERROR_NONE);
        String8 names[] = {
            S8("undefined_tls"), S8("undefined_data"), S8("undefined_function"), S8("defined_data"),
            S8("defined_function"), S8("defined_tls_data"), S8("defined_tls_zero"),
        };
        u8 expected_types[] = {6, 1, 2, 1, 2, 6, 6};
        if (artifact.error == OBJECT_ERROR_NONE)
        {
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(names); index += 1)
            {
                u8 type = UINT8_MAX;
                bool found = object_test_elf_symbol_type(artifact.bytes, names[index], &type);
                BUSTER_TEST(arguments, found && type == expected_types[index]);
            }
            ObjectFile restored = object_read(arguments->arena, artifact.bytes, target);
            BUSTER_TEST(arguments, restored.error == OBJECT_ERROR_NONE && restored.symbol_count == BUSTER_ARRAY_LENGTH(symbols));
            if (restored.error == OBJECT_ERROR_NONE && restored.symbol_count == BUSTER_ARRAY_LENGTH(symbols))
            {
                u8 expected_states[] = {
                    OBJECT_SYMBOL_THREAD_LOCAL_YES, OBJECT_SYMBOL_THREAD_LOCAL_NO, OBJECT_SYMBOL_THREAD_LOCAL_NO,
                    OBJECT_SYMBOL_THREAD_LOCAL_NO, OBJECT_SYMBOL_THREAD_LOCAL_NO, OBJECT_SYMBOL_THREAD_LOCAL_YES,
                    OBJECT_SYMBOL_THREAD_LOCAL_YES,
                };
                for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(names); index += 1)
                {
                    bool found = false;
                    for (u32 symbol_index = 0; symbol_index < restored.symbol_count; symbol_index += 1)
                    {
                        ObjectSymbol* symbol = restored.symbols + symbol_index;
                        if (string_equal(symbol->name, names[index]))
                        {
                            found = true;
                            BUSTER_TEST(arguments, symbol->thread_local_state == expected_states[index]);
                            break;
                        }
                    }
                    BUSTER_TEST(arguments, found);
                }
                ObjectArtifact rewritten = object_write(arguments->arena, &restored, OBJECT_FORMAT_ELF64);
                BUSTER_TEST(arguments, rewritten.error == OBJECT_ERROR_NONE);
                if (rewritten.error == OBJECT_ERROR_NONE)
                {
                    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(names); index += 1)
                    {
                        u8 type = UINT8_MAX;
                        bool found = object_test_elf_symbol_type(rewritten.bytes, names[index], &type);
                        BUSTER_TEST(arguments, found && type == expected_types[index]);
                    }
                }
            }
        }
    }
    return result;
}

UnitTestResult object_tests(UnitTestArguments* arguments)
{
    UnitTestResult result = object_test_assembly_index_order(arguments);
    UnitTestResult coff_alignment = object_test_coff_section_alignment(arguments);
    result.test_count += coff_alignment.test_count;
    result.succeeded_test_count += coff_alignment.succeeded_test_count;
    UnitTestResult dwarf5 = object_test_dwarf5_sections(arguments);
    result.test_count += dwarf5.test_count;
    result.succeeded_test_count += dwarf5.succeeded_test_count;
    UnitTestResult thread_local_identity = object_test_elf_thread_local_symbol_identity(arguments);
    result.test_count += thread_local_identity.test_count;
    result.succeeded_test_count += thread_local_identity.succeeded_test_count;
    UnitTestResult scaling = object_test_assembly_scaling(arguments);
    result.test_count += scaling.test_count;
    result.succeeded_test_count += scaling.succeeded_test_count;
    UnitTestResult alignment_capacity = object_test_writer_alignment_capacity(arguments);
    result.test_count += alignment_capacity.test_count;
    result.succeeded_test_count += alignment_capacity.succeeded_test_count;
    BUSTER_TEST(arguments, sizeof(CodegenModuleRelocation) == 24);
    BUSTER_TEST(arguments, BUSTER_ALIGN_OF(CodegenModuleRelocation) == 8);
    BUSTER_TEST(arguments, BUSTER_OFFSET_OF(CodegenModuleRelocation, addend) == 0);
    BUSTER_TEST(arguments, BUSTER_OFFSET_OF(CodegenModuleRelocation, symbol) == 8);
    BUSTER_TEST(arguments, BUSTER_OFFSET_OF(CodegenModuleRelocation, offset) == 12);
    BUSTER_TEST(arguments, BUSTER_OFFSET_OF(CodegenModuleRelocation, label_block) == 16);
    BUSTER_TEST(arguments, BUSTER_OFFSET_OF(CodegenModuleRelocation, source) == 20);
    BUSTER_TEST(arguments, BUSTER_OFFSET_OF(CodegenModuleRelocation, label_address) == 21);
    BUSTER_TEST(arguments, BUSTER_OFFSET_OF(CodegenModuleRelocation, kind) == 22);
    BUSTER_TEST(arguments, CODEGEN_MODULE_RELOCATION_COUNT <= UINT8_MAX);

    typedef struct CodegenRelocationKindExpectation CodegenRelocationKindExpectation;
    struct CodegenRelocationKindExpectation
    {
        CodegenModuleRelocationKind kind;
        bool aarch64;
        bool absolute;
        bool is_thread_local;
        bool thread_local_low;
        bool thread_local_index;
    };
    CodegenRelocationKindExpectation relocation_kinds[] = {
        {CODEGEN_MODULE_RELOCATION_X86_64_PC32, false, false, false, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_CALL26, true, false, false, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_BRANCH26, true, false, false, false, false},
        {CODEGEN_MODULE_RELOCATION_ABSOLUTE32, false, true, false, false, false},
        {CODEGEN_MODULE_RELOCATION_ABSOLUTE64, false, true, false, false, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_TPOFF32, false, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_GOTTPOFF, false, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_TLSGD, false, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_TLS_GET_ADDR_PLT32, false, false, false, false, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_PE_TLS_INDEX_PC32, false, false, true, false, true},
        {CODEGEN_MODULE_RELOCATION_PE_TLS_OFFSET32, false, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_PE_TLS_INDEX_ADRP, true, false, true, false, true},
        {CODEGEN_MODULE_RELOCATION_AARCH64_PE_TLS_INDEX_LO12, true, false, true, true, true},
        {CODEGEN_MODULE_RELOCATION_AARCH64_PE_TLS_OFFSET12, true, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_TLSLE_ADD_TPREL_HI12, true, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_TLSLE_ADD_TPREL_LO12, true, false, true, true, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_MACH_TLV_PC32, false, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_MACH_TLVP_PAGE21, true, false, true, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_MACH_TLVP_PAGEOFF12, true, false, true, true, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_MACH_PAGE21, true, false, false, false, false},
        {CODEGEN_MODULE_RELOCATION_AARCH64_MACH_PAGEOFF12, true, false, false, false, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_GOTPCREL, false, false, false, false, false},
        {CODEGEN_MODULE_RELOCATION_X86_64_PLT32, false, false, false, false, false},
    };
    BUSTER_TEST(arguments, BUSTER_ARRAY_LENGTH(relocation_kinds) == CODEGEN_MODULE_RELOCATION_COUNT);
    for (u32 kind_index = 0; kind_index < BUSTER_ARRAY_LENGTH(relocation_kinds); kind_index += 1)
    {
        CodegenRelocationKindExpectation expectation = relocation_kinds[kind_index];
        CodegenModuleRelocation relocation = {
            .kind = (u8)expectation.kind,
        };
        BUSTER_TEST(arguments, codegen_module_relocation_kind_valid(relocation.kind));
        BUSTER_TEST(arguments, codegen_module_relocation_kind_is_aarch64(relocation.kind) == expectation.aarch64);
        BUSTER_TEST(arguments, codegen_module_relocation_kind_is_absolute(relocation.kind) == expectation.absolute);
        BUSTER_TEST(arguments, codegen_module_relocation_kind_is_thread_local(relocation.kind) == expectation.is_thread_local);
        BUSTER_TEST(arguments, codegen_module_relocation_kind_is_thread_local_low(relocation.kind) == expectation.thread_local_low);
        BUSTER_TEST(arguments, codegen_module_relocation_kind_is_thread_local_index(relocation.kind) == expectation.thread_local_index);
        BUSTER_TEST(arguments, codegen_module_relocation_valid(&relocation));
        relocation.label_address = true;
        BUSTER_TEST(arguments, codegen_module_relocation_valid(&relocation) ==
                                   (expectation.kind == CODEGEN_MODULE_RELOCATION_ABSOLUTE64));
    }

    CodegenModuleRelocation zero_relocation = {0};
    BUSTER_TEST(arguments, codegen_module_relocation_valid(&zero_relocation));
    BUSTER_TEST(arguments, !codegen_module_relocation_valid(0));
    for (u8 source = 0; source < CODEGEN_MODULE_RELOCATION_SOURCE_COUNT; source += 1)
    {
        CodegenModuleRelocation relocation = {
            .source = source,
        };
        BUSTER_TEST(arguments, codegen_module_relocation_valid(&relocation));
    }

    CodegenModuleRelocation invalid_relocation = {
        .kind = CODEGEN_MODULE_RELOCATION_COUNT,
    };
    BUSTER_TEST(arguments, !codegen_module_relocation_kind_valid(invalid_relocation.kind));
    BUSTER_TEST(arguments, !codegen_module_relocation_valid(&invalid_relocation));
    invalid_relocation = (CodegenModuleRelocation){
        .kind = UINT8_MAX,
    };
    BUSTER_TEST(arguments, !codegen_module_relocation_kind_valid(invalid_relocation.kind));
    BUSTER_TEST(arguments, !codegen_module_relocation_valid(&invalid_relocation));
    BUSTER_TEST(arguments, !codegen_module_relocation_kind_is_aarch64(invalid_relocation.kind));
    BUSTER_TEST(arguments, !codegen_module_relocation_kind_is_absolute(invalid_relocation.kind));
    BUSTER_TEST(arguments, !codegen_module_relocation_kind_is_thread_local(invalid_relocation.kind));
    BUSTER_TEST(arguments, !codegen_module_relocation_kind_is_thread_local_low(invalid_relocation.kind));
    BUSTER_TEST(arguments, !codegen_module_relocation_kind_is_thread_local_index(invalid_relocation.kind));
    invalid_relocation = (CodegenModuleRelocation){
        .source = CODEGEN_MODULE_RELOCATION_SOURCE_COUNT,
    };
    BUSTER_TEST(arguments, !codegen_module_relocation_valid(&invalid_relocation));

    u8 x86_text[] = {
        0xe8, 0, 0, 0, 0, 0xc3, 0xb8, 42, 0, 0, 0, 0xc3,
    };
    u8 aarch64_text[] = {
        0xfd, 0x7b, 0xbf, 0xa9, 0x00, 0x00, 0x00, 0x94, 0xfd, 0x7b, 0xc1, 0xa8, 0xc0, 0x03, 0x5f, 0xd6, 0x40, 0x05, 0x80, 0x52, 0xc0, 0x03, 0x5f, 0xd6,
    };
    u8 read_only_data[] = {
        'h', 'e', 'l', 'l', 'o', 0,
    };
    u8 writable_data[8] = {0};
    ObjectSection sections[] = {
        {
            .name = S8(".text"),
            .data = BUSTER_ARRAY_TO_SLICE(x86_text),
            .kind = OBJECT_SECTION_TEXT,
            .alignment = 16,
        },
        {
            .name = S8(".rodata"),
            .data = BUSTER_ARRAY_TO_SLICE(read_only_data),
            .kind = OBJECT_SECTION_READ_ONLY_DATA,
            .alignment = 1,
        },
        {
            .name = S8(".data"),
            .data = BUSTER_ARRAY_TO_SLICE(writable_data),
            .kind = OBJECT_SECTION_DATA,
            .alignment = 8,
        },
        {
            .name = S8(".bss"),
            .virtual_size = BUSTER_MB(1),
            .kind = OBJECT_SECTION_ZERO,
            .alignment = 64,
        },
    };
    ObjectSymbol symbols[] = {
        {
            .name = S8("object_entry"),
            .size = 6,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("object_callee"),
            .value = 6,
            .size = 6,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("object_message"),
            .size = sizeof(read_only_data),
            .section = OBJECT_SECTION_READ_ONLY_DATA,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
        {
            .name = S8("external_function"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("object_zero"),
            .size = BUSTER_MB(1),
            .section = OBJECT_SECTION_ZERO,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectRelocation relocation = {
        .addend = -4,
        .offset = 1,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_PC32,
    };
    ObjectFile object = {
        .sections = sections,
        .symbols = symbols,
        .relocations = &relocation,
        .target =
            {
                .cpu_arch = CPU_ARCH_X86_64,
                .os = OPERATING_SYSTEM_LINUX,
            },
        .section_count = BUSTER_ARRAY_LENGTH(sections),
        .symbol_count = BUSTER_ARRAY_LENGTH(symbols),
        .relocation_count = 1,
    };
    u8 x86_accumulator_extend[] = {0x66, 0x98, 0x98, 0x48, 0x98};
    ObjectSection accumulator_extend_section = {
        .name = S8(".text"),
        .data = BUSTER_ARRAY_TO_SLICE(x86_accumulator_extend),
        .kind = OBJECT_SECTION_TEXT,
        .alignment = 1,
    };
    ObjectFile accumulator_extend_object = {
        .sections = &accumulator_extend_section,
        .target = object.target,
        .section_count = 1,
    };
    String8 accumulator_extend_assembly = object_print_assembly(arguments->arena, &accumulator_extend_object);
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(accumulator_extend_assembly), S8("\tcbw\n\tcwde\n\tcdqe\n")));
    u8 x86_mmx[] = {0x0f, 0x6f, 0xc1, 0x0f, 0xef, 0xc2, 0x0f, 0xfc, 0xc3, 0x0f, 0xfe, 0xc4};
    ObjectSection mmx_section = {
        .name = S8(".text"),
        .data = BUSTER_ARRAY_TO_SLICE(x86_mmx),
        .kind = OBJECT_SECTION_TEXT,
        .alignment = 1,
    };
    ObjectFile mmx_object = {
        .sections = &mmx_section,
        .target = object.target,
        .section_count = 1,
    };
    String8 mmx_assembly = object_print_assembly(arguments->arena, &mmx_object);
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(mmx_assembly),
                                                S8("\tmovq mm0, mm1\n\tpxor mm0, mm2\n\tpaddb mm0, mm3\n\tpaddd mm0, mm4\n")));
    ObjectFormat formats[] = {
        OBJECT_FORMAT_ELF64,
        OBJECT_FORMAT_COFF,
        OBJECT_FORMAT_MACH_O64,
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(formats); index += 1)
    {
        ObjectArtifact artifact = object_write(arguments->arena, &object, formats[index]);
        BUSTER_TEST(arguments, artifact.error == OBJECT_ERROR_NONE);
        BUSTER_TEST(arguments, artifact.bytes.length > 64);
        BUSTER_TEST(arguments, artifact.bytes.length < BUSTER_MB(1));
        BUSTER_TEST(arguments, object_bytes_contain(artifact.bytes, S8("object_entry")));
        BUSTER_TEST(arguments, object_bytes_contain(artifact.bytes, S8("external_function")));
        BUSTER_TEST(arguments, object_bytes_contain(artifact.bytes, S8("hello")));
    }
    ObjectRelocation section_relocations[] = {
        relocation,
        {
            .addend = 2,
            .offset = 0,
            .section = OBJECT_SECTION_DATA,
            .symbol = 2,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        },
    };
    ObjectFile section_relocation_object = object;
    section_relocation_object.relocations = section_relocations;
    section_relocation_object.relocation_count = BUSTER_ARRAY_LENGTH(section_relocations);
    ObjectArtifact section_relocation_elf = object_write(arguments->arena, &section_relocation_object, OBJECT_FORMAT_ELF64);
    BUSTER_TEST(arguments, section_relocation_elf.error == OBJECT_ERROR_NONE);
    BUSTER_TEST(arguments, object_bytes_contain(section_relocation_elf.bytes, S8(".rela.data")));
    ObjectArtifact elf = object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64);
    bool elf_magic_matches = false;
    if (elf.bytes.pointer && elf.bytes.length >= 4)
    {
        elf_magic_matches = elf.bytes.pointer[0] == 0x7f && elf.bytes.pointer[1] == 'E' && elf.bytes.pointer[2] == 'L' && elf.bytes.pointer[3] == 'F';
    }
    BUSTER_TEST(arguments, elf_magic_matches);
    // Capacity checks in object readers are part of malformed-input handling,
    // not optimizer assumptions. A deliberately tiny result arena must reject
    // an otherwise valid object without attempting the checked allocation.
    {
        Arena* constrained_arena = arena_create((ArenaCreation){
            .reserved_size = arena_minimum_position + 1,
            .initial_size = arena_minimum_position,
            .granularity = 1,
            .flags = {.no_pool = 1},
        });
        BUSTER_TEST(arguments, constrained_arena != 0);
        if (constrained_arena)
        {
            ObjectFile constrained = object_read(constrained_arena, elf.bytes, object.target);
            BUSTER_TEST(arguments, constrained.error == OBJECT_ERROR_INVALID_INPUT);
            BUSTER_TEST(arguments, arena_destroy(constrained_arena, 1));
        }
    }
    UnitTestResult capacity_tests = object_test_elf_arena_capacities(arguments, elf.bytes, object.target);
    result.succeeded_test_count += capacity_tests.succeeded_test_count;
    result.test_count += capacity_tests.test_count;
    ObjectFile elf_roundtrip = object_read(arguments->arena, elf.bytes, object.target);
    bool elf_roundtrip_valid = BUSTER_REQUIRE(arguments, elf_roundtrip.error == OBJECT_ERROR_NONE);
    BUSTER_TEST(arguments, elf_roundtrip.section_count == OBJECT_SECTION_COUNT);
    BUSTER_TEST(arguments, elf_roundtrip.symbol_count == object.symbol_count);
    BUSTER_TEST(arguments, elf_roundtrip.relocation_count == object.relocation_count);
    bool elf_sections_valid = elf_roundtrip_valid && elf_roundtrip.sections && elf_roundtrip.section_count > OBJECT_SECTION_TEXT &&
                              elf_roundtrip.sections[OBJECT_SECTION_TEXT].data.pointer;
    BUSTER_TEST(arguments, elf_sections_valid);
    if (elf_sections_valid)
    {
        BUSTER_TEST(arguments, elf_roundtrip.sections[OBJECT_SECTION_TEXT].data.length == sizeof(x86_text));
        BUSTER_TEST(arguments, memcmp(elf_roundtrip.sections[OBJECT_SECTION_TEXT].data.pointer, x86_text, sizeof(x86_text)) == 0);
    }
    bool elf_zero_section_valid = elf_roundtrip_valid && elf_roundtrip.sections && elf_roundtrip.section_count > OBJECT_SECTION_ZERO;
    BUSTER_TEST(arguments, elf_zero_section_valid);
    if (elf_zero_section_valid)
    {
        BUSTER_TEST(arguments, elf_roundtrip.sections[OBJECT_SECTION_ZERO].data.length == 0);
        BUSTER_TEST(arguments, elf_roundtrip.sections[OBJECT_SECTION_ZERO].virtual_size == BUSTER_MB(1));
    }
    // A `constructor(N)` priority survives a write and a read (issues 789 and
    // 795).  The writer spells it in the section name -- one section per
    // group, in the convention that format's linker orders by -- and this
    // model has one section per kind, so the reader has to put the name back
    // into the per-entry priorities: they are what the linker orders a whole
    // program's constructors by, and it is also the one place an external
    // producer's spelling reaches this compiler.  The entries come back merged
    // in that order, so the priorities do too.
    {
        ObjectSection* initializer_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
        for (u32 kind = 0; kind < OBJECT_SECTION_COUNT; kind += 1)
        {
            initializer_sections[kind] = (ObjectSection){
                .name = object_section_name_for_kind((ObjectSectionKind)kind),
                .kind = (ObjectSectionKind)kind,
                .alignment = object_section_default_alignment((ObjectSectionKind)kind),
            };
        }
        initializer_sections[OBJECT_SECTION_TEXT].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(x86_text);
        u8 initializer_entries[3 * OBJECT_INITIALIZER_ENTRY_SIZE] = {0};
        u8 terminator_entries[2 * OBJECT_INITIALIZER_ENTRY_SIZE] = {0};
        initializer_sections[OBJECT_SECTION_INIT_ARRAY].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(initializer_entries);
        // The terminator array carries a priority the same way, in the group
        // one letter along -- `.fini_array.NNNNN` and `.CRT$XTA00101` -- so it
        // is here to keep that half of every spelling covered.
        initializer_sections[OBJECT_SECTION_FINI_ARRAY].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(terminator_entries);
        // Written in the order the converter sorts them into, which is the
        // shape the writer's split expects: ascending, the run that named no
        // priority last.
        u32 written_priorities[] = {101, 150, IR_INITIALIZER_PRIORITY_NONE};
        u32 written_terminator_priorities[] = {101, IR_INITIALIZER_PRIORITY_NONE};
        ObjectSymbol initializer_symbols[] = {
            {.name = S8("initializer_earliest"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
            {.name = S8("initializer_latest"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
            {.name = S8("initializer_plain"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
        };
        ObjectRelocation initializer_relocations[] = {
            {.section = OBJECT_SECTION_INIT_ARRAY, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = OBJECT_INITIALIZER_ENTRY_SIZE, .section = OBJECT_SECTION_INIT_ARRAY, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 2 * OBJECT_INITIALIZER_ENTRY_SIZE, .section = OBJECT_SECTION_INIT_ARRAY, .symbol = 2, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.section = OBJECT_SECTION_FINI_ARRAY, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = OBJECT_INITIALIZER_ENTRY_SIZE, .section = OBJECT_SECTION_FINI_ARRAY, .symbol = 2, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        };
        ObjectFile initializer_object = {
            .sections = initializer_sections,
            .symbols = initializer_symbols,
            .relocations = initializer_relocations,
            .target = object.target,
            .section_count = OBJECT_SECTION_COUNT,
            .symbol_count = BUSTER_ARRAY_LENGTH(initializer_symbols),
            .relocation_count = BUSTER_ARRAY_LENGTH(initializer_relocations),
            .initializer_priorities = {written_priorities, written_terminator_priorities},
        };
        ObjectArtifact initializer_elf = object_write(arguments->arena, &initializer_object, OBJECT_FORMAT_ELF64);
        BUSTER_TEST(arguments, initializer_elf.error == OBJECT_ERROR_NONE);
        BUSTER_TEST(arguments, object_bytes_contain(initializer_elf.bytes, S8(".init_array.00101")));
        BUSTER_TEST(arguments, object_bytes_contain(initializer_elf.bytes, S8(".fini_array.00101")));
        ObjectFile initializer_roundtrip = object_read(arguments->arena, initializer_elf.bytes, initializer_object.target);
        bool initializer_read_valid = initializer_roundtrip.error == OBJECT_ERROR_NONE && initializer_roundtrip.initializer_priorities[0] &&
                                      initializer_roundtrip.initializer_priorities[1] && initializer_roundtrip.sections &&
                                      initializer_roundtrip.section_count > OBJECT_SECTION_FINI_ARRAY &&
                                      initializer_roundtrip.sections[OBJECT_SECTION_INIT_ARRAY].data.length == sizeof(initializer_entries) &&
                                      initializer_roundtrip.sections[OBJECT_SECTION_FINI_ARRAY].data.length == sizeof(terminator_entries);
        if (BUSTER_REQUIRE(arguments, initializer_read_valid))
        {
            for (u64 entry = 0; entry < BUSTER_ARRAY_LENGTH(written_priorities); entry += 1)
            {
                BUSTER_TEST(arguments, initializer_roundtrip.initializer_priorities[0][entry] == written_priorities[entry]);
            }
            // The entry that named no priority keeps the unsuffixed section
            // and comes back last, which is where `ld` puts it.
            for (u64 entry = 0; entry < BUSTER_ARRAY_LENGTH(written_terminator_priorities); entry += 1)
            {
                BUSTER_TEST(arguments, initializer_roundtrip.initializer_priorities[1][entry] == written_terminator_priorities[entry]);
            }
            String8 expected_initializer_names[] = {
                S8("initializer_earliest"), S8("initializer_latest"), S8("initializer_plain"),
            };
            u32 initializer_entries_found = 0;
            for (u32 relocation_index = 0; relocation_index < initializer_roundtrip.relocation_count; relocation_index += 1)
            {
                ObjectRelocation read_relocation = initializer_roundtrip.relocations[relocation_index];
                u64 entry = read_relocation.offset / OBJECT_INITIALIZER_ENTRY_SIZE;
                if (read_relocation.section != OBJECT_SECTION_INIT_ARRAY || entry >= BUSTER_ARRAY_LENGTH(expected_initializer_names) ||
                    read_relocation.symbol >= initializer_roundtrip.symbol_count)
                {
                    continue;
                }
                BUSTER_TEST(arguments, string_equal(initializer_roundtrip.symbols[read_relocation.symbol].name, expected_initializer_names[entry]));
                initializer_entries_found += 1;
            }
            BUSTER_TEST(arguments, initializer_entries_found == BUSTER_ARRAY_LENGTH(expected_initializer_names));
        }
        // The other two formats must come back as the arrays they were
        // written as: read as data, the entries reach no initializer plan at
        // all and a program linked from an object runs no constructor.  COFF
        // states the priority as well, in the `.CRT$XC*` group MSVC's linker
        // orders lexicographically and Clang emits into; a Mach-O section name
        // has no room past `__mod_init_func` and the platform has no other
        // carrier, so that format states none and its priorities come back
        // null -- every entry unprioritized, which leaves the arrays in link
        // order (issue 795).
        ObjectFormat initializer_formats[] = {OBJECT_FORMAT_COFF, OBJECT_FORMAT_MACH_O64};
        OperatingSystem initializer_systems[] = {OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_MACOS};
        for (u64 format_index = 0; format_index < BUSTER_ARRAY_LENGTH(initializer_formats); format_index += 1)
        {
            bool states_priorities = initializer_formats[format_index] == OBJECT_FORMAT_COFF;
            ObjectArtifact initializer_artifact = object_write(arguments->arena, &initializer_object, initializer_formats[format_index]);
            BUSTER_TEST(arguments, initializer_artifact.error == OBJECT_ERROR_NONE);
            // The group names, which are the whole carrier: `A` sorts before
            // `U`, so `link.exe` and `lld-link` put the two prioritized groups
            // ahead of what named none exactly as `ld` does.
            BUSTER_TEST(arguments, object_bytes_contain(initializer_artifact.bytes, S8(".CRT$XCA00101")) == states_priorities);
            BUSTER_TEST(arguments, object_bytes_contain(initializer_artifact.bytes, S8(".CRT$XCA00150")) == states_priorities);
            BUSTER_TEST(arguments, object_bytes_contain(initializer_artifact.bytes, S8(".CRT$XCU")) == states_priorities);
            BUSTER_TEST(arguments, object_bytes_contain(initializer_artifact.bytes, S8(".CRT$XTA00101")) == states_priorities);
            BUSTER_TEST(arguments, object_bytes_contain(initializer_artifact.bytes, S8(".CRT$XTX")) == states_priorities);
            ObjectFile initializer_read = object_read(arguments->arena, initializer_artifact.bytes,
                                                      (Target){
                                                          .cpu_arch = CPU_ARCH_X86_64,
                                                          .os = initializer_systems[format_index],
                                                      });
            BUSTER_TEST(arguments, initializer_read.error == OBJECT_ERROR_NONE);
            if (initializer_read.error != OBJECT_ERROR_NONE)
            {
                continue;
            }
            BUSTER_TEST(arguments, initializer_read.sections[OBJECT_SECTION_INIT_ARRAY].data.length == sizeof(initializer_entries));
            BUSTER_TEST(arguments, initializer_read.sections[OBJECT_SECTION_INIT_ARRAY].kind == OBJECT_SECTION_INIT_ARRAY);
            BUSTER_TEST(arguments, initializer_read.sections[OBJECT_SECTION_FINI_ARRAY].data.length == sizeof(terminator_entries));
            u32 initializer_read_found = 0;
            u32 terminator_read_found = 0;
            for (u32 relocation_index = 0; relocation_index < initializer_read.relocation_count; relocation_index += 1)
            {
                initializer_read_found += initializer_read.relocations[relocation_index].section == OBJECT_SECTION_INIT_ARRAY ? 1 : 0;
                terminator_read_found += initializer_read.relocations[relocation_index].section == OBJECT_SECTION_FINI_ARRAY ? 1 : 0;
            }
            BUSTER_TEST(arguments, initializer_read_found == BUSTER_ARRAY_LENGTH(written_priorities));
            BUSTER_TEST(arguments, terminator_read_found == BUSTER_ARRAY_LENGTH(written_terminator_priorities));
            BUSTER_TEST(arguments, (initializer_read.initializer_priorities[0] != 0) == states_priorities);
            BUSTER_TEST(arguments, (initializer_read.initializer_priorities[1] != 0) == states_priorities);
            for (u64 entry = 0; states_priorities && entry < BUSTER_ARRAY_LENGTH(written_priorities); entry += 1)
            {
                BUSTER_TEST(arguments, initializer_read.initializer_priorities[0][entry] == written_priorities[entry]);
            }
            for (u64 entry = 0; states_priorities && entry < BUSTER_ARRAY_LENGTH(written_terminator_priorities); entry += 1)
            {
                BUSTER_TEST(arguments, initializer_read.initializer_priorities[1][entry] == written_terminator_priorities[entry]);
            }
        }
    }
    bool elf_relocation_valid = elf_roundtrip.relocations && elf_roundtrip.relocation_count && elf_roundtrip.symbols &&
                                elf_roundtrip.relocations[0].symbol < elf_roundtrip.symbol_count;
    BUSTER_TEST(arguments, elf_relocation_valid);
    if (elf_relocation_valid)
    {
        BUSTER_TEST(arguments, elf_roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_PC32);
        BUSTER_TEST(arguments, elf_roundtrip.relocations[0].addend == -4);
        BUSTER_STRING_TEST(arguments, elf_roundtrip.symbols[elf_roundtrip.relocations[0].symbol].name, S8("object_callee"));
    }
    // Clang's non-PIC x86-64 output uses the signed absolute relocation for
    // addresses that must sign-extend from a 32-bit field.  Preserve its kind
    // and signed REL addend instead of collapsing it into unsigned ABS32.
    ObjectRelocation absolute32s_relocation = relocation;
    absolute32s_relocation.kind = OBJECT_RELOCATION_X86_64_ABSOLUTE32S;
    ObjectFile absolute32s_object = object;
    absolute32s_object.relocations = &absolute32s_relocation;
    ObjectArtifact absolute32s_elf = object_write(arguments->arena, &absolute32s_object, OBJECT_FORMAT_ELF64);
    ObjectFile absolute32s_roundtrip = object_read(arguments->arena, absolute32s_elf.bytes, absolute32s_object.target);
    BUSTER_TEST(arguments, absolute32s_elf.error == OBJECT_ERROR_NONE && absolute32s_roundtrip.error == OBJECT_ERROR_NONE &&
                               absolute32s_roundtrip.relocation_count == 1 &&
                               absolute32s_roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_ABSOLUTE32S &&
                               absolute32s_roundtrip.relocations[0].addend == -4);
    u64 absolute32s_relocation_section = 0;
    u64 absolute32s_target_data = 0;
    bool absolute32s_offsets_valid = object_test_elf_relocation_offsets(absolute32s_elf.bytes, &absolute32s_relocation_section, &absolute32s_target_data);
    u64 absolute32s_relocation_data = 0;
    if (absolute32s_offsets_valid)
    {
        memcpy(&absolute32s_relocation_data, absolute32s_elf.bytes.pointer + absolute32s_relocation_section + 24, sizeof(absolute32s_relocation_data));
        // Convert this synthetic RELA object to REL and put the signed
        // addend in the relocated word, as clang can do for SHT_REL inputs.
        object_test_write_u32(absolute32s_elf.bytes, absolute32s_relocation_section + 4, 9);
        object_test_write_u64(absolute32s_elf.bytes, absolute32s_relocation_section + 32, 16);
        object_test_write_u64(absolute32s_elf.bytes, absolute32s_relocation_section + 56, 16);
        object_test_write_u32(absolute32s_elf.bytes, absolute32s_target_data + absolute32s_relocation.offset, UINT32_C(0xfffffffc));
    }
    ObjectFile absolute32s_rel_roundtrip = object_read(arguments->arena, absolute32s_elf.bytes, absolute32s_object.target);
    BUSTER_TEST(arguments, absolute32s_offsets_valid && absolute32s_rel_roundtrip.error == OBJECT_ERROR_NONE &&
                               absolute32s_rel_roundtrip.relocation_count == 1 &&
                               absolute32s_rel_roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_ABSOLUTE32S &&
                               absolute32s_rel_roundtrip.relocations[0].addend == -4);
    // Each GOTPCREL spelling keeps its own kind on the way in, which is what
    // lets a -fPIC object -- this compiler's or clang's -- be linked here at
    // all: the relaxable spellings also say how many bytes of the instruction
    // precede the field, and the linker rewrites a different instruction
    // without that.  Every kind writes its own type back out.  Local dynamic
    // is the one thread-local model with no kind, and the refusal names it.
    u32 gotpc_rel_types[] = {9, 41, 42, 43};
    ObjectRelocationKind gotpc_rel_kinds[] = {OBJECT_RELOCATION_X86_64_GOTPCREL, OBJECT_RELOCATION_X86_64_GOTPCRELX,
                                              OBJECT_RELOCATION_X86_64_REX_GOTPCRELX, OBJECT_RELOCATION_X86_64_CODE_4_GOTPCRELX};
    for (u32 type_index = 0; type_index < BUSTER_ARRAY_LENGTH(gotpc_rel_types); type_index += 1)
    {
        ObjectArtifact gotpc_rel_elf = object_write(arguments->arena, &absolute32s_object, OBJECT_FORMAT_ELF64);
        u64 gotpc_rel_section = 0;
        u64 gotpc_rel_target_data = 0;
        bool gotpc_rel_offsets_valid = object_test_elf_relocation_offsets(gotpc_rel_elf.bytes, &gotpc_rel_section, &gotpc_rel_target_data);
        u64 gotpc_rel_data = 0;
        if (gotpc_rel_offsets_valid)
        {
            memcpy(&gotpc_rel_data, gotpc_rel_elf.bytes.pointer + gotpc_rel_section + 24, sizeof(gotpc_rel_data));
            object_test_write_u32(gotpc_rel_elf.bytes, gotpc_rel_data + 8, gotpc_rel_types[type_index]);
        }
        ObjectFile gotpc_rel_roundtrip = object_read(arguments->arena, gotpc_rel_elf.bytes, absolute32s_object.target);
        BUSTER_TEST(arguments, gotpc_rel_offsets_valid && gotpc_rel_roundtrip.error == OBJECT_ERROR_NONE &&
                                   gotpc_rel_roundtrip.relocation_count == 1 &&
                                   gotpc_rel_roundtrip.relocations[0].kind == gotpc_rel_kinds[type_index] &&
                                   object_relocation_kind_is_x86_got(gotpc_rel_roundtrip.relocations[0].kind));
        ObjectArtifact gotpc_rel_written = object_write(arguments->arena, &gotpc_rel_roundtrip, OBJECT_FORMAT_ELF64);
        u64 gotpc_rel_written_section = 0;
        u64 gotpc_rel_written_target = 0;
        u64 gotpc_rel_written_data = 0;
        u32 gotpc_rel_written_type = 0;
        bool gotpc_rel_written_valid =
            object_test_elf_relocation_offsets(gotpc_rel_written.bytes, &gotpc_rel_written_section, &gotpc_rel_written_target);
        if (gotpc_rel_written_valid)
        {
            memcpy(&gotpc_rel_written_data, gotpc_rel_written.bytes.pointer + gotpc_rel_written_section + 24, sizeof(gotpc_rel_written_data));
            memcpy(&gotpc_rel_written_type, gotpc_rel_written.bytes.pointer + gotpc_rel_written_data + 8, sizeof(gotpc_rel_written_type));
        }
        BUSTER_TEST(arguments, gotpc_rel_written_valid && gotpc_rel_written_type == gotpc_rel_types[type_index]);
    }
    ObjectArtifact tls_local_dynamic_elf = object_write(arguments->arena, &absolute32s_object, OBJECT_FORMAT_ELF64);
    u64 tls_local_dynamic_section = 0;
    u64 tls_local_dynamic_target_data = 0;
    bool tls_local_dynamic_offsets_valid =
        object_test_elf_relocation_offsets(tls_local_dynamic_elf.bytes, &tls_local_dynamic_section, &tls_local_dynamic_target_data);
    u64 tls_local_dynamic_data = 0;
    if (tls_local_dynamic_offsets_valid)
    {
        memcpy(&tls_local_dynamic_data, tls_local_dynamic_elf.bytes.pointer + tls_local_dynamic_section + 24, sizeof(tls_local_dynamic_data));
        object_test_write_u32(tls_local_dynamic_elf.bytes, tls_local_dynamic_data + 8, 20);
    }
    ObjectFile tls_local_dynamic_roundtrip = object_read(arguments->arena, tls_local_dynamic_elf.bytes, absolute32s_object.target);
    BUSTER_TEST(arguments, tls_local_dynamic_offsets_valid && tls_local_dynamic_roundtrip.error == OBJECT_ERROR_UNSUPPORTED_TARGET &&
                               object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(tls_local_dynamic_roundtrip.diagnostic), S8("R_X86_64_TLSLD")));
    ObjectArtifact coff = object_write(arguments->arena, &object, OBJECT_FORMAT_COFF);
    ObjectFile coff_roundtrip = object_read(arguments->arena, coff.bytes,
                                            (Target){
                                                .cpu_arch = CPU_ARCH_X86_64,
                                                .os = OPERATING_SYSTEM_WINDOWS,
                                            });
    if (BUSTER_REQUIRE(arguments, coff_roundtrip.error == OBJECT_ERROR_NONE))
    {
        BUSTER_TEST(arguments, coff_roundtrip.symbol_count == object.symbol_count);
        BUSTER_TEST(arguments, coff_roundtrip.relocation_count == object.relocation_count);
        if (BUSTER_REQUIRE(arguments, coff_roundtrip.sections && coff_roundtrip.section_count > OBJECT_SECTION_ZERO))
        {
            BUSTER_TEST(arguments, coff_roundtrip.sections[OBJECT_SECTION_ZERO].data.length == 0);
            BUSTER_TEST(arguments, coff_roundtrip.sections[OBJECT_SECTION_ZERO].virtual_size == BUSTER_MB(1));
        }
        bool coff_relocation_valid = coff_roundtrip.relocations && coff_roundtrip.relocation_count && coff_roundtrip.symbols &&
                                     coff_roundtrip.relocations[0].symbol < coff_roundtrip.symbol_count;
        if (BUSTER_REQUIRE(arguments, coff_relocation_valid))
        {
            BUSTER_TEST(arguments, coff_roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_PC32);
            BUSTER_TEST(arguments, coff_roundtrip.relocations[0].addend == -4);
            BUSTER_STRING_TEST(arguments, coff_roundtrip.symbols[coff_roundtrip.relocations[0].symbol].name, S8("object_callee"));
        }
    }

    {
        // The standard COFF count is a 16-bit real-entry count. In overflow
        // form it stays 0xffff and the first record's VirtualAddress is N+1,
        // since that 32-bit count includes the marker itself.
        u32 coff_relocation_counts[] = {UINT16_MAX - 1, UINT16_MAX, UINT16_MAX + 1, UINT16_MAX + 2};
        CpuArch coff_architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
        for (u32 architecture_index = 0; architecture_index < BUSTER_ARRAY_LENGTH(coff_architectures); architecture_index += 1)
        {
            Target target = {
                .cpu_arch = coff_architectures[architecture_index],
                .os = OPERATING_SYSTEM_WINDOWS,
            };
            u16 expected_relocation_type = target.cpu_arch == CPU_ARCH_AARCH64 ? 0x000e : 0x0001;
            for (u32 count_index = 0; count_index < BUSTER_ARRAY_LENGTH(coff_relocation_counts); count_index += 1)
            {
                u32 relocation_count = coff_relocation_counts[count_index];
                bool relocation_overflow = relocation_count > UINT16_MAX;
                TemporalArena overflow_scope = arena_begin_temporal(arguments->arena);

                // These bytes are assembled independently of object_write.
                // The real relocations end exactly at the symbol table, so a
                // reader that counts the marker as real consumes symbol bytes.
                ByteSlice external_bytes =
                    object_test_coff_relocation_count_object(arguments->arena, target.cpu_arch, relocation_count);
                ObjectFile external_read = object_read(arguments->arena, external_bytes, target);
                bool external_read_valid = external_read.error == OBJECT_ERROR_NONE && external_read.relocations &&
                                           external_read.symbols && external_read.relocation_count == relocation_count &&
                                           external_read.symbol_count == 1;
                if (BUSTER_REQUIRE(arguments, external_read_valid))
                {
                    ObjectRelocation* first = external_read.relocations;
                    ObjectRelocation* last = external_read.relocations + relocation_count - 1;
                    BUSTER_STRING_TEST(arguments, external_read.symbols[0].name, S8("external"));
                    BUSTER_TEST(arguments, first->offset == 0 && first->symbol == 0 && first->addend == -17);
                    BUSTER_TEST(arguments, last->offset == (u64)(relocation_count - 1) * sizeof(u64) &&
                                               last->symbol == 0 && last->addend == 23);
                }

                u64 data_size = (u64)relocation_count * sizeof(u64);
                u8* data = arena_allocate(arguments->arena, u8, data_size);
                memset(data, 0, data_size);
                ObjectSection section = {
                    .name = S8(".data"),
                    .data = {.pointer = data, .length = data_size},
                    .kind = OBJECT_SECTION_DATA,
                    .alignment = 8,
                };
                ObjectSymbol symbol = {
                    .name = S8("external"),
                    .section = OBJECT_SECTION_UNDEFINED,
                    .kind = OBJECT_SYMBOL_DATA,
                    .global = true,
                };
                ObjectRelocation* relocations = arena_allocate(arguments->arena, ObjectRelocation, relocation_count);
                for (u32 relocation_index = 0; relocation_index < relocation_count; relocation_index += 1)
                {
                    relocations[relocation_index] = (ObjectRelocation){
                        .addend = relocation_index == 0 ? -17 : relocation_index + 1 == relocation_count ? 23 : 0,
                        .offset = (u64)relocation_index * sizeof(u64),
                        .section = 0,
                        .symbol = 0,
                        .kind = OBJECT_RELOCATION_ABSOLUTE64,
                    };
                }
                ObjectFile writer_input = {
                    .sections = &section,
                    .symbols = &symbol,
                    .relocations = relocations,
                    .target = target,
                    .section_count = 1,
                    .symbol_count = 1,
                    .relocation_count = relocation_count,
                };
                ObjectArtifact written = object_write(arguments->arena, &writer_input, OBJECT_FORMAT_COFF);
                BUSTER_TEST(arguments, written.error == OBJECT_ERROR_NONE);

                u32 raw_offset = 0;
                u32 relocation_offset = 0;
                u16 written_count = 0;
                u32 characteristics = 0;
                bool section_found = written.error == OBJECT_ERROR_NONE &&
                                     object_test_coff_named_section(written.bytes, S8(".data"), &raw_offset, &relocation_offset,
                                                                    &written_count, &characteristics);
                if (BUSTER_REQUIRE(arguments, section_found))
                {
                    BUSTER_TEST(arguments, written_count == (relocation_overflow ? UINT16_MAX : (u16)relocation_count));
                    BUSTER_TEST(arguments, ((characteristics & OBJECT_TEST_COFF_SECTION_LINK_NRELOC_OVFL) != 0) == relocation_overflow);
                    u64 first_entry = relocation_offset + (relocation_overflow ? 10 : 0);
                    u64 last_entry = first_entry + (u64)(relocation_count - 1) * 10;
                    u32 first_source_offset = 0;
                    u32 last_source_offset = 0;
                    u32 first_symbol = UINT32_MAX;
                    u32 last_symbol = UINT32_MAX;
                    u16 first_type = 0;
                    u16 last_type = 0;
                    memcpy(&first_source_offset, written.bytes.pointer + first_entry, sizeof(first_source_offset));
                    memcpy(&first_symbol, written.bytes.pointer + first_entry + 4, sizeof(first_symbol));
                    memcpy(&first_type, written.bytes.pointer + first_entry + 8, sizeof(first_type));
                    memcpy(&last_source_offset, written.bytes.pointer + last_entry, sizeof(last_source_offset));
                    memcpy(&last_symbol, written.bytes.pointer + last_entry + 4, sizeof(last_symbol));
                    memcpy(&last_type, written.bytes.pointer + last_entry + 8, sizeof(last_type));
                    BUSTER_TEST(arguments, first_source_offset == 0 && first_symbol == 0 && first_type == expected_relocation_type);
                    BUSTER_TEST(arguments, last_source_offset == (u32)((u64)(relocation_count - 1) * sizeof(u64)) &&
                                               last_symbol == 0 && last_type == expected_relocation_type);
                    if (relocation_overflow)
                    {
                        u32 marker_count = 0;
                        u32 marker_symbol = UINT32_MAX;
                        u16 marker_type = UINT16_MAX;
                        memcpy(&marker_count, written.bytes.pointer + relocation_offset, sizeof(marker_count));
                        memcpy(&marker_symbol, written.bytes.pointer + relocation_offset + 4, sizeof(marker_symbol));
                        memcpy(&marker_type, written.bytes.pointer + relocation_offset + 8, sizeof(marker_type));
                        BUSTER_TEST(arguments, marker_count == relocation_count + 1 && marker_symbol == 0 && marker_type == 0);
                    }
                }

                ObjectFile writer_readback = object_read(arguments->arena, written.bytes, target);
                bool writer_readback_valid = written.error == OBJECT_ERROR_NONE && writer_readback.error == OBJECT_ERROR_NONE &&
                                             writer_readback.relocations && writer_readback.symbols &&
                                             writer_readback.relocation_count == relocation_count && writer_readback.symbol_count == 1;
                if (BUSTER_REQUIRE(arguments, writer_readback_valid))
                {
                    ObjectRelocation* first = writer_readback.relocations;
                    ObjectRelocation* last = writer_readback.relocations + relocation_count - 1;
                    BUSTER_STRING_TEST(arguments, writer_readback.symbols[0].name, S8("external"));
                    BUSTER_TEST(arguments, first->offset == 0 && first->symbol == 0 && first->addend == -17);
                    BUSTER_TEST(arguments, last->offset == (u64)(relocation_count - 1) * sizeof(u64) &&
                                               last->symbol == 0 && last->addend == 23);
                }
                arena_set_position(arguments->arena, overflow_scope.position);
            }
        }
    }
    {
        TemporalArena malformed_scope = arena_begin_temporal(arguments->arena);
        u32 relocation_count = UINT16_MAX + 1;
        ByteSlice malformed_bytes =
            object_test_coff_relocation_count_object(arguments->arena, CPU_ARCH_X86_64, relocation_count);
        u64 marker_offset = OBJECT_TEST_COFF_HEADER_SIZE + OBJECT_TEST_COFF_SECTION_SIZE +
                            (u64)relocation_count * sizeof(u64);
        object_test_coff_write_u32(malformed_bytes.pointer, marker_offset, UINT16_MAX + 1);
        ObjectFile malformed = object_read(arguments->arena, malformed_bytes,
                                           (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS});
        BUSTER_TEST(arguments, malformed.error == OBJECT_ERROR_INVALID_INPUT && !malformed.relocation_count);
        arena_set_position(arguments->arena, malformed_scope.position);
    }
    {
        TemporalArena comdat_scope = arena_begin_temporal(arguments->arena);
        ByteSlice comdat_bytes = object_test_coff_comdat_object(arguments->arena);
        ObjectFile comdat = object_read(arguments->arena, comdat_bytes,
                                        (Target){
                                            .cpu_arch = CPU_ARCH_X86_64,
                                            .os = OPERATING_SYSTEM_WINDOWS,
                                        });
        BUSTER_TEST(arguments, comdat.error == OBJECT_ERROR_NONE);
        // Six symbols: the two auxiliary records carry no symbol of their own.
        BUSTER_TEST(arguments, comdat.symbol_count == 6);
        if (comdat.error == OBJECT_ERROR_NONE && comdat.symbol_count == 6)
        {
            BUSTER_STRING_TEST(arguments, comdat.symbols[0].name, S8("plain"));
            BUSTER_TEST(arguments, comdat.symbols[0].section == OBJECT_SECTION_TEXT && comdat.symbols[0].global && !comdat.symbols[0].weak);
            BUSTER_STRING_TEST(arguments, comdat.symbols[2].name, S8("any_one"));
            BUSTER_TEST(arguments, comdat.symbols[2].section == OBJECT_SECTION_READ_ONLY_DATA && comdat.symbols[2].global && comdat.symbols[2].weak);
            // The section symbol shares its section's selection, but stays
            // local, so it never reaches the linker's global arbitration.
            BUSTER_TEST(arguments, !comdat.symbols[1].global && comdat.symbols[1].weak);
            BUSTER_STRING_TEST(arguments, comdat.symbols[4].name, S8("strict1"));
            BUSTER_TEST(arguments, comdat.symbols[4].global && !comdat.symbols[4].weak);
            BUSTER_TEST(arguments, !comdat.symbols[3].weak);
            // IMAGE_SCN_LNK_COMDAT with no section symbol to name a selection
            // stays a hard definition rather than a silently dropped one.
            BUSTER_STRING_TEST(arguments, comdat.symbols[5].name, S8("pending"));
            BUSTER_TEST(arguments, comdat.symbols[5].global && !comdat.symbols[5].weak);
            BUSTER_TEST(arguments, comdat.comdat_count == 3);
            if (comdat.comdat_count == 3)
            {
                BUSTER_STRING_TEST(arguments, comdat.comdats[0].key, S8("any_one"));
                BUSTER_TEST(arguments, comdat.comdats[0].selection == OBJECT_COMDAT_SELECTION_ANY &&
                                       comdat.comdats[0].section == OBJECT_SECTION_READ_ONLY_DATA &&
                                       comdat.symbols[2].comdat == 1);
                BUSTER_STRING_TEST(arguments, comdat.comdats[1].key, S8("strict1"));
                BUSTER_TEST(arguments, comdat.comdats[1].selection == OBJECT_COMDAT_SELECTION_NO_DUPLICATES &&
                                       comdat.symbols[4].comdat == 2);
                BUSTER_TEST(arguments, comdat.comdats[2].selection == OBJECT_COMDAT_SELECTION_NONE &&
                                       comdat.symbols[5].comdat == 3);
            }
        }
        arena_set_position(arguments->arena, comdat_scope.position);
    }
    {
        TemporalArena arm64_coff_scope = arena_begin_temporal(arguments->arena);
        Target arm64_coff_target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_WINDOWS};
        // Both inline fields carry seven as an implicit COFF addend. The
        // reader must retain it once and leave canonical zero-immediate words.
        ByteSlice page_bytes = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0xf0000028),
                                                                   UINT32_C(0x91001d00), 0x0006);
        ObjectFile page = object_read(arguments->arena, page_bytes, arm64_coff_target);
        BUSTER_TEST(arguments, page.error == OBJECT_ERROR_NONE && page.relocation_count == 2);
        if (BUSTER_REQUIRE(arguments, page.error == OBJECT_ERROR_NONE && page.relocation_count == 2))
        {
            u32 page_word = 0;
            u32 low_word = 0;
            memcpy(&page_word, page.sections[OBJECT_SECTION_TEXT].data.pointer, sizeof(page_word));
            memcpy(&low_word, page.sections[OBJECT_SECTION_TEXT].data.pointer + 4, sizeof(low_word));
            BUSTER_TEST(arguments, page.relocations[0].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21 &&
                                       page.relocations[0].addend == 7 && page_word == UINT32_C(0x90000008));
            BUSTER_TEST(arguments, page.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A &&
                                       page.relocations[1].addend == 7 && low_word == UINT32_C(0x91000100));
            ObjectArtifact rewritten = object_write(arguments->arena, &page, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, rewritten.error == OBJECT_ERROR_NONE);
            u32 raw_offset = 0;
            u32 relocation_offset = 0;
            u16 relocation_count = 0;
            bool text_found = rewritten.error == OBJECT_ERROR_NONE &&
                              object_test_coff_named_section(rewritten.bytes, S8(".text"), &raw_offset, &relocation_offset, &relocation_count, 0);
            BUSTER_TEST(arguments, text_found && relocation_count == 2);
            if (text_found && relocation_count == 2)
            {
                u32 written_page = 0;
                u32 written_low = 0;
                u16 page_type = 0;
                u16 low_type = 0;
                memcpy(&written_page, rewritten.bytes.pointer + raw_offset, sizeof(written_page));
                memcpy(&written_low, rewritten.bytes.pointer + raw_offset + 4, sizeof(written_low));
                memcpy(&page_type, rewritten.bytes.pointer + relocation_offset + 8, sizeof(page_type));
                memcpy(&low_type, rewritten.bytes.pointer + relocation_offset + 18, sizeof(low_type));
                BUSTER_TEST(arguments, written_page == UINT32_C(0xf0000028) && written_low == UINT32_C(0x91001d00));
                BUSTER_TEST(arguments, page_type == 0x0004 && low_type == 0x0006);
            }
            ObjectFile reread = object_read(arguments->arena, rewritten.bytes, arm64_coff_target);
            BUSTER_TEST(arguments, reread.error == OBJECT_ERROR_NONE && reread.relocation_count == 2 &&
                                       reread.relocations[0].addend == 7 && reread.relocations[1].addend == 7);

            page.relocations[0].addend = -INT64_C(0x100000);
            BUSTER_TEST(arguments, object_write(arguments->arena, &page, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_NONE);
            page.relocations[0].addend = INT64_C(0xfffff);
            BUSTER_TEST(arguments, object_write(arguments->arena, &page, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_NONE);
            page.relocations[0].addend = INT64_C(0x100000);
            ObjectArtifact oversized_page = object_write(arguments->arena, &page, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, oversized_page.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !oversized_page.bytes.length);
            page.relocations[0].addend = 1;
            BUSTER_TEST(arguments, object_write(arguments->arena, &page, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_NONE);
            page.relocations[0].addend = 0;
            page.relocations[1].addend = A64_IMM12_MAX;
            BUSTER_TEST(arguments, object_write(arguments->arena, &page, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_NONE);
            page.relocations[1].addend = A64_IMM12_MAX + 1;
            BUSTER_TEST(arguments, object_write(arguments->arena, &page, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
            page.relocations[1].addend = -1;
            BUSTER_TEST(arguments, object_write(arguments->arena, &page, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        }

        ByteSlice load_bytes = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0x90000008),
                                                                   UINT32_C(0xfd401d00), 0x0007);
        ObjectFile load = object_read(arguments->arena, load_bytes, arm64_coff_target);
        BUSTER_TEST(arguments, load.error == OBJECT_ERROR_NONE && load.relocation_count == 2);
        if (load.error == OBJECT_ERROR_NONE && load.relocation_count == 2)
        {
            u32 load_word = 0;
            memcpy(&load_word, load.sections[OBJECT_SECTION_TEXT].data.pointer + 4, sizeof(load_word));
            BUSTER_TEST(arguments, load.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L &&
                                       load.relocations[1].addend == 56 && load_word == UINT32_C(0xfd400100));
            ObjectArtifact rewritten_load = object_write(arguments->arena, &load, OBJECT_FORMAT_COFF);
            ObjectFile reread_load = object_read(arguments->arena, rewritten_load.bytes, arm64_coff_target);
            BUSTER_TEST(arguments, rewritten_load.error == OBJECT_ERROR_NONE && reread_load.error == OBJECT_ERROR_NONE &&
                                       reread_load.relocation_count == 2 &&
                                       reread_load.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L &&
                                       reread_load.relocations[1].addend == 56);
            load.relocations[1].addend = (s64)A64_IMM12_MAX * 8;
            BUSTER_TEST(arguments, object_write(arguments->arena, &load, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_NONE);
            load.relocations[1].addend = (s64)(A64_IMM12_MAX + 1) * 8;
            ObjectArtifact oversized_load = object_write(arguments->arena, &load, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, oversized_load.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !oversized_load.bytes.length);
            load.relocations[1].addend = 1;
            ObjectArtifact misaligned_load = object_write(arguments->arena, &load, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, misaligned_load.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !misaligned_load.bytes.length);
            load.relocations[1].addend = 56;
            u32 stored_load = UINT32_C(0xfd000100);
            memcpy(load.sections[OBJECT_SECTION_TEXT].data.pointer + 4, &stored_load, sizeof(stored_load));
            ObjectArtifact stored_load_output = object_write(arguments->arena, &load, OBJECT_FORMAT_COFF);
            ObjectFile stored_load_reread = object_read(arguments->arena, stored_load_output.bytes, arm64_coff_target);
            BUSTER_TEST(arguments, stored_load_output.error == OBJECT_ERROR_NONE && stored_load_reread.error == OBJECT_ERROR_NONE &&
                                       stored_load_reread.relocation_count == 2 &&
                                       stored_load_reread.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L &&
                                       stored_load_reread.relocations[1].addend == 56);
            load.symbols[load.relocations[1].symbol].name = S8("__tls_index");
            ObjectArtifact reserved_load = object_write(arguments->arena, &load, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, reserved_load.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !reserved_load.bytes.length);
        }

        ByteSlice prfm_bytes = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0x90000008),
                                                                   UINT32_C(0xf9801d00), 0x0007);
        ObjectFile prfm = object_read(arguments->arena, prfm_bytes, arm64_coff_target);
        ObjectArtifact rewritten_prfm = object_write(arguments->arena, &prfm, OBJECT_FORMAT_COFF);
        ObjectFile reread_prfm = object_read(arguments->arena, rewritten_prfm.bytes, arm64_coff_target);
        BUSTER_TEST(arguments, prfm.error == OBJECT_ERROR_NONE && prfm.relocation_count == 2 &&
                                   prfm.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L &&
                                   prfm.relocations[1].addend == 56 && rewritten_prfm.error == OBJECT_ERROR_NONE &&
                                   reread_prfm.error == OBJECT_ERROR_NONE && reread_prfm.relocations[1].addend == 56);

        typedef struct ObjectTestArm64CoffMalformed ObjectTestArm64CoffMalformed;
        struct ObjectTestArm64CoffMalformed
        {
            u32 first_word;
            u32 second_word;
            u16 second_type;
        };
        ObjectTestArm64CoffMalformed malformed[] = {
            {UINT32_C(0x10000008), UINT32_C(0x91000100), 0x0006}, // ADR, not ADRP
            {UINT32_C(0x90000008), UINT32_C(0x91400100), 0x0006}, // shifted ADD
            {UINT32_C(0x90000008), UINT32_C(0xd1000100), 0x0006}, // SUB
            {UINT32_C(0x90000008), UINT32_C(0xb1000100), 0x0006}, // ADDS is not an admitted form
            {UINT32_C(0x90000008), UINT32_C(0xd65f03c0), 0x0006}, // unrelated instruction
            {UINT32_C(0x90000008), UINT32_C(0x91000100), 0x0007}, // ADD, not PAGEOFFSET_12L LDR
            {UINT32_C(0x90000008), UINT32_C(0x5c000100), 0x0007}, // literal LDR, not indexed unsigned immediate
            {UINT32_C(0x90000008), UINT32_C(0xfc400100), 0x0007}, // unscaled LDR
            {UINT32_C(0x90000008), UINT32_C(0xf8606900), 0x0007}, // register-offset LDR
            {UINT32_C(0x90000008), UINT32_C(0x91000100), 0x000f}, // BRANCH19, never TLS
        };
        for (u32 malformed_index = 0; malformed_index < BUSTER_ARRAY_LENGTH(malformed); malformed_index += 1)
        {
            ObjectTestArm64CoffMalformed row = malformed[malformed_index];
            ByteSlice bytes = object_test_coff_arm64_page_object(arguments->arena, S8("target"), row.first_word, row.second_word, row.second_type);
            BUSTER_TEST(arguments, object_read(arguments->arena, bytes, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        }

        u32 pageoffset_load_store_words[] = {
            UINT32_C(0x39000100), UINT32_C(0x79000100), UINT32_C(0xb9000100), UINT32_C(0xf9000100),
            UINT32_C(0x39400100), UINT32_C(0x79400100), UINT32_C(0xb9400100), UINT32_C(0xf9400100),
            UINT32_C(0xb9800100), UINT32_C(0x3d000100), UINT32_C(0x7d000100), UINT32_C(0xbd000100),
            UINT32_C(0xfd000100), UINT32_C(0x3d400100), UINT32_C(0x7d400100), UINT32_C(0xbd400100),
            UINT32_C(0xfd400100), UINT32_C(0x3d800100), UINT32_C(0x3dc00100), UINT32_C(0xf9800100),
        };
        u8 pageoffset_load_store_scales[] = {0, 1, 2, 3, 0, 1, 2, 3, 2, 0, 1, 2, 3, 0, 1, 2, 3, 4, 4, 3};
        BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(pageoffset_load_store_words) == BUSTER_ARRAY_LENGTH(pageoffset_load_store_scales));
        for (u32 word_index = 0; word_index < BUSTER_ARRAY_LENGTH(pageoffset_load_store_words); word_index += 1)
        {
            u32 patched = 0;
            u32 shift = pageoffset_load_store_scales[word_index];
            BUSTER_TEST(arguments,
                        object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L,
                                                         pageoffset_load_store_words[word_index], 0, 0x17f0, 0, &patched) &&
                            (patched & ~(A64_IMM12_MAX << 10)) == pageoffset_load_store_words[word_index] &&
                            ((patched >> 10) & A64_IMM12_MAX) == (0x7f0u >> shift));
        }
        u32 pageoffset_patched = 0;
        BUSTER_TEST(arguments,
                    !object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L, UINT32_C(0xfd400100), 0, 0x1001, 0,
                                                      &pageoffset_patched));
        BUSTER_TEST(arguments,
                    !object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L, UINT32_C(0xfd400100), 0, UINT64_MAX, 8,
                                                      &pageoffset_patched));

        ByteSlice tls_bytes = object_test_coff_arm64_page_object(arguments->arena, S8("__tls_index"), UINT32_C(0x90000008),
                                                                  UINT32_C(0xb9400120), 0x0007);
        object_test_coff_write_u16(tls_bytes.pointer, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 12, 0);
        ObjectFile tls = object_read(arguments->arena, tls_bytes, arm64_coff_target);
        BUSTER_TEST(arguments, tls.error == OBJECT_ERROR_NONE && tls.relocation_count == 2);
        if (tls.error == OBJECT_ERROR_NONE && tls.relocation_count == 2)
        {
            BUSTER_TEST(arguments, tls.relocations[0].kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_ADRP &&
                                       tls.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_LO12);
            BUSTER_TEST(arguments, tls.relocations[0].addend == 0 && tls.relocations[1].addend == 0);
            tls.relocation_count = 1;
            ObjectArtifact unmatched_tls = object_write(arguments->arena, &tls, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, unmatched_tls.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !unmatched_tls.bytes.length);
            tls.relocation_count = 2;
            ObjectArtifact tls_preserved = object_write(arguments->arena, &tls, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, tls_preserved.error == OBJECT_ERROR_NONE && object_read(arguments->arena, tls_preserved.bytes, arm64_coff_target).error == OBJECT_ERROR_NONE);

            tls.symbols[0].kind = OBJECT_SYMBOL_FUNCTION;
            ObjectArtifact function_tls_index = object_write(arguments->arena, &tls, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, function_tls_index.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !function_tls_index.bytes.length);
            tls.symbols[0].kind = OBJECT_SYMBOL_DATA;
            tls.symbols[0].global = false;
            ObjectArtifact local_tls_index = object_write(arguments->arena, &tls, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, local_tls_index.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !local_tls_index.bytes.length);
            tls.symbols[0].global = true;

            // Codegen associates the pair with the TLS variable. The COFF
            // writer must synthesize the loader-owned symbol without mutating
            // that in-memory object and only redirect the serialized pair.
            tls.symbols[0].name = S8("__tls_indexx");
            tls.symbols[0].section = OBJECT_SECTION_DATA;
            ObjectArtifact tls_written = object_write(arguments->arena, &tls, OBJECT_FORMAT_COFF);
            BUSTER_TEST(arguments, tls_written.error == OBJECT_ERROR_NONE && tls.symbol_count == 1 &&
                                       string_equal(tls.symbols[0].name, S8("__tls_indexx")));
            ObjectFile tls_reread = object_read(arguments->arena, tls_written.bytes, arm64_coff_target);
            BUSTER_TEST(arguments, tls_reread.error == OBJECT_ERROR_NONE && tls_reread.relocation_count == 2 &&
                                       string_equal(tls_reread.symbols[tls_reread.relocations[0].symbol].name, S8("__tls_index")) &&
                                       string_equal(tls_reread.symbols[tls_reread.relocations[1].symbol].name, S8("__tls_index")));
        }
        ByteSlice tls_addend = object_test_coff_arm64_page_object(arguments->arena, S8("__tls_index"), UINT32_C(0xf0000028),
                                                                  UINT32_C(0xb9400120), 0x0007);
        object_test_coff_write_u16(tls_addend.pointer, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 12, 0);
        BUSTER_TEST(arguments, object_read(arguments->arena, tls_addend, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        ByteSlice defined_tls_index = object_test_coff_arm64_page_object(arguments->arena, S8("__tls_index"), UINT32_C(0x90000008),
                                                                          UINT32_C(0xb9400120), 0x0007);
        BUSTER_TEST(arguments, object_read(arguments->arena, defined_tls_index, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        ByteSlice function_tls_index = object_test_coff_arm64_page_object(arguments->arena, S8("__tls_index"), UINT32_C(0x90000008),
                                                                           UINT32_C(0xb9400120), 0x0007);
        object_test_coff_write_u16(function_tls_index.pointer, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 12, 0);
        object_test_coff_write_u16(function_tls_index.pointer, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 14, 0x20);
        BUSTER_TEST(arguments, object_read(arguments->arena, function_tls_index, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        ByteSlice local_tls_index = object_test_coff_arm64_page_object(arguments->arena, S8("__tls_index"), UINT32_C(0x90000008),
                                                                        UINT32_C(0xb9400120), 0x0007);
        object_test_coff_write_u16(local_tls_index.pointer, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 12, 0);
        local_tls_index.pointer[OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 16] = 3;
        BUSTER_TEST(arguments, object_read(arguments->arena, local_tls_index, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        ByteSlice near_name_tls_index = object_test_coff_arm64_page_object(arguments->arena, S8("__tls_indexx"), UINT32_C(0x90000008),
                                                                            UINT32_C(0xb9400120), 0x0007);
        object_test_coff_write_u16(near_name_tls_index.pointer, OBJECT_TEST_ARM64_COFF_SYMBOL_OFFSET + 12, 0);
        ObjectFile near_name = object_read(arguments->arena, near_name_tls_index, arm64_coff_target);
        BUSTER_TEST(arguments, near_name.error == OBJECT_ERROR_NONE && near_name.relocation_count == 2 &&
                                   near_name.relocations[0].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21 &&
                                   near_name.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L);

        ByteSlice tls_offset_bytes = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0x90000008),
                                                                         UINT32_C(0x91000100), 0x0009);
        object_test_coff_write_name(tls_offset_bytes.pointer, 60, S8(".tls$AAA"));
        ObjectFile tls_offset = object_read(arguments->arena, tls_offset_bytes, arm64_coff_target);
        BUSTER_TEST(arguments, tls_offset.error == OBJECT_ERROR_NONE && tls_offset.relocation_count == 2 &&
                                   tls_offset.relocations[1].kind == OBJECT_RELOCATION_AARCH64_PE_TLS_OFFSET12);
        ByteSlice ordinary_tls_offset = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0x90000008),
                                                                            UINT32_C(0x91000100), 0x0009);
        BUSTER_TEST(arguments, object_read(arguments->arena, ordinary_tls_offset, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);

        ByteSlice misaligned = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0x90000008),
                                                                   UINT32_C(0x91000100), 0x0006);
        object_test_coff_write_u32(misaligned.pointer, OBJECT_TEST_ARM64_COFF_RELOCATION_OFFSET + 10, 5);
        BUSTER_TEST(arguments, object_read(arguments->arena, misaligned, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        ByteSlice underaligned = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0x90000008),
                                                                    UINT32_C(0x91000100), 0x0006);
        object_test_coff_write_u32(underaligned.pointer, 20 + 36, 0x60100020);
        BUSTER_TEST(arguments, object_read(arguments->arena, underaligned, arm64_coff_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        ByteSlice truncated = object_test_coff_arm64_page_object(arguments->arena, S8("target"), UINT32_C(0x90000008),
                                                                  UINT32_C(0x91000100), 0x0006);
        object_test_coff_write_u32(truncated.pointer, 20 + 16, 7);
        BUSTER_TEST(arguments, object_read(arguments->arena, truncated, arm64_coff_target).error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, arm64_coff_scope.position);
    }
    {
        TemporalArena codeview_scope = arena_begin_temporal(arguments->arena);
        ByteSlice codeview_bytes = object_test_coff_repeated_codeview_object(arguments->arena, CPU_ARCH_X86_64);
        Target codeview_target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS};
        ObjectFile codeview = object_read(arguments->arena, codeview_bytes, codeview_target);
        BUSTER_TEST(arguments, codeview.error == OBJECT_ERROR_NONE && codeview.section_count == OBJECT_SECTION_COUNT &&
                                   codeview.debug_module_count == 1 && codeview.relocation_count == 1);
        if (codeview.error == OBJECT_ERROR_NONE && codeview.section_count == OBJECT_SECTION_COUNT && codeview.debug_module_count == 1 &&
            codeview.relocation_count == 1)
        {
            ByteSlice codeview_symbols = codeview.sections[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS].data;
            ByteSlice types = codeview.sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data;
            u32 symbols_signature = 0;
            u32 second_symbols_kind = 0;
            u32 types_signature = 0;
            u16 first_type_leaf = 0;
            u16 second_type_leaf = 0;
            if (codeview_symbols.length >= 28)
            {
                memcpy(&symbols_signature, codeview_symbols.pointer, sizeof(symbols_signature));
                memcpy(&second_symbols_kind, codeview_symbols.pointer + 24, sizeof(second_symbols_kind));
            }
            if (types.length >= 12)
            {
                memcpy(&types_signature, types.pointer, sizeof(types_signature));
                memcpy(&first_type_leaf, types.pointer + 6, sizeof(first_type_leaf));
                memcpy(&second_type_leaf, types.pointer + 10, sizeof(second_type_leaf));
            }
            BUSTER_TEST(arguments, codeview_symbols.length == 36 && symbols_signature == 4 && second_symbols_kind == 0xf1);
            BUSTER_TEST(arguments, types.length == 12 && types_signature == 4 && first_type_leaf == 0x9998 && second_type_leaf == 0x9997);
            BUSTER_TEST(arguments, codeview.relocations[0].section == OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS &&
                                       codeview.relocations[0].kind == OBJECT_RELOCATION_COFF_SECTION16 && codeview.relocations[0].offset == 32);
            PdbSection section = {.name = S8(".text"), .virtual_size = 4, .raw_size = 4, .characteristics = 0x60000020};
            PdbModule module = {
                .name = S8("repeated.obj"),
                .codeview_symbols = codeview_symbols,
                .codeview_types = types,
                .code_size = 4,
                .code_section = 1,
            };
            PdbInput input = {.sections = &section, .section_count = 1, .machine = 0x8664, .modules = &module, .module_count = 1};
            BUSTER_TEST(arguments, pdb_build(arguments->arena, input).valid);
            u8 nested_types[20] = {0};
            object_test_coff_write_u32(nested_types, 0, 4);
            object_test_coff_write_u16(nested_types, 4, 12);
            object_test_coff_write_u16(nested_types, 6, 0x1203);
            object_test_coff_write_u16(nested_types, 8, 0x1510);
            object_test_coff_write_u32(nested_types, 12, 0x22);
            nested_types[16] = 'n';
            nested_types[18] = 0xf2;
            nested_types[19] = 0xf1;
            module.codeview_types = (ByteSlice){.pointer = nested_types, .length = sizeof(nested_types)};
            BUSTER_TEST(arguments, pdb_build(arguments->arena, input).valid);
            object_test_coff_write_u16(nested_types, 8, 0x1511);
            object_test_coff_write_u16(nested_types, 10, 0xb);
            BUSTER_TEST(arguments, pdb_build(arguments->arena, input).valid);
            object_test_coff_write_u16(nested_types, 10, 0x13);
            BUSTER_TEST(arguments, !pdb_build(arguments->arena, input).valid);
            object_test_coff_write_u16(nested_types, 10, 0xb);
            u8 packed_symbols[24] = {0};
            object_test_coff_write_u32(packed_symbols, 0, 4);
            object_test_coff_write_u32(packed_symbols, 4, 0xf1);
            object_test_coff_write_u32(packed_symbols, 8, 9);
            object_test_coff_write_u16(packed_symbols, 12, 3);
            object_test_coff_write_u16(packed_symbols, 14, 0x9996);
            packed_symbols[16] = 1;
            object_test_coff_write_u16(packed_symbols, 17, 2);
            object_test_coff_write_u16(packed_symbols, 19, 0x9995);
            module.codeview_symbols = (ByteSlice){.pointer = packed_symbols, .length = sizeof(packed_symbols)};
            BUSTER_TEST(arguments, pdb_build(arguments->arena, input).valid);
        }
        ByteSlice bad_signature = {
            .pointer = arena_allocate(arguments->arena, u8, codeview_bytes.length),
            .length = codeview_bytes.length,
        };
        memcpy(bad_signature.pointer, codeview_bytes.pointer, codeview_bytes.length);
        object_test_coff_write_u32(bad_signature.pointer, 248, 3);
        BUSTER_TEST(arguments, object_read(arguments->arena, bad_signature, codeview_target).error != OBJECT_ERROR_NONE);
        ByteSlice short_signature = {
            .pointer = arena_allocate(arguments->arena, u8, codeview_bytes.length),
            .length = codeview_bytes.length,
        };
        memcpy(short_signature.pointer, codeview_bytes.pointer, codeview_bytes.length);
        object_test_coff_write_u32(short_signature.pointer, 116, 3);
        BUSTER_TEST(arguments, object_read(arguments->arena, short_signature, codeview_target).error != OBJECT_ERROR_NONE);
        ByteSlice prefix_relocation = {
            .pointer = arena_allocate(arguments->arena, u8, codeview_bytes.length),
            .length = codeview_bytes.length,
        };
        memcpy(prefix_relocation.pointer, codeview_bytes.pointer, codeview_bytes.length);
        object_test_coff_write_u32(prefix_relocation.pointer, 280, 2);
        BUSTER_TEST(arguments, object_read(arguments->arena, prefix_relocation, codeview_target).error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, codeview_scope.position);
    }
    {
        TemporalArena arm64_codeview_scope = arena_begin_temporal(arguments->arena);
        Target arm64_codeview_target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_WINDOWS};
        ByteSlice codeview_bytes = object_test_coff_repeated_codeview_object(arguments->arena, CPU_ARCH_AARCH64);
        ObjectFile codeview = object_read(arguments->arena, codeview_bytes, arm64_codeview_target);
        BUSTER_TEST(arguments, codeview.error == OBJECT_ERROR_NONE && codeview.relocation_count == 1);
        if (codeview.error == OBJECT_ERROR_NONE && codeview.relocation_count == 1)
        {
            BUSTER_TEST(arguments, codeview.relocations[0].kind == OBJECT_RELOCATION_COFF_SECTION16 && codeview.relocations[0].addend == 2);
            ObjectArtifact rewritten = object_write(arguments->arena, &codeview, OBJECT_FORMAT_COFF);
            u32 raw_offset = 0;
            u32 relocation_offset = 0;
            u16 relocation_count = 0;
            bool debug_found = rewritten.error == OBJECT_ERROR_NONE &&
                               object_test_coff_named_section(rewritten.bytes, S8(".debug$S"), &raw_offset, &relocation_offset, &relocation_count, 0);
            BUSTER_TEST(arguments, debug_found && relocation_count == 1);
            if (debug_found && relocation_count == 1)
            {
                u16 stored = 0;
                u16 type = 0;
                u32 source_offset = 0;
                memcpy(&source_offset, rewritten.bytes.pointer + relocation_offset, sizeof(source_offset));
                memcpy(&stored, rewritten.bytes.pointer + raw_offset + source_offset, sizeof(stored));
                memcpy(&type, rewritten.bytes.pointer + relocation_offset + 8, sizeof(type));
                BUSTER_TEST(arguments, stored == 2 && type == 0x000d);
            }
        }
        ByteSlice old_section = object_test_coff_repeated_codeview_object(arguments->arena, CPU_ARCH_AARCH64);
        object_test_coff_write_u16(old_section.pointer, 288, 0x0007);
        BUSTER_TEST(arguments, object_read(arguments->arena, old_section, arm64_codeview_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        ByteSlice short_section = object_test_coff_repeated_codeview_object(arguments->arena, CPU_ARCH_AARCH64);
        object_test_coff_write_u32(short_section.pointer, 280, 15);
        BUSTER_TEST(arguments, object_read(arguments->arena, short_section, arm64_codeview_target).error != OBJECT_ERROR_NONE);
        ByteSlice secrel_bytes = object_test_coff_repeated_codeview_object(arguments->arena, CPU_ARCH_AARCH64);
        object_test_coff_write_u16(secrel_bytes.pointer, 288, 0x0008);
        object_test_coff_write_u32(secrel_bytes.pointer, 260, UINT32_C(0xfffffffc));
        ObjectFile secrel = object_read(arguments->arena, secrel_bytes, arm64_codeview_target);
        BUSTER_TEST(arguments, secrel.error == OBJECT_ERROR_NONE && secrel.relocation_count == 1 &&
                                   secrel.relocations[0].kind == OBJECT_RELOCATION_COFF_SECREL32 && secrel.relocations[0].addend == -4);
        arena_set_position(arguments->arena, arm64_codeview_scope.position);
    }
    {
        // ELF64 and Mach-O carry the replaceable bit on the wire; COFF cannot,
        // because expressing it needs a section per COMDAT and the writer
        // merges sections by kind.
        TemporalArena weak_scope = arena_begin_temporal(arguments->arena);
        ObjectSymbol weak_symbols[] = {
            {.name = S8("object_weak"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true, .weak = true},
            {.name = S8("object_strong"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
        };
        ObjectFile weak_object = object;
        weak_object.symbols = weak_symbols;
        weak_object.symbol_count = BUSTER_ARRAY_LENGTH(weak_symbols);
        weak_object.relocations = 0;
        weak_object.relocation_count = 0;
        ObjectFormat weak_formats[] = {OBJECT_FORMAT_ELF64, OBJECT_FORMAT_MACH_O64};
        OperatingSystem weak_systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_MACOS};
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(weak_formats); index += 1)
        {
            ObjectArtifact weak_artifact = object_write(arguments->arena, &weak_object, weak_formats[index]);
            BUSTER_TEST(arguments, weak_artifact.error == OBJECT_ERROR_NONE);
            ObjectFile weak_roundtrip = object_read(arguments->arena, weak_artifact.bytes,
                                                    (Target){
                                                        .cpu_arch = CPU_ARCH_X86_64,
                                                        .os = weak_systems[index],
                                                    });
            BUSTER_TEST(arguments, weak_roundtrip.error == OBJECT_ERROR_NONE && weak_roundtrip.symbol_count == BUSTER_ARRAY_LENGTH(weak_symbols));
            if (weak_roundtrip.error == OBJECT_ERROR_NONE && weak_roundtrip.symbol_count == BUSTER_ARRAY_LENGTH(weak_symbols))
            {
                bool weak_found = false;
                bool strong_found = false;
                for (u32 symbol = 0; symbol < weak_roundtrip.symbol_count; symbol += 1)
                {
                    ObjectSymbol* read = weak_roundtrip.symbols + symbol;
                    weak_found = weak_found || (string_equal(read->name, S8("object_weak")) && read->global && read->weak);
                    strong_found = strong_found || (string_equal(read->name, S8("object_strong")) && read->global && !read->weak);
                }
                BUSTER_TEST(arguments, weak_found);
                BUSTER_TEST(arguments, strong_found);
            }
        }
        arena_set_position(arguments->arena, weak_scope.position);
    }
    {
        u8 debug_data[] = {0};
        ObjectSection long_coff_sections[OBJECT_SECTION_COUNT] = {0};
        for (u32 section_index = 0; section_index < OBJECT_SECTION_COUNT; section_index += 1)
        {
            long_coff_sections[section_index] = (ObjectSection){
                .name = object_section_name_for_kind((ObjectSectionKind)section_index),
                .kind = (ObjectSectionKind)section_index,
                .alignment = object_section_default_alignment((ObjectSectionKind)section_index),
            };
        }
        for (u32 section_index = 0; section_index < BUSTER_ARRAY_LENGTH(sections); section_index += 1)
        {
            long_coff_sections[section_index] = sections[section_index];
        }
        long_coff_sections[OBJECT_SECTION_DEBUG_INFO].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(debug_data);
        long_coff_sections[OBJECT_SECTION_DEBUG_INFO].virtual_size = sizeof(debug_data);
        ObjectFile long_coff_object = object;
        long_coff_object.sections = long_coff_sections;
        long_coff_object.section_count = OBJECT_SECTION_COUNT;
        ObjectArtifact long_coff = object_write(arguments->arena, &long_coff_object, OBJECT_FORMAT_COFF);
        BUSTER_TEST(arguments, long_coff.error == OBJECT_ERROR_NONE);
        ObjectFile long_coff_roundtrip = object_read(arguments->arena, long_coff.bytes,
                                                     (Target){
                                                         .cpu_arch = CPU_ARCH_X86_64,
                                                         .os = OPERATING_SYSTEM_WINDOWS,
                                                     });
        if (BUSTER_REQUIRE(arguments, long_coff_roundtrip.error == OBJECT_ERROR_NONE && long_coff_roundtrip.sections != 0 &&
                                          long_coff_roundtrip.section_count > OBJECT_SECTION_DEBUG_INFO))
        {
            BUSTER_TEST(arguments, long_coff_roundtrip.sections[OBJECT_SECTION_DEBUG_INFO].data.length == sizeof(debug_data));
        }
        if (long_coff.bytes.pointer && long_coff.bytes.length > 0)
        {
            u64 section = 20 + (u64)OBJECT_SECTION_DEBUG_INFO * 40;
            TemporalArena bad_offset_scope = arena_begin_temporal(arguments->arena);
            ByteSlice bad_offset = {
                .pointer = arena_allocate(arguments->arena, u8, long_coff.bytes.length),
                .length = long_coff.bytes.length,
            };
            memcpy(bad_offset.pointer, long_coff.bytes.pointer, long_coff.bytes.length);
            memset(bad_offset.pointer + section, 0, 8);
            memcpy(bad_offset.pointer + section, "/999999", 7);
            BUSTER_TEST(arguments, object_read(arguments->arena, bad_offset,
                                               (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS})
                                             .error != OBJECT_ERROR_NONE);
            arena_set_position(arguments->arena, bad_offset_scope.position);

            TemporalArena unterminated_scope = arena_begin_temporal(arguments->arena);
            ByteSlice unterminated = {
                .pointer = arena_allocate(arguments->arena, u8, long_coff.bytes.length),
                .length = long_coff.bytes.length,
            };
            memcpy(unterminated.pointer, long_coff.bytes.pointer, long_coff.bytes.length);
            unterminated.pointer[unterminated.length - 1] = 'x';
            BUSTER_TEST(arguments, object_read(arguments->arena, unterminated,
                                               (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS})
                                             .error != OBJECT_ERROR_NONE);
            arena_set_position(arguments->arena, unterminated_scope.position);
        }
    }
    u16 coff_machine = 0;
    if (coff.bytes.pointer && coff.bytes.length >= 2)
    {
        memcpy(&coff_machine, coff.bytes.pointer, 2);
    }
    BUSTER_TEST(arguments, coff_machine == 0x8664);
    ObjectArtifact mach = object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64);
    ObjectFile mach_roundtrip = object_read(arguments->arena, mach.bytes,
                                            (Target){
                                                .cpu_arch = CPU_ARCH_X86_64,
                                                .os = OPERATING_SYSTEM_MACOS,
                                            });
    if (BUSTER_REQUIRE(arguments, mach_roundtrip.error == OBJECT_ERROR_NONE))
    {
        BUSTER_TEST(arguments, mach_roundtrip.symbol_count == object.symbol_count);
        BUSTER_TEST(arguments, mach_roundtrip.relocation_count == object.relocation_count);
        if (BUSTER_REQUIRE(arguments, mach_roundtrip.sections && mach_roundtrip.section_count > OBJECT_SECTION_ZERO))
        {
            BUSTER_TEST(arguments, mach_roundtrip.sections[OBJECT_SECTION_ZERO].data.length == 0);
            BUSTER_TEST(arguments, mach_roundtrip.sections[OBJECT_SECTION_ZERO].virtual_size == BUSTER_MB(1));
        }
        bool mach_relocation_valid = mach_roundtrip.relocations && mach_roundtrip.relocation_count && mach_roundtrip.symbols &&
                                     mach_roundtrip.relocations[0].symbol < mach_roundtrip.symbol_count;
        if (BUSTER_REQUIRE(arguments, mach_relocation_valid))
        {
            BUSTER_TEST(arguments, mach_roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_PC32);
            BUSTER_TEST(arguments, mach_roundtrip.relocations[0].addend == -4);
            BUSTER_STRING_TEST(arguments, mach_roundtrip.symbols[mach_roundtrip.relocations[0].symbol].name, S8("object_callee"));
        }
    }
    u32 mach_magic = 0;
    if (mach.bytes.pointer && mach.bytes.length >= 4)
    {
        memcpy(&mach_magic, mach.bytes.pointer, 4);
    }
    BUSTER_TEST(arguments, mach_magic == 0xfeedfacf);
    sections[0].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(aarch64_text);
    object.target.cpu_arch = CPU_ARCH_AARCH64;
    relocation = (ObjectRelocation){
        .offset = 4,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_AARCH64_CALL26,
    };
    symbols[0].size = 16;
    symbols[1].value = 16;
    symbols[1].size = 8;
    ObjectArtifact aarch64_elf = object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64);
    BUSTER_TEST(arguments, aarch64_elf.error == OBJECT_ERROR_NONE);
    u16 aarch64_elf_machine = 0;
    if (aarch64_elf.bytes.pointer && aarch64_elf.bytes.length >= 20)
    {
        memcpy(&aarch64_elf_machine, aarch64_elf.bytes.pointer + 18, 2);
    }
    BUSTER_TEST(arguments, aarch64_elf_machine == 183);
    ObjectArtifact aarch64_coff = object_write(arguments->arena, &object, OBJECT_FORMAT_COFF);
    BUSTER_TEST(arguments, aarch64_coff.error == OBJECT_ERROR_NONE);
    u16 aarch64_coff_machine = 0;
    if (aarch64_coff.bytes.pointer && aarch64_coff.bytes.length >= 2)
    {
        memcpy(&aarch64_coff_machine, aarch64_coff.bytes.pointer, 2);
    }
    BUSTER_TEST(arguments, aarch64_coff_machine == 0xaa64);
    ObjectArtifact aarch64_mach = object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64);
    BUSTER_TEST(arguments, aarch64_mach.error == OBJECT_ERROR_NONE);
    u32 aarch64_mach_cpu = 0;
    if (aarch64_mach.bytes.pointer && aarch64_mach.bytes.length >= 8)
    {
        memcpy(&aarch64_mach_cpu, aarch64_mach.bytes.pointer + 4, 4);
    }
    BUSTER_TEST(arguments, aarch64_mach_cpu == 0x0100000c);
    u16 aarch64_mach_n_desc[5] = {0};
    bool aarch64_mach_n_desc_valid = true;
    for (u32 symbol_index = 0; symbol_index < BUSTER_ARRAY_LENGTH(aarch64_mach_n_desc); symbol_index += 1)
    {
        u64 symbol_offset = object_test_mach_symbol_offset(aarch64_mach.bytes, symbol_index);
        aarch64_mach_n_desc_valid &= symbol_offset != UINT64_MAX &&
                                     (u64)symbol_offset + 8 <= aarch64_mach.bytes.length;
        if (symbol_offset != UINT64_MAX && (u64)symbol_offset + 8 <= aarch64_mach.bytes.length)
        {
            memcpy(&aarch64_mach_n_desc[symbol_index], aarch64_mach.bytes.pointer + symbol_offset + 6, sizeof(u16));
        }
    }
    BUSTER_TEST(arguments, aarch64_mach_n_desc_valid && aarch64_mach_n_desc[0] == 2 && aarch64_mach_n_desc[1] == 2 &&
                               aarch64_mach_n_desc[2] == 2 && aarch64_mach_n_desc[3] == 0 && aarch64_mach_n_desc[4] == 2);
    u32 aarch64_jump_instruction = UINT32_C(0x14000000);
    memcpy(aarch64_text + 4, &aarch64_jump_instruction, sizeof(aarch64_jump_instruction));
    relocation.kind = OBJECT_RELOCATION_AARCH64_JUMP26;
    ObjectFormat aarch64_jump_formats[] = {OBJECT_FORMAT_ELF64, OBJECT_FORMAT_COFF, OBJECT_FORMAT_MACH_O64};
    OperatingSystem aarch64_jump_systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_MACOS};
    for (u32 format_index = 0; format_index < BUSTER_ARRAY_LENGTH(aarch64_jump_formats); format_index += 1)
    {
        ObjectArtifact jump_artifact = object_write(arguments->arena, &object, aarch64_jump_formats[format_index]);
        ObjectFile jump_roundtrip = object_read(arguments->arena, jump_artifact.bytes,
                                                (Target){
                                                    .cpu_arch = CPU_ARCH_AARCH64,
                                                    .os = aarch64_jump_systems[format_index],
                                                });
        BUSTER_TEST(arguments, jump_artifact.error == OBJECT_ERROR_NONE && jump_roundtrip.error == OBJECT_ERROR_NONE);
        BUSTER_TEST(arguments, jump_roundtrip.relocation_count == 1 &&
                                   jump_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_JUMP26 &&
                                   jump_roundtrip.relocations[0].addend == 0);
    }
    s64 mach_branch_addends[] = {-4, 4, -INT64_C(0x800000), INT64_C(0x7fffff)};
    for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(mach_branch_addends); addend_index += 1)
    {
        relocation.addend = mach_branch_addends[addend_index];
        ObjectArtifact addend_mach = object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64);
        u32 raw_offset = 0;
        u32 relocation_offset = 0;
        u32 relocation_count = 0;
        bool offsets_valid = object_test_mach_text_offsets(addend_mach.bytes, &raw_offset, &relocation_offset, &relocation_count);
        BUSTER_TEST(arguments, addend_mach.error == OBJECT_ERROR_NONE && offsets_valid && relocation_count == 2);
        u32 stored_instruction = 0;
        if (offsets_valid && (u64)raw_offset + relocation.offset <= addend_mach.bytes.length &&
            sizeof(stored_instruction) <= addend_mach.bytes.length - ((u64)raw_offset + relocation.offset))
        {
            memcpy(&stored_instruction, addend_mach.bytes.pointer + raw_offset + relocation.offset, sizeof(stored_instruction));
        }
        BUSTER_TEST(arguments, stored_instruction == UINT32_C(0x14000000));
        ObjectFile addend_roundtrip = object_read(arguments->arena, addend_mach.bytes,
                                                  (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
        BUSTER_TEST(arguments, addend_roundtrip.error == OBJECT_ERROR_NONE && addend_roundtrip.relocation_count == 1 &&
                                   addend_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_JUMP26 &&
                                   addend_roundtrip.relocations[0].addend == mach_branch_addends[addend_index]);
    }
    s64 invalid_mach_addends[] = {-INT64_C(0x800001), INT64_C(0x800000)};
    for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(invalid_mach_addends); addend_index += 1)
    {
        relocation.addend = invalid_mach_addends[addend_index];
        BUSTER_TEST(arguments, object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    }
    s64 unsupported_coff_addends[] = {-4, 4};
    for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(unsupported_coff_addends); addend_index += 1)
    {
        relocation.addend = unsupported_coff_addends[addend_index];
        BUSTER_TEST(arguments, object_write(arguments->arena, &object, OBJECT_FORMAT_COFF).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    }
    relocation.addend = 0;

    // ELF page relocations retain explicit RELA addends; REL ADRP carries
    // an unscaled signed literal, while ADD carries an unsigned low twelve.
    u32 elf_page_words[] = {UINT32_C(0xb0000008), UINT32_C(0xf0ffffe8), UINT32_C(0x913ffd08), UINT32_C(0x11000517)};
    u32 elf_page_canonical[] = {UINT32_C(0x90000008), UINT32_C(0x90000008), UINT32_C(0x91000108), UINT32_C(0x11000117)};
    s64 elf_page_implicit[] = {1, -1, 4095, 1};
    for (u32 case_index = 0; case_index < BUSTER_ARRAY_LENGTH(elf_page_words); case_index += 1)
    {
        ObjectSection page_sections[BUSTER_ARRAY_LENGTH(sections)];
        memcpy(page_sections, sections, sizeof(page_sections));
        u32 page_text[] = {elf_page_words[case_index], UINT32_C(0xd65f03c0), 0, 0, 0, 0};
        page_sections[OBJECT_SECTION_TEXT].data = (ByteSlice){.pointer = (u8*)page_text, .length = sizeof(page_text)};
        page_sections[OBJECT_SECTION_TEXT].virtual_size = sizeof(page_text);
        ObjectRelocation page_relocation = {.section = OBJECT_SECTION_TEXT, .symbol = 1, .addend = -17,
            .kind = case_index < 2 ? OBJECT_RELOCATION_AARCH64_ELF_PAGE21 : OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12};
        ObjectFile page_object = object;
        page_object.sections = page_sections;
        page_object.relocations = &page_relocation;
        for (u32 implicit = 0; implicit < 2; implicit += 1)
        {
            ObjectArtifact artifact = object_write(arguments->arena, &page_object, OBJECT_FORMAT_ELF64);
            u64 relocation_section = 0;
            u64 target_data = 0;
            bool offsets_valid = object_test_elf_relocation_offsets(artifact.bytes, &relocation_section, &target_data);
            BUSTER_TEST(arguments, artifact.error == OBJECT_ERROR_NONE && offsets_valid);
            if (!case_index && !implicit && offsets_valid)
            {
                u64 section_table = 0;
                u32 symbol_section = 0;
                u64 symbol_data = 0;
                u64 symbol_size = 0;
                memcpy(&section_table, artifact.bytes.pointer + 40, sizeof(section_table));
                memcpy(&symbol_section, artifact.bytes.pointer + relocation_section + 40, sizeof(symbol_section));
                memcpy(&symbol_data, artifact.bytes.pointer + section_table + (u64)symbol_section * 64 + 24, sizeof(symbol_data));
                memcpy(&symbol_size, artifact.bytes.pointer + section_table + (u64)symbol_section * 64 + 32, sizeof(symbol_size));
                for (u32 symbol_type = 0; symbol_type < 2; symbol_type += 1)
                {
                    for (u64 offset = 0; offset + 24 <= symbol_size; offset += 24)
                    {
                        u8* information = artifact.bytes.pointer + symbol_data + offset + 4;
                        if ((*information >> 4) != 0)
                        {
                            *information = (u8)((*information & 0xf0) | symbol_type);
                        }
                    }
                    ObjectFile typed = object_read(arguments->arena, artifact.bytes, page_object.target);
                    bool found = false;
                    for (u32 symbol_index = 0; typed.error == OBJECT_ERROR_NONE && symbol_index < typed.symbol_count; symbol_index += 1)
                    {
                        ObjectSymbol* symbol = typed.symbols + symbol_index;
                        if (string_equal(symbol->name, S8("object_entry")))
                        {
                            found = symbol->kind == (symbol_type ? OBJECT_SYMBOL_DATA : OBJECT_SYMBOL_FUNCTION);
                        }
                    }
                    BUSTER_TEST(arguments, found);
                }
            }
            if (implicit && offsets_valid)
            {
                object_test_write_u32(artifact.bytes, relocation_section + 4, 9);
                object_test_write_u64(artifact.bytes, relocation_section + 32, 16);
                object_test_write_u64(artifact.bytes, relocation_section + 56, 16);
            }
            ObjectFile imported = object_read(arguments->arena, artifact.bytes, page_object.target);
            bool valid = imported.error == OBJECT_ERROR_NONE && imported.relocation_count == 1;
            BUSTER_TEST(arguments, valid);
            if (valid)
            {
                BUSTER_TEST(arguments, imported.relocations[0].kind == page_relocation.kind);
                BUSTER_TEST(arguments, imported.relocations[0].addend == (implicit ? elf_page_implicit[case_index] : -17));
                BUSTER_STRING_TEST(arguments, imported.symbols[imported.relocations[0].symbol].name, S8("object_callee"));
                u32 canonical = 0;
                memcpy(&canonical, imported.sections[OBJECT_SECTION_TEXT].data.pointer, sizeof(canonical));
                BUSTER_TEST(arguments, canonical == elf_page_canonical[case_index]);
                ObjectArtifact rewritten = object_write(arguments->arena, &imported, OBJECT_FORMAT_ELF64);
                ObjectFile roundtrip = object_read(arguments->arena, rewritten.bytes, page_object.target);
                BUSTER_TEST(arguments, rewritten.error == OBJECT_ERROR_NONE && roundtrip.error == OBJECT_ERROR_NONE &&
                                       roundtrip.relocation_count == 1 && roundtrip.relocations[0].addend == imported.relocations[0].addend);
            }
            if (offsets_valid)
            {
                u32 invalid_words[] = {UINT32_C(0xd503201f), UINT32_C(0x10000008), UINT32_C(0x91400400), UINT32_C(0xf9400000)};
                for (u32 bad = 0; bad < BUSTER_ARRAY_LENGTH(invalid_words); bad += 1)
                {
                    object_test_write_u32(artifact.bytes, target_data, invalid_words[bad]);
                    BUSTER_TEST(arguments, object_read(arguments->arena, artifact.bytes, page_object.target).error != OBJECT_ERROR_NONE);
                }
                object_test_write_u32(artifact.bytes, target_data, elf_page_words[case_index]);
                u64 relocation_data = 0;
                memcpy(&relocation_data, artifact.bytes.pointer + relocation_section + 24, sizeof(relocation_data));
                object_test_write_u64(artifact.bytes, relocation_data, 1);
                BUSTER_TEST(arguments, object_read(arguments->arena, artifact.bytes, page_object.target).error != OBJECT_ERROR_NONE);
                object_test_write_u64(artifact.bytes, relocation_data, sizeof(page_text) - 2);
                BUSTER_TEST(arguments, object_read(arguments->arena, artifact.bytes, page_object.target).error != OBJECT_ERROR_NONE);

            }
        }
    }
    u32 page_patched = 0;
    BUSTER_TEST(arguments, object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_PAGE21, UINT32_C(0x90000008),
                                                         0x2004, 0x2fff, 1, &page_patched) && page_patched == UINT32_C(0xb0000008));
    BUSTER_TEST(arguments, object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_PAGE21, UINT32_C(0x90000008),
                                                         0x3004, 0x3000, -1, &page_patched) && page_patched == UINT32_C(0xf0ffffe8));
    BUSTER_TEST(arguments, object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12, UINT32_C(0x91000108),
                                                         0x2008, 0x2fff, 1, &page_patched) && page_patched == UINT32_C(0x91000108));
    BUSTER_TEST(arguments, object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12, UINT32_C(0x91000108),
                                                         0x2008, 0x3000, -1, &page_patched) && page_patched == UINT32_C(0x913ffd08));
    BUSTER_TEST(arguments, !object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_PAGE21, UINT32_C(0x90000008),
                                                          0, UINT64_C(0x100000000), 0, &page_patched));
    BUSTER_TEST(arguments, !object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_PAGE21, UINT32_C(0x90000008),
                                                          UINT64_C(0x100001000), 0, 0, &page_patched));
    BUSTER_TEST(arguments, !object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_PAGE21, UINT32_C(0x90000008),
                                                          1, 0, 0, &page_patched));
    BUSTER_TEST(arguments, !object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12, UINT32_C(0x91000108),
                                                          0, UINT64_MAX, 1, &page_patched));
    BUSTER_TEST(arguments, !object_aarch64_elf_page_relocate(OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12, UINT32_C(0x91000108),
                                                          0, 0, -1, &page_patched));

    u32 aarch64_branch_opcodes[] = {UINT32_C(0x14000000), UINT32_C(0x94000000)};
    ObjectRelocationKind aarch64_branch_kinds[] = {OBJECT_RELOCATION_AARCH64_JUMP26, OBJECT_RELOCATION_AARCH64_CALL26};
    s64 elf_rel_addends[] = {4, -4};
    for (u32 opcode_index = 0; opcode_index < BUSTER_ARRAY_LENGTH(aarch64_branch_opcodes); opcode_index += 1)
    {
        relocation.kind = aarch64_branch_kinds[opcode_index];
        memcpy(aarch64_text + 4, aarch64_branch_opcodes + opcode_index, sizeof(u32));
        for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(elf_rel_addends); addend_index += 1)
        {
            relocation.addend = elf_rel_addends[addend_index];
            ObjectArtifact rela_artifact = object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64);
            u64 rela_section = 0;
            u64 rela_target_data = 0;
            bool rela_offsets_valid = object_test_elf_relocation_offsets(rela_artifact.bytes, &rela_section, &rela_target_data);
            if (rela_offsets_valid)
            {
                u32 ignored_immediate = 0;
                bool ignored_encoded = a64_signed_scaled_immediate_encode(-elf_rel_addends[addend_index], 26, 2, &ignored_immediate);
                object_test_write_u32(rela_artifact.bytes, rela_target_data + relocation.offset,
                                      aarch64_branch_opcodes[opcode_index] | ignored_immediate);
                BUSTER_TEST(arguments, ignored_encoded);
            }
            ObjectFile rela_roundtrip = object_read(arguments->arena, rela_artifact.bytes,
                                                    (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX});
            BUSTER_TEST(arguments, rela_artifact.error == OBJECT_ERROR_NONE && rela_offsets_valid && rela_roundtrip.error == OBJECT_ERROR_NONE &&
                                       rela_roundtrip.relocation_count == 1 && rela_roundtrip.relocations[0].kind == aarch64_branch_kinds[opcode_index] &&
                                       rela_roundtrip.relocations[0].addend == elf_rel_addends[addend_index]);
            ObjectArtifact rela_rewritten = object_write(arguments->arena, &rela_roundtrip, OBJECT_FORMAT_ELF64);
            BUSTER_TEST(arguments, rela_rewritten.error == OBJECT_ERROR_NONE);

            relocation.addend = 0;
            ObjectArtifact rel_artifact = object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64);
            u64 relocation_section = 0;
            u64 target_data = 0;
            bool offsets_valid = object_test_elf_relocation_offsets(rel_artifact.bytes, &relocation_section, &target_data);
            BUSTER_TEST(arguments, rel_artifact.error == OBJECT_ERROR_NONE && offsets_valid);
            if (offsets_valid)
            {
                u32 encoded_immediate = 0;
                bool encoded = a64_signed_scaled_immediate_encode(elf_rel_addends[addend_index], 26, 2, &encoded_immediate);
                u32 rel_instruction = aarch64_branch_opcodes[opcode_index] | encoded_immediate;
                object_test_write_u32(rel_artifact.bytes, target_data + relocation.offset, rel_instruction);
                object_test_write_u32(rel_artifact.bytes, relocation_section + 4, 9);
                object_test_write_u64(rel_artifact.bytes, relocation_section + 32, 16);
                object_test_write_u64(rel_artifact.bytes, relocation_section + 56, 16);
                BUSTER_TEST(arguments, encoded);
            }
            ObjectFile rel_roundtrip = object_read(arguments->arena, rel_artifact.bytes,
                                                   (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX});
            BUSTER_TEST(arguments, rel_roundtrip.error == OBJECT_ERROR_NONE && rel_roundtrip.relocation_count == 1 &&
                                       rel_roundtrip.relocations[0].kind == aarch64_branch_kinds[opcode_index] &&
                                       rel_roundtrip.relocations[0].addend == elf_rel_addends[addend_index]);
            ObjectArtifact rel_rewritten = object_write(arguments->arena, &rel_roundtrip, OBJECT_FORMAT_ELF64);
            ObjectFile rel_rewritten_roundtrip = object_read(arguments->arena, rel_rewritten.bytes,
                                                             (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX});
            BUSTER_TEST(arguments, rel_rewritten.error == OBJECT_ERROR_NONE && rel_rewritten_roundtrip.error == OBJECT_ERROR_NONE &&
                                       rel_rewritten_roundtrip.relocation_count == 1 &&
                                       rel_rewritten_roundtrip.relocations[0].kind == aarch64_branch_kinds[opcode_index] &&
                                       rel_rewritten_roundtrip.relocations[0].addend == elf_rel_addends[addend_index]);
        }
    }

    relocation.kind = OBJECT_RELOCATION_AARCH64_JUMP26;
    relocation.addend = 0;
    aarch64_jump_instruction = UINT32_C(0x14000000);
    memcpy(aarch64_text + 4, &aarch64_jump_instruction, sizeof(aarch64_jump_instruction));
    ObjectArtifact valid_mach_branch = object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64);
    u32 mach_raw_offset = 0;
    u32 mach_relocation_offset = 0;
    u32 mach_relocation_count = 0;
    bool mach_offsets_valid = object_test_mach_text_offsets(valid_mach_branch.bytes, &mach_raw_offset, &mach_relocation_offset, &mach_relocation_count);
    BUSTER_TEST(arguments, valid_mach_branch.error == OBJECT_ERROR_NONE && mach_offsets_valid && mach_relocation_count == 1);
    if (mach_offsets_valid)
    {
        u32 relocation_information = 0;
        memcpy(&relocation_information, valid_mach_branch.bytes.pointer + mach_relocation_offset + 4, sizeof(relocation_information));
        object_test_write_u32(valid_mach_branch.bytes, mach_relocation_offset + 4, relocation_information & ~(1u << 24));
    }
    BUSTER_TEST(arguments, object_read(arguments->arena, valid_mach_branch.bytes,
                                       (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                 .error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    valid_mach_branch = object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64);
    mach_offsets_valid = object_test_mach_text_offsets(valid_mach_branch.bytes, &mach_raw_offset, &mach_relocation_offset, &mach_relocation_count);
    if (mach_offsets_valid)
    {
        u32 relocation_information = 0;
        memcpy(&relocation_information, valid_mach_branch.bytes.pointer + mach_relocation_offset + 4, sizeof(relocation_information));
        object_test_write_u32(valid_mach_branch.bytes, mach_relocation_offset + 4, relocation_information & ~(1u << 27));
    }
    BUSTER_TEST(arguments, mach_offsets_valid &&
                               object_read(arguments->arena, valid_mach_branch.bytes,
                                           (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                       .error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    valid_mach_branch = object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64);
    mach_offsets_valid = object_test_mach_text_offsets(valid_mach_branch.bytes, &mach_raw_offset, &mach_relocation_offset, &mach_relocation_count);
    if (mach_offsets_valid)
    {
        object_test_write_u32(valid_mach_branch.bytes, (u64)mach_raw_offset + relocation.offset, UINT32_C(0x14000001));
    }
    BUSTER_TEST(arguments, mach_offsets_valid &&
                               object_read(arguments->arena, valid_mach_branch.bytes,
                                           (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                       .error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    relocation.addend = 4;
    ObjectArtifact malformed_addend_pair = object_write(arguments->arena, &object, OBJECT_FORMAT_MACH_O64);
    mach_offsets_valid = object_test_mach_text_offsets(malformed_addend_pair.bytes, &mach_raw_offset, &mach_relocation_offset, &mach_relocation_count);
    if (mach_offsets_valid && mach_relocation_count == 2)
    {
        u32 addend_information = 0;
        memcpy(&addend_information, malformed_addend_pair.bytes.pointer + mach_relocation_offset + 4, sizeof(addend_information));
        object_test_write_u32(malformed_addend_pair.bytes, mach_relocation_offset + 4, addend_information | (1u << 27));
    }
    BUSTER_TEST(arguments, mach_offsets_valid && mach_relocation_count == 2 &&
                               object_read(arguments->arena, malformed_addend_pair.bytes,
                                           (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                       .error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    relocation.addend = 0;

    u8 direct_page_words[] = {0x09, 0x00, 0x00, 0x90, 0x29, 0x01, 0x00, 0x91};
    ObjectSection direct_page_sections[] = {
        {
            .name = S8(".text"),
            .data = BUSTER_ARRAY_TO_SLICE(direct_page_words),
            .kind = OBJECT_SECTION_TEXT,
            .alignment = 4,
        },
    };
    ObjectSymbol direct_page_symbols[] = {
        {
            .name = S8("direct_page_target"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectRelocation direct_page_relocations[] = {
        {
            .offset = 0,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGE21,
        },
        {
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12,
        },
    };
    ObjectFile direct_page_object = {
        .sections = direct_page_sections,
        .section_count = BUSTER_ARRAY_LENGTH(direct_page_sections),
        .symbols = direct_page_symbols,
        .symbol_count = BUSTER_ARRAY_LENGTH(direct_page_symbols),
        .relocations = direct_page_relocations,
        .relocation_count = BUSTER_ARRAY_LENGTH(direct_page_relocations),
        .target = {
            .cpu_arch = CPU_ARCH_AARCH64,
            .os = OPERATING_SYSTEM_MACOS,
        },
    };
    String8 direct_page_assembly = object_print_assembly(arguments->arena, &direct_page_object);
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(direct_page_assembly), S8("\tadrp x9, _direct_page_target@PAGE\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(direct_page_assembly), S8("\tadd x9, x9, _direct_page_target@PAGEOFF\n")));
    u32 saved_direct_page_instruction = 0;
    memcpy(&saved_direct_page_instruction, direct_page_words, sizeof(saved_direct_page_instruction));
    u32 page21_xzr_instruction = UINT32_C(0x9000001f);
    memcpy(direct_page_words, &page21_xzr_instruction, sizeof(page21_xzr_instruction));
    String8 page21_xzr_assembly = object_print_assembly(arguments->arena, &direct_page_object);
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(page21_xzr_assembly), S8("\tadrp xzr, _direct_page_target@PAGE\n")));
    BUSTER_TEST(arguments, object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64).error == OBJECT_ERROR_NONE);
    memcpy(direct_page_words, &saved_direct_page_instruction, sizeof(saved_direct_page_instruction));
    u32 malformed_page21_instruction = UINT32_C(0x14000000);
    memcpy(direct_page_words, &malformed_page21_instruction, sizeof(malformed_page21_instruction));
    BUSTER_TEST(arguments, object_print_assembly(arguments->arena, &direct_page_object).length == 0);
    memcpy(direct_page_words, &saved_direct_page_instruction, sizeof(saved_direct_page_instruction));
    ObjectArtifact direct_page_mach = object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64);
    u32 direct_page_raw_offset = 0;
    u32 direct_page_relocation_offset = 0;
    u32 direct_page_relocation_count = 0;
    bool direct_page_offsets_valid = object_test_mach_text_offsets(direct_page_mach.bytes, &direct_page_raw_offset,
                                                                    &direct_page_relocation_offset, &direct_page_relocation_count);
    BUSTER_TEST(arguments, direct_page_mach.error == OBJECT_ERROR_NONE && direct_page_offsets_valid && direct_page_relocation_count == 2);
    if (direct_page_offsets_valid && direct_page_relocation_count == 2)
    {
        u32 high_information = 0;
        u32 low_information = 0;
        memcpy(&high_information, direct_page_mach.bytes.pointer + direct_page_relocation_offset + 4, sizeof(high_information));
        memcpy(&low_information, direct_page_mach.bytes.pointer + direct_page_relocation_offset + 8 + 4, sizeof(low_information));
        BUSTER_TEST(arguments, high_information >> 28 == 3 && low_information >> 28 == 4);
        BUSTER_TEST(arguments, (high_information & (1u << 24)) != 0 && (low_information & (1u << 24)) == 0);
        BUSTER_TEST(arguments, ((high_information >> 25) & 3) == 2 && ((low_information >> 25) & 3) == 2);
        BUSTER_TEST(arguments, (high_information & (1u << 27)) != 0 && (low_information & (1u << 27)) != 0);
        BUSTER_TEST(arguments, direct_page_mach.bytes.pointer[direct_page_relocation_offset] == 0);
        BUSTER_TEST(arguments, direct_page_mach.bytes.pointer[direct_page_relocation_offset + 8] == sizeof(u32));
    }
    ObjectFile direct_page_roundtrip = object_read(arguments->arena, direct_page_mach.bytes,
                                                   (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    BUSTER_TEST(arguments, direct_page_roundtrip.error == OBJECT_ERROR_NONE && direct_page_roundtrip.relocation_count == 2);
    if (direct_page_roundtrip.error == OBJECT_ERROR_NONE && direct_page_roundtrip.relocation_count == 2)
    {
        BUSTER_TEST(arguments, direct_page_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_MACH_PAGE21 &&
                                   direct_page_roundtrip.relocations[1].kind == OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12 &&
                                   direct_page_roundtrip.symbol_count >= 1 &&
                                   direct_page_roundtrip.symbols[0].kind == OBJECT_SYMBOL_DATA);
        BUSTER_TEST(arguments, direct_page_roundtrip.relocations[0].offset == 0 && direct_page_roundtrip.relocations[1].offset == sizeof(u32));
    }
    u32 tlvp_words[] = {UINT32_C(0x90000009), UINT32_C(0xf9400129)};
    ObjectSection tlvp_section = {
        .name = S8(".text"),
        .data = {.pointer = (u8*)tlvp_words, .length = sizeof(tlvp_words)},
        .kind = OBJECT_SECTION_TEXT,
        .alignment = 4,
    };
    ObjectSymbol tlvp_symbol = {
        .name = S8("tls_value"),
        .section = OBJECT_SECTION_UNDEFINED,
        .kind = OBJECT_SYMBOL_DATA,
        .global = true,
    };
    ObjectRelocation tlvp_relocations[] = {
        {
            .addend = 0x1000,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGE21,
        },
        {
            .addend = 8,
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGEOFF12,
        },
    };
    ObjectFile tlvp_object = {
        .sections = &tlvp_section,
        .symbols = &tlvp_symbol,
        .relocations = tlvp_relocations,
        .target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS},
        .section_count = 1,
        .symbol_count = 1,
        .relocation_count = BUSTER_ARRAY_LENGTH(tlvp_relocations),
    };
    ObjectArtifact tlvp_mach = object_write(arguments->arena, &tlvp_object, OBJECT_FORMAT_MACH_O64);
    ObjectFile tlvp_roundtrip = object_read(arguments->arena, tlvp_mach.bytes,
                                            (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    BUSTER_TEST(arguments, tlvp_mach.error == OBJECT_ERROR_NONE && tlvp_roundtrip.error == OBJECT_ERROR_NONE &&
                               tlvp_roundtrip.relocation_count == BUSTER_ARRAY_LENGTH(tlvp_relocations));
    if (tlvp_roundtrip.error == OBJECT_ERROR_NONE && tlvp_roundtrip.relocation_count == BUSTER_ARRAY_LENGTH(tlvp_relocations))
    {
        BUSTER_TEST(arguments, tlvp_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGE21 &&
                                   tlvp_roundtrip.relocations[1].kind == OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGEOFF12 &&
                                   tlvp_roundtrip.relocations[0].addend == 0x1000 && tlvp_roundtrip.relocations[1].addend == 8);
    }
    tlvp_words[1] = UINT32_C(0x91000029);
    BUSTER_TEST(arguments, object_write(arguments->arena, &tlvp_object, OBJECT_FORMAT_MACH_O64).error != OBJECT_ERROR_NONE);
    tlvp_words[1] = UINT32_C(0xf9400129);
    u64 direct_page_symbol_offset = object_test_mach_symbol_offset(direct_page_mach.bytes, 0);
    u16 direct_page_n_desc = 0;
    if (direct_page_symbol_offset != UINT64_MAX && direct_page_symbol_offset + 8 <= direct_page_mach.bytes.length)
    {
        memcpy(&direct_page_n_desc, direct_page_mach.bytes.pointer + direct_page_symbol_offset + 6, sizeof(direct_page_n_desc));
    }
    BUSTER_TEST(arguments, direct_page_n_desc == 0);
    ObjectArtifact lazy_reference_kind_one = object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64);
    u64 lazy_reference_symbol = object_test_mach_symbol_offset(lazy_reference_kind_one.bytes, 0);
    ObjectFile lazy_reference_kind_one_roundtrip = {0};
    if (lazy_reference_symbol != UINT64_MAX && lazy_reference_symbol + 8 <= lazy_reference_kind_one.bytes.length)
    {
        object_test_write_u16(lazy_reference_kind_one.bytes, lazy_reference_symbol + 6, 1);
        lazy_reference_kind_one_roundtrip = object_read(arguments->arena, lazy_reference_kind_one.bytes,
                                                         (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    }
    BUSTER_TEST(arguments, lazy_reference_kind_one_roundtrip.error == OBJECT_ERROR_NONE &&
                               lazy_reference_kind_one_roundtrip.symbol_count >= 1 &&
                               lazy_reference_kind_one_roundtrip.symbols[0].kind == OBJECT_SYMBOL_FUNCTION);
    ObjectArtifact lazy_reference_kind_five = object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64);
    lazy_reference_symbol = object_test_mach_symbol_offset(lazy_reference_kind_five.bytes, 0);
    ObjectFile lazy_reference_kind_five_roundtrip = {0};
    if (lazy_reference_symbol != UINT64_MAX && lazy_reference_symbol + 8 <= lazy_reference_kind_five.bytes.length)
    {
        object_test_write_u16(lazy_reference_kind_five.bytes, lazy_reference_symbol + 6, 5);
        lazy_reference_kind_five_roundtrip = object_read(arguments->arena, lazy_reference_kind_five.bytes,
                                                          (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    }
    BUSTER_TEST(arguments, lazy_reference_kind_five_roundtrip.error == OBJECT_ERROR_NONE &&
                               lazy_reference_kind_five_roundtrip.symbol_count >= 1 &&
                               lazy_reference_kind_five_roundtrip.symbols[0].kind == OBJECT_SYMBOL_FUNCTION);
    ObjectArtifact unknown_reference_kind = object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64);
    u64 unknown_reference_symbol = object_test_mach_symbol_offset(unknown_reference_kind.bytes, 0);
    if (unknown_reference_symbol != UINT64_MAX && unknown_reference_symbol + 8 <= unknown_reference_kind.bytes.length)
    {
        object_test_write_u16(unknown_reference_kind.bytes, unknown_reference_symbol + 6, 7);
    }
    BUSTER_TEST(arguments, unknown_reference_kind.error == OBJECT_ERROR_NONE &&
                               object_read(arguments->arena, unknown_reference_kind.bytes,
                                           (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                       .error != OBJECT_ERROR_NONE);
    ObjectRelocation direct_page_addend_relocations[] = {
        direct_page_relocations[0],
        direct_page_relocations[1],
    };
    direct_page_addend_relocations[0].addend = 0x1000;
    direct_page_addend_relocations[1].addend = 4;
    ObjectFile direct_page_addend_object = direct_page_object;
    direct_page_addend_object.relocations = direct_page_addend_relocations;
    ObjectArtifact direct_page_addend_mach = object_write(arguments->arena, &direct_page_addend_object, OBJECT_FORMAT_MACH_O64);
    u32 direct_page_addend_raw_offset = 0;
    u32 direct_page_addend_relocation_offset = 0;
    u32 direct_page_addend_relocation_count = 0;
    bool direct_page_addend_offsets_valid = object_test_mach_text_offsets(direct_page_addend_mach.bytes, &direct_page_addend_raw_offset,
                                                                           &direct_page_addend_relocation_offset,
                                                                           &direct_page_addend_relocation_count);
    BUSTER_TEST(arguments, direct_page_addend_mach.error == OBJECT_ERROR_NONE && direct_page_addend_offsets_valid &&
                               direct_page_addend_relocation_count == 4);
    ObjectFile direct_page_addend_roundtrip = object_read(arguments->arena, direct_page_addend_mach.bytes,
                                                          (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    BUSTER_TEST(arguments, direct_page_addend_roundtrip.error == OBJECT_ERROR_NONE && direct_page_addend_roundtrip.relocation_count == 2);
    if (direct_page_addend_roundtrip.error == OBJECT_ERROR_NONE && direct_page_addend_roundtrip.relocation_count == 2)
    {
        BUSTER_TEST(arguments, direct_page_addend_roundtrip.relocations[0].addend == 0x1000 &&
                                   direct_page_addend_roundtrip.relocations[1].addend == 4);
    }
    ObjectArtifact malformed_direct_page = object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64);
    if (object_test_mach_text_offsets(malformed_direct_page.bytes, &direct_page_raw_offset, &direct_page_relocation_offset, &direct_page_relocation_count))
    {
        object_test_write_u32(malformed_direct_page.bytes, (u64)direct_page_raw_offset, UINT32_C(0x14000000));
    }
    BUSTER_TEST(arguments, object_read(arguments->arena, malformed_direct_page.bytes,
                                       (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                 .error != OBJECT_ERROR_NONE);
    malformed_direct_page = object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64);
    if (object_test_mach_text_offsets(malformed_direct_page.bytes, &direct_page_raw_offset, &direct_page_relocation_offset, &direct_page_relocation_count))
    {
        u32 information = 0;
        memcpy(&information, malformed_direct_page.bytes.pointer + direct_page_relocation_offset + 8 + 4, sizeof(information));
        object_test_write_u32(malformed_direct_page.bytes, direct_page_relocation_offset + 8 + 4, information | (1u << 24));
    }
    BUSTER_TEST(arguments, object_read(arguments->arena, malformed_direct_page.bytes,
                                       (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                 .error != OBJECT_ERROR_NONE);
    malformed_direct_page = object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64);
    if (object_test_mach_text_offsets(malformed_direct_page.bytes, &direct_page_raw_offset, &direct_page_relocation_offset, &direct_page_relocation_count))
    {
        object_test_write_u32(malformed_direct_page.bytes, direct_page_relocation_offset + 8, 2 * sizeof(u32));
    }
    BUSTER_TEST(arguments, object_read(arguments->arena, malformed_direct_page.bytes,
                                       (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                 .error != OBJECT_ERROR_NONE);
    ObjectRelocation standalone_pageoff = direct_page_relocations[1];
    ObjectFile standalone_pageoff_object = direct_page_object;
    standalone_pageoff_object.relocations = &standalone_pageoff;
    standalone_pageoff_object.relocation_count = 1;
    ObjectArtifact standalone_pageoff_mach = object_write(arguments->arena, &standalone_pageoff_object, OBJECT_FORMAT_MACH_O64);
    BUSTER_TEST(arguments, standalone_pageoff_mach.error == OBJECT_ERROR_NONE &&
                               object_read(arguments->arena, standalone_pageoff_mach.bytes,
                                           (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                       .error == OBJECT_ERROR_NONE);

    ObjectRelocation standalone_page21 = direct_page_relocations[0];
    ObjectFile standalone_page21_object = direct_page_object;
    standalone_page21_object.relocations = &standalone_page21;
    standalone_page21_object.relocation_count = 1;
    ObjectArtifact standalone_page21_mach = object_write(arguments->arena, &standalone_page21_object, OBJECT_FORMAT_MACH_O64);
    BUSTER_TEST(arguments, standalone_page21_mach.error == OBJECT_ERROR_NONE &&
                               object_read(arguments->arena, standalone_page21_mach.bytes,
                                           (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS})
                                       .error == OBJECT_ERROR_NONE);

    // LLVM writes Mach-O relocations in descending place order.  The reader
    // must preserve each ADDEND's own PAGE relocation without pairing it to a
    // neighboring PAGE21/PAGEOFF12 record.
    ObjectArtifact descending_direct_page = object_write(arguments->arena, &direct_page_addend_object, OBJECT_FORMAT_MACH_O64);
    if (object_test_mach_text_offsets(descending_direct_page.bytes, &direct_page_addend_raw_offset, &direct_page_addend_relocation_offset,
                                      &direct_page_addend_relocation_count) &&
        direct_page_addend_relocation_count == 4)
    {
        u8 records[2 * 8];
        memcpy(records, descending_direct_page.bytes.pointer + direct_page_addend_relocation_offset, sizeof(records));
        memcpy(descending_direct_page.bytes.pointer + direct_page_addend_relocation_offset,
               descending_direct_page.bytes.pointer + direct_page_addend_relocation_offset + sizeof(records), sizeof(records));
        memcpy(descending_direct_page.bytes.pointer + direct_page_addend_relocation_offset + sizeof(records), records, sizeof(records));
    }
    ObjectFile descending_direct_page_roundtrip = object_read(arguments->arena, descending_direct_page.bytes,
                                                              (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    BUSTER_TEST(arguments, descending_direct_page_roundtrip.error == OBJECT_ERROR_NONE && descending_direct_page_roundtrip.relocation_count == 2);
    if (descending_direct_page_roundtrip.error == OBJECT_ERROR_NONE && descending_direct_page_roundtrip.relocation_count == 2)
    {
        BUSTER_TEST(arguments, descending_direct_page_roundtrip.relocations[0].offset == sizeof(u32) &&
                                   descending_direct_page_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12 &&
                                   descending_direct_page_roundtrip.relocations[0].addend == 4 &&
                                   descending_direct_page_roundtrip.relocations[1].offset == 0 &&
                                   descending_direct_page_roundtrip.relocations[1].kind == OBJECT_RELOCATION_AARCH64_MACH_PAGE21 &&
                                   descending_direct_page_roundtrip.relocations[1].addend == 0x1000);
    }

    u32 pageoff_words[] = {
        UINT32_C(0x91000041), // add x1, x2, #0
        UINT32_C(0xf9400083), // ldr x3, [x4]
        UINT32_C(0x394000c5), // ldrb w5, [x6]
        UINT32_C(0x79400107), // ldrh w7, [x8]
        UINT32_C(0x39800149), // ldrsb x9, [x10]
        UINT32_C(0x79c0018b), // ldrsh w11, [x12]
        UINT32_C(0xb98001cd), // ldrsw x13, [x14]
        UINT32_C(0x3d400020), // ldr b0, [x1]
        UINT32_C(0x7d400062), // ldr h2, [x3]
        UINT32_C(0xbd4000a4), // ldr s4, [x5]
        UINT32_C(0xfd4000e6), // ldr d6, [x7]
        UINT32_C(0x3d00016a), // str b10, [x11]
        UINT32_C(0x7d0001ac), // str h12, [x13]
        UINT32_C(0xbd0001ee), // str s14, [x15]
        UINT32_C(0xfd000230), // str d16, [x17]
        UINT32_C(0x3dc0020f), // ldr q15, [x16]
        UINT32_C(0x3d80024f), // str q15, [x18]
        UINT32_C(0xf9800280), // prfm pldl1keep, [x20]
        UINT32_C(0xf9800288), // prfm plil1keep, [x20]
        UINT32_C(0xf9800290), // prfm pstl1keep, [x20]
        UINT32_C(0x394000ff), // ldrb wzr, [x7]
        UINT32_C(0x390001ff), // strb wzr, [x15]
        UINT32_C(0xf94000ff), // ldr xzr, [x7]
        UINT32_C(0xf90001ff), // str xzr, [x15]
        UINT32_C(0x9100003f), // add sp, x1, #0
    };
    ObjectRelocation pageoff_relocations[BUSTER_ARRAY_LENGTH(pageoff_words)];
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(pageoff_relocations); index += 1)
    {
        pageoff_relocations[index] = (ObjectRelocation){
            .offset = index * sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12,
        };
    }
    ObjectSection pageoff_sections[] = {
        {
            .name = S8(".text"),
            .data = {.pointer = (u8*)pageoff_words, .length = sizeof(pageoff_words)},
            .kind = OBJECT_SECTION_TEXT,
            .alignment = 4,
        },
    };
    ObjectFile pageoff_object = direct_page_object;
    pageoff_object.sections = pageoff_sections;
    pageoff_object.section_count = BUSTER_ARRAY_LENGTH(pageoff_sections);
    pageoff_object.relocations = pageoff_relocations;
    pageoff_object.relocation_count = BUSTER_ARRAY_LENGTH(pageoff_relocations);
    String8 pageoff_assembly = object_print_assembly(arguments->arena, &pageoff_object);
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tadd x1, x2, _direct_page_target@PAGEOFF\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldr x3, [x4, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldrb w5, [x6, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldrh w7, [x8, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldrsb x9, [x10, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldrsh w11, [x12, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldrsw x13, [x14, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldr b0, [x1, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldr h2, [x3, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldr s4, [x5, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldr d6, [x7, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tstr b10, [x11, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tstr h12, [x13, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tstr s14, [x15, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tstr d16, [x17, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldr q15, [x16, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tstr q15, [x18, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tprfm pldl1keep, [x20, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tprfm plil1keep, [x20, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tprfm pstl1keep, [x20, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldrb wzr, [x7, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tstrb wzr, [x15, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tldr xzr, [x7, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tstr xzr, [x15, _direct_page_target@PAGEOFF]\n")));
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(pageoff_assembly), S8("\tadd sp, x1, _direct_page_target@PAGEOFF\n")));
    ObjectArtifact pageoff_mach = object_write(arguments->arena, &pageoff_object, OBJECT_FORMAT_MACH_O64);
    ObjectFile pageoff_roundtrip = object_read(arguments->arena, pageoff_mach.bytes,
                                               (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    BUSTER_TEST(arguments, pageoff_mach.error == OBJECT_ERROR_NONE && pageoff_roundtrip.error == OBJECT_ERROR_NONE &&
                               pageoff_roundtrip.relocation_count == BUSTER_ARRAY_LENGTH(pageoff_words));
    if (pageoff_roundtrip.error == OBJECT_ERROR_NONE && pageoff_roundtrip.relocation_count == BUSTER_ARRAY_LENGTH(pageoff_words))
    {
        BUSTER_TEST(arguments, pageoff_roundtrip.sections[OBJECT_SECTION_TEXT].data.length == sizeof(pageoff_words) &&
                                   memcmp(pageoff_roundtrip.sections[OBJECT_SECTION_TEXT].data.pointer, pageoff_words, sizeof(pageoff_words)) == 0);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(pageoff_words); index += 1)
        {
            BUSTER_TEST(arguments, pageoff_roundtrip.relocations[index].kind == OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12 &&
                                       pageoff_roundtrip.relocations[index].offset == index * sizeof(u32));
        }
    }
    u32 valid_pageoff_bases[] = {
        UINT32_C(0x91000000),
        UINT32_C(0x39000000), UINT32_C(0x39400000), UINT32_C(0x39800000), UINT32_C(0x39c00000),
        UINT32_C(0x79000000), UINT32_C(0x79400000), UINT32_C(0x79800000), UINT32_C(0x79c00000),
        UINT32_C(0xb9000000), UINT32_C(0xb9400000), UINT32_C(0xb9800000),
        UINT32_C(0xf9000000), UINT32_C(0xf9400000), UINT32_C(0xf9800000),
        UINT32_C(0x3d000000), UINT32_C(0x3d400000), UINT32_C(0x3d800000), UINT32_C(0x3dc00000),
        UINT32_C(0x7d000000), UINT32_C(0x7d400000),
        UINT32_C(0xbd000000), UINT32_C(0xbd400000),
        UINT32_C(0xfd000000), UINT32_C(0xfd400000),
    };
    u32 invalid_pageoff_bases[] = {
        UINT32_C(0x91800000),
        UINT32_C(0xb9c00000), UINT32_C(0xf9c00000),
        UINT32_C(0x7d800000), UINT32_C(0x7dc00000),
        UINT32_C(0xbd800000), UINT32_C(0xbdc00000),
        UINT32_C(0xfd800000), UINT32_C(0xfdc00000),
    };
    ObjectFile pageoff_domain_object = pageoff_object;
    pageoff_domain_object.relocation_count = 1;
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(valid_pageoff_bases); index += 1)
    {
        pageoff_words[0] = valid_pageoff_bases[index];
        BUSTER_TEST(arguments, object_write(arguments->arena, &pageoff_domain_object, OBJECT_FORMAT_MACH_O64).error == OBJECT_ERROR_NONE);
    }
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(invalid_pageoff_bases); index += 1)
    {
        pageoff_words[0] = invalid_pageoff_bases[index];
        BUSTER_TEST(arguments, object_write(arguments->arena, &pageoff_domain_object, OBJECT_FORMAT_MACH_O64).error != OBJECT_ERROR_NONE);
    }
    pageoff_words[0] = UINT32_C(0x91000041);
    u32 saved_pageoff_word = pageoff_words[0];
    pageoff_words[0] = UINT32_C(0x91000441); // stale imm12
    BUSTER_TEST(arguments, object_write(arguments->arena, &pageoff_object, OBJECT_FORMAT_MACH_O64).error != OBJECT_ERROR_NONE);
    pageoff_words[0] = UINT32_C(0x14000000); // unrelated opcode
    BUSTER_TEST(arguments, object_write(arguments->arena, &pageoff_object, OBJECT_FORMAT_MACH_O64).error != OBJECT_ERROR_NONE);
    pageoff_words[0] = saved_pageoff_word;
    ObjectRelocation misaligned_pageoff_relocation = pageoff_relocations[0];
    misaligned_pageoff_relocation.offset = 2;
    ObjectFile misaligned_pageoff_object = pageoff_object;
    misaligned_pageoff_object.relocations = &misaligned_pageoff_relocation;
    misaligned_pageoff_object.relocation_count = 1;
    BUSTER_TEST(arguments, object_write(arguments->arena, &misaligned_pageoff_object, OBJECT_FORMAT_MACH_O64).error != OBJECT_ERROR_NONE);
    ObjectRelocation out_of_range_page_addend = direct_page_relocations[0];
    out_of_range_page_addend.addend = INT64_C(0x800000);
    ObjectFile out_of_range_page_object = direct_page_object;
    out_of_range_page_object.relocations = &out_of_range_page_addend;
    out_of_range_page_object.relocation_count = 1;
    BUSTER_TEST(arguments, object_write(arguments->arena, &out_of_range_page_object, OBJECT_FORMAT_MACH_O64).error != OBJECT_ERROR_NONE);
    u32 saved_direct_page_high = 0;
    memcpy(&saved_direct_page_high, direct_page_words, sizeof(saved_direct_page_high));
    direct_page_words[0] |= 1u << 5; // stale ADRP immediate
    BUSTER_TEST(arguments, object_write(arguments->arena, &direct_page_object, OBJECT_FORMAT_MACH_O64).error != OBJECT_ERROR_NONE);
    memcpy(direct_page_words, &saved_direct_page_high, sizeof(saved_direct_page_high));

    ObjectArtifact stale_coff_branch = object_write(arguments->arena, &object, OBJECT_FORMAT_COFF);
    u32 coff_raw_offset = 0;
    if (stale_coff_branch.bytes.pointer && stale_coff_branch.bytes.length >= 44)
    {
        memcpy(&coff_raw_offset, stale_coff_branch.bytes.pointer + 40, sizeof(coff_raw_offset));
    }
    object_test_write_u32(stale_coff_branch.bytes, (u64)coff_raw_offset + relocation.offset, UINT32_C(0x14000001));
    BUSTER_TEST(arguments, object_read(arguments->arena, stale_coff_branch.bytes,
                                       (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_WINDOWS})
                                 .error == OBJECT_ERROR_UNSUPPORTED_TARGET);

    ObjectFormat strict_branch_formats[] = {OBJECT_FORMAT_ELF64, OBJECT_FORMAT_COFF, OBJECT_FORMAT_MACH_O64};
    aarch64_jump_instruction = UINT32_C(0x94000000);
    memcpy(aarch64_text + 4, &aarch64_jump_instruction, sizeof(aarch64_jump_instruction));
    for (u32 format_index = 0; format_index < BUSTER_ARRAY_LENGTH(strict_branch_formats); format_index += 1)
    {
        BUSTER_TEST(arguments, object_write(arguments->arena, &object, strict_branch_formats[format_index]).error == OBJECT_ERROR_INVALID_INPUT);
    }
    aarch64_jump_instruction = UINT32_C(0x14000001);
    memcpy(aarch64_text + 4, &aarch64_jump_instruction, sizeof(aarch64_jump_instruction));
    for (u32 format_index = 0; format_index < BUSTER_ARRAY_LENGTH(strict_branch_formats); format_index += 1)
    {
        BUSTER_TEST(arguments, object_write(arguments->arena, &object, strict_branch_formats[format_index]).error == OBJECT_ERROR_INVALID_INPUT);
    }
    aarch64_jump_instruction = UINT32_C(0x14000000);
    memcpy(aarch64_text + 4, &aarch64_jump_instruction, sizeof(aarch64_jump_instruction));
    ObjectArtifact underaligned_elf = object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64);
    u64 underaligned_relocation_section = 0;
    u64 underaligned_target_data = 0;
    bool underaligned_offsets_valid =
        object_test_elf_relocation_offsets(underaligned_elf.bytes, &underaligned_relocation_section, &underaligned_target_data);
    if (underaligned_offsets_valid)
    {
        u64 section_table = 0;
        u32 target_index = 0;
        memcpy(&section_table, underaligned_elf.bytes.pointer + 40, sizeof(section_table));
        memcpy(&target_index, underaligned_elf.bytes.pointer + underaligned_relocation_section + 44, sizeof(target_index));
        object_test_write_u64(underaligned_elf.bytes, section_table + (u64)target_index * 64 + 48, 1);
    }
    BUSTER_TEST(arguments, underaligned_offsets_valid);
    if (underaligned_offsets_valid)
    {
        ObjectFile rejected = object_read(arguments->arena, underaligned_elf.bytes,
                                          (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX});
        BUSTER_TEST(arguments, rejected.error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        // The reader owns this copied section, but must not canonicalize an
        // instruction after its relocation validation has already failed.
        bool text_present = rejected.sections && rejected.section_count > OBJECT_SECTION_TEXT &&
                            rejected.sections[OBJECT_SECTION_TEXT].data.length == sizeof(aarch64_text);
        BUSTER_TEST(arguments, text_present);
        if (text_present)
        {
            BUSTER_TEST(arguments, memcmp(rejected.sections[OBJECT_SECTION_TEXT].data.pointer, aarch64_text, sizeof(aarch64_text)) == 0);
        }
        BUSTER_TEST(arguments, rejected.relocation_count == 0);
    }
    sections[0].alignment = 1;
    BUSTER_TEST(arguments, object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64).error == OBJECT_ERROR_INVALID_INPUT);
    sections[0].alignment = 16;
    relocation.offset = 5;
    BUSTER_TEST(arguments, object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64).error == OBJECT_ERROR_INVALID_INPUT);
    relocation.offset = UINT64_MAX - 1;
    BUSTER_TEST(arguments, object_write(arguments->arena, &object, OBJECT_FORMAT_ELF64).error == OBJECT_ERROR_INVALID_INPUT);
    relocation.offset = 4;
    u8 misaligned_link_text[12] = {0};
    memcpy(misaligned_link_text + 1, &aarch64_jump_instruction, sizeof(aarch64_jump_instruction));
    ObjectSection misaligned_link_section = {
        .name = S8(".text"),
        .data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(misaligned_link_text),
        .kind = OBJECT_SECTION_TEXT,
        .alignment = 16,
    };
    ObjectSymbol misaligned_link_symbols[] = {
        {
            .name = S8("misaligned_entry"),
            .size = 5,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("misaligned_target"),
            .value = 5,
            .size = 4,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
        },
    };
    ObjectRelocation misaligned_link_relocation = {
        .offset = 1,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_AARCH64_JUMP26,
    };
    ObjectFile misaligned_link_object = {
        .sections = &misaligned_link_section,
        .symbols = misaligned_link_symbols,
        .relocations = &misaligned_link_relocation,
        .target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
        .section_count = 1,
        .symbol_count = BUSTER_ARRAY_LENGTH(misaligned_link_symbols),
        .relocation_count = 1,
    };
    ObjectExecutable misaligned_link_executable = object_link_executable(&misaligned_link_object);
    BUSTER_TEST(arguments, misaligned_link_executable.error == OBJECT_ERROR_CAPACITY);
    object_release_executable(misaligned_link_executable);

    // The in-memory AArch64 linker shares the checked Mach PAGE patch rules
    // with the JIT.  Local data is enough to exercise both fixups without
    // requiring an AArch64 host, while TLVP remains an explicit resolver-only
    // exclusion and must fail before exposing an executable mapping.
    u32 linked_page_words[] = {UINT32_C(0x90000009), UINT32_C(0x91000129)};
    u64 linked_page_data = UINT64_C(0x1122334455667788);
    ObjectSection linked_page_sections[] = {
        {
            .name = S8(".text"),
            .data = {.pointer = (u8*)linked_page_words, .length = sizeof(linked_page_words)},
            .kind = OBJECT_SECTION_TEXT,
            .alignment = 4,
        },
        {
            .name = S8(".data"),
            .data = {.pointer = (u8*)&linked_page_data, .length = sizeof(linked_page_data)},
            .kind = OBJECT_SECTION_READ_ONLY_DATA,
            .alignment = 8,
        },
    };
    ObjectSymbol linked_page_symbols[] = {
        {
            .name = S8("linked_page_entry"),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
            .size = sizeof(linked_page_words),
        },
        {
            .name = S8("linked_page_data"),
            .section = 1,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
            .size = sizeof(linked_page_data),
        },
    };
    ObjectRelocation linked_page_relocations[] = {
        {
            .offset = 0,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGE21,
        },
        {
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12,
        },
    };
    ObjectFile linked_page_object = {
        .sections = linked_page_sections,
        .symbols = linked_page_symbols,
        .relocations = linked_page_relocations,
        .target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},
        .section_count = BUSTER_ARRAY_LENGTH(linked_page_sections),
        .symbol_count = BUSTER_ARRAY_LENGTH(linked_page_symbols),
        .relocation_count = BUSTER_ARRAY_LENGTH(linked_page_relocations),
    };
    ObjectRelocationKind linked_page_kinds[][2] = {
        {OBJECT_RELOCATION_AARCH64_MACH_PAGE21, OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12},
        {OBJECT_RELOCATION_AARCH64_ELF_PAGE21, OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12},
    };
    for (u32 format_index = 0; format_index < BUSTER_ARRAY_LENGTH(linked_page_kinds); format_index += 1)
    {
        linked_page_relocations[0].kind = linked_page_kinds[format_index][0];
        linked_page_relocations[1].kind = linked_page_kinds[format_index][1];
        ObjectExecutable linked_page_executable = object_link_executable(&linked_page_object);
        BUSTER_TEST(arguments, linked_page_executable.error == OBJECT_ERROR_NONE && linked_page_executable.address);
        if (linked_page_executable.error == OBJECT_ERROR_NONE && linked_page_executable.address)
        {
            u8* linked_page_text = (u8*)linked_page_executable.address;
            u8* linked_page_data_address = linked_page_text + 8;
            u32 expected_linked_page21 = 0;
            u32 actual_linked_page21 = 0;
            u32 actual_linked_pageoff12 = 0;
            memcpy(&actual_linked_page21, linked_page_text, sizeof(actual_linked_page21));
            memcpy(&actual_linked_pageoff12, linked_page_text + sizeof(u32), sizeof(actual_linked_pageoff12));
            bool linked_page21_valid = a64_adrp_encode(9, (u64)(uintptr_t)linked_page_text, (u64)(uintptr_t)linked_page_data_address, &expected_linked_page21);
            BUSTER_TEST(arguments, linked_page21_valid && actual_linked_page21 == expected_linked_page21);
            BUSTER_TEST(arguments, actual_linked_pageoff12 == (UINT32_C(0x91000000) | (u32)((u64)(uintptr_t)linked_page_data_address & 0xfff) << 10 | (9u << 5) | 9u));
            object_release_executable(linked_page_executable);
        }
    }
    ObjectRelocation linked_page_tlvp_relocation = linked_page_relocations[0];
    linked_page_tlvp_relocation.kind = OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGE21;
    ObjectFile linked_page_tlvp_object = linked_page_object;
    linked_page_tlvp_object.relocations = &linked_page_tlvp_relocation;
    linked_page_tlvp_object.relocation_count = 1;
    ObjectExecutable linked_page_tlvp_executable = object_link_executable(&linked_page_tlvp_object);
    BUSTER_TEST(arguments, linked_page_tlvp_executable.error == OBJECT_ERROR_UNSUPPORTED_TARGET && !linked_page_tlvp_executable.address);
    object_release_executable(linked_page_tlvp_executable);

    String8 aarch64_jump_assembly = object_print_assembly(arguments->arena, &object);
    BUSTER_TEST(arguments, object_bytes_contain(BUSTER_SLICE_TO_BYTE_SLICE(aarch64_jump_assembly), S8("\tb object_callee\n")));
    aarch64_jump_instruction = UINT32_C(0x94000000);
    memcpy(aarch64_text + 4, &aarch64_jump_instruction, sizeof(aarch64_jump_instruction));
    relocation.kind = OBJECT_RELOCATION_AARCH64_CALL26;
    sections[0].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(x86_text);
    object.target.cpu_arch = CPU_ARCH_X86_64;
    relocation = (ObjectRelocation){
        .addend = -4,
        .offset = 1,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_PC32,
    };
    symbols[0].size = 6;
    symbols[1].value = 6;
    symbols[1].size = 6;
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_SANITIZE
    ObjectExecutable executable = object_link_executable(&object);
    BUSTER_TEST(arguments, executable.error == OBJECT_ERROR_NONE);
    if (executable.address)
    {
        u64 (*entry)(void) = 0;
        memcpy(&entry, &executable.address, sizeof(entry));
        BUSTER_TEST(arguments, entry() == 42);
        object_release_executable(executable);
    }
#endif
#if BUSTER_CPU_ARCH_AARCH64 && !BUSTER_SANITIZE
    sections[0].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(aarch64_text);
    object.target.cpu_arch = CPU_ARCH_AARCH64;
    relocation = (ObjectRelocation){
        .offset = 4,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_AARCH64_CALL26,
    };
    symbols[0].size = 16;
    symbols[1].value = 16;
    symbols[1].size = 8;
    ObjectExecutable executable = object_link_executable(&object);
    BUSTER_TEST(arguments, executable.error == OBJECT_ERROR_NONE);
    if (executable.address)
    {
        u64 (*entry)(void) = 0;
        memcpy(&entry, &executable.address, sizeof(entry));
        BUSTER_TEST(arguments, entry() == 42);
        object_release_executable(executable);
    }
#else
    BUSTER_UNUSED(aarch64_text);
#endif
    IrProgram separate_program = ir_program_initialize(arguments->arena, 0, 0, 256, 0);
    IrSymbolId defined_symbol = ir_program_add_symbol(&separate_program, (IrSymbol){
        .name = S8("defined_function"),
        .kind = IR_SYMBOL_FUNCTION,
        .linkage = IR_LINKAGE_EXTERNAL,
        .is_definition = true,
    });
    IrSymbolId undefined_symbol = ir_program_add_symbol(&separate_program, (IrSymbol){
        .name = S8("external_function"),
        .kind = IR_SYMBOL_FUNCTION,
        .linkage = IR_LINKAGE_EXTERNAL,
    });
    u8 separate_code[] = {
        0xe8, 0, 0, 0, 0, 0xc3,
    };
    CodegenModuleEntry separate_entry = {
        .symbol = defined_symbol,
    };
    CodegenFunctionDescriptor separate_function = {
        .symbol = defined_symbol,
        .code_size = (u32)sizeof(separate_code),
    };
    CodegenModuleRelocation separate_relocation = {
        .symbol = undefined_symbol,
        .offset = 1,
    };
    CodegenModule separate_module = {
        .code = (ByteSlice)BUSTER_ARRAY_TO_SLICE(separate_code),
        .entries = &separate_entry,
        .functions = &separate_function,
        .relocations = &separate_relocation,
        .abi = CODEGEN_ABI_X86_64_SYSTEM_V,
        .entry_count = 1,
        .function_count = 1,
        .relocation_count = 1,
    };
    ObjectFile separate_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &separate_module,
                                                            (Target){
                                                                .cpu_arch = CPU_ARCH_X86_64,
                                                                .os = OPERATING_SYSTEM_LINUX,
                                                            });
    bool separate_object_valid = BUSTER_REQUIRE(arguments, separate_object.error == OBJECT_ERROR_NONE && separate_object.sections != 0 &&
                                                               separate_object.section_count > OBJECT_SECTION_UNWIND && separate_object.symbols != 0 &&
                                                               separate_object.relocations != 0);
    if (separate_object_valid)
    {
        BUSTER_TEST(arguments, separate_object.symbol_count == 2);
        BUSTER_TEST(arguments, separate_object.sections[OBJECT_SECTION_UNWIND].data.length > 0);
        BUSTER_TEST(arguments, separate_object.symbol_count >= 2 && separate_object.symbols[1].section == OBJECT_SECTION_UNDEFINED);
        BUSTER_TEST(arguments, separate_object.relocation_count == 2);
        bool separate_cfi_relocation = false;
        for (u32 relocation_index = 0; relocation_index < separate_object.relocation_count; relocation_index += 1)
        {
            ObjectRelocation* candidate = separate_object.relocations + relocation_index;
            separate_cfi_relocation |=
                candidate->section == OBJECT_SECTION_UNWIND && candidate->symbol == 0 && candidate->kind == OBJECT_RELOCATION_X86_64_PC32;
        }
        BUSTER_TEST(arguments, separate_cfi_relocation);
    }

    enum
    {
        OBJECT_LOOKUP_STRESS_ENTRY_COUNT = 128,
        OBJECT_LOOKUP_STRESS_RELOCATION_COUNT = 512,
    };
    u8* lookup_stress_code = arena_allocate(arguments->arena, u8, OBJECT_LOOKUP_STRESS_RELOCATION_COUNT * 4);
    CodegenModuleEntry* lookup_stress_entries = arena_allocate(arguments->arena, CodegenModuleEntry, OBJECT_LOOKUP_STRESS_ENTRY_COUNT);
    CodegenFunctionDescriptor* lookup_stress_functions = arena_allocate(arguments->arena, CodegenFunctionDescriptor, OBJECT_LOOKUP_STRESS_ENTRY_COUNT);
    CodegenModuleRelocation* lookup_stress_relocations =
        arena_allocate(arguments->arena, CodegenModuleRelocation, OBJECT_LOOKUP_STRESS_RELOCATION_COUNT);
    memset(lookup_stress_code, 0xcc, OBJECT_LOOKUP_STRESS_RELOCATION_COUNT * 4);
    memset(lookup_stress_entries, 0, sizeof(*lookup_stress_entries) * OBJECT_LOOKUP_STRESS_ENTRY_COUNT);
    memset(lookup_stress_functions, 0, sizeof(*lookup_stress_functions) * OBJECT_LOOKUP_STRESS_ENTRY_COUNT);
    memset(lookup_stress_relocations, 0, sizeof(*lookup_stress_relocations) * OBJECT_LOOKUP_STRESS_RELOCATION_COUNT);
    for (u32 index = 0; index < OBJECT_LOOKUP_STRESS_ENTRY_COUNT; index += 1)
    {
        IrSymbolId symbol = ir_program_add_symbol(&separate_program, (IrSymbol){
            .name = string_format(arguments->arena, S8("lookup_{u32}"), index),
            .kind = IR_SYMBOL_FUNCTION,
            .linkage = IR_LINKAGE_EXTERNAL,
            .is_definition = true,
        });
        lookup_stress_entries[index] = (CodegenModuleEntry){
            .symbol = symbol,
            .offset = index * 4,
        };
        lookup_stress_functions[index] = (CodegenFunctionDescriptor){
            .symbol = symbol,
            .code_offset = index * 4,
            .code_size = 4,
        };
    }
    // Duplicate canonical symbol lookup is deliberately first-entry-wins.
    lookup_stress_entries[OBJECT_LOOKUP_STRESS_ENTRY_COUNT - 1].symbol = lookup_stress_entries[0].symbol;
    lookup_stress_functions[OBJECT_LOOKUP_STRESS_ENTRY_COUNT - 1].symbol = lookup_stress_entries[0].symbol;
    IrSymbolId missing_lookup_symbol = ir_program_add_symbol(&separate_program, (IrSymbol){
        .name = S8("lookup_missing"),
        .kind = IR_SYMBOL_FUNCTION,
        .linkage = IR_LINKAGE_EXTERNAL,
    });
    for (u32 index = 0; index < OBJECT_LOOKUP_STRESS_RELOCATION_COUNT; index += 1)
    {
        u32 target_index = (index * 37) % OBJECT_LOOKUP_STRESS_ENTRY_COUNT;
        bool missing = index % 29 == 0;
        lookup_stress_relocations[index] = (CodegenModuleRelocation){
            .symbol = missing ? missing_lookup_symbol : lookup_stress_entries[target_index].symbol,
            .offset = index * 4,
        };
    }
    CodegenModule lookup_stress_module = {
        .code = {.pointer = lookup_stress_code, .length = OBJECT_LOOKUP_STRESS_RELOCATION_COUNT * 4},
        .entries = lookup_stress_entries,
        .functions = lookup_stress_functions,
        .relocations = lookup_stress_relocations,
        .abi = CODEGEN_ABI_X86_64_SYSTEM_V,
        .entry_count = OBJECT_LOOKUP_STRESS_ENTRY_COUNT,
        .function_count = OBJECT_LOOKUP_STRESS_ENTRY_COUNT,
        .relocation_count = OBJECT_LOOKUP_STRESS_RELOCATION_COUNT,
    };
    ObjectFile lookup_stress_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &lookup_stress_module,
                                                                  (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX});
    BUSTER_TEST(arguments, lookup_stress_object.error == OBJECT_ERROR_NONE);
    BUSTER_TEST(arguments, lookup_stress_object.symbol_count == OBJECT_LOOKUP_STRESS_ENTRY_COUNT + 1);
    BUSTER_TEST(arguments, lookup_stress_object.relocation_count >= OBJECT_LOOKUP_STRESS_RELOCATION_COUNT);
    if (lookup_stress_object.error == OBJECT_ERROR_NONE && lookup_stress_object.relocation_count >= OBJECT_LOOKUP_STRESS_RELOCATION_COUNT)
    {
        bool lookup_stress_mapping_valid = true;
        for (u32 index = 0; index < OBJECT_LOOKUP_STRESS_RELOCATION_COUNT; index += 1)
        {
            u32 target_index = (index * 37) % OBJECT_LOOKUP_STRESS_ENTRY_COUNT;
            u32 expected_symbol = index % 29 == 0                             ? OBJECT_LOOKUP_STRESS_ENTRY_COUNT
                                  : target_index == OBJECT_LOOKUP_STRESS_ENTRY_COUNT - 1 ? 0
                                                                                       : target_index;
            lookup_stress_mapping_valid &= lookup_stress_object.relocations[index].symbol == expected_symbol;
        }
        BUSTER_TEST(arguments, lookup_stress_mapping_valid);
    }

    if (separate_object_valid)
    {
        ObjectArtifact separate_elf = object_write(arguments->arena, &separate_object, OBJECT_FORMAT_ELF64);
        if (BUSTER_REQUIRE(arguments, separate_elf.error == OBJECT_ERROR_NONE))
        {
            BUSTER_TEST(arguments, object_bytes_contain(separate_elf.bytes, S8(".eh_frame")));
            BUSTER_TEST(arguments, object_bytes_contain(separate_elf.bytes, S8(".rela.eh_frame")));
            ObjectFile separate_roundtrip = object_read(arguments->arena, separate_elf.bytes, separate_object.target);
            if (BUSTER_REQUIRE(arguments, separate_roundtrip.error == OBJECT_ERROR_NONE && separate_roundtrip.sections != 0 &&
                                              separate_roundtrip.section_count > OBJECT_SECTION_UNWIND && separate_roundtrip.relocations != 0))
            {
                BUSTER_TEST(arguments,
                            separate_roundtrip.sections[OBJECT_SECTION_UNWIND].data.length == separate_object.sections[OBJECT_SECTION_UNWIND].data.length);
                bool separate_roundtrip_cfi = false;
                for (u32 relocation_index = 0; relocation_index < separate_roundtrip.relocation_count; relocation_index += 1)
                {
                    ObjectRelocation* candidate = separate_roundtrip.relocations + relocation_index;
                    separate_roundtrip_cfi |= candidate->section == OBJECT_SECTION_UNWIND && candidate->kind == OBJECT_RELOCATION_X86_64_PC32;
                }
                BUSTER_TEST(arguments, separate_roundtrip_cfi);
            }
        }
    }

    u8 windows_unwind_code[32] = {0};
    CodegenUnwindAction windows_unwind_actions[] = {
        {
            .code_offset = 1,
            .kind = CODEGEN_UNWIND_ACTION_PUSH_REGISTER,
            .register_index = 5,
        },
        {
            .code_offset = 4,
            .kind = CODEGEN_UNWIND_ACTION_SET_FRAME_POINTER,
            .register_index = 5,
        },
        {
            .code_offset = 11,
            .value = 144,
            .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK,
        },
    };
    CodegenFunctionDescriptor windows_unwind_function = {
        .unwind_actions = windows_unwind_actions,
        .code_size = sizeof(windows_unwind_code),
        .prolog_size = 11,
        .unwind_action_count = BUSTER_ARRAY_LENGTH(windows_unwind_actions),
    };
    CodegenModule windows_unwind_module = {
        .code = BUSTER_ARRAY_TO_SLICE(windows_unwind_code),
        .entries = &separate_entry,
        .functions = &windows_unwind_function,
        .abi = CODEGEN_ABI_X86_64_WINDOWS,
        .entry_count = 1,
        .function_count = 1,
    };
    Target windows_unwind_target = {
        .cpu_arch = CPU_ARCH_X86_64,
        .os = OPERATING_SYSTEM_WINDOWS,
    };
    ObjectFile windows_unwind_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &windows_unwind_module, windows_unwind_target);
    u8 expected_windows_xdata[] = {
        1, 11, 3, 0, 11, 1, 18, 0, 1, 0x50, 0, 0,
    };
    bool windows_unwind_object_valid =
        BUSTER_REQUIRE(arguments, windows_unwind_object.error == OBJECT_ERROR_NONE && windows_unwind_object.sections != 0 &&
                                      windows_unwind_object.section_count > OBJECT_SECTION_WINDOWS_XDATA && windows_unwind_object.relocations != 0);
    if (windows_unwind_object_valid)
    {
        BUSTER_TEST(arguments, windows_unwind_object.sections[OBJECT_SECTION_UNWIND].data.length == 0);
        BUSTER_TEST(arguments, windows_unwind_object.sections[OBJECT_SECTION_WINDOWS_PDATA].data.length == 12);
        BUSTER_TEST(arguments, windows_unwind_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data.length == 12);
        ByteSlice windows_unwind_xdata = windows_unwind_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data;
        if (BUSTER_REQUIRE(arguments, windows_unwind_xdata.pointer != 0 && windows_unwind_xdata.length == sizeof(expected_windows_xdata)))
        {
            BUSTER_TEST(arguments, memcmp(windows_unwind_xdata.pointer, expected_windows_xdata, sizeof(expected_windows_xdata)) == 0);
        }
        if (BUSTER_REQUIRE(arguments, windows_unwind_object.relocation_count == 3))
        {
            for (u32 relocation_index = 0; relocation_index < windows_unwind_object.relocation_count; relocation_index += 1)
            {
                BUSTER_TEST(arguments, windows_unwind_object.relocations[relocation_index].section == OBJECT_SECTION_WINDOWS_PDATA);
                BUSTER_TEST(arguments, windows_unwind_object.relocations[relocation_index].kind == OBJECT_RELOCATION_COFF_ADDR32NB);
            }
        }
        ObjectArtifact windows_unwind_coff = object_write(arguments->arena, &windows_unwind_object, OBJECT_FORMAT_COFF);
        if (BUSTER_REQUIRE(arguments, windows_unwind_coff.error == OBJECT_ERROR_NONE))
        {
            BUSTER_TEST(arguments, object_bytes_contain(windows_unwind_coff.bytes, S8(".pdata")));
            BUSTER_TEST(arguments, object_bytes_contain(windows_unwind_coff.bytes, S8(".xdata")));
            ObjectFile windows_unwind_roundtrip = object_read(arguments->arena, windows_unwind_coff.bytes, windows_unwind_target);
            if (BUSTER_REQUIRE(arguments, windows_unwind_roundtrip.error == OBJECT_ERROR_NONE && windows_unwind_roundtrip.sections != 0 &&
                                              windows_unwind_roundtrip.section_count > OBJECT_SECTION_WINDOWS_XDATA &&
                                              windows_unwind_roundtrip.relocations != 0))
            {
                BUSTER_TEST(arguments, windows_unwind_roundtrip.sections[OBJECT_SECTION_WINDOWS_PDATA].data.length == 12);
                BUSTER_TEST(arguments, windows_unwind_roundtrip.sections[OBJECT_SECTION_WINDOWS_XDATA].data.length == sizeof(expected_windows_xdata));
                if (BUSTER_REQUIRE(arguments, windows_unwind_roundtrip.relocation_count == 3))
                {
                    for (u32 relocation_index = 0; relocation_index < windows_unwind_roundtrip.relocation_count; relocation_index += 1)
                    {
                        BUSTER_TEST(arguments, windows_unwind_roundtrip.relocations[relocation_index].section == OBJECT_SECTION_WINDOWS_PDATA);
                        BUSTER_TEST(arguments, windows_unwind_roundtrip.relocations[relocation_index].kind == OBJECT_RELOCATION_COFF_ADDR32NB);
                    }
                }
            }
        }
    }
    // #363: an early RBP establishment cannot be shifted to describe a
    // later allocation. Pin both prologue orders, SAVE offsets, and the
    // small/large allocation encodings through the public object path.
    u32 fixed_sizes[] = {32, 48, 144, 256, 8192};
    for (u32 size_index = 0; size_index < BUSTER_ARRAY_LENGTH(fixed_sizes); size_index += 1)
    {
        u32 fixed_size = fixed_sizes[size_index];
        CodegenUnwindAction frame_order_actions[] = {
            {.code_offset = 1, .kind = CODEGEN_UNWIND_ACTION_PUSH_REGISTER, .register_index = 5},
            {.code_offset = 2, .kind = CODEGEN_UNWIND_ACTION_PUSH_REGISTER, .register_index = 12},
            {.code_offset = 5, .kind = CODEGEN_UNWIND_ACTION_SET_FRAME_POINTER, .register_index = 5},
            {.code_offset = 12, .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK, .value = fixed_size},
            {.code_offset = 16, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 3, .value = fixed_size - 8},
        };
        CodegenFunctionDescriptor frame_order_descriptor = windows_unwind_function;
        frame_order_descriptor.unwind_actions = frame_order_actions;
        frame_order_descriptor.unwind_action_count = BUSTER_ARRAY_LENGTH(frame_order_actions);
        frame_order_descriptor.prolog_size = 16;
        CodegenModule frame_order_module = windows_unwind_module;
        frame_order_module.functions = &frame_order_descriptor;
        ObjectFile frame_order_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &frame_order_module, windows_unwind_target);
        u8 frame_order_expected[16] = {1, 16, (u8)(fixed_size <= 128 ? 5 : 6), 0, 16, 0x34};
        u16 frame_order_save_offset = (u16)((fixed_size - 8) / 8);
        memcpy(frame_order_expected + 6, &frame_order_save_offset, sizeof(frame_order_save_offset));
        frame_order_expected[8] = 12;
        u32 frame_order_cursor;
        if (fixed_size <= 128)
        {
            frame_order_expected[9] = (u8)(((fixed_size / 8 - 1) << 4) | 2);
            frame_order_cursor = 10;
        }
        else
        {
            frame_order_expected[9] = 1;
            u16 frame_order_allocation = (u16)(fixed_size / 8);
            memcpy(frame_order_expected + 10, &frame_order_allocation, sizeof(frame_order_allocation));
            frame_order_cursor = 12;
        }
        frame_order_expected[frame_order_cursor] = 2;
        frame_order_expected[frame_order_cursor + 1] = 0xc0;
        frame_order_expected[frame_order_cursor + 2] = 1;
        frame_order_expected[frame_order_cursor + 3] = 0x50;
        ByteSlice frame_order_actual = frame_order_object.error == OBJECT_ERROR_NONE ? frame_order_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data : (ByteSlice){0};
        BUSTER_TEST(arguments, frame_order_object.error == OBJECT_ERROR_NONE);
        BUSTER_TEST(arguments, frame_order_actual.length == sizeof(frame_order_expected) && memcmp(frame_order_actual.pointer, frame_order_expected, sizeof(frame_order_expected)) == 0);
    }
    // Allocating first is the dynamic-stack producer's contract. The offset
    // belongs to SET_FRAME_POINTER itself (zero and nonzero legal values).
    for (u32 frame_offset = 0; frame_offset <= 32; frame_offset += 16)
    {
        CodegenUnwindAction frame_order_actions[] = {
            {.code_offset = 1, .kind = CODEGEN_UNWIND_ACTION_PUSH_REGISTER, .register_index = 5},
            {.code_offset = 8, .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK, .value = 144},
            {.code_offset = 12, .kind = CODEGEN_UNWIND_ACTION_SET_FRAME_POINTER, .register_index = 5, .value = frame_offset},
        };
        CodegenFunctionDescriptor frame_order_descriptor = windows_unwind_function;
        frame_order_descriptor.unwind_actions = frame_order_actions;
        frame_order_descriptor.prolog_size = 12;
        CodegenModule frame_order_module = windows_unwind_module;
        frame_order_module.functions = &frame_order_descriptor;
        ObjectFile frame_order_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &frame_order_module, windows_unwind_target);
        u8 frame_order_expected[] = {1, 12, 4, (u8)(5 | ((frame_offset / 16) << 4)), 12, 3, 8, 1, 18, 0, 1, 0x50};
        ByteSlice frame_order_actual = frame_order_object.error == OBJECT_ERROR_NONE ? frame_order_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data : (ByteSlice){0};
        BUSTER_TEST(arguments, frame_order_object.error == OBJECT_ERROR_NONE);
        BUSTER_TEST(arguments, frame_order_actual.length == sizeof(frame_order_expected) && memcmp(frame_order_actual.pointer, frame_order_expected, sizeof(frame_order_expected)) == 0);
    }
    u8 windows_save_code[16] = {0};
    CodegenUnwindAction windows_save_actions[] = {
        {
            .code_offset = 8,
            .value = 512,
            .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER,
            .register_index = 3,
        },
    };
    CodegenFunctionDescriptor windows_save_function = {
        .unwind_actions = windows_save_actions,
        .code_size = sizeof(windows_save_code),
        .prolog_size = 8,
        .unwind_action_count = BUSTER_ARRAY_LENGTH(windows_save_actions),
    };
    CodegenModule windows_save_module = windows_unwind_module;
    windows_save_module.code = (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_save_code);
    windows_save_module.functions = &windows_save_function;
    ObjectFile windows_save_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &windows_save_module, windows_unwind_target);
    u8 expected_windows_save_xdata[] = {
        1, 8, 2, 0, 8, 0x34, 64, 0,
    };
    if (BUSTER_REQUIRE(arguments, windows_save_object.error == OBJECT_ERROR_NONE && windows_save_object.sections != 0 &&
                                      windows_save_object.section_count > OBJECT_SECTION_WINDOWS_XDATA))
    {
        ByteSlice windows_save_xdata = windows_save_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data;
        if (BUSTER_REQUIRE(arguments, windows_save_xdata.pointer != 0 && windows_save_xdata.length == sizeof(expected_windows_save_xdata)))
        {
            BUSTER_TEST(arguments, memcmp(windows_save_xdata.pointer, expected_windows_save_xdata, sizeof(expected_windows_save_xdata)) == 0);
        }
    }
    u8 windows_far_save_code[16] = {0};
    windows_save_actions[0].value = 524288;
    CodegenModule windows_far_save_module = windows_save_module;
    windows_far_save_module.code = (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_far_save_code);
    ObjectFile windows_far_save_object =
        object_from_canonical_codegen_module(arguments->arena, &separate_program, &windows_far_save_module, windows_unwind_target);
    u8 expected_windows_far_save_xdata[] = {
        1, 8, 3, 0, 8, 0x35, 0, 0, 8, 0, 0, 0,
    };
    if (BUSTER_REQUIRE(arguments, windows_far_save_object.error == OBJECT_ERROR_NONE && windows_far_save_object.sections != 0 &&
                                      windows_far_save_object.section_count > OBJECT_SECTION_WINDOWS_XDATA))
    {
        ByteSlice windows_far_save_xdata = windows_far_save_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data;
        if (BUSTER_REQUIRE(arguments, windows_far_save_xdata.pointer != 0 && windows_far_save_xdata.length == sizeof(expected_windows_far_save_xdata)))
        {
            BUSTER_TEST(arguments, memcmp(windows_far_save_xdata.pointer, expected_windows_far_save_xdata, sizeof(expected_windows_far_save_xdata)) == 0);
        }
        ObjectArtifact windows_far_save_coff = object_write(arguments->arena, &windows_far_save_object, OBJECT_FORMAT_COFF);
        if (BUSTER_REQUIRE(arguments, windows_far_save_coff.error == OBJECT_ERROR_NONE))
        {
            ObjectFile windows_far_save_roundtrip = object_read(arguments->arena, windows_far_save_coff.bytes, windows_unwind_target);
            if (BUSTER_REQUIRE(arguments, windows_far_save_roundtrip.error == OBJECT_ERROR_NONE && windows_far_save_roundtrip.sections != 0 &&
                                              windows_far_save_roundtrip.section_count > OBJECT_SECTION_WINDOWS_XDATA))
            {
                ByteSlice roundtrip_xdata = windows_far_save_roundtrip.sections[OBJECT_SECTION_WINDOWS_XDATA].data;
                if (BUSTER_REQUIRE(arguments, roundtrip_xdata.pointer != 0 && roundtrip_xdata.length == sizeof(expected_windows_far_save_xdata)))
                {
                    BUSTER_TEST(arguments, memcmp(roundtrip_xdata.pointer, expected_windows_far_save_xdata, sizeof(expected_windows_far_save_xdata)) == 0);
                }
            }
        }
    }
#if BUSTER_CPU_ARCH_X86_64 && !BUSTER_SANITIZE
    if (windows_unwind_object_valid)
    {
        ObjectExecutable windows_unwind_executable = object_link_executable(&windows_unwind_object);
        BUSTER_TEST(arguments, windows_unwind_executable.error == OBJECT_ERROR_NONE);
        if (windows_unwind_executable.address)
        {
            object_release_executable(windows_unwind_executable);
        }
    }
#endif

    u8 windows_arm64_code[64] = {0};
    u32 windows_arm64_epilog = 48;
    CodegenUnwindAction windows_arm64_actions[] = {
        {.code_offset = 4, .value = 16, .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK},
        {.code_offset = 4, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 29},
        {.code_offset = 4, .value = 8, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 30},
        {.code_offset = 8, .kind = CODEGEN_UNWIND_ACTION_SET_FRAME_POINTER, .register_index = 29},
        {.code_offset = 12, .value = 48, .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK},
        {.code_offset = 16, .kind = CODEGEN_UNWIND_ACTION_NOP},
        {.code_offset = 20, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 28},
        {.code_offset = 24, .kind = CODEGEN_UNWIND_ACTION_NOP},
    };
    CodegenFunctionDescriptor windows_arm64_function = {
        .unwind_actions = windows_arm64_actions,
        .epilog_offsets = &windows_arm64_epilog,
        .code_size = sizeof(windows_arm64_code),
        .prolog_size = 24,
        .unwind_action_count = BUSTER_ARRAY_LENGTH(windows_arm64_actions),
        .epilog_count = 1,
    };
    CodegenModule windows_arm64_module = {
        .code = BUSTER_ARRAY_TO_SLICE(windows_arm64_code),
        .entries = &separate_entry,
        .functions = &windows_arm64_function,
        .abi = CODEGEN_ABI_AARCH64_WINDOWS,
        .entry_count = 1,
        .function_count = 1,
    };
    Target windows_arm64_target = {
        .cpu_arch = CPU_ARCH_AARCH64,
        .os = OPERATING_SYSTEM_WINDOWS,
    };
    ObjectFile windows_arm64_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &windows_arm64_module, windows_arm64_target);
    u8 expected_windows_arm64_xdata[] = {
        0x10, 0x00, 0x40, 0x20, 0x0c, 0x00, 0x00, 0x02, 0xe3, 0xd2, 0x40, 0xe3, 0x03, 0xe1, 0x81, 0xe4, 0xe3, 0xd2, 0x40, 0x03,
        0x81, 0xe4, 0x00, 0x00,
    };
    if (BUSTER_REQUIRE(arguments, windows_arm64_object.error == OBJECT_ERROR_NONE && windows_arm64_object.sections != 0 &&
                                      windows_arm64_object.section_count > OBJECT_SECTION_WINDOWS_XDATA))
    {
        BUSTER_TEST(arguments, windows_arm64_object.sections[OBJECT_SECTION_WINDOWS_PDATA].data.length == 8);
        ByteSlice windows_arm64_xdata = windows_arm64_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data;
        if (BUSTER_REQUIRE(arguments, windows_arm64_xdata.pointer != 0 && windows_arm64_xdata.length == sizeof(expected_windows_arm64_xdata)))
        {
            BUSTER_TEST(arguments, memcmp(windows_arm64_xdata.pointer, expected_windows_arm64_xdata, sizeof(expected_windows_arm64_xdata)) == 0);
        }
        BUSTER_TEST(arguments, windows_arm64_object.relocation_count == 2);
        ObjectArtifact windows_arm64_coff = object_write(arguments->arena, &windows_arm64_object, OBJECT_FORMAT_COFF);
        if (BUSTER_REQUIRE(arguments, windows_arm64_coff.error == OBJECT_ERROR_NONE))
        {
            ObjectFile windows_arm64_roundtrip = object_read(arguments->arena, windows_arm64_coff.bytes, windows_arm64_target);
            if (BUSTER_REQUIRE(arguments, windows_arm64_roundtrip.error == OBJECT_ERROR_NONE && windows_arm64_roundtrip.sections != 0 &&
                                              windows_arm64_roundtrip.section_count > OBJECT_SECTION_WINDOWS_XDATA && windows_arm64_roundtrip.relocations != 0))
            {
                BUSTER_TEST(arguments, windows_arm64_roundtrip.sections[OBJECT_SECTION_WINDOWS_PDATA].data.length == 8);
                BUSTER_TEST(arguments, windows_arm64_roundtrip.sections[OBJECT_SECTION_WINDOWS_XDATA].data.length == sizeof(expected_windows_arm64_xdata));
                if (BUSTER_REQUIRE(arguments, windows_arm64_roundtrip.relocation_count == 2))
                {
                    for (u32 relocation_index = 0; relocation_index < windows_arm64_roundtrip.relocation_count; relocation_index += 1)
                    {
                        BUSTER_TEST(arguments, windows_arm64_roundtrip.relocations[relocation_index].section == OBJECT_SECTION_WINDOWS_PDATA);
                        BUSTER_TEST(arguments, windows_arm64_roundtrip.relocations[relocation_index].kind == OBJECT_RELOCATION_COFF_ADDR32NB);
                    }
                }
            }
        }
    }

    // A module-level assembly label is retained as a sized text symbol, but
    // it has no compiler prologue or unwind directives. The ARM64 COFF writer
    // must therefore omit only the trailing raw-assembly descriptor from
    // .pdata/.xdata while keeping the preceding C function's unwind record.
    IrSymbolId windows_arm64_assembly_symbol = ir_program_add_symbol(&separate_program, (IrSymbol){
        .name = S8("raw_assembly_function"),
        .kind = IR_SYMBOL_FUNCTION,
        .linkage = IR_LINKAGE_EXTERNAL,
        .is_definition = true,
    });
    u8 windows_arm64_assembly_code[sizeof(windows_arm64_code) + 8] = {0};
    memcpy(windows_arm64_assembly_code, windows_arm64_code, sizeof(windows_arm64_code));
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 0] = 0x40;
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 1] = 0x05;
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 2] = 0x80;
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 3] = 0x52;
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 4] = 0xc0;
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 5] = 0x03;
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 6] = 0x5f;
    windows_arm64_assembly_code[sizeof(windows_arm64_code) + 7] = 0xd6;
    CodegenModuleEntry windows_arm64_assembly_entries[] = {
        separate_entry,
        {.symbol = windows_arm64_assembly_symbol, .offset = sizeof(windows_arm64_code)},
    };
    CodegenFunctionDescriptor windows_arm64_assembly_functions[] = {
        windows_arm64_function,
        {.symbol = windows_arm64_assembly_symbol, .code_offset = sizeof(windows_arm64_code), .code_size = 8},
    };
    CodegenModule windows_arm64_assembly_module = windows_arm64_module;
    windows_arm64_assembly_module.code = (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_arm64_assembly_code);
    windows_arm64_assembly_module.entries = windows_arm64_assembly_entries;
    windows_arm64_assembly_module.functions = windows_arm64_assembly_functions;
    windows_arm64_assembly_module.entry_count = 2;
    windows_arm64_assembly_module.function_count = 2;
    windows_arm64_assembly_module.assembly_function_count = 1;
    ObjectFile windows_arm64_assembly_object =
        object_from_canonical_codegen_module(arguments->arena, &separate_program, &windows_arm64_assembly_module, windows_arm64_target);
    BUSTER_TEST(arguments, windows_arm64_assembly_object.error == OBJECT_ERROR_NONE);
    BUSTER_TEST(arguments, windows_arm64_assembly_object.sections[OBJECT_SECTION_WINDOWS_PDATA].data.length == 8);
    BUSTER_TEST(arguments, windows_arm64_assembly_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data.length == sizeof(expected_windows_arm64_xdata));
    BUSTER_TEST(arguments, windows_arm64_assembly_object.relocation_count == 2);
    bool windows_arm64_assembly_symbol_valid = false;
    for (u32 symbol_index = 0; symbol_index < windows_arm64_assembly_object.symbol_count; symbol_index += 1)
    {
        ObjectSymbol* symbol = windows_arm64_assembly_object.symbols + symbol_index;
        if (string_equal(symbol->name, S8("raw_assembly_function")))
        {
            windows_arm64_assembly_symbol_valid = symbol->section == OBJECT_SECTION_TEXT && symbol->value == sizeof(windows_arm64_code) &&
                                                  symbol->size == 8 && symbol->global;
        }
    }
    BUSTER_TEST(arguments, windows_arm64_assembly_symbol_valid);
    ObjectArtifact windows_arm64_assembly_coff = object_write(arguments->arena, &windows_arm64_assembly_object, OBJECT_FORMAT_COFF);
    BUSTER_TEST(arguments, windows_arm64_assembly_coff.error == OBJECT_ERROR_NONE);
    CodegenModule invalid_windows_arm64_assembly_module = windows_arm64_assembly_module;
    invalid_windows_arm64_assembly_module.assembly_function_count = 3;
    BUSTER_TEST(arguments, object_from_canonical_codegen_module(arguments->arena, &separate_program, &invalid_windows_arm64_assembly_module,
                                                                 windows_arm64_target)
                               .error == OBJECT_ERROR_INVALID_INPUT);

    // MIR saves precede X29 establishment. Its epilog shares the suffix
    // starting at SET_FP, including sparse allocator saves in reverse order.
    u8 windows_arm64_machine_code[80] = {0};
    u32 windows_arm64_machine_epilog = 56;
    CodegenUnwindAction windows_arm64_machine_actions[] = {
        {.code_offset = 4, .value = 48, .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK},
        {.code_offset = 4, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 29},
        {.code_offset = 4, .value = 8, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 30},
        {.code_offset = 8, .value = 16, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 19},
        {.code_offset = 12, .value = 24, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 27},
        {.code_offset = 16, .value = 32, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 28},
        {.code_offset = 20, .kind = CODEGEN_UNWIND_ACTION_SET_FRAME_POINTER, .register_index = 29},
        {.code_offset = 24, .value = 64, .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK},
        {.code_offset = 28, .kind = CODEGEN_UNWIND_ACTION_NOP},
        {.code_offset = 32, .kind = CODEGEN_UNWIND_ACTION_NOP},
    };
    CodegenFunctionDescriptor windows_arm64_machine_function = {
        .unwind_actions = windows_arm64_machine_actions,
        .epilog_offsets = &windows_arm64_machine_epilog,
        .code_size = sizeof(windows_arm64_machine_code),
        .prolog_size = 32,
        .unwind_action_count = BUSTER_ARRAY_LENGTH(windows_arm64_machine_actions),
        .epilog_count = 1,
    };
    CodegenModule windows_arm64_machine_module = windows_arm64_module;
    windows_arm64_machine_module.code = (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_arm64_machine_code);
    windows_arm64_machine_module.functions = &windows_arm64_machine_function;
    ObjectFile windows_arm64_machine_object =
        object_from_canonical_codegen_module(arguments->arena, &separate_program, &windows_arm64_machine_module, windows_arm64_target);
    bool windows_arm64_machine_object_valid = BUSTER_REQUIRE(arguments, windows_arm64_machine_object.error == OBJECT_ERROR_NONE);
    if (windows_arm64_machine_object_valid)
    {
        windows_arm64_machine_object_valid =
            BUSTER_REQUIRE(arguments, windows_arm64_machine_object.sections != 0 && windows_arm64_machine_object.section_count > OBJECT_SECTION_WINDOWS_XDATA);
    }
    u8 expected_windows_arm64_machine_xdata[] = {
        0x14, 0x00, 0x40, 0x18, 0x0e, 0x00, 0xc0, 0x00, 0xe3, 0xe3, 0x04, 0xe1, 0xd2, 0x44, 0xd2, 0x03, 0xd0, 0x02, 0x85, 0xe4,
    };
    if (windows_arm64_machine_object_valid)
    {
        ByteSlice windows_arm64_machine_xdata = windows_arm64_machine_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data;
        BUSTER_TEST(arguments,
                    windows_arm64_machine_xdata.length == sizeof(expected_windows_arm64_machine_xdata) &&
                        memcmp(windows_arm64_machine_xdata.pointer, expected_windows_arm64_machine_xdata, sizeof(expected_windows_arm64_machine_xdata)) == 0);
    }
    for (u32 malformed = 0; malformed < 5; malformed += 1)
    {
        CodegenUnwindAction invalid_actions[BUSTER_ARRAY_LENGTH(windows_arm64_machine_actions)];
        memcpy(invalid_actions, windows_arm64_machine_actions, sizeof(invalid_actions));
        CodegenFunctionDescriptor invalid_function = windows_arm64_machine_function;
        invalid_function.unwind_actions = invalid_actions;
        if (malformed == 0)
        {
            invalid_actions[5].value += 8;
        }
        if (malformed == 1)
        {
            invalid_actions[4].register_index = 19;
        }
        if (malformed == 2)
        {
            invalid_actions[7].code_offset += 4;
        }
        if (malformed == 3)
        {
            invalid_actions[6].kind = CODEGEN_UNWIND_ACTION_NOP;
        }
        if (malformed == 4)
        {
            invalid_function.prolog_size += 4;
        }
        CodegenModule invalid_module = windows_arm64_machine_module;
        invalid_module.functions = &invalid_function;
        ObjectFile invalid_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &invalid_module, windows_arm64_target);
        BUSTER_TEST(arguments, invalid_object.error != OBJECT_ERROR_NONE);
    }

    CodegenModule mach_cfi_module = separate_module;
    mach_cfi_module.relocations = 0;
    mach_cfi_module.relocation_count = 0;
    ObjectFile mach_cfi_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &mach_cfi_module,
                                                                      (Target){
                                                                          .cpu_arch = CPU_ARCH_X86_64,
                                                                          .os = OPERATING_SYSTEM_MACOS,
                                                                      });
    bool mach_cfi_object_valid = BUSTER_REQUIRE(arguments, mach_cfi_object.error == OBJECT_ERROR_NONE);
    if (mach_cfi_object_valid)
    {
        mach_cfi_object_valid =
            BUSTER_REQUIRE(arguments, mach_cfi_object.section_count > OBJECT_SECTION_UNWIND && mach_cfi_object.sections != 0 &&
                                          mach_cfi_object.relocation_count == 1 && mach_cfi_object.relocations != 0 &&
                                          mach_cfi_object.relocations[0].symbol < mach_cfi_object.symbol_count && mach_cfi_object.symbols != 0);
    }
    if (mach_cfi_object_valid)
    {
        BUSTER_TEST(arguments, mach_cfi_object.sections[OBJECT_SECTION_UNWIND].data.length > 0);
        ObjectArtifact mach_cfi_artifact = object_write(arguments->arena, &mach_cfi_object, OBJECT_FORMAT_MACH_O64);
        if (BUSTER_REQUIRE(arguments, mach_cfi_artifact.error == OBJECT_ERROR_NONE))
        {
            BUSTER_TEST(arguments, object_bytes_contain(mach_cfi_artifact.bytes, S8("__eh_frame")));
            ObjectFile mach_cfi_roundtrip = object_read(arguments->arena, mach_cfi_artifact.bytes, mach_cfi_object.target);
            if (BUSTER_REQUIRE(arguments, mach_cfi_roundtrip.error == OBJECT_ERROR_NONE && mach_cfi_roundtrip.sections != 0 &&
                                              mach_cfi_roundtrip.section_count > OBJECT_SECTION_UNWIND))
            {
                BUSTER_TEST(arguments,
                            mach_cfi_roundtrip.sections[OBJECT_SECTION_UNWIND].data.length == mach_cfi_object.sections[OBJECT_SECTION_UNWIND].data.length);
                if (BUSTER_REQUIRE(arguments, mach_cfi_roundtrip.relocation_count == 1 && mach_cfi_roundtrip.relocations != 0))
                {
                    BUSTER_TEST(arguments, mach_cfi_roundtrip.relocations[0].section == OBJECT_SECTION_UNWIND);
                    BUSTER_TEST(arguments, mach_cfi_roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_PC32);
                }
            }
        }

        // Apple ld accepts a SUBTRACTOR/UNSIGNED pair in x86 __eh_frame, not the
        // SIGNED relocation used for instruction operands. Keep the section at a
        // noncanonical index to test classification by kind rather than array slot.
        ObjectSection x86_cfi_sections[] = {
            mach_cfi_object.sections[OBJECT_SECTION_TEXT],
            mach_cfi_object.sections[OBJECT_SECTION_UNWIND],
        };
        x86_cfi_sections[1].data.pointer = arena_allocate(arguments->arena, u8, x86_cfi_sections[1].data.length);
        memcpy(x86_cfi_sections[1].data.pointer, mach_cfi_object.sections[OBJECT_SECTION_UNWIND].data.pointer, (size_t)x86_cfi_sections[1].data.length);
        ObjectRelocation x86_cfi_relocation = mach_cfi_object.relocations[0];
        ObjectSymbol x86_cfi_symbol = mach_cfi_object.symbols[x86_cfi_relocation.symbol];
        x86_cfi_symbol.section = 0;
        x86_cfi_relocation.section = 1;
        x86_cfi_relocation.symbol = 0;
        ObjectFile x86_cfi_sparse = mach_cfi_object;
        x86_cfi_sparse.sections = x86_cfi_sections;
        x86_cfi_sparse.section_count = BUSTER_ARRAY_LENGTH(x86_cfi_sections);
        x86_cfi_sparse.symbols = &x86_cfi_symbol;
        x86_cfi_sparse.symbol_count = 1;
        x86_cfi_sparse.relocations = &x86_cfi_relocation;
        x86_cfi_sparse.relocation_count = 1;
        u64 x86_cfi_record_start = 0;
        bool x86_cfi_record_valid = object_test_eh_frame_record_start(x86_cfi_sections[1].data, x86_cfi_relocation.offset, &x86_cfi_record_start);
        u64 x86_cfi_place_adjustment = x86_cfi_record_valid ? x86_cfi_relocation.offset - x86_cfi_record_start : 0;
        BUSTER_TEST(arguments, x86_cfi_record_valid && x86_cfi_place_adjustment <= INT32_MAX);
        s64 x86_cfi_addends[] = {(s64)INT32_MIN + (s64)x86_cfi_place_adjustment, -17, 0, 23, INT32_MAX};
        ObjectArtifact x86_cfi_pair = {0};
        u32 x86_cfi_relocations_offset = 0;
        for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(x86_cfi_addends); addend_index += 1)
        {
            x86_cfi_relocation.addend = x86_cfi_addends[addend_index];
            memset(x86_cfi_sections[1].data.pointer + x86_cfi_relocation.offset, 0xa5, 4);
            x86_cfi_pair = object_write(arguments->arena, &x86_cfi_sparse, OBJECT_FORMAT_MACH_O64);
            BUSTER_TEST(arguments, x86_cfi_pair.error == OBJECT_ERROR_NONE);
            u32 raw_offset = 0;
            u32 relocation_count = 0;
            bool located = object_test_mach_section_offsets(x86_cfi_pair.bytes, 1, &raw_offset, &x86_cfi_relocations_offset, &relocation_count);
            if (BUSTER_REQUIRE(arguments, located && relocation_count == 2))
            {
                u32 words[4] = {0};
                u32 stored = 0;
                memcpy(words, x86_cfi_pair.bytes.pointer + x86_cfi_relocations_offset, sizeof(words));
                memcpy(&stored, x86_cfi_pair.bytes.pointer + raw_offset + x86_cfi_relocation.offset, sizeof(stored));
                // The relocation records stay at the field, but the subtractor
                // symbol is a CFI-record boundary accepted by ld64.lld.
                BUSTER_TEST(arguments, words[0] == x86_cfi_relocation.offset && words[2] == words[0]);
                BUSTER_TEST(arguments, (words[1] >> 28) == 5 && (words[3] >> 28) == 0);
                BUSTER_TEST(arguments, ((words[1] >> 24) & 15) == 12 && ((words[3] >> 24) & 15) == 12);
                BUSTER_TEST(arguments, (s32)stored == x86_cfi_addends[addend_index] - (s64)x86_cfi_place_adjustment);
                u64 place_symbol_record = object_test_mach_symbol_offset(x86_cfi_pair.bytes, x86_cfi_sparse.symbol_count);
                u64 place_symbol_value = UINT64_MAX;
                u64 unwind_section_address = UINT64_MAX;
                u64 unwind_section_header = 32 + 72 + (u64)1 * 80;
                if (place_symbol_record != UINT64_MAX && unwind_section_header + 40 <= x86_cfi_pair.bytes.length)
                {
                    memcpy(&place_symbol_value, x86_cfi_pair.bytes.pointer + place_symbol_record + 8, sizeof(place_symbol_value));
                    memcpy(&unwind_section_address, x86_cfi_pair.bytes.pointer + unwind_section_header + 32, sizeof(unwind_section_address));
                }
                BUSTER_TEST(arguments, place_symbol_value == unwind_section_address + x86_cfi_record_start);
            }
            ObjectFile roundtrip = object_read(arguments->arena, x86_cfi_pair.bytes, x86_cfi_sparse.target);
            if (BUSTER_REQUIRE(arguments, roundtrip.error == OBJECT_ERROR_NONE && roundtrip.relocation_count == 1 && roundtrip.relocations != 0))
            {
                BUSTER_TEST(arguments, roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_PC32 &&
                                           roundtrip.relocations[0].section == OBJECT_SECTION_UNWIND &&
                                           roundtrip.relocations[0].offset == x86_cfi_relocation.offset &&
                                           roundtrip.relocations[0].addend == x86_cfi_addends[addend_index]);
            }
        }
        x86_cfi_relocation.addend = (s64)INT32_MAX + 1;
        BUSTER_TEST(arguments, object_write(arguments->arena, &x86_cfi_sparse, OBJECT_FORMAT_MACH_O64).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        x86_cfi_relocation.addend = (s64)INT32_MIN - 1;
        BUSTER_TEST(arguments, object_write(arguments->arena, &x86_cfi_sparse, OBJECT_FORMAT_MACH_O64).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        if (x86_cfi_place_adjustment)
        {
            x86_cfi_relocation.addend = (s64)INT32_MIN + (s64)x86_cfi_place_adjustment - 1;
            BUSTER_TEST(arguments, object_write(arguments->arena, &x86_cfi_sparse, OBJECT_FORMAT_MACH_O64).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
        }
        if (x86_cfi_pair.error == OBJECT_ERROR_NONE && x86_cfi_relocations_offset)
        {
            for (u32 defect = 0; defect < 7; defect += 1)
            {
                ByteSlice broken = {.pointer = arena_allocate(arguments->arena, u8, x86_cfi_pair.bytes.length), .length = x86_cfi_pair.bytes.length};
                memcpy(broken.pointer, x86_cfi_pair.bytes.pointer, (size_t)broken.length);
                u32 words[4] = {0};
                memcpy(words, broken.pointer + x86_cfi_relocations_offset, sizeof(words));
                switch (defect)
                {
                case 0:
                    words[2] += 4;
                    break; // Pair offsets differ.
                case 1:
                    words[1] |= 1u << 24;
                    break; // Subtraction is not PC-relative.
                case 2:
                    words[3] |= 1u << 28;
                    break; // Second record must be UNSIGNED.
                case 3:
                    words[3] &= ~(1u << 27);
                    break; // Both symbols must be external.
                case 4:
                    words[1] |= 0x00ffffff;
                    break; // Invalid subtractor symbol.
                case 5:
                    words[1] &= 0xff000000;
                    break; // Text symbol is not the CFI record base.
                case 6:
                {
                    u64 symbol_record = object_test_mach_symbol_offset(broken, x86_cfi_sparse.symbol_count);
                    if (symbol_record != UINT64_MAX)
                    {
                        u64 value = 0;
                        memcpy(&value, broken.pointer + symbol_record + 8, sizeof(value));
                        object_test_write_u64(broken, symbol_record + 8, value + 1);
                    }
                    break; // An internal CFI label is not a record boundary.
                }
                }
                memcpy(broken.pointer + x86_cfi_relocations_offset, words, sizeof(words));
                BUSTER_TEST(arguments, object_read(arguments->arena, broken, x86_cfi_sparse.target).error != OBJECT_ERROR_NONE);
            }
        }
    }

    CodegenModule a64_cfi_module = separate_module;
    a64_cfi_module.relocations = 0;
    a64_cfi_module.relocation_count = 0;
    a64_cfi_module.abi = CODEGEN_ABI_AARCH64_AAPCS64;
    ObjectFile a64_cfi_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &a64_cfi_module,
                                                                     (Target){
                                                                         .cpu_arch = CPU_ARCH_AARCH64,
                                                                         .os = OPERATING_SYSTEM_LINUX,
                                                                     });
    if (BUSTER_REQUIRE(arguments, a64_cfi_object.error == OBJECT_ERROR_NONE))
    {
        ObjectArtifact a64_cfi_elf = object_write(arguments->arena, &a64_cfi_object, OBJECT_FORMAT_ELF64);
        if (BUSTER_REQUIRE(arguments, a64_cfi_elf.error == OBJECT_ERROR_NONE))
        {
            ObjectFile a64_cfi_roundtrip = object_read(arguments->arena, a64_cfi_elf.bytes, a64_cfi_object.target);
            if (BUSTER_REQUIRE(arguments, a64_cfi_roundtrip.error == OBJECT_ERROR_NONE))
            {
                if (BUSTER_REQUIRE(arguments, a64_cfi_roundtrip.relocation_count == 1 && a64_cfi_roundtrip.relocations != 0))
                {
                    BUSTER_TEST(arguments, a64_cfi_roundtrip.relocations[0].section == OBJECT_SECTION_UNWIND);
                    BUSTER_TEST(arguments, a64_cfi_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_PREL32);
                }
            }
        }
    }
    ObjectFile a64_mach_cfi_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &a64_cfi_module,
                                                                (Target){
                                                                    .cpu_arch = CPU_ARCH_AARCH64,
                                                                    .os = OPERATING_SYSTEM_MACOS,
                                                                });
    bool a64_mach_cfi_object_valid = BUSTER_REQUIRE(arguments, a64_mach_cfi_object.error == OBJECT_ERROR_NONE);
    if (a64_mach_cfi_object_valid)
    {
        a64_mach_cfi_object_valid = BUSTER_REQUIRE(arguments, a64_mach_cfi_object.section_count > OBJECT_SECTION_UNWIND && a64_mach_cfi_object.sections != 0);
    }
    if (a64_mach_cfi_object_valid)
    {
        ObjectArtifact a64_mach_cfi_artifact = object_write(arguments->arena, &a64_mach_cfi_object, OBJECT_FORMAT_MACH_O64);
        if (BUSTER_REQUIRE(arguments, a64_mach_cfi_artifact.error == OBJECT_ERROR_NONE))
        {
            u64 a64_mach_cfi_section_header = 32 + 72 + (u64)OBJECT_SECTION_UNWIND * 80;
            if (BUSTER_REQUIRE(arguments, a64_mach_cfi_artifact.bytes.pointer != 0 && a64_mach_cfi_section_header + 68 <= a64_mach_cfi_artifact.bytes.length))
            {
                u32 a64_mach_cfi_flags = 0;
                memcpy(&a64_mach_cfi_flags, a64_mach_cfi_artifact.bytes.pointer + a64_mach_cfi_section_header + 64, sizeof(a64_mach_cfi_flags));
                BUSTER_TEST(arguments, a64_mach_cfi_flags == 0x6800000b);
            }
            if (BUSTER_REQUIRE(arguments, a64_mach_cfi_object.relocation_count == 1 && a64_mach_cfi_object.relocations != 0))
            {
                ObjectRelocation* cfi_relocation = a64_mach_cfi_object.relocations;
                u32 raw_offset = 0;
                u32 relocation_offset = 0;
                u32 relocation_count = 0;
                bool located = object_test_mach_section_offsets(a64_mach_cfi_artifact.bytes, OBJECT_SECTION_UNWIND, &raw_offset,
                                                                  &relocation_offset, &relocation_count);
                u64 record_start = 0;
                bool record_valid = object_test_eh_frame_record_start(a64_mach_cfi_object.sections[OBJECT_SECTION_UNWIND].data,
                                                                      cfi_relocation->offset, &record_start);
                u64 symbol_record = object_test_mach_symbol_offset(a64_mach_cfi_artifact.bytes, a64_mach_cfi_object.symbol_count);
                u64 symbol_value = UINT64_MAX;
                u64 section_address = UINT64_MAX;
                u32 stored = 0;
                if (located && symbol_record != UINT64_MAX)
                {
                    memcpy(&stored, a64_mach_cfi_artifact.bytes.pointer + raw_offset + cfi_relocation->offset, sizeof(stored));
                    memcpy(&symbol_value, a64_mach_cfi_artifact.bytes.pointer + symbol_record + 8, sizeof(symbol_value));
                    memcpy(&section_address, a64_mach_cfi_artifact.bytes.pointer + a64_mach_cfi_section_header + 32, sizeof(section_address));
                }
                BUSTER_TEST(arguments, located && relocation_count == 2 && record_valid &&
                                           symbol_value == section_address + record_start &&
                                           (s32)stored == cfi_relocation->addend - (s64)(cfi_relocation->offset - record_start));
            }
            ObjectFile a64_mach_cfi_roundtrip = object_read(arguments->arena, a64_mach_cfi_artifact.bytes, a64_mach_cfi_object.target);
            if (BUSTER_REQUIRE(arguments, a64_mach_cfi_roundtrip.error == OBJECT_ERROR_NONE && a64_mach_cfi_roundtrip.sections != 0 &&
                                              a64_mach_cfi_roundtrip.section_count > OBJECT_SECTION_UNWIND))
            {
                BUSTER_TEST(arguments, a64_mach_cfi_roundtrip.sections[OBJECT_SECTION_UNWIND].data.length ==
                                           a64_mach_cfi_object.sections[OBJECT_SECTION_UNWIND].data.length);
                if (BUSTER_REQUIRE(arguments, a64_mach_cfi_roundtrip.relocation_count == 1 && a64_mach_cfi_roundtrip.relocations != 0))
                {
                    BUSTER_TEST(arguments, a64_mach_cfi_roundtrip.relocations[0].section == OBJECT_SECTION_UNWIND);
                    BUSTER_TEST(arguments, a64_mach_cfi_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_PREL32);
                }
            }
        }
    }

    u32 a64_mach_prel_text_data[2] = {0};
    u32 a64_mach_prel_read_only_data[2] = {0};
    u32 a64_mach_prel_data_data[2] = {0};
    ObjectSection a64_mach_prel_sections[] = {
        {
            .name = S8(".text"),
            .data = BUSTER_ARRAY_TO_BYTE_SLICE(a64_mach_prel_text_data),
            .kind = OBJECT_SECTION_TEXT,
            .alignment = 4,
        },
        {
            .name = S8(".rodata"),
            .data = BUSTER_ARRAY_TO_BYTE_SLICE(a64_mach_prel_read_only_data),
            .kind = OBJECT_SECTION_READ_ONLY_DATA,
            .alignment = 4,
        },
        {
            .name = S8(".data"),
            .data = BUSTER_ARRAY_TO_BYTE_SLICE(a64_mach_prel_data_data),
            .kind = OBJECT_SECTION_DATA,
            .alignment = 4,
        },
    };
    ObjectSymbol a64_mach_prel_symbols[] = {
        {
            .name = S8("prel_text_target"),
            .section = OBJECT_SECTION_TEXT,
            .size = sizeof(u32),
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
        {
            .name = S8("prel_read_only_target"),
            .section = OBJECT_SECTION_READ_ONLY_DATA,
            .size = sizeof(u32),
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
        {
            .name = S8("prel_data_target"),
            .section = OBJECT_SECTION_DATA,
            .size = sizeof(u32),
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    s64 a64_mach_prel_addends[] = {17, -23, 4096};
    ObjectRelocation a64_mach_prel_relocations[] = {
        {
            .addend = a64_mach_prel_addends[0],
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_PREL32,
        },
        {
            .addend = a64_mach_prel_addends[1],
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_READ_ONLY_DATA,
            .symbol = 2,
            .kind = OBJECT_RELOCATION_AARCH64_PREL32,
        },
        {
            .addend = a64_mach_prel_addends[2],
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_DATA,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_AARCH64_PREL32,
        },
    };
    ObjectFile a64_mach_prel_object = {
        .sections = a64_mach_prel_sections,
        .section_count = BUSTER_ARRAY_LENGTH(a64_mach_prel_sections),
        .symbols = a64_mach_prel_symbols,
        .symbol_count = BUSTER_ARRAY_LENGTH(a64_mach_prel_symbols),
        .relocations = a64_mach_prel_relocations,
        .relocation_count = BUSTER_ARRAY_LENGTH(a64_mach_prel_relocations),
        .target = {
            .cpu_arch = CPU_ARCH_AARCH64,
            .os = OPERATING_SYSTEM_MACOS,
        },
    };
    ObjectArtifact a64_mach_prel_artifact = object_write(arguments->arena, &a64_mach_prel_object, OBJECT_FORMAT_MACH_O64);
    BUSTER_TEST(arguments, a64_mach_prel_artifact.error == OBJECT_ERROR_NONE);
    // LLVM's AArch64 Mach-O PREL32 lowering is the SUBTRACTOR/UNSIGNED pair
    // checked below: both records are external, non-PC-relative, and 32-bit.
    bool a64_mach_prel_shape_valid = true;
    for (u32 section_index = 0; section_index < BUSTER_ARRAY_LENGTH(a64_mach_prel_sections); section_index += 1)
    {
        u32 raw_offset = 0;
        u32 relocation_offset = 0;
        u32 relocation_count = 0;
        bool offsets_valid = object_test_mach_section_offsets(a64_mach_prel_artifact.bytes, section_index, &raw_offset, &relocation_offset,
                                                               &relocation_count);
        a64_mach_prel_shape_valid &= offsets_valid && relocation_count == 2;
        if (offsets_valid && relocation_count == 2)
        {
            u32 first_source_offset = 0;
            u32 first_information = 0;
            u32 second_source_offset = 0;
            u32 second_information = 0;
            memcpy(&first_source_offset, a64_mach_prel_artifact.bytes.pointer + relocation_offset, sizeof(first_source_offset));
            memcpy(&first_information, a64_mach_prel_artifact.bytes.pointer + relocation_offset + 4, sizeof(first_information));
            memcpy(&second_source_offset, a64_mach_prel_artifact.bytes.pointer + relocation_offset + 8, sizeof(second_source_offset));
            memcpy(&second_information, a64_mach_prel_artifact.bytes.pointer + relocation_offset + 12, sizeof(second_information));
            a64_mach_prel_shape_valid &= first_source_offset == sizeof(u32) && second_source_offset == sizeof(u32) &&
                                         (first_information >> 28) == 1 && ((first_information >> 25) & 3) == 2 &&
                                         (first_information & (1u << 27)) && !(first_information & (1u << 24)) &&
                                         (second_information >> 28) == 0 && ((second_information >> 25) & 3) == 2 &&
                                         (second_information & (1u << 27)) && !(second_information & (1u << 24));
        }
    }
    BUSTER_TEST(arguments, a64_mach_prel_shape_valid);
    ObjectFile a64_mach_prel_roundtrip = object_read(arguments->arena, a64_mach_prel_artifact.bytes, a64_mach_prel_object.target);
    ObjectSectionKind a64_mach_prel_expected_sections[] = {
        OBJECT_SECTION_TEXT,
        OBJECT_SECTION_READ_ONLY_DATA,
        OBJECT_SECTION_DATA,
    };
    String8 a64_mach_prel_expected_symbols[] = {
        S8("prel_read_only_target"),
        S8("prel_data_target"),
        S8("prel_text_target"),
    };
    if (BUSTER_REQUIRE(arguments, a64_mach_prel_roundtrip.error == OBJECT_ERROR_NONE && a64_mach_prel_roundtrip.relocations != 0 &&
                                      a64_mach_prel_roundtrip.symbols != 0 &&
                                      a64_mach_prel_roundtrip.relocation_count == BUSTER_ARRAY_LENGTH(a64_mach_prel_relocations)))
    {
        for (u32 relocation_index = 0; relocation_index < BUSTER_ARRAY_LENGTH(a64_mach_prel_relocations); relocation_index += 1)
        {
            ObjectRelocation* roundtrip_relocation = &a64_mach_prel_roundtrip.relocations[relocation_index];
            BUSTER_TEST(arguments, roundtrip_relocation->section == (u32)a64_mach_prel_expected_sections[relocation_index]);
            BUSTER_TEST(arguments, roundtrip_relocation->offset == sizeof(u32));
            BUSTER_TEST(arguments, roundtrip_relocation->kind == OBJECT_RELOCATION_AARCH64_PREL32);
            BUSTER_TEST(arguments, roundtrip_relocation->addend == a64_mach_prel_addends[relocation_index]);
            BUSTER_TEST(arguments, roundtrip_relocation->symbol < a64_mach_prel_roundtrip.symbol_count);
            if (roundtrip_relocation->symbol < a64_mach_prel_roundtrip.symbol_count)
            {
                BUSTER_STRING_TEST(arguments, a64_mach_prel_roundtrip.symbols[roundtrip_relocation->symbol].name,
                                   a64_mach_prel_expected_symbols[relocation_index]);
            }
        }
    }
    for (u32 malformed_kind = 0; malformed_kind < 13; malformed_kind += 1)
    {
        TemporalArena malformed_scope = arena_begin_temporal(arguments->arena);
        ByteSlice malformed = {
            .pointer = arena_allocate(arguments->arena, u8, a64_mach_prel_artifact.bytes.length),
            .length = a64_mach_prel_artifact.bytes.length,
        };
        memcpy(malformed.pointer, a64_mach_prel_artifact.bytes.pointer, malformed.length);
        u32 raw_offset = 0;
        u32 relocation_offset = 0;
        u32 relocation_count = 0;
        bool offsets_valid = object_test_mach_section_offsets(malformed, 0, &raw_offset, &relocation_offset, &relocation_count);
        if (offsets_valid && relocation_count == 2)
        {
            u32 first_information = 0;
            u32 second_information = 0;
            memcpy(&first_information, malformed.pointer + relocation_offset + 4, sizeof(first_information));
            memcpy(&second_information, malformed.pointer + relocation_offset + 12, sizeof(second_information));
            switch (malformed_kind)
            {
                case 0:
                    object_test_write_u32(malformed, relocation_offset + 4, first_information & ~(1u << 27));
                    break;
                case 1:
                    object_test_write_u32(malformed, relocation_offset + 4, first_information | (1u << 24));
                    break;
                case 2:
                    object_test_write_u32(malformed, relocation_offset + 12, second_information & ~(1u << 27));
                    break;
                case 3:
                    object_test_write_u32(malformed, relocation_offset + 12, second_information | (1u << 24));
                    break;
                case 4:
                    object_test_write_u32(malformed, relocation_offset + 12,
                                          (second_information & ~(0xfu << 28)) | (2u << 28));
                    break;
                case 5:
                    object_test_write_u32(malformed, relocation_offset + 12,
                                          (second_information & ~(3u << 25)) | (3u << 25));
                    break;
                case 6:
                    object_test_write_u32(malformed, relocation_offset + 8, sizeof(u32) * 2);
                    break;
                case 7:
                {
                    u32 first_source_offset = 0;
                    u32 first_word = 0;
                    u32 second_source_offset = 0;
                    u32 second_word = 0;
                    memcpy(&first_source_offset, malformed.pointer + relocation_offset, sizeof(first_source_offset));
                    memcpy(&first_word, malformed.pointer + relocation_offset + 4, sizeof(first_word));
                    memcpy(&second_source_offset, malformed.pointer + relocation_offset + 8, sizeof(second_source_offset));
                    memcpy(&second_word, malformed.pointer + relocation_offset + 12, sizeof(second_word));
                    object_test_write_u32(malformed, relocation_offset, second_source_offset);
                    object_test_write_u32(malformed, relocation_offset + 4, second_word);
                    object_test_write_u32(malformed, relocation_offset + 8, first_source_offset);
                    object_test_write_u32(malformed, relocation_offset + 12, first_word);
                    break;
                }
                case 8:
                {
                    u64 symbol_offset = object_test_mach_symbol_offset(malformed, BUSTER_ARRAY_LENGTH(a64_mach_prel_symbols));
                    if (symbol_offset != UINT64_MAX)
                    {
                        object_test_write_u64(malformed, symbol_offset + 8, 8);
                    }
                    break;
                }
                case 9:
                {
                    u64 symbol_offset = object_test_mach_symbol_offset(malformed, BUSTER_ARRAY_LENGTH(a64_mach_prel_symbols));
                    if (symbol_offset != UINT64_MAX && symbol_offset + 6 <= malformed.length)
                    {
                        malformed.pointer[symbol_offset + 5] = OBJECT_SECTION_READ_ONLY_DATA + 1;
                    }
                    break;
                }
                case 10:
                    object_test_write_u32(malformed, 32 + 72 + 60, 1);
                    break;
                case 11:
                    // A bare arm64 32-bit UNSIGNED record is not a PREL32
                    // pair and must not be accepted as ABS32.
                    object_test_write_u32(malformed, relocation_offset + 4, (first_information & ~(0xfu << 28)) | (0u << 28));
                    break;
                case 12:
                    // PREL32 fields are 4-byte objects; a pair at an
                    // unaligned offset is malformed even when its records
                    // otherwise have the canonical shape.
                    object_test_write_u32(malformed, relocation_offset, 2);
                    object_test_write_u32(malformed, relocation_offset + 8, 2);
                    break;
            }
        }
        ObjectFile malformed_result = object_read(arguments->arena, malformed, a64_mach_prel_object.target);
        BUSTER_TEST(arguments, offsets_valid && malformed_result.error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, malformed_scope.position);
    }
    // The Mach-O writer owns the serialized PREL32 word.  Verify that it
    // overwrites stale input for both zero and nonzero addends.
    u32 saved_a64_mach_prel_text = a64_mach_prel_text_data[1];
    u32 saved_a64_mach_prel_read_only = a64_mach_prel_read_only_data[1];
    u32 saved_a64_mach_prel_data = a64_mach_prel_data_data[1];
    s64 saved_a64_mach_prel_addend = a64_mach_prel_relocations[0].addend;
    a64_mach_prel_text_data[1] = UINT32_C(0xdeadbeef);
    a64_mach_prel_read_only_data[1] = UINT32_C(0xcafebabe);
    a64_mach_prel_data_data[1] = UINT32_C(0xfeedface);
    a64_mach_prel_relocations[0].addend = 0;
    ObjectArtifact a64_mach_prel_zero_artifact = object_write(arguments->arena, &a64_mach_prel_object, OBJECT_FORMAT_MACH_O64);
    u32 zero_raw_offset = 0;
    u32 ignored_relocation_offset = 0;
    u32 ignored_relocation_count = 0;
    bool zero_offsets_valid = object_test_mach_section_offsets(a64_mach_prel_zero_artifact.bytes, OBJECT_SECTION_TEXT, &zero_raw_offset,
                                                                &ignored_relocation_offset, &ignored_relocation_count);
    u32 zero_slot = UINT32_MAX;
    if (zero_offsets_valid && (u64)zero_raw_offset + sizeof(u32) * 2 <= a64_mach_prel_zero_artifact.bytes.length)
    {
        memcpy(&zero_slot, a64_mach_prel_zero_artifact.bytes.pointer + zero_raw_offset + sizeof(u32), sizeof(zero_slot));
    }
    if (BUSTER_REQUIRE(arguments, a64_mach_prel_zero_artifact.error == OBJECT_ERROR_NONE && zero_offsets_valid && zero_slot == 0))
    {
        ObjectFile a64_mach_prel_zero_roundtrip = object_read(arguments->arena, a64_mach_prel_zero_artifact.bytes, a64_mach_prel_object.target);
        if (BUSTER_REQUIRE(arguments, a64_mach_prel_zero_roundtrip.error == OBJECT_ERROR_NONE && a64_mach_prel_zero_roundtrip.relocation_count == 3 &&
                                          a64_mach_prel_zero_roundtrip.relocations != 0))
        {
            BUSTER_TEST(arguments, a64_mach_prel_zero_roundtrip.relocations[0].addend == 0);
        }
    }
    a64_mach_prel_relocations[0].addend = INT32_MAX;
    a64_mach_prel_relocations[1].addend = INT32_MIN;
    a64_mach_prel_relocations[2].addend = 0;
    ObjectArtifact a64_mach_prel_boundary_artifact = object_write(arguments->arena, &a64_mach_prel_object, OBJECT_FORMAT_MACH_O64);
    if (BUSTER_REQUIRE(arguments, a64_mach_prel_boundary_artifact.error == OBJECT_ERROR_NONE))
    {
        ObjectFile a64_mach_prel_boundary_roundtrip = object_read(arguments->arena, a64_mach_prel_boundary_artifact.bytes, a64_mach_prel_object.target);
        if (BUSTER_REQUIRE(arguments, a64_mach_prel_boundary_roundtrip.error == OBJECT_ERROR_NONE && a64_mach_prel_boundary_roundtrip.relocation_count == 3 &&
                                          a64_mach_prel_boundary_roundtrip.relocations != 0))
        {
            BUSTER_TEST(arguments, a64_mach_prel_boundary_roundtrip.relocations[0].addend == INT32_MAX &&
                                       a64_mach_prel_boundary_roundtrip.relocations[1].addend == INT32_MIN &&
                                       a64_mach_prel_boundary_roundtrip.relocations[2].addend == 0);
        }
    }
    s64 invalid_a64_mach_prel_addends[] = {(s64)INT32_MIN - 1, (s64)INT32_MAX + 1};
    for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(invalid_a64_mach_prel_addends); addend_index += 1)
    {
        a64_mach_prel_relocations[0].addend = invalid_a64_mach_prel_addends[addend_index];
        ObjectArtifact invalid_prel_artifact = object_write(arguments->arena, &a64_mach_prel_object, OBJECT_FORMAT_MACH_O64);
        BUSTER_TEST(arguments, invalid_prel_artifact.error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    }
    ObjectRelocation misaligned_a64_mach_prel_relocation = a64_mach_prel_relocations[0];
    misaligned_a64_mach_prel_relocation.offset = 2;
    ObjectFile misaligned_a64_mach_prel_object = a64_mach_prel_object;
    misaligned_a64_mach_prel_object.relocations = &misaligned_a64_mach_prel_relocation;
    misaligned_a64_mach_prel_object.relocation_count = 1;
    misaligned_a64_mach_prel_relocation.addend = 0;
    BUSTER_TEST(arguments, object_write(arguments->arena, &misaligned_a64_mach_prel_object, OBJECT_FORMAT_MACH_O64).error == OBJECT_ERROR_INVALID_INPUT);
    a64_mach_prel_text_data[1] = saved_a64_mach_prel_text;
    a64_mach_prel_read_only_data[1] = saved_a64_mach_prel_read_only;
    a64_mach_prel_data_data[1] = saved_a64_mach_prel_data;
    a64_mach_prel_relocations[0].addend = saved_a64_mach_prel_addend;
    a64_mach_prel_relocations[1].addend = -23;
    a64_mach_prel_relocations[2].addend = 4096;
    u8 compact_x64_code[] = {
        0x55, 0x48, 0x89, 0xe5, 0xc3,
    };
    CodegenFunctionDescriptor compact_x64_descriptor = {0};
    BUSTER_TEST(arguments, object_mach_compact_decode(arguments->arena, (ByteSlice)BUSTER_ARRAY_TO_SLICE(compact_x64_code), 0,
                                                      (u32)sizeof(compact_x64_code), 0x01000000,
                                                      (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS}, &compact_x64_descriptor));
    BUSTER_TEST(arguments, compact_x64_descriptor.unwind_action_count == 2 && compact_x64_descriptor.prolog_size == 4);
    BUSTER_TEST(arguments, !object_mach_compact_decode(arguments->arena, (ByteSlice)BUSTER_ARRAY_TO_SLICE(compact_x64_code), 0,
                                                       (u32)sizeof(compact_x64_code), 0x01000001,
                                                       (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS}, &compact_x64_descriptor));
    u32 compact_a64_code[] = {
        0xd10083ff, 0xa9017bfd, 0x910043fd, 0xd65f03c0,
    };
    CodegenFunctionDescriptor compact_a64_descriptor = {0};
    BUSTER_TEST(arguments, object_mach_compact_decode(arguments->arena,
                                                      (ByteSlice){.pointer = (u8*)compact_a64_code, .length = sizeof(compact_a64_code)}, 0,
                                                      (u32)sizeof(compact_a64_code), 0x04000000,
                                                      (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS}, &compact_a64_descriptor));
    BUSTER_TEST(arguments, compact_a64_descriptor.unwind_action_count == 4 && compact_a64_descriptor.prolog_size == 12);
    DwarfCfiResult compact_a64_cfi = dwarf_cfi_build(arguments->arena, (DwarfCfiInput){
                                                                           .functions = &compact_a64_descriptor,
                                                                           .target = {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS},
                                                                           .function_count = 1,
                                                                       });
    BUSTER_TEST(arguments, compact_a64_cfi.valid);
    u32 compact_a64_saved_code[] = {
        0xa9be6ffc, 0xa9017bfd, 0x910043fd, 0xd65f03c0,
    };
    BUSTER_TEST(arguments, object_mach_compact_decode(arguments->arena,
                                                      (ByteSlice){.pointer = (u8*)compact_a64_saved_code, .length = sizeof(compact_a64_saved_code)}, 0,
                                                      (u32)sizeof(compact_a64_saved_code), 0x04000010,
                                                      (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS}, &compact_a64_descriptor));
    BUSTER_TEST(arguments, compact_a64_descriptor.unwind_action_count == 6);
    u32 compact_a64_leaf_code[] = {
        0xd10083ff, 0xd65f03c0,
    };
    BUSTER_TEST(arguments, object_mach_compact_decode(arguments->arena,
                                                      (ByteSlice){.pointer = (u8*)compact_a64_leaf_code, .length = sizeof(compact_a64_leaf_code)}, 0,
                                                      (u32)sizeof(compact_a64_leaf_code), 0x02002000,
                                                      (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS}, &compact_a64_descriptor));
    BUSTER_TEST(arguments, compact_a64_descriptor.unwind_action_count == 1 && compact_a64_descriptor.prolog_size == 4);
    BUSTER_TEST(arguments, !object_mach_compact_decode(arguments->arena,
                                                       (ByteSlice){.pointer = (u8*)compact_a64_code, .length = sizeof(compact_a64_code)}, 0,
                                                       (u32)sizeof(compact_a64_code), 0x05000000,
                                                       (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS}, &compact_a64_descriptor));
    u8 compact_x64_entry[32] = {0};
    u32 compact_x64_size = (u32)sizeof(compact_x64_code);
    u32 compact_x64_encoding = 0x01000000;
    memcpy(compact_x64_entry + 8, &compact_x64_size, sizeof(compact_x64_size));
    memcpy(compact_x64_entry + 12, &compact_x64_encoding, sizeof(compact_x64_encoding));
    if (mach_cfi_object_valid)
    {
        ObjectSection* compact_x64_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
        memcpy(compact_x64_sections, mach_cfi_object.sections, sizeof(*compact_x64_sections) * OBJECT_SECTION_COUNT);
        compact_x64_sections[OBJECT_SECTION_TEXT].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(compact_x64_code);
        compact_x64_sections[OBJECT_SECTION_READ_ONLY_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(compact_x64_entry);
        compact_x64_sections[OBJECT_SECTION_UNWIND].data = (ByteSlice){0};
        ObjectSymbol compact_x64_symbol = {
            .name = S8("compact_x64"),
            .size = sizeof(compact_x64_code),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        };
        ObjectRelocation compact_x64_relocation = {
            .section = OBJECT_SECTION_READ_ONLY_DATA,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        };
        ObjectFile compact_x64_object = mach_cfi_object;
        compact_x64_object.sections = compact_x64_sections;
        compact_x64_object.symbols = &compact_x64_symbol;
        compact_x64_object.relocations = &compact_x64_relocation;
        compact_x64_object.symbol_count = 1;
        compact_x64_object.relocation_count = 1;
        ObjectArtifact compact_x64_artifact = object_write(arguments->arena, &compact_x64_object, OBJECT_FORMAT_MACH_O64);
        BUSTER_TEST(arguments, compact_x64_artifact.error == OBJECT_ERROR_NONE && object_test_mach_compact_section_rewrite(compact_x64_artifact.bytes));
        ObjectFile compact_x64_roundtrip = object_read(arguments->arena, compact_x64_artifact.bytes, compact_x64_object.target);
        if (BUSTER_REQUIRE(arguments, compact_x64_roundtrip.error == OBJECT_ERROR_NONE && compact_x64_roundtrip.sections != 0 &&
                                          compact_x64_roundtrip.section_count > OBJECT_SECTION_UNWIND))
        {
            BUSTER_TEST(arguments, compact_x64_roundtrip.sections[OBJECT_SECTION_UNWIND].data.length > 0);
            if (BUSTER_REQUIRE(arguments, compact_x64_roundtrip.relocation_count == 1 && compact_x64_roundtrip.relocations != 0))
            {
                BUSTER_TEST(arguments, compact_x64_roundtrip.relocations[0].kind == OBJECT_RELOCATION_X86_64_PC32);
            }
        }
    }

    u8 compact_a64_entry[32] = {0};
    u32 compact_a64_size = (u32)sizeof(compact_a64_code);
    u32 compact_a64_encoding = 0x04000000;
    memcpy(compact_a64_entry + 8, &compact_a64_size, sizeof(compact_a64_size));
    memcpy(compact_a64_entry + 12, &compact_a64_encoding, sizeof(compact_a64_encoding));
    if (a64_mach_cfi_object_valid)
    {
        ObjectSection* compact_a64_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
        memcpy(compact_a64_sections, a64_mach_cfi_object.sections, sizeof(*compact_a64_sections) * OBJECT_SECTION_COUNT);
        compact_a64_sections[OBJECT_SECTION_TEXT].data = (ByteSlice){.pointer = (u8*)compact_a64_code, .length = sizeof(compact_a64_code)};
        compact_a64_sections[OBJECT_SECTION_READ_ONLY_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(compact_a64_entry);
        compact_a64_sections[OBJECT_SECTION_UNWIND].data = (ByteSlice){0};
        ObjectSymbol compact_a64_symbol = {
            .name = S8("compact_a64"),
            .size = sizeof(compact_a64_code),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        };
        ObjectRelocation compact_a64_relocation = {
            .section = OBJECT_SECTION_READ_ONLY_DATA,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        };
        ObjectFile compact_a64_object = a64_mach_cfi_object;
        compact_a64_object.sections = compact_a64_sections;
        compact_a64_object.symbols = &compact_a64_symbol;
        compact_a64_object.relocations = &compact_a64_relocation;
        compact_a64_object.symbol_count = 1;
        compact_a64_object.relocation_count = 1;
        ObjectArtifact compact_a64_artifact = object_write(arguments->arena, &compact_a64_object, OBJECT_FORMAT_MACH_O64);
        BUSTER_TEST(arguments, compact_a64_artifact.error == OBJECT_ERROR_NONE && object_test_mach_compact_section_rewrite(compact_a64_artifact.bytes));
        ObjectFile compact_a64_roundtrip = object_read(arguments->arena, compact_a64_artifact.bytes, compact_a64_object.target);
        if (BUSTER_REQUIRE(arguments, compact_a64_roundtrip.error == OBJECT_ERROR_NONE && compact_a64_roundtrip.sections != 0 &&
                                          compact_a64_roundtrip.section_count > OBJECT_SECTION_UNWIND))
        {
            BUSTER_TEST(arguments, compact_a64_roundtrip.sections[OBJECT_SECTION_UNWIND].data.length > 0);
            if (BUSTER_REQUIRE(arguments, compact_a64_roundtrip.relocation_count == 1 && compact_a64_roundtrip.relocations != 0))
            {
                BUSTER_TEST(arguments, compact_a64_roundtrip.relocations[0].kind == OBJECT_RELOCATION_AARCH64_PREL32);
            }
        }
    }
    CodegenFunctionDescriptor invalid_function = separate_function;
    invalid_function.prolog_size = invalid_function.code_size + 1;
    CodegenModule invalid_module = separate_module;
    invalid_module.functions = &invalid_function;
    ObjectFile invalid_object = object_from_canonical_codegen_module(arguments->arena, &separate_program, &invalid_module,
                                                           (Target){
                                                               .cpu_arch = CPU_ARCH_X86_64,
                                                               .os = OPERATING_SYSTEM_LINUX,
                                                           });
    BUSTER_TEST(arguments, invalid_object.error == OBJECT_ERROR_INVALID_INPUT);

    Target x86_linux_target = {
        .cpu_arch = CPU_ARCH_X86_64,
        .os = OPERATING_SYSTEM_LINUX,
    };
    {
        TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
        ByteSlice mutation = {
            .pointer = arena_allocate(arguments->arena, u8, elf.bytes.length),
            .length = elf.bytes.length,
        };
        memcpy(mutation.pointer, elf.bytes.pointer, elf.bytes.length);
        object_test_write_u64(mutation, 40, UINT64_MAX);
        BUSTER_TEST(arguments, object_read(arguments->arena, mutation, x86_linux_target).error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, mutation_scope.position);
    }
    {
        u64 section_table = 0;
        u16 section_count = 0;
        u16 section_string_index = 0;
        memcpy(&section_table, elf.bytes.pointer + 40, sizeof(section_table));
        memcpy(&section_count, elf.bytes.pointer + 60, sizeof(section_count));
        memcpy(&section_string_index, elf.bytes.pointer + 62, sizeof(section_string_index));
        if (section_string_index < section_count)
        {
            TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
            ByteSlice mutation = {
                .pointer = arena_allocate(arguments->arena, u8, elf.bytes.length),
                .length = elf.bytes.length,
            };
            memcpy(mutation.pointer, elf.bytes.pointer, elf.bytes.length);
            object_test_write_u32(mutation, section_table + (u64)section_string_index * 64, UINT32_MAX);
            BUSTER_TEST(arguments, object_read(arguments->arena, mutation, x86_linux_target).error != OBJECT_ERROR_NONE);
            arena_set_position(arguments->arena, mutation_scope.position);
        }
    }
    {
        u64 section_table = 0;
        u16 section_count = 0;
        memcpy(&section_table, elf.bytes.pointer + 40, sizeof(section_table));
        memcpy(&section_count, elf.bytes.pointer + 60, sizeof(section_count));
        for (u16 section_index = 0; section_index < section_count; section_index += 1)
        {
            u64 section = section_table + (u64)section_index * 64;
            u32 section_type = 0;
            memcpy(&section_type, elf.bytes.pointer + section + 4, sizeof(section_type));
            if (section_type == 8)
            {
                TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
                ByteSlice mutation = {
                    .pointer = arena_allocate(arguments->arena, u8, elf.bytes.length),
                    .length = elf.bytes.length,
                };
                memcpy(mutation.pointer, elf.bytes.pointer, elf.bytes.length);
                object_test_write_u64(mutation, section + 32, UINT64_MAX);
                BUSTER_TEST(arguments, object_read(arguments->arena, mutation, x86_linux_target).error != OBJECT_ERROR_NONE);
                arena_set_position(arguments->arena, mutation_scope.position);
                break;
            }
        }
    }
    {
        u64 section_table = 0;
        u16 section_count = 0;
        memcpy(&section_table, elf.bytes.pointer + 40, sizeof(section_table));
        memcpy(&section_count, elf.bytes.pointer + 60, sizeof(section_count));
        for (u16 section_index = 0; section_index < section_count; section_index += 1)
        {
            u64 section = section_table + (u64)section_index * 64;
            u32 section_type = 0;
            memcpy(&section_type, elf.bytes.pointer + section + 4, sizeof(section_type));
            if (section_type == 4)
            {
                TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
                ByteSlice mutation = {
                    .pointer = arena_allocate(arguments->arena, u8, elf.bytes.length),
                    .length = elf.bytes.length,
                };
                memcpy(mutation.pointer, elf.bytes.pointer, elf.bytes.length);
                object_test_write_u64(mutation, section + 24, UINT64_MAX);
                BUSTER_TEST(arguments, object_read(arguments->arena, mutation, x86_linux_target).error != OBJECT_ERROR_NONE);
                arena_set_position(arguments->arena, mutation_scope.position);
                break;
            }
        }
    }
    {
        u64 section_table = 0;
        u16 section_count = 0;
        memcpy(&section_table, elf.bytes.pointer + 40, sizeof(section_table));
        memcpy(&section_count, elf.bytes.pointer + 60, sizeof(section_count));
        for (u16 section_index = 0; section_index < section_count; section_index += 1)
        {
            u64 section = section_table + (u64)section_index * 64;
            u32 section_type = 0;
            u64 symbol_offset = 0;
            u64 symbol_size = 0;
            memcpy(&section_type, elf.bytes.pointer + section + 4, sizeof(section_type));
            memcpy(&symbol_offset, elf.bytes.pointer + section + 24, sizeof(symbol_offset));
            memcpy(&symbol_size, elf.bytes.pointer + section + 32, sizeof(symbol_size));
            if (section_type == 2 && symbol_size >= 48)
            {
                TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
                ByteSlice mutation = {
                    .pointer = arena_allocate(arguments->arena, u8, elf.bytes.length),
                    .length = elf.bytes.length,
                };
                memcpy(mutation.pointer, elf.bytes.pointer, elf.bytes.length);
                object_test_write_u16(mutation, symbol_offset + 24 + 6, 0x7fff);
                BUSTER_TEST(arguments, object_read(arguments->arena, mutation, x86_linux_target).error != OBJECT_ERROR_NONE);
                arena_set_position(arguments->arena, mutation_scope.position);
                break;
            }
        }
    }
    {
        u64 symbol = object_test_elf_symbol_offset(elf.bytes, 1);
        BUSTER_TEST(arguments, symbol != UINT64_MAX);
        if (symbol != UINT64_MAX)
        {
            u16 special_indexes[] = {0xfff1, 0xfff2, 0xffff};
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(special_indexes); index += 1)
            {
                TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
                ByteSlice mutation = {
                    .pointer = arena_allocate(arguments->arena, u8, elf.bytes.length),
                    .length = elf.bytes.length,
                };
                memcpy(mutation.pointer, elf.bytes.pointer, elf.bytes.length);
                object_test_write_u16(mutation, symbol + 6, special_indexes[index]);
                BUSTER_TEST(arguments, object_read(arguments->arena, mutation, x86_linux_target).error == OBJECT_ERROR_NONE);
                arena_set_position(arguments->arena, mutation_scope.position);
            }
        }
    }
    {
        u8 one_byte_text[] = {0xc3};
        ObjectSection one_byte_section = {
            .name = S8(".text"),
            .data = BUSTER_ARRAY_TO_SLICE(one_byte_text),
            .virtual_size = sizeof(one_byte_text),
            .kind = OBJECT_SECTION_TEXT,
            .alignment = 1,
        };
        ObjectSymbol one_byte_symbol = {
            .name = S8("one_byte"),
            .size = sizeof(one_byte_text),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        };
        ObjectFile one_byte_object = {
            .sections = &one_byte_section,
            .symbols = &one_byte_symbol,
            .target = x86_linux_target,
            .section_count = 1,
            .symbol_count = 1,
        };
        ObjectArtifact one_byte_elf = object_write(arguments->arena, &one_byte_object, OBJECT_FORMAT_ELF64);
        BUSTER_TEST(arguments, one_byte_elf.error == OBJECT_ERROR_NONE);
        u64 symbol = object_test_elf_symbol_offset(one_byte_elf.bytes, 1);
        BUSTER_TEST(arguments, symbol != UINT64_MAX);
        if (symbol != UINT64_MAX)
        {
            TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
            ByteSlice mutation = {
                .pointer = arena_allocate(arguments->arena, u8, one_byte_elf.bytes.length),
                .length = one_byte_elf.bytes.length,
            };
            memcpy(mutation.pointer, one_byte_elf.bytes.pointer, one_byte_elf.bytes.length);
            object_test_write_u64(mutation, symbol + 16, UINT64_MAX);
            BUSTER_TEST(arguments, object_read(arguments->arena, mutation, x86_linux_target).error != OBJECT_ERROR_NONE);
            arena_set_position(arguments->arena, mutation_scope.position);
        }
    }
    {
        TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
        ByteSlice mutation = {
            .pointer = arena_allocate(arguments->arena, u8, coff.bytes.length),
            .length = coff.bytes.length,
        };
        memcpy(mutation.pointer, coff.bytes.pointer, coff.bytes.length);
        object_test_write_u32(mutation, 20 + 16, UINT32_MAX);
        object_test_write_u32(mutation, 20 + 20, 0);
        BUSTER_TEST(arguments, object_read(arguments->arena, mutation, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS}).error !=
                                   OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, mutation_scope.position);
    }
    {
        TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
        ByteSlice mutation = {
            .pointer = arena_allocate(arguments->arena, u8, coff.bytes.length),
            .length = coff.bytes.length,
        };
        memcpy(mutation.pointer, coff.bytes.pointer, coff.bytes.length);
        object_test_write_u32(mutation, 8, UINT32_MAX);
        BUSTER_TEST(arguments, object_read(arguments->arena, mutation, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS}).error !=
                                   OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, mutation_scope.position);
    }
    {
        u32 symbol_offset = 0;
        u32 symbol_count = 0;
        memcpy(&symbol_offset, coff.bytes.pointer + 8, sizeof(symbol_offset));
        memcpy(&symbol_count, coff.bytes.pointer + 12, sizeof(symbol_count));
        if (symbol_count)
        {
            TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
            ByteSlice mutation = {
                .pointer = arena_allocate(arguments->arena, u8, coff.bytes.length),
                .length = coff.bytes.length,
            };
            memcpy(mutation.pointer, coff.bytes.pointer, coff.bytes.length);
            object_test_write_u32(mutation, symbol_offset, 0);
            object_test_write_u32(mutation, symbol_offset + 4, UINT32_MAX);
            object_test_write_u32(mutation, symbol_offset + 8, 0);
            object_test_write_u16(mutation, symbol_offset + 12, 1);
            BUSTER_TEST(arguments, object_read(arguments->arena, mutation, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS}).error !=
                                       OBJECT_ERROR_NONE);
            arena_set_position(arguments->arena, mutation_scope.position);
        }
    }
    {
        u16 section_count = 0;
        u32 symbol_offset = 0;
        u32 symbol_count = 0;
        memcpy(&section_count, coff.bytes.pointer + 2, sizeof(section_count));
        memcpy(&symbol_offset, coff.bytes.pointer + 8, sizeof(symbol_offset));
        memcpy(&symbol_count, coff.bytes.pointer + 12, sizeof(symbol_count));
        u16 ignored_section_number = 0;
        u64 ignored_section = 0;
        for (u16 section_index = 0; section_index < section_count; section_index += 1)
        {
            u64 section = 20 + (u64)section_index * 40;
            if (memcmp(coff.bytes.pointer + section, ".bss", 4) == 0 && coff.bytes.pointer[section + 4] == 0)
            {
                ignored_section_number = section_index + 1;
                ignored_section = section;
                break;
            }
        }
        BUSTER_TEST(arguments, ignored_section_number != 0);
        if (ignored_section_number)
        {
            bool ignored_symbol = false;
            for (u32 symbol_index = 0; symbol_index < symbol_count; symbol_index += 1)
            {
                u16 symbol_section = 0;
                u64 symbol = (u64)symbol_offset + (u64)symbol_index * 18;
                memcpy(&symbol_section, coff.bytes.pointer + symbol + 12, sizeof(symbol_section));
                ignored_symbol |= symbol_section == ignored_section_number;
            }
            BUSTER_TEST(arguments, ignored_symbol);

            TemporalArena ignored_scope = arena_begin_temporal(arguments->arena);
            ByteSlice ignored_bytes = {
                .pointer = arena_allocate(arguments->arena, u8, coff.bytes.length),
                .length = coff.bytes.length,
            };
            memcpy(ignored_bytes.pointer, coff.bytes.pointer, coff.bytes.length);
            object_test_write_u32(ignored_bytes, ignored_section + 36, 0x02000800);
            ObjectFile ignored_object = object_read(arguments->arena, ignored_bytes,
                                                     (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS});
            BUSTER_TEST(arguments, ignored_object.error == OBJECT_ERROR_NONE);
            BUSTER_TEST(arguments, ignored_object.symbol_count < coff_roundtrip.symbol_count);
            arena_set_position(arguments->arena, ignored_scope.position);

            bool relocation_symbol = false;
            u32 relocation_symbol_index = 0;
            for (u16 section_index = 0; section_index < section_count && !relocation_symbol; section_index += 1)
            {
                if (section_index + 1 == ignored_section_number)
                {
                    continue;
                }
                u64 section = 20 + (u64)section_index * 40;
                u32 relocation_offset = 0;
                u16 relocation_count = 0;
                memcpy(&relocation_offset, coff.bytes.pointer + section + 24, sizeof(relocation_offset));
                memcpy(&relocation_count, coff.bytes.pointer + section + 32, sizeof(relocation_count));
                if (relocation_count)
                {
                    memcpy(&relocation_symbol_index, coff.bytes.pointer + relocation_offset + 4, sizeof(relocation_symbol_index));
                    relocation_symbol = relocation_symbol_index < symbol_count;
                }
            }
            BUSTER_TEST(arguments, relocation_symbol);
            if (relocation_symbol)
            {
                TemporalArena relocation_scope = arena_begin_temporal(arguments->arena);
                ByteSlice relocation_bytes = {
                    .pointer = arena_allocate(arguments->arena, u8, coff.bytes.length),
                    .length = coff.bytes.length,
                };
                memcpy(relocation_bytes.pointer, coff.bytes.pointer, coff.bytes.length);
                object_test_write_u32(relocation_bytes, ignored_section + 36, 0x02000800);
                object_test_write_u16(relocation_bytes, (u64)symbol_offset + (u64)relocation_symbol_index * 18 + 12, ignored_section_number);
                BUSTER_TEST(arguments, object_read(arguments->arena, relocation_bytes,
                                                   (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS})
                                                   .error != OBJECT_ERROR_NONE);
                arena_set_position(arguments->arena, relocation_scope.position);
            }
        }
    }
    {
        TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
        ByteSlice mutation = {
            .pointer = arena_allocate(arguments->arena, u8, mach.bytes.length),
            .length = mach.bytes.length,
        };
        memcpy(mutation.pointer, mach.bytes.pointer, mach.bytes.length);
        object_test_write_u32(mutation, 20, 8);
        BUSTER_TEST(arguments, object_read(arguments->arena, mutation, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS}).error !=
                                   OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, mutation_scope.position);
    }
    {
        TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
        ByteSlice mutation = {
            .pointer = arena_allocate(arguments->arena, u8, mach.bytes.length),
            .length = mach.bytes.length,
        };
        memcpy(mutation.pointer, mach.bytes.pointer, mach.bytes.length);
        object_test_write_u32(mutation, 16, UINT32_MAX);
        BUSTER_TEST(arguments, object_read(arguments->arena, mutation, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS}).error !=
                                   OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, mutation_scope.position);
    }
    {
        u32 command_count = 0;
        memcpy(&command_count, mach.bytes.pointer + 16, sizeof(command_count));
        u64 command = 32;
        for (u32 command_index = 0; command_index < command_count; command_index += 1)
        {
            u32 kind = 0;
            u32 command_size = 0;
            memcpy(&kind, mach.bytes.pointer + command, sizeof(kind));
            memcpy(&command_size, mach.bytes.pointer + command + 4, sizeof(command_size));
            if (kind == 2)
            {
                TemporalArena mutation_scope = arena_begin_temporal(arguments->arena);
                ByteSlice mutation = {
                    .pointer = arena_allocate(arguments->arena, u8, mach.bytes.length),
                    .length = mach.bytes.length,
                };
                memcpy(mutation.pointer, mach.bytes.pointer, mach.bytes.length);
                object_test_write_u32(mutation, command + 16, UINT32_MAX);
                BUSTER_TEST(arguments, object_read(arguments->arena, mutation, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS}).error !=
                                           OBJECT_ERROR_NONE);
                arena_set_position(arguments->arena, mutation_scope.position);
                break;
            }
            command += command_size;
        }
    }
    {
        TemporalArena archive_scope = arena_begin_temporal(arguments->arena);
        ByteSlice normal_archive = object_test_archive(arguments->arena, elf.bytes, false);
        ObjectArchive normal = object_archive_read(arguments->arena, normal_archive, x86_linux_target);
        BUSTER_TEST(arguments, normal.error == OBJECT_ERROR_NONE && normal.object_count == 1);
        ByteSlice bsd_archive = object_test_archive(arguments->arena, elf.bytes, true);
        ObjectArchive bsd = object_archive_read(arguments->arena, bsd_archive, x86_linux_target);
        BUSTER_TEST(arguments, bsd.error == OBJECT_ERROR_NONE && bsd.object_count == 1);
        ByteSlice long_name_archive = object_test_archive_long_name(arguments->arena, elf.bytes);
        ObjectArchive long_name = object_archive_read(arguments->arena, long_name_archive, x86_linux_target);
        BUSTER_TEST(arguments, long_name.error == OBJECT_ERROR_NONE && long_name.object_count == 1);
        if (long_name.error == OBJECT_ERROR_NONE && long_name.object_count == 1)
        {
            BUSTER_STRING_TEST(arguments, long_name.member_names[0], S8("long-member-name.o"));
        }
        ByteSlice ecsymbols_archive = object_test_archive_ecsymbols(arguments->arena, elf.bytes, S8("/<ECSYMBOLS>/"));
        ObjectArchive ecsymbols = object_archive_read(arguments->arena, ecsymbols_archive, x86_linux_target);
        BUSTER_TEST(arguments, ecsymbols.error == OBJECT_ERROR_NONE && ecsymbols.object_count == 1);
        ByteSlice near_ecsymbols_archive = object_test_archive_ecsymbols(arguments->arena, elf.bytes, S8("/<ECSYMBOLS>X/"));
        BUSTER_TEST(arguments, object_archive_read(arguments->arena, near_ecsymbols_archive, x86_linux_target).error != OBJECT_ERROR_NONE);
        {
            u64 long_table_size = S8("long-member-name.o/\n").length;
            u64 object_header = 8 + 60 + long_table_size + (long_table_size & 1);
            TemporalArena boundary_scope = arena_begin_temporal(arguments->arena);
            ByteSlice bad_boundary = {
                .pointer = arena_allocate(arguments->arena, u8, long_name_archive.length),
                .length = long_name_archive.length,
            };
            memcpy(bad_boundary.pointer, long_name_archive.pointer, long_name_archive.length);
            bad_boundary.pointer[object_header] = '/';
            bad_boundary.pointer[object_header + 1] = '1';
            BUSTER_TEST(arguments, object_archive_read(arguments->arena, bad_boundary, x86_linux_target).error != OBJECT_ERROR_NONE);
            arena_set_position(arguments->arena, boundary_scope.position);
        }
        TemporalArena long_name_scope = arena_begin_temporal(arguments->arena);
        ByteSlice bad_long_name = {
            .pointer = arena_allocate(arguments->arena, u8, long_name_archive.length),
            .length = long_name_archive.length,
        };
        memcpy(bad_long_name.pointer, long_name_archive.pointer, long_name_archive.length);
        bad_long_name.pointer[8 + 60 + S8("long-member-name.o/\n").length - 1] = 'x';
        BUSTER_TEST(arguments, object_archive_read(arguments->arena, bad_long_name, x86_linux_target).error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, long_name_scope.position);
        ByteSlice padded_archive = elf.bytes.length & 1 ? normal_archive : bsd_archive;
        TemporalArena padding_scope = arena_begin_temporal(arguments->arena);
        ByteSlice bad_padding = {
            .pointer = arena_allocate(arguments->arena, u8, padded_archive.length),
            .length = padded_archive.length,
        };
        memcpy(bad_padding.pointer, padded_archive.pointer, padded_archive.length);
        bad_padding.pointer[bad_padding.length - 1] = 0;
        BUSTER_TEST(arguments, object_archive_read(arguments->arena, bad_padding, x86_linux_target).error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, padding_scope.position);
        TemporalArena size_scope = arena_begin_temporal(arguments->arena);
        ByteSlice bad_size = {
            .pointer = arena_allocate(arguments->arena, u8, normal_archive.length),
            .length = normal_archive.length,
        };
        memcpy(bad_size.pointer, normal_archive.pointer, normal_archive.length);
        memset(bad_size.pointer + 8 + 48, '9', 10);
        BUSTER_TEST(arguments, object_archive_read(arguments->arena, bad_size, x86_linux_target).error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, size_scope.position);
        ObjectArchive null_archive = object_archive_read(arguments->arena, (ByteSlice){.length = 8}, x86_linux_target);
        BUSTER_TEST(arguments, null_archive.error != OBJECT_ERROR_NONE);
        arena_set_position(arguments->arena, archive_scope.position);
    }
    String8 clang_coff_fixture_path = arguments->coff_relocation_fixture_path;
    if (clang_coff_fixture_path.length)
    {
        TemporalArena clang_coff_scope = arena_begin_temporal(arguments->arena);
        ByteSlice clang_coff_bytes = file_read(arguments->arena, clang_coff_fixture_path, (FileReadOptions){0});
        Target clang_coff_target = {
            .cpu_arch = CPU_ARCH_X86_64,
            .os = OPERATING_SYSTEM_WINDOWS,
        };
        ObjectFile clang_coff = object_read(arguments->arena, clang_coff_bytes, clang_coff_target);
        bool clang_coff_valid = clang_coff.error == OBJECT_ERROR_NONE && clang_coff.relocation_count == UINT16_MAX + 1 &&
                                clang_coff.relocations && clang_coff.symbols && clang_coff.symbol_count;
        if (BUSTER_REQUIRE(arguments, clang_coff_valid))
        {
            ObjectRelocation* first = clang_coff.relocations;
            ObjectRelocation* last = clang_coff.relocations + clang_coff.relocation_count - 1;
            bool symbols_valid = first->symbol < clang_coff.symbol_count && last->symbol < clang_coff.symbol_count;
            BUSTER_TEST(arguments, first->section == last->section && first->offset == 0 && first->addend == 0 &&
                                       first->kind == OBJECT_RELOCATION_ABSOLUTE64);
            BUSTER_TEST(arguments, last->offset == (u64)UINT16_MAX * sizeof(u64) && last->addend == 0 &&
                                       last->kind == OBJECT_RELOCATION_ABSOLUTE64);
            if (BUSTER_REQUIRE(arguments, symbols_valid))
            {
                BUSTER_STRING_TEST(arguments, clang_coff.symbols[first->symbol].name, S8("relocation_marker"));
                BUSTER_STRING_TEST(arguments, clang_coff.symbols[last->symbol].name, S8("relocation_marker"));
            }
        }
        arena_set_position(arguments->arena, clang_coff_scope.position);
    }
#if BUSTER_FUZZ_AVAILABLE
    {
        TemporalArena fuzz_scope = arena_begin_temporal(arguments->arena);
        u64 boundary_size = BUSTER_KB(64);
        u8* boundary_input = arena_allocate(arguments->arena, u8, boundary_size + 1);
        memset(boundary_input, 0, boundary_size + 1);
        BUSTER_TEST(arguments, object_fuzz_test_input(boundary_input, boundary_size) == 0);
        BUSTER_TEST(arguments, object_fuzz_test_input(boundary_input, boundary_size + 1) == -1);
        arena_set_position(arguments->arena, fuzz_scope.position);
    }
#endif
    return result;
}
#endif
