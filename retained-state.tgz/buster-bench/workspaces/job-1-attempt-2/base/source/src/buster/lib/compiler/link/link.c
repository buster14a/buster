// The linker. Two public steps (link.h): link_objects merges ObjectFiles —
// section merging, deterministic COFF COMDAT group resolution, ordinary
// symbol resolution (ObjectSymbol.weak decides weak/strong precedence after
// a group winner is known), and relocation rebasing — into one
// combined ObjectFile, and link_native_executable lays that file out as a
// runnable image, dispatching near the bottom to one writer per
// target/format family: static and dynamic ELF64 for x86-64 and AArch64,
// hosted PE64, imports-free UEFI PE64, Mach-O, and Android ELF. The
// writers share the helpers above them — AArch64 branch range checks and
// veneers, ELF .eh_frame table construction, PE export/import plumbing,
// CodeView/PDB resolution (link_pe_resolved_codeview), SHA-256 for build
// ids — but each owns its image layout whole, because the formats agree
// on almost nothing. Before x86-64 Linux writer selection,
// link_elf_without_unused_got_marker removes only unreferenced reserved markers
// from a private symbol/relocation view; the input object is never changed.
//
// One rule crosses every writer that synthesizes an entry point: C 5.1.2.2.3
// makes a return from `main` equivalent to calling `exit` with that value, so
// a **hosted** stub calls the C runtime's `exit` and lets it terminate the
// process. Ending in a raw exit syscall (Linux) or ExitProcess (Windows)
// skips stdio flushing and every atexit handler, which silently discards
// what a program printed and returned on. The raw syscall stays as the
// **freestanding** shape, where there is no `exit` to call: the static ELF
// writers, which are chosen exactly when nothing is undefined. Mach-O
// synthesizes no stub at all — LC_MAIN hands the entry point to dyld, which
// already calls `exit` with what it returns.
// Hosted ELF startup also preserves and registers the loader-supplied
// finalizer before any executable destructor registration, so `exit` reaches
// the startup-loaded shared libraries as well as this image's handlers.
//
// `__attribute__((constructor))` follows the same split. A writer with an
// entry stub calls the registered functions from it and takes the two array
// sections off the object first (link_initializer_plan_build), because every
// writer places every non-debug section it is given. Mach-O has no stub and
// needs none for its constructors: it keeps `__DATA,__mod_init_func`, gives
// it a section command of the type dyld dispatches on, and lets the loader
// call the entries. dyld runs no `__mod_term_func` in a main executable, so
// that array comes off the object instead (link_mach_initializer_prepare)
// and a registrar prepended to the initializer array registers a runner over
// it with `atexit`. The UEFI writer has neither a stub nor such a loader and
// refuses the link; link_initializer_plan_empty is that refusal.
//
// A second rule crosses the dynamic ELF writers: imported data reaches a
// non-PIE executable through a copy relocation, and the slot that relocation
// fills stands for the shared library's object, not for the name the program
// referenced. When the driver was able to read the library's symbol table
// (NativeDynamicDataSymbol), the writer defines every name exported at that
// address on the slot, sizes the slot from the library, and gives two imported
// names for one object one slot; see link_elf_index_initialize. Defining
// only the referenced name leaves the library binding its own post-startup
// stores — glibc's `__environ = ev` — to its own storage while the program
// reads a copy taken before startup ran. The ordinary ELF symbol table must
// describe those final copy-slot definitions too: link_elf_output_symbol uses
// the writer's import indices and emitted dynamic values without changing the
// input ObjectFile. The .bss section header includes the slots already covered
// by the writable segment; no loaded bytes or program headers move.
//
// A third rule crosses every ELF writer: an undefined weak symbol is worth
// address zero rather than a dynamic import, which is what a startup object
// reads to tell a static program from a dynamic one. A default-visibility
// reference is the one exception, and only when some library in the link is
// known to define the name -- otherwise the loader is being asked for a
// symbol nothing has and the import's own thunk or slot is what answers.
// link_elf_symbol_resolves_to_zero and link_elf_symbol_needs_dynamic_import,
// above the first ELF writer, are the single form of that question; the
// writers, the dispatcher at the bottom, and the Android writer all ask it,
// and the AArch64 dynamic writer re-derives the x86-64 writer's import
// numbering from it, so the two cannot be allowed to disagree. The dynamic
// writers ask it once per symbol and then read their own import numbering,
// using the same link-local export index as version and alias construction.

#include <buster/lib/compiler/link/link.h>
#include <buster/lib/compiler/link/link_internal.h>

#include <buster/lib/compiler/assembly/aarch64_encoding.h>
#include <buster/lib/compiler/assembly/x86_64_metadata.h>
#include <buster/lib/compiler/pdb/pdb.h>

#include <buster/lib/file.h>
#include <buster/lib/hash.h>
#include <buster/lib/integer.h>
#include <buster/lib/os.h>
#include <buster/lib/string.h>

BUSTER_GLOBAL_LOCAL ObjectSectionKind const link_elf_debug_kinds[] = {
    OBJECT_SECTION_DEBUG_INFO,
    OBJECT_SECTION_DEBUG_ABBREV,
    OBJECT_SECTION_DEBUG_LINE,
    OBJECT_SECTION_DEBUG_STR,
    OBJECT_SECTION_DEBUG_LOC,
    OBJECT_SECTION_DEBUG_RANGES,
    OBJECT_SECTION_DEBUG_ADDR,
    OBJECT_SECTION_DEBUG_STR_OFFSETS,
    OBJECT_SECTION_DEBUG_LINE_STR,
    OBJECT_SECTION_DEBUG_RNGLISTS,
    OBJECT_SECTION_DEBUG_LOCLISTS,
};

BUSTER_GLOBAL_LOCAL ObjectSectionKind const link_elf_loaded_kinds[] = {
    OBJECT_SECTION_TEXT,
    OBJECT_SECTION_READ_ONLY_DATA,
    OBJECT_SECTION_DATA,
    OBJECT_SECTION_ZERO,
    OBJECT_SECTION_THREAD_LOCAL_DATA,
    OBJECT_SECTION_THREAD_LOCAL_ZERO,
    OBJECT_SECTION_UNWIND,
};

#define BUSTER_LINK_ELF_SECTION_HEADER_SIZE 64
#define BUSTER_LINK_ELF_SYMBOL_SIZE 24
#define BUSTER_LINK_ELF_SECTION_TYPE_VERSION_NEED 0x6ffffffe
#define BUSTER_LINK_ELF_SECTION_TYPE_VERSION_SYMBOLS 0x6fffffff
#define BUSTER_LINK_ELF_DYNAMIC_SECTION_COUNT 10
#define BUSTER_LINK_ELF_SECTION_DESCRIPTOR_CAPACITY                                                                                                          \
    (BUSTER_ARRAY_LENGTH(link_elf_loaded_kinds) + 1 + BUSTER_LINK_ELF_DYNAMIC_SECTION_COUNT + BUSTER_ARRAY_LENGTH(link_elf_debug_kinds) + 2)

typedef struct LinkElfSectionTableLayout LinkElfSectionTableLayout;
struct LinkElfSectionTableLayout
{
    u64 eh_frame_header_offset;
    u64 eh_frame_header_size;
    u64 interpreter_offset;
    u64 interpreter_size;
    u64 plt_offset;
    u64 plt_size;
    u64 dynamic_string_offset;
    u64 dynamic_string_size;
    u64 dynamic_symbol_offset;
    u64 dynamic_symbol_size;
    u64 hash_offset;
    u64 hash_size;
    u64 version_symbol_offset;
    u64 version_symbol_size;
    u64 version_need_offset;
    u64 version_need_size;
    u64 relocation_offset;
    u64 relocation_size;
    u64 got_offset;
    u64 got_size;
    u64 dynamic_offset;
    u64 dynamic_size;
    u32 const* import_indices;
    String8 const* copy_alias_names;
    u64 copy_alias_symbol_offset;
    u64 copy_zero_size;
    u32 copy_alias_count;
    u32 version_need_count;
    bool dynamic;
    u8 reserved[3];
};

typedef struct LinkElfEhFrameEntry LinkElfEhFrameEntry;
struct LinkElfEhFrameEntry
{
    u64 fde_offset;
    u64 function_address;
    u32 relocation;
    u32 reserved;
};

typedef struct LinkElfEhFrameTable LinkElfEhFrameTable;
struct LinkElfEhFrameTable
{
    LinkElfEhFrameEntry* entries;
    LinkElfEhFrameEntry* scratch;
    u32 count;
    bool valid;
    u8 reserved[3];
};

BUSTER_GLOBAL_LOCAL String8 link_string_copy(Arena* arena, String8 source)
{
    String8 result = {0};
    if (source.length)
    {
        result.pointer = arena_allocate(arena, char8, source.length);
        result.length = source.length;
        memcpy(result.pointer, source.pointer, source.length);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool link_target_matches(Target left, Target right)
{
    return left.cpu_arch == right.cpu_arch && left.os == right.os;
}

BUSTER_GLOBAL_LOCAL void link_write_u16(u8* bytes, u64 offset, u16 value)
{
    memcpy(bytes + offset, &value, sizeof(value));
}

BUSTER_GLOBAL_LOCAL void link_write_u32(u8* bytes, u64 offset, u32 value)
{
    memcpy(bytes + offset, &value, sizeof(value));
}

typedef struct LinkX86InstructionBuilder LinkX86InstructionBuilder;
struct LinkX86InstructionBuilder
{
    u8* bytes;
    u32 capacity;
    u32 count;
};

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand link_x86_register(u16 index, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
        .width = width,
        .reg = {.index = index, .width = width, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand link_x86_memory_rip(u16 width, s64 displacement)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
        .width = width,
        .memory = {
            .displacement = displacement,
            .address_size = 64,
            .has_displacement = true,
            .rip_relative = true,
            .source_width = width,
        },
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand link_x86_memory_base(u16 base, u16 width, s64 displacement)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
        .width = width,
        .memory = {
            .base = {.index = base, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
            .displacement = displacement,
            .address_size = 64,
            .scale = 1,
            .has_base = true,
            .has_displacement = displacement != 0,
            .source_width = width,
        },
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand link_x86_memory_base_index(u16 base, u16 index, u8 scale, u16 width,
                                                                                  s64 displacement)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
        .width = width,
        .memory = {
            .base = {.index = base, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
            .index = {.index = index, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
            .displacement = displacement,
            .address_size = 64,
            .scale = scale,
            .has_base = true,
            .has_index = true,
            .has_displacement = displacement != 0,
            .source_width = width,
        },
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand link_x86_immediate(s64 value, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE,
        .width = width,
        .value = value,
        .has_value = true,
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand link_x86_relative(s64 value, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE,
        .width = width,
        .value = value,
        .has_value = true,
    };
}

BUSTER_GLOBAL_LOCAL bool link_x86_emit(LinkX86InstructionBuilder* builder, String8 mnemonic,
                                       BusterX86MetadataPhysicalOperand const* operands, u32 operand_count)
{
    if (!builder || builder->count > builder->capacity || (operand_count && !operands) || operand_count > 16) return false;
    BusterX86MetadataEmitResult result = buster_x86_metadata_encode((BusterX86MetadataEncodeQuery){
        .physical = {
            .mnemonic = mnemonic,
            .operands = operands,
            .operand_count = operand_count,
            .features = {.names = 0, .count = 0},
            .address_size = 64,
            .execution_mode = BUSTER_X86_METADATA_EXECUTION_MODE_64,
            .include_privileged = true,
            .include_not64 = false,
            .include_implicit = false,
            .source_semantics = false,
        },
        .output = builder->bytes + builder->count,
        .output_capacity = builder->capacity - builder->count,
    });
    if (result.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || result.byte_count > builder->capacity - builder->count)
        return false;
    builder->count += result.byte_count;
    return true;
}

BUSTER_GLOBAL_LOCAL bool link_x86_emit_zero(LinkX86InstructionBuilder* builder, String8 mnemonic)
{
    return link_x86_emit(builder, mnemonic, 0, 0);
}

// ELF PLT entries reserve a five-byte PUSH for the import index.  The generic
// physical selector intentionally shortens numeric immediates when they fit
// (for example, PUSH 0 -> 6a 00), which is correct for ordinary instructions
// but changes the fixed 16-byte PLT entry layout.  Enumerate the PUSH metadata
// candidates locally and exact-emit the candidate whose schema carries an
// imm32 field; no form ID or raw instruction bytes are part of this adapter.
BUSTER_GLOBAL_LOCAL bool link_x86_emit_push_imm32(LinkX86InstructionBuilder* builder,
                                                  BusterX86MetadataPhysicalOperand const* immediate)
{
    if (builder && builder->count <= builder->capacity && immediate && immediate->kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE &&
        immediate->width == 32 && builder->capacity - builder->count >= 5)
    {
        BusterX86MetadataPhysicalQuery physical = {
            .mnemonic = S8("PUSH"),
            .operands = immediate,
            .operand_count = 1,
            .features = {.names = 0, .count = 0},
            .address_size = 64,
            .execution_mode = BUSTER_X86_METADATA_EXECUTION_MODE_64,
            .include_privileged = true,
            .include_not64 = false,
            .include_implicit = false,
            .source_semantics = false,
        };
        BusterX86MetadataCandidateRange candidates = buster_x86_metadata_lookup_mnemonic(S8("PUSH"));
        BusterX86MetadataCandidateIterator iterator = buster_x86_metadata_filter(candidates, (BusterX86MetadataFilter){
                                                                                                  .require_64_bit = true,
                                                                                                  .exclude_not64 = true,
                                                                                              });
        u32 form_id = UINT32_MAX;
        while (buster_x86_metadata_candidate_next(&iterator, &form_id))
        {
            BusterX86MetadataForm form = {0};
            if (!buster_x86_metadata_form(form_id, &form) || form.immediate_width != 4) continue;
            bool has_imm32_operand = false;
            for (u32 operand_index = 0; operand_index < form.operand_count; operand_index += 1)
            {
                BusterX86MetadataOperand operand = {0};
                if (!buster_x86_metadata_operand(form_id, operand_index, &operand))
                {
                    has_imm32_operand = false;
                    break;
                }
                if (operand.kind == BUSTER_X86_METADATA_OPERAND_IMMEDIATE &&
                    (operand.physical_width_flags & BUSTER_X86_METADATA_PHYSICAL_WIDTH_32))
                {
                    has_imm32_operand = true;
                }
            }
            if (!has_imm32_operand) continue;
            u8 encoded[16] = {0};
            BusterX86MetadataEmitResult result = buster_x86_metadata_emit_form((BusterX86MetadataEmitQuery){
                .physical = physical,
                .form_id = form_id,
                .output = encoded,
                .output_capacity = BUSTER_ARRAY_LENGTH(encoded),
            });
            if (result.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || result.byte_count != 5) continue;
            memcpy(builder->bytes + builder->count, encoded, result.byte_count);
            builder->count += result.byte_count;
            return true;
        }
    }

    return false;
}

// The freestanding shape without initializers has a fixed size. Hosted
// shapes also register the loader finalizer; both architectures report their
// actual stub size so the shared ELF layout can reserve the larger one.
enum
{
    LINK_ELF_FREESTANDING_ENTRY_STUB_SIZE = 35,
};

// One function an image has to call before or after `main`, as the merged
// object spells it: the symbol its `.init_array`/`.fini_array` slot is
// relocated against, plus that relocation's addend.  Buster's own objects
// name the function itself with a zero addend; Clang's name the section
// symbol plus the function's offset inside it, which is why the addend is
// carried rather than assumed away.
typedef struct LinkInitializerEntry LinkInitializerEntry;
struct LinkInitializerEntry
{
    s64 addend;
    u32 symbol;
    u32 reserved;
};

// Every initializer of an image, in the order it runs.  The linker writes the
// entry point itself -- there is no libc startup object in an image it
// produces, so nothing else would walk the arrays -- and it knows every
// entry's target at layout time, so it calls them directly rather than laying
// the arrays out and looping over them.  The two array sections are dropped
// from the image for exactly that reason: nothing in it would read them.
//
// `.fini_array` runs backwards, which is the order `destructors` is already
// in: the plan reverses it while it is built so every consumer walks both
// lists forwards.
typedef struct LinkInitializerPlan LinkInitializerPlan;
struct LinkInitializerPlan
{
    LinkInitializerEntry* constructors;
    LinkInitializerEntry* destructors;
    u32 constructor_count;
    u32 destructor_count;
};

// The entries of one array section, ordered by slot.  A slot with no
// relocation is a null pointer, which every startup implementation skips and
// which this therefore drops too.
BUSTER_GLOBAL_LOCAL u32 link_initializer_entries_collect(ObjectFile* object, ObjectSectionKind kind, LinkInitializerEntry* entries, bool reverse)
{
    u32 count = 0;
    u64 length = object->sections[kind].data.length;
    for (u64 offset = 0; offset + OBJECT_INITIALIZER_ENTRY_SIZE <= length; offset += OBJECT_INITIALIZER_ENTRY_SIZE)
    {
        for (u32 index = 0; index < object->relocation_count; index += 1)
        {
            ObjectRelocation relocation = object->relocations[index];
            if (relocation.section == (u32)kind && relocation.offset == offset && relocation.kind == OBJECT_RELOCATION_ABSOLUTE64)
            {
                entries[count++] = (LinkInitializerEntry){
                    .addend = relocation.addend,
                    .symbol = relocation.symbol,
                };
                break;
            }
        }
    }
    for (u32 index = 0; reverse && index * 2 + 1 < count; index += 1)
    {
        LinkInitializerEntry swapped = entries[index];
        entries[index] = entries[count - 1 - index];
        entries[count - 1 - index] = swapped;
    }

    return count;
}

// Reads the two array sections into a plan and hands back the same object
// with them, and the relocations that filled them, removed: the writers below
// place every non-debug section they are given, and an array nothing reads is
// storage the image does not need.  The object is copied rather than edited,
// because a caller may link the same merged file twice -- the AArch64 dynamic
// writer does exactly that.
BUSTER_GLOBAL_LOCAL bool link_initializer_plan_build(Arena* arena, ObjectFile* object, ObjectFile* stripped, LinkInitializerPlan* plan)
{
    bool result = true;
    *stripped = *object;
    *plan = (LinkInitializerPlan){0};
    u64 total = object->sections[OBJECT_SECTION_INIT_ARRAY].data.length + object->sections[OBJECT_SECTION_FINI_ARRAY].data.length;
    if (total)
    {
        u64 capacity = total / OBJECT_INITIALIZER_ENTRY_SIZE;
        if (capacity > UINT32_MAX)
        {
            result = false;
        }
        else
        {
            plan->constructors = arena_allocate(arena, LinkInitializerEntry, capacity ? capacity : 1);
            plan->destructors = plan->constructors + object->sections[OBJECT_SECTION_INIT_ARRAY].data.length / OBJECT_INITIALIZER_ENTRY_SIZE;
            plan->constructor_count = link_initializer_entries_collect(object, OBJECT_SECTION_INIT_ARRAY, plan->constructors, false);
            plan->destructor_count = link_initializer_entries_collect(object, OBJECT_SECTION_FINI_ARRAY, plan->destructors, true);
            ObjectSection* sections = arena_allocate(arena, ObjectSection, object->section_count);
            memcpy(sections, object->sections, (u64)object->section_count * sizeof(*sections));
            sections[OBJECT_SECTION_INIT_ARRAY].data = (ByteSlice){0};
            sections[OBJECT_SECTION_INIT_ARRAY].virtual_size = 0;
            sections[OBJECT_SECTION_FINI_ARRAY].data = (ByteSlice){0};
            sections[OBJECT_SECTION_FINI_ARRAY].virtual_size = 0;
            stripped->sections = sections;
            ObjectRelocation* relocations = arena_allocate(arena, ObjectRelocation, object->relocation_count ? object->relocation_count : 1);
            stripped->relocation_count = 0;
            for (u32 index = 0; index < object->relocation_count; index += 1)
            {
                u32 section = object->relocations[index].section;
                if (section != OBJECT_SECTION_INIT_ARRAY && section != OBJECT_SECTION_FINI_ARRAY)
                {
                    relocations[stripped->relocation_count++] = object->relocations[index];
                }
            }
            stripped->relocations = relocations;
        }
    }

    return result;
}

// Whether the destructors of this plan are registered with the C runtime
// instead of being called where `main` returned.  A program that terminates
// by calling `exit` never comes back to the entry stub, so an inline
// sequence after the call to `main` is skipped for it, while GNU runs a
// destructor either way (issue 781).  The hosted shapes therefore register a
// runner before the constructors run -- the position glibc's
// `__libc_start_main` hands `_dl_fini` to `__cxa_atexit` from, and what puts
// the runner behind every handler the program registers itself.  The
// freestanding shape keeps the inline sequence: it has no `exit` to call and
// no runtime to register with, and a -nostdlib program that reaches the raw
// exit syscall runs no handler either.
BUSTER_GLOBAL_LOCAL bool link_initializer_plan_defers_destructors(bool hosted, LinkInitializerPlan const* plan)
{
    return hosted && plan && plan->destructor_count != 0;
}

// The ELF loader supplies its finalizer in RDX. Register it before the
// executable's destructor runner and before any constructor can register a
// user handler, so reverse exit order leaves the shared libraries until last.
BUSTER_GLOBAL_LOCAL bool link_x86_register_loader_finalizer(LinkX86InstructionBuilder* builder, u32* call_offset)
{
    BusterX86MetadataPhysicalOperand operands[2] = {link_x86_register(2, 64), link_x86_register(2, 64)};
    bool valid = link_x86_emit(builder, S8("TEST"), operands, 2);
    operands[0] = link_x86_relative(0, 32);
    valid = valid && link_x86_emit(builder, S8("JZ"), operands, 1);
    u32 skip_field = builder->count >= 4 ? builder->count - 4 : 0;
    operands[0] = link_x86_register(7, 64);
    operands[1] = link_x86_register(2, 64);
    valid = valid && link_x86_emit(builder, S8("MOV"), operands, 2);
    operands[0] = link_x86_register(6, 32);
    operands[1] = link_x86_register(6, 32);
    valid = valid && link_x86_emit(builder, S8("XOR"), operands, 2);
    operands[0] = link_x86_register(2, 32);
    operands[1] = link_x86_register(2, 32);
    valid = valid && link_x86_emit(builder, S8("XOR"), operands, 2);
    if (call_offset) *call_offset = builder->count + 1;
    operands[0] = link_x86_relative(0, 32);
    valid = valid && link_x86_emit(builder, S8("CALL"), operands, 1);
    if (valid)
    {
        link_write_u32(builder->bytes, skip_field, builder->count - (skip_field + 4));
    }
    return valid;
}

// C 5.1.2.2.3 makes a return from `main` equivalent to calling `exit` with
// that value, so the entry stub of a hosted link must end in libc's `exit`
// (`hosted` true) and never in the raw exit_group syscall: the syscall
// terminates the process without flushing stdio and without running one
// atexit/__cxa_atexit handler, which silently discards everything a program
// printed and returned on.  The syscall shape stays for the freestanding link
// (`hosted` false) — a -nostdlib image has no `exit` to call and must still
// terminate with main's status.  `exit_displacement_offset` receives the
// hosted shape's second rel32 field for the caller to patch, exactly like the
// call to main; it is untouched in the freestanding shape.
// The initializer calls sit between the `and rsp, -16` and the call to
// `main`, so they run on the same aligned stack `main` does; the mask has to
// follow the three reads because it is the stack pointer those index off.
// GNU hands argc, argv and envp to every initializer, so they are read once
// into callee-saved registers and copied back into the argument registers
// before each call -- a called constructor owns rdi, rsi and rdx -- and
// `main`'s status is parked in ebx across the destructors, which take no
// arguments.
//
// Where link_initializer_plan_defers_destructors holds, the destructors are
// not called after `main` at all: the stub registers a runner with the C
// runtime through `atexit_displacement_offset`'s rel32, and the runner
// itself is emitted past the trap that ends the stub, in this same buffer,
// so one file slot holds both and one patch pass fills in every call.  Its
// address reaches rdi through a rip-relative LEA the builder resolves
// itself, because both ends of that displacement are offsets it just chose.
// The runner's own `sub rsp, 8` is what re-aligns the stack the call to it
// left eight bytes short of a sixteen-byte boundary.
//
// Hosted startup also registers the loader's finalizer even when the program
// has no initializer arrays of its own.
BUSTER_GLOBAL_LOCAL bool link_x86_build_elf_entry_stub(u8* bytes, u32 capacity, u32* byte_count, u32* call_displacement_offset, bool hosted,
                                                       u32* exit_displacement_offset, u32* atexit_displacement_offset, u32* loader_atexit_offset, LinkInitializerPlan const* plan,
                                                       u32* initializer_displacement_offsets)
{
    LinkX86InstructionBuilder builder = {.bytes = bytes, .capacity = capacity};
    BusterX86MetadataPhysicalOperand operands[2] = {0};
    u32 constructor_count = plan ? plan->constructor_count : 0;
    u32 destructor_count = plan ? plan->destructor_count : 0;
    bool registered = hosted || constructor_count || destructor_count;
    bool deferred_destructors = link_initializer_plan_defers_destructors(hosted, plan);
    // rbx, r12 and r13 preserve the arguments across runtime registration and
    // initializer calls. In hosted startup this also keeps incoming RDX intact
    // until link_x86_register_loader_finalizer consumes the loader finalizer.
    u16 argc_register = registered ? 3 : 7;
    u16 argv_register = registered ? 12 : 6;
    u16 envp_register = registered ? 13 : 2;
    u32 initializer_index = 0;
    u32 runner_displacement_field = 0;
    operands[0] = link_x86_register(5, 32);
    operands[1] = link_x86_register(5, 32);
    if (!link_x86_emit(&builder, S8("XOR"), operands, 2)) return false;
    operands[0] = link_x86_register(argc_register, 64);
    operands[1] = link_x86_memory_base(4, 64, 0);
    if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    operands[0] = link_x86_register(argv_register, 64);
    operands[1] = link_x86_memory_base(4, 64, 8);
    if (!link_x86_emit(&builder, S8("LEA"), operands, 2)) return false;
    operands[0] = link_x86_register(envp_register, 64);
    operands[1] = link_x86_memory_base_index(argv_register, argc_register, 8, 64, 8);
    if (!link_x86_emit(&builder, S8("LEA"), operands, 2)) return false;
    operands[0] = link_x86_register(4, 64);
    operands[1] = link_x86_immediate(-16, 8);
    if (!link_x86_emit(&builder, S8("AND"), operands, 2) ||
        (hosted && !link_x86_register_loader_finalizer(&builder, loader_atexit_offset))) return false;
    if (deferred_destructors)
    {
        // __cxa_atexit(runner, 0, 0).  The rip-relative displacement is the
        // last four bytes of the LEA whatever prefixes it carries, which is
        // why the field is taken from the end of the instruction rather than
        // from a counted opcode length.
        operands[0] = link_x86_register(7, 64);
        operands[1] = link_x86_memory_rip(64, 0);
        if (!link_x86_emit(&builder, S8("LEA"), operands, 2) || builder.count < 4) return false;
        runner_displacement_field = builder.count - 4;
        operands[0] = link_x86_register(6, 32);
        operands[1] = link_x86_register(6, 32);
        if (!link_x86_emit(&builder, S8("XOR"), operands, 2)) return false;
        operands[0] = link_x86_register(2, 32);
        operands[1] = link_x86_register(2, 32);
        if (!link_x86_emit(&builder, S8("XOR"), operands, 2)) return false;
        if (atexit_displacement_offset) *atexit_displacement_offset = builder.count + 1;
        operands[0] = link_x86_relative(0, 32);
        if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    }
    for (u32 constructor = 0; constructor < constructor_count; constructor += 1)
    {
        operands[0] = link_x86_register(7, 64);
        operands[1] = link_x86_register(argc_register, 64);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
        operands[0] = link_x86_register(6, 64);
        operands[1] = link_x86_register(argv_register, 64);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
        operands[0] = link_x86_register(2, 64);
        operands[1] = link_x86_register(envp_register, 64);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
        if (initializer_displacement_offsets) initializer_displacement_offsets[initializer_index] = builder.count + 1;
        initializer_index += 1;
        operands[0] = link_x86_relative(0, 32);
        if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    }
    if (registered)
    {
        operands[0] = link_x86_register(7, 64);
        operands[1] = link_x86_register(argc_register, 64);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
        operands[0] = link_x86_register(6, 64);
        operands[1] = link_x86_register(argv_register, 64);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
        operands[0] = link_x86_register(2, 64);
        operands[1] = link_x86_register(envp_register, 64);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    }
    if (call_displacement_offset) *call_displacement_offset = builder.count + 1;
    operands[0] = link_x86_relative(0, 32);
    if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    if (destructor_count && !deferred_destructors)
    {
        operands[0] = link_x86_register(3, 32);
        operands[1] = link_x86_register(0, 32);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
        for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
        {
            if (initializer_displacement_offsets) initializer_displacement_offsets[initializer_index] = builder.count + 1;
            initializer_index += 1;
            operands[0] = link_x86_relative(0, 32);
            if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
        }
        operands[0] = link_x86_register(0, 32);
        operands[1] = link_x86_register(3, 32);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    }
    operands[0] = link_x86_register(7, 32);
    operands[1] = link_x86_register(0, 32);
    if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    u32 expected_size = LINK_ELF_FREESTANDING_ENTRY_STUB_SIZE;
    if (hosted)
    {
        if (exit_displacement_offset) *exit_displacement_offset = builder.count + 1;
        operands[0] = link_x86_relative(0, 32);
        if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    }
    else
    {
        operands[0] = link_x86_register(0, 32);
        operands[1] = link_x86_immediate(60, 32);
        if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
        if (!link_x86_emit_zero(&builder, S8("SYSCALL"))) return false;
    }
    // Neither `exit` nor exit_group returns; the trap catches a libc that did.
    if (!link_x86_emit_zero(&builder, S8("HLT"))) return false;
    if (deferred_destructors)
    {
        link_write_u32(builder.bytes, runner_displacement_field, (u32)(builder.count - (runner_displacement_field + 4)));
        operands[0] = link_x86_register(4, 64);
        operands[1] = link_x86_immediate(8, 8);
        if (!link_x86_emit(&builder, S8("SUB"), operands, 2)) return false;
        for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
        {
            if (initializer_displacement_offsets) initializer_displacement_offsets[initializer_index] = builder.count + 1;
            initializer_index += 1;
            operands[0] = link_x86_relative(0, 32);
            if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
        }
        operands[0] = link_x86_register(4, 64);
        operands[1] = link_x86_immediate(8, 8);
        if (!link_x86_emit(&builder, S8("ADD"), operands, 2)) return false;
        if (!link_x86_emit_zero(&builder, S8("RET"))) return false;
    }
    if (byte_count) *byte_count = builder.count;
    return registered || builder.count == expected_size;
}

// The buffer the stub above needs.  Sixteen bytes per initializer covers the
// three argument moves and the call the constructor shape emits, and the
// destructor shape is shorter; the base carries the freestanding size, the
// status save and restore the inline destructors add, and -- for the hosted
// shape that defers them instead -- the registration call and the runner's
// own prologue, epilogue and return.
BUSTER_GLOBAL_LOCAL u32 link_x86_elf_entry_stub_capacity(LinkInitializerPlan const* plan)
{
    u32 count = plan ? plan->constructor_count + plan->destructor_count : 0;
    return 128 + 16 * count;
}

// The word an `ADR Xd, label` takes to reach a target this many bytes away.
// Both ends are offsets inside one stub buffer, so the displacement is known
// before the image has an address; the 21-bit signed field is what bounds the
// distance, and a stub that large is refused rather than truncated.
BUSTER_GLOBAL_LOCAL u32 link_aarch64_adr(u32 destination, s64 displacement, bool* valid)
{
    u32 result = 0;
    if (!valid || displacement < -(s64)(1 << 20) || displacement >= (s64)(1 << 20))
    {
        if (valid)
        {
            *valid = false;
        }
    }
    else
    {
        u32 immediate = (u32)(s32)displacement & UINT32_C(0x1fffff);
        result = UINT32_C(0x10000000) | ((immediate & 3u) << 29) | (((immediate >> 2) & UINT32_C(0x7ffff)) << 5) | destination;
    }

    return result;
}

// Exactly how many words link_aarch64_build_elf_entry_stub emits: the
// argument sequence, the registration of the destructor runner where the
// hosted shape defers it, the copies back into x0-x2, four words per
// constructor, one branch per destructor with the status save and restore
// around them where they are still inline, the tail, the trap, and the
// runner's own frame and branches past it.  Both the builder's own bound and
// the slot the AArch64 dynamic writer overlays are taken from here, so
// neither can drift from what is emitted.
BUSTER_GLOBAL_LOCAL u32 link_aarch64_elf_entry_stub_words(bool hosted, LinkInitializerPlan const* plan)
{
    u32 constructor_count = plan ? plan->constructor_count : 0;
    u32 destructor_count = plan ? plan->destructor_count : 0;
    bool registered = hosted || constructor_count || destructor_count;
    bool deferred = link_initializer_plan_defers_destructors(hosted, plan);
    u32 inline_destructors = destructor_count && !deferred ? destructor_count + 2 : 0u;
    u32 runner = deferred ? destructor_count + 4 : 0u;
    return 4 + (hosted ? 4u : 0u) + (deferred ? 4u : 0u) + (registered ? 3u : 0u) + constructor_count * 4 + 1 + inline_destructors + (hosted ? 1u : 2u) + 1 + runner;
}

// The AArch64 spelling of the same stub, in whole words.  `ORR Xd, XZR, Xm`
// is how A64 writes a register move; the argc/argv/envp sequence and the trap
// are the ones this writer has always emitted.  Every branch is laid down as
// a bare `bl #0` and its word index is reported, because the callers patch
// displacements through link_aarch64_branch_encode after the layout settles
// -- exactly what the call to `main` already needed.  A capacity short of
// what the shape needs writes nothing and reports zero words.
BUSTER_GLOBAL_LOCAL u32 link_aarch64_build_elf_entry_stub(u32* words, u32 capacity, bool hosted, LinkInitializerPlan const* plan, u32* entry_word,
                                                          u32* exit_word, u32* atexit_word, u32* loader_atexit_word, u32* initializer_words)
{
    u32 count = 0;
    u32 constructor_count = plan ? plan->constructor_count : 0;
    u32 destructor_count = plan ? plan->destructor_count : 0;
    bool registered = hosted || constructor_count || destructor_count;
    bool deferred = link_initializer_plan_defers_destructors(hosted, plan);
    bool valid = true;
    u32 runner_adr_word = 0;
    // x19, x20 and x21 hold argc, argv and envp across the initializer calls;
    // x0, x1 and x2 are where the original shape leaves them for `main`.
    u32 argc_register = registered ? 19u : 0u;
    u32 argv_register = registered ? 20u : 1u;
    u32 envp_register = registered ? 21u : 2u;
    u32 initializer_index = 0;
    if (capacity >= link_aarch64_elf_entry_stub_words(hosted, plan))
    {
        words[count++] = 0xf94003e0u | argc_register;
        words[count++] = 0x910023e0u | argv_register;
        words[count++] = 0x8b000000u | (argc_register << 16) | (3u << 10) | (argv_register << 5) | envp_register;
        words[count++] = 0x91002000u | (envp_register << 5) | envp_register;
        if (hosted)
        {
            // X0 still holds the loader finalizer: the argument reads above
            // use X19-X21. Skip a null finalizer, then __cxa_atexit(X0, 0, 0).
            words[count++] = 0xb4000080u;
            words[count++] = 0xd2800001u;
            words[count++] = 0xd2800002u;
            if (loader_atexit_word) *loader_atexit_word = count;
            words[count++] = 0x94000000u;
        }
        if (deferred)
        {
            // __cxa_atexit(runner, 0, 0).  The runner's address is an ADR
            // away, patched once the words past the trap have been counted.
            runner_adr_word = count;
            words[count++] = 0;
            words[count++] = 0xd2800001u;
            words[count++] = 0xd2800002u;
            if (atexit_word) *atexit_word = count;
            words[count++] = 0x94000000u;
        }
        for (u32 constructor = 0; constructor < constructor_count; constructor += 1)
        {
            words[count++] = 0xaa0003e0u | (argc_register << 16);
            words[count++] = 0xaa0003e0u | (argv_register << 16) | 1u;
            words[count++] = 0xaa0003e0u | (envp_register << 16) | 2u;
            if (initializer_words) initializer_words[initializer_index] = count;
            initializer_index += 1;
            words[count++] = 0x94000000u;
        }
        if (registered)
        {
            words[count++] = 0xaa0003e0u | (argc_register << 16);
            words[count++] = 0xaa0003e0u | (argv_register << 16) | 1u;
            words[count++] = 0xaa0003e0u | (envp_register << 16) | 2u;
        }
        if (entry_word) *entry_word = count;
        words[count++] = 0x94000000u;
        if (destructor_count && !deferred)
        {
            // main's status parked in w19 across the destructors, which take no
            // arguments, and put back where `exit` and the syscall both want it.
            words[count++] = 0x2a0003f3u;
            for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
            {
                if (initializer_words) initializer_words[initializer_index] = count;
                initializer_index += 1;
                words[count++] = 0x94000000u;
            }
            words[count++] = 0x2a1303e0u;
        }
        if (hosted)
        {
            if (exit_word) *exit_word = count;
            words[count++] = 0x94000000u;
        }
        else
        {
            words[count++] = 0xd2800ba8u;
            words[count++] = 0xd4000001u;
        }
        words[count++] = 0xd4200000u;
        if (deferred)
        {
            // The runner, past the trap: a frame the destructors' own calls
            // can return through, one `bl` each, and a return to whatever the
            // C runtime called it from.
            words[runner_adr_word] = link_aarch64_adr(0, ((s64)count - (s64)runner_adr_word) * (s64)sizeof(u32), &valid);
            words[count++] = 0xa9bf7bfdu;
            words[count++] = 0x910003fdu;
            for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
            {
                if (initializer_words) initializer_words[initializer_index] = count;
                initializer_index += 1;
                words[count++] = 0x94000000u;
            }
            words[count++] = 0xa8c17bfdu;
            words[count++] = 0xd65f03c0u;
        }
        if (!valid)
        {
            count = 0;
        }
    }

    return count;
}

// The AArch64 dynamic writer overlays the x86-64 writer's image. Reserve
// whichever complete startup shape is larger: their registration, constructor
// and destructor sequences have different fixed and per-entry sizes.
BUSTER_GLOBAL_LOCAL u32 link_elf_entry_stub_slot(u32 x86_stub_size, LinkInitializerPlan const* plan)
{
    u32 aarch64_size = link_aarch64_elf_entry_stub_words(true, plan) * (u32)sizeof(u32);
    return x86_stub_size > aarch64_size ? x86_stub_size : aarch64_size;
}

// The PE entry stub.  Its initializers are called straight after the prologue,
// before the argv machinery runs, and they are called with no arguments: the
// Windows convention for an initializer is MSVC's `.CRT$XCU` one, which takes
// none, and there is no argc or argv to hand over at that point anyway.  That
// is the one way this differs from the ELF stub above.  The prologue is left
// exactly as it was because the unwind record beside it describes that and
// nothing else; `sub rsp, 0x38` also leaves the stack aligned and reserves
// more than the 32 bytes of home space a callee may write.  Every displacement
// field is reported rather than counted by the caller, because inserting a
// call moves all of them.
//
// A PE link is always hosted, so its destructors are always registered rather
// than called after `main` (link_initializer_plan_defers_destructors), and
// the runner sits past the trap in this same buffer.  The runner opens with
// the same `sub rsp, 0x38` the stub does, at the same offset from its own
// start, so the one unwind record the writer lays down over both ranges
// describes the frame at either address: unwinding out of a destructor pops
// the runner's frame rather than a frame it never built.
BUSTER_GLOBAL_LOCAL bool link_x86_build_pe_entry_stub(u8* bytes, u32 capacity, u32* byte_count, LinkInitializerPlan const* plan,
                                                      u32* startup_displacement_offsets, u32* main_displacement_offset, u32* exit_displacement_offset,
                                                      u32* atexit_displacement_offset, u32* initializer_displacement_offsets)
{
    LinkX86InstructionBuilder builder = {.bytes = bytes, .capacity = capacity};
    BusterX86MetadataPhysicalOperand operands[2] = {0};
    u32 constructor_count = plan ? plan->constructor_count : 0;
    u32 destructor_count = plan ? plan->destructor_count : 0;
    bool deferred_destructors = link_initializer_plan_defers_destructors(true, plan);
    u32 initializer_index = 0;
    u32 runner_displacement_field = 0;
    operands[0] = link_x86_register(4, 64);
    operands[1] = link_x86_immediate(0x38, 8);
    if (!link_x86_emit(&builder, S8("SUB"), operands, 2)) return false;
    if (deferred_destructors)
    {
        // _crt_atexit(runner).  Its one argument rides rcx, and the runner's
        // address is a rip-relative LEA whose displacement is the last four
        // bytes of the instruction whatever prefixes precede it.
        operands[0] = link_x86_register(1, 64);
        operands[1] = link_x86_memory_rip(64, 0);
        if (!link_x86_emit(&builder, S8("LEA"), operands, 2) || builder.count < 4) return false;
        runner_displacement_field = builder.count - 4;
        BusterX86MetadataPhysicalOperand atexit_indirect = link_x86_memory_rip(64, 0);
        if (atexit_displacement_offset) *atexit_displacement_offset = builder.count + 2;
        if (!link_x86_emit(&builder, S8("CALL"), &atexit_indirect, 1)) return false;
    }
    for (u32 constructor = 0; constructor < constructor_count; constructor += 1)
    {
        if (initializer_displacement_offsets) initializer_displacement_offsets[initializer_index] = builder.count + 1;
        initializer_index += 1;
        operands[0] = link_x86_relative(0, 32);
        if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    }
    operands[0] = link_x86_register(1, 32);
    operands[1] = link_x86_register(1, 32);
    if (!link_x86_emit(&builder, S8("XOR"), operands, 2)) return false;
    operands[0] = link_x86_register(1, 32);
    if (!link_x86_emit(&builder, S8("INC"), operands, 1)) return false;
    BusterX86MetadataPhysicalOperand indirect = link_x86_memory_rip(64, 0);
    if (startup_displacement_offsets) startup_displacement_offsets[0] = builder.count + 2;
    if (!link_x86_emit(&builder, S8("CALL"), &indirect, 1)) return false;
    if (startup_displacement_offsets) startup_displacement_offsets[1] = builder.count + 2;
    if (!link_x86_emit(&builder, S8("CALL"), &indirect, 1)) return false;
    operands[0] = link_x86_register(0, 32);
    operands[1] = link_x86_memory_base(0, 32, 0);
    if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    operands[0] = link_x86_memory_base(4, 32, 0x20);
    operands[1] = link_x86_register(0, 32);
    if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    if (startup_displacement_offsets) startup_displacement_offsets[2] = builder.count + 2;
    if (!link_x86_emit(&builder, S8("CALL"), &indirect, 1)) return false;
    operands[0] = link_x86_register(2, 64);
    operands[1] = link_x86_memory_base(0, 64, 0);
    if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    operands[0] = link_x86_register(1, 32);
    operands[1] = link_x86_memory_base(4, 32, 0x20);
    if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    if (main_displacement_offset) *main_displacement_offset = builder.count + 1;
    operands[0] = link_x86_relative(0, 32);
    if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    operands[0] = link_x86_register(1, 32);
    operands[1] = link_x86_register(0, 32);
    if (!link_x86_emit(&builder, S8("MOV"), operands, 2)) return false;
    if (exit_displacement_offset) *exit_displacement_offset = builder.count + 2;
    if (!link_x86_emit(&builder, S8("CALL"), &indirect, 1) || !link_x86_emit_zero(&builder, S8("INT3"))) return false;
    if (deferred_destructors)
    {
        link_write_u32(builder.bytes, runner_displacement_field, (u32)(builder.count - (runner_displacement_field + 4)));
        operands[0] = link_x86_register(4, 64);
        operands[1] = link_x86_immediate(0x38, 8);
        if (!link_x86_emit(&builder, S8("SUB"), operands, 2)) return false;
        for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
        {
            if (initializer_displacement_offsets) initializer_displacement_offsets[initializer_index] = builder.count + 1;
            initializer_index += 1;
            operands[0] = link_x86_relative(0, 32);
            if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
        }
        operands[0] = link_x86_register(4, 64);
        operands[1] = link_x86_immediate(0x38, 8);
        if (!link_x86_emit(&builder, S8("ADD"), operands, 2)) return false;
        if (!link_x86_emit_zero(&builder, S8("RET"))) return false;
    }
    if (byte_count) *byte_count = builder.count;
    return constructor_count || destructor_count || builder.count == 53;
}

// The PE stub's buffer: five bytes per initializer call plus the four the
// destructor status save and restore add, over the 53-byte base.  The base
// also carries the registration call and the runner's frame and return,
// which the deferred shape adds once.
BUSTER_GLOBAL_LOCAL u32 link_x86_pe_entry_stub_capacity(LinkInitializerPlan const* plan)
{
    u32 count = plan ? plan->constructor_count + plan->destructor_count : 0;
    return 96 + 8 * count;
}

// The AArch64 PE stub, in whole words: the frame the unwind record describes,
// the registration of the destructor runner, the initializer branches,
// `bl main`, `bl exit`, a trap, and the runner past it.  Like the x86-64
// shape above, initializers take no arguments here.
BUSTER_GLOBAL_LOCAL u32 link_aarch64_pe_entry_stub_words(LinkInitializerPlan const* plan)
{
    u32 constructor_count = plan ? plan->constructor_count : 0;
    u32 destructor_count = plan ? plan->destructor_count : 0;
    bool deferred = link_initializer_plan_defers_destructors(true, plan);
    // Two saved-register pairs, optional destructor registration, the
    // constructors, UCRT argv setup, main/exit, and the trap. A deferred
    // destructor runner has the same two-pair frame and restores both pairs.
    return 12 + constructor_count + (deferred ? 7u + destructor_count : 0u);
}

BUSTER_GLOBAL_LOCAL u32 link_aarch64_build_pe_entry_stub(u32* words, u32 capacity, LinkInitializerPlan const* plan, u32* entry_word, u32* exit_word,
                                                         u32* atexit_word, u32* startup_words, u32* initializer_words, u32* runner_word)
{
    u32 count = 0;
    u32 constructor_count = plan ? plan->constructor_count : 0;
    u32 destructor_count = plan ? plan->destructor_count : 0;
    bool deferred = link_initializer_plan_defers_destructors(true, plan);
    bool valid = true;
    u32 runner_adr_word = 0;
    u32 initializer_index = 0;
    if (capacity >= link_aarch64_pe_entry_stub_words(plan))
    {
        // Preserve x19 across the UCRT queries so argc survives the argv
        // query. The pair shapes also have compact, exact ARM64 unwind codes.
        words[count++] = 0xa9bf53f3u;
        words[count++] = 0xa9bf7bfdu;
        if (deferred)
        {
            // _crt_atexit(runner): one argument, in x0.
            runner_adr_word = count;
            words[count++] = 0;
            if (atexit_word) *atexit_word = count;
            words[count++] = 0x94000000u;
        }
        for (u32 constructor = 0; constructor < constructor_count; constructor += 1)
        {
            if (initializer_words) initializer_words[initializer_index] = count;
            initializer_index += 1;
            words[count++] = 0x94000000u;
        }
        // UCRT owns the process command-line conversion. Configure narrow
        // argv, obtain argc and argv through its stable accessor exports, and
        // only then enter the C program with the platform ABI registers.
        words[count++] = 0x52800020u;
        if (startup_words) startup_words[0] = count;
        words[count++] = 0x94000000u;
        if (startup_words) startup_words[1] = count;
        words[count++] = 0x94000000u;
        words[count++] = 0xb9400013u;
        if (startup_words) startup_words[2] = count;
        words[count++] = 0x94000000u;
        words[count++] = 0xf9400001u;
        words[count++] = 0x2a1303e0u;
        if (entry_word) *entry_word = count;
        words[count++] = 0x94000000u;
        if (exit_word) *exit_word = count;
        words[count++] = 0x94000000u;
        words[count++] = 0xd4200000u;
        if (deferred)
        {
            words[runner_adr_word] = link_aarch64_adr(0, ((s64)count - (s64)runner_adr_word) * (s64)sizeof(u32), &valid);
            if (runner_word) *runner_word = count;
            words[count++] = 0xa9bf53f3u;
            words[count++] = 0xa9bf7bfdu;
            for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
            {
                if (initializer_words) initializer_words[initializer_index] = count;
                initializer_index += 1;
                words[count++] = 0x94000000u;
            }
            words[count++] = 0xa8c17bfdu;
            words[count++] = 0xa8c153f3u;
            words[count++] = 0xd65f03c0u;
        }
        if (!valid)
        {
            count = 0;
        }
    }

    return count;
}

typedef struct LinkGlobalSymbolTable LinkGlobalSymbolTable;
struct LinkGlobalSymbolTable
{
    ObjectSymbol* symbols;
    u32* slots;
    u64 capacity;
};

BUSTER_GLOBAL_LOCAL bool link_global_symbol_table_initialize(Arena* arena, ObjectSymbol* symbols, u64 total_symbols, LinkGlobalSymbolTable* table)
{
    *table = (LinkGlobalSymbolTable){.symbols = symbols};
    if (total_symbols)
    {
        if (total_symbols > UINT64_MAX / 2)
        {
            return false;
        }
        u64 required_capacity = total_symbols * 2;
        u64 capacity = 1;
        while (capacity < required_capacity)
        {
            if (capacity > UINT64_MAX / 2)
            {
                return false;
            }
            capacity *= 2;
        }
        if (capacity > UINT64_MAX / sizeof(*table->slots))
        {
            return false;
        }
        table->slots = arena_allocate(arena, u32, capacity);
        table->capacity = capacity;
        memset(table->slots, 0xff, sizeof(*table->slots) * capacity);
    }

    return true;
}

BUSTER_GLOBAL_LOCAL u32* link_global_symbol_table_slot(LinkGlobalSymbolTable* table, String8 name)
{
    if (table->capacity)
    {
        u64 mask = table->capacity - 1;
        u64 slot_index = buster_hash_64((u8*)name.pointer, name.length) & mask;
        for (u64 probe = 0; probe < table->capacity; probe += 1)
        {
            u32* slot = table->slots + slot_index;
            if (*slot == UINT32_MAX || string_equal(table->symbols[*slot].name, name))
            {
                return slot;
            }
            slot_index = (slot_index + 1) & mask;
        }
    }

    return 0;
}

// PE assigns each undefined symbol to the first dynamic library that exports
// it, falling back to the runtime export list only when no library does. Build
// that ordered relation once instead of rescanning every export list for every
// import.
typedef struct LinkPeExportSlot LinkPeExportSlot;
struct LinkPeExportSlot
{
    String8 name;
    u32 group;
    bool used;
    u8 reserved[3];
};

typedef struct LinkPeExportIndex LinkPeExportIndex;
struct LinkPeExportIndex
{
    LinkPeExportSlot* slots;
    u64 capacity;
};

enum
{
    LINK_PE_EXPORT_INDEX_MIN_QUERY_COUNT = 8,
};

BUSTER_GLOBAL_LOCAL LinkPeExportSlot* link_pe_export_slot(LinkPeExportIndex* table, String8 name)
{
    if (table->capacity)
    {
        u64 mask = table->capacity - 1;
        u64 slot_index = buster_hash_64((u8*)name.pointer, name.length) & mask;
        for (u64 probe = 0; probe < table->capacity; probe += 1)
        {
            LinkPeExportSlot* slot = table->slots + slot_index;
            if (!slot->used || string_equal(slot->name, name))
            {
                return slot;
            }
            slot_index = (slot_index + 1) & mask;
        }
    }

    return 0;
}

BUSTER_GLOBAL_LOCAL bool link_pe_export_insert(LinkPeExportIndex* table, String8 name, u32 group)
{
    if (name.length && !name.pointer)
    {
        return false;
    }
    LinkPeExportSlot* slot = link_pe_export_slot(table, name);
    if (!slot)
    {
        return false;
    }
    if (!slot->used)
    {
        slot->name = name;
        slot->group = group;
        slot->used = true;
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool link_pe_export_index_initialize(Arena* arena, NativeExecutableLinkOptions options, LinkPeExportIndex* table)
{
    *table = (LinkPeExportIndex){0};
    u64 export_count = options.runtime_exported_symbol_count;
    for (u32 library_index = 0; library_index < options.dynamic_library_count; library_index += 1)
    {
        NativeDynamicLibrary* library = options.dynamic_libraries + library_index;
        if ((library->exported_symbol_count && !library->exported_symbols) || library->exported_symbol_count > UINT64_MAX - export_count)
        {
            return false;
        }
        export_count += library->exported_symbol_count;
    }
    if (export_count)
    {
        if (export_count > UINT64_MAX / 2)
        {
            return false;
        }
        u64 required_capacity = export_count * 2;
        u64 capacity = 1;
        while (capacity < required_capacity)
        {
            if (capacity > UINT64_MAX / 2)
            {
                return false;
            }
            capacity *= 2;
        }
        if (capacity > UINT64_MAX / sizeof(*table->slots))
        {
            return false;
        }
        table->slots = arena_allocate(arena, LinkPeExportSlot, capacity);
        table->capacity = capacity;
        memset(table->slots, 0, sizeof(*table->slots) * capacity);
        for (u32 library_index = 0; library_index < options.dynamic_library_count; library_index += 1)
        {
            NativeDynamicLibrary* library = options.dynamic_libraries + library_index;
            for (u32 export_index = 0; export_index < library->exported_symbol_count; export_index += 1)
            {
                if (!link_pe_export_insert(table, library->exported_symbols[export_index], library_index + 1))
                {
                    return false;
                }
            }
        }
        for (u32 export_index = 0; export_index < options.runtime_exported_symbol_count; export_index += 1)
        {
            if (!link_pe_export_insert(table, options.runtime_exported_symbols[export_index], 0))
            {
                return false;
            }
        }
    }

    return true;
}

BUSTER_GLOBAL_LOCAL u32 link_pe_export_group(LinkPeExportIndex* table, String8 name)
{
    LinkPeExportSlot* slot = link_pe_export_slot(table, name);
    return slot && slot->used ? slot->group : UINT32_MAX;
}

BUSTER_GLOBAL_LOCAL u32 link_pe_export_group_scalar(NativeExecutableLinkOptions options, String8 name)
{
    for (u32 library_index = 0; library_index < options.dynamic_library_count; library_index += 1)
    {
        NativeDynamicLibrary* library = options.dynamic_libraries + library_index;
        for (u32 export_index = 0; export_index < library->exported_symbol_count; export_index += 1)
        {
            if (string_equal(name, library->exported_symbols[export_index]))
            {
                return library_index + 1;
            }
        }
    }
    for (u32 export_index = 0; export_index < options.runtime_exported_symbol_count; export_index += 1)
    {
        if (string_equal(name, options.runtime_exported_symbols[export_index]))
        {
            return 0;
        }
    }
    return UINT32_MAX;
}


typedef enum LinkComdatState
{
    LINK_COMDAT_STATE_UNKNOWN,
    LINK_COMDAT_STATE_KEEP,
    LINK_COMDAT_STATE_DISCARD,
} LinkComdatState;

typedef struct LinkComdatPlan LinkComdatPlan;
struct LinkComdatPlan
{
    u64* object_offsets;
    u8* states;
    u64 count;
};

typedef struct LinkComdatGroup LinkComdatGroup;
struct LinkComdatGroup
{
    String8 key;
    u32 object_index;
    u32 comdat_index;
    ObjectComdatSelection selection;
};

typedef struct LinkComdatTable LinkComdatTable;
struct LinkComdatTable
{
    LinkComdatGroup* groups;
    u32* slots;
    u64 capacity;
    u32 count;
};

BUSTER_GLOBAL_LOCAL bool link_comdat_table_initialize(Arena* arena, u64 count, LinkComdatTable* table)
{
    bool result = table != 0;
    if (result)
    {
        *table = (LinkComdatTable){0};
        if (count)
        {
            result = count <= UINT64_MAX / 2;
            u64 capacity = 1;
            u64 required = result ? count * 2 : 0;
            while (result && capacity < required)
            {
                result = capacity <= UINT64_MAX / 2;
                if (result)
                {
                    capacity *= 2;
                }
            }
            result = result && capacity <= UINT64_MAX / sizeof(*table->slots) && count <= UINT64_MAX / sizeof(*table->groups);
            if (result)
            {
                table->groups = arena_allocate(arena, LinkComdatGroup, count);
                table->slots = arena_allocate(arena, u32, capacity);
                table->capacity = capacity;
                memset(table->slots, 0xff, capacity * sizeof(*table->slots));
            }
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL u32* link_comdat_table_slot(LinkComdatTable* table, String8 key)
{
    u32* result = 0;
    if (table && table->capacity)
    {
        u64 mask = table->capacity - 1;
        u64 slot_index = buster_hash_64((u8*)key.pointer, key.length) & mask;
        for (u64 probe = 0; !result && probe < table->capacity; probe += 1)
        {
            u32* slot = table->slots + slot_index;
            if (*slot == UINT32_MAX || string_equal(table->groups[*slot].key, key))
            {
                result = slot;
            }
            slot_index = (slot_index + 1) & mask;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL s32 link_comdat_string_compare(String8 left, String8 right)
{
    u64 length = BUSTER_MIN(left.length, right.length);
    s32 result = length ? (s32)memcmp(left.pointer, right.pointer, length) : 0;
    if (!result && left.length != right.length)
    {
        result = left.length < right.length ? -1 : 1;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL u8 link_comdat_byte(ObjectFile* object, ObjectComdat* comdat, u64 index)
{
    ObjectSection* section = object->sections + comdat->section;
    u64 offset = comdat->offset + index;
    return offset < section->data.length ? section->data.pointer[offset] : 0;
}

BUSTER_GLOBAL_LOCAL bool link_comdat_symbol_inside(ObjectSymbol* symbol, ObjectComdat* comdat)
{
    bool result = symbol->section == comdat->section && symbol->value >= comdat->offset;
    if (result)
    {
        u64 relative = symbol->value - comdat->offset;
        result = relative <= comdat->size;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL s32 link_comdat_symbol_identity_compare(ObjectFile* left_object, ObjectComdat* left_comdat, u32 left_index,
                                                            ObjectFile* right_object, ObjectComdat* right_comdat, u32 right_index)
{
    s32 result = 0;
    if (left_index >= left_object->symbol_count || right_index >= right_object->symbol_count)
    {
        result = left_index < right_index ? -1 : left_index != right_index;
    }
    else
    {
        ObjectSymbol* left = left_object->symbols + left_index;
        ObjectSymbol* right = right_object->symbols + right_index;
        bool left_inside = !left->global && left->section != OBJECT_SECTION_UNDEFINED && link_comdat_symbol_inside(left, left_comdat);
        bool right_inside = !right->global && right->section != OBJECT_SECTION_UNDEFINED && link_comdat_symbol_inside(right, right_comdat);
        if (left_inside && right_inside)
        {
            u64 left_relative = left->value - left_comdat->offset;
            u64 right_relative = right->value - right_comdat->offset;
            if (left->kind != right->kind)
            {
                result = left->kind < right->kind ? -1 : 1;
            }
            else if (left_relative != right_relative)
            {
                result = left_relative < right_relative ? -1 : 1;
            }
            else if (left->size != right->size)
            {
                result = left->size < right->size ? -1 : 1;
            }
        }
        else
        {
            result = link_comdat_string_compare(left->name, right->name);
            if (!result && left->global != right->global)
            {
                result = left->global ? 1 : -1;
            }
            if (!result && left->kind != right->kind)
            {
                result = left->kind < right->kind ? -1 : 1;
            }
            bool left_defined = left->section != OBJECT_SECTION_UNDEFINED;
            bool right_defined = right->section != OBJECT_SECTION_UNDEFINED;
            if (!result && left_defined != right_defined)
            {
                result = left_defined ? 1 : -1;
            }
            if (!result && left_defined)
            {
                ObjectSectionKind left_kind = left_object->sections[left->section].kind;
                ObjectSectionKind right_kind = right_object->sections[right->section].kind;
                if (left_kind != right_kind)
                {
                    result = left_kind < right_kind ? -1 : 1;
                }
                else if (left->value != right->value)
                {
                    result = left->value < right->value ? -1 : 1;
                }
            }
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL s32 link_comdat_identity_compare(ObjectFile* left_object, ObjectComdat* left,
                                                     ObjectFile* right_object, ObjectComdat* right)
{
    s32 result = 0;
    u64 shared_size = BUSTER_MIN(left->size, right->size);
    ObjectSection* left_section = left_object->sections + left->section;
    ObjectSection* right_section = right_object->sections + right->section;
    if (left->offset <= left_section->data.length && right->offset <= right_section->data.length &&
        shared_size <= left_section->data.length - left->offset && shared_size <= right_section->data.length - right->offset)
    {
        result = shared_size ? (s32)memcmp(left_section->data.pointer + left->offset, right_section->data.pointer + right->offset, shared_size) : 0;
    }
    else
    {
        for (u64 index = 0; !result && index < shared_size; index += 1)
        {
            u8 left_byte = link_comdat_byte(left_object, left, index);
            u8 right_byte = link_comdat_byte(right_object, right, index);
            if (left_byte != right_byte)
            {
                result = left_byte < right_byte ? -1 : 1;
            }
        }
    }
    if (!result && left->size != right->size)
    {
        result = left->size < right->size ? -1 : 1;
    }
    u32 shared_relocations = BUSTER_MIN(left->relocation_count, right->relocation_count);
    for (u32 index = 0; !result && index < shared_relocations; index += 1)
    {
        ObjectRelocation* left_relocation = left_object->relocations + left->first_relocation + index;
        ObjectRelocation* right_relocation = right_object->relocations + right->first_relocation + index;
        u64 left_offset = left_relocation->offset - left->offset;
        u64 right_offset = right_relocation->offset - right->offset;
        if (left_offset != right_offset)
        {
            result = left_offset < right_offset ? -1 : 1;
        }
        else if (left_relocation->kind != right_relocation->kind)
        {
            result = left_relocation->kind < right_relocation->kind ? -1 : 1;
        }
        else if (left_relocation->addend != right_relocation->addend)
        {
            result = left_relocation->addend < right_relocation->addend ? -1 : 1;
        }
        else
        {
            result = link_comdat_symbol_identity_compare(left_object, left, left_relocation->symbol,
                                                         right_object, right, right_relocation->symbol);
        }
    }
    if (!result && left->relocation_count != right->relocation_count)
    {
        result = left->relocation_count < right->relocation_count ? -1 : 1;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool link_comdat_record_valid(ObjectFile* object, u32 index)
{
    bool result = object && index < object->comdat_count;
    if (result)
    {
        ObjectComdat* comdat = object->comdats + index;
        result = comdat->selection < OBJECT_COMDAT_SELECTION_COUNT && comdat->section < object->section_count;
        if (result)
        {
            ObjectSection* section = object->sections + comdat->section;
            u64 size = BUSTER_MAX(section->data.length, section->virtual_size);
            result = comdat->offset <= size && comdat->size <= size - comdat->offset &&
                     comdat->first_relocation <= object->relocation_count &&
                     comdat->relocation_count <= object->relocation_count - comdat->first_relocation;
        }
        if (result && comdat->selection != OBJECT_COMDAT_SELECTION_NONE &&
            comdat->selection != OBJECT_COMDAT_SELECTION_ASSOCIATIVE)
        {
            result = comdat->key.length && comdat->key.pointer;
        }
        if (result && comdat->selection == OBJECT_COMDAT_SELECTION_ASSOCIATIVE)
        {
            result = comdat->associated < object->comdat_count && comdat->associated != index;
        }
        for (u32 relocation_index = 0; result && relocation_index < comdat->relocation_count; relocation_index += 1)
        {
            ObjectRelocation* relocation = object->relocations + comdat->first_relocation + relocation_index;
            result = relocation->comdat == index + 1 && relocation->section == comdat->section &&
                     relocation->offset >= comdat->offset && relocation->offset - comdat->offset < comdat->size &&
                     relocation->symbol < object->symbol_count;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL LinkError link_comdat_plan_build(Arena* arena, ObjectFile* objects, u32 object_count,
                                                     LinkComdatPlan* plan, String8* error_symbol)
{
    LinkError error = LINK_ERROR_NONE;
    *plan = (LinkComdatPlan){0};
    *error_symbol = (String8){0};
    plan->object_offsets = arena_allocate(arena, u64, (u64)object_count + 1);
    for (u32 object_index = 0; object_index < object_count && error == LINK_ERROR_NONE; object_index += 1)
    {
        plan->object_offsets[object_index] = plan->count;
        if (objects[object_index].comdat_count > UINT64_MAX - plan->count)
        {
            error = LINK_ERROR_INVALID_INPUT;
        }
        else
        {
            plan->count += objects[object_index].comdat_count;
        }
    }
    plan->object_offsets[object_count] = plan->count;
    if (error == LINK_ERROR_NONE)
    {
        plan->states = arena_allocate(arena, u8, plan->count ? plan->count : 1);
        memset(plan->states, LINK_COMDAT_STATE_UNKNOWN, plan->count);
        LinkComdatTable table = {0};
        if (!link_comdat_table_initialize(arena, plan->count, &table))
        {
            error = LINK_ERROR_INVALID_INPUT;
        }
        for (u32 object_index = 0; object_index < object_count && error == LINK_ERROR_NONE; object_index += 1)
        {
            ObjectFile* object = objects + object_index;
            u64 base = plan->object_offsets[object_index];
            for (u32 comdat_index = 0; comdat_index < object->comdat_count && error == LINK_ERROR_NONE; comdat_index += 1)
            {
                ObjectComdat* comdat = object->comdats + comdat_index;
                u64 state_index = base + comdat_index;
                if (!link_comdat_record_valid(object, comdat_index))
                {
                    error = LINK_ERROR_INVALID_INPUT;
                }
                else if (comdat->selection == OBJECT_COMDAT_SELECTION_NONE)
                {
                    plan->states[state_index] = LINK_COMDAT_STATE_KEEP;
                }
                else if (comdat->selection != OBJECT_COMDAT_SELECTION_ASSOCIATIVE)
                {
                    u32* slot = link_comdat_table_slot(&table, comdat->key);
                    if (!slot)
                    {
                        error = LINK_ERROR_INVALID_INPUT;
                    }
                    else if (*slot == UINT32_MAX)
                    {
                        u32 group_index = table.count++;
                        *slot = group_index;
                        table.groups[group_index] = (LinkComdatGroup){
                            .key = comdat->key,
                            .object_index = object_index,
                            .comdat_index = comdat_index,
                            .selection = comdat->selection,
                        };
                        plan->states[state_index] = LINK_COMDAT_STATE_KEEP;
                    }
                    else
                    {
                        LinkComdatGroup* group = table.groups + *slot;
                        ObjectFile* winner_object = objects + group->object_index;
                        ObjectComdat* winner = winner_object->comdats + group->comdat_index;
                        u64 winner_state = plan->object_offsets[group->object_index] + group->comdat_index;
                        *error_symbol = comdat->key;
                        if (group->selection != comdat->selection)
                        {
                            error = LINK_ERROR_COMDAT_SELECTION_MISMATCH;
                        }
                        else if (comdat->selection == OBJECT_COMDAT_SELECTION_NO_DUPLICATES)
                        {
                            error = LINK_ERROR_DUPLICATE_SYMBOL;
                        }
                        else if (comdat->selection == OBJECT_COMDAT_SELECTION_SAME_SIZE && winner->size != comdat->size)
                        {
                            error = LINK_ERROR_COMDAT_SIZE_MISMATCH;
                        }
                        else if (comdat->selection == OBJECT_COMDAT_SELECTION_EXACT_MATCH &&
                                 link_comdat_identity_compare(winner_object, winner, object, comdat) != 0)
                        {
                            error = LINK_ERROR_COMDAT_EXACT_MATCH;
                        }
                        else
                        {
                            bool replace = comdat->selection == OBJECT_COMDAT_SELECTION_LARGEST &&
                                           (comdat->size > winner->size ||
                                            (comdat->size == winner->size &&
                                             link_comdat_identity_compare(object, comdat, winner_object, winner) > 0));
                            if (replace)
                            {
                                plan->states[winner_state] = LINK_COMDAT_STATE_DISCARD;
                                plan->states[state_index] = LINK_COMDAT_STATE_KEEP;
                                group->object_index = object_index;
                                group->comdat_index = comdat_index;
                            }
                            else
                            {
                                plan->states[state_index] = LINK_COMDAT_STATE_DISCARD;
                            }
                        }
                    }
                }
            }
        }
        bool progress = true;
        for (u64 pass = 0; error == LINK_ERROR_NONE && progress && pass < plan->count; pass += 1)
        {
            progress = false;
            for (u32 object_index = 0; object_index < object_count; object_index += 1)
            {
                ObjectFile* object = objects + object_index;
                u64 base = plan->object_offsets[object_index];
                for (u32 comdat_index = 0; comdat_index < object->comdat_count; comdat_index += 1)
                {
                    ObjectComdat* comdat = object->comdats + comdat_index;
                    u64 state_index = base + comdat_index;
                    if (comdat->selection == OBJECT_COMDAT_SELECTION_ASSOCIATIVE &&
                        plan->states[state_index] == LINK_COMDAT_STATE_UNKNOWN)
                    {
                        u8 parent = plan->states[base + comdat->associated];
                        if (parent != LINK_COMDAT_STATE_UNKNOWN)
                        {
                            plan->states[state_index] = parent;
                            progress = true;
                        }
                    }
                }
            }
        }
        for (u64 index = 0; error == LINK_ERROR_NONE && index < plan->count; index += 1)
        {
            if (plan->states[index] == LINK_COMDAT_STATE_UNKNOWN)
            {
                error = LINK_ERROR_INVALID_INPUT;
            }
        }
    }
    return error;
}

BUSTER_GLOBAL_LOCAL bool link_comdat_is_discarded(LinkComdatPlan* plan, u32 object_index, u32 comdat)
{
    bool result = false;
    if (comdat)
    {
        result = plan->states[plan->object_offsets[object_index] + comdat - 1] == LINK_COMDAT_STATE_DISCARD;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool link_symbol_definition_set(ObjectSymbol* destination, ObjectSymbol* source, ObjectFile* object, u64* section_offsets, Arena* arena)
{
    *destination = *source;
    destination->name = link_string_copy(arena, source->name);
    destination->comdat = 0;
    if (source->section != OBJECT_SECTION_UNDEFINED)
    {
        if (source->section >= object->section_count)
        {
            return false;
        }
        ObjectSectionKind kind = object->sections[source->section].kind;
        if (kind >= OBJECT_SECTION_COUNT)
        {
            return false;
        }
        destination->section = (u32)kind;
        destination->value += section_offsets[source->section];
    }

    return true;
}

BUSTER_GLOBAL_LOCAL u8 link_symbol_thread_local_state(ObjectFile* object, ObjectSymbol* symbol)
{
    u8 result = symbol->thread_local_state;
    if (result == OBJECT_SYMBOL_THREAD_LOCAL_UNKNOWN && symbol->section != OBJECT_SECTION_UNDEFINED && symbol->section < object->section_count)
    {
        ObjectSectionKind kind = object->sections[symbol->section].kind;
        result = kind == OBJECT_SECTION_THREAD_LOCAL_DATA || kind == OBJECT_SECTION_THREAD_LOCAL_ZERO ? OBJECT_SYMBOL_THREAD_LOCAL_YES
                                                                                                      : OBJECT_SYMBOL_THREAD_LOCAL_NO;
    }

    return result;
}

// GNU runs every prioritized initializer before every unprioritized one,
// ascending, across the *whole program* rather than within one translation
// unit, and `ld` gets that off the section name: every `.init_array.NNNNN`
// ahead of the unsuffixed `.init_array`.  A merge that concatenates each
// input's array in link order is that order only while no input names a
// priority, so this puts the merged arrays back in it -- a stable sort of the
// 8-byte entries by ObjectFile.initializer_priorities, which is where the
// name went (see object_read_elf64 and object_from_canonical_codegen_module).
//
// The sort moves an entry's relocation and any symbol that names it with the
// entry, because the relocation *is* the entry: the slot holds nothing until
// a writer fills it with the function's address.  It runs on the merged file
// rather than in link_initializer_plan_build so that every consumer of the
// arrays agrees -- the entry-stub writers read the plan, and the Mach-O
// writer keeps its initializer section and lets dyld walk it in the order it
// is laid out in, which is the consumer that has no plan to be sorted in.
// (issue 789)
BUSTER_GLOBAL_LOCAL void link_initializer_arrays_order(Arena* arena, ObjectFile* object)
{
    for (u32 slot = 0; slot < 2; slot += 1)
    {
        ObjectSectionKind kind = slot ? OBJECT_SECTION_FINI_ARRAY : OBJECT_SECTION_INIT_ARRAY;
        u32* priorities = object->initializer_priorities[slot];
        ObjectSection* section = object->sections + kind;
        u64 entries = priorities ? section->data.length / OBJECT_INITIALIZER_ENTRY_SIZE : 0;
        bool ordered = true;
        for (u64 entry = 1; entry < entries; entry += 1)
        {
            ordered = ordered && priorities[entry - 1] <= priorities[entry];
        }
        // A program whose initializers all named no priority, and one whose
        // inputs happen to have arrived in GNU's order already, are the
        // common shapes and cost nothing beyond the scan above.
        if (ordered)
        {
            continue;
        }
        TemporalArena temporary = scratch_begin(&arena, 1);
        u32* order = arena_allocate(temporary.arena, u32, entries);
        u8* bytes = arena_allocate(temporary.arena, u8, section->data.length);
        // Stable least-significant-byte radix passes keep reverse-priority
        // inputs linear. Forward scattering preserves link order for ties.
        // Reuse the inverse-permutation storage as the second index buffer;
        // sorting needs no additional allocation proportional to entries.
        u32* destination = arena_allocate(temporary.arena, u32, entries);
        for (u64 entry = 0; entry < entries; entry += 1)
        {
            order[entry] = (u32)entry;
        }
        enum { INITIALIZER_RADIX_BITS = 8, INITIALIZER_RADIX_BUCKETS = 1 << INITIALIZER_RADIX_BITS };
        for (u32 byte_index = 0; byte_index < sizeof(*priorities); byte_index += 1)
        {
            u64 offsets[INITIALIZER_RADIX_BUCKETS] = {0};
            u32 shift = byte_index * INITIALIZER_RADIX_BITS;
            for (u64 entry = 0; entry < entries; entry += 1)
            {
                u32 bucket = (priorities[order[entry]] >> shift) & (INITIALIZER_RADIX_BUCKETS - 1);
                offsets[bucket] += 1;
            }
            u64 offset = 0;
            for (u32 bucket = 0; bucket < INITIALIZER_RADIX_BUCKETS; bucket += 1)
            {
                u64 count = offsets[bucket];
                offsets[bucket] = offset;
                offset += count;
            }
            for (u64 entry = 0; entry < entries; entry += 1)
            {
                u32 bucket = (priorities[order[entry]] >> shift) & (INITIALIZER_RADIX_BUCKETS - 1);
                destination[offsets[bucket]++] = order[entry];
            }
            u32* swap = order;
            order = destination;
            destination = swap;
        }
        // The inverse permutation, which is what the relocations and the
        // symbols are rewritten through.
        for (u64 entry = 0; entry < entries; entry += 1)
        {
            memcpy(bytes + entry * OBJECT_INITIALIZER_ENTRY_SIZE, section->data.pointer + (u64)order[entry] * OBJECT_INITIALIZER_ENTRY_SIZE,
                   OBJECT_INITIALIZER_ENTRY_SIZE);
            destination[order[entry]] = (u32)entry;
        }
        memcpy(section->data.pointer, bytes, entries * OBJECT_INITIALIZER_ENTRY_SIZE);
        u32* sorted = arena_allocate(temporary.arena, u32, entries);
        for (u64 entry = 0; entry < entries; entry += 1)
        {
            sorted[entry] = priorities[order[entry]];
        }
        memcpy(priorities, sorted, entries * sizeof(*priorities));
        for (u32 index = 0; index < object->relocation_count; index += 1)
        {
            ObjectRelocation* relocation = object->relocations + index;
            u64 entry = relocation->offset / OBJECT_INITIALIZER_ENTRY_SIZE;
            if (relocation->section == (u32)kind && entry < entries)
            {
                relocation->offset = (u64)destination[entry] * OBJECT_INITIALIZER_ENTRY_SIZE + relocation->offset % OBJECT_INITIALIZER_ENTRY_SIZE;
            }
        }
        for (u32 index = 0; index < object->symbol_count; index += 1)
        {
            ObjectSymbol* symbol = object->symbols + index;
            u64 entry = symbol->value / OBJECT_INITIALIZER_ENTRY_SIZE;
            if (symbol->section == (u32)kind && entry < entries)
            {
                symbol->value = (u64)destination[entry] * OBJECT_INITIALIZER_ENTRY_SIZE + symbol->value % OBJECT_INITIALIZER_ENTRY_SIZE;
            }
        }
        scratch_end(temporary);
    }
}

LinkObjectResult link_objects(Arena* arena, ObjectFile* objects, u32 object_count, LinkOptions options)
{
    LinkObjectResult result = {0};
    if (!arena || !objects || !object_count)
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    Target target = objects[0].target;
    u64* section_sizes = arena_allocate(arena, u64, OBJECT_SECTION_COUNT);
    u32* section_alignments = arena_allocate(arena, u32, OBJECT_SECTION_COUNT);
    memset(section_sizes, 0, sizeof(*section_sizes) * OBJECT_SECTION_COUNT);
    memset(section_alignments, 0, sizeof(*section_alignments) * OBJECT_SECTION_COUNT);
    for (u32 kind = 0; kind < OBJECT_SECTION_COUNT; kind += 1)
    {
        section_alignments[kind] = object_section_default_alignment((ObjectSectionKind)kind);
    }
    u64 total_symbols = 0;
    u64 total_relocations = 0;
    u64 total_debug_modules = 0;
    u64 offset_count = (u64)object_count * OBJECT_SECTION_COUNT;
    u64* section_offsets = arena_allocate(arena, u64, offset_count);
    for (u32 object_index = 0; object_index < object_count; object_index += 1)
    {
        ObjectFile* object = &objects[object_index];
        if (object->error != OBJECT_ERROR_NONE || !object->sections || object->section_count > OBJECT_SECTION_COUNT ||
            (object->symbol_count && !object->symbols) || (object->relocation_count && !object->relocations) ||
            (object->comdat_count && !object->comdats) || (object->debug_module_count && !object->debug_modules))
        {
            result.error = LINK_ERROR_INVALID_INPUT;
            return result;
        }
        if (!link_target_matches(target, object->target))
        {
            result.error = LINK_ERROR_TARGET_MISMATCH;
            return result;
        }
        total_symbols += object->symbol_count;
        total_relocations += object->relocation_count;
        total_debug_modules += object->debug_module_count;
        if (total_symbols > UINT32_MAX || total_relocations > UINT32_MAX || total_debug_modules > UINT32_MAX)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
            return result;
        }
        for (u32 section_index = 0; section_index < object->section_count; section_index += 1)
        {
            ObjectSection* section = &object->sections[section_index];
            if (section->kind >= OBJECT_SECTION_COUNT || !section->alignment || !BUSTER_IS_POWER_OF_TWO(section->alignment) ||
                (section->data.length && !section->data.pointer))
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            u32 alignment = section->alignment;
            u64 section_size = BUSTER_MAX(section->data.length, section->virtual_size);
            u64 aligned = 0;
            if (!align_forward_checked(section_sizes[section->kind], alignment, &aligned) || section_size > UINT64_MAX - aligned)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            section_offsets[(u64)object_index * OBJECT_SECTION_COUNT + section_index] = aligned;
            section_sizes[section->kind] = aligned + section_size;
            section_alignments[section->kind] = BUSTER_MAX(section_alignments[section->kind], alignment);
        }
    }
    LinkComdatPlan comdat_plan = {0};
    String8 comdat_error_symbol = {0};
    LinkError comdat_error = link_comdat_plan_build(arena, objects, object_count, &comdat_plan, &comdat_error_symbol);
    if (comdat_error != LINK_ERROR_NONE)
    {
        result.error = comdat_error;
        result.symbol = link_string_copy(arena, comdat_error_symbol);
        return result;
    }
    // A one-input merge has no cross-object concatenation. Sharing a payload
    // is nevertheless an ownership opt-in, and remains unsafe when one kind
    // appears more than once, when a file-backed virtual tail needs zeroing,
    // or when initializer ordering would mutate the input bytes.
    ObjectSection* aliased_sections[OBJECT_SECTION_COUNT] = {0};
    bool alias_section_data[OBJECT_SECTION_COUNT] = {0};
    if (options.alias_single_input_sections && object_count == 1)
    {
        ObjectFile* object = objects;
        for (u32 section_index = 0; section_index < object->section_count; section_index += 1)
        {
            ObjectSection* section = object->sections + section_index;
            ObjectSectionKind kind = section->kind;
            if (!aliased_sections[kind])
            {
                aliased_sections[kind] = section;
                alias_section_data[kind] = !object_section_kind_is_zero_fill(kind) &&
                                           section_offsets[section_index] == 0 &&
                                           section->data.length == section_sizes[kind];
            }
            else
            {
                alias_section_data[kind] = false;
            }
        }
        for (u32 slot = 0; slot < 2; slot += 1)
        {
            ObjectSectionKind kind = slot ? OBJECT_SECTION_FINI_ARRAY : OBJECT_SECTION_INIT_ARRAY;
            u32* priorities = object->initializer_priorities[slot];
            ObjectSection* section = aliased_sections[kind];
            u64 entries = priorities && section ? section->data.length / OBJECT_INITIALIZER_ENTRY_SIZE : 0;
            for (u64 entry = 1; alias_section_data[kind] && entry < entries; entry += 1)
            {
                if (priorities[entry - 1] > priorities[entry])
                {
                    alias_section_data[kind] = false;
                }
            }
        }
    }
    result.object = (ObjectFile){
        .sections = arena_allocate(arena, ObjectSection, OBJECT_SECTION_COUNT),
        .symbols = arena_allocate(arena, ObjectSymbol, total_symbols),
        .relocations = arena_allocate(arena, ObjectRelocation, total_relocations),
        .target = target,
        .section_count = OBJECT_SECTION_COUNT,
        .debug_modules = arena_allocate(arena, ObjectDebugModule, total_debug_modules),
    };
    for (u32 kind = 0; kind < OBJECT_SECTION_COUNT; kind += 1)
    {
        bool zero_fill = object_section_kind_is_zero_fill((ObjectSectionKind)kind);
        // Source copies cover neither alignment gaps nor file-backed virtual
        // tails. Define those bytes even when the output arena is reused.
        u8* data = zero_fill ? 0
                             : alias_section_data[kind] ? aliased_sections[kind]->data.pointer
                                                        : arena_allocate_zeroed(arena, u8, section_sizes[kind]);
        result.object.sections[kind] = (ObjectSection){
            .name = object_section_name_for_kind((ObjectSectionKind)kind),
            .data =
                {
                    .pointer = data,
                    .length = zero_fill ? 0 : section_sizes[kind],
                },
            .virtual_size = section_sizes[kind],
            .kind = (ObjectSectionKind)kind,
            .alignment = section_alignments[kind],
        };
    }
    // One priority per merged initializer entry, filled beside the data below
    // and read by link_initializer_arrays_order once the merge is complete:
    // an input that states none, and every entry no input covered, is
    // unprioritized, which is where `ld` puts it -- last.
    for (u32 slot = 0; slot < 2; slot += 1)
    {
        ObjectSectionKind kind = slot ? OBJECT_SECTION_FINI_ARRAY : OBJECT_SECTION_INIT_ARRAY;
        u64 entries = section_sizes[kind] / OBJECT_INITIALIZER_ENTRY_SIZE;
        if (entries)
        {
            result.object.initializer_priorities[slot] = arena_allocate(arena, u32, entries);
            for (u64 entry = 0; entry < entries; entry += 1)
            {
                result.object.initializer_priorities[slot][entry] = IR_INITIALIZER_PRIORITY_NONE;
            }
        }
    }
    for (u32 object_index = 0; object_index < object_count; object_index += 1)
    {
        ObjectFile* object = objects + object_index;
        u64* offsets = section_offsets + (u64)object_index * OBJECT_SECTION_COUNT;
        for (u32 module_index = 0; module_index < object->debug_module_count; module_index += 1)
        {
            ObjectDebugModule source = object->debug_modules[module_index];
            ObjectDebugModule* destination = result.object.debug_modules + result.object.debug_module_count++;
            *destination = source;
            destination->name = link_string_copy(arena, source.name);
            destination->code_offset += offsets[OBJECT_SECTION_TEXT];
            destination->symbols_offset += offsets[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS];
            destination->types_offset += offsets[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES];
        }
    }
    for (u32 object_index = 0; object_index < object_count; object_index += 1)
    {
        ObjectFile* object = &objects[object_index];
        u64* offsets = section_offsets + (u64)object_index * OBJECT_SECTION_COUNT;
        for (u32 section_index = 0; section_index < object->section_count; section_index += 1)
        {
            ObjectSection* source = &object->sections[section_index];
            if (source->data.length && !alias_section_data[source->kind])
            {
                memcpy(result.object.sections[source->kind].data.pointer + offsets[section_index], source->data.pointer, source->data.length);
            }
            // The priorities of an initializer array travel with its entries.
            // An offset that is not a whole number of entries cannot name one,
            // and only an input section aligned under
            // OBJECT_INITIALIZER_ENTRY_SIZE could produce one.
            u32 slot = source->kind == OBJECT_SECTION_FINI_ARRAY;
            u32* merged = source->kind == OBJECT_SECTION_INIT_ARRAY || source->kind == OBJECT_SECTION_FINI_ARRAY
                              ? result.object.initializer_priorities[slot]
                              : 0;
            u32* priorities = merged ? object->initializer_priorities[slot] : 0;
            if (priorities && !(offsets[section_index] % OBJECT_INITIALIZER_ENTRY_SIZE))
            {
                u64 first = offsets[section_index] / OBJECT_INITIALIZER_ENTRY_SIZE;
                for (u64 entry = 0; entry < source->data.length / OBJECT_INITIALIZER_ENTRY_SIZE; entry += 1)
                {
                    merged[first + entry] = priorities[entry];
                }
            }
        }
    }
    u32** symbol_maps = arena_allocate(arena, u32*, object_count);
    LinkGlobalSymbolTable global_symbols = {0};
    if (!link_global_symbol_table_initialize(arena, result.object.symbols, total_symbols, &global_symbols))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    for (u32 object_index = 0; object_index < object_count; object_index += 1)
    {
        ObjectFile* object = &objects[object_index];
        u32* symbol_map = arena_allocate(arena, u32, object->symbol_count);
        symbol_maps[object_index] = symbol_map;
        for (u32 source_index = 0; source_index < object->symbol_count; source_index += 1)
        {
            symbol_map[source_index] = UINT32_MAX;
            ObjectSymbol* source = &object->symbols[source_index];
            if (!source->name.length)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            if (source->comdat > object->comdat_count || source->thread_local_state > OBJECT_SYMBOL_THREAD_LOCAL_YES ||
                (source->section != OBJECT_SECTION_UNDEFINED &&
                 (source->section >= object->section_count ||
                  source->value > BUSTER_MAX(object->sections[source->section].data.length, object->sections[source->section].virtual_size) ||
                  source->size > BUSTER_MAX(object->sections[source->section].data.length, object->sections[source->section].virtual_size) - source->value)))
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            if (source->section != OBJECT_SECTION_UNDEFINED && source->section < object->section_count &&
                source->thread_local_state != OBJECT_SYMBOL_THREAD_LOCAL_UNKNOWN)
            {
                ObjectSectionKind section_kind = object->sections[source->section].kind;
                bool section_is_thread_local = section_kind == OBJECT_SECTION_THREAD_LOCAL_DATA ||
                                               section_kind == OBJECT_SECTION_THREAD_LOCAL_ZERO;
                if ((source->thread_local_state == OBJECT_SYMBOL_THREAD_LOCAL_YES) != section_is_thread_local)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                    return result;
                }
            }
            ObjectSymbol discarded_source = {0};
            if (link_comdat_is_discarded(&comdat_plan, object_index, source->comdat))
            {
                if (!source->global)
                {
                    continue;
                }
                discarded_source = *source;
                discarded_source.value = 0;
                discarded_source.size = 0;
                discarded_source.section = OBJECT_SECTION_UNDEFINED;
                discarded_source.comdat = 0;
                discarded_source.weak = true;
                source = &discarded_source;
            }
            u32 destination_index = UINT32_MAX;
            u32* global_slot = 0;
            if (source->global)
            {
                global_slot = link_global_symbol_table_slot(&global_symbols, source->name);
                if (!global_slot)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                    return result;
                }
                destination_index = *global_slot;
            }
            if (destination_index == UINT32_MAX)
            {
                destination_index = result.object.symbol_count++;
                if (!link_symbol_definition_set(&result.object.symbols[destination_index], source, object,
                                                section_offsets + (u64)object_index * OBJECT_SECTION_COUNT, arena))
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                    return result;
                }
                if (global_slot)
                {
                    *global_slot = destination_index;
                }
            }
            else
            {
                ObjectSymbol* destination = &result.object.symbols[destination_index];
                bool destination_defined = destination->section != OBJECT_SECTION_UNDEFINED;
                bool source_defined = source->section != OBJECT_SECTION_UNDEFINED;
                u8 destination_thread_local_state = link_symbol_thread_local_state(&result.object, destination);
                u8 source_thread_local_state = link_symbol_thread_local_state(object, source);
                // Undefined symbols in COFF and Mach-O may not carry a TLS
                // bit, so their readers leave the state unknown. Definitions
                // still derive it from their section, and known IR facts are
                // checked on every target format.
                bool thread_local_mismatch = destination_thread_local_state != OBJECT_SYMBOL_THREAD_LOCAL_UNKNOWN &&
                                             source_thread_local_state != OBJECT_SYMBOL_THREAD_LOCAL_UNKNOWN &&
                                             destination_thread_local_state != source_thread_local_state;
                if (thread_local_mismatch)
                {
                    result.error = LINK_ERROR_TLS_SYMBOL_MISMATCH;
                    result.symbol = link_string_copy(arena, source->name);
                    return result;
                }
                // Two definitions collide only when neither is replaceable.
                // A replaceable definition — COFF selectany COMDAT, ELF weak,
                // Mach-O N_WEAK_DEF — yields to a strong one whichever side it
                // arrives on, and to nothing else: among replaceable
                // definitions the first input wins, which is what keeps the
                // merge deterministic in the order the driver hands objects
                // over.  The losing definition keeps its bytes in the merged
                // section; only the symbol stops naming them.
                bool duplicate_definition = destination_defined && source_defined;
                bool source_replaces = duplicate_definition ? destination->weak && !source->weak : !destination_defined && source_defined;
                if (duplicate_definition && !destination->weak && !source->weak)
                {
                    result.error = LINK_ERROR_DUPLICATE_SYMBOL;
                    result.symbol = link_string_copy(arena, source->name);
                    return result;
                }
                // Binding and visibility survive whichever definition wins,
                // so they are merged around the replacement rather than
                // copied with it.  A symbol nothing in the link defines is
                // weak only while every reference to it is: one strong
                // reference is what makes the symbol required, whichever side
                // it arrives on.  Visibility merges the other way -- the most
                // constraining occurrence wins -- so one reference declaring
                // the symbol hidden keeps it out of the dynamic symbol table
                // even when another does not.
                bool merged_hidden = destination->hidden || source->hidden;
                bool merged_weak = destination->weak && source->weak;
                u8 merged_thread_local_state = destination_thread_local_state != OBJECT_SYMBOL_THREAD_LOCAL_UNKNOWN
                                                   ? destination_thread_local_state
                                                   : source_thread_local_state;
                if (source_replaces)
                {
                    if (!link_symbol_definition_set(destination, source, object, section_offsets + (u64)object_index * OBJECT_SECTION_COUNT, arena))
                    {
                        result.error = LINK_ERROR_INVALID_INPUT;
                        return result;
                    }
                }
                destination->hidden = merged_hidden;
                destination->thread_local_state = merged_thread_local_state;
                if (destination->section == OBJECT_SECTION_UNDEFINED)
                {
                    destination->weak = merged_weak;
                }
            }
            symbol_map[source_index] = destination_index;
        }
    }
    for (u32 object_index = 0; object_index < object_count; object_index += 1)
    {
        ObjectFile* object = &objects[object_index];
        u64* offsets = section_offsets + (u64)object_index * OBJECT_SECTION_COUNT;
        for (u32 relocation_index = 0; relocation_index < object->relocation_count; relocation_index += 1)
        {
            ObjectRelocation source = object->relocations[relocation_index];
            if (source.comdat > object->comdat_count)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            if (link_comdat_is_discarded(&comdat_plan, object_index, source.comdat))
            {
                continue;
            }
            if (source.section >= object->section_count || source.symbol >= object->symbol_count || symbol_maps[object_index][source.symbol] == UINT32_MAX)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            ObjectSectionKind kind = object->sections[source.section].kind;
            source.section = (u32)kind;
            source.offset += offsets[object->relocations[relocation_index].section];
            source.symbol = symbol_maps[object_index][source.symbol];
            source.comdat = 0;
            result.object.relocations[result.object.relocation_count++] = source;
        }
    }
    link_initializer_arrays_order(arena, &result.object);
    if (!options.allow_undefined_symbols)
    {
        for (u32 symbol_index = 0; symbol_index < result.object.symbol_count; symbol_index += 1)
        {
            ObjectSymbol* symbol = &result.object.symbols[symbol_index];
            if (symbol->section == OBJECT_SECTION_UNDEFINED)
            {
                result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
                result.symbol = link_string_copy(arena, symbol->name);
                return result;
            }
        }
    }
    return result;
}

ObjectFile link_windows_runtime_object(Arena* arena, Target target)
{
    ObjectFile result = {
        .target = target,
    };
    if (!arena)
    {
        result.error = OBJECT_ERROR_INVALID_INPUT;
        return result;
    }
    if (target.os != OPERATING_SYSTEM_WINDOWS || (target.cpu_arch != CPU_ARCH_X86_64 && target.cpu_arch != CPU_ARCH_AARCH64))
    {
        result.error = OBJECT_ERROR_UNSUPPORTED_TARGET;
        return result;
    }

    // MSVC-compatible COFF objects emit a reference to this data symbol when
    // a translation unit uses floating point.  UCRT exposes the runtime
    // functions but not the compiler marker itself, so it belongs to the
    // compiler's Windows runtime policy rather than to a user fixture.  Keep
    // the definition weak: a CRT or application object with the real marker
    // wins, while mixed Clang/Buster links get the same four-byte contract as
    // an MSVC startup object.
    result.sections = arena_allocate(arena, ObjectSection, OBJECT_SECTION_COUNT);
    result.section_count = OBJECT_SECTION_COUNT;
    for (u32 section_index = 0; section_index < OBJECT_SECTION_COUNT; section_index += 1)
    {
        ObjectSectionKind kind = (ObjectSectionKind)section_index;
        result.sections[section_index] = (ObjectSection){
            .name = object_section_name_for_kind(kind),
            .kind = kind,
            .alignment = object_section_default_alignment(kind),
        };
    }
    u8* marker = arena_allocate(arena, u8, sizeof(u32));
    u32 marker_value = 1;
    memcpy(marker, &marker_value, sizeof(marker_value));
    result.sections[OBJECT_SECTION_DATA].data = (ByteSlice){.pointer = marker, .length = sizeof(marker_value)};
    result.sections[OBJECT_SECTION_DATA].virtual_size = sizeof(marker_value);
    result.sections[OBJECT_SECTION_DATA].alignment = sizeof(marker_value);
    result.symbols = arena_allocate(arena, ObjectSymbol, 1);
    result.symbol_count = 1;
    result.symbols[0] = (ObjectSymbol){
        .name = S8("_fltused"),
        .size = sizeof(marker_value),
        .section = OBJECT_SECTION_DATA,
        .kind = OBJECT_SYMBOL_DATA,
        .global = true,
        .weak = true,
    };
    return result;
}

// Every C library this linker resolves against keeps a few exit-handler
// registration functions out of its shared object and inside the static half
// a program is expected to link: glibc puts `atexit` and `at_quick_exit` in
// libc_nonshared.a, where each is a call to its `__cxa_` form, and UCRT puts
// the same two names in its import library, where each is a call to its
// `_crt_` form.  The writers here import from the shared object alone, so
// those names resolve nowhere and a program that registers an exit handler
// (SQLite's shell does, on its first line of main) fails to link.
//
// This builds the missing half: one weak stub per name whose whole body is a
// tail branch to the exported function, so a program with its own definition
// still wins and the C ABI hands the arguments straight through.
// `zero_trailing_arguments` covers a target that takes more arguments than
// the stub does -- `__cxa_atexit` takes the handler, a null argument and a
// null DSO handle where `atexit` takes only the handler -- which is exactly
// what an executable's own glibc stub passes.  The branch is the last
// instruction of the body; x86 metadata returns its checked field descriptor
// and prepared bytes. The caller has already checked the target.
BUSTER_GLOBAL_LOCAL ObjectFile link_forwarding_runtime_object(Arena* arena, Target target, String8 const* stub_names, String8 const* target_names,
                                                              u64 stub_count, bool zero_trailing_arguments)
{
    ObjectFile result = {
        .target = target,
    };
    static u8 const aarch64_zero_arguments[] = {
        0x01, 0x00, 0x80, 0xd2, // mov x1, #0
        0x02, 0x00, 0x80, 0xd2, // mov x2, #0
    };
    static u8 const aarch64_branch[] = {
        0x00, 0x00, 0x00, 0x14, // b
    };
    bool x86_64 = target.cpu_arch == CPU_ARCH_X86_64;
    u8 recipe[BUSTER_X86_METADATA_FORWARDING_ZERO_SIZE];
    BusterX86MetadataRelocation branch = {0};
    u64 thunk_size = zero_trailing_arguments ? sizeof(aarch64_zero_arguments) + sizeof(aarch64_branch) : sizeof(aarch64_branch);
    bool valid = true;
    if (x86_64)
    {
        BusterX86MetadataForwardingKind kind = zero_trailing_arguments ? BUSTER_X86_METADATA_FORWARDING_ZERO_ARGUMENTS
                                                                     : BUSTER_X86_METADATA_FORWARDING_JUMP;
        thunk_size = zero_trailing_arguments ? BUSTER_X86_METADATA_FORWARDING_ZERO_SIZE : BUSTER_X86_METADATA_FORWARDING_JUMP_SIZE;
        valid = buster_x86_metadata_emit_forwarding(recipe, sizeof(recipe), kind, &branch);
    }
    else
    {
        branch.offset = zero_trailing_arguments ? sizeof(aarch64_zero_arguments) : 0;
    }
    // Derive before allocating or publishing an object. A changed metadata
    // envelope cannot leave an apparently valid object with missing stubs.
    if (!valid)
    {
        result.error = OBJECT_ERROR_INVALID_INPUT;
    }
    else
    {
        result.sections = arena_allocate(arena, ObjectSection, OBJECT_SECTION_COUNT);
        result.section_count = OBJECT_SECTION_COUNT;
        for (u32 section_index = 0; section_index < OBJECT_SECTION_COUNT; section_index += 1)
        {
            ObjectSectionKind kind = (ObjectSectionKind)section_index;
            result.sections[section_index] = (ObjectSection){
                .name = object_section_name_for_kind(kind),
                .kind = kind,
                .alignment = object_section_default_alignment(kind),
            };
        }
        // One thunk per stub, laid out back to back in the same section.
        u8* thunks = arena_allocate(arena, u8, thunk_size * stub_count);
        result.symbols = arena_allocate(arena, ObjectSymbol, stub_count * 2);
        result.relocations = arena_allocate(arena, ObjectRelocation, stub_count);
        for (u64 index = 0; index < stub_count; index += 1)
        {
            u64 offset = thunk_size * index;
            if (x86_64)
            {
                memcpy(thunks + offset, recipe, thunk_size);
            }
            else
            {
                if (zero_trailing_arguments) memcpy(thunks + offset, aarch64_zero_arguments, sizeof(aarch64_zero_arguments));
                memcpy(thunks + offset + branch.offset, aarch64_branch, sizeof(aarch64_branch));
            }
            result.symbols[index * 2] = (ObjectSymbol){
                .name = stub_names[index],
                .value = offset,
                .size = thunk_size,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
                .weak = true,
            };
            result.symbols[index * 2 + 1] = (ObjectSymbol){
                .name = target_names[index],
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            };
            result.relocations[index] = (ObjectRelocation){
                .addend = branch.addend,
                .offset = offset + branch.offset,
                .section = OBJECT_SECTION_TEXT,
                .symbol = (u32)(index * 2 + 1),
                .kind = x86_64 ? OBJECT_RELOCATION_X86_64_PC32 : OBJECT_RELOCATION_AARCH64_JUMP26,
            };
        }
        result.symbol_count = (u32)(stub_count * 2);
        result.relocation_count = (u32)stub_count;
        result.sections[OBJECT_SECTION_TEXT].data = (ByteSlice){.pointer = thunks, .length = thunk_size * stub_count};
        result.sections[OBJECT_SECTION_TEXT].virtual_size = thunk_size * stub_count;
    }

    return result;
}

// The glibc half of that split: libc.so.6 exports only the `__cxa_` forms, so
// the stubs pass the null argument and the null DSO handle the executable's
// own libc_nonshared.a stubs pass.  The driver adds this object only when
// something references one of them and nothing defines it, and a program with
// its own definition keeps it.
ObjectFile link_elf_libc_runtime_object(Arena* arena, Target target)
{
    ObjectFile result = {
        .target = target,
    };
    static String8 const stub_names[] = {S8_INITIALIZER("atexit"), S8_INITIALIZER("at_quick_exit")};
    static String8 const target_names[] = {S8_INITIALIZER("__cxa_atexit"), S8_INITIALIZER("__cxa_at_quick_exit")};
    if (!arena)
    {
        result.error = OBJECT_ERROR_INVALID_INPUT;
    }
    else if (object_format_for_target(target) != OBJECT_FORMAT_ELF64 || (target.cpu_arch != CPU_ARCH_X86_64 && target.cpu_arch != CPU_ARCH_AARCH64))
    {
        result.error = OBJECT_ERROR_UNSUPPORTED_TARGET;
    }
    else
    {
        result = link_forwarding_runtime_object(arena, target, stub_names, target_names, BUSTER_ARRAY_LENGTH(stub_names), true);
    }

    return result;
}

// The UCRT half.  `winedump -j export ucrtbase.dll` lists `_crt_atexit` and
// `_crt_at_quick_exit` and neither `atexit` nor `at_quick_exit`: those two
// live in the import library, where each is one call to its `_crt_` form and
// nothing else, so the stubs here pass their single argument straight on.
// `_onexit` is deliberately not among them.  It is the same registration with
// a different result -- the handler on success, a null pointer on failure,
// where `_crt_atexit` answers with a status -- so it cannot be a tail branch,
// and a stub that called and then chose would need Windows unwind data of its
// own.  Nothing in this project names it.
//
// This is a second object rather than more of link_windows_runtime_object
// because the two are selected differently: `_fltused` is data no image can
// be harmed by, while these stubs carry an undefined `_crt_` reference that
// would become an import in every executable ever linked -- and would fail
// the link outright on a host with no readable ucrtbase.dll.
ObjectFile link_windows_libc_runtime_object(Arena* arena, Target target)
{
    ObjectFile result = {
        .target = target,
    };
    static String8 const stub_names[] = {S8_INITIALIZER("atexit"), S8_INITIALIZER("at_quick_exit")};
    static String8 const target_names[] = {S8_INITIALIZER("_crt_atexit"), S8_INITIALIZER("_crt_at_quick_exit")};
    if (!arena)
    {
        result.error = OBJECT_ERROR_INVALID_INPUT;
    }
    else if (target.os != OPERATING_SYSTEM_WINDOWS || (target.cpu_arch != CPU_ARCH_X86_64 && target.cpu_arch != CPU_ARCH_AARCH64))
    {
        result.error = OBJECT_ERROR_UNSUPPORTED_TARGET;
    }
    else
    {
        result = link_forwarding_runtime_object(arena, target, stub_names, target_names, BUSTER_ARRAY_LENGTH(stub_names), false);
    }

    return result;
}

// An image this linker writes has one thread-local block, laid out here, so
// every reference in it can be answered with a constant offset from the
// thread pointer no matter which model the compiler chose. Initial-exec and
// general-dynamic are rewritten into that constant in place, which is the
// same relaxation `ld` performs when a position-independent object ends up in
// an executable rather than in a shared library.
//
//   initial-exec, seven bytes ending at the patched field:
//     REX.W 03 modrm(00 reg 101) disp32   add reg, [rip + sym@GOTTPOFF]
//   becomes
//     REX.W 81 modrm(11 000 reg) imm32    add reg, tpoff
//   The GOT operand's register is the modrm reg field and the immediate
//   form's is the rm field, so REX.R moves to REX.B with it.
//
//   general-dynamic, sixteen bytes starting four before the patched field:
//     66 48 8d 3d <r32>  66 66 48 e8 <r32>
//   becomes
//     64 48 8b 04 25 00000000    mov rax, fs:0
//     48 8d 80 <tpoff>           lea rax, [rax + tpoff]
//   which is the local-exec sequence, and is why the general-dynamic bytes
//   are emitted as a fixed sixteen rather than in their shortest forms.
BUSTER_GLOBAL_LOCAL bool link_elf_relax_thread_local(u8* bytes, u64 field_offset, u64 section_start, u64 section_end, bool general_dynamic,
                                                     s32 thread_pointer_offset)
{
    u32 prefix_size = general_dynamic ? BUSTER_X86_METADATA_TLS_GD_ADDRESS_OFFSET : BUSTER_X86_METADATA_TLS_IE_OFFSET;
    u32 sequence_size = general_dynamic ? BUSTER_X86_METADATA_TLS_GD_SIZE : BUSTER_X86_METADATA_TLS_IE_SIZE;
    bool result = false;
    // The recipe reaches outside the relocation field. Use subtraction only
    // after ordered bounds checks, including malformed near-UINT64_MAX ranges.
    if (bytes && section_start <= field_offset && field_offset <= section_end &&
        prefix_size <= field_offset - section_start && sequence_size - prefix_size <= section_end - field_offset)
    {
        result = buster_x86_metadata_relax_tls(bytes + field_offset - prefix_size, sequence_size,
                                               general_dynamic ? BUSTER_X86_METADATA_TLS_GENERAL_DYNAMIC : BUSTER_X86_METADATA_TLS_INITIAL_EXEC,
                                               thread_pointer_offset);
    }
    return result;
}

// Whether this relocation is the call half of a general-dynamic pair the
// relaxation above rewrote. Both halves come out of one selected row eight
// bytes apart, in that order, so the TLSGD site is the whole test; the name
// check only keeps the scan off every other rel32 in the object.
BUSTER_GLOBAL_LOCAL bool link_elf_relocation_is_relaxed_tls_get_addr(ObjectFile* object, ObjectRelocation* relocation, ObjectSymbol* symbol)
{
    u32 field_delta = BUSTER_X86_METADATA_TLS_GD_HELPER_OFFSET - BUSTER_X86_METADATA_TLS_GD_ADDRESS_OFFSET;
    if ((relocation->kind != OBJECT_RELOCATION_X86_64_PC32 && relocation->kind != OBJECT_RELOCATION_X86_64_PLT32) || relocation->offset < field_delta ||
        !string_equal(symbol->name, S8("__tls_get_addr")))
    {
        return false;
    }
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation* candidate = object->relocations + index;
        if (candidate->kind == OBJECT_RELOCATION_X86_64_TLSGD && candidate->section == relocation->section &&
            candidate->offset == relocation->offset - field_delta)
        {
            return true;
        }
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool link_aarch64_branch_encode(A64Opcode opcode, s64 displacement, u32* word)
{
    bool result;
    if (opcode != A64_OPCODE_B && opcode != A64_OPCODE_BL)
    {
        result = false;
    }
    else
    {
        A64MCInst instruction = {
            .operands = {{.value = displacement, .kind = A64_MC_OPERAND_PC_RELATIVE}},
            .opcode = opcode,
            .operand_count = 1,
        };
        result = a64_mc_encode(&instruction, word);
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool link_aarch64_branch_relocate(ObjectRelocationKind kind, u32 instruction, s64 displacement, u32* word)
{
    A64Opcode opcode = kind == OBJECT_RELOCATION_AARCH64_CALL26 ? A64_OPCODE_BL
                       : kind == OBJECT_RELOCATION_AARCH64_JUMP26 ? A64_OPCODE_B
                                                                  : A64_OPCODE_INVALID;
    return a64_pc_relative_patch(opcode, instruction, displacement, word);
}

BUSTER_GLOBAL_LOCAL bool link_address_difference(u64 target, u64 place, s64 addend, s64* result)
{
    return a64_pc_relative_displacement(target, place, addend, result);
}

BUSTER_GLOBAL_LOCAL bool link_address_addend(u64 address, s64 addend, u64* result)
{
    if (!result)
    {
        return false;
    }
    if (addend < 0)
    {
        u64 magnitude = (u64)(-(addend + 1)) + 1;
        if (magnitude > address)
        {
            return false;
        }
        *result = address - magnitude;
    }
    else
    {
        u64 magnitude = (u64)addend;
        if (magnitude > UINT64_MAX - address)
        {
            return false;
        }
        *result = address + magnitude;
    }
    return true;
}

// The object writer binds GOT references to this image's definitions. The
// metadata authority validates and rewrites the bounded instruction shape and
// answers with the patch its replacement now takes; this adapter owns section
// bounds and the psABI spelling only, never opcode bits. Both ELF image
// writers consume it.
BUSTER_GLOBAL_LOCAL BusterX86MetadataGotPatch link_x86_relax_got_reference(ObjectRelocationKind kind, s64 addend, u8* bytes, u64 field_offset,
                                                                          u64 section_start, u64 section_end)
{
    BusterX86MetadataGotPatch result = BUSTER_X86_METADATA_GOT_PATCH_NONE;
    if (bytes && section_start <= field_offset && field_offset <= section_end)
    {
        BusterX86MetadataGotSite site = kind == OBJECT_RELOCATION_X86_64_GOTPCRELX          ? BUSTER_X86_METADATA_GOT_SITE_GOTPCRELX
                                        : kind == OBJECT_RELOCATION_X86_64_REX_GOTPCRELX    ? BUSTER_X86_METADATA_GOT_SITE_REX_GOTPCRELX
                                        : kind == OBJECT_RELOCATION_X86_64_CODE_4_GOTPCRELX ? BUSTER_X86_METADATA_GOT_SITE_CODE_4_GOTPCRELX
                                                                                            : BUSTER_X86_METADATA_GOT_SITE_GOTPCREL;
        result = buster_x86_metadata_relax_got_reference(site, bytes + section_start, field_offset - section_start, section_end - section_start, addend);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool link_absolute32s_value(u64 address, s64 addend, s32* result)
{
    bool valid = result && address <= (u64)INT64_MAX;
    s64 value = valid ? (s64)address : 0;
    if (valid && ((addend > 0 && value > INT64_MAX - addend) || (addend < 0 && value < INT64_MIN - addend)))
    {
        valid = false;
    }
    if (valid)
    {
        value += addend;
        valid = value >= INT32_MIN && value <= INT32_MAX;
    }
    if (valid)
    {
        *result = (s32)value;
    }
    return valid;
}

BUSTER_GLOBAL_LOCAL bool link_u64_add(u64 left, u64 right, u64* result)
{
    bool valid = result && right <= UINT64_MAX - left;
    if (valid)
    {
        *result = left + right;
    }

    return valid;
}

BUSTER_GLOBAL_LOCAL bool link_u64_align_forward(u64 value, u64 alignment, u64* result)
{
    return align_forward_checked(value, alignment, result);
}

BUSTER_GLOBAL_LOCAL bool link_aarch64_page21_instruction_valid(u32 instruction)
{
    return (instruction & UINT32_C(0xffffffe0)) == UINT32_C(0x90000000);
}

BUSTER_GLOBAL_LOCAL bool link_aarch64_pageoff12_shift(u32 instruction, u32* shift)
{
    if (shift)
    {
        u32 base = instruction & UINT32_C(0xffc00000);
        bool valid_ldst = false;
        switch (base)
        {
        case UINT32_C(0x39000000):
        case UINT32_C(0x39400000):
        case UINT32_C(0x39800000):
        case UINT32_C(0x39c00000):
        case UINT32_C(0x79000000):
        case UINT32_C(0x79400000):
        case UINT32_C(0x79800000):
        case UINT32_C(0x79c00000):
        case UINT32_C(0xb9000000):
        case UINT32_C(0xb9400000):
        case UINT32_C(0xb9800000):
        case UINT32_C(0xf9000000):
        case UINT32_C(0xf9400000):
        case UINT32_C(0xf9800000):
        case UINT32_C(0x3d000000):
        case UINT32_C(0x3d400000):
        case UINT32_C(0x3d800000):
        case UINT32_C(0x3dc00000):
        case UINT32_C(0x7d000000):
        case UINT32_C(0x7d400000):
        case UINT32_C(0xbd000000):
        case UINT32_C(0xbd400000):
        case UINT32_C(0xfd000000):
        case UINT32_C(0xfd400000):
            valid_ldst = true;
            break;
        default:
            break;
        }
        if (valid_ldst)
        {
            u32 implicit_shift = instruction >> 30;
            if (!implicit_shift && (instruction & UINT32_C(0x04800000)) == UINT32_C(0x04800000))
            {
                implicit_shift = 4;
            }
            if (instruction & (UINT32_C(0xfff) << 10))
            {
                return false;
            }
            *shift = implicit_shift;
            return true;
        }
        if ((instruction & UINT32_C(0xffc00000)) == UINT32_C(0x91000000) &&
            !(instruction & (UINT32_C(0xfff) << 10)))
        {
            *shift = 0;
            return true;
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL void link_write_u64(u8* bytes, u64 offset, u64 value)
{
    memcpy(bytes + offset, &value, sizeof(value));
}

u64 link_read_u64(u8 const* bytes, u64 offset)
{
    u64 result = 0;
    memcpy(&result, bytes + offset, sizeof(result));
    return result;
}

u32 link_read_u32(u8 const* bytes, u64 offset)
{
    u32 result = 0;
    memcpy(&result, bytes + offset, sizeof(result));
    return result;
}

BUSTER_GLOBAL_LOCAL void link_write_u32_be(u8* bytes, u64 offset, u32 value)
{
    bytes[offset] = (u8)(value >> 24);
    bytes[offset + 1] = (u8)(value >> 16);
    bytes[offset + 2] = (u8)(value >> 8);
    bytes[offset + 3] = (u8)value;
}

BUSTER_GLOBAL_LOCAL u32 link_rotate_right_u32(u32 value, u32 amount)
{
    return (value >> amount) | (value << (32 - amount));
}

void link_sha256(Arena* arena, u8 const* input, u64 length, u8* output)
{
    static u32 const constants[64] = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be,
        0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa,
        0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85,
        0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
        0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    };
    u32* state = arena_allocate(arena, u32, 8);
    state[0] = 0x6a09e667;
    state[1] = 0xbb67ae85;
    state[2] = 0x3c6ef372;
    state[3] = 0xa54ff53a;
    state[4] = 0x510e527f;
    state[5] = 0x9b05688c;
    state[6] = 0x1f83d9ab;
    state[7] = 0x5be0cd19;
    u8* block = arena_allocate(arena, u8, 64);
    u32* words = arena_allocate(arena, u32, 64);
    u64 block_count = (length + 9 + 63) / 64;
    for (u64 block_index = 0; block_index < block_count; block_index += 1)
    {
        memset(block, 0, 64);
        u64 block_offset = block_index * 64;
        for (u64 byte_index = 0; byte_index < 64; byte_index += 1)
        {
            u64 source_offset = block_offset + byte_index;
            if (source_offset < length)
            {
                block[byte_index] = input[source_offset];
            }
            else if (source_offset == length)
            {
                block[byte_index] = 0x80;
            }
        }
        if (block_index + 1 == block_count)
        {
            u64 bit_length = length * 8;
            for (u32 index = 0; index < 8; index += 1)
            {
                block[63 - index] = (u8)(bit_length >> (index * 8));
            }
        }
        memset(words, 0, 64 * sizeof(*words));
        for (u32 index = 0; index < 16; index += 1)
        {
            u32 offset = index * 4;
            words[index] = ((u32)block[offset] << 24) | ((u32)block[offset + 1] << 16) | ((u32)block[offset + 2] << 8) | block[offset + 3];
        }
        for (u32 index = 16; index < 64; index += 1)
        {
            u32 first = link_rotate_right_u32(words[index - 15], 7) ^ link_rotate_right_u32(words[index - 15], 18) ^ (words[index - 15] >> 3);
            u32 second = link_rotate_right_u32(words[index - 2], 17) ^ link_rotate_right_u32(words[index - 2], 19) ^ (words[index - 2] >> 10);
            words[index] = words[index - 16] + first + words[index - 7] + second;
        }
        u32 a = state[0];
        u32 b = state[1];
        u32 c = state[2];
        u32 d = state[3];
        u32 e = state[4];
        u32 f = state[5];
        u32 g = state[6];
        u32 h = state[7];
        for (u32 index = 0; index < 64; index += 1)
        {
            u32 sigma1 = link_rotate_right_u32(e, 6) ^ link_rotate_right_u32(e, 11) ^ link_rotate_right_u32(e, 25);
            u32 choice = (e & f) ^ (~e & g);
            u32 temporary1 = h + sigma1 + choice + constants[index] + words[index];
            u32 sigma0 = link_rotate_right_u32(a, 2) ^ link_rotate_right_u32(a, 13) ^ link_rotate_right_u32(a, 22);
            u32 majority = (a & b) ^ (a & c) ^ (b & c);
            u32 temporary2 = sigma0 + majority;
            h = g;
            g = f;
            f = e;
            e = d + temporary1;
            d = c;
            c = b;
            b = a;
            a = temporary1 + temporary2;
        }
        state[0] += a;
        state[1] += b;
        state[2] += c;
        state[3] += d;
        state[4] += e;
        state[5] += f;
        state[6] += g;
        state[7] += h;
    }
    for (u32 index = 0; index < 8; index += 1)
    {
        link_write_u32_be(output, (u64)index * 4, state[index]);
    }
}

BUSTER_GLOBAL_LOCAL bool link_write_executable_file(String8 path, ByteSlice bytes)
{
    return file_publish_executable(path, bytes);
}

BUSTER_GLOBAL_LOCAL u32 link_symbol_find(ObjectFile* object, String8 name)
{
    for (u32 index = 0; index < object->symbol_count; index += 1)
    {
        if (string_equal(object->symbols[index].name, name))
        {
            return index;
        }
    }
    return UINT32_MAX;
}

BUSTER_GLOBAL_LOCAL bool link_elf_uleb_read(ByteSlice data, u64 end, u64* cursor, u64* value)
{
    u64 result = 0;
    u32 shift = 0;
    for (u32 byte_index = 0; byte_index < 10; byte_index += 1)
    {
        if (*cursor >= end || *cursor >= data.length)
        {
            return false;
        }
        u8 byte = data.pointer[(*cursor)++];
        u64 payload = byte & 0x7f;
        if (shift >= 64 || payload > (UINT64_MAX >> shift))
        {
            return false;
        }
        result |= payload << shift;
        if (!(byte & 0x80))
        {
            *value = result;
            return true;
        }
        shift += 7;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool link_elf_cie_has_pcrel_sdata4(ByteSlice data, u64 cie_offset)
{
    if (cie_offset > data.length || data.length - cie_offset < 12)
    {
        return false;
    }
    u32 length = link_read_u32(data.pointer, cie_offset);
    if (length < 8 || length > data.length - cie_offset - 4 || link_read_u32(data.pointer, cie_offset + 4) != 0)
    {
        return false;
    }
    u64 end = cie_offset + 4 + length;
    u64 cursor = cie_offset + 8;
    if (data.pointer[cursor++] != 1 || end - cursor < 3 || data.pointer[cursor] != 'z' || data.pointer[cursor + 1] != 'R' || data.pointer[cursor + 2] != 0)
    {
        return false;
    }
    cursor += 3;
    u64 ignored = 0;
    if (!link_elf_uleb_read(data, end, &cursor, &ignored) || !link_elf_uleb_read(data, end, &cursor, &ignored) ||
        !link_elf_uleb_read(data, end, &cursor, &ignored))
    {
        return false;
    }
    u64 augmentation_size = 0;
    return link_elf_uleb_read(data, end, &cursor, &augmentation_size) && augmentation_size == 1 && cursor < end && data.pointer[cursor] == 0x1b;
}

BUSTER_GLOBAL_LOCAL LinkElfEhFrameTable link_elf_eh_frame_table_build(Arena* arena, ObjectFile* object)
{
    LinkElfEhFrameTable result = {0};
    if (arena && object && object->section_count > OBJECT_SECTION_UNWIND)
    {
        ByteSlice data = object->sections[OBJECT_SECTION_UNWIND].data;
        if (!data.length)
        {
            result.valid = true;
            return result;
        }
        if (object->relocation_count > (UINT32_C(1) << 30))
        {
            return result;
        }
        result.entries = arena_allocate(arena, LinkElfEhFrameEntry, object->relocation_count);
        result.scratch = arena_allocate(arena, LinkElfEhFrameEntry, object->relocation_count);
        u32 relocation_map_capacity = 1;
        while (relocation_map_capacity < object->relocation_count * 2)
        {
            relocation_map_capacity <<= 1;
        }
        u32* relocation_map = arena_allocate(arena, u32, relocation_map_capacity);
        memset(relocation_map, 0xff, sizeof(*relocation_map) * relocation_map_capacity);
        for (u32 relocation_index = 0; relocation_index < object->relocation_count; relocation_index += 1)
        {
            ObjectRelocation* relocation = object->relocations + relocation_index;
            if (relocation->section != OBJECT_SECTION_UNWIND ||
                (relocation->kind != OBJECT_RELOCATION_X86_64_PC32 && relocation->kind != OBJECT_RELOCATION_AARCH64_PREL32))
            {
                continue;
            }
            u32 slot = (u32)((relocation->offset ^ (relocation->offset >> 32)) * UINT64_C(11400714819323198485)) & (relocation_map_capacity - 1);
            while (relocation_map[slot] != UINT32_MAX)
            {
                if (object->relocations[relocation_map[slot]].offset == relocation->offset)
                {
                    return result;
                }
                slot = (slot + 1) & (relocation_map_capacity - 1);
            }
            relocation_map[slot] = relocation_index;
        }
        u64 cursor = 0;
        while (cursor < data.length)
        {
            if (data.length - cursor < 4)
            {
                return result;
            }
            u32 length = link_read_u32(data.pointer, cursor);
            if (!length)
            {
                cursor += 4;
                continue;
            }
            if (length == UINT32_MAX || length > data.length - cursor - 4 || length < 4)
            {
                return result;
            }
            u64 record_end = cursor + 4 + length;
            u32 cie_pointer = link_read_u32(data.pointer, cursor + 4);
            if (cie_pointer)
            {
                u64 cie_pointer_offset = cursor + 4;
                if (cie_pointer > cie_pointer_offset || record_end - cursor < 12 || !link_elf_cie_has_pcrel_sdata4(data, cie_pointer_offset - cie_pointer))
                {
                    return result;
                }
                u64 initial_location = cursor + 8;
                u32 relocation_slot = (u32)((initial_location ^ (initial_location >> 32)) * UINT64_C(11400714819323198485)) & (relocation_map_capacity - 1);
                while (relocation_map[relocation_slot] != UINT32_MAX &&
                       object->relocations[relocation_map[relocation_slot]].offset != initial_location)
                {
                    relocation_slot = (relocation_slot + 1) & (relocation_map_capacity - 1);
                }
                u32 matched_relocation = relocation_map[relocation_slot];
                if (matched_relocation == UINT32_MAX || object->relocations[matched_relocation].symbol >= object->symbol_count || result.count == UINT32_MAX)
                {
                    return result;
                }
                result.entries[result.count++] = (LinkElfEhFrameEntry){
                    .fde_offset = cursor,
                    .relocation = matched_relocation,
                };
            }
            cursor = record_end;
        }
        result.valid = true;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool link_elf_signed_difference(u64 left, u64 right, s32* output)
{
    if (left >= right)
    {
        u64 difference = left - right;
        if (difference > INT32_MAX)
        {
            return false;
        }
        *output = (s32)difference;
        return true;
    }
    u64 difference = right - left;
    if (difference > UINT64_C(2147483648))
    {
        return false;
    }
    *output = difference == UINT64_C(2147483648) ? INT32_MIN : -(s32)difference;
    return true;
}

BUSTER_GLOBAL_LOCAL bool link_elf_eh_frame_header_write(u8* bytes, u64 byte_count, LinkElfEhFrameTable* table, ObjectFile* object, u64 image_base,
                                                        u64 const* section_offsets, u64 header_offset)
{
    u64 header_size = table->count ? 12 + (u64)table->count * 8 : 0;
    if (!table->valid || !header_size || header_offset > byte_count || header_size > byte_count - header_offset)
    {
        return !header_size && table->valid;
    }
    u64 header_address = image_base + header_offset;
    for (u32 entry_index = 0; entry_index < table->count; entry_index += 1)
    {
        LinkElfEhFrameEntry* entry = table->entries + entry_index;
        ObjectRelocation* relocation = object->relocations + entry->relocation;
        ObjectSymbol* symbol = object->symbols + relocation->symbol;
        if (symbol->section >= OBJECT_SECTION_COUNT)
        {
            return false;
        }
        u64 address = 0;
        if (!link_u64_add(image_base, section_offsets[symbol->section], &address) ||
            !link_u64_add(address, symbol->value, &address) || !link_address_addend(address, relocation->addend, &address))
        {
            return false;
        }
        entry->function_address = address;
    }
    LinkElfEhFrameEntry* source = table->entries;
    LinkElfEhFrameEntry* destination = table->scratch;
    for (u32 byte_index = 0; byte_index < 8; byte_index += 1)
    {
        u32 counts[256] = {0};
        u32 offsets[256];
        u32 shift = byte_index * 8;
        for (u32 entry_index = 0; entry_index < table->count; entry_index += 1)
        {
            counts[(source[entry_index].function_address >> shift) & 0xff] += 1;
        }
        u32 offset = 0;
        for (u32 bucket = 0; bucket < BUSTER_ARRAY_LENGTH(counts); bucket += 1)
        {
            offsets[bucket] = offset;
            offset += counts[bucket];
        }
        for (u32 entry_index = 0; entry_index < table->count; entry_index += 1)
        {
            u32 bucket = (source[entry_index].function_address >> shift) & 0xff;
            destination[offsets[bucket]++] = source[entry_index];
        }
        LinkElfEhFrameEntry* swap = source;
        source = destination;
        destination = swap;
    }
    table->entries = source;
    bytes[header_offset] = 1;
    bytes[header_offset + 1] = 0x1b;
    bytes[header_offset + 2] = 0x03;
    bytes[header_offset + 3] = 0x3b;
    s32 relative = 0;
    u64 unwind_address = image_base + section_offsets[OBJECT_SECTION_UNWIND];
    if (!link_elf_signed_difference(unwind_address, header_address + 4, &relative))
    {
        return false;
    }
    link_write_u32(bytes, header_offset + 4, (u32)relative);
    link_write_u32(bytes, header_offset + 8, table->count);
    for (u32 entry_index = 0; entry_index < table->count; entry_index += 1)
    {
        LinkElfEhFrameEntry* entry = table->entries + entry_index;
        u64 output = header_offset + 12 + (u64)entry_index * 8;
        u64 fde_address = unwind_address + entry->fde_offset;
        if (!link_elf_signed_difference(entry->function_address, header_address, &relative))
        {
            return false;
        }
        link_write_u32(bytes, output, (u32)relative);
        if (!link_elf_signed_difference(fde_address, header_address, &relative))
        {
            return false;
        }
        link_write_u32(bytes, output + 4, (u32)relative);
    }
    return true;
}

typedef struct LinkElfSectionDescriptor LinkElfSectionDescriptor;
struct LinkElfSectionDescriptor
{
    String8 name;
    u64 flags;
    u64 address;
    u64 offset;
    u64 size;
    u64 alignment;
    u64 entry_size;
    u32 type;
    u32 link;
    u32 info;
    u32 reserved;
};

// The input symbol stays undefined after a dynamic writer reserves its copy
// slot. Resolve that symbol and the writer-generated aliases from the same
// .dynsym entries the loader sees. This is a transient, section-relative view
// for .symtab only: no extra symbol search, allocation, or input mutation, and
// the image remains on top of the arena for the zero-copy tail append.
BUSTER_GLOBAL_LOCAL ObjectSymbol link_elf_output_symbol(ObjectFile* object, u64 index, u8 const* bytes, u64 image_base,
                                                        u64 const* section_offsets, LinkElfSectionTableLayout const* layout)
{
    ObjectSymbol result;
    u64 dynamic_symbol_offset = 0;
    if (index < object->symbol_count)
    {
        result = object->symbols[index];
        if (result.section == OBJECT_SECTION_UNDEFINED && result.kind == OBJECT_SYMBOL_DATA && layout->import_indices &&
            layout->import_indices[index] != UINT32_MAX)
        {
            dynamic_symbol_offset = layout->dynamic_symbol_offset + ((u64)layout->import_indices[index] + 1) * BUSTER_LINK_ELF_SYMBOL_SIZE;
        }
    }
    else
    {
        u64 alias_index = index - object->symbol_count;
        result = (ObjectSymbol){
            .name = layout->copy_alias_names[alias_index],
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        };
        dynamic_symbol_offset = layout->copy_alias_symbol_offset + alias_index * BUSTER_LINK_ELF_SYMBOL_SIZE;
    }
    if (dynamic_symbol_offset)
    {
        result.section = OBJECT_SECTION_ZERO;
        result.value = link_read_u64(bytes, dynamic_symbol_offset + 8) - image_base - section_offsets[OBJECT_SECTION_ZERO];
        result.size = link_read_u64(bytes, dynamic_symbol_offset + 16);
    }
    return result;
}

typedef struct LinkElfSymbolTableLayout LinkElfSymbolTableLayout;
struct LinkElfSymbolTableLayout
{
    u64 symbol_offset;
    u64 symbol_size;
    u64 string_offset;
    u64 string_size;
    u64 symbol_count;
    u32 local_symbol_count;
};

BUSTER_GLOBAL_LOCAL bool link_elf_symbol_table_layout(ObjectFile* object, u64 image_base, u64 const* section_offsets,
                                                      u32 const* output_section_indices, u8 const* bytes, LinkElfSectionTableLayout const* section_layout,
                                                      u64 cursor, LinkElfSymbolTableLayout* layout)
{
    bool result = cursor <= UINT64_MAX - 7;
    *layout = (LinkElfSymbolTableLayout){.string_size = 1};
    for (u64 index = 0; index < (u64)object->symbol_count + section_layout->copy_alias_count && result; index += 1)
    {
        ObjectSymbol output_symbol = link_elf_output_symbol(object, index, bytes, image_base, section_offsets, section_layout);
        ObjectSymbol* symbol = &output_symbol;
        bool emitted = symbol->section == OBJECT_SECTION_UNDEFINED ||
                       (symbol->section < OBJECT_SECTION_COUNT && output_section_indices[symbol->section]);
        if (emitted)
        {
            layout->symbol_count += 1;
            layout->local_symbol_count += !symbol->global;
            u64 value = 0;
            bool thread_local_symbol = symbol->section == OBJECT_SECTION_THREAD_LOCAL_DATA || symbol->section == OBJECT_SECTION_THREAD_LOCAL_ZERO;
            if (symbol->section != OBJECT_SECTION_UNDEFINED && thread_local_symbol)
            {
                result = section_offsets[symbol->section] >= section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] &&
                         link_u64_add(section_offsets[symbol->section] - section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA], symbol->value, &value);
            }
            else if (symbol->section != OBJECT_SECTION_UNDEFINED && !object_section_kind_is_debug((ObjectSectionKind)symbol->section))
            {
                result = link_u64_add(image_base, section_offsets[symbol->section], &value) && link_u64_add(value, symbol->value, &value);
            }
            if (result && symbol->name.length)
            {
                result = symbol->name.length <= UINT32_MAX - 1 && layout->string_size <= UINT32_MAX - symbol->name.length - 1;
                if (result)
                {
                    layout->string_size += symbol->name.length + 1;
                }
            }
        }
    }
    if (result)
    {
        result = layout->local_symbol_count < UINT32_MAX;
    }
    if (result)
    {
        layout->symbol_offset = align_forward(cursor, 8);
        result = layout->symbol_count + 1 <= (UINT64_MAX - layout->symbol_offset) / BUSTER_LINK_ELF_SYMBOL_SIZE;
    }
    if (result)
    {
        layout->symbol_size = (layout->symbol_count + 1) * BUSTER_LINK_ELF_SYMBOL_SIZE;
        layout->string_offset = layout->symbol_offset + layout->symbol_size;
        result = layout->string_size <= UINT64_MAX - layout->string_offset;
    }
    return result;
}

// Appends merged DWARF data and an ELF section table to a finished image.
// Loaded bytes retain their program-header layout, while zero-fill and debug
// sections preserve their virtual and non-loaded representations. Debug
// relocations are resolved statically here: references into debug sections
// receive section offsets (including DWARF64); other 64-bit slots receive
// link-time addresses, with the legacy range-list exception below.
// Whether `bytes` ends exactly where the arena will hand out its next byte, so
// the block can be grown without being moved.
BUSTER_GLOBAL_LOCAL bool link_arena_block_on_top(Arena* arena, u8* bytes, u64 length)
{
    return bytes + length == arena_get_byte_pointer_at_position(arena, arena->position);
}

BUSTER_GLOBAL_LOCAL void link_elf_section_table_append(Arena* arena, NativeExecutableLinkResult* result, ObjectFile* object, u64 image_base,
                                                       u64 const* section_offsets, LinkElfSectionTableLayout layout)
{
    if (result->error == LINK_ERROR_NONE && object->section_count >= OBJECT_SECTION_COUNT)
    {
        LinkElfSectionDescriptor descriptors[BUSTER_LINK_ELF_SECTION_DESCRIPTOR_CAPACITY] = {0};
        u32 output_section_indices[OBJECT_SECTION_COUNT] = {0};
        u32 descriptor_count = 0;
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(link_elf_loaded_kinds); index += 1)
        {
            ObjectSectionKind kind = link_elf_loaded_kinds[index];
            ObjectSection* section = &object->sections[kind];
            u64 size = BUSTER_MAX(section->data.length, section->virtual_size);
            if (kind == OBJECT_SECTION_ZERO)
            {
                size = BUSTER_MAX(size, layout.copy_zero_size);
            }
            u64 offset = section_offsets[kind];
            bool thread_local_section = kind == OBJECT_SECTION_THREAD_LOCAL_DATA || kind == OBJECT_SECTION_THREAD_LOCAL_ZERO;
            bool writable = kind == OBJECT_SECTION_DATA || kind == OBJECT_SECTION_ZERO || thread_local_section;
            output_section_indices[kind] = descriptor_count + 1;
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = object_section_name_for_kind(kind),
                .flags = (kind == OBJECT_SECTION_TEXT ? UINT64_C(0x6) : writable ? UINT64_C(0x3) : UINT64_C(0x2)) |
                         (thread_local_section ? UINT64_C(0x400) : 0),
                .address = size ? image_base + offset : 0,
                .offset = size ? offset : 0,
                .size = size,
                .alignment = section->alignment,
                .type = object_section_kind_is_zero_fill(kind) ? 8 : 1,
            };
        }
        if (layout.eh_frame_header_size)
        {
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".eh_frame_hdr"),
                .flags = 0x2,
                .address = image_base + layout.eh_frame_header_offset,
                .offset = layout.eh_frame_header_offset,
                .size = layout.eh_frame_header_size,
                .alignment = 4,
                .type = 1,
            };
        }
        if (layout.dynamic)
        {
            u32 dynamic_base = 1 + descriptor_count;
            u32 dynamic_string_index = dynamic_base + 2;
            u32 dynamic_symbol_index = dynamic_base + 3;
            // The two version sections sit between .hash and .rela.plt, and
            // only when the image needs them, so everything after them is
            // numbered from how many of them there are.
            u32 version_section_count = (u32)(layout.version_symbol_size != 0) + (u32)(layout.version_need_size != 0);
            u32 got_index = dynamic_base + 6 + version_section_count;
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".interp"),
                .flags = 0x2,
                .address = image_base + layout.interpreter_offset,
                .offset = layout.interpreter_offset,
                .size = layout.interpreter_size,
                .alignment = 1,
                .type = 1,
            };
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".plt"),
                .flags = 0x6,
                .address = image_base + layout.plt_offset,
                .offset = layout.plt_offset,
                .size = layout.plt_size,
                .alignment = 16,
                .entry_size = 16,
                .type = 1,
            };
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".dynstr"),
                .flags = 0x2,
                .address = image_base + layout.dynamic_string_offset,
                .offset = layout.dynamic_string_offset,
                .size = layout.dynamic_string_size,
                .alignment = 1,
                .type = 3,
            };
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".dynsym"),
                .flags = 0x2,
                .address = image_base + layout.dynamic_symbol_offset,
                .offset = layout.dynamic_symbol_offset,
                .size = layout.dynamic_symbol_size,
                .alignment = 8,
                .entry_size = 24,
                .type = 11,
                .link = dynamic_string_index,
            };
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".hash"),
                .flags = 0x2,
                .address = image_base + layout.hash_offset,
                .offset = layout.hash_offset,
                .size = layout.hash_size,
                .alignment = 4,
                .entry_size = 4,
                .type = 5,
                .link = dynamic_symbol_index,
            };
            if (layout.version_symbol_size)
            {
                descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                    .name = S8(".gnu.version"),
                    .flags = 0x2,
                    .address = image_base + layout.version_symbol_offset,
                    .offset = layout.version_symbol_offset,
                    .size = layout.version_symbol_size,
                    .alignment = 2,
                    .entry_size = 2,
                    .type = BUSTER_LINK_ELF_SECTION_TYPE_VERSION_SYMBOLS,
                    .link = dynamic_symbol_index,
                };
            }
            if (layout.version_need_size)
            {
                descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                    .name = S8(".gnu.version_r"),
                    .flags = 0x2,
                    .address = image_base + layout.version_need_offset,
                    .offset = layout.version_need_offset,
                    .size = layout.version_need_size,
                    .alignment = 8,
                    .type = BUSTER_LINK_ELF_SECTION_TYPE_VERSION_NEED,
                    .link = dynamic_string_index,
                    .info = layout.version_need_count,
                };
            }
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".rela.plt"),
                .flags = 0x2,
                .address = image_base + layout.relocation_offset,
                .offset = layout.relocation_offset,
                .size = layout.relocation_size,
                .alignment = 8,
                .entry_size = 24,
                .type = 4,
                .link = dynamic_symbol_index,
                .info = got_index,
            };
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".got.plt"),
                .flags = 0x3,
                .address = image_base + layout.got_offset,
                .offset = layout.got_offset,
                .size = layout.got_size,
                .alignment = 8,
                .entry_size = 8,
                .type = 1,
            };
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".dynamic"),
                .flags = 0x3,
                .address = image_base + layout.dynamic_offset,
                .offset = layout.dynamic_offset,
                .size = layout.dynamic_size,
                .alignment = 8,
                .entry_size = 16,
                .type = 6,
                .link = dynamic_string_index,
            };
        }
        u64 debug_offsets[BUSTER_ARRAY_LENGTH(link_elf_debug_kinds)];
        u64 cursor = result->executable.length;
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(link_elf_debug_kinds); index += 1)
        {
            ObjectSection* section = &object->sections[link_elf_debug_kinds[index]];
            debug_offsets[index] = cursor;
            // Preserve the existing empty DWARF 4 section table. The external
            // DWARF 5 family adds output only when an input contributes bytes.
            if (!section->data.length && link_elf_debug_kinds[index] >= OBJECT_SECTION_DEBUG_ADDR)
            {
                continue;
            }
            if (section->data.length > UINT64_MAX - cursor)
            {
                result->error = LINK_ERROR_INVALID_INPUT;
                return;
            }
            ObjectSectionKind kind = link_elf_debug_kinds[index];
            output_section_indices[kind] = descriptor_count + 1;
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = object_section_name_for_kind(kind),
                .offset = cursor,
                .size = section->data.length,
                .alignment = section->alignment,
                .type = 1,
            };
            cursor += section->data.length;
        }
        LinkElfSymbolTableLayout symbol_layout = {0};
        bool symbol_layout_valid = link_elf_symbol_table_layout(object, image_base, section_offsets, output_section_indices, result->executable.pointer,
                                                               &layout, cursor, &symbol_layout);
        if (!symbol_layout_valid)
        {
            result->error = LINK_ERROR_INVALID_INPUT;
        }
        if (symbol_layout_valid)
        {
            cursor = symbol_layout.string_offset + symbol_layout.string_size;
            u32 symbol_table_index = descriptor_count + 1;
            u32 symbol_string_table_index = symbol_table_index + 1;
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".symtab"),
                .offset = symbol_layout.symbol_offset,
                .size = symbol_layout.symbol_size,
                .alignment = 8,
                .entry_size = BUSTER_LINK_ELF_SYMBOL_SIZE,
                .type = 2,
                .link = symbol_string_table_index,
                .info = symbol_layout.local_symbol_count + 1,
            };
            descriptors[descriptor_count++] = (LinkElfSectionDescriptor){
                .name = S8(".strtab"),
                .offset = symbol_layout.string_offset,
                .size = symbol_layout.string_size,
                .alignment = 1,
                .type = 3,
            };
        }
        u64 section_string_offset = cursor;
        u64 name_offsets[BUSTER_LINK_ELF_SECTION_DESCRIPTOR_CAPACITY + 2] = {0};
        u64 section_string_size = 1;
        for (u32 index = 0; index < descriptor_count; index += 1)
        {
            name_offsets[index + 1] = section_string_size;
            if (descriptors[index].name.length > UINT64_MAX - section_string_size - 1)
            {
                result->error = LINK_ERROR_INVALID_INPUT;
                return;
            }
            section_string_size += descriptors[index].name.length + 1;
        }
        u32 section_string_table_index = descriptor_count + 1;
        u32 section_count = section_string_table_index + 1;
        name_offsets[section_string_table_index] = section_string_size;
        section_string_size += sizeof(".shstrtab");
        if (section_string_offset > UINT64_MAX - 7 || section_string_size > UINT64_MAX - section_string_offset - 7)
        {
            result->error = LINK_ERROR_INVALID_INPUT;
            return;
        }
        cursor = align_forward(section_string_offset + section_string_size, 8);
        u64 header_offset = cursor;
        if ((u64)section_count > (UINT64_MAX - header_offset) / BUSTER_LINK_ELF_SECTION_HEADER_SIZE)
        {
            result->error = LINK_ERROR_INVALID_INPUT;
            return;
        }
        u64 total_size = header_offset + (u64)section_count * BUSTER_LINK_ELF_SECTION_HEADER_SIZE;
        // The debug sections and the section table are appended to the image the
        // writer above just finished, and `cursor` started at its end, so the block
        // only ever grows. Every writer that reaches here allocated that image
        // last, so the growth is a bump: taking the tail alone leaves the image
        // where it is and copies nothing. Reallocating and copying instead moved
        // 35 MB per self-host link and was 3,03% of the compile's fills from DRAM
        // (audit 2026-08-22T084855Z). The copying form stays for the case where
        // something else has allocated since — it is the same block either way.
        //
        // The tail's own allocation zeroes it. A reused arena can hand back old
        // bytes only below its dirty high-water mark, and arena_allocate_zeroed
        // clears exactly that part of the tail; above the mark the storage is
        // still the operating system's zero. The copying form takes the prefix
        // unzeroed and then the tail as a second byte-aligned allocation directly
        // after it, so the prefix memcpy overwrites is never cleared first.
        // Nothing below writes the padding before the section table, the null
        // section header, the string table's separators or the unused fields of
        // its header; they are zero from here.
        u8* bytes = result->executable.pointer;
        if (!link_arena_block_on_top(arena, bytes, result->executable.length))
        {
            bytes = arena_allocate(arena, u8, result->executable.length);
            memcpy(bytes, result->executable.pointer, result->executable.length);
        }
        u8* tail = arena_allocate_zeroed(arena, u8, total_size - result->executable.length);
        BUSTER_CHECK(tail == bytes + result->executable.length);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(link_elf_debug_kinds); index += 1)
        {
            ByteSlice data = object->sections[link_elf_debug_kinds[index]].data;
            if (data.length)
            {
                memcpy(bytes + debug_offsets[index], data.pointer, data.length);
            }
        }
        for (u32 index = 0; index < object->relocation_count; index += 1)
        {
            ObjectRelocation* relocation = &object->relocations[index];
            if (relocation->section >= OBJECT_SECTION_COUNT || !object_section_kind_is_debug((ObjectSectionKind)relocation->section) ||
                relocation->symbol >= object->symbol_count)
            {
                continue;
            }
            u32 debug_index = 0;
            while (debug_index < BUSTER_ARRAY_LENGTH(link_elf_debug_kinds) && link_elf_debug_kinds[debug_index] != (ObjectSectionKind)relocation->section)
            {
                debug_index += 1;
            }
            if (debug_index >= BUSTER_ARRAY_LENGTH(link_elf_debug_kinds))
            {
                continue;
            }
            ObjectSection* section = &object->sections[relocation->section];
            ObjectSymbol* symbol = &object->symbols[relocation->symbol];
            u64 width = relocation->kind == OBJECT_RELOCATION_ABSOLUTE64 ? 8 : 4;
            if (relocation->offset > section->data.length || width > section->data.length - relocation->offset || symbol->section >= OBJECT_SECTION_COUNT)
            {
                result->error = LINK_ERROR_RELOCATION;
                return;
            }
            u64 slot = debug_offsets[debug_index] + relocation->offset;
            if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
            {
                // DWARF 4 range and location lists use offset pairs relative to
                // the containing compilation unit's base address.  Their text
                // relocations therefore remain section-relative after linking;
                // adding the final image address here makes consumers add the CU
                // base a second time.  Other debug address attributes (line
                // addresses, DW_OP_addr, and DW_AT_low_pc) are true addresses.
                bool relative_text_range = (relocation->section == OBJECT_SECTION_DEBUG_LOC || relocation->section == OBJECT_SECTION_DEBUG_RANGES) &&
                                           symbol->section == OBJECT_SECTION_TEXT;
                u64 value = 0;
                if (relative_text_range || object_section_kind_is_debug((ObjectSectionKind)symbol->section))
                {
                    if (!link_address_addend(symbol->value, relocation->addend, &value))
                    {
                        result->error = LINK_ERROR_RELOCATION;
                        return;
                    }
                }
                else if (!link_u64_add(image_base, section_offsets[symbol->section], &value) ||
                         !link_u64_add(value, symbol->value, &value) || !link_address_addend(value, relocation->addend, &value))
                {
                    result->error = LINK_ERROR_RELOCATION;
                    return;
                }
                link_write_u64(bytes, slot, value);
            }
            else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE32 && object_section_kind_is_debug((ObjectSectionKind)symbol->section))
            {
                u64 value = 0;
                if (!link_address_addend(symbol->value, relocation->addend, &value) || value > UINT32_MAX)
                {
                    result->error = LINK_ERROR_RELOCATION;
                    return;
                }
                link_write_u32(bytes, slot, (u32)value);
            }
            else if (relocation->kind == OBJECT_RELOCATION_X86_64_ABSOLUTE32S && object_section_kind_is_debug((ObjectSectionKind)symbol->section))
            {
                s32 value = 0;
                if (!link_absolute32s_value(symbol->value, relocation->addend, &value))
                {
                    result->error = LINK_ERROR_RELOCATION;
                    return;
                }
                link_write_u32(bytes, slot, (u32)value);
            }
            else
            {
                result->error = LINK_ERROR_RELOCATION;
                return;
            }
        }
        if (symbol_layout_valid)
        {
            u64 symbol_entry = 1;
            u64 symbol_name_cursor = symbol_layout.string_offset + 1;
            for (u32 pass = 0; pass < 2; pass += 1)
            {
                bool global = pass != 0;
                for (u64 index = 0; index < (u64)object->symbol_count + layout.copy_alias_count; index += 1)
                {
                    ObjectSymbol output_symbol = link_elf_output_symbol(object, index, bytes, image_base, section_offsets, &layout);
                    ObjectSymbol* symbol = &output_symbol;
                    bool emitted = symbol->section == OBJECT_SECTION_UNDEFINED ||
                                   (symbol->section < OBJECT_SECTION_COUNT && output_section_indices[symbol->section]);
                    if (!emitted || symbol->global != global)
                    {
                        continue;
                    }
                    u64 output = symbol_layout.symbol_offset + symbol_entry * BUSTER_LINK_ELF_SYMBOL_SIZE;
                    if (symbol->name.length)
                    {
                        link_write_u32(bytes, output, (u32)(symbol_name_cursor - symbol_layout.string_offset));
                        memcpy(bytes + symbol_name_cursor, symbol->name.pointer, symbol->name.length);
                        symbol_name_cursor += symbol->name.length + 1;
                    }
                    bool thread_local_symbol = symbol->section == OBJECT_SECTION_THREAD_LOCAL_DATA || symbol->section == OBJECT_SECTION_THREAD_LOCAL_ZERO;
                    u8 binding = symbol->global ? (symbol->weak ? 0x20 : 0x10) : 0;
                    bytes[output + 4] = (u8)(binding | (thread_local_symbol ? 6 : symbol->kind == OBJECT_SYMBOL_FUNCTION ? 2 : 1));
                    bytes[output + 5] = symbol->hidden ? 2 : 0;
                    u64 value = 0;
                    if (symbol->section != OBJECT_SECTION_UNDEFINED)
                    {
                        link_write_u16(bytes, output + 6, (u16)output_section_indices[symbol->section]);
                        if (thread_local_symbol)
                        {
                            value = section_offsets[symbol->section] - section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] + symbol->value;
                        }
                        else if (object_section_kind_is_debug((ObjectSectionKind)symbol->section))
                        {
                            value = symbol->value;
                        }
                        else
                        {
                            value = image_base + section_offsets[symbol->section] + symbol->value;
                        }
                    }
                    link_write_u64(bytes, output + 8, value);
                    link_write_u64(bytes, output + 16, symbol->size);
                    symbol_entry += 1;
                }
            }
            BUSTER_CHECK(symbol_entry == symbol_layout.symbol_count + 1 && symbol_name_cursor == symbol_layout.string_offset + symbol_layout.string_size);
        }
        u64 name_cursor = section_string_offset + 1;
        for (u32 index = 0; index < descriptor_count; index += 1)
        {
            String8 name = descriptors[index].name;
            memcpy(bytes + name_cursor, name.pointer, name.length);
            name_cursor += name.length + 1;
        }
        memcpy(bytes + name_cursor, ".shstrtab", sizeof(".shstrtab"));
        for (u32 descriptor_index = 0; descriptor_index < descriptor_count; descriptor_index += 1)
        {
            u32 header_index = descriptor_index + 1;
            u64 offset = header_offset + (u64)header_index * BUSTER_LINK_ELF_SECTION_HEADER_SIZE;
            link_write_u32(bytes, offset, (u32)name_offsets[header_index]);
            LinkElfSectionDescriptor* descriptor = &descriptors[descriptor_index];
            link_write_u32(bytes, offset + 4, descriptor->type);
            link_write_u64(bytes, offset + 8, descriptor->flags);
            link_write_u64(bytes, offset + 16, descriptor->address);
            link_write_u64(bytes, offset + 24, descriptor->offset);
            link_write_u64(bytes, offset + 32, descriptor->size);
            link_write_u32(bytes, offset + 40, descriptor->link);
            link_write_u32(bytes, offset + 44, descriptor->info);
            link_write_u64(bytes, offset + 48, descriptor->alignment);
            link_write_u64(bytes, offset + 56, descriptor->entry_size);
        }
        u64 string_header = header_offset + (u64)section_string_table_index * BUSTER_LINK_ELF_SECTION_HEADER_SIZE;
        link_write_u32(bytes, string_header, (u32)name_offsets[section_string_table_index]);
        link_write_u32(bytes, string_header + 4, 3);
        link_write_u64(bytes, string_header + 24, section_string_offset);
        link_write_u64(bytes, string_header + 32, section_string_size);
        link_write_u64(bytes, string_header + 48, 1);
        link_write_u64(bytes, 40, header_offset);
        link_write_u16(bytes, 58, BUSTER_LINK_ELF_SECTION_HEADER_SIZE);
        link_write_u16(bytes, 60, (u16)section_count);
        link_write_u16(bytes, 62, (u16)section_string_table_index);
        if (result->error == LINK_ERROR_NONE)
        {
            result->executable = (ByteSlice){
                .pointer = bytes,
                .length = total_size,
            };
        }
    }
}

// ELF64 format facts shared by every ELF executable writer below. Each
// writer keeps only its own policy counts (base program-header count,
// dynamic-entry count) local, so a writer that grows cannot silently
// diverge from the format sizes the others rely on.
enum
{
    ELF_HEADER_SIZE = 64,
    ELF_PROGRAM_HEADER_SIZE = 56,
    ELF_PAGE_SIZE = 4096,
    ELF_IMAGE_BASE = 0x400000,
    ELF_MACHINE_X86_64 = 62,
    ELF_MACHINE_AARCH64 = 183,
    ELF_SYMBOL_SIZE = 24,
    ELF_RELOCATION_SIZE = 24,
    ELF_DYNAMIC_SIZE = 16,
    ELF_PLT_ENTRY_SIZE = 16,
    ELF_GOT_RESERVED_COUNT = 3,
    ELF_VERSION_NEED_SIZE = 16,
    ELF_VERSION_AUXILIARY_SIZE = 16,
    // 0 is VER_NDX_LOCAL and 1 VER_NDX_GLOBAL, so the versions an image needs
    // are numbered from 2; the top bit of a .gnu.version entry is the hidden
    // flag and never part of the index.
    ELF_VERSION_FIRST_INDEX = 2,
    ELF_VERSION_INDEX_MAX = 0x7fff,
    ELF_DYNAMIC_TAG_VERSION_SYMBOLS = 0x6ffffff0,
    ELF_DYNAMIC_TAG_VERSION_NEED = 0x6ffffffe,
    ELF_DYNAMIC_TAG_VERSION_NEED_COUNT = 0x6fffffff,
};

// The writable segment must obey the object's alignment as well as page
// alignment. Align its virtual address rather than just its file offset:
// requested alignments may exceed the fixed image base itself.
BUSTER_GLOBAL_LOCAL bool link_elf_virtual_align(u64 start, u64 alignment, u64* offset)
{
    u64 address = 0;
    bool valid = link_u64_add(ELF_IMAGE_BASE, start, &address) && link_u64_align_forward(address, alignment, &address);
    if (valid)
    {
        *offset = address - ELF_IMAGE_BASE;
    }
    return valid;
}

// Dynamic relocation types.  The two machines number theirs independently, and
// the AArch64 dynamic writer builds its image by patching the x86-64 writer's
// output, so every type that writer stamped has to be translated on the way
// out.  Naming them here keeps that translation table in one place: a type
// left behind is not a link failure but a loader applying the wrong machine's
// rule, which on AArch64 turns a copy relocation into a 16-bit absolute move.
enum
{
    ELF_RELOCATION_TYPE_X86_64_COPY = 5,
    ELF_RELOCATION_TYPE_X86_64_JUMP_SLOT = 7,
    ELF_RELOCATION_TYPE_AARCH64_COPY = 1024,
    ELF_RELOCATION_TYPE_AARCH64_JUMP_SLOT = 1026,
};

// One link-local name index serves import classification, version binding and
// copy relocation construction. Insertion follows DT_NEEDED order (runtime
// first); the first data definition and first default version win independently.
typedef struct LinkElfName LinkElfName;
struct LinkElfName
{
    String8 name;
    NativeDynamicVersionedSymbol* version;
    u32 library;
    u32 data;
    u32 alias_owner;
};

typedef struct LinkElfDataEntry LinkElfDataEntry;
struct LinkElfDataEntry
{
    NativeDynamicDataSymbol* symbol;
    u32 table_count;
    u32 group;
    u32 next;
    u32 name;
};

typedef struct LinkElfDataGroup LinkElfDataGroup;
struct LinkElfDataGroup
{
    NativeDynamicDataSymbol* table;
    u64 address;
    u32 first;
    u32 last;
    u32 owner;
};

typedef struct LinkElfIndex LinkElfIndex;
struct LinkElfIndex
{
    Arena* arena;
    LinkElfName* names;
    LinkElfDataEntry* data;
    LinkElfDataGroup* groups;
    u32* name_slots;
    u32* group_slots;
    u64 name_capacity;
    u64 group_capacity;
    u32 name_count;
    u32 data_count;
    u32 group_count;
    bool exports_complete;
};

// Counts are bounded before either rounding or multiplying. UINT32_MAX is
// reserved for empty slots and links; no table can fill even half its buckets.
BUSTER_GLOBAL_LOCAL u64 link_elf_index_capacity(u64 count)
{
    u64 capacity = 0;
    if (count && count < UINT32_MAX)
    {
        capacity = 1;
        while (capacity < count * 2) capacity *= 2;
    }
    return capacity;
}

BUSTER_GLOBAL_LOCAL LinkElfName* link_elf_name(LinkElfIndex* index, String8 name, bool insert)
{
    LinkElfName* result = 0;
    if (index->name_capacity)
    {
        u64 mask = index->name_capacity - 1;
        u64 bucket = buster_hash_64((u8*)name.pointer, name.length) & mask;
        for (u64 probe = 0; !result && probe < index->name_capacity; probe += 1)
        {
            u32* slot = index->name_slots + bucket;
            if (*slot == UINT32_MAX)
            {
                if (insert)
                {
                    *slot = index->name_count++;
                    result = index->names + *slot;
                    *result = (LinkElfName){.name = name, .data = UINT32_MAX, .alias_owner = UINT32_MAX};
                }
                break;
            }
            if (string_equal(index->names[*slot].name, name)) result = index->names + *slot;
            bucket = (bucket + 1) & mask;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL u32 link_elf_data_group(LinkElfIndex* index, NativeDynamicDataSymbol* table, u64 address)
{
    u32 result = UINT32_MAX;
    u64 key[] = {(u64)table, address};
    u64 mask = index->group_capacity - 1;
    u64 bucket = buster_hash_64((u8*)key, sizeof(key)) & mask;
    for (u64 probe = 0; result == UINT32_MAX && probe < index->group_capacity; probe += 1)
    {
        u32* slot = index->group_slots + bucket;
        if (*slot == UINT32_MAX)
        {
            *slot = index->group_count++;
            index->groups[*slot] = (LinkElfDataGroup){.table = table, .address = address,
                .first = UINT32_MAX, .last = UINT32_MAX, .owner = UINT32_MAX};
        }
        LinkElfDataGroup* group = index->groups + *slot;
        if (group->table == table && group->address == address) result = *slot;
        bucket = (bucket + 1) & mask;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool link_elf_index_initialize(Arena* arena, NativeExecutableLinkOptions options, LinkElfIndex* index)
{
    *index = (LinkElfIndex){.arena = arena, .exports_complete = options.runtime_exports_known};
    bool valid = options.dynamic_library_count != UINT32_MAX && (!options.dynamic_library_count || options.dynamic_libraries) &&
                 (!options.runtime_data_symbol_count || options.runtime_data_symbols) &&
                 (!options.runtime_versioned_symbol_count || options.runtime_versioned_symbols);
    u64 data_count = options.runtime_data_symbol_count;
    u64 name_count = data_count + options.runtime_versioned_symbol_count;
    for (u32 library = 0; valid && library < options.dynamic_library_count; library += 1)
    {
        NativeDynamicLibrary* source = options.dynamic_libraries + library;
        valid = (!source->exported_data_symbol_count || source->exported_data_symbols) &&
                (!source->versioned_symbol_count || source->versioned_symbols);
        data_count += source->exported_data_symbol_count;
        name_count += (u64)source->exported_data_symbol_count + source->versioned_symbol_count;
        valid = valid && name_count < UINT32_MAX;
        index->exports_complete = index->exports_complete && source->exports_known;
    }
    valid = valid && name_count < UINT32_MAX;
    if (valid)
    {
        index->name_capacity = link_elf_index_capacity(name_count);
        index->group_capacity = link_elf_index_capacity(data_count);
        // Include alignment for all five arrays in the preflight. Aggregate
        // counts are already below 2^32, so these byte products cannot wrap.
        u64 bytes = name_count * sizeof(LinkElfName) + data_count * (sizeof(LinkElfDataEntry) + sizeof(LinkElfDataGroup)) +
                    (index->name_capacity + index->group_capacity) * sizeof(u32) + 5 * BUSTER_ALIGN_OF(LinkElfName);
        valid = bytes <= arena->reserved_size - arena->position;
    }
    if (valid)
    {
        index->names = arena_allocate(arena, LinkElfName, name_count);
        index->data = arena_allocate(arena, LinkElfDataEntry, data_count);
        index->groups = arena_allocate(arena, LinkElfDataGroup, data_count);
        index->name_slots = arena_allocate(arena, u32, index->name_capacity);
        index->group_slots = arena_allocate(arena, u32, index->group_capacity);
        memset(index->name_slots, 0xff, index->name_capacity * sizeof(u32));
        memset(index->group_slots, 0xff, index->group_capacity * sizeof(u32));
    }
    for (u32 library = 0; valid && library <= options.dynamic_library_count; library += 1)
    {
        NativeDynamicDataSymbol* data = library ? options.dynamic_libraries[library - 1].exported_data_symbols : options.runtime_data_symbols;
        u32 count = library ? options.dynamic_libraries[library - 1].exported_data_symbol_count : options.runtime_data_symbol_count;
        for (u32 entry = 0; valid && entry < count; entry += 1)
        {
            NativeDynamicDataSymbol* symbol = data + entry;
            valid = !symbol->name.length || symbol->name.pointer;
            if (valid)
            {
                LinkElfName* name = link_elf_name(index, symbol->name, true);
                u32 group_index = link_elf_data_group(index, data, symbol->address);
                LinkElfDataGroup* group = index->groups + group_index;
                u32 data_index = index->data_count++;
                index->data[data_index] = (LinkElfDataEntry){.symbol = symbol, .table_count = count, .group = group_index,
                    .next = UINT32_MAX, .name = (u32)(name - index->names)};
                if (name->data == UINT32_MAX) name->data = data_index;
                if (group->last != UINT32_MAX) index->data[group->last].next = data_index;
                else group->first = data_index;
                group->last = data_index;
            }
        }
        NativeDynamicVersionedSymbol* versions = library ? options.dynamic_libraries[library - 1].versioned_symbols : options.runtime_versioned_symbols;
        count = library ? options.dynamic_libraries[library - 1].versioned_symbol_count : options.runtime_versioned_symbol_count;
        for (u32 entry = 0; valid && entry < count; entry += 1)
        {
            NativeDynamicVersionedSymbol* symbol = versions + entry;
            valid = (!symbol->name.length || symbol->name.pointer) && (!symbol->version.length || symbol->version.pointer);
            if (valid)
            {
                LinkElfName* name = link_elf_name(index, symbol->name, true);
                if (!name->version || (!name->version->has_default && symbol->has_default))
                {
                    name->version = symbol;
                    name->library = library;
                }
            }
        }
    }
    return valid;
}

BUSTER_GLOBAL_LOCAL bool link_elf_symbol_version(LinkElfIndex* index, String8 name, u32* library_index, String8* version, bool* no_default)
{
    LinkElfName* found = link_elf_name(index, name, false);
    bool result = found && found->version && found->version->has_default;
    *no_default = found && found->version && !result;
    if (result)
    {
        *library_index = found->library;
        *version = found->version->version;
    }
    return result;
}


// An undefined symbol only weak references name resolves to address zero
// rather than to anything in the image: ELF gives an unresolved weak
// reference the value 0, which is how a program asks whether a symbol is
// present at all. musl's static startup is the case that matters --
// arch/x86_64/crt_arch.h takes the address of a weak hidden `_DYNAMIC` and
// reads zero to learn the program is static -- so every startup object a
// libc ships depends on this.
//
// Whether the answer is decided here or by the dynamic loader is exactly the
// question of whether the reference can be preempted. Hidden visibility says
// it cannot, and a static image has no loader to ask, so both resolve to zero
// at link time, whatever any library exports.
//
// A default-visibility weak reference can be preempted, so the loader is the
// party that answers it -- but only if some library the image names actually
// defines it. Asking the loader for a name nothing has is how a reference
// nothing defines came out non-zero: the import's own PLT thunk or copy slot
// is what answers. So such a reference is promoted to an import only when a
// library in the link publishes a default definition of the name, which is
// the same question `link_elf_symbol_version` answers for the version to
// record; a name defined only as `name@VER` has nothing an unversioned
// reference can bind to and is worth zero too. Where the link could not read
// every one of its libraries, an absent name proves nothing -- ignorance is
// not evidence of absence -- so the reference stays the import it was before
// there was an export list to consult.
BUSTER_GLOBAL_LOCAL bool link_elf_symbol_resolves_to_zero(LinkElfIndex* exports, ObjectSymbol const* symbol, bool dynamic_image)
{
    bool result = symbol->section == OBJECT_SECTION_UNDEFINED && symbol->weak;
    if (result && dynamic_image && !symbol->hidden)
    {
        u32 library_index = 0;
        String8 version = {0};
        bool no_default = false;
        result = exports->exports_complete && !link_elf_symbol_version(exports, symbol->name, &library_index, &version, &no_default);
    }

    return result;
}

// Whether an undefined symbol is one the image needs the dynamic shape for.
// A weak reference that resolves to zero is not: it is worth zero wherever it
// is linked, so a program whose only undefined symbols are those stays the
// static image it would have been without them. Every ELF path that chooses
// between the static and dynamic writers asks this, and the dynamic writers
// ask it again to number their imports, so the two cannot disagree about
// which symbols reach .dynsym.
BUSTER_GLOBAL_LOCAL bool link_elf_symbol_needs_dynamic_import(LinkElfIndex* exports, ObjectSymbol const* symbol)
{
    return symbol->section == OBJECT_SECTION_UNDEFINED && !link_elf_symbol_resolves_to_zero(exports, symbol, true);
}

// A strong undefined reference no library on the link line publishes a
// default definition of.  The static writer refuses every undefined symbol,
// but the dynamic writers refused none, so `char fdwalk(); return fdwalk();`
// linked into an executable whose .dynsym asks the loader for a name nothing
// exports -- ld reports "undefined reference" at link time, and every
// autoconf AC_CHECK_FUNC probe reads that difference, so CPython's configure
// found fdwalk, fork1, plock, rtpspawn and _getpty on Linux.  The refusal
// asks the same questions the weak promotion above asks: only when every
// library's export list was read is absence evidence of absence, and a name
// published only as `name@VER` has no default an unversioned reference could
// bind to, which is ld's answer too.
BUSTER_GLOBAL_LOCAL bool link_elf_strong_import_unresolved(LinkElfIndex* exports, ObjectSymbol const* symbol)
{
    bool result = false;
    // __tls_get_addr is defined by the dynamic loader rather than by
    // libc.so.6 -- glibc's libc.so linker script names ld-linux beside the
    // library so ld resolves it, but the driver's export scan reads only the
    // library file.  The writer names that same loader in PT_INTERP, so the
    // name is answered in every image this writer can produce.
    if (!symbol->weak && exports->exports_complete && !string_equal(symbol->name, S8("__tls_get_addr")))
    {
        u32 library_index = 0;
        String8 version = {0};
        bool no_default = false;
        result = !link_elf_symbol_version(exports, symbol->name, &library_index, &version, &no_default);
    }

    return result;
}

// The UEFI writer places an image but synthesizes no entry point of its own
// -- the entry is the firmware's call to the application, with the image
// handle and the system table in the argument registers -- so it has nowhere
// to put the initializer sequence, and no loader that would walk the arrays
// on its behalf the way dyld walks the Mach-O writer's.  It still has to take
// the arrays off the object, because every writer places every non-debug
// section it is given and a section with no offset of its own would be
// written over the image header; what it must not do is drop them silently,
// which is the state issue 771 found the whole attribute in.  A refusal names
// the gap instead (issue 779).
BUSTER_GLOBAL_LOCAL bool link_initializer_plan_empty(LinkInitializerPlan const* plan)
{
    return !plan->constructor_count && !plan->destructor_count;
}

// The name of the first initializer a refusing writer could not place, so the
// diagnostic points at a function in the program rather than at the format.
BUSTER_GLOBAL_LOCAL String8 link_initializer_plan_first_name(ObjectFile* object, LinkInitializerPlan const* plan)
{
    String8 result = {0};
    u32 symbol = plan->constructor_count ? plan->constructors[0].symbol : plan->destructor_count ? plan->destructors[0].symbol : UINT32_MAX;
    if (symbol < object->symbol_count)
    {
        result = object->symbols[symbol].name;
    }

    return result;
}

// Patches the rel32 of every initializer call the entry stub emitted.  Each
// target is the symbol that initializer's array slot named plus that slot's
// addend, at the image address this layout gave it -- the same arithmetic the
// call to `main` beside it takes.
BUSTER_GLOBAL_LOCAL bool link_x86_patch_initializer_calls(u8* bytes, ObjectFile* object, LinkInitializerPlan const* plan, u64 const* section_offsets,
                                                          u64 image_base, u64 entry_stub_offset, u32 const* displacement_offsets)
{
    bool result = true;
    u32 count = plan->constructor_count + plan->destructor_count;
    for (u32 index = 0; index < count && result; index += 1)
    {
        LinkInitializerEntry entry = index < plan->constructor_count ? plan->constructors[index] : plan->destructors[index - plan->constructor_count];
        ObjectSymbol* symbol = entry.symbol < object->symbol_count ? object->symbols + entry.symbol : 0;
        if (!symbol || symbol->section == OBJECT_SECTION_UNDEFINED || symbol->section >= OBJECT_SECTION_COUNT)
        {
            result = false;
        }
        else
        {
            u64 target = image_base + section_offsets[symbol->section] + symbol->value + (u64)entry.addend;
            u64 field = entry_stub_offset + displacement_offsets[index];
            s64 displacement = (s64)target - (s64)(image_base + field + 4);
            result = displacement >= INT32_MIN && displacement <= INT32_MAX;
            if (result)
            {
                link_write_u32(bytes, field, (u32)(s32)displacement);
            }
        }
    }

    return result;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_elf64_x86_64(Arena* arena, ObjectFile* object, NativeExecutableLinkOptions options)
{
    NativeExecutableLinkResult result = {0};
    u32 entry_stub_size = 0;
    u32 entry_call_displacement_offset = 0;
    if ((options.dynamic_library_count && !options.dynamic_libraries) || (options.runtime_exported_symbol_count && !options.runtime_exported_symbols) ||
        object->section_count < OBJECT_SECTION_COUNT || !object->sections || (object->symbol_count && !object->symbols) ||
        (object->relocation_count && !object->relocations))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    ObjectFile stripped_object = {0};
    LinkInitializerPlan plan = {0};
    if (!link_initializer_plan_build(arena, object, &stripped_object, &plan))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    object = &stripped_object;
    u8* entry_stub = arena_allocate(arena, u8, link_x86_elf_entry_stub_capacity(&plan));
    u32* initializer_displacement_offsets =
        arena_allocate(arena, u32, plan.constructor_count + plan.destructor_count ? plan.constructor_count + plan.destructor_count : 1);
    buster_x86_metadata_prewarm();
    // No libc in this image: every symbol is defined here, so the freestanding
    // syscall shape is the only way to terminate (see
    // link_x86_build_elf_entry_stub).
    if (!link_x86_build_elf_entry_stub(entry_stub, link_x86_elf_entry_stub_capacity(&plan), &entry_stub_size, &entry_call_displacement_offset, false, 0, 0, 0,
                                       &plan, initializer_displacement_offsets))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
    {
        ObjectSymbol* symbol = &object->symbols[symbol_index];
        if (symbol->section == OBJECT_SECTION_UNDEFINED && !link_elf_symbol_resolves_to_zero(0, symbol, false))
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = symbol->name;
            return result;
        }
    }
    String8 entry_name = options.entry_symbol.length ? options.entry_symbol : S8("main");
    u32 entry_symbol_index = link_symbol_find(object, entry_name);
    if (entry_symbol_index == UINT32_MAX || object->symbols[entry_symbol_index].section == OBJECT_SECTION_UNDEFINED ||
        object->symbols[entry_symbol_index].kind != OBJECT_SYMBOL_FUNCTION)
    {
        result.error = LINK_ERROR_ENTRY_SYMBOL;
        result.symbol = entry_name;
        return result;
    }
    LinkElfEhFrameTable eh_frame_table = link_elf_eh_frame_table_build(arena, object);
    if (!eh_frame_table.valid)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    u64 eh_frame_header_size = eh_frame_table.count ? 12 + (u64)eh_frame_table.count * 8 : 0;
    bool has_writable = object->sections[OBJECT_SECTION_DATA].data.length || object->sections[OBJECT_SECTION_ZERO].virtual_size;
    u32 load_program_header_count = has_writable ? 2 : 1;
    u32 program_header_count = load_program_header_count + (eh_frame_header_size != 0);
    u64 header_end = ELF_HEADER_SIZE + (u64)program_header_count * ELF_PROGRAM_HEADER_SIZE;
    u64 section_offsets[OBJECT_SECTION_COUNT] = {0};
    u64 entry_stub_offset = align_forward(header_end, 16);
    section_offsets[OBJECT_SECTION_TEXT] = align_forward(entry_stub_offset + entry_stub_size, object->sections[OBJECT_SECTION_TEXT].alignment);
    section_offsets[OBJECT_SECTION_READ_ONLY_DATA] = align_forward(section_offsets[OBJECT_SECTION_TEXT] + object->sections[OBJECT_SECTION_TEXT].data.length,
                                                                   object->sections[OBJECT_SECTION_READ_ONLY_DATA].alignment);
    u64 eh_frame_header_offset = align_forward(section_offsets[OBJECT_SECTION_READ_ONLY_DATA] + object->sections[OBJECT_SECTION_READ_ONLY_DATA].data.length, 4);
    section_offsets[OBJECT_SECTION_UNWIND] = align_forward(eh_frame_header_offset + eh_frame_header_size, object->sections[OBJECT_SECTION_UNWIND].alignment);
    u64 read_only_end = section_offsets[OBJECT_SECTION_UNWIND] + object->sections[OBJECT_SECTION_UNWIND].data.length;
    if (!link_elf_virtual_align(read_only_end, BUSTER_MAX((u32)ELF_PAGE_SIZE, object->sections[OBJECT_SECTION_DATA].alignment),
                                &section_offsets[OBJECT_SECTION_DATA]))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u64 file_size = object->sections[OBJECT_SECTION_DATA].data.length ? section_offsets[OBJECT_SECTION_DATA] + object->sections[OBJECT_SECTION_DATA].data.length
                                                                      : read_only_end;
    if (!link_elf_virtual_align(BUSTER_MAX(file_size, section_offsets[OBJECT_SECTION_DATA]), object->sections[OBJECT_SECTION_ZERO].alignment,
                                &section_offsets[OBJECT_SECTION_ZERO]))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u64 writable_memory_end = section_offsets[OBJECT_SECTION_ZERO] + object->sections[OBJECT_SECTION_ZERO].virtual_size;
    if (file_size > UINT32_MAX)
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    result.executable = (ByteSlice){
        // The image is written section by section over a zero background, and
        // the background is what a fresh arena mapping already is: the fill
        // now covers only the arena's dirty prefix, which for the one image a
        // link produces is nothing at all.
        .pointer = arena_allocate_zeroed(arena, u8, file_size),
        .length = file_size,
    };
    u8* bytes = result.executable.pointer;
    memcpy(bytes + entry_stub_offset, entry_stub, entry_stub_size);
    for (u32 section = 0; section < OBJECT_SECTION_COUNT; section += 1)
    {
        if (object_section_kind_is_debug((ObjectSectionKind)section))
        {
            continue;
        }
        ByteSlice data = object->sections[section].data;
        if (data.length)
        {
            memcpy(bytes + section_offsets[section], data.pointer, data.length);
        }
    }
    u64 image_base = ELF_IMAGE_BASE;
    ObjectSymbol* entry_symbol = &object->symbols[entry_symbol_index];
    u64 entry_address = image_base + section_offsets[entry_symbol->section] + entry_symbol->value;
    u64 call_displacement_offset = entry_stub_offset + entry_call_displacement_offset;
    s64 call_displacement = (s64)entry_address - (s64)(image_base + call_displacement_offset + 4);
    if (call_displacement < INT32_MIN || call_displacement > INT32_MAX)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    link_write_u32(bytes, call_displacement_offset, (u32)(s32)call_displacement);
    if (!link_x86_patch_initializer_calls(bytes, object, &plan, section_offsets, image_base, entry_stub_offset, initializer_displacement_offsets))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation* relocation = &object->relocations[index];
        if (relocation->section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation->section))
        {
            continue;
        }
        if (relocation->section >= OBJECT_SECTION_COUNT || relocation->symbol >= object->symbol_count)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        ObjectSection* section = &object->sections[relocation->section];
        u64 width = relocation->kind == OBJECT_RELOCATION_ABSOLUTE64 ? 8 : 4;
        if (relocation->offset > section->data.length || width > section->data.length - relocation->offset)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        ObjectSymbol* symbol = &object->symbols[relocation->symbol];
        // Address zero is the answer for a reference nothing defines and
        // nothing can define; every other undefined symbol was rejected above.
        bool absent_weak = link_elf_symbol_resolves_to_zero(0, symbol, false);
        if (!absent_weak && symbol->section >= OBJECT_SECTION_COUNT)
        {
            result.error = LINK_ERROR_RELOCATION;
            result.symbol = symbol->name;
            return result;
        }
        u64 symbol_address = 0;
        if (!absent_weak && (!link_u64_add(image_base, section_offsets[symbol->section], &symbol_address) ||
                             !link_u64_add(symbol_address, symbol->value, &symbol_address)))
        {
            result.error = LINK_ERROR_RELOCATION;
            result.symbol = symbol->name;
            return result;
        }
        u64 place_address = image_base + section_offsets[relocation->section] + relocation->offset;
        u64 output_offset = section_offsets[relocation->section] + relocation->offset;
        BusterX86MetadataGotPatch got_patch = BUSTER_X86_METADATA_GOT_PATCH_NONE;
        if (object_relocation_kind_is_x86_got(relocation->kind))
        {
            got_patch = link_x86_relax_got_reference(relocation->kind, relocation->addend, bytes, output_offset, section_offsets[relocation->section],
                                                     section_offsets[relocation->section] + section->data.length);
            if (got_patch == BUSTER_X86_METADATA_GOT_PATCH_NONE)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
        }
        // A relaxed GOT load and a PLT call both patch the same rel32 the
        // direct form does, against the same address: this image has one
        // definition of every name in it. A conversion that answers with the
        // address as an immediate patches the same field with the address
        // itself, and the GOT load's -4 has no part in that value.
        if (relocation->kind == OBJECT_RELOCATION_X86_64_PC32 || relocation->kind == OBJECT_RELOCATION_X86_64_PLT32 ||
            got_patch == BUSTER_X86_METADATA_GOT_PATCH_PC32)
        {
            s64 value = 0;
            if (!link_address_difference(symbol_address, place_address, relocation->addend, &value) || value < INT32_MIN || value > INT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)(s32)value);
        }
        else if (got_patch == BUSTER_X86_METADATA_GOT_PATCH_ABSOLUTE32)
        {
            s32 value = 0;
            if (!link_absolute32s_value(symbol_address, 0, &value))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)value);
        }
        else if (relocation->kind == OBJECT_RELOCATION_X86_64_ABSOLUTE32S)
        {
            s32 value = 0;
            if (!link_absolute32s_value(symbol_address, relocation->addend, &value))
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)value);
        }
        // R_X86_64_32 zero-extends: -fno-pic small-model foreign objects
        // (clang emits it for every address literal there) are valid in an
        // image whose base keeps the whole file below 4GB.
        else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE32)
        {
            u64 value = 0;
            if (!link_address_addend(symbol_address, relocation->addend, &value) || value > UINT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)value);
        }
        else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
        {
            u64 value = 0;
            if (!link_address_addend(symbol_address, relocation->addend, &value))
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u64(bytes, output_offset, value);
        }
        else
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
    }
    if (!link_elf_eh_frame_header_write(bytes, file_size, &eh_frame_table, object, image_base, section_offsets, eh_frame_header_offset))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    bytes[0] = 0x7f;
    bytes[1] = 'E';
    bytes[2] = 'L';
    bytes[3] = 'F';
    bytes[4] = 2;
    bytes[5] = 1;
    bytes[6] = 1;
    link_write_u16(bytes, 16, 2);
    link_write_u16(bytes, 18, ELF_MACHINE_X86_64);
    link_write_u32(bytes, 20, 1);
    link_write_u64(bytes, 24, image_base + entry_stub_offset);
    link_write_u64(bytes, 32, ELF_HEADER_SIZE);
    link_write_u16(bytes, 52, ELF_HEADER_SIZE);
    link_write_u16(bytes, 54, ELF_PROGRAM_HEADER_SIZE);
    link_write_u16(bytes, 56, (u16)program_header_count);
    u64 program_header = ELF_HEADER_SIZE;
    link_write_u32(bytes, program_header, 1);
    link_write_u32(bytes, program_header + 4, 5);
    link_write_u64(bytes, program_header + 16, image_base);
    link_write_u64(bytes, program_header + 24, image_base);
    link_write_u64(bytes, program_header + 32, read_only_end);
    link_write_u64(bytes, program_header + 40, read_only_end);
    link_write_u64(bytes, program_header + 48, ELF_PAGE_SIZE);
    if (load_program_header_count == 2)
    {
        program_header += ELF_PROGRAM_HEADER_SIZE;
        u64 data_size = object->sections[OBJECT_SECTION_DATA].data.length;
        u64 writable_file_size = file_size > section_offsets[OBJECT_SECTION_DATA] ? file_size - section_offsets[OBJECT_SECTION_DATA] : 0;
        u64 writable_memory_size = writable_memory_end - section_offsets[OBJECT_SECTION_DATA];
        link_write_u32(bytes, program_header, 1);
        link_write_u32(bytes, program_header + 4, 6);
        link_write_u64(bytes, program_header + 8, section_offsets[OBJECT_SECTION_DATA]);
        link_write_u64(bytes, program_header + 16, image_base + section_offsets[OBJECT_SECTION_DATA]);
        link_write_u64(bytes, program_header + 24, image_base + section_offsets[OBJECT_SECTION_DATA]);
        link_write_u64(bytes, program_header + 32, writable_file_size);
        link_write_u64(bytes, program_header + 40, BUSTER_MAX(data_size, writable_memory_size));
        link_write_u64(bytes, program_header + 48, ELF_PAGE_SIZE);
    }
    if (eh_frame_header_size)
    {
        program_header = ELF_HEADER_SIZE + (u64)load_program_header_count * ELF_PROGRAM_HEADER_SIZE;
        link_write_u32(bytes, program_header, 0x6474e550);
        link_write_u32(bytes, program_header + 4, 4);
        link_write_u64(bytes, program_header + 8, eh_frame_header_offset);
        link_write_u64(bytes, program_header + 16, image_base + eh_frame_header_offset);
        link_write_u64(bytes, program_header + 24, image_base + eh_frame_header_offset);
        link_write_u64(bytes, program_header + 32, eh_frame_header_size);
        link_write_u64(bytes, program_header + 40, eh_frame_header_size);
        link_write_u64(bytes, program_header + 48, 4);
    }
    link_elf_section_table_append(arena, &result, object, image_base, section_offsets,
                                  (LinkElfSectionTableLayout){
                                      .eh_frame_header_offset = eh_frame_header_offset,
                                      .eh_frame_header_size = eh_frame_header_size,
                                  });
    if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
    {
        result.error = LINK_ERROR_FILE_WRITE;
    }
    return result;
}

// Both ELF dynamic writers name libc first in DT_NEEDED, so `exit` is always
// resolvable through the PLT there.  Hand back the program with a synthetic
// undefined `exit` appended when it has no symbol of that name, so the hosted
// entry stub has something to call (C 5.1.2.2.3; see
// link_x86_build_elf_entry_stub).  A program that defines its own `exit`
// keeps it and the stub calls that definition directly.  The AArch64 writer
// must run this before handing the object to the x86-64 writer, because it
// re-derives the same import numbering from the same symbol table afterwards
// and the two would otherwise disagree by one import.
//
// Every hosted image registers the loader finalizer through __cxa_atexit.
// A program with its own destructors uses that same import for its runner.
// The name is __cxa_atexit because plain atexit lives in libc_nonshared.a,
// while the shared libc exports this three-argument form.
BUSTER_GLOBAL_LOCAL bool link_elf_hosted_exit_symbol(Arena* arena, ObjectFile* object, ObjectFile* hosted_out, u32* exit_symbol_index_out,
                                                     u32* atexit_symbol_index_out)
{
    static String8 const hosted_names[] = {S8_INITIALIZER("exit"), S8_INITIALIZER("__cxa_atexit")};
    bool valid = true;
    u32 wanted = BUSTER_ARRAY_LENGTH(hosted_names);
    u32 indices[BUSTER_ARRAY_LENGTH(hosted_names)] = {UINT32_MAX, UINT32_MAX};
    u32 missing = 0;
    *hosted_out = *object;
    for (u32 name_index = 0; name_index < wanted; name_index += 1)
    {
        indices[name_index] = link_symbol_find(object, hosted_names[name_index]);
        missing += indices[name_index] == UINT32_MAX;
    }
    if (missing)
    {
        if (object->symbol_count > UINT32_MAX - missing)
        {
            valid = false;
        }
        else
        {
            ObjectSymbol* hosted_symbols = arena_allocate(arena, ObjectSymbol, (u64)object->symbol_count + missing);
            if (object->symbol_count)
            {
                memcpy(hosted_symbols, object->symbols, sizeof(*hosted_symbols) * object->symbol_count);
            }
            u32 appended = 0;
            for (u32 name_index = 0; name_index < wanted; name_index += 1)
            {
                if (indices[name_index] == UINT32_MAX)
                {
                    hosted_symbols[object->symbol_count + appended] = (ObjectSymbol){
                        .name = hosted_names[name_index],
                        .section = OBJECT_SECTION_UNDEFINED,
                        .kind = OBJECT_SYMBOL_FUNCTION,
                        .global = true,
                    };
                    indices[name_index] = object->symbol_count + appended;
                    appended += 1;
                }
            }
            hosted_out->symbols = hosted_symbols;
            hosted_out->symbol_count = object->symbol_count + missing;
        }
    }
    *exit_symbol_index_out = indices[0];
    *atexit_symbol_index_out = indices[1];
    return valid;
}

// Where a call the hosted entry stub makes to the C runtime lands: the
// symbol's PLT entry when the name is imported, or the program's own
// definition when it has one.  `plt_address` is the image address of the
// reserved first entry, so entry N sits one stride past it, and both ELF
// dynamic writers ask the same question about the same two names.
BUSTER_GLOBAL_LOCAL bool link_elf_hosted_call_address(ObjectFile* object, u32 symbol_index, u32 const* import_indices, u64 const* section_offsets,
                                                      u64 image_base, u64 plt_address, u64* address_out)
{
    bool valid = false;
    ObjectSymbol* symbol = &object->symbols[symbol_index];
    if (symbol->section == OBJECT_SECTION_UNDEFINED)
    {
        u32 import_index = import_indices[symbol_index];
        valid = import_index != UINT32_MAX;
        if (valid)
        {
            *address_out = plt_address + ((u64)import_index + 1) * ELF_PLT_ENTRY_SIZE;
        }
    }
    else
    {
        valid = true;
        *address_out = image_base + section_offsets[symbol->section] + symbol->value;
    }

    return valid;
}

// The System V hash of a version string.  .gnu.version_r records it beside
// every version it names so the loader can match the library's own
// .gnu.version_d entry without comparing strings.
BUSTER_GLOBAL_LOCAL u32 link_elf_hash(String8 name)
{
    u32 result = 0;
    for (u64 index = 0; index < name.length; index += 1)
    {
        result = (result << 4) + (u8)name.pointer[index];
        u32 high = result & UINT32_C(0xf0000000);
        result ^= high >> 24;
        result &= ~high;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_elf64_x86_64_dynamic(Arena* arena, ObjectFile* object,
                                                                                           NativeExecutableLinkOptions options, LinkElfIndex* exports)
{
    NativeExecutableLinkResult result = {0};
    enum
    {
        ELF_BASE_PROGRAM_HEADER_COUNT = 7,
    };
    u32 entry_stub_size = 0;
    u32 entry_call_displacement_offset = 0;
    u32 entry_exit_displacement_offset = 0;
    u32 entry_atexit_displacement_offset = 0;
    u32 loader_atexit_displacement_offset = 0;
    static char8 const interpreter[] = "/lib64/ld-linux-x86-64.so.2";
    static char8 const library_name[] = "libc.so.6";
    if ((options.dynamic_library_count && !options.dynamic_libraries) || object->section_count < OBJECT_SECTION_COUNT || !object->sections ||
        (object->symbol_count && !object->symbols) || (object->relocation_count && !object->relocations))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    buster_x86_metadata_prewarm();
    // Whether this image needs the dynamic shape at all is decided on the
    // program as given, before the synthetic `exit` import below could make
    // every image look like it has one.
    bool has_thread_local_data =
        object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length != 0 || object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size != 0;
    bool has_undefined_symbol = false;
    for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
    {
        has_undefined_symbol = has_undefined_symbol || link_elf_symbol_needs_dynamic_import(exports, &object->symbols[symbol_index]);
    }
    if (!has_undefined_symbol && !has_thread_local_data && !options.dynamic_library_count)
    {
        return link_native_executable_elf64_x86_64(arena, object, options);
    }
    // The synthetic symbols are appended before the arrays are stripped,
    // because whether the program has a destructor is a fact about the arrays;
    // the plan the stub is built from then comes off the object that already
    // carries them, which is the order the AArch64 writer uses too.
    ObjectFile hosted_object = {0};
    u32 exit_symbol_index = 0;
    u32 atexit_symbol_index = 0;
    if (!link_elf_hosted_exit_symbol(arena, object, &hosted_object, &exit_symbol_index, &atexit_symbol_index))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    object = &hosted_object;
    ObjectFile stripped_object = {0};
    LinkInitializerPlan plan = {0};
    if (!link_initializer_plan_build(arena, object, &stripped_object, &plan))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    object = &stripped_object;
    u8* entry_stub = arena_allocate(arena, u8, link_x86_elf_entry_stub_capacity(&plan));
    u32* initializer_displacement_offsets =
        arena_allocate(arena, u32, plan.constructor_count + plan.destructor_count ? plan.constructor_count + plan.destructor_count : 1);
    if (!link_x86_build_elf_entry_stub(entry_stub, link_x86_elf_entry_stub_capacity(&plan), &entry_stub_size, &entry_call_displacement_offset, true,
                                       &entry_exit_displacement_offset, &entry_atexit_displacement_offset, &loader_atexit_displacement_offset, &plan, initializer_displacement_offsets))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    u32 import_count = 0;
    u64 imported_name_size = 0;
    u32* import_indices = arena_allocate(arena, u32, object->symbol_count);
    ObjectSymbolKind* import_kinds = arena_allocate(arena, ObjectSymbolKind, object->symbol_count);
    u32* import_name_offsets = arena_allocate(arena, u32, object->symbol_count);
    String8* import_names = arena_allocate(arena, String8, object->symbol_count);
    for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
    {
        import_indices[symbol_index] = UINT32_MAX;
        ObjectSymbol* symbol = &object->symbols[symbol_index];
        if (!link_elf_symbol_needs_dynamic_import(exports, symbol))
        {
            continue;
        }
        if (link_elf_strong_import_unresolved(exports, symbol))
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = symbol->name;
            return result;
        }
        if (!symbol->global || (symbol->kind != OBJECT_SYMBOL_FUNCTION && symbol->kind != OBJECT_SYMBOL_DATA) || !symbol->name.length ||
            symbol->name.length > UINT32_MAX ||
            imported_name_size > UINT32_MAX - symbol->name.length - 1)
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = symbol->name;
            return result;
        }
        import_indices[symbol_index] = import_count;
        import_kinds[import_count] = symbol->kind;
        import_names[import_count] = symbol->name;
        imported_name_size += symbol->name.length + 1;
        import_count += 1;
    }
    // Direct references to imported data (for example libc's stdin/stdout/
    // stderr variables) use copy relocations.  Reserve local storage for each
    // imported object so the PC-relative references in non-PIC upstream
    // objects remain within the executable's image; the dynamic loader fills
    // those slots from the shared library.
    //
    // What is reserved is the library's object, not the one name this program
    // spelled.  A shared library exports one object under every name it was
    // aliased to — glibc publishes `environ`, `_environ` and `__environ` at
    // one address — and a definition in the executable takes precedence over
    // the library's own for all of them.  An executable that defines only the
    // referenced name therefore leaves libc writing `__environ` into libc's
    // storage while the program reads a copy taken before startup ran, which
    // is how `extern char **environ` came to read null.  So each slot carries
    // every exported name at its address, takes the library's own size, and is
    // shared by two imports that name one object.  When the library's symbol
    // table was not read, the slot keeps the pointer-sized shape it had.
    String8* alias_names = arena_allocate(arena, String8, (u64)exports->data_count + 1);
    u32* import_alias_first = arena_allocate(arena, u32, import_count);
    u32* import_alias_counts = arena_allocate(arena, u32, import_count);
    u32* import_copy_owners = arena_allocate(arena, u32, import_count);
    u64* import_copy_sizes = arena_allocate(arena, u64, import_count);
    LinkGlobalSymbolTable globals = {0};
    bool globals_valid = true;
    if (exports->data_count)
    {
        u64 capacity = link_elf_index_capacity(object->symbol_count);
        globals_valid = object->symbol_count < UINT32_MAX &&
                        capacity * sizeof(u32) + BUSTER_ALIGN_OF(u32) <= exports->arena->reserved_size - exports->arena->position;
        if (globals_valid) globals_valid = link_global_symbol_table_initialize(exports->arena, object->symbols, object->symbol_count, &globals);
        for (u32 symbol = 0; globals_valid && symbol < object->symbol_count; symbol += 1)
        {
            if (object->symbols[symbol].global)
            {
                u32* slot = link_global_symbol_table_slot(&globals, object->symbols[symbol].name);
                if (slot) *slot = symbol;
                else globals_valid = false;
            }
        }
    }
    if (!globals_valid)
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u32 alias_count = 0;
    u32 copy_slot_count = 0;
    for (u32 import_index = 0; import_index < import_count; import_index += 1)
    {
        import_alias_first[import_index] = alias_count;
        import_alias_counts[import_index] = 0;
        import_copy_owners[import_index] = UINT32_MAX;
        import_copy_sizes[import_index] = 0;
        if (import_kinds[import_index] != OBJECT_SYMBOL_DATA) continue;
        LinkElfName* name = link_elf_name(exports, import_names[import_index], false);
        LinkElfDataEntry* definition = name && name->data != UINT32_MAX ? exports->data + name->data : 0;
        LinkElfDataGroup* group = definition ? exports->groups + definition->group : 0;
        u64 slot_size = definition && definition->symbol->size ? definition->symbol->size : sizeof(u64);
        if (group && group->owner != UINT32_MAX)
        {
            import_copy_owners[import_index] = group->owner;
            continue;
        }
        import_copy_owners[import_index] = import_index;
        copy_slot_count += 1;
        if (group) group->owner = import_index;
        // Walk only this object's exports, in their original table order.
        // Table identity (not virtual address alone) distinguishes libraries.
        // A caller may expose the same table through different-length views;
        // only the selected definition's view contributes aliases.
        for (u32 entry = group ? group->first : UINT32_MAX; entry != UINT32_MAX; entry = exports->data[entry].next)
        {
            LinkElfDataEntry* data = exports->data + entry;
            NativeDynamicDataSymbol* exported = data->symbol;
            if ((u64)(exported - group->table) >= definition->table_count ||
                string_equal(exported->name, import_names[import_index]) || !exported->name.length ||
                exported->name.length >= UINT32_MAX || imported_name_size > UINT32_MAX - exported->name.length - 1)
            {
                continue;
            }
            u32* global = link_global_symbol_table_slot(&globals, exported->name);
            LinkElfName* alias = exports->names + data->name;
            if ((global && *global != UINT32_MAX) || alias->alias_owner == import_index) continue;
            // Preserve the old sizing rule: an existing global/import or a
            // duplicate version-name does not enlarge the owner's slot.
            alias->alias_owner = import_index;
            slot_size = BUSTER_MAX(slot_size, exported->size);
            alias_names[alias_count++] = exported->name;
            imported_name_size += exported->name.length + 1;
        }
        if (slot_size > UINT32_MAX)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
            result.symbol = import_names[import_index];
            return result;
        }
        import_alias_counts[import_index] = alias_count - import_alias_first[import_index];
        import_copy_sizes[import_index] = slot_size;
    }
    u32 dynamic_data_relocation_count = copy_slot_count;
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation* relocation = &object->relocations[index];
        if (relocation->section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation->section))
        {
            continue;
        }
        if (relocation->section >= OBJECT_SECTION_COUNT || relocation->symbol >= object->symbol_count)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        ObjectSymbol* symbol = &object->symbols[relocation->symbol];
        // Asked of the numbering above rather than of the symbol again: an
        // undefined symbol that was not numbered is one that resolves to
        // zero, and re-deriving that per relocation would rescan every
        // library's exports for every reference to an absent weak name.
        if (import_indices[relocation->symbol] != UINT32_MAX && symbol->kind == OBJECT_SYMBOL_DATA &&
            relocation->kind != OBJECT_RELOCATION_X86_64_PC32 && !object_relocation_kind_is_x86_got(relocation->kind) &&
            relocation->kind != OBJECT_RELOCATION_ABSOLUTE64)
        {
            result.error = LINK_ERROR_RELOCATION;
            result.symbol = symbol->name;
            return result;
        }
    }
    String8 entry_name = options.entry_symbol.length ? options.entry_symbol : S8("main");
    u32 entry_symbol_index = link_symbol_find(object, entry_name);
    if (entry_symbol_index == UINT32_MAX || object->symbols[entry_symbol_index].section == OBJECT_SECTION_UNDEFINED ||
        object->symbols[entry_symbol_index].kind != OBJECT_SYMBOL_FUNCTION)
    {
        result.error = LINK_ERROR_ENTRY_SYMBOL;
        result.symbol = entry_name;
        return result;
    }
    LinkElfEhFrameTable eh_frame_table = link_elf_eh_frame_table_build(arena, object);
    if (!eh_frame_table.valid)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    u64 eh_frame_header_size = eh_frame_table.count ? 12 + (u64)eh_frame_table.count * 8 : 0;
    u32 program_header_count = ELF_BASE_PROGRAM_HEADER_COUNT + (eh_frame_header_size != 0);
    u64 header_end = ELF_HEADER_SIZE + (u64)program_header_count * ELF_PROGRAM_HEADER_SIZE;
    u64 section_offsets[OBJECT_SECTION_COUNT] = {0};
    u64 image_base = ELF_IMAGE_BASE;
    u64* copy_slot_addresses = arena_allocate(arena, u64, import_count);
    u64 entry_stub_offset = align_forward(header_end, 16);
    section_offsets[OBJECT_SECTION_TEXT] =
        align_forward(entry_stub_offset + link_elf_entry_stub_slot(entry_stub_size, &plan), object->sections[OBJECT_SECTION_TEXT].alignment);
    u64 plt_offset = align_forward(section_offsets[OBJECT_SECTION_TEXT] + object->sections[OBJECT_SECTION_TEXT].data.length, 16);
    u64 plt_size = (u64)(import_count + 1) * ELF_PLT_ENTRY_SIZE;
    section_offsets[OBJECT_SECTION_READ_ONLY_DATA] = align_forward(plt_offset + plt_size, object->sections[OBJECT_SECTION_READ_ONLY_DATA].alignment);
    u64 eh_frame_header_offset = align_forward(section_offsets[OBJECT_SECTION_READ_ONLY_DATA] + object->sections[OBJECT_SECTION_READ_ONLY_DATA].data.length, 4);
    section_offsets[OBJECT_SECTION_UNWIND] = align_forward(eh_frame_header_offset + eh_frame_header_size, object->sections[OBJECT_SECTION_UNWIND].alignment);
    u64 interpreter_offset = section_offsets[OBJECT_SECTION_UNWIND] + object->sections[OBJECT_SECTION_UNWIND].data.length;
    u64 interpreter_size = sizeof(interpreter);
    if (options.dynamic_library_count == UINT32_MAX)
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u32 needed_library_count = options.dynamic_library_count + 1;
    u32* library_name_offsets = arena_allocate(arena, u32, needed_library_count);
    u64 library_name_size = sizeof(library_name);
    library_name_offsets[0] = 1;
    for (u32 library_index = 0; library_index < options.dynamic_library_count; library_index += 1)
    {
        String8 library = options.dynamic_libraries[library_index].name;
        if (!library.length || library.length >= UINT32_MAX || library_name_size > UINT32_MAX - library.length - 1)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
            return result;
        }
        library_name_offsets[library_index + 1] = 1 + (u32)library_name_size;
        library_name_size += library.length + 1;
    }
    // --export-dynamic (clang spells it -rdynamic; configure scripts pass
    // `-Xlinker -export-dynamic`): every defined global lands in .dynsym so
    // dlopen(NULL)/dlsym can find the program's own definitions.  CPython's
    // ctypes.pythonapi is exactly that call, and every
    // `pythonapi.PyBytes_FromFormat` lookup died with "undefined symbol"
    // while the flag was ignored.  Thread-local symbols are excluded: their
    // st_value speaks TLS-offset, not address, and nothing dlsym-shaped asks
    // for them.
    bool export_dynamic = false;
    for (u32 argument_index = 0; argument_index < options.linker_argument_count; argument_index += 1)
    {
        String8 linker_argument = options.linker_arguments[argument_index];
        export_dynamic |= string_equal(linker_argument, S8("-export-dynamic")) || string_equal(linker_argument, S8("--export-dynamic")) ||
                          string_equal(linker_argument, S8("-E"));
    }
    u32 export_count = 0;
    u32* export_symbols = arena_allocate(arena, u32, object->symbol_count ? object->symbol_count : 1);
    u64 exported_name_size = 0;
    for (u32 symbol_index = 0; export_dynamic && symbol_index < object->symbol_count; symbol_index += 1)
    {
        ObjectSymbol* export_symbol = object->symbols + symbol_index;
        if ((!export_symbol->global && !export_symbol->weak) || export_symbol->hidden || export_symbol->section >= OBJECT_SECTION_COUNT ||
            object_section_kind_is_debug((ObjectSectionKind)export_symbol->section) || export_symbol->section == OBJECT_SECTION_THREAD_LOCAL_DATA ||
            export_symbol->section == OBJECT_SECTION_THREAD_LOCAL_ZERO || !export_symbol->name.length ||
            (export_symbol->kind != OBJECT_SYMBOL_FUNCTION && export_symbol->kind != OBJECT_SYMBOL_DATA))
        {
            continue;
        }
        if (export_symbol->name.length > UINT32_MAX || exported_name_size > UINT32_MAX - export_symbol->name.length - 1)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
            result.symbol = export_symbol->name;
            return result;
        }
        export_symbols[export_count++] = symbol_index;
        exported_name_size += export_symbol->name.length + 1;
    }
    // Symbol versions.  A reference GNU ld resolves records the version it
    // bound to, so the image keeps that one answer for its whole life instead
    // of taking whatever the running library happens to call default; that is
    // the versioning mechanism's entire purpose.  Every name the image spells
    // is versioned here, the imports and the alias names each copy slot
    // defines alike, because each of them is a name the library publishes.
    //
    // The result is a set of distinct (library, version) pairs numbered from
    // ELF_VERSION_FIRST_INDEX, which is what .gnu.version records per dynamic
    // symbol and what .gnu.version_r's auxiliary entries name.
    u64 versioned_name_count = (u64)import_count + alias_count;
    u32* version_libraries = arena_allocate(arena, u32, versioned_name_count + 1);
    String8* version_names = arena_allocate(arena, String8, versioned_name_count + 1);
    u32* version_name_offsets = arena_allocate(arena, u32, versioned_name_count + 1);
    u16* import_versions = arena_allocate(arena, u16, (u64)import_count + 1);
    u16* alias_versions = arena_allocate(arena, u16, (u64)alias_count + 1);
    u64 maximum_versions = BUSTER_MIN(versioned_name_count, (u64)ELF_VERSION_INDEX_MAX - ELF_VERSION_FIRST_INDEX + 1);
    u64 version_capacity = link_elf_index_capacity(maximum_versions);
    u64 version_index_bytes = (version_capacity + maximum_versions + (u64)needed_library_count * 3) * sizeof(u32) + 5 * BUSTER_ALIGN_OF(u32);
    if (version_index_bytes > exports->arena->reserved_size - exports->arena->position)
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u32* version_slots = arena_allocate(exports->arena, u32, version_capacity);
    u32* version_next = arena_allocate(exports->arena, u32, maximum_versions);
    u32* library_version_first = arena_allocate(exports->arena, u32, needed_library_count);
    u32* library_version_last = arena_allocate(exports->arena, u32, needed_library_count);
    u32* library_version_counts = arena_allocate_zeroed(exports->arena, u32, needed_library_count);
    memset(version_slots, 0xff, version_capacity * sizeof(u32));
    memset(library_version_first, 0xff, (u64)needed_library_count * sizeof(u32));
    memset(library_version_last, 0xff, (u64)needed_library_count * sizeof(u32));
    u32 version_count = 0;
    u64 version_name_size = 0;
    for (u64 entry = 0; entry < versioned_name_count; entry += 1)
    {
        String8 name = entry < import_count ? import_names[entry] : alias_names[entry - import_count];
        u32 library_index = 0;
        String8 version = {0};
        bool no_default = false;
        u16 version_index = 0;
        if (link_elf_symbol_version(exports, name, &library_index, &version, &no_default))
        {
            u64 bucket = 0;
            if (version.length)
            {
                bucket = (buster_hash_64((u8*)version.pointer, version.length) ^ library_index) & (version_capacity - 1);
                while (version_slots[bucket] != UINT32_MAX)
                {
                    u32 existing = version_slots[bucket];
                    if (version_libraries[existing] == library_index && string_equal(version_names[existing], version))
                    {
                        version_index = (u16)(ELF_VERSION_FIRST_INDEX + existing);
                        break;
                    }
                    bucket = (bucket + 1) & (version_capacity - 1);
                }
            }
            if (!version_index && version.length)
            {
                if (version_count > ELF_VERSION_INDEX_MAX - ELF_VERSION_FIRST_INDEX || version.length >= UINT32_MAX ||
                    version_name_size > UINT32_MAX - version.length - 1)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                    result.symbol = name;
                    return result;
                }
                version_libraries[version_count] = library_index;
                version_names[version_count] = version;
                version_slots[bucket] = version_count;
                version_next[version_count] = UINT32_MAX;
                if (library_version_last[library_index] != UINT32_MAX) version_next[library_version_last[library_index]] = version_count;
                else library_version_first[library_index] = version_count;
                library_version_last[library_index] = version_count;
                library_version_counts[library_index] += 1;
                version_index = (u16)(ELF_VERSION_FIRST_INDEX + version_count);
                version_count += 1;
                version_name_size += version.length + 1;
            }
        }
        else if (no_default && entry < import_count)
        {
            // Every definition this library has for the name is a non-default
            // `name@VER`.  An unversioned reference has nothing to bind to, so
            // GNU ld reports it undefined; linking it anyway leaves the answer
            // to whichever version the running loader picks.
            result.error = LINK_ERROR_SYMBOL_VERSION;
            result.symbol = name;
            return result;
        }
        if (entry < import_count)
        {
            import_versions[entry] = version_index;
        }
        else
        {
            alias_versions[entry - import_count] = version_index;
        }
    }
    // One .gnu.version_r entry per library that contributes a version, each
    // followed by its own auxiliary list.
    u64 version_need_size = 0;
    u32 version_need_count = 0;
    for (u32 library_index = 0; version_count && library_index < needed_library_count; library_index += 1)
    {
        u32 library_version_count = library_version_counts[library_index];
        version_need_size += library_version_count ? ELF_VERSION_NEED_SIZE + (u64)library_version_count * ELF_VERSION_AUXILIARY_SIZE : 0;
        version_need_count += library_version_count != 0;
    }
    u64 dynamic_string_offset = interpreter_offset + interpreter_size;
    u32 first_symbol_name_offset = 1 + (u32)library_name_size;
    u64 dynamic_string_size = 1 + library_name_size + imported_name_size + version_name_size + exported_name_size;
    u64 dynamic_symbol_offset = align_forward(dynamic_string_offset + dynamic_string_size, 8);
    u64 dynamic_symbol_count = (u64)import_count + 1 + alias_count + export_count;
    if (dynamic_symbol_count > UINT32_MAX)
    {
        // The hash table states its chain length in one 32-bit word.
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u64 dynamic_symbol_size = dynamic_symbol_count * ELF_SYMBOL_SIZE;
    u64 hash_offset = align_forward(dynamic_symbol_offset + dynamic_symbol_size, 4);
    u64 hash_size = (2 + 1 + dynamic_symbol_count) * sizeof(u32);
    // Both version sections are absent when nothing needed a version, and the
    // two alignments then collapse into the one .rela always had, so an image
    // with no versioned reference is laid out exactly as before.
    u64 version_symbol_offset = align_forward(hash_offset + hash_size, 2);
    u64 version_symbol_size = version_count ? dynamic_symbol_count * sizeof(u16) : 0;
    u64 version_need_offset = align_forward(version_symbol_offset + version_symbol_size, 8);
    u64 relocation_offset = align_forward(version_need_offset + version_need_size, 8);
    u64 plt_relocation_size = (u64)import_count * ELF_RELOCATION_SIZE;
    u64 relocation_size = (u64)(import_count + dynamic_data_relocation_count) * ELF_RELOCATION_SIZE;
    u64 read_only_end = relocation_offset + relocation_size;
    if (!link_elf_virtual_align(read_only_end, BUSTER_MAX((u32)ELF_PAGE_SIZE, object->sections[OBJECT_SECTION_DATA].alignment),
                                &section_offsets[OBJECT_SECTION_DATA]))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u64 got_offset = align_forward(section_offsets[OBJECT_SECTION_DATA] + object->sections[OBJECT_SECTION_DATA].data.length, 8);
    u64 got_size = (u64)(ELF_GOT_RESERVED_COUNT + import_count) * sizeof(u64);
    u64 dynamic_offset = align_forward(got_offset + got_size, 8);
    u32 dynamic_count = needed_library_count + 11 + (dynamic_data_relocation_count ? 2 : 0) + (version_count ? 3 : 0);
    u64 dynamic_size = (u64)dynamic_count * ELF_DYNAMIC_SIZE;
    section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] = align_forward(dynamic_offset + dynamic_size, object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].alignment);
    u64 file_size = section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] + object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length;
    section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO] = align_forward(file_size, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment);
    u64 thread_local_memory_end = section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO] + object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size;
    if (!link_elf_virtual_align(thread_local_memory_end, object->sections[OBJECT_SECTION_ZERO].alignment, &section_offsets[OBJECT_SECTION_ZERO]))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u64 copy_data_offset = align_forward(section_offsets[OBJECT_SECTION_ZERO] + object->sections[OBJECT_SECTION_ZERO].virtual_size, 16);
    u64 copy_slot_cursor = copy_data_offset;
    for (u32 import_index = 0; import_index < import_count; import_index += 1)
    {
        if (import_kinds[import_index] != OBJECT_SYMBOL_DATA)
        {
            continue;
        }
        u32 owner = import_copy_owners[import_index];
        if (owner != import_index)
        {
            copy_slot_addresses[import_index] = copy_slot_addresses[owner];
            continue;
        }
        copy_slot_cursor = align_forward(copy_slot_cursor, import_copy_sizes[import_index] >= 16 ? 16 : 8);
        copy_slot_addresses[import_index] = image_base + copy_slot_cursor;
        copy_slot_cursor += import_copy_sizes[import_index];
    }
    u64 writable_memory_end = copy_slot_cursor;
    if (file_size > UINT32_MAX)
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    result.executable = (ByteSlice){
        // The image is written section by section over a zero background, and
        // the background is what a fresh arena mapping already is: the fill
        // now covers only the arena's dirty prefix, which for the one image a
        // link produces is nothing at all.
        .pointer = arena_allocate_zeroed(arena, u8, file_size),
        .length = file_size,
    };
    u8* bytes = result.executable.pointer;
    memcpy(bytes + entry_stub_offset, entry_stub, entry_stub_size);
    for (u32 section = 0; section < OBJECT_SECTION_COUNT; section += 1)
    {
        if (object_section_kind_is_debug((ObjectSectionKind)section))
        {
            continue;
        }
        ByteSlice data = object->sections[section].data;
        if (data.length)
        {
            memcpy(bytes + section_offsets[section], data.pointer, data.length);
        }
    }
    memcpy(bytes + interpreter_offset, interpreter, interpreter_size);
    memcpy(bytes + dynamic_string_offset + library_name_offsets[0], library_name, sizeof(library_name));
    for (u32 library_index = 0; library_index < options.dynamic_library_count; library_index += 1)
    {
        String8 library = options.dynamic_libraries[library_index].name;
        u64 output = dynamic_string_offset + library_name_offsets[library_index + 1];
        memcpy(bytes + output, library.pointer, library.length);
        bytes[output + library.length] = 0;
    }
    u64 dynamic_name_cursor = dynamic_string_offset + first_symbol_name_offset;
    for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
    {
        u32 import_index = import_indices[symbol_index];
        if (import_index == UINT32_MAX)
        {
            continue;
        }
        ObjectSymbol* symbol = &object->symbols[symbol_index];
        import_name_offsets[import_index] = (u32)(dynamic_name_cursor - dynamic_string_offset);
        memcpy(bytes + dynamic_name_cursor, symbol->name.pointer, symbol->name.length);
        dynamic_name_cursor += symbol->name.length + 1;
        u64 symbol_offset = dynamic_symbol_offset + (u64)(import_index + 1) * ELF_SYMBOL_SIZE;
        link_write_u32(bytes, symbol_offset, import_name_offsets[import_index]);
        // STB_GLOBAL or STB_WEAK over STT_OBJECT or STT_FUNC.  The binding is
        // the reference's own: a weak one tells the loader that finding no
        // definition is an answer (address zero) rather than a failed load.
        bytes[symbol_offset + 4] = (symbol->weak ? 0x20 : 0x10) | (import_kinds[import_index] == OBJECT_SYMBOL_DATA ? 0x1 : 0x2);
        if (import_kinds[import_index] == OBJECT_SYMBOL_DATA)
        {
            // SHN_ABS marks the executable-owned copy slot as defined while
            // retaining the imported name used by the R_X86_64_COPY entry.
            link_write_u16(bytes, symbol_offset + 6, 0xfff1);
            link_write_u64(bytes, symbol_offset + 8, copy_slot_addresses[import_index]);
            link_write_u64(bytes, symbol_offset + 16, import_copy_sizes[import_copy_owners[import_index]]);
        }
    }
    // The library's other names for each copy-relocated object, defined at the
    // same slot so the library's own post-startup stores through them land in
    // the executable's copy.
    u64 alias_symbol_index = (u64)import_count + 1;
    for (u32 import_index = 0; import_index < import_count; import_index += 1)
    {
        for (u32 alias_index = 0; alias_index < import_alias_counts[import_index]; alias_index += 1)
        {
            String8 alias = alias_names[import_alias_first[import_index] + alias_index];
            u64 symbol_offset = dynamic_symbol_offset + alias_symbol_index * ELF_SYMBOL_SIZE;
            link_write_u32(bytes, symbol_offset, (u32)(dynamic_name_cursor - dynamic_string_offset));
            memcpy(bytes + dynamic_name_cursor, alias.pointer, alias.length);
            dynamic_name_cursor += alias.length + 1;
            bytes[symbol_offset + 4] = 0x11;
            link_write_u16(bytes, symbol_offset + 6, 0xfff1);
            link_write_u64(bytes, symbol_offset + 8, copy_slot_addresses[import_index]);
            link_write_u64(bytes, symbol_offset + 16, import_copy_sizes[import_index]);
            alias_symbol_index += 1;
        }
    }
    u64 export_symbol_slot = (u64)import_count + 1 + alias_count;
    for (u32 export_index = 0; export_index < export_count; export_index += 1)
    {
        ObjectSymbol* export_symbol = object->symbols + export_symbols[export_index];
        u64 symbol_offset = dynamic_symbol_offset + export_symbol_slot * ELF_SYMBOL_SIZE;
        link_write_u32(bytes, symbol_offset, (u32)(dynamic_name_cursor - dynamic_string_offset));
        memcpy(bytes + dynamic_name_cursor, export_symbol->name.pointer, export_symbol->name.length);
        dynamic_name_cursor += export_symbol->name.length + 1;
        // Binding and type in st_info; SHN_ABS in st_shndx, the shape the
        // copy-slot aliases above already use -- the loader reads only the
        // value, and the value is the final image address.
        bytes[symbol_offset + 4] = (u8)(((export_symbol->weak ? 2u : 1u) << 4) | (export_symbol->kind == OBJECT_SYMBOL_FUNCTION ? 2u : 1u));
        link_write_u16(bytes, symbol_offset + 6, 0xfff1);
        link_write_u64(bytes, symbol_offset + 8, image_base + section_offsets[export_symbol->section] + export_symbol->value);
        link_write_u64(bytes, symbol_offset + 16, export_symbol->size);
        export_symbol_slot += 1;
    }
    link_write_u32(bytes, hash_offset, 1);
    link_write_u32(bytes, hash_offset + 4, (u32)dynamic_symbol_count);
    link_write_u32(bytes, hash_offset + 8, 1);
    for (u64 chain_index = 1; chain_index < dynamic_symbol_count; chain_index += 1)
    {
        link_write_u32(bytes, hash_offset + (3 + chain_index) * sizeof(u32), chain_index + 1 == dynamic_symbol_count ? 0 : (u32)chain_index + 1);
    }
    if (version_count)
    {
        // The version names, then .gnu.version -- one index per dynamic
        // symbol, parallel to .dynsym, and 0 for both the null entry and every
        // name that binds without a version -- and .gnu.version_r, which names
        // per library the versions those indexes stand for.
        for (u32 index = 0; index < version_count; index += 1)
        {
            version_name_offsets[index] = (u32)(dynamic_name_cursor - dynamic_string_offset);
            memcpy(bytes + dynamic_name_cursor, version_names[index].pointer, version_names[index].length);
            dynamic_name_cursor += version_names[index].length + 1;
        }
        for (u32 import_index = 0; import_index < import_count; import_index += 1)
        {
            link_write_u16(bytes, version_symbol_offset + ((u64)import_index + 1) * sizeof(u16), import_versions[import_index]);
        }
        for (u32 alias_index = 0; alias_index < alias_count; alias_index += 1)
        {
            link_write_u16(bytes, version_symbol_offset + ((u64)import_count + 1 + alias_index) * sizeof(u16), alias_versions[alias_index]);
        }
        // An exported definition is VER_NDX_GLOBAL: the zero the buffer
        // holds means "local", which the lookup skips, and dlsym would once
        // again answer nothing.
        for (u32 export_index = 0; export_index < export_count; export_index += 1)
        {
            link_write_u16(bytes, version_symbol_offset + ((u64)import_count + 1 + alias_count + export_index) * sizeof(u16), 1);
        }
        u64 need_cursor = version_need_offset;
        u64 previous_need = 0;
        for (u32 library_index = 0; library_index < needed_library_count; library_index += 1)
        {
            u32 library_version_count = library_version_counts[library_index];
            if (!library_version_count)
            {
                continue;
            }
            link_write_u16(bytes, need_cursor, 1);
            link_write_u16(bytes, need_cursor + 2, (u16)library_version_count);
            link_write_u32(bytes, need_cursor + 4, library_name_offsets[library_index]);
            link_write_u32(bytes, need_cursor + 8, ELF_VERSION_NEED_SIZE);
            if (previous_need)
            {
                link_write_u32(bytes, previous_need + 12, (u32)(need_cursor - previous_need));
            }
            previous_need = need_cursor;
            u64 auxiliary = need_cursor + ELF_VERSION_NEED_SIZE;
            u32 written = 0;
            for (u32 index = library_version_first[library_index]; index != UINT32_MAX; index = version_next[index])
            {
                written += 1;
                link_write_u32(bytes, auxiliary, link_elf_hash(version_names[index]));
                link_write_u16(bytes, auxiliary + 6, (u16)(ELF_VERSION_FIRST_INDEX + index));
                link_write_u32(bytes, auxiliary + 8, version_name_offsets[index]);
                link_write_u32(bytes, auxiliary + 12, written == library_version_count ? 0 : ELF_VERSION_AUXILIARY_SIZE);
                auxiliary += ELF_VERSION_AUXILIARY_SIZE;
            }
            need_cursor = auxiliary;
        }
    }
    u64 got_address = image_base + got_offset;
    u64 plt_address = image_base + plt_offset;
    u64 dynamic_address = image_base + dynamic_offset;
    LinkX86InstructionBuilder plt0 = {.bytes = bytes + plt_offset, .capacity = ELF_PLT_ENTRY_SIZE};
    BusterX86MetadataPhysicalOperand plt_memory = link_x86_memory_rip(64, 0);
    if (!link_x86_emit(&plt0, S8("PUSH"), &plt_memory, 1) ||
        !link_x86_emit(&plt0, S8("JMP"), &plt_memory, 1) ||
        !link_x86_emit(&plt0, S8("NOP"), &(BusterX86MetadataPhysicalOperand){
                                               .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
                                               .width = 8,
                                               .memory = {
                                                   .base = {.index = 0, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
                                                   .address_size = 64,
                                                   .scale = 1,
                                                   .has_base = true,
                                                   .has_displacement = true,
                                                   .source_width = 8,
                                               },
                                           },
                       1) ||
        plt0.count != ELF_PLT_ENTRY_SIZE)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    link_write_u32(bytes, plt_offset + 2, (u32)(s32)((s64)(got_address + 8) - (s64)(plt_address + 6)));
    link_write_u32(bytes, plt_offset + 8, (u32)(s32)((s64)(got_address + 16) - (s64)(plt_address + 12)));
    link_write_u64(bytes, got_offset, dynamic_address);
    for (u32 import_index = 0; import_index < import_count; import_index += 1)
    {
        u64 entry_offset = plt_offset + (u64)(import_index + 1) * ELF_PLT_ENTRY_SIZE;
        u64 entry_address = image_base + entry_offset;
        u64 slot_offset = got_offset + (u64)(ELF_GOT_RESERVED_COUNT + import_index) * sizeof(u64);
        u64 slot_address = image_base + slot_offset;
        LinkX86InstructionBuilder plt_entry = {.bytes = bytes + entry_offset, .capacity = ELF_PLT_ENTRY_SIZE};
        BusterX86MetadataPhysicalOperand slot_memory = link_x86_memory_rip(64, 0);
        BusterX86MetadataPhysicalOperand import_immediate = link_x86_immediate(import_index, 32);
        BusterX86MetadataPhysicalOperand plt_relative = link_x86_relative(0, 32);
        if (!link_x86_emit(&plt_entry, S8("JMP"), &slot_memory, 1) ||
            !link_x86_emit_push_imm32(&plt_entry, &import_immediate) ||
            !link_x86_emit(&plt_entry, S8("JMP"), &plt_relative, 1) ||
            plt_entry.count != ELF_PLT_ENTRY_SIZE)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        link_write_u32(bytes, entry_offset + 2, (u32)(s32)((s64)slot_address - (s64)(entry_address + 6)));
        link_write_u32(bytes, entry_offset + 12, (u32)(s32)((s64)plt_address - (s64)(entry_address + 16)));
        link_write_u64(bytes, slot_offset, entry_address + 6);
        u64 relocation_entry = relocation_offset + (u64)import_index * ELF_RELOCATION_SIZE;
        link_write_u64(bytes, relocation_entry, slot_address);
        // Keep every PLT relocation in the JUMP_SLOT range.  Imported data
        // gets its address through the ordinary RELA entry emitted below;
        // a harmless JUMP_SLOT for its reserved, otherwise-unused thunk
        // keeps the PLT relocation table valid for the system loader.
        link_write_u64(bytes, relocation_entry + 8, ((u64)(import_index + 1) << 32) | ELF_RELOCATION_TYPE_X86_64_JUMP_SLOT);
    }
    ObjectSymbol* entry_symbol = &object->symbols[entry_symbol_index];
    u64 entry_address = image_base + section_offsets[entry_symbol->section] + entry_symbol->value;
    u64 call_displacement_offset = entry_stub_offset + entry_call_displacement_offset;
    s64 call_displacement = (s64)entry_address - (s64)(image_base + call_displacement_offset + 4);
    if (call_displacement < INT32_MIN || call_displacement > INT32_MAX)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    link_write_u32(bytes, call_displacement_offset, (u32)(s32)call_displacement);
    // The stub's second call: `exit` through its PLT entry when it is
    // imported, or straight to the program's own definition when it has one.
    u64 exit_address = 0;
    if (!link_elf_hosted_call_address(object, exit_symbol_index, import_indices, section_offsets, image_base, plt_address, &exit_address))
    {
        result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
        result.symbol = object->symbols[exit_symbol_index].name;
        return result;
    }
    u64 exit_displacement_offset = entry_stub_offset + entry_exit_displacement_offset;
    s64 exit_displacement = (s64)exit_address - (s64)(image_base + exit_displacement_offset + 4);
    if (exit_displacement < INT32_MIN || exit_displacement > INT32_MAX)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    link_write_u32(bytes, exit_displacement_offset, (u32)(s32)exit_displacement);
    // Register the loader finalizer first, then the optional executable runner.
    u32 registration_offsets[] = {loader_atexit_displacement_offset, entry_atexit_displacement_offset};
    for (u32 registration = 0; registration < 1u + (plan.destructor_count != 0); registration += 1)
    {
        u64 atexit_address = 0;
        if (atexit_symbol_index >= object->symbol_count ||
            !link_elf_hosted_call_address(object, atexit_symbol_index, import_indices, section_offsets, image_base, plt_address, &atexit_address))
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = S8("__cxa_atexit");
            return result;
        }
        u64 atexit_displacement_offset = entry_stub_offset + registration_offsets[registration];
        s64 atexit_displacement = (s64)atexit_address - (s64)(image_base + atexit_displacement_offset + 4);
        if (atexit_displacement < INT32_MIN || atexit_displacement > INT32_MAX)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        link_write_u32(bytes, atexit_displacement_offset, (u32)(s32)atexit_displacement);
    }
    if (!link_x86_patch_initializer_calls(bytes, object, &plan, section_offsets, image_base, entry_stub_offset, initializer_displacement_offsets))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation* relocation = &object->relocations[index];
        if (relocation->section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation->section))
        {
            continue;
        }
        if (relocation->section >= OBJECT_SECTION_COUNT || relocation->symbol >= object->symbol_count)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        ObjectSection* section = &object->sections[relocation->section];
        u64 width = relocation->kind == OBJECT_RELOCATION_ABSOLUTE64 ? 8 : 4;
        if (relocation->offset > section->data.length || width > section->data.length - relocation->offset)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        ObjectSymbol* symbol = &object->symbols[relocation->symbol];
        // The call in a general-dynamic pair is gone once the pair is relaxed
        // into local-exec, and __tls_get_addr with it: the sequence eight
        // bytes back is what makes this call that call rather than a written
        // one, and an image this linker produces has no dynamic thread-local
        // storage for a real call to reach.
        if (link_elf_relocation_is_relaxed_tls_get_addr(object, relocation, symbol))
        {
            continue;
        }
        u64 symbol_address = 0;
        if (symbol->section == OBJECT_SECTION_UNDEFINED && import_indices[relocation->symbol] == UINT32_MAX)
        {
            // Nothing in the image and nothing the loader can reach defines
            // it, so the reference is worth zero and the relocation is
            // applied against that address like any other. An undefined
            // symbol the numbering above left unimported is exactly one
            // link_elf_symbol_resolves_to_zero answered for, and asking the
            // numbering is what keeps the export scan to one per symbol.
            symbol_address = 0;
        }
        else if (symbol->section == OBJECT_SECTION_UNDEFINED && symbol->kind == OBJECT_SYMBOL_DATA)
        {
            u32 import_index = import_indices[relocation->symbol];
            if (import_index == UINT32_MAX || copy_slot_addresses[import_index] == 0)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            symbol_address = copy_slot_addresses[import_index];
        }
        else if (symbol->section == OBJECT_SECTION_UNDEFINED)
        {
            u32 import_index = import_indices[relocation->symbol];
            // Function-pointer initializers (for example cJSON's allocator
            // hooks) use an absolute 64-bit relocation for the imported
            // function.  Point those at the generated PLT entry just like a
            // direct PC-relative call; the dynamic loader then resolves the
            // entry on first use.  Reject every other undefined relocation so
            // data imports cannot be mistaken for callable symbols.
            if (import_index == UINT32_MAX ||
                (relocation->kind != OBJECT_RELOCATION_X86_64_PC32 && relocation->kind != OBJECT_RELOCATION_X86_64_PLT32 &&
                 !object_relocation_kind_is_x86_got(relocation->kind) && relocation->kind != OBJECT_RELOCATION_ABSOLUTE64))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            u64 plt_slot = (u64)import_index + 1;
            if (import_index == UINT32_MAX || plt_slot > UINT64_MAX / ELF_PLT_ENTRY_SIZE ||
                !link_u64_add(plt_address, plt_slot * ELF_PLT_ENTRY_SIZE, &symbol_address))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
        }
        else if (symbol->section < OBJECT_SECTION_COUNT)
        {
            if (!link_u64_add(image_base, section_offsets[symbol->section], &symbol_address) ||
                !link_u64_add(symbol_address, symbol->value, &symbol_address))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
        }
        else
        {
            result.error = LINK_ERROR_RELOCATION;
            result.symbol = symbol->name;
            return result;
        }
        u64 place_address = image_base + section_offsets[relocation->section] + relocation->offset;
        u64 output_offset = section_offsets[relocation->section] + relocation->offset;
        BusterX86MetadataGotPatch got_patch = BUSTER_X86_METADATA_GOT_PATCH_NONE;
        if (object_relocation_kind_is_x86_got(relocation->kind))
        {
            got_patch = link_x86_relax_got_reference(relocation->kind, relocation->addend, bytes, output_offset, section_offsets[relocation->section],
                                                     section_offsets[relocation->section] + section->data.length);
            if (got_patch == BUSTER_X86_METADATA_GOT_PATCH_NONE)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
        }
        // A relaxed GOT load and a PLT call both patch the same rel32 the
        // direct form does, against the same address: this image has one
        // definition of every name in it. A conversion that answers with the
        // address as an immediate patches the same field with the address
        // itself, and the GOT load's -4 has no part in that value.
        if (relocation->kind == OBJECT_RELOCATION_X86_64_PC32 || relocation->kind == OBJECT_RELOCATION_X86_64_PLT32 ||
            got_patch == BUSTER_X86_METADATA_GOT_PATCH_PC32)
        {
            s64 value = 0;
            if (!link_address_difference(symbol_address, place_address, relocation->addend, &value) || value < INT32_MIN || value > INT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)(s32)value);
        }
        else if (got_patch == BUSTER_X86_METADATA_GOT_PATCH_ABSOLUTE32)
        {
            s32 value = 0;
            if (!link_absolute32s_value(symbol_address, 0, &value))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)value);
        }
        else if (relocation->kind == OBJECT_RELOCATION_X86_64_ABSOLUTE32S)
        {
            s32 value = 0;
            if (!link_absolute32s_value(symbol_address, relocation->addend, &value))
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)value);
        }
        // R_X86_64_32 zero-extends: -fno-pic small-model foreign objects
        // (clang emits it for every address literal there) are valid in an
        // image whose base keeps the whole file below 4GB.
        else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE32)
        {
            u64 value = 0;
            if (!link_address_addend(symbol_address, relocation->addend, &value) || value > UINT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)value);
        }
        else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
        {
            u64 value = 0;
            if (!link_address_addend(symbol_address, relocation->addend, &value))
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u64(bytes, output_offset, value);
        }
        else if (relocation->kind == OBJECT_RELOCATION_X86_64_TPOFF32 || relocation->kind == OBJECT_RELOCATION_X86_64_GOTTPOFF ||
                 relocation->kind == OBJECT_RELOCATION_X86_64_TLSGD)
        {
            if (symbol->section != OBJECT_SECTION_THREAD_LOCAL_DATA && symbol->section != OBJECT_SECTION_THREAD_LOCAL_ZERO)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            u64 initialized_size =
                align_forward(object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment);
            u64 thread_local_size = align_forward(initialized_size + object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size,
                                                  object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].alignment);
            u64 symbol_offset = symbol->section == OBJECT_SECTION_THREAD_LOCAL_ZERO ? initialized_size + symbol->value : symbol->value;
            // Local-exec patches a field the addend belongs to. The other two
            // name a rip-relative operand whose -4 is about the instruction,
            // not about the offset from the thread pointer, and relaxing them
            // replaces that operand outright.
            s64 thread_local_addend = relocation->kind == OBJECT_RELOCATION_X86_64_TPOFF32 ? relocation->addend : 0;
            s64 value = 0;
            if (!link_address_difference(symbol_offset, thread_local_size, thread_local_addend, &value) || value < INT32_MIN || value > INT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            if (relocation->kind == OBJECT_RELOCATION_X86_64_TPOFF32)
            {
                link_write_u32(bytes, output_offset, (u32)(s32)value);
            }
            else if (!link_elf_relax_thread_local(bytes, output_offset, section_offsets[relocation->section],
                                                  section_offsets[relocation->section] + section->data.length,
                                                  relocation->kind == OBJECT_RELOCATION_X86_64_TLSGD, (s32)value))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
        }
        else
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
    }
    if (!link_elf_eh_frame_header_write(bytes, file_size, &eh_frame_table, object, image_base, section_offsets, eh_frame_header_offset))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    u32 copy_relocation_cursor = 0;
    for (u32 import_index = 0; import_index < import_count; import_index += 1)
    {
        if (import_kinds[import_index] != OBJECT_SYMBOL_DATA || import_copy_owners[import_index] != import_index)
        {
            continue;
        }
        u64 relocation_entry = relocation_offset + plt_relocation_size + (u64)copy_relocation_cursor * ELF_RELOCATION_SIZE;
        link_write_u64(bytes, relocation_entry, copy_slot_addresses[import_index]);
        link_write_u64(bytes, relocation_entry + 8, ((u64)(import_index + 1) << 32) | ELF_RELOCATION_TYPE_X86_64_COPY);
        link_write_u64(bytes, relocation_entry + 16, 0);
        copy_relocation_cursor += 1;
    }
    u64 dynamic_cursor = dynamic_offset;
#define BUSTER_LINK_DYNAMIC(tag, value)                                                                                                                        \
    do                                                                                                                                                         \
    {                                                                                                                                                          \
        link_write_u64(bytes, dynamic_cursor, (tag));                                                                                                          \
        link_write_u64(bytes, dynamic_cursor + 8, (value));                                                                                                    \
        dynamic_cursor += ELF_DYNAMIC_SIZE;                                                                                                                    \
    } while (0)
    for (u32 library_index = 0; library_index < needed_library_count; library_index += 1)
    {
        BUSTER_LINK_DYNAMIC(1, library_name_offsets[library_index]);
    }
    BUSTER_LINK_DYNAMIC(4, image_base + hash_offset);
    BUSTER_LINK_DYNAMIC(5, image_base + dynamic_string_offset);
    BUSTER_LINK_DYNAMIC(6, image_base + dynamic_symbol_offset);
    BUSTER_LINK_DYNAMIC(10, dynamic_string_size);
    BUSTER_LINK_DYNAMIC(11, ELF_SYMBOL_SIZE);
    BUSTER_LINK_DYNAMIC(3, got_address);
    BUSTER_LINK_DYNAMIC(2, plt_relocation_size);
    BUSTER_LINK_DYNAMIC(20, 7);
    BUSTER_LINK_DYNAMIC(23, image_base + relocation_offset);
    BUSTER_LINK_DYNAMIC(9, ELF_RELOCATION_SIZE);
    if (dynamic_data_relocation_count)
    {
        BUSTER_LINK_DYNAMIC(7, image_base + relocation_offset + plt_relocation_size);
        BUSTER_LINK_DYNAMIC(8, (u64)dynamic_data_relocation_count * ELF_RELOCATION_SIZE);
    }
    if (version_count)
    {
        BUSTER_LINK_DYNAMIC(ELF_DYNAMIC_TAG_VERSION_SYMBOLS, image_base + version_symbol_offset);
        BUSTER_LINK_DYNAMIC(ELF_DYNAMIC_TAG_VERSION_NEED, image_base + version_need_offset);
        BUSTER_LINK_DYNAMIC(ELF_DYNAMIC_TAG_VERSION_NEED_COUNT, version_need_count);
    }
    BUSTER_LINK_DYNAMIC(0, 0);
#undef BUSTER_LINK_DYNAMIC
    bytes[0] = 0x7f;
    bytes[1] = 'E';
    bytes[2] = 'L';
    bytes[3] = 'F';
    bytes[4] = 2;
    bytes[5] = 1;
    bytes[6] = 1;
    link_write_u16(bytes, 16, 2);
    link_write_u16(bytes, 18, ELF_MACHINE_X86_64);
    link_write_u32(bytes, 20, 1);
    link_write_u64(bytes, 24, image_base + entry_stub_offset);
    link_write_u64(bytes, 32, ELF_HEADER_SIZE);
    link_write_u16(bytes, 52, ELF_HEADER_SIZE);
    link_write_u16(bytes, 54, ELF_PROGRAM_HEADER_SIZE);
    link_write_u16(bytes, 56, (u16)program_header_count);
    u64 program_header = ELF_HEADER_SIZE;
#define BUSTER_LINK_PROGRAM_HEADER(type, flags, offset, address, file_bytes, memory_bytes, alignment)                                                         \
    do                                                                                                                                                         \
    {                                                                                                                                                          \
        link_write_u32(bytes, program_header, (type));                                                                                                         \
        link_write_u32(bytes, program_header + 4, (flags));                                                                                                    \
        link_write_u64(bytes, program_header + 8, (offset));                                                                                                   \
        link_write_u64(bytes, program_header + 16, (address));                                                                                                 \
        link_write_u64(bytes, program_header + 24, (address));                                                                                                 \
        link_write_u64(bytes, program_header + 32, (file_bytes));                                                                                              \
        link_write_u64(bytes, program_header + 40, (memory_bytes));                                                                                            \
        link_write_u64(bytes, program_header + 48, (alignment));                                                                                               \
        program_header += ELF_PROGRAM_HEADER_SIZE;                                                                                                             \
    } while (0)
    BUSTER_LINK_PROGRAM_HEADER(6, 4, ELF_HEADER_SIZE, image_base + ELF_HEADER_SIZE, (u64)program_header_count * ELF_PROGRAM_HEADER_SIZE,
                               (u64)program_header_count * ELF_PROGRAM_HEADER_SIZE, 8);
    BUSTER_LINK_PROGRAM_HEADER(3, 4, interpreter_offset, image_base + interpreter_offset, interpreter_size, interpreter_size, 1);
    BUSTER_LINK_PROGRAM_HEADER(1, 5, 0, image_base, read_only_end, read_only_end, ELF_PAGE_SIZE);
    BUSTER_LINK_PROGRAM_HEADER(1, 6, section_offsets[OBJECT_SECTION_DATA], image_base + section_offsets[OBJECT_SECTION_DATA],
                               file_size - section_offsets[OBJECT_SECTION_DATA], writable_memory_end - section_offsets[OBJECT_SECTION_DATA], ELF_PAGE_SIZE);
    BUSTER_LINK_PROGRAM_HEADER(2, 6, dynamic_offset, dynamic_address, dynamic_size, dynamic_size, 8);
    u64 thread_local_file_size = object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length;
    u64 thread_local_memory_size = align_forward(thread_local_file_size, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment) +
                                   object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size;
    link_write_u32(bytes, program_header, 7);
    link_write_u32(bytes, program_header + 4, 4);
    link_write_u64(bytes, program_header + 8, section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA]);
    link_write_u64(bytes, program_header + 16, image_base + section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA]);
    link_write_u64(bytes, program_header + 24, image_base + section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA]);
    link_write_u64(bytes, program_header + 32, thread_local_file_size);
    link_write_u64(bytes, program_header + 40, thread_local_memory_size);
    link_write_u64(bytes, program_header + 48,
                   BUSTER_MAX(object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].alignment, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment));
    program_header += ELF_PROGRAM_HEADER_SIZE;
    if (eh_frame_header_size)
    {
        BUSTER_LINK_PROGRAM_HEADER(0x6474e550, 4, eh_frame_header_offset, image_base + eh_frame_header_offset, eh_frame_header_size, eh_frame_header_size, 4);
    }
    BUSTER_LINK_PROGRAM_HEADER(0x6474e551, 6, 0, 0, 0, 0, 16);
#undef BUSTER_LINK_PROGRAM_HEADER
    link_elf_section_table_append(arena, &result, object, image_base, section_offsets,
                                  (LinkElfSectionTableLayout){
                                      .eh_frame_header_offset = eh_frame_header_offset,
                                      .eh_frame_header_size = eh_frame_header_size,
                                      .interpreter_offset = interpreter_offset,
                                      .interpreter_size = interpreter_size,
                                      .plt_offset = plt_offset,
                                      .plt_size = plt_size,
                                      .dynamic_string_offset = dynamic_string_offset,
                                      .dynamic_string_size = dynamic_string_size,
                                      .dynamic_symbol_offset = dynamic_symbol_offset,
                                      .dynamic_symbol_size = dynamic_symbol_size,
                                      .hash_offset = hash_offset,
                                      .hash_size = hash_size,
                                      .version_symbol_offset = version_symbol_offset,
                                      .version_symbol_size = version_symbol_size,
                                      .version_need_offset = version_need_offset,
                                      .version_need_size = version_need_size,
                                      .version_need_count = version_need_count,
                                      .relocation_offset = relocation_offset,
                                      .relocation_size = relocation_size,
                                      .got_offset = got_offset,
                                      .got_size = got_size,
                                      .dynamic_offset = dynamic_offset,
                                      .dynamic_size = dynamic_size,
                                      .import_indices = import_indices,
                                      .copy_alias_names = alias_names,
                                      .copy_alias_symbol_offset = dynamic_symbol_offset + ((u64)import_count + 1) * ELF_SYMBOL_SIZE,
                                      .copy_alias_count = alias_count,
                                      .copy_zero_size = copy_slot_count ? copy_slot_cursor - section_offsets[OBJECT_SECTION_ZERO] : 0,
                                      .dynamic = true,
                                  });
    if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
    {
        result.error = LINK_ERROR_FILE_WRITE;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL void link_pe_section_header(u8* bytes, u64 offset, char const* name, u32 virtual_size, u32 virtual_address, u32 raw_size, u32 raw_offset,
                                                u32 characteristics)
{
    memcpy(bytes + offset, name, 8);
    link_write_u32(bytes, offset + 8, virtual_size);
    link_write_u32(bytes, offset + 12, virtual_address);
    link_write_u32(bytes, offset + 16, raw_size);
    link_write_u32(bytes, offset + 20, raw_offset);
    link_write_u32(bytes, offset + 36, characteristics);
}

// The AArch64 counterpart of link_x86_patch_initializer_calls: one `bl` per
// initializer, at the word index the stub builder reported.
BUSTER_GLOBAL_LOCAL bool link_aarch64_patch_initializer_calls(u8* bytes, ObjectFile* object, LinkInitializerPlan const* plan, u64 const* section_offsets,
                                                              u64 image_base, u64 entry_stub_offset, u32 const* initializer_words)
{
    bool result = true;
    u32 count = plan->constructor_count + plan->destructor_count;
    for (u32 index = 0; index < count && result; index += 1)
    {
        LinkInitializerEntry entry = index < plan->constructor_count ? plan->constructors[index] : plan->destructors[index - plan->constructor_count];
        ObjectSymbol* symbol = entry.symbol < object->symbol_count ? object->symbols + entry.symbol : 0;
        if (!symbol || symbol->section == OBJECT_SECTION_UNDEFINED || symbol->section >= OBJECT_SECTION_COUNT)
        {
            result = false;
        }
        else
        {
            u64 target = image_base + section_offsets[symbol->section] + symbol->value + (u64)entry.addend;
            u64 offset = entry_stub_offset + (u64)initializer_words[index] * sizeof(u32);
            u32 instruction = 0;
            result = link_aarch64_branch_encode(A64_OPCODE_BL, (s64)target - (s64)(image_base + offset), &instruction);
            if (result)
            {
                link_write_u32(bytes, offset, instruction);
            }
        }
    }

    return result;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_elf64_aarch64(Arena* arena, ObjectFile* object, NativeExecutableLinkOptions options)
{
    NativeExecutableLinkResult result = {0};
    if ((options.dynamic_library_count && !options.dynamic_libraries) || object->section_count < OBJECT_SECTION_COUNT || !object->sections ||
        (object->symbol_count && !object->symbols) || (object->relocation_count && !object->relocations))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    ObjectFile stripped_object = {0};
    LinkInitializerPlan plan = {0};
    if (!link_initializer_plan_build(arena, object, &stripped_object, &plan))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    object = &stripped_object;
    u32 entry_stub_capacity = link_aarch64_elf_entry_stub_words(false, &plan);
    u32* entry_stub = arena_allocate(arena, u32, entry_stub_capacity);
    u32* initializer_words =
        arena_allocate(arena, u32, plan.constructor_count + plan.destructor_count ? plan.constructor_count + plan.destructor_count : 1);
    u32 entry_stub_word = 0;
    u32 entry_stub_words = link_aarch64_build_elf_entry_stub(entry_stub, entry_stub_capacity, false, &plan, &entry_stub_word, 0, 0, 0, initializer_words);
    u64 entry_stub_size = (u64)entry_stub_words * sizeof(u32);
    if (!entry_stub_words)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
    {
        ObjectSymbol* symbol = &object->symbols[symbol_index];
        if (symbol->section == OBJECT_SECTION_UNDEFINED && !link_elf_symbol_resolves_to_zero(0, symbol, false))
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = symbol->name;
            return result;
        }
    }
    String8 entry_name = options.entry_symbol.length ? options.entry_symbol : S8("main");
    u32 entry_symbol_index = link_symbol_find(object, entry_name);
    if (entry_symbol_index == UINT32_MAX || object->symbols[entry_symbol_index].section == OBJECT_SECTION_UNDEFINED ||
        object->symbols[entry_symbol_index].kind != OBJECT_SYMBOL_FUNCTION)
    {
        result.error = LINK_ERROR_ENTRY_SYMBOL;
        result.symbol = entry_name;
        return result;
    }
    LinkElfEhFrameTable eh_frame_table = link_elf_eh_frame_table_build(arena, object);
    if (!eh_frame_table.valid)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    u64 eh_frame_header_size = eh_frame_table.count ? 12 + (u64)eh_frame_table.count * 8 : 0;
    bool has_writable = object->sections[OBJECT_SECTION_DATA].data.length || object->sections[OBJECT_SECTION_ZERO].virtual_size;
    u32 load_program_header_count = has_writable ? 2 : 1;
    u32 program_header_count = load_program_header_count + (eh_frame_header_size != 0);
    u64 header_end = ELF_HEADER_SIZE + (u64)program_header_count * ELF_PROGRAM_HEADER_SIZE;
    u64 section_offsets[OBJECT_SECTION_COUNT] = {0};
    u64 entry_stub_offset = align_forward(header_end, 16);
    section_offsets[OBJECT_SECTION_TEXT] = align_forward(entry_stub_offset + entry_stub_size, object->sections[OBJECT_SECTION_TEXT].alignment);
    section_offsets[OBJECT_SECTION_READ_ONLY_DATA] = align_forward(section_offsets[OBJECT_SECTION_TEXT] + object->sections[OBJECT_SECTION_TEXT].data.length,
                                                                   object->sections[OBJECT_SECTION_READ_ONLY_DATA].alignment);
    u64 eh_frame_header_offset = align_forward(section_offsets[OBJECT_SECTION_READ_ONLY_DATA] + object->sections[OBJECT_SECTION_READ_ONLY_DATA].data.length, 4);
    section_offsets[OBJECT_SECTION_UNWIND] = align_forward(eh_frame_header_offset + eh_frame_header_size, object->sections[OBJECT_SECTION_UNWIND].alignment);
    u64 read_only_end = section_offsets[OBJECT_SECTION_UNWIND] + object->sections[OBJECT_SECTION_UNWIND].data.length;
    if (!link_elf_virtual_align(read_only_end, BUSTER_MAX((u32)ELF_PAGE_SIZE, object->sections[OBJECT_SECTION_DATA].alignment),
                                &section_offsets[OBJECT_SECTION_DATA]))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u64 file_size = object->sections[OBJECT_SECTION_DATA].data.length ? section_offsets[OBJECT_SECTION_DATA] + object->sections[OBJECT_SECTION_DATA].data.length
                                                                      : read_only_end;
    if (!link_elf_virtual_align(BUSTER_MAX(file_size, section_offsets[OBJECT_SECTION_DATA]), object->sections[OBJECT_SECTION_ZERO].alignment,
                                &section_offsets[OBJECT_SECTION_ZERO]))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u64 writable_memory_end = section_offsets[OBJECT_SECTION_ZERO] + object->sections[OBJECT_SECTION_ZERO].virtual_size;
    if (file_size > UINT32_MAX)
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    result.executable = (ByteSlice){
        // The image is written section by section over a zero background, and
        // the background is what a fresh arena mapping already is: the fill
        // now covers only the arena's dirty prefix, which for the one image a
        // link produces is nothing at all.
        .pointer = arena_allocate_zeroed(arena, u8, file_size),
        .length = file_size,
    };
    u8* bytes = result.executable.pointer;
    memcpy(bytes + entry_stub_offset, entry_stub, entry_stub_size);
    for (u32 section = 0; section < OBJECT_SECTION_COUNT; section += 1)
    {
        if (object_section_kind_is_debug((ObjectSectionKind)section))
        {
            continue;
        }
        ByteSlice data = object->sections[section].data;
        if (data.length)
        {
            memcpy(bytes + section_offsets[section], data.pointer, data.length);
        }
    }
    u64 image_base = ELF_IMAGE_BASE;
    ObjectSymbol* entry_symbol = &object->symbols[entry_symbol_index];
    u64 entry_address = image_base + section_offsets[entry_symbol->section] + entry_symbol->value;
    u64 call_offset = entry_stub_offset + (u64)entry_stub_word * sizeof(u32);
    s64 call_displacement = (s64)entry_address - (s64)(image_base + call_offset);
    u32 call_instruction = 0;
    if (!link_aarch64_branch_encode(A64_OPCODE_BL, call_displacement, &call_instruction))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    link_write_u32(bytes, call_offset, call_instruction);
    if (!link_aarch64_patch_initializer_calls(bytes, object, &plan, section_offsets, image_base, entry_stub_offset, initializer_words))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation* relocation = &object->relocations[index];
        if (relocation->section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation->section))
        {
            continue;
        }
        if (relocation->section >= OBJECT_SECTION_COUNT || relocation->symbol >= object->symbol_count)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        ObjectSection* section = &object->sections[relocation->section];
        u64 width = relocation->kind == OBJECT_RELOCATION_ABSOLUTE64 ? 8 : 4;
        if (relocation->offset > section->data.length || width > section->data.length - relocation->offset)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        ObjectSymbol* symbol = &object->symbols[relocation->symbol];
        // Address zero is the answer for a reference nothing defines and
        // nothing can define; every other undefined symbol was rejected above.
        bool absent_weak = link_elf_symbol_resolves_to_zero(0, symbol, false);
        if (!absent_weak && symbol->section >= OBJECT_SECTION_COUNT)
        {
            result.error = LINK_ERROR_RELOCATION;
            result.symbol = symbol->name;
            return result;
        }
        u64 symbol_address = 0;
        if (!absent_weak && (!link_u64_add(image_base, section_offsets[symbol->section], &symbol_address) ||
                             !link_u64_add(symbol_address, symbol->value, &symbol_address)))
        {
            result.error = LINK_ERROR_RELOCATION;
            result.symbol = symbol->name;
            return result;
        }
        u64 place_address = image_base + section_offsets[relocation->section] + relocation->offset;
        u64 output_offset = section_offsets[relocation->section] + relocation->offset;
        if (relocation->kind == OBJECT_RELOCATION_AARCH64_CALL26 || relocation->kind == OBJECT_RELOCATION_AARCH64_JUMP26)
        {
            s64 displacement = 0;
            u32 instruction = link_read_u32(section->data.pointer, relocation->offset);
            u32 patched = 0;
            if ((place_address & 3) || !link_address_difference(symbol_address, place_address, relocation->addend, &displacement) ||
                !link_aarch64_branch_relocate(relocation->kind, instruction, displacement, &patched))
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u32(bytes, output_offset, patched);
        }
        else if (relocation->kind == OBJECT_RELOCATION_AARCH64_ELF_PAGE21 || relocation->kind == OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12)
        {
            u32 patched = 0;
            if (section->alignment < 4 ||
                !object_aarch64_elf_page_relocate(relocation->kind, link_read_u32(section->data.pointer, relocation->offset),
                                                place_address, symbol_address, relocation->addend, &patched))
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u32(bytes, output_offset, patched);
        }
        else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PREL32)
        {
            s64 value = 0;
            if (section->alignment < 4 || (place_address & 3) ||
                !link_address_difference(symbol_address, place_address, relocation->addend, &value) || value < INT32_MIN || value > INT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u32(bytes, output_offset, (u32)(s32)value);
        }
        else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
        {
            u64 value = 0;
            if (!link_address_addend(symbol_address, relocation->addend, &value))
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            link_write_u64(bytes, output_offset, value);
        }
        else
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
    }
    if (!link_elf_eh_frame_header_write(bytes, file_size, &eh_frame_table, object, image_base, section_offsets, eh_frame_header_offset))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    bytes[0] = 0x7f;
    bytes[1] = 'E';
    bytes[2] = 'L';
    bytes[3] = 'F';
    bytes[4] = 2;
    bytes[5] = 1;
    bytes[6] = 1;
    link_write_u16(bytes, 16, 2);
    link_write_u16(bytes, 18, ELF_MACHINE_AARCH64);
    link_write_u32(bytes, 20, 1);
    link_write_u64(bytes, 24, image_base + entry_stub_offset);
    link_write_u64(bytes, 32, ELF_HEADER_SIZE);
    link_write_u16(bytes, 52, ELF_HEADER_SIZE);
    link_write_u16(bytes, 54, ELF_PROGRAM_HEADER_SIZE);
    link_write_u16(bytes, 56, (u16)program_header_count);
    u64 program_header = ELF_HEADER_SIZE;
    link_write_u32(bytes, program_header, 1);
    link_write_u32(bytes, program_header + 4, 5);
    link_write_u64(bytes, program_header + 16, image_base);
    link_write_u64(bytes, program_header + 24, image_base);
    link_write_u64(bytes, program_header + 32, read_only_end);
    link_write_u64(bytes, program_header + 40, read_only_end);
    link_write_u64(bytes, program_header + 48, ELF_PAGE_SIZE);
    if (load_program_header_count == 2)
    {
        program_header += ELF_PROGRAM_HEADER_SIZE;
        u64 writable_file_size = file_size > section_offsets[OBJECT_SECTION_DATA] ? file_size - section_offsets[OBJECT_SECTION_DATA] : 0;
        u64 writable_memory_size = writable_memory_end - section_offsets[OBJECT_SECTION_DATA];
        link_write_u32(bytes, program_header, 1);
        link_write_u32(bytes, program_header + 4, 6);
        link_write_u64(bytes, program_header + 8, section_offsets[OBJECT_SECTION_DATA]);
        link_write_u64(bytes, program_header + 16, image_base + section_offsets[OBJECT_SECTION_DATA]);
        link_write_u64(bytes, program_header + 24, image_base + section_offsets[OBJECT_SECTION_DATA]);
        link_write_u64(bytes, program_header + 32, writable_file_size);
        link_write_u64(bytes, program_header + 40, writable_memory_size);
        link_write_u64(bytes, program_header + 48, ELF_PAGE_SIZE);
    }
    if (eh_frame_header_size)
    {
        program_header = ELF_HEADER_SIZE + (u64)load_program_header_count * ELF_PROGRAM_HEADER_SIZE;
        link_write_u32(bytes, program_header, 0x6474e550);
        link_write_u32(bytes, program_header + 4, 4);
        link_write_u64(bytes, program_header + 8, eh_frame_header_offset);
        link_write_u64(bytes, program_header + 16, image_base + eh_frame_header_offset);
        link_write_u64(bytes, program_header + 24, image_base + eh_frame_header_offset);
        link_write_u64(bytes, program_header + 32, eh_frame_header_size);
        link_write_u64(bytes, program_header + 40, eh_frame_header_size);
        link_write_u64(bytes, program_header + 48, 4);
    }
    link_elf_section_table_append(arena, &result, object, image_base, section_offsets,
                                  (LinkElfSectionTableLayout){
                                      .eh_frame_header_offset = eh_frame_header_offset,
                                      .eh_frame_header_size = eh_frame_header_size,
                                  });
    if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
    {
        result.error = LINK_ERROR_FILE_WRITE;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL u32 link_aarch64_adrp(u32 destination, u64 instruction_address, u64 target_address, bool* valid)
{
    u32 word = 0;
    if (!valid || !a64_adrp_encode(destination, instruction_address, target_address, &word))
    {
        if (valid)
        {
            *valid = false;
        }
        return 0;
    }
    return word;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_elf64_aarch64_dynamic(Arena* arena, ObjectFile* object,
                                                                                            NativeExecutableLinkOptions options, LinkElfIndex* exports)
{
    // argc, argv and envp off the stack, the initializers, `bl main`,
    // `bl exit` and a trap — link_aarch64_build_elf_entry_stub emits the
    // words.  The hosted shape calls libc's exit for the reason
    // link_x86_build_elf_entry_stub states; the freestanding writer above
    // keeps `mov x8,#93 / svc #0`.
    static char8 const interpreter[] = "/lib/ld-linux-aarch64.so.1";
    NativeExecutableLinkResult result = {0};
    ObjectFile hosted_object = {0};
    u32 exit_symbol_index = 0;
    u32 atexit_symbol_index = 0;
    if (!link_elf_hosted_exit_symbol(arena, object, &hosted_object, &exit_symbol_index, &atexit_symbol_index))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    object = &hosted_object;
    ObjectFile stripped_object = {0};
    LinkInitializerPlan plan = {0};
    if (!link_initializer_plan_build(arena, object, &stripped_object, &plan))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    u32 initializer_count = plan.constructor_count + plan.destructor_count;
    u32 entry_stub_capacity = link_aarch64_elf_entry_stub_words(true, &plan);
    u32* entry_stub = arena_allocate(arena, u32, entry_stub_capacity);
    u32* initializer_words = arena_allocate(arena, u32, initializer_count ? initializer_count : 1);
    u32 entry_stub_word = 0;
    u32 exit_stub_word = 0;
    u32 atexit_stub_word = 0;
    u32 loader_atexit_stub_word = 0;
    u32 entry_stub_words = link_aarch64_build_elf_entry_stub(entry_stub, entry_stub_capacity, true, &plan, &entry_stub_word, &exit_stub_word,
                                                             &atexit_stub_word, &loader_atexit_stub_word, initializer_words);
    // The slot this overlays is the x86-64 hosted stub's, whatever length the
    // same plan gave it there; building that stub here is how the two agree
    // without either writer publishing a formula.
    u32 x86_stub_capacity = link_x86_elf_entry_stub_capacity(&plan);
    u8* x86_stub = arena_allocate(arena, u8, x86_stub_capacity);
    u32 x86_stub_size = 0;
    buster_x86_metadata_prewarm();
    if (!entry_stub_words || !link_x86_build_elf_entry_stub(x86_stub, x86_stub_capacity, &x86_stub_size, 0, true, 0, 0, 0, &plan, 0))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    ObjectRelocation* converted_relocations = arena_allocate(arena, ObjectRelocation, object->relocation_count);
    u32 converted_count = 0;
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation relocation = object->relocations[index];
        if (relocation.kind == OBJECT_RELOCATION_AARCH64_ELF_PAGE21 || relocation.kind == OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12)
        {
            // The layout staging writer cannot patch an A64 page field. Do
            // not impose an unrelated x86 rel32/absolute32 range on it; the
            // overlay below applies the original relocation after layout.
            if (relocation.section >= OBJECT_SECTION_COUNT || relocation.symbol >= object->symbol_count)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            ObjectSection* section = object->sections + relocation.section;
            if (section->alignment < 4 || (relocation.offset & 3) || relocation.offset > section->data.length ||
                4 > section->data.length - relocation.offset)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
        }
        else
        {
            if (relocation.kind == OBJECT_RELOCATION_AARCH64_CALL26 || relocation.kind == OBJECT_RELOCATION_AARCH64_JUMP26 ||
                relocation.kind == OBJECT_RELOCATION_AARCH64_PREL32)
            {
                relocation.kind = OBJECT_RELOCATION_X86_64_PC32;
            }
            else if (relocation.kind == OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_HI12 ||
                     relocation.kind == OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_LO12)
            {
                relocation.kind = OBJECT_RELOCATION_X86_64_TPOFF32;
            }
            converted_relocations[converted_count++] = relocation;
        }
    }
    ObjectFile converted = *object;
    converted.relocations = converted_relocations;
    converted.relocation_count = converted_count;
    NativeExecutableLinkOptions staging_options = options;
    staging_options.output_path = (String8){0};
    // The staging link is handed the object with its initializer arrays still
    // on it, because the plan it derives from them is what decides the entry
    // stub slot this overlay has to reproduce.  Everything below reads the
    // stripped copy, whose relocations no longer name sections the image does
    // not carry.
    result = link_native_executable_elf64_x86_64_dynamic(arena, &converted, staging_options, exports);
    if (result.error != LINK_ERROR_NONE)
    {
        return result;
    }
    object = &stripped_object;
    u8* bytes = result.executable.pointer;
    u64 image_base = ELF_IMAGE_BASE;
    u32 program_header_count = bytes[56] | ((u32)bytes[57] << 8);
    u64 header_end = ELF_HEADER_SIZE + (u64)program_header_count * ELF_PROGRAM_HEADER_SIZE;
    u64 entry_stub_offset = align_forward(header_end, 16);
    u64 section_offsets[OBJECT_SECTION_COUNT] = {0};
    // The layout below has to be the one the x86-64 dynamic writer produced,
    // so the stub slot is that writer's hosted stub size, not this stub's.
    section_offsets[OBJECT_SECTION_TEXT] =
        align_forward(entry_stub_offset + link_elf_entry_stub_slot(x86_stub_size, &plan), object->sections[OBJECT_SECTION_TEXT].alignment);
    u64 plt_offset = align_forward(section_offsets[OBJECT_SECTION_TEXT] + object->sections[OBJECT_SECTION_TEXT].data.length, 16);
    u32 import_count = 0;
    u32* import_indices = arena_allocate(arena, u32, object->symbol_count);
    for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
    {
        import_indices[symbol_index] = UINT32_MAX;
        if (link_elf_symbol_needs_dynamic_import(exports, &object->symbols[symbol_index]))
        {
            import_indices[symbol_index] = import_count++;
        }
    }
    u64 plt_size = (u64)(import_count + 1) * ELF_PLT_ENTRY_SIZE;
    memset(bytes + plt_offset, 0, plt_size);
    // Clear the whole slot: this stub is shorter than the x86-64 one it
    // replaces, and leaving that tail behind would put x86 bytes past the
    // trap.
    memset(bytes + entry_stub_offset, 0, link_elf_entry_stub_slot(x86_stub_size, &plan));
    memcpy(bytes + entry_stub_offset, entry_stub, (u64)entry_stub_words * sizeof(u32));
    memcpy(bytes + link_read_u64(bytes, ELF_HEADER_SIZE + ELF_PROGRAM_HEADER_SIZE + 8), interpreter, sizeof(interpreter));
    link_write_u16(bytes, 18, 183);
    u64 dynamic_program_header = ELF_HEADER_SIZE + 4 * ELF_PROGRAM_HEADER_SIZE;
    u64 dynamic_offset = link_read_u64(bytes, dynamic_program_header + 8);
    u64 relocation_offset = 0;
    u64 dynamic_symbol_offset = 0;
    u64 copy_relocation_offset = 0;
    u64 copy_relocation_size = 0;
    // Walked to its DT_NULL terminator, over the extent PT_DYNAMIC states,
    // rather than to a length this writer recomputes from the other one's
    // policy: that array grows both with the copy relocations and with the
    // symbol versions an image needs, and a count that stops short leaves the
    // tags after it unpatched.  DT_RELA/DT_RELASZ are also how the copy
    // range's extent is learned at all -- it counts slots, not data imports,
    // because two imported names for one library object share one slot.
    u64 dynamic_count = link_read_u64(bytes, dynamic_program_header + 32) / ELF_DYNAMIC_SIZE;
    for (u64 index = 0; index < dynamic_count; index += 1)
    {
        u64 entry = dynamic_offset + index * ELF_DYNAMIC_SIZE;
        u64 tag = link_read_u64(bytes, entry);
        if (!tag)
        {
            break;
        }
        if (tag == 3)
        {
            link_write_u64(bytes, entry, 24);
            link_write_u64(bytes, entry + 8, 0);
        }
        else if (tag == 23)
        {
            u64 address = link_read_u64(bytes, entry + 8);
            relocation_offset = address - image_base;
        }
        else if (tag == 6)
        {
            u64 address = link_read_u64(bytes, entry + 8);
            dynamic_symbol_offset = address - image_base;
        }
        else if (tag == 7)
        {
            u64 address = link_read_u64(bytes, entry + 8);
            copy_relocation_offset = address - image_base;
        }
        else if (tag == 8)
        {
            copy_relocation_size = link_read_u64(bytes, entry + 8);
        }
    }
    if (!relocation_offset || (copy_relocation_offset != 0) != (copy_relocation_size != 0))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    bool valid = true;
    for (u32 import_index = 0; import_index < import_count; import_index += 1)
    {
        u64 relocation = relocation_offset + (u64)import_index * ELF_RELOCATION_SIZE;
        u64 slot_address = link_read_u64(bytes, relocation);
        link_write_u64(bytes, relocation + 8, ((u64)(import_index + 1) << 32) | ELF_RELOCATION_TYPE_AARCH64_JUMP_SLOT);
        u64 thunk_offset = plt_offset + (u64)(import_index + 1) * ELF_PLT_ENTRY_SIZE;
        u64 thunk_address = image_base + thunk_offset;
        u64 page_offset = slot_address & 0xfff;
        if (page_offset % 8 || page_offset / 8 > 0xfff)
        {
            valid = false;
            break;
        }
        link_write_u32(bytes, thunk_offset, link_aarch64_adrp(16, thunk_address, slot_address, &valid));
        link_write_u32(bytes, thunk_offset + 4, 0xf9400000 | ((u32)(page_offset / 8) << 10) | (16 << 5) | 17);
        link_write_u32(bytes, thunk_offset + 8, 0xd61f0220);
        link_write_u32(bytes, thunk_offset + 12, 0xd503201f);
        link_write_u64(bytes, (slot_address - image_base), 0);
    }
    // The copy relocations sit past the PLT range the loop above walks, so
    // they still carry the type the staging x86-64 writer stamped -- which on
    // AArch64 is not a copy but a 16-bit absolute move the loader would apply
    // over the slot.  Only the type is wrong: the slot address and the dynamic
    // symbol index the entry already holds are machine-independent, and the
    // alias dynamic symbols carry no relocation of their own to fix up.
    for (u64 entry = 0; entry + ELF_RELOCATION_SIZE <= copy_relocation_size; entry += ELF_RELOCATION_SIZE)
    {
        u64 relocation = copy_relocation_offset + entry;
        u64 info = link_read_u64(bytes, relocation + 8);
        link_write_u64(bytes, relocation + 8, (info & ~(u64)UINT32_MAX) | ELF_RELOCATION_TYPE_AARCH64_COPY);
    }
    String8 entry_name = options.entry_symbol.length ? options.entry_symbol : S8("main");
    u32 entry_symbol_index = link_symbol_find(object, entry_name);
    if (!valid || entry_symbol_index == UINT32_MAX)
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    ObjectSymbol* entry_symbol = &object->symbols[entry_symbol_index];
    u64 entry_address = image_base + section_offsets[entry_symbol->section] + entry_symbol->value;
    u64 call_offset = entry_stub_offset + (u64)entry_stub_word * sizeof(u32);
    s64 call_displacement = (s64)entry_address - (s64)(image_base + call_offset);
    u32 call_instruction = 0;
    if (!link_aarch64_branch_encode(A64_OPCODE_BL, call_displacement, &call_instruction))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    link_write_u32(bytes, call_offset, call_instruction);
    // The stub's second BL: `exit` through its PLT thunk when imported, or the
    // program's own definition when it has one.
    u64 exit_address = 0;
    if (!link_elf_hosted_call_address(object, exit_symbol_index, import_indices, section_offsets, image_base, image_base + plt_offset, &exit_address))
    {
        result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
        result.symbol = object->symbols[exit_symbol_index].name;
        return result;
    }
    u64 exit_call_offset = entry_stub_offset + (u64)exit_stub_word * sizeof(u32);
    u32 exit_instruction = 0;
    if (!link_aarch64_branch_encode(A64_OPCODE_BL, (s64)exit_address - (s64)(image_base + exit_call_offset), &exit_instruction))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    link_write_u32(bytes, exit_call_offset, exit_instruction);
    // The same registrations as the x86-64 staging writer, in AArch64 words.
    u32 registration_words[] = {loader_atexit_stub_word, atexit_stub_word};
    for (u32 registration = 0; registration < 1u + (plan.destructor_count != 0); registration += 1)
    {
        u64 atexit_address = 0;
        if (atexit_symbol_index >= object->symbol_count ||
            !link_elf_hosted_call_address(object, atexit_symbol_index, import_indices, section_offsets, image_base, image_base + plt_offset, &atexit_address))
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = S8("__cxa_atexit");
            return result;
        }
        u64 atexit_call_offset = entry_stub_offset + (u64)registration_words[registration] * sizeof(u32);
        u32 atexit_instruction = 0;
        if (!link_aarch64_branch_encode(A64_OPCODE_BL, (s64)atexit_address - (s64)(image_base + atexit_call_offset), &atexit_instruction))
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        link_write_u32(bytes, atexit_call_offset, atexit_instruction);
    }
    if (!link_aarch64_patch_initializer_calls(bytes, object, &plan, section_offsets, image_base, entry_stub_offset, initializer_words))
    {
        result.error = LINK_ERROR_RELOCATION;
        return result;
    }
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation* relocation = &object->relocations[index];
        if (relocation->kind != OBJECT_RELOCATION_AARCH64_CALL26 && relocation->kind != OBJECT_RELOCATION_AARCH64_JUMP26 &&
            relocation->kind != OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_HI12 &&
            relocation->kind != OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_LO12 &&
            relocation->kind != OBJECT_RELOCATION_AARCH64_ELF_PAGE21 && relocation->kind != OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12)
        {
            continue;
        }
        bool page_relocation = relocation->kind == OBJECT_RELOCATION_AARCH64_ELF_PAGE21 ||
                               relocation->kind == OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12;
        ObjectSymbol* symbol = &object->symbols[relocation->symbol];
        u64 output_offset = section_offsets[relocation->section] + relocation->offset;
        if (relocation->kind == OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_HI12 || relocation->kind == OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_LO12)
        {
            if ((symbol->section != OBJECT_SECTION_THREAD_LOCAL_DATA && symbol->section != OBJECT_SECTION_THREAD_LOCAL_ZERO) || relocation->addend < 0)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            u64 initialized_size =
                align_forward(object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment);
            u64 symbol_offset = symbol->section == OBJECT_SECTION_THREAD_LOCAL_ZERO ? initialized_size + symbol->value : symbol->value;
            u64 thread_pointer_offset = 16 + symbol_offset + (u64)relocation->addend;
            if (thread_pointer_offset > 0xffffff)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            u32 instruction = link_read_u32(object->sections[relocation->section].data.pointer, relocation->offset);
            u32 immediate =
                relocation->kind == OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_HI12 ? (u32)(thread_pointer_offset >> 12) : (u32)(thread_pointer_offset & 0xfff);
            instruction &= ~(UINT32_C(0xfff) << 10);
            instruction |= immediate << 10;
            link_write_u32(bytes, output_offset, instruction);
            continue;
        }
        u64 symbol_address = 0;
        if (symbol->section == OBJECT_SECTION_UNDEFINED && import_indices[relocation->symbol] == UINT32_MAX)
        {
            // No PLT thunk for a reference nothing can define: the branch is
            // relocated against address zero, which is what the program asked
            // for by declaring the symbol weak. The numbering above is what
            // decided that, exactly as in the x86-64 writer.
            symbol_address = 0;
        }
        else if (symbol->section == OBJECT_SECTION_UNDEFINED && symbol->kind == OBJECT_SYMBOL_DATA && page_relocation)
        {
            // The staging writer already assigned copy slots, including
            // aliases. Their dynamic symbols carry the authoritative address.
            u64 value_offset = dynamic_symbol_offset + ((u64)import_indices[relocation->symbol] + 1) * ELF_SYMBOL_SIZE + 8;
            if (!dynamic_symbol_offset || value_offset > result.executable.length || 8 > result.executable.length - value_offset)
            {
                result.error = LINK_ERROR_RELOCATION;
                return result;
            }
            symbol_address = link_read_u64(bytes, value_offset);
        }
        else if (symbol->section == OBJECT_SECTION_UNDEFINED)
        {
            if (relocation->addend && !page_relocation)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            u32 import_index = import_indices[relocation->symbol];
            if (import_index == UINT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
            u64 plt_slot = (u64)import_index + 1;
            if (import_index == UINT32_MAX || plt_slot > UINT64_MAX / ELF_PLT_ENTRY_SIZE ||
                !link_u64_add(image_base, plt_offset, &symbol_address) ||
                !link_u64_add(symbol_address, plt_slot * ELF_PLT_ENTRY_SIZE, &symbol_address))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
        }
        else
        {
            if (!link_u64_add(image_base, section_offsets[symbol->section], &symbol_address) ||
                !link_u64_add(symbol_address, symbol->value, &symbol_address))
            {
                result.error = LINK_ERROR_RELOCATION;
                result.symbol = symbol->name;
                return result;
            }
        }
        u64 place_address = image_base + output_offset;
        s64 displacement = 0;
        u32 instruction = link_read_u32(object->sections[relocation->section].data.pointer, relocation->offset);
        u32 patched = 0;
        bool relocated = page_relocation
                             ? object_aarch64_elf_page_relocate(relocation->kind, instruction, place_address, symbol_address, relocation->addend, &patched)
                             : !(place_address & 3) && link_address_difference(symbol_address, place_address, relocation->addend, &displacement) &&
                               link_aarch64_branch_relocate(relocation->kind, instruction, displacement, &patched);
        if (!relocated)
        {
            result.error = LINK_ERROR_RELOCATION;
            return result;
        }
        link_write_u32(bytes, output_offset, patched);
    }
    if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
    {
        result.error = LINK_ERROR_FILE_WRITE;
    }
    return result;
}

// PE32+ format facts shared by the hosted and UEFI writers, and the hosted
// writer's stack/heap policy (written into the optional header at offsets
// 72..96 as reserve/commit pairs). Each writer keeps its own section-kind
// list local — the two images carry different section sets.
enum
{
    PE_OFFSET = 0x80,
    PE_COFF_HEADER_SIZE = 20,
    PE_OPTIONAL_HEADER_SIZE = 240,
    PE_SECTION_HEADER_SIZE = 40,
    PE_FILE_ALIGNMENT = 0x200,
    PE_SECTION_ALIGNMENT = 0x1000,
    LINK_PE_STACK_RESERVE = 8 * 1024 * 1024,
    LINK_PE_STACK_COMMIT = 4096,
    LINK_PE_HEAP_RESERVE = 1024 * 1024,
    LINK_PE_HEAP_COMMIT = 4096,
};

BUSTER_GLOBAL_LOCAL String8 link_pe_pdb_path(Arena* arena, String8 executable_path)
{
    if (!executable_path.length)
    {
        executable_path = S8("a.exe");
    }
    u64 dot = executable_path.length;
    u64 slash = 0;
    for (u64 index = 0; index < executable_path.length; index += 1)
    {
        if (executable_path.pointer[index] == '/' || executable_path.pointer[index] == '\\')
        {
            slash = index + 1;
        }
        else if (executable_path.pointer[index] == '.' && index >= slash)
        {
            dot = index;
        }
    }
    return string_format_z(arena, S8("{S8}.pdb"), string_slice(executable_path, 0, dot));
}

BUSTER_GLOBAL_LOCAL void link_u32_shell_sort(u32* values, u32 count)
{
    for (u32 gap = count / 2; gap; gap /= 2)
    {
        for (u32 index = gap; index < count; index += 1)
        {
            u32 value = values[index];
            u32 cursor = index;
            while (cursor >= gap && values[cursor - gap] > value)
            {
                values[cursor] = values[cursor - gap];
                cursor -= gap;
            }
            values[cursor] = value;
        }
    }
}

BUSTER_GLOBAL_LOCAL bool link_pe_base_relocation_size(u32 const* rvas, u32 count, u64* size)
{
    if ((!rvas && count) || !size)
    {
        return false;
    }
    *size = 0;
    for (u32 index = 0; index < count;)
    {
        if (index && rvas[index] == rvas[index - 1])
        {
            return false;
        }
        u32 page = rvas[index] & ~UINT32_C(0xfff);
        u32 end = index + 1;
        while (end < count && (rvas[end] & ~UINT32_C(0xfff)) == page)
        {
            if (rvas[end] == rvas[end - 1])
            {
                return false;
            }
            end += 1;
        }
        u64 unaligned = 0;
        u64 block = 0;
        if (!link_u64_add(8, (u64)(end - index) * sizeof(u16), &unaligned) || !link_u64_align_forward(unaligned, 4, &block) ||
            !link_u64_add(*size, block, size))
        {
            return false;
        }
        index = end;
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool link_pe_base_relocations_write(u8* bytes, u64 capacity, u64 output, u32 const* rvas, u32 count, u64 size)
{
    if (!bytes || (!rvas && count) || output > capacity || size > capacity - output)
    {
        return false;
    }
    u64 end_output = output + size;
    for (u32 index = 0; index < count;)
    {
        u32 page = rvas[index] & ~UINT32_C(0xfff);
        u32 end = index + 1;
        while (end < count && (rvas[end] & ~UINT32_C(0xfff)) == page)
        {
            end += 1;
        }
        u64 unaligned = 0;
        u64 block = 0;
        if (!link_u64_add(8, (u64)(end - index) * sizeof(u16), &unaligned) || !link_u64_align_forward(unaligned, 4, &block) ||
            output > end_output || block > end_output - output)
        {
            return false;
        }
        link_write_u32(bytes, output, page);
        link_write_u32(bytes, output + 4, (u32)block);
        u64 entry_output = output + 8;
        for (u32 relocation = index; relocation < end; relocation += 1)
        {
            link_write_u16(bytes, entry_output, (u16)((10u << 12) | (rvas[relocation] - page)));
            entry_output += sizeof(u16);
        }
        output += block;
        index = end;
    }
    return output == end_output;
}

ByteSlice link_pe_resolved_codeview(Arena* arena, ObjectFile* object, ObjectDebugModule* debug_module,
                                                       u32 const* object_output_sections, u64 const* object_section_offsets,
                                                       u32 output_section_count)
{
    ByteSlice result = {0};
    if (arena && object && debug_module && object_output_sections && object_section_offsets && output_section_count &&
        debug_module->symbols_size <= UINT32_MAX && debug_module->symbols_offset <= object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS].data.length &&
        debug_module->symbols_size <= object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS].data.length - debug_module->symbols_offset)
    {
        u8* bytes = arena_allocate(arena, u8, debug_module->symbols_size);
        memcpy(bytes, object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS].data.pointer + debug_module->symbols_offset, debug_module->symbols_size);
        for (u32 relocation_index = 0; relocation_index < object->relocation_count; relocation_index += 1)
        {
            ObjectRelocation* relocation = object->relocations + relocation_index;
            if (relocation->section != OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS || relocation->offset < debug_module->symbols_offset ||
                relocation->offset - debug_module->symbols_offset >= debug_module->symbols_size || relocation->symbol >= object->symbol_count)
            {
                continue;
            }
            u64 offset = relocation->offset - debug_module->symbols_offset;
            ObjectSymbol* symbol = object->symbols + relocation->symbol;
            if (symbol->section >= OBJECT_SECTION_COUNT || object_output_sections[symbol->section] >= output_section_count ||
                object_output_sections[symbol->section] >= UINT16_MAX)
            {
                return (ByteSlice){0};
            }
            if (relocation->kind == OBJECT_RELOCATION_COFF_SECREL32)
            {
                if (offset + 4 > debug_module->symbols_size || symbol->value > INT64_MAX || object_section_offsets[symbol->section] > INT64_MAX)
                {
                    return (ByteSlice){0};
                }
                s64 signed_value = (s64)symbol->value;
                if ((relocation->addend > 0 && signed_value > INT64_MAX - relocation->addend) ||
                    (relocation->addend < 0 && signed_value < INT64_MIN - relocation->addend))
                {
                    return (ByteSlice){0};
                }
                signed_value += relocation->addend;
                if (signed_value > INT64_MAX - (s64)object_section_offsets[symbol->section])
                {
                    return (ByteSlice){0};
                }
                signed_value += (s64)object_section_offsets[symbol->section];
                if (signed_value < 0 || signed_value > UINT32_MAX)
                {
                    return (ByteSlice){0};
                }
                memcpy(bytes + offset, &(u32){(u32)signed_value}, sizeof(u32));
            }
            else if (relocation->kind == OBJECT_RELOCATION_COFF_SECTION16)
            {
                u64 section = (u64)object_output_sections[symbol->section] + 1;
                if (offset + 2 > debug_module->symbols_size || relocation->addend < 0 ||
                    (u64)relocation->addend > UINT16_MAX - section)
                {
                    return (ByteSlice){0};
                }
                u16 resolved_section = (u16)(section + (u64)relocation->addend);
                memcpy(bytes + offset, &resolved_section, sizeof(resolved_section));
            }
        }
        result = (ByteSlice){.pointer = bytes, .length = debug_module->symbols_size};
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool link_pe_aarch64_tls_index_symbol(ObjectFile* object, u32 symbol_index)
{
    if (!object || symbol_index >= object->symbol_count)
    {
        return false;
    }
    ObjectSymbol* symbol = object->symbols + symbol_index;
    if (symbol->section != OBJECT_SECTION_UNDEFINED || !symbol->global || symbol->kind != OBJECT_SYMBOL_DATA ||
        !string_equal(symbol->name, S8("__tls_index")))
    {
        return false;
    }
    u32 page_count = 0;
    u32 low_count = 0;
    for (u32 index = 0; index < object->relocation_count; index += 1)
    {
        ObjectRelocation* relocation = object->relocations + index;
        if (relocation->symbol != symbol_index)
        {
            continue;
        }
        if (relocation->kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_ADRP)
        {
            page_count += 1;
        }
        else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_LO12)
        {
            low_count += 1;
        }
        else
        {
            return false;
        }
    }
    return page_count && page_count == low_count;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_pe64(Arena* arena, ObjectFile* object, NativeExecutableLinkOptions options)
{
    NativeExecutableLinkResult result = {0};
    enum
    {
        PE_SECTION_TEXT = 0,
        PE_SECTION_READ_ONLY_DATA,
        PE_SECTION_DATA,
        PE_SECTION_ZERO,
        PE_SECTION_TLS,
        PE_SECTION_PDATA,
        PE_SECTION_XDATA,
        PE_SECTION_IMPORT,
        PE_SECTION_DEBUG,
        PE_SECTION_RELOCATION,
        PE_SECTION_COUNT,
        PE_IMPORT_DESCRIPTOR_SIZE = 20,
        PE_IMAGE_BASE_LOW = 0x40000000,
        PE_IMAGE_BASE_HIGH = 1,
    };
    u8* entry_stub_x86_64 = 0;
    u32 entry_stub_x86_64_size = 0;
    u32* entry_stub_aarch64 = 0;
    u32 entry_stub_aarch64_words = 0;
    u32 startup_displacement_offsets[3] = {0};
    u32 main_displacement_offset = 0;
    u32 exit_displacement_offset = 0;
    u32 atexit_displacement_offset = 0;
    u32 entry_stub_word = 0;
    u32 exit_stub_word = 0;
    u32 atexit_stub_word = 0;
    static char8 const runtime_library[] = "ucrtbase.dll";
    // The entry stub terminates through the C runtime's `exit`, not through
    // kernel32's ExitProcess, because C 5.1.2.2.3 makes a return from `main`
    // equivalent to calling `exit`: ExitProcess ends the process without
    // flushing a single CRT stream or running one atexit/`_onexit` handler,
    // so everything a program printed and returned on is discarded.  This is
    // a second import descriptor naming the same DLL as `runtime_library`
    // rather than a fourth entry in `startup_names`; the layout below is
    // shared by both architectures.
    static char8 const terminate_library[] = "ucrtbase.dll";
    static char8 const exit_name[] = "exit";
    // The registration the destructor runner is handed to (issue 781).
    // ucrtbase.dll exports `_crt_atexit` and not `atexit`, the same way
    // glibc's shared object exports only `__cxa_atexit`: UCRT's own `atexit`
    // is a static-library call to this, onto the one table `exit` walks, so
    // the runner lands behind every handler the program registered first.
    static char8 const atexit_name[] = "_crt_atexit";
    static String8 const startup_names[] = {
        S8_INITIALIZER("_configure_narrow_argv"),
        S8_INITIALIZER("__p___argc"),
        S8_INITIALIZER("__p___argv"),
    };
    u32 startup_stub_words[BUSTER_ARRAY_LENGTH(startup_names)] = {0};
    u32 runner_stub_word = 0;
    bool aarch64 = object->target.cpu_arch == CPU_ARCH_AARCH64;
    if ((options.dynamic_library_count && !options.dynamic_libraries) || (options.runtime_exported_symbol_count && !options.runtime_exported_symbols) ||
        object->section_count < OBJECT_SECTION_COUNT || !object->sections || (object->symbol_count && !object->symbols) ||
        (object->relocation_count && !object->relocations) || options.dynamic_library_count == UINT32_MAX ||
        (object->target.cpu_arch != CPU_ARCH_X86_64 && !aarch64))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
    }
    ObjectFile stripped_object = {0};
    LinkInitializerPlan plan = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        if (!link_initializer_plan_build(arena, object, &stripped_object, &plan))
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
        else
        {
            object = &stripped_object;
        }
    }
    u32 initializer_count = plan.constructor_count + plan.destructor_count;
    // The names the terminating import descriptor carries: `exit` always, and
    // the registration `_crt_atexit` only for a program that has a destructor
    // runner to hand it, so an image without one keeps the import table it
    // had.  The lookup and address tables each hold one more slot than that,
    // for the null terminator every descriptor ends with.
    u32 terminate_import_count = plan.destructor_count ? 2u : 1u;
    u32 terminate_slot_count = terminate_import_count + 1;
    u32* initializer_displacement_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        initializer_displacement_offsets = arena_allocate(arena, u32, initializer_count ? initializer_count : 1);
        if (aarch64)
        {
            entry_stub_aarch64_words = link_aarch64_pe_entry_stub_words(&plan);
            entry_stub_aarch64 = arena_allocate(arena, u32, entry_stub_aarch64_words);
            u32 built_words = link_aarch64_build_pe_entry_stub(entry_stub_aarch64, entry_stub_aarch64_words, &plan, &entry_stub_word, &exit_stub_word,
                                                               &atexit_stub_word, startup_stub_words, initializer_displacement_offsets,
                                                               &runner_stub_word);
            if (built_words != entry_stub_aarch64_words)
            {
                result.error = LINK_ERROR_RELOCATION;
            }
        }
        else
        {
            buster_x86_metadata_prewarm();
            entry_stub_x86_64 = arena_allocate(arena, u8, link_x86_pe_entry_stub_capacity(&plan));
            if (!link_x86_build_pe_entry_stub(entry_stub_x86_64, link_x86_pe_entry_stub_capacity(&plan), &entry_stub_x86_64_size, &plan,
                                              startup_displacement_offsets, &main_displacement_offset, &exit_displacement_offset,
                                              &atexit_displacement_offset, initializer_displacement_offsets))
            {
                result.error = LINK_ERROR_RELOCATION;
            }
        }
    }
    u32 import_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_count = 0;
    }
    u64 imported_name_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        imported_name_size = 0;
    }
    u32*import_indices = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_indices = arena_allocate(arena, u32, object->symbol_count);
    }
    u32*import_slots = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_slots = arena_allocate(arena, u32, object->symbol_count);
    }
    u32*import_groups = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_groups = arena_allocate(arena, u32, object->symbol_count);
    }
    u32 library_group_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        library_group_count = options.dynamic_library_count + 1;
    }
    u32*group_import_counts = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        group_import_counts = arena_allocate(arena, u32, library_group_count);
        memset(group_import_counts, 0, sizeof(*group_import_counts) * library_group_count);
    }
    Arena* export_conflicts[] = {
        arena,
    };
    TemporalArena export_temporary = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        export_temporary = (TemporalArena){0};
    }
    LinkPeExportIndex export_index = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        export_index = (LinkPeExportIndex){0};
    }
    u32 export_query_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        export_query_count = 0;
    }
    bool export_index_initialized = false;
    if (result.error == LINK_ERROR_NONE)
    {
        export_index_initialized = false;
        for (u32 symbol_index = 0; symbol_index < object->symbol_count && result.error == LINK_ERROR_NONE; symbol_index += 1)
        {
            import_indices[symbol_index] = UINT32_MAX;
            import_slots[symbol_index] = UINT32_MAX;
            import_groups[symbol_index] = UINT32_MAX;
            ObjectSymbol* symbol = &object->symbols[symbol_index];
            if (symbol->section != OBJECT_SECTION_UNDEFINED)
            {
                continue;
            }
            if (aarch64 && link_pe_aarch64_tls_index_symbol(object, symbol_index))
            {
                continue;
            }
            if (!symbol->global || (symbol->kind != OBJECT_SYMBOL_FUNCTION && symbol->kind != OBJECT_SYMBOL_DATA) || !symbol->name.length ||
                symbol->name.length > UINT32_MAX ||
                imported_name_size > UINT32_MAX - symbol->name.length - 3)
            {
                result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
                result.symbol = symbol->name;
                if (export_index_initialized)
                {
                    scratch_end(export_temporary);
                }
            }
            u32 group = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                group = 0;
                if (options.dynamic_library_count)
                {
                    export_query_count += 1;
                    if (!export_index_initialized && export_query_count == LINK_PE_EXPORT_INDEX_MIN_QUERY_COUNT)
                    {
                        export_temporary = scratch_begin(export_conflicts, BUSTER_ARRAY_LENGTH(export_conflicts));
                        if (!link_pe_export_index_initialize(export_temporary.arena, options, &export_index))
                        {
                            scratch_end(export_temporary);
                            result.error = LINK_ERROR_INVALID_INPUT;
                        }
                        if (result.error == LINK_ERROR_NONE)
                        {
                            export_index_initialized = true;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        group = export_index_initialized ? link_pe_export_group(&export_index, symbol->name) : link_pe_export_group_scalar(options, symbol->name);
                        if (group == UINT32_MAX || (group == 0 && !options.runtime_exports_known))
                        {
                            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
                            result.symbol = symbol->name;
                            if (export_index_initialized)
                            {
                                scratch_end(export_temporary);
                            }
                        }
                    }
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                import_indices[symbol_index] = import_count;
                import_groups[symbol_index] = group;
                group_import_counts[group] += 1;
                imported_name_size += align_forward(symbol->name.length + 3, 2);
                import_count += 1;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (export_index_initialized)
        {
            scratch_end(export_temporary);
        }
        group_import_counts[0] += (u32)BUSTER_ARRAY_LENGTH(startup_names);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(startup_names); index += 1)
        {
            imported_name_size += align_forward(startup_names[index].length + 3, 2);
        }
    }
    u32*group_slot_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        group_slot_offsets = arena_allocate(arena, u32, library_group_count);
    }
    u32*group_slot_counts = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        group_slot_counts = arena_allocate(arena, u32, library_group_count);
    }
    u32 total_import_slots = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        total_import_slots = 0;
        for (u32 group = 0; group < library_group_count; group += 1)
        {
            group_slot_offsets[group] = total_import_slots;
            group_slot_counts[group] = 0;
            if (group_import_counts[group])
            {
                total_import_slots += group_import_counts[group] + 1;
            }
        }
        for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
        {
            u32 group = import_groups[symbol_index];
            if (group == UINT32_MAX)
            {
                continue;
            }
            import_slots[symbol_index] = group_slot_offsets[group] + group_slot_counts[group]++;
        }
    }
    u32*startup_import_slots = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        startup_import_slots = arena_allocate(arena, u32, BUSTER_ARRAY_LENGTH(startup_names));
        memset(startup_import_slots, 0, sizeof(*startup_import_slots) * BUSTER_ARRAY_LENGTH(startup_names));
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(startup_names); index += 1)
        {
            startup_import_slots[index] = group_slot_offsets[0] + group_slot_counts[0]++;
        }
    }
    String8 entry_name = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        entry_name = options.entry_symbol.length ? options.entry_symbol : S8("main");
    }
    u32 entry_symbol_index = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_symbol_index = link_symbol_find(object, entry_name);
        if (entry_symbol_index == UINT32_MAX || object->symbols[entry_symbol_index].section == OBJECT_SECTION_UNDEFINED ||
            object->symbols[entry_symbol_index].kind != OBJECT_SYMBOL_FUNCTION)
        {
            result.error = LINK_ERROR_ENTRY_SYMBOL;
            result.symbol = entry_name;
        }
    }
    bool emit_debug = false;
    if (result.error == LINK_ERROR_NONE)
    {
        emit_debug = options.debug_info && object->debug_module_count && object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS].data.length;
    }
    u16 pe_section_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        pe_section_count = aarch64 ? (emit_debug ? PE_SECTION_COUNT : PE_SECTION_DEBUG + 1)
                                     : (emit_debug ? PE_SECTION_RELOCATION : PE_SECTION_DEBUG);
    }
    String8 pdb_path = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        pdb_path = emit_debug ? link_pe_pdb_path(arena, options.output_path) : (String8){0};
    }
    u64 debug_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        debug_virtual_size = emit_debug ? 28 + 24 + pdb_path.length + 1 : 0;
    }
    u64 debug_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        debug_raw_size = align_forward(BUSTER_MAX(debug_virtual_size, 1), PE_FILE_ALIGNMENT);
    }
    u64 header_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        header_size = align_forward(PE_OFFSET + 4 + PE_COFF_HEADER_SIZE + PE_OPTIONAL_HEADER_SIZE + (u64)pe_section_count * PE_SECTION_HEADER_SIZE, PE_FILE_ALIGNMENT);
    }
    u32*section_rvas = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        section_rvas = arena_allocate(arena, u32, PE_SECTION_COUNT);
    }
    u32*section_raw_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        section_raw_offsets = arena_allocate(arena, u32, PE_SECTION_COUNT);
    }
    u32*object_output_sections = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        object_output_sections = arena_allocate(arena, u32, OBJECT_SECTION_COUNT);
    }
    u64*object_section_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        object_section_offsets = arena_allocate(arena, u64, OBJECT_SECTION_COUNT);
        memset(section_rvas, 0, sizeof(*section_rvas) * PE_SECTION_COUNT);
        memset(section_raw_offsets, 0, sizeof(*section_raw_offsets) * PE_SECTION_COUNT);
        memset(object_output_sections, 0xff, sizeof(*object_output_sections) * OBJECT_SECTION_COUNT);
        memset(object_section_offsets, 0, sizeof(*object_section_offsets) * OBJECT_SECTION_COUNT);
        section_rvas[PE_SECTION_TEXT] = PE_SECTION_ALIGNMENT;
        section_raw_offsets[PE_SECTION_TEXT] = (u32)header_size;
        object_output_sections[OBJECT_SECTION_TEXT] = PE_SECTION_TEXT;
        object_output_sections[OBJECT_SECTION_READ_ONLY_DATA] = PE_SECTION_READ_ONLY_DATA;
        object_output_sections[OBJECT_SECTION_DATA] = PE_SECTION_DATA;
        object_output_sections[OBJECT_SECTION_ZERO] = PE_SECTION_ZERO;
        object_output_sections[OBJECT_SECTION_THREAD_LOCAL_DATA] = PE_SECTION_TLS;
        object_output_sections[OBJECT_SECTION_THREAD_LOCAL_ZERO] = PE_SECTION_TLS;
        object_output_sections[OBJECT_SECTION_WINDOWS_PDATA] = PE_SECTION_PDATA;
        object_output_sections[OBJECT_SECTION_WINDOWS_XDATA] = PE_SECTION_XDATA;
    }
    u64 entry_stub_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_stub_offset = 0;
    }
    u64 entry_stub_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_stub_size = aarch64 ? (u64)entry_stub_aarch64_words * sizeof(u32) : entry_stub_x86_64_size;
        object_section_offsets[OBJECT_SECTION_TEXT] = align_forward(entry_stub_size, object->sections[OBJECT_SECTION_TEXT].alignment);
    }
    u64 thunk_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        thunk_offset = align_forward(object_section_offsets[OBJECT_SECTION_TEXT] + object->sections[OBJECT_SECTION_TEXT].data.length, 16);
    }
    u32 thunk_entry_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        thunk_entry_size = aarch64 ? 16 : 6;
    }
    u64 thunk_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        u32 startup_thunk_count = aarch64 ? (u32)BUSTER_ARRAY_LENGTH(startup_names) : 0;
        thunk_size = (u64)(import_count + startup_thunk_count + (aarch64 ? terminate_import_count : 0)) * thunk_entry_size;
    }
    u64 text_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        text_virtual_size = thunk_offset + thunk_size;
    }
    u64 text_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        text_raw_size = align_forward(text_virtual_size, PE_FILE_ALIGNMENT);
        section_rvas[PE_SECTION_READ_ONLY_DATA] = (u32)align_forward(section_rvas[PE_SECTION_TEXT] + text_virtual_size, PE_SECTION_ALIGNMENT);
        section_raw_offsets[PE_SECTION_READ_ONLY_DATA] = section_raw_offsets[PE_SECTION_TEXT] + (u32)text_raw_size;
        object_section_offsets[OBJECT_SECTION_READ_ONLY_DATA] = 0;
    }
    u64 read_only_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        read_only_virtual_size = object->sections[OBJECT_SECTION_READ_ONLY_DATA].data.length;
    }
    u64 read_only_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        read_only_raw_size = align_forward(BUSTER_MAX(read_only_virtual_size, 1), PE_FILE_ALIGNMENT);
        section_rvas[PE_SECTION_DATA] =
            (u32)align_forward(section_rvas[PE_SECTION_READ_ONLY_DATA] + BUSTER_MAX(read_only_virtual_size, 1), PE_SECTION_ALIGNMENT);
        section_raw_offsets[PE_SECTION_DATA] = section_raw_offsets[PE_SECTION_READ_ONLY_DATA] + (u32)read_only_raw_size;
        object_section_offsets[OBJECT_SECTION_DATA] = 0;
    }
    u64 data_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_virtual_size = object->sections[OBJECT_SECTION_DATA].data.length;
    }
    u64 data_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_raw_size = align_forward(BUSTER_MAX(data_virtual_size, 1), PE_FILE_ALIGNMENT);
        section_rvas[PE_SECTION_ZERO] = (u32)align_forward(section_rvas[PE_SECTION_DATA] + BUSTER_MAX(data_virtual_size, 1), PE_SECTION_ALIGNMENT);
        object_section_offsets[OBJECT_SECTION_ZERO] = 0;
    }
    u64 zero_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        zero_virtual_size = object->sections[OBJECT_SECTION_ZERO].virtual_size;
        section_rvas[PE_SECTION_TLS] = (u32)align_forward(section_rvas[PE_SECTION_ZERO] + BUSTER_MAX(zero_virtual_size, 1), PE_SECTION_ALIGNMENT);
        section_raw_offsets[PE_SECTION_TLS] = section_raw_offsets[PE_SECTION_DATA] + (u32)data_raw_size;
        object_section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] = 0;
        object_section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO] =
            align_forward(object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment);
    }
    u64 tls_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_virtual_size = object_section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO] + object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size;
    }
    u32 tls_alignment = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_alignment = BUSTER_MAX(object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].alignment, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment);
        if (tls_virtual_size && (!BUSTER_IS_POWER_OF_TWO(tls_alignment) || tls_alignment > 8192))
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    u32 tls_alignment_shift = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_alignment_shift = 0;
        for (u32 alignment = tls_alignment; alignment > 1; alignment >>= 1)
        {
            tls_alignment_shift += 1;
        }
    }
    u32 tls_characteristics = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_characteristics = tls_virtual_size ? (tls_alignment_shift + 1) << 20 : 0;
    }
    // The loader copies the complete TLS template before applying per-thread zero-fill.
    // Serialize the TBSS range in that template so the directory can describe no
    // additional zero-fill and EndAddressOfRawData covers every TLS object.
    u64 tls_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_raw_size = align_forward(BUSTER_MAX(tls_virtual_size, 1), PE_FILE_ALIGNMENT);
    }
    u32 runtime_function_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        runtime_function_size = aarch64 ? 8 : 12;
    }
    u32 startup_runtime_function_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        startup_runtime_function_count = aarch64 && plan.destructor_count ? 2 : 1;
    }
    u32 startup_xdata_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        startup_xdata_size = aarch64 ? startup_runtime_function_count * 8 : 8;
    }
    u64 pdata_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        pdata_virtual_size = (u64)runtime_function_size * startup_runtime_function_count + object->sections[OBJECT_SECTION_WINDOWS_PDATA].data.length;
    }
    u64 pdata_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        pdata_raw_size = align_forward(pdata_virtual_size, PE_FILE_ALIGNMENT);
    }
    u64 xdata_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        xdata_virtual_size = startup_xdata_size + object->sections[OBJECT_SECTION_WINDOWS_XDATA].data.length;
    }
    u64 xdata_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        xdata_raw_size = align_forward(xdata_virtual_size, PE_FILE_ALIGNMENT);
        if (object->sections[OBJECT_SECTION_WINDOWS_PDATA].data.length % runtime_function_size)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        section_rvas[PE_SECTION_PDATA] = (u32)align_forward(section_rvas[PE_SECTION_TLS] + BUSTER_MAX(tls_virtual_size, 1), PE_SECTION_ALIGNMENT);
        section_raw_offsets[PE_SECTION_PDATA] = section_raw_offsets[PE_SECTION_TLS] + (u32)tls_raw_size;
        object_section_offsets[OBJECT_SECTION_WINDOWS_PDATA] = (u64)runtime_function_size * startup_runtime_function_count;
        section_rvas[PE_SECTION_XDATA] =
            (u32)align_forward(section_rvas[PE_SECTION_PDATA] + BUSTER_MAX(pdata_virtual_size, 1), PE_SECTION_ALIGNMENT);
        section_raw_offsets[PE_SECTION_XDATA] = section_raw_offsets[PE_SECTION_PDATA] + (u32)pdata_raw_size;
        object_section_offsets[OBJECT_SECTION_WINDOWS_XDATA] = startup_xdata_size;
        section_rvas[PE_SECTION_IMPORT] =
            (u32)align_forward(section_rvas[PE_SECTION_XDATA] + BUSTER_MAX(xdata_virtual_size, 1), PE_SECTION_ALIGNMENT);
        section_raw_offsets[PE_SECTION_IMPORT] = section_raw_offsets[PE_SECTION_XDATA] + (u32)xdata_raw_size;
    }
    u32 active_group_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        active_group_count = 0;
        for (u32 group = 0; group < library_group_count; group += 1)
        {
            active_group_count += group_import_counts[group] != 0;
        }
    }
    u32 import_descriptor_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_descriptor_count = active_group_count + 2;
    }
    u64 tls_directory_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_directory_offset = 0;
    }
    u64 tls_index_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_index_offset = 40;
    }
    u64 tls_callbacks_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        tls_callbacks_offset = tls_virtual_size ? align_forward(tls_index_offset + 4, 8) : 0;
    }
    u64 import_descriptor_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_descriptor_offset = tls_virtual_size ? align_forward(tls_callbacks_offset + sizeof(u64), 8) : align_forward(tls_index_offset + 4, 8);
    }
    u64 runtime_lookup_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        runtime_lookup_offset = align_forward(import_descriptor_offset + (u64)import_descriptor_count * PE_IMPORT_DESCRIPTOR_SIZE, 8);
    }
    u64 runtime_address_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        runtime_address_offset = runtime_lookup_offset + (u64)total_import_slots * sizeof(u64);
    }
    u64 terminate_lookup_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        terminate_lookup_offset = runtime_address_offset + (u64)total_import_slots * sizeof(u64);
    }
    u64 terminate_address_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        terminate_address_offset = terminate_lookup_offset + (u64)terminate_slot_count * sizeof(u64);
    }
    u64 import_name_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_name_offset = terminate_address_offset + (u64)terminate_slot_count * sizeof(u64);
    }
    u64*library_name_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        library_name_offsets = arena_allocate(arena, u64, library_group_count);
    }
    u64 library_name_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        library_name_cursor = import_name_offset + imported_name_size;
        library_name_offsets[0] = library_name_cursor;
        library_name_cursor += sizeof(runtime_library);
        for (u32 library_index = 0; library_index < options.dynamic_library_count && result.error == LINK_ERROR_NONE; library_index += 1)
        {
            String8 library = options.dynamic_libraries[library_index].name;
            if (!library.length || library.length >= UINT32_MAX)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                library_name_offsets[library_index + 1] = library_name_cursor;
                library_name_cursor += library.length + 1;
            }
        }
    }
    u64 terminate_library_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        terminate_library_offset = library_name_cursor;
    }
    u64 exit_import_name_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        exit_import_name_offset = align_forward(terminate_library_offset + sizeof(terminate_library), 2);
    }
    // Each import-by-name entry is a two-byte hint followed by the name, and
    // the next one starts on an even offset.
    u64 atexit_import_name_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        atexit_import_name_offset = align_forward(exit_import_name_offset + 2 + sizeof(exit_name), 2);
    }
    u64 import_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_virtual_size = terminate_import_count > 1 ? atexit_import_name_offset + 2 + sizeof(atexit_name) : exit_import_name_offset + 2 + sizeof(exit_name);
    }
    u64 import_raw_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_raw_size = align_forward(import_virtual_size, PE_FILE_ALIGNMENT);
    }
    u32*base_relocation_rvas = 0;
    u32 base_relocation_count = 0;
    if (result.error == LINK_ERROR_NONE && aarch64)
    {
        if (object->relocation_count > UINT32_MAX - 4)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
        else
        {
            base_relocation_rvas = arena_allocate(arena, u32, object->relocation_count + 4);
        }
    }
    if (result.error == LINK_ERROR_NONE && aarch64)
    {
        for (u32 relocation_index = 0; relocation_index < object->relocation_count; relocation_index += 1)
        {
            ObjectRelocation* relocation = object->relocations + relocation_index;
            if (relocation->kind != OBJECT_RELOCATION_ABSOLUTE64 || relocation->section >= OBJECT_SECTION_COUNT ||
                relocation->symbol >= object->symbol_count || object_section_kind_is_debug((ObjectSectionKind)relocation->section) ||
                object->symbols[relocation->symbol].section == OBJECT_SECTION_UNDEFINED)
            {
                continue;
            }
            ObjectSection* source = object->sections + relocation->section;
            u32 output_section = object_output_sections[relocation->section];
            u64 rva = 0;
            if (output_section >= PE_SECTION_DEBUG || relocation->offset > source->data.length ||
                source->data.length - relocation->offset < sizeof(u64) ||
                !link_u64_add(section_rvas[output_section], object_section_offsets[relocation->section], &rva) ||
                !link_u64_add(rva, relocation->offset, &rva) || rva > UINT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
                break;
            }
            base_relocation_rvas[base_relocation_count++] = (u32)rva;
        }
        if (result.error == LINK_ERROR_NONE && tls_virtual_size)
        {
            u64 directory_rva = section_rvas[PE_SECTION_IMPORT] + tls_directory_offset;
            for (u32 field = 0; field < 4; field += 1)
            {
                u64 rva = directory_rva + (u64)field * sizeof(u64);
                if (rva > UINT32_MAX)
                {
                    result.error = LINK_ERROR_RELOCATION;
                    break;
                }
                base_relocation_rvas[base_relocation_count++] = (u32)rva;
            }
        }
    }
    u64 relocation_virtual_size = 0;
    u64 relocation_raw_size = 0;
    if (result.error == LINK_ERROR_NONE && aarch64)
    {
        link_u32_shell_sort(base_relocation_rvas, base_relocation_count);
        if (!link_pe_base_relocation_size(base_relocation_rvas, base_relocation_count, &relocation_virtual_size))
        {
            result.error = LINK_ERROR_RELOCATION;
        }
        else
        {
            relocation_raw_size = align_forward(BUSTER_MAX(relocation_virtual_size, 1), PE_FILE_ALIGNMENT);
        }
    }
    u64 base_file_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        base_file_size = section_raw_offsets[PE_SECTION_IMPORT] + import_raw_size;
        if (emit_debug)
        {
            section_rvas[PE_SECTION_DEBUG] =
                (u32)align_forward(section_rvas[PE_SECTION_IMPORT] + BUSTER_MAX(import_virtual_size, 1), PE_SECTION_ALIGNMENT);
            section_raw_offsets[PE_SECTION_DEBUG] = (u32)base_file_size;
        }
    }
    u64 relocation_file_offset = 0;
    if (result.error == LINK_ERROR_NONE && aarch64)
    {
        u64 previous_rva = emit_debug ? section_rvas[PE_SECTION_DEBUG] + BUSTER_MAX(debug_virtual_size, 1)
                                      : section_rvas[PE_SECTION_IMPORT] + BUSTER_MAX(import_virtual_size, 1);
        relocation_file_offset = base_file_size + (emit_debug ? debug_raw_size : 0);
        section_rvas[PE_SECTION_RELOCATION] = (u32)align_forward(previous_rva, PE_SECTION_ALIGNMENT);
        section_raw_offsets[PE_SECTION_RELOCATION] = (u32)relocation_file_offset;
    }
    u64 file_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        file_size = base_file_size + (emit_debug ? debug_raw_size : 0) + (aarch64 ? relocation_raw_size : 0);
    }
    u64 image_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        u64 image_end = aarch64 ? section_rvas[PE_SECTION_RELOCATION] + BUSTER_MAX(relocation_virtual_size, 1)
                                : (emit_debug ? section_rvas[PE_SECTION_DEBUG] + debug_virtual_size
                                              : section_rvas[PE_SECTION_IMPORT] + import_virtual_size);
        image_size = align_forward(image_end, PE_SECTION_ALIGNMENT);
        if (file_size > UINT32_MAX || image_size > UINT32_MAX)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        result.executable = (ByteSlice){
            .pointer = arena_allocate(arena, u8, file_size),
            .length = file_size,
        };
    }
    u8*bytes = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        bytes = result.executable.pointer;
        memset(bytes, 0, file_size);
        memcpy(bytes + section_raw_offsets[PE_SECTION_TEXT] + entry_stub_offset,
               aarch64 ? (void const*)entry_stub_aarch64 : (void const*)entry_stub_x86_64, entry_stub_size);
        for (u32 section = 0; section < OBJECT_SECTION_COUNT && result.error == LINK_ERROR_NONE; section += 1)
        {
            if (object_section_kind_is_debug((ObjectSectionKind)section))
            {
                continue;
            }
            u32 output_section = object_output_sections[section];
            ByteSlice data = object->sections[section].data;
            if (data.length)
            {
                if (output_section >= pe_section_count)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
                if (result.error == LINK_ERROR_NONE)
                {
                    memcpy(bytes + section_raw_offsets[output_section] + object_section_offsets[section], data.pointer, data.length);
                }
            }
        }
    }
    u64 startup_pdata_raw = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        startup_pdata_raw = section_raw_offsets[PE_SECTION_PDATA];
    }
    u64 startup_xdata_raw = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        startup_xdata_raw = section_raw_offsets[PE_SECTION_XDATA];
        link_write_u32(bytes, startup_pdata_raw, section_rvas[PE_SECTION_TEXT] + (u32)entry_stub_offset);
        if (aarch64)
        {
            link_write_u32(bytes, startup_pdata_raw + 4, section_rvas[PE_SECTION_XDATA]);
            u32 entry_function_words = runner_stub_word ? runner_stub_word : entry_stub_aarch64_words;
            link_write_u32(bytes, startup_xdata_raw, entry_function_words | (1u << 27));
            bytes[startup_xdata_raw + 4] = 0x81;
            bytes[startup_xdata_raw + 5] = 0xcc;
            bytes[startup_xdata_raw + 6] = 0x01;
            bytes[startup_xdata_raw + 7] = 0xe4;
            if (runner_stub_word)
            {
                link_write_u32(bytes, startup_pdata_raw + runtime_function_size,
                               section_rvas[PE_SECTION_TEXT] + (u32)(entry_stub_offset + (u64)runner_stub_word * sizeof(u32)));
                link_write_u32(bytes, startup_pdata_raw + runtime_function_size + 4, section_rvas[PE_SECTION_XDATA] + 8);
                link_write_u32(bytes, startup_xdata_raw + 8, (entry_stub_aarch64_words - runner_stub_word) | (1u << 27));
                bytes[startup_xdata_raw + 12] = 0x81;
                bytes[startup_xdata_raw + 13] = 0xcc;
                bytes[startup_xdata_raw + 14] = 0x01;
                bytes[startup_xdata_raw + 15] = 0xe4;
            }
        }
        else
        {
            link_write_u32(bytes, startup_pdata_raw + 4, section_rvas[PE_SECTION_TEXT] + (u32)(entry_stub_offset + entry_stub_size));
            link_write_u32(bytes, startup_pdata_raw + 8, section_rvas[PE_SECTION_XDATA]);
            bytes[startup_xdata_raw] = 1;
            bytes[startup_xdata_raw + 1] = 4;
            bytes[startup_xdata_raw + 2] = 1;
            bytes[startup_xdata_raw + 4] = 4;
            bytes[startup_xdata_raw + 5] = 0x62;
        }
    }
    u32 import_section_rva = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_section_rva = section_rvas[PE_SECTION_IMPORT];
    }
    u64 import_section_raw = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_section_raw = section_raw_offsets[PE_SECTION_IMPORT];
    }
    u64 pe_image_base = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        pe_image_base = ((u64)PE_IMAGE_BASE_HIGH << 32) | PE_IMAGE_BASE_LOW;
        link_write_u64(bytes, import_section_raw + tls_directory_offset, pe_image_base + section_rvas[PE_SECTION_TLS]);
        link_write_u64(bytes, import_section_raw + tls_directory_offset + 8, pe_image_base + section_rvas[PE_SECTION_TLS] + tls_virtual_size);
        link_write_u64(bytes, import_section_raw + tls_directory_offset + 16, pe_image_base + import_section_rva + tls_index_offset);
        if (tls_virtual_size)
        {
            link_write_u64(bytes, import_section_raw + tls_directory_offset + 24, pe_image_base + import_section_rva + tls_callbacks_offset);
            link_write_u32(bytes, import_section_raw + tls_directory_offset + 32, 0);
            link_write_u32(bytes, import_section_raw + tls_directory_offset + 36, tls_characteristics);
            link_write_u64(bytes, import_section_raw + tls_callbacks_offset, 0);
        }
    }
    u64 imported_name_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        imported_name_cursor = import_name_offset;
        for (u32 symbol_index = 0; symbol_index < object->symbol_count && result.error == LINK_ERROR_NONE; symbol_index += 1)
        {
            u32 import_index = import_indices[symbol_index];
            if (import_index == UINT32_MAX)
            {
                continue;
            }
            ObjectSymbol* symbol = &object->symbols[symbol_index];
            u32 import_slot = import_slots[symbol_index];
            if (import_slot == UINT32_MAX)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            u32 name_rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                name_rva = import_section_rva + (u32)imported_name_cursor;
                link_write_u64(bytes, import_section_raw + runtime_lookup_offset + (u64)import_slot * sizeof(u64), name_rva);
                link_write_u64(bytes, import_section_raw + runtime_address_offset + (u64)import_slot * sizeof(u64), name_rva);
                memcpy(bytes + import_section_raw + imported_name_cursor + 2, symbol->name.pointer, symbol->name.length);
                imported_name_cursor += align_forward(symbol->name.length + 3, 2);
            }
            u64 thunk_raw = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                thunk_raw = section_raw_offsets[PE_SECTION_TEXT] + thunk_offset + (u64)import_index * thunk_entry_size;
            }
            u64 thunk_rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                thunk_rva = section_rvas[PE_SECTION_TEXT] + thunk_offset + (u64)import_index * thunk_entry_size;
            }
            u64 iat_rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                iat_rva = import_section_rva + runtime_address_offset + (u64)import_slot * sizeof(u64);
                if (!aarch64)
                {
                    LinkX86InstructionBuilder thunk_builder = {.bytes = bytes + thunk_raw, .capacity = 6};
                    BusterX86MetadataPhysicalOperand thunk_memory = link_x86_memory_rip(64, 0);
                    if (!link_x86_emit(&thunk_builder, S8("JMP"), &thunk_memory, 1) || thunk_builder.count != 6)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, thunk_raw + 2, (u32)(s32)((s64)iat_rva - (s64)(thunk_rva + 6)));
                    }
                }
                else
                {
                    u64 slot_address = (((u64)PE_IMAGE_BASE_HIGH << 32) | PE_IMAGE_BASE_LOW) + iat_rva;
                    u64 thunk_address = (((u64)PE_IMAGE_BASE_HIGH << 32) | PE_IMAGE_BASE_LOW) + thunk_rva;
                    u64 page_offset = slot_address & 0xfff;
                    bool adrp_valid = true;
                    link_write_u32(bytes, thunk_raw, link_aarch64_adrp(16, thunk_address, slot_address, &adrp_valid));
                    if (!adrp_valid || page_offset % 8)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, thunk_raw + 4, 0xf9400000 | ((u32)(page_offset / 8) << 10) | (16 << 5) | 17);
                        link_write_u32(bytes, thunk_raw + 8, 0xd61f0220);
                        link_write_u32(bytes, thunk_raw + 12, 0xd503201f);
                    }
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(startup_names); index += 1)
        {
            u32 name_rva = import_section_rva + (u32)imported_name_cursor;
            u32 import_slot = startup_import_slots[index];
            link_write_u64(bytes, import_section_raw + runtime_lookup_offset + (u64)import_slot * sizeof(u64), name_rva);
            link_write_u64(bytes, import_section_raw + runtime_address_offset + (u64)import_slot * sizeof(u64), name_rva);
            memcpy(bytes + import_section_raw + imported_name_cursor + 2, startup_names[index].pointer, startup_names[index].length);
            imported_name_cursor += align_forward(startup_names[index].length + 3, 2);
        }
        memcpy(bytes + import_section_raw + library_name_offsets[0], runtime_library, sizeof(runtime_library));
        for (u32 library_index = 0; library_index < options.dynamic_library_count; library_index += 1)
        {
            String8 library = options.dynamic_libraries[library_index].name;
            memcpy(bytes + import_section_raw + library_name_offsets[library_index + 1], library.pointer, library.length);
            bytes[import_section_raw + library_name_offsets[library_index + 1] + library.length] = 0;
        }
        memcpy(bytes + import_section_raw + terminate_library_offset, terminate_library, sizeof(terminate_library));
        memcpy(bytes + import_section_raw + exit_import_name_offset + 2, exit_name, sizeof(exit_name));
        if (terminate_import_count > 1)
        {
            memcpy(bytes + import_section_raw + atexit_import_name_offset + 2, atexit_name, sizeof(atexit_name));
        }
    }
    u32 exit_name_rva = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        exit_name_rva = import_section_rva + (u32)exit_import_name_offset;
        link_write_u64(bytes, import_section_raw + terminate_lookup_offset, exit_name_rva);
        link_write_u64(bytes, import_section_raw + terminate_address_offset, exit_name_rva);
        if (terminate_import_count > 1)
        {
            u32 atexit_name_rva = import_section_rva + (u32)atexit_import_name_offset;
            link_write_u64(bytes, import_section_raw + terminate_lookup_offset + sizeof(u64), atexit_name_rva);
            link_write_u64(bytes, import_section_raw + terminate_address_offset + sizeof(u64), atexit_name_rva);
        }
    }
    u64 descriptor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        descriptor = import_section_raw + import_descriptor_offset;
        for (u32 group = 0; group < library_group_count; group += 1)
        {
            if (!group_import_counts[group])
            {
                continue;
            }
            link_write_u32(bytes, descriptor, import_section_rva + (u32)runtime_lookup_offset + (u32)(group_slot_offsets[group] * sizeof(u64)));
            link_write_u32(bytes, descriptor + 12, import_section_rva + (u32)library_name_offsets[group]);
            link_write_u32(bytes, descriptor + 16, import_section_rva + (u32)runtime_address_offset + (u32)(group_slot_offsets[group] * sizeof(u64)));
            descriptor += PE_IMPORT_DESCRIPTOR_SIZE;
        }
        link_write_u32(bytes, descriptor, import_section_rva + (u32)terminate_lookup_offset);
        link_write_u32(bytes, descriptor + 12, import_section_rva + (u32)terminate_library_offset);
        link_write_u32(bytes, descriptor + 16, import_section_rva + (u32)terminate_address_offset);
    }
    u64 entry_rva = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_rva = section_rvas[PE_SECTION_TEXT] + entry_stub_offset;
    }
    ObjectSymbol*entry_symbol = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_symbol = &object->symbols[entry_symbol_index];
    }
    u64 main_rva = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        main_rva = section_rvas[object_output_sections[entry_symbol->section]] + object_section_offsets[entry_symbol->section] + entry_symbol->value;
    }
    u64 exit_iat_rva = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        exit_iat_rva = import_section_rva + terminate_address_offset;
        if (!aarch64)
        {
            u64 configure_argv_iat_rva = import_section_rva + runtime_address_offset + (u64)startup_import_slots[0] * sizeof(u64);
            u64 argc_iat_rva = import_section_rva + runtime_address_offset + (u64)startup_import_slots[1] * sizeof(u64);
            u64 argv_iat_rva = import_section_rva + runtime_address_offset + (u64)startup_import_slots[2] * sizeof(u64);
            // Each rip-relative field ends four bytes past its own offset,
            // which is where the displacement is measured from; the builder
            // reports every offset because an initializer call moves them all.
            s64 configure_argv_displacement = (s64)configure_argv_iat_rva - (s64)(entry_rva + startup_displacement_offsets[0] + 4);
            s64 argc_displacement = (s64)argc_iat_rva - (s64)(entry_rva + startup_displacement_offsets[1] + 4);
            s64 argv_displacement = (s64)argv_iat_rva - (s64)(entry_rva + startup_displacement_offsets[2] + 4);
            s64 main_displacement = (s64)main_rva - (s64)(entry_rva + main_displacement_offset + 4);
            s64 exit_displacement = (s64)exit_iat_rva - (s64)(entry_rva + exit_displacement_offset + 4);
            if (configure_argv_displacement < INT32_MIN || configure_argv_displacement > INT32_MAX || argc_displacement < INT32_MIN ||
                argc_displacement > INT32_MAX || argv_displacement < INT32_MIN || argv_displacement > INT32_MAX || main_displacement < INT32_MIN ||
                main_displacement > INT32_MAX || exit_displacement < INT32_MIN || exit_displacement > INT32_MAX)
            {
                result.error = LINK_ERROR_RELOCATION;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + startup_displacement_offsets[0], (u32)(s32)configure_argv_displacement);
                link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + startup_displacement_offsets[1], (u32)(s32)argc_displacement);
                link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + startup_displacement_offsets[2], (u32)(s32)argv_displacement);
                link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + main_displacement_offset, (u32)(s32)main_displacement);
                link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + exit_displacement_offset, (u32)(s32)exit_displacement);
                if (plan.destructor_count)
                {
                    // The registration's IAT slot is the terminating
                    // descriptor's second, laid out beside `exit`'s.
                    u64 atexit_iat_rva = import_section_rva + terminate_address_offset + sizeof(u64);
                    s64 atexit_displacement = (s64)atexit_iat_rva - (s64)(entry_rva + atexit_displacement_offset + 4);
                    if (atexit_displacement < INT32_MIN || atexit_displacement > INT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    else
                    {
                        link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + atexit_displacement_offset, (u32)(s32)atexit_displacement);
                    }
                }
                for (u32 index = 0; index < initializer_count && result.error == LINK_ERROR_NONE; index += 1)
                {
                    LinkInitializerEntry entry =
                        index < plan.constructor_count ? plan.constructors[index] : plan.destructors[index - plan.constructor_count];
                    ObjectSymbol* initializer = entry.symbol < object->symbol_count ? object->symbols + entry.symbol : 0;
                    if (!initializer || initializer->section >= OBJECT_SECTION_COUNT ||
                        object_output_sections[initializer->section] >= pe_section_count)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        break;
                    }
                    u64 initializer_rva = section_rvas[object_output_sections[initializer->section]] + object_section_offsets[initializer->section] +
                                          initializer->value + (u64)entry.addend;
                    u32 field = initializer_displacement_offsets[index];
                    s64 displacement = (s64)initializer_rva - (s64)(entry_rva + field + 4);
                    if (displacement < INT32_MIN || displacement > INT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        break;
                    }
                    link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + field, (u32)(s32)displacement);
                }
            }
        }
        else
        {
            u64 image_base = ((u64)PE_IMAGE_BASE_HIGH << 32) | PE_IMAGE_BASE_LOW;
            u64 startup_thunk_rva[BUSTER_ARRAY_LENGTH(startup_names)] = {0};
            for (u32 startup_index = 0; startup_index < BUSTER_ARRAY_LENGTH(startup_names) && result.error == LINK_ERROR_NONE; startup_index += 1)
            {
                u64 thunk_delta = ((u64)import_count + startup_index) * thunk_entry_size;
                u64 thunk_raw = section_raw_offsets[PE_SECTION_TEXT] + thunk_offset + thunk_delta;
                u64 thunk_rva = section_rvas[PE_SECTION_TEXT] + thunk_offset + thunk_delta;
                u64 iat_rva = import_section_rva + runtime_address_offset + (u64)startup_import_slots[startup_index] * sizeof(u64);
                u64 slot_address = image_base + iat_rva;
                u64 thunk_address = image_base + thunk_rva;
                u64 page_offset = slot_address & 0xfff;
                bool adrp_valid = true;
                startup_thunk_rva[startup_index] = thunk_rva;
                link_write_u32(bytes, thunk_raw, link_aarch64_adrp(16, thunk_address, slot_address, &adrp_valid));
                if (!adrp_valid || page_offset % 8)
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
                if (result.error == LINK_ERROR_NONE)
                {
                    link_write_u32(bytes, thunk_raw + 4, 0xf9400000 | ((u32)(page_offset / 8) << 10) | (16 << 5) | 17);
                    link_write_u32(bytes, thunk_raw + 8, 0xd61f0220);
                    link_write_u32(bytes, thunk_raw + 12, 0xd503201f);
                }
            }
            // One thunk per terminating import, past the program and startup
            // imports: `exit` first and `_crt_atexit` beside it when needed.
            u64 terminate_thunk_rva[2] = {0};
            for (u32 terminate_index = 0; terminate_index < terminate_import_count && result.error == LINK_ERROR_NONE; terminate_index += 1)
            {
                u64 thunk_delta = ((u64)import_count + BUSTER_ARRAY_LENGTH(startup_names) + terminate_index) * thunk_entry_size;
                u64 terminate_thunk_raw = section_raw_offsets[PE_SECTION_TEXT] + thunk_offset + thunk_delta;
                u64 iat_address = image_base + exit_iat_rva + (u64)terminate_index * sizeof(u64);
                u64 thunk_address = image_base + section_rvas[PE_SECTION_TEXT] + thunk_offset + thunk_delta;
                u64 page_offset = iat_address & 0xfff;
                bool adrp_valid = true;
                terminate_thunk_rva[terminate_index] = section_rvas[PE_SECTION_TEXT] + thunk_offset + thunk_delta;
                link_write_u32(bytes, terminate_thunk_raw, link_aarch64_adrp(16, thunk_address, iat_address, &adrp_valid));
                if (!adrp_valid || page_offset % 8)
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
                if (result.error == LINK_ERROR_NONE)
                {
                    link_write_u32(bytes, terminate_thunk_raw + 4, 0xf9400000 | ((u32)(page_offset / 8) << 10) | (16 << 5) | 17);
                    link_write_u32(bytes, terminate_thunk_raw + 8, 0xd61f0220);
                    link_write_u32(bytes, terminate_thunk_raw + 12, 0xd503201f);
                }
            }
            u64 exit_thunk_rva = terminate_thunk_rva[0];
            s64 main_displacement = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                main_displacement = (s64)main_rva - (s64)(entry_rva + (u64)entry_stub_word * sizeof(u32));
            }
            s64 exit_displacement = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                exit_displacement = (s64)exit_thunk_rva - (s64)(entry_rva + (u64)exit_stub_word * sizeof(u32));
            }
            u32 main_instruction = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                main_instruction = 0;
            }
            u32 exit_instruction = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                exit_instruction = 0;
                if (!link_aarch64_branch_encode(A64_OPCODE_BL, main_displacement, &main_instruction) ||
                    !link_aarch64_branch_encode(A64_OPCODE_BL, exit_displacement, &exit_instruction))
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + (u64)entry_stub_word * sizeof(u32), main_instruction);
                link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + (u64)exit_stub_word * sizeof(u32), exit_instruction);
                for (u32 startup_index = 0; startup_index < BUSTER_ARRAY_LENGTH(startup_names) && result.error == LINK_ERROR_NONE; startup_index += 1)
                {
                    s64 startup_displacement = (s64)startup_thunk_rva[startup_index] -
                                               (s64)(entry_rva + (u64)startup_stub_words[startup_index] * sizeof(u32));
                    u32 startup_instruction = 0;
                    if (!link_aarch64_branch_encode(A64_OPCODE_BL, startup_displacement, &startup_instruction))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    else
                    {
                        link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + (u64)startup_stub_words[startup_index] * sizeof(u32),
                                       startup_instruction);
                    }
                }
                if (plan.destructor_count)
                {
                    u32 atexit_instruction = 0;
                    s64 atexit_displacement = (s64)terminate_thunk_rva[1] - (s64)(entry_rva + (u64)atexit_stub_word * sizeof(u32));
                    if (!link_aarch64_branch_encode(A64_OPCODE_BL, atexit_displacement, &atexit_instruction))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    else
                    {
                        link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + (u64)atexit_stub_word * sizeof(u32), atexit_instruction);
                    }
                }
                for (u32 index = 0; index < initializer_count && result.error == LINK_ERROR_NONE; index += 1)
                {
                    LinkInitializerEntry entry =
                        index < plan.constructor_count ? plan.constructors[index] : plan.destructors[index - plan.constructor_count];
                    ObjectSymbol* initializer = entry.symbol < object->symbol_count ? object->symbols + entry.symbol : 0;
                    if (!initializer || initializer->section >= OBJECT_SECTION_COUNT ||
                        object_output_sections[initializer->section] >= pe_section_count)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        break;
                    }
                    u64 initializer_rva = section_rvas[object_output_sections[initializer->section]] + object_section_offsets[initializer->section] +
                                          initializer->value + (u64)entry.addend;
                    u64 field = (u64)initializer_displacement_offsets[index] * sizeof(u32);
                    u32 instruction = 0;
                    if (!link_aarch64_branch_encode(A64_OPCODE_BL, (s64)initializer_rva - (s64)(entry_rva + field), &instruction))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        break;
                    }
                    link_write_u32(bytes, section_raw_offsets[PE_SECTION_TEXT] + field, instruction);
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        for (u32 relocation_index = 0; relocation_index < object->relocation_count && result.error == LINK_ERROR_NONE; relocation_index += 1)
        {
            ObjectRelocation* relocation = &object->relocations[relocation_index];
            if (relocation->section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation->section))
            {
                continue;
            }
            if (relocation->section >= OBJECT_SECTION_COUNT || relocation->symbol >= object->symbol_count)
            {
                result.error = LINK_ERROR_RELOCATION;
            }
            ObjectSection*section = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                section = &object->sections[relocation->section];
            }
            u64 width = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                width = relocation->kind == OBJECT_RELOCATION_ABSOLUTE64 ? 8 : 4;
                if (relocation->offset > section->data.length || width > section->data.length - relocation->offset)
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
            ObjectSymbol*symbol = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                symbol = &object->symbols[relocation->symbol];
            }
            u64 symbol_rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                symbol_rva = 0;
            }
            bool data_import = false;
            if (result.error == LINK_ERROR_NONE)
            {
                data_import = false;
                if (symbol->section == OBJECT_SECTION_UNDEFINED)
                {
                    if (aarch64 && link_pe_aarch64_tls_index_symbol(object, relocation->symbol))
                    {
                        // __tls_index is owned by the PE loader rather than an
                        // import library.  The two relocation handlers below
                        // resolve it to this image's synthesized index slot.
                        symbol_rva = 0;
                    }
                    else
                    {
                        u32 import_index = import_indices[relocation->symbol];
                        bool call_relocation = (!aarch64 && relocation->kind == OBJECT_RELOCATION_X86_64_PC32) ||
                                               (aarch64 && (relocation->kind == OBJECT_RELOCATION_AARCH64_CALL26 ||
                                                            relocation->kind == OBJECT_RELOCATION_AARCH64_JUMP26));
                        if (import_index == UINT32_MAX)
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                        if (result.error == LINK_ERROR_NONE)
                        {
                            if (symbol->kind == OBJECT_SYMBOL_DATA)
                            {
                                if ((!aarch64 && relocation->kind != OBJECT_RELOCATION_X86_64_PC32) ||
                                    (aarch64 && relocation->kind != OBJECT_RELOCATION_ABSOLUTE64))
                                {
                                    result.error = LINK_ERROR_RELOCATION;
                                    result.symbol = symbol->name;
                                }
                                u64 import_slot = (u64)import_slots[relocation->symbol] * sizeof(u64);
                                if (!link_u64_add(import_section_rva, runtime_address_offset, &symbol_rva) ||
                                    !link_u64_add(symbol_rva, import_slot, &symbol_rva))
                                {
                                    result.error = LINK_ERROR_RELOCATION;
                                    result.symbol = symbol->name;
                                }
                                data_import = true;
                            }
                            else
                            {
                                if (!call_relocation)
                                {
                                    result.error = LINK_ERROR_RELOCATION;
                                    result.symbol = symbol->name;
                                }
                                u64 thunk_delta = (u64)import_index * thunk_entry_size;
                                if (!link_u64_add(section_rvas[PE_SECTION_TEXT], thunk_offset, &symbol_rva) ||
                                    !link_u64_add(symbol_rva, thunk_delta, &symbol_rva))
                                {
                                    result.error = LINK_ERROR_RELOCATION;
                                    result.symbol = symbol->name;
                                }
                            }
                        }
                    }
                }
                else if (symbol->section < OBJECT_SECTION_COUNT)
                {
                    if (object_output_sections[symbol->section] >= pe_section_count)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        if (!link_u64_add(section_rvas[object_output_sections[symbol->section]], object_section_offsets[symbol->section], &symbol_rva) ||
                            !link_u64_add(symbol_rva, symbol->value, &symbol_rva))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                }
                else
                {
                    result.error = LINK_ERROR_RELOCATION;
                    result.symbol = symbol->name;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (object_output_sections[relocation->section] >= pe_section_count)
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
            u64 place_rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                place_rva = 0;
            }
            u64 output_offset = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                output_offset = 0;
                if (!link_u64_add(section_rvas[object_output_sections[relocation->section]], object_section_offsets[relocation->section], &place_rva) ||
                    !link_u64_add(place_rva, relocation->offset, &place_rva) ||
                    !link_u64_add(section_raw_offsets[object_output_sections[relocation->section]], object_section_offsets[relocation->section], &output_offset) ||
                    !link_u64_add(output_offset, relocation->offset, &output_offset))
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (relocation->kind == OBJECT_RELOCATION_COFF_ADDR32NB)
                {
                    u64 value = 0;
                    if (symbol->section == OBJECT_SECTION_UNDEFINED || !link_address_addend(symbol_rva, relocation->addend, &value) || value > UINT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)value);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_X86_64_PE_TLS_INDEX_PC32)
                {
                    u64 target_rva = 0;
                    s64 value = 0;
                    if (!link_u64_add(import_section_rva, tls_index_offset, &target_rva) ||
                        !link_address_difference(target_rva, place_rva, relocation->addend, &value) || value < INT32_MIN || value > INT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)(s32)value);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_PE_TLS_OFFSET32)
                {
                    if (symbol->section != OBJECT_SECTION_THREAD_LOCAL_DATA && symbol->section != OBJECT_SECTION_THREAD_LOCAL_ZERO)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    u64 tls_offset = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        tls_offset = 0;
                        if (!link_u64_add(object_section_offsets[symbol->section], symbol->value, &tls_offset) ||
                            !link_address_addend(tls_offset, relocation->addend, &tls_offset) || tls_offset > UINT32_MAX)
                        {
                            result.error = LINK_ERROR_RELOCATION;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)tls_offset);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_ADRP)
                {
                    u64 target_address = pe_image_base + import_section_rva + tls_index_offset;
                    u64 place_address = pe_image_base + place_rva;
                    u32 instruction = link_read_u32(bytes, output_offset);
                    u32 encoded = 0;
                    if (!object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21, instruction, place_address,
                                                          target_address, relocation->addend, &encoded))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, encoded);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_LO12)
                {
                    u64 target_address = pe_image_base + import_section_rva + tls_index_offset;
                    u32 instruction = link_read_u32(bytes, output_offset);
                    u32 encoded = 0;
                    if (!object_aarch64_pe_tls_index_lo12_relocate(instruction, target_address, relocation->addend, &encoded))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, encoded);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PE_TLS_OFFSET12)
                {
                    if (symbol->section != OBJECT_SECTION_THREAD_LOCAL_DATA && symbol->section != OBJECT_SECTION_THREAD_LOCAL_ZERO)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    u64 tls_offset = 0;
                    if (result.error == LINK_ERROR_NONE && !link_u64_add(object_section_offsets[symbol->section], symbol->value, &tls_offset))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        u32 instruction = link_read_u32(bytes, output_offset);
                        u32 encoded = 0;
                        if (!object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A, instruction, output_offset, tls_offset,
                                                              relocation->addend, &encoded))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                        }
                        else
                        {
                            link_write_u32(bytes, output_offset, encoded);
                        }
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21 ||
                         relocation->kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A ||
                         relocation->kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L)
                {
                    u32 instruction = link_read_u32(bytes, output_offset);
                    u32 encoded = 0;
                    if (symbol->section == OBJECT_SECTION_UNDEFINED ||
                        !object_aarch64_pe_page_relocate(relocation->kind, instruction, pe_image_base + place_rva,
                                                          pe_image_base + symbol_rva, relocation->addend, &encoded))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, encoded);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_X86_64_PC32)
                {
                    if (data_import)
                    {
                        if (relocation->section != OBJECT_SECTION_TEXT || relocation->offset < 3 || bytes[output_offset - 3] != 0x48 ||
                            bytes[output_offset - 2] != 0x8d || bytes[output_offset - 1] != 0x05)
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                        if (result.error == LINK_ERROR_NONE)
                        {
                            if (output_offset < 3 || output_offset > result.executable.length || result.executable.length - output_offset < 4)
                            {
                                result.error = LINK_ERROR_RELOCATION;
                                result.symbol = symbol->name;
                            }
                        }
                        LinkX86InstructionBuilder load_builder = {0};
                        if (result.error == LINK_ERROR_NONE)
                        {
                            load_builder = (LinkX86InstructionBuilder){.bytes = bytes + output_offset - 3, .capacity = 7};
                        }
                        BusterX86MetadataPhysicalOperand load_operands[2] = {
                            link_x86_register(0, 64),
                            link_x86_memory_rip(64, 0),
                        };
                        if (result.error == LINK_ERROR_NONE)
                        {
                            if (!link_x86_emit(&load_builder, S8("MOV"), load_operands, 2) || load_builder.count != 7)
                            {
                                result.error = LINK_ERROR_RELOCATION;
                                result.symbol = symbol->name;
                            }
                        }
                    }
                    s64 value = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        value = 0;
                        if (!link_address_difference(symbol_rva, place_rva, relocation->addend, &value) || value < INT32_MIN || value > INT32_MAX)
                        {
                            result.error = LINK_ERROR_RELOCATION;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)(s32)value);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_CALL26 || relocation->kind == OBJECT_RELOCATION_AARCH64_JUMP26)
                {
                    s64 displacement = 0;
                    u32 instruction = link_read_u32(section->data.pointer, relocation->offset);
                    u32 patched = 0;
                    if ((place_rva & 3) || (symbol->section == OBJECT_SECTION_UNDEFINED && relocation->addend) ||
                        !link_address_difference(symbol_rva, place_rva, relocation->addend, &displacement) ||
                        !link_aarch64_branch_relocate(relocation->kind, instruction, displacement, &patched))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, patched);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
                {
                    u64 image_base = ((u64)PE_IMAGE_BASE_HIGH << 32) | PE_IMAGE_BASE_LOW;
                    if (data_import)
                    {
                        if (!aarch64 || relocation->section != OBJECT_SECTION_TEXT || relocation->offset < 8 ||
                            link_read_u32(bytes + output_offset - 8, 0) != UINT32_C(0x58000049) ||
                            link_read_u32(bytes + output_offset - 4, 0) != UINT32_C(0x14000003) || relocation->addend)
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                        u64 iat_address = 0;
                        if (result.error == LINK_ERROR_NONE)
                        {
                            iat_address = image_base + symbol_rva;
                        }
                        u64 load_address = 0;
                        if (result.error == LINK_ERROR_NONE)
                        {
                            load_address = image_base + place_rva - 8;
                        }
                        bool valid = false;
                        if (result.error == LINK_ERROR_NONE)
                        {
                            valid = true;
                            link_write_u32(bytes, output_offset - 8, link_aarch64_adrp(9, load_address, iat_address, &valid));
                        }
                        u64 page_offset = 0;
                        if (result.error == LINK_ERROR_NONE)
                        {
                            page_offset = symbol_rva & 0xfff;
                            if (!valid || page_offset % sizeof(u64))
                            {
                                result.error = LINK_ERROR_RELOCATION;
                                result.symbol = symbol->name;
                            }
                        }
                        if (result.error == LINK_ERROR_NONE)
                        {
                            link_write_u32(bytes, output_offset - 4, UINT32_C(0xf9400000) | ((u32)(page_offset / sizeof(u64)) << 10) | (9 << 5) | 9);
                            link_write_u32(bytes, output_offset, UINT32_C(0x14000002));
                            link_write_u32(bytes, output_offset + sizeof(u32), 0);
                        }
                    }
                    else
                    {
                        u64 address = 0;
                        if (!link_u64_add(image_base, symbol_rva, &address) || !link_address_addend(address, relocation->addend, &address))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                        if (result.error == LINK_ERROR_NONE)
                        {
                            link_write_u64(bytes, output_offset, address);
                        }
                    }
                }
                else
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE && aarch64 &&
        !link_pe_base_relocations_write(bytes, file_size, relocation_file_offset, base_relocation_rvas, base_relocation_count,
                                        relocation_virtual_size))
    {
        result.error = LINK_ERROR_RELOCATION;
    }
    if (result.error == LINK_ERROR_NONE)
    {
        bytes[0] = 'M';
        bytes[1] = 'Z';
        link_write_u32(bytes, 0x3c, PE_OFFSET);
        memcpy(bytes + PE_OFFSET, "PE\0\0", 4);
    }
    u64 coff = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        coff = PE_OFFSET + 4;
        link_write_u16(bytes, coff, aarch64 ? 0xaa64 : 0x8664);
        link_write_u16(bytes, coff + 2, pe_section_count);
        link_write_u16(bytes, coff + 16, PE_OPTIONAL_HEADER_SIZE);
        link_write_u16(bytes, coff + 18, aarch64 ? 0x22 : 0x23);
    }
    u64 optional = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        optional = coff + PE_COFF_HEADER_SIZE;
        link_write_u16(bytes, optional, 0x20b);
        link_write_u32(bytes, optional + 4, (u32)text_raw_size);
        link_write_u32(bytes, optional + 8,
                       (u32)(read_only_raw_size + data_raw_size + tls_raw_size + pdata_raw_size + xdata_raw_size + import_raw_size +
                             (emit_debug ? debug_raw_size : 0) + (aarch64 ? relocation_raw_size : 0)));
        link_write_u32(bytes, optional + 12, (u32)zero_virtual_size);
        link_write_u32(bytes, optional + 16, (u32)entry_rva);
        link_write_u32(bytes, optional + 20, section_rvas[PE_SECTION_TEXT]);
        link_write_u32(bytes, optional + 24, PE_IMAGE_BASE_LOW);
        link_write_u32(bytes, optional + 28, PE_IMAGE_BASE_HIGH);
        link_write_u32(bytes, optional + 32, PE_SECTION_ALIGNMENT);
        link_write_u32(bytes, optional + 36, PE_FILE_ALIGNMENT);
        link_write_u16(bytes, optional + 40, 6);
        link_write_u16(bytes, optional + 48, 6);
        link_write_u32(bytes, optional + 56, (u32)image_size);
        link_write_u32(bytes, optional + 60, (u32)header_size);
        link_write_u16(bytes, optional + 68, 3);
        link_write_u16(bytes, optional + 70, aarch64 ? 0x160 : 0x100);
        link_write_u64(bytes, optional + 72, LINK_PE_STACK_RESERVE);
        link_write_u64(bytes, optional + 80, LINK_PE_STACK_COMMIT);
        link_write_u64(bytes, optional + 88, LINK_PE_HEAP_RESERVE);
        link_write_u64(bytes, optional + 96, LINK_PE_HEAP_COMMIT);
        link_write_u32(bytes, optional + 108, 16);
        link_write_u32(bytes, optional + 120, import_section_rva + (u32)import_descriptor_offset);
        link_write_u32(bytes, optional + 124, (u32)(import_descriptor_count * PE_IMPORT_DESCRIPTOR_SIZE));
        if (pdata_virtual_size)
        {
            link_write_u32(bytes, optional + 136, section_rvas[PE_SECTION_PDATA]);
            link_write_u32(bytes, optional + 140, (u32)pdata_virtual_size);
        }
        if (tls_virtual_size)
        {
            link_write_u32(bytes, optional + 184, import_section_rva + (u32)tls_directory_offset);
            link_write_u32(bytes, optional + 188, 40);
        }
        if (aarch64 && relocation_virtual_size)
        {
            link_write_u32(bytes, optional + 152, section_rvas[PE_SECTION_RELOCATION]);
            link_write_u32(bytes, optional + 156, (u32)relocation_virtual_size);
        }
        link_write_u32(bytes, optional + 208, import_section_rva + (u32)(total_import_slots ? runtime_address_offset : terminate_address_offset));
        link_write_u32(bytes, optional + 212,
                       (u32)(total_import_slots ? ((u64)total_import_slots + 2 * terminate_slot_count) * sizeof(u64)
                                                : (u64)terminate_slot_count * sizeof(u64)));
        if (emit_debug)
        {
            link_write_u32(bytes, optional + 160, section_rvas[PE_SECTION_DEBUG]);
            link_write_u32(bytes, optional + 164, 28);
        }
    }
    u64 section_header = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        section_header = optional + PE_OPTIONAL_HEADER_SIZE;
        link_pe_section_header(bytes, section_header + PE_SECTION_TEXT * PE_SECTION_HEADER_SIZE, ".text\0\0\0", (u32)text_virtual_size,
                               section_rvas[PE_SECTION_TEXT], (u32)text_raw_size, section_raw_offsets[PE_SECTION_TEXT], 0x60000020);
        link_pe_section_header(bytes, section_header + PE_SECTION_READ_ONLY_DATA * PE_SECTION_HEADER_SIZE, ".rdata\0\0",
                               (u32)BUSTER_MAX(read_only_virtual_size, 1), section_rvas[PE_SECTION_READ_ONLY_DATA], (u32)read_only_raw_size,
                               section_raw_offsets[PE_SECTION_READ_ONLY_DATA], 0x40000040);
        link_pe_section_header(bytes, section_header + PE_SECTION_DATA * PE_SECTION_HEADER_SIZE, ".data\0\0\0", (u32)BUSTER_MAX(data_virtual_size, 1),
                               section_rvas[PE_SECTION_DATA], (u32)data_raw_size, section_raw_offsets[PE_SECTION_DATA], 0xc0000040);
        link_pe_section_header(bytes, section_header + PE_SECTION_ZERO * PE_SECTION_HEADER_SIZE, ".bss\0\0\0\0", (u32)BUSTER_MAX(zero_virtual_size, 1),
                               section_rvas[PE_SECTION_ZERO], 0, 0, 0xc0000080);
        link_pe_section_header(bytes, section_header + PE_SECTION_TLS * PE_SECTION_HEADER_SIZE, ".tls\0\0\0\0", (u32)BUSTER_MAX(tls_virtual_size, 1),
                               section_rvas[PE_SECTION_TLS], (u32)tls_raw_size, section_raw_offsets[PE_SECTION_TLS], 0xc0000040);
        link_pe_section_header(bytes, section_header + PE_SECTION_PDATA * PE_SECTION_HEADER_SIZE, ".pdata\0\0", (u32)pdata_virtual_size,
                               section_rvas[PE_SECTION_PDATA], (u32)pdata_raw_size, section_raw_offsets[PE_SECTION_PDATA], 0x40000040);
        link_pe_section_header(bytes, section_header + PE_SECTION_XDATA * PE_SECTION_HEADER_SIZE, ".xdata\0\0", (u32)xdata_virtual_size,
                               section_rvas[PE_SECTION_XDATA], (u32)xdata_raw_size, section_raw_offsets[PE_SECTION_XDATA], 0x40000040);
        link_pe_section_header(bytes, section_header + PE_SECTION_IMPORT * PE_SECTION_HEADER_SIZE, ".idata\0\0", (u32)import_virtual_size,
                               section_rvas[PE_SECTION_IMPORT], (u32)import_raw_size, section_raw_offsets[PE_SECTION_IMPORT], 0xc0000040);
        if (emit_debug)
        {
            link_pe_section_header(bytes, section_header + PE_SECTION_DEBUG * PE_SECTION_HEADER_SIZE, ".debug\0\0", (u32)debug_virtual_size,
                                   section_rvas[PE_SECTION_DEBUG], (u32)debug_raw_size, section_raw_offsets[PE_SECTION_DEBUG], 0x40000040);
        }
        if (aarch64)
        {
            u32 relocation_header = emit_debug ? PE_SECTION_RELOCATION : PE_SECTION_DEBUG;
            link_pe_section_header(bytes, section_header + (u64)relocation_header * PE_SECTION_HEADER_SIZE, ".reloc\0\0",
                                   (u32)relocation_virtual_size, section_rvas[PE_SECTION_RELOCATION], (u32)relocation_raw_size,
                                   section_raw_offsets[PE_SECTION_RELOCATION], 0x42000040);
        }
        if (emit_debug)
        {
    
            PdbSection* pdb_sections = arena_allocate(arena, PdbSection, pe_section_count);
            for (u32 section_index = 0; section_index < pe_section_count; section_index += 1)
            {
                String8 name = section_index == PE_SECTION_TEXT             ? S8(".text")
                              : section_index == PE_SECTION_READ_ONLY_DATA ? S8(".rdata")
                              : section_index == PE_SECTION_DATA           ? S8(".data")
                              : section_index == PE_SECTION_ZERO           ? S8(".bss")
                              : section_index == PE_SECTION_TLS            ? S8(".tls")
                              : section_index == PE_SECTION_PDATA          ? S8(".pdata")
                              : section_index == PE_SECTION_XDATA          ? S8(".xdata")
                              : section_index == PE_SECTION_IMPORT         ? S8(".idata")
                              : section_index == PE_SECTION_DEBUG          ? S8(".debug")
                                                                          : S8(".reloc");
                u64 virtual_size = section_index == PE_SECTION_TEXT             ? text_virtual_size
                                   : section_index == PE_SECTION_READ_ONLY_DATA ? read_only_virtual_size
                                   : section_index == PE_SECTION_DATA           ? data_virtual_size
                                   : section_index == PE_SECTION_ZERO           ? zero_virtual_size
                                   : section_index == PE_SECTION_TLS            ? tls_virtual_size
                                   : section_index == PE_SECTION_PDATA          ? pdata_virtual_size
                                   : section_index == PE_SECTION_XDATA          ? xdata_virtual_size
                                   : section_index == PE_SECTION_IMPORT         ? import_virtual_size
                                   : section_index == PE_SECTION_DEBUG          ? debug_virtual_size
                                                                               : relocation_virtual_size;
                u64 raw_size = section_index == PE_SECTION_TEXT             ? text_raw_size
                               : section_index == PE_SECTION_READ_ONLY_DATA ? read_only_raw_size
                               : section_index == PE_SECTION_DATA           ? data_raw_size
                               : section_index == PE_SECTION_ZERO           ? 0
                               : section_index == PE_SECTION_TLS            ? tls_raw_size
                               : section_index == PE_SECTION_PDATA          ? pdata_raw_size
                               : section_index == PE_SECTION_XDATA          ? xdata_raw_size
                               : section_index == PE_SECTION_IMPORT         ? import_raw_size
                               : section_index == PE_SECTION_DEBUG          ? debug_raw_size
                                                                           : relocation_raw_size;
                u32 characteristics = section_index == PE_SECTION_TEXT             ? 0x60000020
                                      : section_index == PE_SECTION_DATA           ? 0xc0000040
                                      : section_index == PE_SECTION_ZERO           ? 0xc0000080
                                      : section_index == PE_SECTION_TLS            ? 0xc0000040
                                      : section_index == PE_SECTION_IMPORT         ? 0xc0000040
                                      : section_index == PE_SECTION_RELOCATION     ? 0x42000040
                                                                                   : 0x40000040;
                pdb_sections[section_index] = (PdbSection){
                    .name = name,
                    .virtual_address = section_rvas[section_index],
                    .virtual_size = (u32)BUSTER_MIN(virtual_size, UINT32_MAX),
                    .raw_size = (u32)BUSTER_MIN(raw_size, UINT32_MAX),
                    .raw_offset = section_raw_offsets[section_index],
                    .characteristics = characteristics,
                };
            }
            PdbModule* pdb_modules = arena_allocate(arena, PdbModule, object->debug_module_count);
            PdbContribution* pdb_contributions = arena_allocate(arena, PdbContribution, object->debug_module_count);
            u64 identity_size = base_file_size;
            for (u32 module_index = 0; module_index < object->debug_module_count && result.error == LINK_ERROR_NONE; module_index += 1)
            {
                ObjectDebugModule* source = object->debug_modules + module_index;
                ByteSlice symbols =
                    link_pe_resolved_codeview(arena, object, source, object_output_sections, object_section_offsets, pe_section_count);
                if (!symbols.pointer || source->types_offset > object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.length ||
                    source->types_size > object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.length - source->types_offset ||
                    object_section_offsets[OBJECT_SECTION_TEXT] > UINT32_MAX ||
                    source->code_offset > UINT32_MAX - object_section_offsets[OBJECT_SECTION_TEXT] || source->code_size > UINT32_MAX)
                {
                    result.error = LINK_ERROR_OBJECT_WRITE;
                }
                u8*types = 0;
                if (result.error == LINK_ERROR_NONE)
                {
                    types = arena_allocate(arena, u8, source->types_size);
                    if (source->types_size)
                    {
                        memcpy(types, object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.pointer + source->types_offset, source->types_size);
                    }
                    pdb_modules[module_index] = (PdbModule){
                        .name = source->name,
                        .codeview_symbols = symbols,
                        .codeview_types = (ByteSlice){.pointer = types, .length = source->types_size},
                        .code_offset = (u32)(object_section_offsets[OBJECT_SECTION_TEXT] + source->code_offset),
                        .code_size = (u32)source->code_size,
                        .code_section = 1,
                        .contributions = pdb_contributions + module_index,
                        .contribution_count = source->code_size != 0,
                    };
                    pdb_contributions[module_index] = (PdbContribution){
                        .section = 1,
                        .offset = pdb_modules[module_index].code_offset,
                        .size = pdb_modules[module_index].code_size,
                    };
                    identity_size += source->name.length + symbols.length + source->types_size + 16;
                }
            }
            u8*identity = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                identity = arena_allocate(arena, u8, identity_size);
                memcpy(identity, bytes, base_file_size);
            }
            u64 identity_cursor = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                identity_cursor = base_file_size;
                for (u32 module_index = 0; module_index < object->debug_module_count; module_index += 1)
                {
                    PdbModule* module = pdb_modules + module_index;
                    memcpy(identity + identity_cursor, module->name.pointer, module->name.length);
                    identity_cursor += module->name.length;
                    memcpy(identity + identity_cursor, module->codeview_symbols.pointer, module->codeview_symbols.length);
                    identity_cursor += module->codeview_symbols.length;
                    memcpy(identity + identity_cursor, module->codeview_types.pointer, module->codeview_types.length);
                    identity_cursor += module->codeview_types.length;
                    link_write_u32(identity, identity_cursor, module->code_offset);
                    identity_cursor += 4;
                    link_write_u32(identity, identity_cursor, module->code_size);
                    identity_cursor += 4;
                }
            }
            u8*digest = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                digest = arena_allocate(arena, u8, 32);
                memset(digest, 0, 32);
                link_sha256(arena, identity, identity_cursor, digest);
            }
            PdbInput pdb_input = {0};
            if (result.error == LINK_ERROR_NONE)
            {
                pdb_input = (PdbInput){
                    .sections = pdb_sections,
                    .section_count = pe_section_count,
                    .age = 1,
                    .machine = aarch64 ? 0xaa64 : 0x8664,
                    .modules = pdb_modules,
                    .module_count = object->debug_module_count,
                };
                memcpy(pdb_input.guid, digest, sizeof(pdb_input.guid));
            }
            PdbResult pdb = {0};
            if (result.error == LINK_ERROR_NONE)
            {
                pdb = pdb_build(arena, pdb_input);
                if (!pdb.valid)
                {
                    result.error = LINK_ERROR_OBJECT_WRITE;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                result.pdb = pdb.bytes;
                result.pdb_path = pdb_path;
            }
            u64 debug_raw = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                debug_raw = section_raw_offsets[PE_SECTION_DEBUG];
            }
            u32 rsds_size = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                rsds_size = (u32)(24 + pdb_path.length + 1);
                link_write_u32(bytes, debug_raw, 0);
                link_write_u32(bytes, debug_raw + 4, 0);
                link_write_u16(bytes, debug_raw + 8, 0);
                link_write_u16(bytes, debug_raw + 10, 0);
                link_write_u32(bytes, debug_raw + 12, 2);
                link_write_u32(bytes, debug_raw + 16, rsds_size);
                link_write_u32(bytes, debug_raw + 20, section_rvas[PE_SECTION_DEBUG] + 28);
                link_write_u32(bytes, debug_raw + 24, (u32)(debug_raw + 28));
                memcpy(bytes + debug_raw + 28, "RSDS", 4);
                memcpy(bytes + debug_raw + 32, pdb_input.guid, sizeof(pdb_input.guid));
                link_write_u32(bytes, debug_raw + 48, 1);
                memcpy(bytes + debug_raw + 52, pdb_path.pointer, pdb_path.length);
                bytes[debug_raw + 52 + pdb_path.length] = 0;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
        {
            result.error = LINK_ERROR_FILE_WRITE;
        }
        else if (emit_debug && options.output_path.length && !link_write_executable_file(result.pdb_path, result.pdb))
        {
            result.error = LINK_ERROR_FILE_WRITE;
        }
    }
    if (result.error != LINK_ERROR_NONE)
    {
        // A failed relocation or artifact write must not look like a usable
        // in-memory image to callers.  Disk publication happens only above,
        // after every relocation and debug record has been finalized.
        result.executable = (ByteSlice){0};
        result.pdb = (ByteSlice){0};
    }
    return result;
}

typedef struct LinkUefiPeSection LinkUefiPeSection;
struct LinkUefiPeSection
{
    u64 virtual_size;
    u64 raw_size;
    u32 virtual_address;
    u32 raw_offset;
    u32 characteristics;
    u32 output_index;
    bool present;
    u8 reserved[3];
};

BUSTER_GLOBAL_LOCAL bool link_uefi_relocation_is_tls(ObjectRelocationKind kind)
{
    return kind == OBJECT_RELOCATION_X86_64_TPOFF32 || kind == OBJECT_RELOCATION_X86_64_GOTTPOFF || kind == OBJECT_RELOCATION_X86_64_TLSGD ||
           kind == OBJECT_RELOCATION_X86_64_PE_TLS_INDEX_PC32 ||
           kind == OBJECT_RELOCATION_PE_TLS_OFFSET32 || kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_ADRP ||
           kind == OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_LO12 || kind == OBJECT_RELOCATION_AARCH64_PE_TLS_OFFSET12 ||
           kind == OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_HI12 || kind == OBJECT_RELOCATION_AARCH64_TLSLE_ADD_TPREL_LO12;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_uefi_pe64(Arena* arena, ObjectFile* object,
                                                                                 NativeExecutableLinkOptions options)
{
    NativeExecutableLinkResult result = {0};
    enum
    {
        PE_SECTION_TEXT = 0,
        PE_SECTION_READ_ONLY_DATA,
        PE_SECTION_DATA,
        PE_SECTION_ZERO,
        PE_SECTION_PDATA,
        PE_SECTION_XDATA,
        PE_SECTION_RELOCATION,
        PE_SECTION_DEBUG,
        PE_SECTION_KIND_COUNT,
    };
    static char const* const section_header_names[PE_SECTION_KIND_COUNT] = {
        ".text\0\0\0", ".rdata\0\0", ".data\0\0\0", ".bss\0\0\0\0", ".pdata\0\0", ".xdata\0\0", ".reloc\0\0", ".debug\0\0",
    };
    static String8 const section_names[PE_SECTION_KIND_COUNT] = {
        S8_INITIALIZER(".text"),  S8_INITIALIZER(".rdata"), S8_INITIALIZER(".data"),  S8_INITIALIZER(".bss"),
        S8_INITIALIZER(".pdata"), S8_INITIALIZER(".xdata"), S8_INITIALIZER(".reloc"), S8_INITIALIZER(".debug"),
    };
    static u32 const section_characteristics[PE_SECTION_KIND_COUNT] = {
        0x60000020, 0x40000040, 0xc0000040, 0xc0000080, 0x40000040, 0x40000040, 0x42000040, 0x42000040,
    };
    ObjectFile stripped_object = {0};
    LinkInitializerPlan plan = {0};
    if (!link_initializer_plan_build(arena, object, &stripped_object, &plan))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
        return result;
    }
    // A UEFI application's entry point is the firmware's call to the image,
    // and this writer synthesizes no stub of its own to run initializers
    // before it.  Unlike the Mach-O writer -- which hands the arrays to dyld,
    // a loader that already knows to call them -- there is no third party
    // here: a firmware image has no C runtime, and its entry takes the image
    // handle and the system table, so a stub would have to forward both into
    // `UefiMain` after calling the constructors.  That stub is deliberately
    // not built (issue 779): EDK2 firmware drives its own constructor
    // protocol rather than the GNU attribute, so a refusal that names the
    // function is a better answer here than a startup sequence no firmware
    // program asked for.  See link_initializer_plan_empty.
    if (!link_initializer_plan_empty(&plan))
    {
        result.error = LINK_ERROR_UNSUPPORTED_FEATURE;
        result.symbol = link_initializer_plan_first_name(object, &plan);
        return result;
    }
    object = &stripped_object;
    bool aarch64 = object->target.cpu_arch == CPU_ARCH_AARCH64;
    if (object->target.os != OPERATING_SYSTEM_UEFI || (object->target.cpu_arch != CPU_ARCH_X86_64 && !aarch64) ||
        object->section_count < OBJECT_SECTION_COUNT || !object->sections || (object->symbol_count && !object->symbols) ||
        (object->relocation_count && !object->relocations) || (object->debug_module_count && !object->debug_modules) ||
        (options.output_path.length && !options.output_path.pointer) || (options.entry_symbol.length && !options.entry_symbol.pointer) ||
        (options.dynamic_library_count && !options.dynamic_libraries) ||
        (options.runtime_exported_symbol_count && !options.runtime_exported_symbols))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (options.dynamic_library_count || options.runtime_exported_symbol_count || options.framework_path_count || options.framework_count ||
            options.linker_argument_count)
        {
            result.error = LINK_ERROR_UNSUPPORTED_FEATURE;
            result.symbol = S8("UEFI dynamic linking and host linker options");
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length ||
            object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].virtual_size || object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].data.length ||
            object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size)
        {
            result.error = LINK_ERROR_UNSUPPORTED_FEATURE;
            result.symbol = S8("UEFI thread-local storage");
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (object->sections[OBJECT_SECTION_UNWIND].data.length || object->sections[OBJECT_SECTION_UNWIND].virtual_size)
        {
            result.error = LINK_ERROR_UNSUPPORTED_FEATURE;
            result.symbol = S8("DWARF unwind data in a UEFI image");
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        for (u32 section_index = 0; section_index < OBJECT_SECTION_COUNT && result.error == LINK_ERROR_NONE; section_index += 1)
        {
            ObjectSection* section = object->sections + section_index;
            if (section->kind != (ObjectSectionKind)section_index || !section->alignment || !BUSTER_IS_POWER_OF_TWO(section->alignment) ||
                section->alignment > PE_SECTION_ALIGNMENT ||
                (section->data.length && !section->data.pointer))
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (object->sections[OBJECT_SECTION_ZERO].data.length)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        for (u32 symbol_index = 0; symbol_index < object->symbol_count && result.error == LINK_ERROR_NONE; symbol_index += 1)
        {
            ObjectSymbol* symbol = object->symbols + symbol_index;
            if ((symbol->name.length && !symbol->name.pointer) || symbol->kind >= OBJECT_SYMBOL_COUNT)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (symbol->section == OBJECT_SECTION_UNDEFINED)
                {
                    if (symbol->value || symbol->size)
                    {
                        result.error = LINK_ERROR_INVALID_INPUT;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        continue;
                    }
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (symbol->section >= OBJECT_SECTION_COUNT)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
            ObjectSection*section = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                section = object->sections + symbol->section;
            }
            u64 section_size = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                section_size = BUSTER_MAX(section->data.length, section->virtual_size);
                if (symbol->value > section_size || symbol->size > section_size - symbol->value)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
        }
    }
    String8 entry_name = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        entry_name = options.entry_symbol.length ? options.entry_symbol : S8("UefiMain");
    }
    u32 entry_symbol_index = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_symbol_index = link_symbol_find(object, entry_name);
        if (entry_symbol_index == UINT32_MAX || object->symbols[entry_symbol_index].section != OBJECT_SECTION_TEXT ||
            object->symbols[entry_symbol_index].kind != OBJECT_SYMBOL_FUNCTION)
        {
            result.error = LINK_ERROR_ENTRY_SYMBOL;
            result.symbol = entry_name;
        }
    }
    bool emit_debug = false;
    if (result.error == LINK_ERROR_NONE)
    {
        emit_debug = options.debug_info && object->debug_module_count && object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS].data.length;
        if (emit_debug && !object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.pointer &&
            object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.length)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    String8 pdb_path = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        pdb_path = emit_debug ? link_pe_pdb_path(arena, options.output_path) : (String8){0};
    }
    u64 debug_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        debug_virtual_size = 0;
        if (emit_debug && (!link_u64_add(28 + 24 + 1, pdb_path.length, &debug_virtual_size) || debug_virtual_size > UINT32_MAX))
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
    
    }
    u32*object_pe_section_kinds = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        object_pe_section_kinds = arena_allocate(arena, u32, OBJECT_SECTION_COUNT);
    }
    u32*object_output_sections = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        object_output_sections = arena_allocate(arena, u32, OBJECT_SECTION_COUNT);
    }
    u64*object_section_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        object_section_offsets = arena_allocate(arena, u64, OBJECT_SECTION_COUNT);
        memset(object_pe_section_kinds, 0xff, sizeof(*object_pe_section_kinds) * OBJECT_SECTION_COUNT);
        memset(object_output_sections, 0xff, sizeof(*object_output_sections) * OBJECT_SECTION_COUNT);
        memset(object_section_offsets, 0, sizeof(*object_section_offsets) * OBJECT_SECTION_COUNT);
        object_pe_section_kinds[OBJECT_SECTION_TEXT] = PE_SECTION_TEXT;
        object_pe_section_kinds[OBJECT_SECTION_READ_ONLY_DATA] = PE_SECTION_READ_ONLY_DATA;
        object_pe_section_kinds[OBJECT_SECTION_DATA] = PE_SECTION_DATA;
        object_pe_section_kinds[OBJECT_SECTION_ZERO] = PE_SECTION_ZERO;
        object_pe_section_kinds[OBJECT_SECTION_WINDOWS_PDATA] = PE_SECTION_PDATA;
        object_pe_section_kinds[OBJECT_SECTION_WINDOWS_XDATA] = PE_SECTION_XDATA;
    
    }
    LinkUefiPeSection sections[PE_SECTION_KIND_COUNT] = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        for (u32 section_kind = 0; section_kind < PE_SECTION_KIND_COUNT; section_kind += 1)
        {
            sections[section_kind].characteristics = section_characteristics[section_kind];
            sections[section_kind].output_index = UINT32_MAX;
        }
        sections[PE_SECTION_TEXT].virtual_size =
            BUSTER_MAX(object->sections[OBJECT_SECTION_TEXT].data.length, object->sections[OBJECT_SECTION_TEXT].virtual_size);
        sections[PE_SECTION_READ_ONLY_DATA].virtual_size = BUSTER_MAX(object->sections[OBJECT_SECTION_READ_ONLY_DATA].data.length,
                                                                      object->sections[OBJECT_SECTION_READ_ONLY_DATA].virtual_size);
        sections[PE_SECTION_DATA].virtual_size =
            BUSTER_MAX(object->sections[OBJECT_SECTION_DATA].data.length, object->sections[OBJECT_SECTION_DATA].virtual_size);
        sections[PE_SECTION_ZERO].virtual_size = object->sections[OBJECT_SECTION_ZERO].virtual_size;
        sections[PE_SECTION_PDATA].virtual_size = BUSTER_MAX(object->sections[OBJECT_SECTION_WINDOWS_PDATA].data.length,
                                                             object->sections[OBJECT_SECTION_WINDOWS_PDATA].virtual_size);
        sections[PE_SECTION_XDATA].virtual_size = BUSTER_MAX(object->sections[OBJECT_SECTION_WINDOWS_XDATA].data.length,
                                                             object->sections[OBJECT_SECTION_WINDOWS_XDATA].virtual_size);
        sections[PE_SECTION_DEBUG].virtual_size = debug_virtual_size;
        for (u32 section_kind = 0; section_kind < PE_SECTION_KIND_COUNT && result.error == LINK_ERROR_NONE; section_kind += 1)
        {
            if (sections[section_kind].virtual_size > UINT32_MAX)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (!sections[PE_SECTION_TEXT].virtual_size || object->symbols[entry_symbol_index].value >= sections[PE_SECTION_TEXT].virtual_size)
        {
            result.error = LINK_ERROR_ENTRY_SYMBOL;
            result.symbol = entry_name;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        sections[PE_SECTION_TEXT].present = true;
        sections[PE_SECTION_READ_ONLY_DATA].present = sections[PE_SECTION_READ_ONLY_DATA].virtual_size != 0;
        sections[PE_SECTION_DATA].present = sections[PE_SECTION_DATA].virtual_size != 0;
        sections[PE_SECTION_ZERO].present = sections[PE_SECTION_ZERO].virtual_size != 0;
        sections[PE_SECTION_PDATA].present = sections[PE_SECTION_PDATA].virtual_size != 0;
        sections[PE_SECTION_XDATA].present = sections[PE_SECTION_XDATA].virtual_size != 0;
        sections[PE_SECTION_DEBUG].present = emit_debug;
    
    }
    u32 base_relocation_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        base_relocation_count = 0;
        for (u32 relocation_index = 0; relocation_index < object->relocation_count && result.error == LINK_ERROR_NONE; relocation_index += 1)
        {
            ObjectRelocation* relocation = object->relocations + relocation_index;
            if (relocation->section >= OBJECT_SECTION_COUNT || relocation->symbol >= object->symbol_count ||
                relocation->kind >= OBJECT_RELOCATION_COUNT)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (object_section_kind_is_debug((ObjectSectionKind)relocation->section))
                {
                    continue;
                }
                if (link_uefi_relocation_is_tls(relocation->kind))
                {
                    result.error = LINK_ERROR_UNSUPPORTED_FEATURE;
                    result.symbol = S8("UEFI thread-local storage relocation");
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
                {
                    if (object_pe_section_kinds[relocation->section] == UINT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        base_relocation_count += 1;
                    }
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        sections[PE_SECTION_RELOCATION].present = base_relocation_count != 0;
    
    }
    u32 pe_section_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        pe_section_count = 0;
        for (u32 section_kind = 0; section_kind < PE_SECTION_KIND_COUNT; section_kind += 1)
        {
            if (sections[section_kind].present)
            {
                sections[section_kind].output_index = pe_section_count++;
            }
        }
    }
    u64 header_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        header_size = 0;
    }
    u64 header_unaligned_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        header_unaligned_size = PE_OFFSET + 4 + PE_COFF_HEADER_SIZE + PE_OPTIONAL_HEADER_SIZE +
                                    (u64)pe_section_count * PE_SECTION_HEADER_SIZE;
        if (!link_u64_align_forward(header_unaligned_size, PE_FILE_ALIGNMENT, &header_size) || header_size > UINT32_MAX)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    u64 virtual_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        virtual_cursor = PE_SECTION_ALIGNMENT;
    }
    u64 raw_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        raw_cursor = header_size;
        for (u32 section_kind = PE_SECTION_TEXT; section_kind < PE_SECTION_RELOCATION && result.error == LINK_ERROR_NONE; section_kind += 1)
        {
            LinkUefiPeSection* section = sections + section_kind;
            if (!section->present)
            {
                continue;
            }
            if (!link_u64_align_forward(virtual_cursor, PE_SECTION_ALIGNMENT, &virtual_cursor) || virtual_cursor > UINT32_MAX)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                section->virtual_address = (u32)virtual_cursor;
                if (section_kind != PE_SECTION_ZERO)
                {
                    if (!link_u64_align_forward(section->virtual_size, PE_FILE_ALIGNMENT, &section->raw_size) || raw_cursor > UINT32_MAX ||
                        section->raw_size > UINT32_MAX)
                    {
                        result.error = LINK_ERROR_INVALID_INPUT;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        section->raw_offset = (u32)raw_cursor;
                        if (!link_u64_add(raw_cursor, section->raw_size, &raw_cursor))
                        {
                            result.error = LINK_ERROR_INVALID_INPUT;
                        }
                    }
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (!link_u64_add(virtual_cursor, BUSTER_MAX(section->virtual_size, 1), &virtual_cursor))
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        for (u32 object_section = 0; object_section < OBJECT_SECTION_COUNT; object_section += 1)
        {
            u32 pe_kind = object_pe_section_kinds[object_section];
            if (pe_kind != UINT32_MAX && sections[pe_kind].present)
            {
                object_output_sections[object_section] = sections[pe_kind].output_index;
            }
        }
    
    }
    u32*base_relocation_rvas = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        base_relocation_rvas = arena_allocate(arena, u32, base_relocation_count);
    }
    u32 base_relocation_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        base_relocation_cursor = 0;
        for (u32 relocation_index = 0; relocation_index < object->relocation_count && result.error == LINK_ERROR_NONE; relocation_index += 1)
        {
            ObjectRelocation* relocation = object->relocations + relocation_index;
            if (relocation->kind != OBJECT_RELOCATION_ABSOLUTE64 || object_section_kind_is_debug((ObjectSectionKind)relocation->section))
            {
                continue;
            }
            u32 pe_kind = object_pe_section_kinds[relocation->section];
            ObjectSection* source = object->sections + relocation->section;
            if (pe_kind == UINT32_MAX || !sections[pe_kind].present || pe_kind == PE_SECTION_ZERO || relocation->offset > source->data.length ||
                source->data.length - relocation->offset < sizeof(u64))
            {
                result.error = LINK_ERROR_RELOCATION;
            }
            u64 rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                rva = 0;
                if (!link_u64_add(sections[pe_kind].virtual_address, object_section_offsets[relocation->section], &rva) ||
                    !link_u64_add(rva, relocation->offset, &rva) || rva > UINT32_MAX)
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                base_relocation_rvas[base_relocation_cursor++] = (u32)rva;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (base_relocation_cursor != base_relocation_count)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        link_u32_shell_sort(base_relocation_rvas, base_relocation_count);
    }
    u64 relocation_virtual_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        relocation_virtual_size = 0;
        for (u32 index = 0; index < base_relocation_count && result.error == LINK_ERROR_NONE;)
        {
            if (index && base_relocation_rvas[index] == base_relocation_rvas[index - 1])
            {
                result.error = LINK_ERROR_RELOCATION;
            }
            u32 page = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                page = base_relocation_rvas[index] & ~UINT32_C(0xfff);
            }
            u32 end = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                end = index + 1;
                while (end < base_relocation_count && (base_relocation_rvas[end] & ~UINT32_C(0xfff)) == page && result.error == LINK_ERROR_NONE)
                {
                    if (base_relocation_rvas[end] == base_relocation_rvas[end - 1])
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        end += 1;
                    }
                }
            }
            u64 block_unaligned_size = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                block_unaligned_size = 0;
            }
            u64 block_size = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                block_size = 0;
                if (!link_u64_add(8, (u64)(end - index) * sizeof(u16), &block_unaligned_size) ||
                    !link_u64_align_forward(block_unaligned_size, 4, &block_size) || block_size > UINT32_MAX ||
                    !link_u64_add(relocation_virtual_size, block_size, &relocation_virtual_size))
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                index = end;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (sections[PE_SECTION_RELOCATION].present)
        {
            LinkUefiPeSection* section = sections + PE_SECTION_RELOCATION;
            section->virtual_size = relocation_virtual_size;
            if (!link_u64_align_forward(relocation_virtual_size, PE_FILE_ALIGNMENT, &section->raw_size) ||
                !link_u64_align_forward(virtual_cursor, PE_SECTION_ALIGNMENT, &virtual_cursor) || virtual_cursor > UINT32_MAX ||
                raw_cursor > UINT32_MAX || section->raw_size > UINT32_MAX)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                section->virtual_address = (u32)virtual_cursor;
                section->raw_offset = (u32)raw_cursor;
                if (!link_u64_add(virtual_cursor, BUSTER_MAX(section->virtual_size, 1), &virtual_cursor) ||
                    !link_u64_add(raw_cursor, section->raw_size, &raw_cursor))
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
        }
    }
    u64 base_file_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        base_file_size = raw_cursor;
        if (sections[PE_SECTION_DEBUG].present)
        {
            LinkUefiPeSection* section = sections + PE_SECTION_DEBUG;
            if (!link_u64_align_forward(section->virtual_size, PE_FILE_ALIGNMENT, &section->raw_size) ||
                !link_u64_align_forward(virtual_cursor, PE_SECTION_ALIGNMENT, &virtual_cursor) || virtual_cursor > UINT32_MAX ||
                raw_cursor > UINT32_MAX || section->raw_size > UINT32_MAX)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                section->virtual_address = (u32)virtual_cursor;
                section->raw_offset = (u32)raw_cursor;
                if (!link_u64_add(virtual_cursor, BUSTER_MAX(section->virtual_size, 1), &virtual_cursor) ||
                    !link_u64_add(raw_cursor, section->raw_size, &raw_cursor))
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
        }
    }
    u64 image_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        image_size = 0;
    }
    u64 file_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        file_size = raw_cursor;
        if (!link_u64_align_forward(virtual_cursor, PE_SECTION_ALIGNMENT, &image_size) || image_size > UINT32_MAX || file_size > UINT32_MAX)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        result.executable = (ByteSlice){
            .pointer = arena_allocate(arena, u8, file_size),
            .length = file_size,
        };
    }
    u8*bytes = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        bytes = result.executable.pointer;
        memset(bytes, 0, file_size);
        for (u32 object_section = 0; object_section < OBJECT_SECTION_COUNT && result.error == LINK_ERROR_NONE; object_section += 1)
        {
            u32 pe_kind = object_pe_section_kinds[object_section];
            if (pe_kind == UINT32_MAX || !sections[pe_kind].present || pe_kind == PE_SECTION_ZERO)
            {
                continue;
            }
            ByteSlice data = object->sections[object_section].data;
            if (data.length)
            {
                u64 output_offset = 0;
                if (!link_u64_add(sections[pe_kind].raw_offset, object_section_offsets[object_section], &output_offset) ||
                    output_offset > file_size || data.length > file_size - output_offset)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
                if (result.error == LINK_ERROR_NONE)
                {
                    memcpy(bytes + output_offset, data.pointer, data.length);
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
    
    }
    u64 image_base = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        image_base = UINT64_C(0x140000000);
        for (u32 relocation_index = 0; relocation_index < object->relocation_count && result.error == LINK_ERROR_NONE; relocation_index += 1)
        {
            ObjectRelocation* relocation = object->relocations + relocation_index;
            if (object_section_kind_is_debug((ObjectSectionKind)relocation->section))
            {
                continue;
            }
            if (relocation->symbol >= object->symbol_count)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            ObjectSymbol*symbol = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                symbol = object->symbols + relocation->symbol;
                if (symbol->section == OBJECT_SECTION_UNDEFINED)
                {
                    result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
                    result.symbol = symbol->name;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (symbol->section >= OBJECT_SECTION_COUNT || object_pe_section_kinds[symbol->section] == UINT32_MAX ||
                    !sections[object_pe_section_kinds[symbol->section]].present)
                {
                    result.error = LINK_ERROR_RELOCATION;
                    result.symbol = symbol->name;
                }
            }
            u32 source_pe_kind = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                source_pe_kind = object_pe_section_kinds[relocation->section];
                if (source_pe_kind == UINT32_MAX || !sections[source_pe_kind].present || source_pe_kind == PE_SECTION_ZERO)
                {
                    result.error = LINK_ERROR_RELOCATION;
                    result.symbol = symbol->name;
                }
            }
            u32 symbol_pe_kind = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                symbol_pe_kind = object_pe_section_kinds[symbol->section];
            }
            ObjectSection*source = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                source = object->sections + relocation->section;
            }
            u64 symbol_rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                symbol_rva = 0;
            }
            u64 place_rva = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                place_rva = 0;
            }
            u64 output_offset = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                output_offset = 0;
                if (!link_u64_add(sections[symbol_pe_kind].virtual_address, object_section_offsets[symbol->section], &symbol_rva) ||
                    !link_u64_add(symbol_rva, symbol->value, &symbol_rva) ||
                    !link_u64_add(sections[source_pe_kind].virtual_address, object_section_offsets[relocation->section], &place_rva) ||
                    !link_u64_add(place_rva, relocation->offset, &place_rva) ||
                    !link_u64_add(sections[source_pe_kind].raw_offset, object_section_offsets[relocation->section], &output_offset) ||
                    !link_u64_add(output_offset, relocation->offset, &output_offset) || symbol_rva > UINT32_MAX || place_rva > UINT32_MAX ||
                    output_offset > file_size)
                {
                    result.error = LINK_ERROR_RELOCATION;
                    result.symbol = symbol->name;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (relocation->kind == OBJECT_RELOCATION_X86_64_PC32)
                {
                    s64 value = 0;
                    if (aarch64 || relocation->offset > source->data.length || source->data.length - relocation->offset < sizeof(u32) ||
                        output_offset > file_size || sizeof(u32) > file_size - output_offset ||
                        !link_address_difference(symbol_rva, place_rva, relocation->addend, &value) || value < INT32_MIN || value > INT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)(s32)value);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_CALL26 || relocation->kind == OBJECT_RELOCATION_AARCH64_JUMP26)
                {
                    s64 value = 0;
                    u32 patched = 0;
                    u32 instruction = 0;
                    if (!aarch64 || relocation->offset > source->data.length || source->data.length - relocation->offset < sizeof(u32) ||
                        output_offset > file_size || sizeof(u32) > file_size - output_offset ||
                        !link_address_difference(symbol_rva, place_rva, relocation->addend, &value))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        instruction = link_read_u32(source->data.pointer, relocation->offset);
                        if (!link_aarch64_branch_relocate(relocation->kind, instruction, value, &patched))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, patched);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PREL32)
                {
                    s64 value = 0;
                    if (!aarch64 || relocation->offset > source->data.length || source->data.length - relocation->offset < sizeof(u32) ||
                        output_offset > file_size || sizeof(u32) > file_size - output_offset ||
                        !link_address_difference(symbol_rva, place_rva, relocation->addend, &value) || value < INT32_MIN || value > INT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)(s32)value);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21 ||
                         relocation->kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A ||
                         relocation->kind == OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L)
                {
                    u32 instruction = 0;
                    u32 patched = 0;
                    u64 place_address = 0;
                    u64 symbol_address = 0;
                    if (!aarch64 || relocation->offset > source->data.length || source->data.length - relocation->offset < sizeof(u32) ||
                        output_offset > file_size || sizeof(u32) > file_size - output_offset || !link_u64_add(image_base, place_rva, &place_address) ||
                        !link_u64_add(image_base, symbol_rva, &symbol_address))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        instruction = link_read_u32(bytes, output_offset);
                        if (!object_aarch64_pe_page_relocate(relocation->kind, instruction, place_address, symbol_address, relocation->addend,
                                                              &patched))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, patched);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
                {
                    u64 address = 0;
                    if (relocation->offset > source->data.length || source->data.length - relocation->offset < sizeof(u64) ||
                        output_offset > file_size || sizeof(u64) > file_size - output_offset || !link_u64_add(image_base, symbol_rva, &address) ||
                        !link_address_addend(address, relocation->addend, &address))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u64(bytes, output_offset, address);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_COFF_ADDR32NB)
                {
                    u64 address = 0;
                    if (relocation->offset > source->data.length || source->data.length - relocation->offset < sizeof(u32) ||
                        output_offset > file_size || sizeof(u32) > file_size - output_offset ||
                        !link_address_addend(symbol_rva, relocation->addend, &address) || address > UINT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)address);
                    }
                }
                else
                {
                    result.error = link_uefi_relocation_is_tls(relocation->kind) ? LINK_ERROR_UNSUPPORTED_FEATURE : LINK_ERROR_RELOCATION;
                    result.symbol = symbol->name;
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
    
        if (sections[PE_SECTION_RELOCATION].present)
        {
            u64 output = sections[PE_SECTION_RELOCATION].raw_offset;
            u64 relocation_data_end = 0;
            if (!link_u64_add(output, sections[PE_SECTION_RELOCATION].virtual_size, &relocation_data_end) || relocation_data_end > file_size)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                for (u32 index = 0; index < base_relocation_count && result.error == LINK_ERROR_NONE;)
                {
                    u32 page = base_relocation_rvas[index] & ~UINT32_C(0xfff);
                    u32 end = index + 1;
                    while (end < base_relocation_count && (base_relocation_rvas[end] & ~UINT32_C(0xfff)) == page)
                    {
                        end += 1;
                    }
                    u64 block_unaligned_size = 0;
                    u64 block_size_u64 = 0;
                    if (!link_u64_add(8, (u64)(end - index) * sizeof(u16), &block_unaligned_size) ||
                        !link_u64_align_forward(block_unaligned_size, 4, &block_size_u64) || block_size_u64 > UINT32_MAX ||
                        output > relocation_data_end || block_size_u64 > relocation_data_end - output)
                    {
                        result.error = LINK_ERROR_INVALID_INPUT;
                    }
                    u32 block_size = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        block_size = (u32)block_size_u64;
                        link_write_u32(bytes, output, page);
                        link_write_u32(bytes, output + 4, block_size);
                    }
                    u64 entry_output = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        entry_output = output + 8;
                        for (u32 relocation = index; relocation < end; relocation += 1)
                        {
                            u16 entry = (u16)((10u << 12) | (base_relocation_rvas[relocation] - page));
                            link_write_u16(bytes, entry_output, entry);
                            entry_output += sizeof(u16);
                        }
                        if (!link_u64_add(output, block_size, &output))
                        {
                            result.error = LINK_ERROR_INVALID_INPUT;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        index = end;
                    }
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                if (output != relocation_data_end)
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
    
        bytes[0] = 'M';
        bytes[1] = 'Z';
        link_write_u32(bytes, 0x3c, PE_OFFSET);
        memcpy(bytes + PE_OFFSET, "PE\0\0", 4);
    }
    u64 coff = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        coff = PE_OFFSET + 4;
        link_write_u16(bytes, coff, aarch64 ? 0xaa64 : 0x8664);
        link_write_u16(bytes, coff + 2, (u16)pe_section_count);
        link_write_u16(bytes, coff + 16, PE_OPTIONAL_HEADER_SIZE);
        link_write_u16(bytes, coff + 18, 0x22);
    }
    u64 optional = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        optional = coff + PE_COFF_HEADER_SIZE;
        link_write_u16(bytes, optional, 0x20b);
        bytes[optional + 2] = 14;
        link_write_u32(bytes, optional + 4, (u32)sections[PE_SECTION_TEXT].raw_size);
    }
    u64 initialized_data_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        initialized_data_size = 0;
        for (u32 section_kind = PE_SECTION_READ_ONLY_DATA; section_kind < PE_SECTION_KIND_COUNT && result.error == LINK_ERROR_NONE; section_kind += 1)
        {
            if (section_kind != PE_SECTION_ZERO && sections[section_kind].present)
            {
                if (!link_u64_add(initialized_data_size, sections[section_kind].raw_size, &initialized_data_size))
                {
                    result.error = LINK_ERROR_INVALID_INPUT;
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (initialized_data_size > UINT32_MAX || sections[PE_SECTION_ZERO].virtual_size > UINT32_MAX)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        link_write_u32(bytes, optional + 8, (u32)initialized_data_size);
        link_write_u32(bytes, optional + 12, (u32)sections[PE_SECTION_ZERO].virtual_size);
    }
    u64 entry_rva = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_rva = 0;
        if (!link_u64_add(sections[PE_SECTION_TEXT].virtual_address, object->symbols[entry_symbol_index].value, &entry_rva) ||
            entry_rva > UINT32_MAX)
        {
            result.error = LINK_ERROR_ENTRY_SYMBOL;
            result.symbol = entry_name;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        link_write_u32(bytes, optional + 16, (u32)entry_rva);
        link_write_u32(bytes, optional + 20, sections[PE_SECTION_TEXT].virtual_address);
        link_write_u64(bytes, optional + 24, image_base);
        link_write_u32(bytes, optional + 32, PE_SECTION_ALIGNMENT);
        link_write_u32(bytes, optional + 36, PE_FILE_ALIGNMENT);
        link_write_u16(bytes, optional + 40, 6);
        link_write_u16(bytes, optional + 48, 6);
        link_write_u32(bytes, optional + 56, (u32)image_size);
        link_write_u32(bytes, optional + 60, (u32)header_size);
        link_write_u16(bytes, optional + 68, 10);
        link_write_u16(bytes, optional + 70, 0x8160);
        // Stack/heap reserve+commit quads. Firmware provides the real stack, so
        // these are nominal; they are deliberately smaller than the hosted
        // writer's LINK_PE_* policy above.
        link_write_u64(bytes, optional + 72, 1024 * 1024);
        link_write_u64(bytes, optional + 80, 4096);
        link_write_u64(bytes, optional + 88, 1024 * 1024);
        link_write_u64(bytes, optional + 96, 4096);
        link_write_u32(bytes, optional + 108, 16);
        if (sections[PE_SECTION_PDATA].present)
        {
            link_write_u32(bytes, optional + 136, sections[PE_SECTION_PDATA].virtual_address);
            link_write_u32(bytes, optional + 140, (u32)sections[PE_SECTION_PDATA].virtual_size);
        }
        if (sections[PE_SECTION_RELOCATION].present)
        {
            link_write_u32(bytes, optional + 152, sections[PE_SECTION_RELOCATION].virtual_address);
            link_write_u32(bytes, optional + 156, (u32)sections[PE_SECTION_RELOCATION].virtual_size);
        }
        if (sections[PE_SECTION_DEBUG].present)
        {
            link_write_u32(bytes, optional + 160, sections[PE_SECTION_DEBUG].virtual_address);
            link_write_u32(bytes, optional + 164, 28);
        }
    }
    u64 section_header = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        section_header = optional + PE_OPTIONAL_HEADER_SIZE;
        for (u32 section_kind = 0; section_kind < PE_SECTION_KIND_COUNT; section_kind += 1)
        {
            LinkUefiPeSection* section = sections + section_kind;
            if (!section->present)
            {
                continue;
            }
            link_pe_section_header(bytes, section_header + (u64)section->output_index * PE_SECTION_HEADER_SIZE, section_header_names[section_kind],
                                   (u32)section->virtual_size, section->virtual_address, (u32)section->raw_size,
                                   section_kind == PE_SECTION_ZERO ? 0 : section->raw_offset, section->characteristics);
        }
    
        if (emit_debug)
        {
            PdbSection* pdb_sections = arena_allocate(arena, PdbSection, pe_section_count);
            for (u32 section_kind = 0; section_kind < PE_SECTION_KIND_COUNT; section_kind += 1)
            {
                LinkUefiPeSection* section = sections + section_kind;
                if (!section->present)
                {
                    continue;
                }
                pdb_sections[section->output_index] = (PdbSection){
                    .name = section_names[section_kind],
                    .virtual_address = section->virtual_address,
                    .virtual_size = (u32)section->virtual_size,
                    .raw_size = (u32)section->raw_size,
                    .raw_offset = section_kind == PE_SECTION_ZERO ? 0 : section->raw_offset,
                    .characteristics = section->characteristics,
                };
            }
            PdbModule* pdb_modules = arena_allocate(arena, PdbModule, object->debug_module_count);
            PdbContribution* pdb_contributions = arena_allocate(arena, PdbContribution, object->debug_module_count);
            u64 identity_size = base_file_size;
            for (u32 module_index = 0; module_index < object->debug_module_count && result.error == LINK_ERROR_NONE; module_index += 1)
            {
                ObjectDebugModule* source = object->debug_modules + module_index;
                ByteSlice symbols =
                    link_pe_resolved_codeview(arena, object, source, object_output_sections, object_section_offsets, pe_section_count);
                u64 module_identity_size = 0;
                if (!symbols.pointer || source->types_offset > object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.length ||
                    source->types_size > object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.length - source->types_offset ||
                    source->code_offset > UINT32_MAX || source->code_size > UINT32_MAX ||
                    (source->name.length && !source->name.pointer) || source->code_offset > sections[PE_SECTION_TEXT].virtual_size ||
                    source->code_size > sections[PE_SECTION_TEXT].virtual_size - source->code_offset ||
                    !link_u64_add(source->name.length, symbols.length, &module_identity_size) ||
                    !link_u64_add(module_identity_size, source->types_size, &module_identity_size) ||
                    !link_u64_add(module_identity_size, 8, &module_identity_size) ||
                    !link_u64_add(identity_size, module_identity_size, &identity_size))
                {
                    result.error = LINK_ERROR_OBJECT_WRITE;
                }
                u8*types = 0;
                if (result.error == LINK_ERROR_NONE)
                {
                    types = arena_allocate(arena, u8, source->types_size);
                    if (source->types_size)
                    {
                        memcpy(types, object->sections[OBJECT_SECTION_DEBUG_CODEVIEW_TYPES].data.pointer + source->types_offset, source->types_size);
                    }
                    pdb_modules[module_index] = (PdbModule){
                        .name = source->name,
                        .codeview_symbols = symbols,
                        .codeview_types = (ByteSlice){.pointer = types, .length = source->types_size},
                        .code_offset = (u32)source->code_offset,
                        .code_size = (u32)source->code_size,
                        .code_section = sections[PE_SECTION_TEXT].output_index + 1,
                        .contributions = pdb_contributions + module_index,
                        .contribution_count = source->code_size != 0,
                    };
                    pdb_contributions[module_index] = (PdbContribution){
                        .section = pdb_modules[module_index].code_section,
                        .offset = pdb_modules[module_index].code_offset,
                        .size = pdb_modules[module_index].code_size,
                    };
                }
            }
            u8*identity = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                identity = arena_allocate(arena, u8, identity_size);
                memcpy(identity, bytes, base_file_size);
            }
            u64 identity_cursor = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                identity_cursor = base_file_size;
                for (u32 module_index = 0; module_index < object->debug_module_count; module_index += 1)
                {
                    PdbModule* module = pdb_modules + module_index;
                    memcpy(identity + identity_cursor, module->name.pointer, module->name.length);
                    identity_cursor += module->name.length;
                    memcpy(identity + identity_cursor, module->codeview_symbols.pointer, module->codeview_symbols.length);
                    identity_cursor += module->codeview_symbols.length;
                    memcpy(identity + identity_cursor, module->codeview_types.pointer, module->codeview_types.length);
                    identity_cursor += module->codeview_types.length;
                    link_write_u32(identity, identity_cursor, module->code_offset);
                    identity_cursor += 4;
                    link_write_u32(identity, identity_cursor, module->code_size);
                    identity_cursor += 4;
                }
            }
            u8*digest = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                digest = arena_allocate(arena, u8, 32);
                memset(digest, 0, 32);
                link_sha256(arena, identity, identity_cursor, digest);
            }
            PdbInput pdb_input = {0};
            if (result.error == LINK_ERROR_NONE)
            {
                pdb_input = (PdbInput){
                    .sections = pdb_sections,
                    .section_count = pe_section_count,
                    .age = 1,
                    .machine = aarch64 ? 0xaa64 : 0x8664,
                    .modules = pdb_modules,
                    .module_count = object->debug_module_count,
                };
                memcpy(pdb_input.guid, digest, sizeof(pdb_input.guid));
            }
            PdbResult pdb = {0};
            if (result.error == LINK_ERROR_NONE)
            {
                pdb = pdb_build(arena, pdb_input);
                if (!pdb.valid)
                {
                    result.error = LINK_ERROR_OBJECT_WRITE;
                }
            }
            if (result.error == LINK_ERROR_NONE)
            {
                result.pdb = pdb.bytes;
                result.pdb_path = pdb_path;
            }
            u64 debug_raw = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                debug_raw = sections[PE_SECTION_DEBUG].raw_offset;
            }
            u64 rsds_size_u64 = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                rsds_size_u64 = 0;
                if (!link_u64_add(24 + 1, pdb_path.length, &rsds_size_u64) || rsds_size_u64 > UINT32_MAX ||
                    debug_raw > file_size || sections[PE_SECTION_DEBUG].virtual_size > file_size - debug_raw)
                {
                    result.error = LINK_ERROR_OBJECT_WRITE;
                }
            }
            u32 rsds_size = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                rsds_size = (u32)rsds_size_u64;
                link_write_u32(bytes, debug_raw + 12, 2);
                link_write_u32(bytes, debug_raw + 16, rsds_size);
                link_write_u32(bytes, debug_raw + 20, sections[PE_SECTION_DEBUG].virtual_address + 28);
                link_write_u32(bytes, debug_raw + 24, (u32)(debug_raw + 28));
                memcpy(bytes + debug_raw + 28, "RSDS", 4);
                memcpy(bytes + debug_raw + 32, pdb_input.guid, sizeof(pdb_input.guid));
                link_write_u32(bytes, debug_raw + 48, 1);
                memcpy(bytes + debug_raw + 52, pdb_path.pointer, pdb_path.length);
                bytes[debug_raw + 52 + pdb_path.length] = 0;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
        {
            result.error = LINK_ERROR_FILE_WRITE;
        }
        else if (emit_debug && options.output_path.length && !link_write_executable_file(result.pdb_path, result.pdb))
        {
            result.error = LINK_ERROR_FILE_WRITE;
        }
    }
    if (result.error != LINK_ERROR_NONE)
    {
        result.executable = (ByteSlice){0};
        result.pdb = (ByteSlice){0};
    }
    return result;
}


BUSTER_GLOBAL_LOCAL void link_mach_name_write(u8* bytes, u64 offset, char const* name)
{
    u64 length = strlen(name);
    memcpy(bytes + offset, name, BUSTER_MIN(length, 16));
}

BUSTER_GLOBAL_LOCAL u64 link_uleb128_write(u8* bytes, u64 offset, u64 value)
{
    do
    {
        u8 byte = (u8)(value & 0x7f);
        value >>= 7;
        if (value)
        {
            byte |= 0x80;
        }
        bytes[offset++] = byte;
    } while (value);
    return offset;
}

// The `align` field of a section command is the power of two, not the
// alignment itself.
BUSTER_GLOBAL_LOCAL u32 link_mach_alignment_power(u32 alignment)
{
    u32 result = 0;
    for (u32 remaining = alignment; remaining > 1; remaining >>= 1)
    {
        result += 1;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL void link_mach_section_write(u8* bytes, u64 offset, char const* section_name, char const* segment_name, u64 address, u64 size,
                                                 u32 file_offset, u32 alignment, u32 flags, u32 reserved1, u32 reserved2)
{
    link_mach_name_write(bytes, offset, section_name);
    link_mach_name_write(bytes, offset + 16, segment_name);
    link_write_u64(bytes, offset + 32, address);
    link_write_u64(bytes, offset + 40, size);
    link_write_u32(bytes, offset + 48, file_offset);
    link_write_u32(bytes, offset + 52, alignment);
    link_write_u32(bytes, offset + 64, flags);
    link_write_u32(bytes, offset + 68, reserved1);
    link_write_u32(bytes, offset + 72, reserved2);
}

// dyld runs a main executable's `__DATA,__mod_init_func` and does not run its
// `__mod_term_func`.  That was measured rather than assumed (issue 798): on
// macOS 26.3.2 a pointer placed by hand in a `__mod_term_func` of an image the
// *system* linker wrote never ran, while the `__mod_init_func` slot beside it
// did, and Clang emits no terminator array at all -- it registers every
// `__attribute__((destructor))` with `__cxa_atexit` from an initializer it
// synthesizes.  A terminator array is therefore storage nothing reads, and an
// image this writer produced dropped its destructors silently.
//
// So the terminator array comes off the object here, its entries are called
// from a runner this writer synthesizes, and one initializer slot prepended
// ahead of the program's own constructors registers that runner with
// `atexit`.  Registering it before any constructor runs is what leaves the
// walk behind every handler the program registers itself, which is the order
// `.fini_array` has on ELF, the order the two entry-stub writers already
// produce, and what tests/basic_c_destructor_exit.c pins.  Clang's own macOS
// shape does not have that property -- it registers each destructor as its
// initializer is reached, so a handler registered by a constructor runs after
// them -- and this writer follows GNU rather than that.
//
// The object is copied rather than edited, for the reason
// link_initializer_plan_build copies: a caller may link the same merged file
// twice.  `plan` keeps only destructors; the constructors stay in the section
// dyld already calls, so their slots, relocations and rebases are untouched
// beyond the eight bytes everything past the prepended slot moves by.
BUSTER_GLOBAL_LOCAL bool link_mach_initializer_prepare(Arena* arena, ObjectFile* object, ObjectFile* prepared, LinkInitializerPlan* plan,
                                                       u32* atexit_symbol_index)
{
    bool result = true;
    *prepared = *object;
    *plan = (LinkInitializerPlan){0};
    *atexit_symbol_index = UINT32_MAX;
    u64 terminator_length = object->sections[OBJECT_SECTION_FINI_ARRAY].data.length;
    u64 initializer_length = object->sections[OBJECT_SECTION_INIT_ARRAY].data.length;
    if (terminator_length)
    {
        u64 capacity = terminator_length / OBJECT_INITIALIZER_ENTRY_SIZE;
        if (capacity > UINT32_MAX || initializer_length > UINT64_MAX - OBJECT_INITIALIZER_ENTRY_SIZE || object->symbol_count == UINT32_MAX)
        {
            result = false;
        }
        else
        {
            plan->destructors = arena_allocate(arena, LinkInitializerEntry, capacity ? capacity : 1);
            plan->destructor_count = link_initializer_entries_collect(object, OBJECT_SECTION_FINI_ARRAY, plan->destructors, true);
            ObjectSection* sections = arena_allocate(arena, ObjectSection, object->section_count);
            memcpy(sections, object->sections, (u64)object->section_count * sizeof(*sections));
            sections[OBJECT_SECTION_FINI_ARRAY].data = (ByteSlice){0};
            sections[OBJECT_SECTION_FINI_ARRAY].virtual_size = 0;
            prepared->sections = sections;
            // The priorities are one u32 per slot of the section they
            // describe, and neither section is that shape any more: one is
            // gone and the other gains a slot no attribute named.  They have
            // already done their work by here -- link_initializer_arrays_order
            // sorted the merged arrays as `link_objects` finished -- so the
            // copy states that it records none rather than carrying a table
            // that no longer lines up with its section.
            prepared->initializer_priorities[0] = 0;
            prepared->initializer_priorities[1] = 0;
            if (plan->destructor_count)
            {
                // The prepended slot holds the registrar, whose address this
                // writer chooses at layout time; it carries no relocation and
                // is named directly in the rebase stream instead.
                u8* initializer_data = arena_allocate(arena, u8, initializer_length + OBJECT_INITIALIZER_ENTRY_SIZE);
                memset(initializer_data, 0, OBJECT_INITIALIZER_ENTRY_SIZE);
                if (initializer_length)
                {
                    memcpy(initializer_data + OBJECT_INITIALIZER_ENTRY_SIZE, object->sections[OBJECT_SECTION_INIT_ARRAY].data.pointer, initializer_length);
                }
                sections[OBJECT_SECTION_INIT_ARRAY].data = (ByteSlice){
                    .pointer = initializer_data,
                    .length = initializer_length + OBJECT_INITIALIZER_ENTRY_SIZE,
                };
                if (sections[OBJECT_SECTION_INIT_ARRAY].virtual_size)
                {
                    sections[OBJECT_SECTION_INIT_ARRAY].virtual_size += OBJECT_INITIALIZER_ENTRY_SIZE;
                }
                if (sections[OBJECT_SECTION_INIT_ARRAY].alignment < OBJECT_INITIALIZER_ENTRY_SIZE)
                {
                    sections[OBJECT_SECTION_INIT_ARRAY].alignment = OBJECT_INITIALIZER_ENTRY_SIZE;
                }
            }
            ObjectRelocation* relocations = arena_allocate(arena, ObjectRelocation, object->relocation_count ? object->relocation_count : 1);
            prepared->relocation_count = 0;
            for (u32 index = 0; index < object->relocation_count; index += 1)
            {
                ObjectRelocation relocation = object->relocations[index];
                if (relocation.section == OBJECT_SECTION_FINI_ARRAY)
                {
                    continue;
                }
                if (relocation.section == OBJECT_SECTION_INIT_ARRAY && plan->destructor_count)
                {
                    relocation.offset += OBJECT_INITIALIZER_ENTRY_SIZE;
                }
                relocations[prepared->relocation_count++] = relocation;
            }
            prepared->relocations = relocations;
        }
    }
    // Two things happen to the symbol table at once, and both only where a
    // slot was prepended.  A symbol *defined inside* the initializer array
    // moved with the slot ahead of it -- crtbegin's
    // `__frame_dummy_init_array_entry` is the one that exists in the wild --
    // so its value follows the entry it names.  And the runner is registered
    // with plain `atexit`, which libSystem exports and an image that never
    // called it itself still has to reach, so the name is appended when the
    // program does not already carry it.  A program that defines its own
    // `atexit` keeps that definition and the registrar calls it, exactly as
    // the ELF stub does with `exit`.
    if (result && plan->destructor_count)
    {
        u32 existing = link_symbol_find(prepared, S8("atexit"));
        u32 appended = existing == UINT32_MAX ? 1u : 0u;
        ObjectSymbol* symbols = arena_allocate(arena, ObjectSymbol, (u64)prepared->symbol_count + appended);
        if (prepared->symbol_count)
        {
            memcpy(symbols, prepared->symbols, sizeof(*symbols) * prepared->symbol_count);
        }
        for (u32 index = 0; index < prepared->symbol_count; index += 1)
        {
            if (symbols[index].section == OBJECT_SECTION_INIT_ARRAY)
            {
                symbols[index].value += OBJECT_INITIALIZER_ENTRY_SIZE;
            }
        }
        *atexit_symbol_index = existing;
        if (appended)
        {
            symbols[prepared->symbol_count] = (ObjectSymbol){
                .name = S8("atexit"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            };
            *atexit_symbol_index = prepared->symbol_count;
        }
        prepared->symbols = symbols;
        prepared->symbol_count += appended;
    }

    return result;
}

// The registrar and the runner, in one blob laid down past the import stubs.
// The registrar is what the prepended `__mod_init_func` slot points at: it
// hands the runner to `atexit` and returns, so dyld's own call site is where
// the registration happens.  The runner past it calls one destructor after
// another in the order the plan already holds them -- `__mod_term_func` runs
// backwards, and the plan reversed the entries as it collected them -- and
// returns to whatever the C runtime called it from.  Every call is laid down
// as a bare rel32 whose field offset is reported, because the addresses on
// both ends are only known once the image is laid out.
BUSTER_GLOBAL_LOCAL u32 link_x86_mach_destructor_runner_capacity(u32 destructor_count)
{
    return 32 + 5 * destructor_count;
}

BUSTER_GLOBAL_LOCAL bool link_x86_build_mach_destructor_runner(u8* bytes, u32 capacity, u32* byte_count, u32* atexit_displacement_offset,
                                                               u32* destructor_displacement_offsets, u32 destructor_count)
{
    LinkX86InstructionBuilder builder = {.bytes = bytes, .capacity = capacity};
    BusterX86MetadataPhysicalOperand operands[2] = {0};
    // The call dyld made left the stack eight bytes short of a sixteen-byte
    // boundary, which is what this reserve puts back before the call to
    // `atexit`; the runner below opens the same way for the same reason.
    operands[0] = link_x86_register(4, 64);
    operands[1] = link_x86_immediate(8, 8);
    if (!link_x86_emit(&builder, S8("SUB"), operands, 2)) return false;
    operands[0] = link_x86_register(7, 64);
    operands[1] = link_x86_memory_rip(64, 0);
    if (!link_x86_emit(&builder, S8("LEA"), operands, 2) || builder.count < 4) return false;
    u32 runner_displacement_field = builder.count - 4;
    if (atexit_displacement_offset) *atexit_displacement_offset = builder.count + 1;
    operands[0] = link_x86_relative(0, 32);
    if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    operands[0] = link_x86_register(4, 64);
    operands[1] = link_x86_immediate(8, 8);
    if (!link_x86_emit(&builder, S8("ADD"), operands, 2)) return false;
    if (!link_x86_emit_zero(&builder, S8("RET"))) return false;
    link_write_u32(builder.bytes, runner_displacement_field, (u32)(builder.count - (runner_displacement_field + 4)));
    operands[0] = link_x86_register(4, 64);
    operands[1] = link_x86_immediate(8, 8);
    if (!link_x86_emit(&builder, S8("SUB"), operands, 2)) return false;
    for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
    {
        if (destructor_displacement_offsets) destructor_displacement_offsets[destructor] = builder.count + 1;
        operands[0] = link_x86_relative(0, 32);
        if (!link_x86_emit(&builder, S8("CALL"), operands, 1)) return false;
    }
    operands[0] = link_x86_register(4, 64);
    operands[1] = link_x86_immediate(8, 8);
    if (!link_x86_emit(&builder, S8("ADD"), operands, 2)) return false;
    if (!link_x86_emit_zero(&builder, S8("RET"))) return false;
    if (byte_count) *byte_count = builder.count;

    return true;
}

// The AArch64 spelling of the same blob, in whole words: a frame, the ADR
// that names the runner, the registration, a return, and then the runner's
// own frame, one `bl` per destructor, and its return.  The ADR reaches the
// runner from inside this same buffer, so its displacement is known before
// the image has an address.
BUSTER_GLOBAL_LOCAL u32 link_aarch64_mach_destructor_runner_words(u32 destructor_count)
{
    return 10 + destructor_count;
}

BUSTER_GLOBAL_LOCAL u32 link_aarch64_build_mach_destructor_runner(u32* words, u32 capacity, u32* atexit_word, u32* destructor_words, u32 destructor_count)
{
    u32 count = 0;
    bool valid = true;
    if (capacity >= link_aarch64_mach_destructor_runner_words(destructor_count))
    {
        words[count++] = 0xa9bf7bfdu;
        words[count++] = 0x910003fdu;
        u32 runner_adr_word = count;
        words[count++] = 0;
        if (atexit_word) *atexit_word = count;
        words[count++] = 0x94000000u;
        words[count++] = 0xa8c17bfdu;
        words[count++] = 0xd65f03c0u;
        words[runner_adr_word] = link_aarch64_adr(0, ((s64)count - (s64)runner_adr_word) * (s64)sizeof(u32), &valid);
        words[count++] = 0xa9bf7bfdu;
        words[count++] = 0x910003fdu;
        for (u32 destructor = 0; destructor < destructor_count; destructor += 1)
        {
            if (destructor_words) destructor_words[destructor] = count;
            words[count++] = 0x94000000u;
        }
        words[count++] = 0xa8c17bfdu;
        words[count++] = 0xd65f03c0u;
        if (!valid)
        {
            count = 0;
        }
    }

    return count;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_mach_o64(Arena* arena, ObjectFile* object, NativeExecutableLinkOptions options)
{
    NativeExecutableLinkResult result = {0};
    enum
    {
        MACH_HEADER_SIZE = 32,
        MACH_SEGMENT_COMMAND_SIZE = 72,
        MACH_SECTION_SIZE = 80,
        MACH_DYLD_INFO_COMMAND_SIZE = 48,
        MACH_DYLINKER_COMMAND_SIZE = 32,
        MACH_DYLIB_COMMAND_SIZE = 56,
        MACH_MAIN_COMMAND_SIZE = 24,
        MACH_BUILD_VERSION_COMMAND_SIZE = 24,
        MACH_SYMTAB_COMMAND_SIZE = 24,
        MACH_DYSYMTAB_COMMAND_SIZE = 80,
        MACH_UUID_COMMAND_SIZE = 24,
        MACH_CODE_SIGNATURE_COMMAND_SIZE = 16,
        MACH_BASE_COMMAND_COUNT = 13,
        MACH_PAGE_SIZE = 0x4000,
        MACH_CODE_PAGE_SIZE = 0x1000,
        MACH_CODE_DIRECTORY_HEADER_SIZE = 48,
        MACH_CODE_DIRECTORY_IDENTIFIER_SIZE = 7,
        MACH_NLIST_SIZE = 16,
        MACH_STUB_X86_64_SIZE = 6,
        MACH_STUB_AARCH64_SIZE = 16,
    };
    static char8 const dyld_path[] = "/usr/lib/dyld";
    static char8 const system_path[] = "/usr/lib/libSystem.B.dylib";
    if ((options.dynamic_library_count && !options.dynamic_libraries) || object->section_count < OBJECT_SECTION_COUNT || !object->sections ||
        (object->symbol_count && !object->symbols) || (object->relocation_count && !object->relocations) ||
        (object->target.cpu_arch != CPU_ARCH_X86_64 && object->target.cpu_arch != CPU_ARCH_AARCH64))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
    }
    // LC_MAIN hands `main` straight to dyld, so this writer has no entry stub
    // of its own to call constructors from -- and needs none: dyld runs the
    // main executable's `__DATA,__mod_init_func` before it enters `main`, so
    // that array keeps its section command and the type dyld dispatches on
    // instead of being taken off the object the way the entry-stub writers
    // take it (issue 779).  Its `__mod_term_func` is the half dyld does not
    // run, so link_mach_initializer_prepare takes *that* array off, prepends
    // the slot whose registrar hands a synthesized runner to `atexit`, and
    // leaves the constructors where they were (issue 798).  See
    // link_initializer_plan_empty for the writers that still refuse.
    ObjectFile prepared_object = {0};
    LinkInitializerPlan plan = {0};
    u32 atexit_symbol_index = UINT32_MAX;
    if (result.error == LINK_ERROR_NONE)
    {
        if (link_mach_initializer_prepare(arena, object, &prepared_object, &plan, &atexit_symbol_index))
        {
            object = &prepared_object;
        }
        else
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    bool has_initializer_array = false;
    if (result.error == LINK_ERROR_NONE)
    {
        has_initializer_array = object->sections[OBJECT_SECTION_INIT_ARRAY].data.length != 0;
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (object->target.cpu_arch == CPU_ARCH_X86_64)
        {
            buster_x86_metadata_prewarm();
        }
    }
    u32 import_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_count = 0;
    }
    u64 import_name_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_name_size = 0;
    }
    u32 thread_local_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        thread_local_count = 0;
    }
    u32 bootstrap_symbol_index = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        bootstrap_symbol_index = UINT32_MAX;
    }
    u32*import_indices = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        import_indices = arena_allocate(arena, u32, object->symbol_count);
    }
    u32*thread_local_indices = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        thread_local_indices = arena_allocate(arena, u32, object->symbol_count);
        for (u32 symbol_index = 0; symbol_index < object->symbol_count && result.error == LINK_ERROR_NONE; symbol_index += 1)
        {
            import_indices[symbol_index] = UINT32_MAX;
            thread_local_indices[symbol_index] = UINT32_MAX;
            ObjectSymbol* symbol = &object->symbols[symbol_index];
            if (symbol->section != OBJECT_SECTION_UNDEFINED)
            {
                if (symbol->section < object->section_count && (object->sections[symbol->section].kind == OBJECT_SECTION_THREAD_LOCAL_DATA ||
                                                                object->sections[symbol->section].kind == OBJECT_SECTION_THREAD_LOCAL_ZERO))
                {
                    thread_local_indices[symbol_index] = thread_local_count++;
                }
                continue;
            }
            if (!symbol->global || symbol->kind != OBJECT_SYMBOL_FUNCTION || !symbol->name.length)
            {
                result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
                result.symbol = symbol->name;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                import_indices[symbol_index] = import_count++;
                if (string_equal(symbol->name, S8("_tlv_bootstrap")))
                {
                    bootstrap_symbol_index = symbol_index;
                }
                import_name_size += symbol->name.length + 2;
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (thread_local_count && bootstrap_symbol_index == UINT32_MAX)
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = S8("_tlv_bootstrap");
        }
    }
    String8 entry_name = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        entry_name = options.entry_symbol.length ? options.entry_symbol : S8("main");
    }
    u32 entry_symbol_index = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_symbol_index = link_symbol_find(object, entry_name);
        if (entry_symbol_index == UINT32_MAX || object->symbols[entry_symbol_index].section == OBJECT_SECTION_UNDEFINED ||
            object->symbols[entry_symbol_index].kind != OBJECT_SYMBOL_FUNCTION)
        {
            result.error = LINK_ERROR_ENTRY_SYMBOL;
            result.symbol = entry_name;
        }
    }
    u32 initializer_section_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        initializer_section_count = has_initializer_array ? 1u : 0u;
    }
    u32 data_section_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_section_count = 4u + (thread_local_count ? 3u : 0u) + initializer_section_count;
    }
    u64 data_command_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_command_size = MACH_SEGMENT_COMMAND_SIZE + (u64)data_section_count * MACH_SECTION_SIZE;
    }
    bool has_unwind = false;
    if (result.error == LINK_ERROR_NONE)
    {
        has_unwind = object->sections[OBJECT_SECTION_UNWIND].data.length != 0;
    }
    u64 text_command_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        text_command_size = MACH_SEGMENT_COMMAND_SIZE + (has_unwind ? 2 : 1) * MACH_SECTION_SIZE;
    }
    // Debug sections travel in their own read-only __DWARF segment.  The
    // segment is file-backed and page-rounded (rather than unmapped), which
    // keeps the image acceptable to dyld while retaining the section names
    // that source debuggers expect.
    static ObjectSectionKind const dwarf_kinds[] = {
        OBJECT_SECTION_DEBUG_INFO,
        OBJECT_SECTION_DEBUG_ABBREV,
        OBJECT_SECTION_DEBUG_LINE,
        OBJECT_SECTION_DEBUG_STR,
        OBJECT_SECTION_DEBUG_LOC,
        OBJECT_SECTION_DEBUG_RANGES,
    };
    static char const* const dwarf_section_names[] = {
        "__debug_info",
        "__debug_abbrev",
        "__debug_line",
        "__debug_str",
        "__debug_loc",
        "__debug_ranges",
    };
    u64 dwarf_total = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_total = 0;
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(dwarf_kinds); index += 1)
        {
            dwarf_total += object->sections[dwarf_kinds[index]].data.length;
        }
    }
    bool has_dwarf = false;
    if (result.error == LINK_ERROR_NONE)
    {
        has_dwarf = dwarf_total != 0;
    }
    u64 dwarf_command_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_command_size = has_dwarf ? MACH_SEGMENT_COMMAND_SIZE + BUSTER_ARRAY_LENGTH(dwarf_kinds) * MACH_SECTION_SIZE : 0;
    }
    u64 extra_dylib_command_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        extra_dylib_command_size = 0;
        for (u32 library_index = 0; library_index < options.dynamic_library_count && result.error == LINK_ERROR_NONE; library_index += 1)
        {
            String8 library = options.dynamic_libraries[library_index].name;
            if (!library.length || library.length > UINT32_MAX - 25)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                extra_dylib_command_size += align_forward(24 + library.length + 1, 8);
            }
        }
    }
    u64 command_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        command_size = 2 * MACH_SEGMENT_COMMAND_SIZE + text_command_size + data_command_size + dwarf_command_size + MACH_DYLD_INFO_COMMAND_SIZE +
                           MACH_DYLINKER_COMMAND_SIZE + MACH_DYLIB_COMMAND_SIZE + extra_dylib_command_size + MACH_MAIN_COMMAND_SIZE +
                           MACH_BUILD_VERSION_COMMAND_SIZE + MACH_SYMTAB_COMMAND_SIZE + MACH_DYSYMTAB_COMMAND_SIZE + MACH_UUID_COMMAND_SIZE +
                           MACH_CODE_SIGNATURE_COMMAND_SIZE;
    }
    u64 header_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        header_end = MACH_HEADER_SIZE + command_size;
    }
    u64 section_offsets[OBJECT_SECTION_COUNT] = {0};
    if (result.error == LINK_ERROR_NONE)
    {
        section_offsets[OBJECT_SECTION_TEXT] = align_forward(header_end, object->sections[OBJECT_SECTION_TEXT].alignment);
    }
    u32 stub_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        stub_size = object->target.cpu_arch == CPU_ARCH_X86_64 ? MACH_STUB_X86_64_SIZE : MACH_STUB_AARCH64_SIZE;
    }
    u64 stub_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        stub_offset = align_forward(section_offsets[OBJECT_SECTION_TEXT] + object->sections[OBJECT_SECTION_TEXT].data.length, 16);
    }
    u64 stub_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        stub_end = stub_offset + (u64)import_count * stub_size;
    }
    // The registrar and the runner follow the import stubs: the same
    // executable segment, past the last thing in it, and outside any section
    // command, which is where the stubs already sit.  Both are laid down
    // before the image has an address and patched once it has one, so the
    // shape is built here and only its displacements wait.
    u8* runner_bytes = 0;
    u32 runner_size = 0;
    u32 runner_atexit_field = 0;
    u32* runner_destructor_fields = 0;
    if (result.error == LINK_ERROR_NONE && plan.destructor_count)
    {
        runner_destructor_fields = arena_allocate(arena, u32, plan.destructor_count);
        if (object->target.cpu_arch == CPU_ARCH_X86_64)
        {
            u32 capacity = link_x86_mach_destructor_runner_capacity(plan.destructor_count);
            runner_bytes = arena_allocate(arena, u8, capacity);
            if (!link_x86_build_mach_destructor_runner(runner_bytes, capacity, &runner_size, &runner_atexit_field, runner_destructor_fields,
                                                       plan.destructor_count))
            {
                result.error = LINK_ERROR_RELOCATION;
            }
        }
        else
        {
            u32 capacity = link_aarch64_mach_destructor_runner_words(plan.destructor_count);
            u32* runner_words = arena_allocate(arena, u32, capacity);
            u32 word_count = link_aarch64_build_mach_destructor_runner(runner_words, capacity, &runner_atexit_field, runner_destructor_fields,
                                                                      plan.destructor_count);
            runner_bytes = (u8*)runner_words;
            runner_size = word_count * (u32)sizeof(u32);
            if (!word_count)
            {
                result.error = LINK_ERROR_RELOCATION;
            }
        }
    }
    u64 runner_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        runner_offset = runner_size ? align_forward(stub_end, 16) : stub_end;
    }
    u64 code_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        code_end = runner_offset + runner_size;
        section_offsets[OBJECT_SECTION_UNWIND] = has_unwind ? align_forward(code_end, object->sections[OBJECT_SECTION_UNWIND].alignment) : code_end;
    }
    u64 text_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        text_end = has_unwind ? section_offsets[OBJECT_SECTION_UNWIND] + object->sections[OBJECT_SECTION_UNWIND].data.length : code_end;
    }
    u64 data_file_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_file_offset = align_forward(text_end, MACH_PAGE_SIZE);
        section_offsets[OBJECT_SECTION_DATA] = data_file_offset;
        // The two initializer arrays sit beside __data in __DATA: dyld walks
        // them out of a writable segment and rebases every entry there, and a
        // section this writer laid out nowhere would be copied over the image
        // header at offset zero.
        section_offsets[OBJECT_SECTION_INIT_ARRAY] =
            align_forward(section_offsets[OBJECT_SECTION_DATA] + object->sections[OBJECT_SECTION_DATA].data.length,
                          object->sections[OBJECT_SECTION_INIT_ARRAY].alignment);
        section_offsets[OBJECT_SECTION_FINI_ARRAY] =
            align_forward(section_offsets[OBJECT_SECTION_INIT_ARRAY] + object->sections[OBJECT_SECTION_INIT_ARRAY].data.length,
                          object->sections[OBJECT_SECTION_FINI_ARRAY].alignment);
        section_offsets[OBJECT_SECTION_READ_ONLY_DATA] =
            align_forward(section_offsets[OBJECT_SECTION_FINI_ARRAY] + object->sections[OBJECT_SECTION_FINI_ARRAY].data.length,
                          object->sections[OBJECT_SECTION_READ_ONLY_DATA].alignment);
    }
    u64 got_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        got_offset = align_forward(section_offsets[OBJECT_SECTION_READ_ONLY_DATA] + object->sections[OBJECT_SECTION_READ_ONLY_DATA].data.length, 8);
    }
    u64 got_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        got_count = (u64)import_count + thread_local_count;
    }
    u64 thread_local_variables_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        thread_local_variables_offset = align_forward(got_offset + got_count * sizeof(u64), 8);
    }
    u64 thread_local_variables_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        thread_local_variables_size = (u64)thread_local_count * 3 * sizeof(u64);
        section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] =
            align_forward(thread_local_variables_offset + thread_local_variables_size, object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].alignment);
    }
    u64 data_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_end = section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] + object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length;
        section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO] = align_forward(data_end, object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment);
    }
    u64 thread_local_vm_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        thread_local_vm_end = section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO] + object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size;
        section_offsets[OBJECT_SECTION_ZERO] = align_forward(thread_local_vm_end, object->sections[OBJECT_SECTION_ZERO].alignment);
    }
    u64 data_vm_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_vm_end = section_offsets[OBJECT_SECTION_ZERO] + object->sections[OBJECT_SECTION_ZERO].virtual_size;
    }
    // The kernel loader rejects an image whose segments are not page aligned
    // in the file. Zero-fill storage advances the virtual layout without
    // consuming file bytes, so later segments need distinct file and virtual
    // offsets.
    u64 data_file_end = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_file_end = BUSTER_MAX(data_end, data_file_offset + 1);
    }
    u64 dwarf_file_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_file_offset = align_forward(data_file_end, MACH_PAGE_SIZE);
    }
    u64 dwarf_vm_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_vm_offset = align_forward(BUSTER_MAX(data_vm_end, data_file_offset + 1), MACH_PAGE_SIZE);
    }
    u64*dwarf_file_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_file_offsets = arena_allocate(arena, u64, BUSTER_ARRAY_LENGTH(dwarf_kinds));
    }
    u64*dwarf_vm_offsets = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_vm_offsets = arena_allocate(arena, u64, BUSTER_ARRAY_LENGTH(dwarf_kinds));
    }
    u64 dwarf_file_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_file_cursor = dwarf_file_offset;
    }
    u64 dwarf_vm_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        dwarf_vm_cursor = dwarf_vm_offset;
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(dwarf_kinds); index += 1)
        {
            dwarf_file_offsets[index] = dwarf_file_cursor;
            dwarf_vm_offsets[index] = dwarf_vm_cursor;
            dwarf_file_cursor += object->sections[dwarf_kinds[index]].data.length;
            dwarf_vm_cursor += object->sections[dwarf_kinds[index]].data.length;
        }
    }
    u64 linkedit_file_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        linkedit_file_offset = align_forward(has_dwarf ? dwarf_file_cursor : data_file_end, MACH_PAGE_SIZE);
    }
    u64 linkedit_vm_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        linkedit_vm_offset = align_forward(has_dwarf ? dwarf_vm_cursor : BUSTER_MAX(data_vm_end, data_file_offset + 1), MACH_PAGE_SIZE);
    }
    u32 rebase_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        rebase_count = 0;
        for (u32 relocation_index = 0; relocation_index < object->relocation_count; relocation_index += 1)
        {
            ObjectRelocation relocation = object->relocations[relocation_index];
            if (relocation.section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation.section))
            {
                continue;
            }
            if (relocation.kind == OBJECT_RELOCATION_ABSOLUTE64 && !(object->target.cpu_arch == CPU_ARCH_AARCH64 && relocation.section == OBJECT_SECTION_TEXT))
            {
                rebase_count += 1;
            }
        }
        rebase_count += thread_local_count * 2;
        // The prepended initializer slot has no relocation to be counted from.
        rebase_count += plan.destructor_count ? 1u : 0u;
    }
    u64 rebase_capacity = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        rebase_capacity = rebase_count ? 2 + (u64)rebase_count * 12 : 0;
    }
    u8*rebase_bytes = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        rebase_bytes = arena_allocate(arena, u8, rebase_capacity);
    }
    u64 rebase_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        rebase_size = 0;
        if (rebase_count)
        {
            rebase_bytes[rebase_size++] = 0x11;
            for (u32 relocation_index = 0; relocation_index < object->relocation_count && result.error == LINK_ERROR_NONE; relocation_index += 1)
            {
                ObjectRelocation* relocation = &object->relocations[relocation_index];
                if (relocation->kind != OBJECT_RELOCATION_ABSOLUTE64 || (object->target.cpu_arch == CPU_ARCH_AARCH64 && relocation->section == OBJECT_SECTION_TEXT) ||
                    (relocation->section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation->section)))
                {
                    continue;
                }
                if (relocation->section >= OBJECT_SECTION_COUNT)
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
                u8 segment_index = 0;
                if (result.error == LINK_ERROR_NONE)
                {
                    segment_index = relocation->section == OBJECT_SECTION_DATA || relocation->section == OBJECT_SECTION_ZERO ||
                                               relocation->section == OBJECT_SECTION_READ_ONLY_DATA ||
                                               relocation->section == OBJECT_SECTION_INIT_ARRAY || relocation->section == OBJECT_SECTION_FINI_ARRAY ||
                                               relocation->section == OBJECT_SECTION_THREAD_LOCAL_DATA || relocation->section == OBJECT_SECTION_THREAD_LOCAL_ZERO
                                           ? 2
                                           : 1;
                }
                u64 segment_offset = 0;
                if (result.error == LINK_ERROR_NONE)
                {
                    segment_offset = segment_index == 2 ? section_offsets[relocation->section] + relocation->offset - data_file_offset
                                                            : section_offsets[relocation->section] + relocation->offset;
                    rebase_bytes[rebase_size++] = (u8)(0x20 | segment_index);
                    rebase_size = link_uleb128_write(rebase_bytes, rebase_size, segment_offset);
                    rebase_bytes[rebase_size++] = 0x51;
                }
            }
            if (result.error == LINK_ERROR_NONE && plan.destructor_count)
            {
                // A slot dyld does not rebase holds a stale address in every
                // process that loads at a slide, and this one holds the
                // registrar the whole destructor walk hangs off.
                rebase_bytes[rebase_size++] = 0x22;
                rebase_size = link_uleb128_write(rebase_bytes, rebase_size, section_offsets[OBJECT_SECTION_INIT_ARRAY] - data_file_offset);
                rebase_bytes[rebase_size++] = 0x51;
            }
            if (result.error == LINK_ERROR_NONE)
            {
                for (u32 thread_local_index = 0; thread_local_index < thread_local_count; thread_local_index += 1)
                {
                    u64 pointer_offset = got_offset + ((u64)import_count + thread_local_index) * sizeof(u64);
                    u64 descriptor_offset = thread_local_variables_offset + (u64)thread_local_index * 3 * sizeof(u64);
                    u64 locations[] = {
                        pointer_offset,
                        descriptor_offset,
                    };
                    for (u32 location_index = 0; location_index < BUSTER_ARRAY_LENGTH(locations); location_index += 1)
                    {
                        rebase_bytes[rebase_size++] = 0x22;
                        rebase_size = link_uleb128_write(rebase_bytes, rebase_size, locations[location_index] - data_file_offset);
                        rebase_bytes[rebase_size++] = 0x51;
                    }
                }
                rebase_bytes[rebase_size++] = 0;
            }
        }
    }
    u64 bind_capacity = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        bind_capacity = import_name_size + (u64)import_count * 20 + 4;
    }
    u8*bind_bytes = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        bind_bytes = arena_allocate(arena, u8, bind_capacity);
    }
    u64 bind_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        bind_size = 0;
        if (import_count)
        {
            bind_bytes[bind_size++] = options.dynamic_library_count ? 0x3e : 0x11;
            bind_bytes[bind_size++] = 0x51;
            bind_bytes[bind_size++] = 0x72;
            bind_size = link_uleb128_write(bind_bytes, bind_size, got_offset - data_file_offset);
            for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
            {
                if (import_indices[symbol_index] == UINT32_MAX)
                {
                    continue;
                }
                ObjectSymbol* symbol = &object->symbols[symbol_index];
                bind_bytes[bind_size++] = 0x40;
                bind_bytes[bind_size++] = '_';
                memcpy(bind_bytes + bind_size, symbol->name.pointer, symbol->name.length);
                bind_size += symbol->name.length;
                bind_bytes[bind_size++] = 0;
                bind_bytes[bind_size++] = 0x90;
            }
            bind_bytes[bind_size++] = 0;
        }
    }
    u64 bind_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        // Every __LINKEDIT blob has to start on an eight-byte boundary: dyld's
        // layout check refuses the whole image with "mis-aligned LINKEDIT
        // content" otherwise, and the rebase stream ahead of this one is
        // however many uleb128 bytes it happened to need.  The gap bytes are
        // already zero, and each blob carries its own size, so the padding is
        // read by nothing.
        bind_offset = align_forward(linkedit_file_offset + rebase_size, 8);
    }
    u64 symbol_table_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        symbol_table_offset = align_forward(bind_offset + bind_size, 8);
    }
    u64 symbol_table_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        symbol_table_size = (u64)import_count * MACH_NLIST_SIZE;
    }
    u64 string_table_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        string_table_offset = symbol_table_offset + symbol_table_size;
    }
    u64 string_table_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        string_table_size = 1 + import_name_size;
    }
    u64 unsigned_file_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        unsigned_file_size = string_table_offset + string_table_size;
    }
    u64 signature_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        signature_offset = align_forward(unsigned_file_size, 16);
    }
    u64 code_slot_count = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        code_slot_count = (signature_offset + MACH_CODE_PAGE_SIZE - 1) / MACH_CODE_PAGE_SIZE;
    }
    u64 code_directory_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        code_directory_size = MACH_CODE_DIRECTORY_HEADER_SIZE + MACH_CODE_DIRECTORY_IDENTIFIER_SIZE + code_slot_count * 32;
    }
    u64 signature_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        signature_size = 20 + code_directory_size;
    }
    u64 file_size = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        file_size = signature_offset + signature_size;
        if (file_size > UINT32_MAX)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        result.executable = (ByteSlice){
            .pointer = arena_allocate(arena, u8, file_size),
            .length = file_size,
        };
    }
    u8*bytes = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        bytes = result.executable.pointer;
        memset(bytes, 0, file_size);
        for (u32 section = 0; section < OBJECT_SECTION_COUNT; section += 1)
        {
            if (object_section_kind_is_debug((ObjectSectionKind)section))
            {
                continue;
            }
            ByteSlice data = object->sections[section].data;
            if (data.length)
            {
                memcpy(bytes + section_offsets[section], data.pointer, data.length);
            }
        }
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(dwarf_kinds); index += 1)
        {
            ByteSlice data = object->sections[dwarf_kinds[index]].data;
            if (data.length)
            {
                memcpy(bytes + dwarf_file_offsets[index], data.pointer, data.length);
            }
        }
        if (rebase_size)
        {
            memcpy(bytes + linkedit_file_offset, rebase_bytes, rebase_size);
        }
        if (bind_size)
        {
            memcpy(bytes + bind_offset, bind_bytes, bind_size);
        }
    }
    u64 image_base = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        image_base = UINT64_C(0x100000000);
    }
    u64 text_vm_address = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        text_vm_address = image_base;
    }
    u64 data_vm_address = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        data_vm_address = image_base + data_file_offset;
    }
    u64 string_cursor = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        string_cursor = string_table_offset + 1;
    }
    u32 string_index = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        string_index = 1;
    }
    bool valid = false;
    if (result.error == LINK_ERROR_NONE)
    {
        valid = true;
        for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
        {
            u32 import_index = import_indices[symbol_index];
            if (import_index == UINT32_MAX)
            {
                continue;
            }
            ObjectSymbol* symbol = &object->symbols[symbol_index];
            u64 nlist = symbol_table_offset + (u64)import_index * MACH_NLIST_SIZE;
            link_write_u32(bytes, nlist, string_index);
            bytes[nlist + 4] = 0x01;
            link_write_u16(bytes, nlist + 6, 0x0100);
            bytes[string_cursor++] = '_';
            memcpy(bytes + string_cursor, symbol->name.pointer, symbol->name.length);
            string_cursor += symbol->name.length + 1;
            string_index += (u32)symbol->name.length + 2;
            u64 slot_address = data_vm_address + (got_offset - data_file_offset) + (u64)import_index * sizeof(u64);
            u64 current_stub_offset = stub_offset + (u64)import_index * stub_size;
            u64 stub_address = text_vm_address + current_stub_offset;
            if (object->target.cpu_arch == CPU_ARCH_X86_64)
            {
                s64 displacement = (s64)slot_address - (s64)(stub_address + 6);
                if (displacement < INT32_MIN || displacement > INT32_MAX)
                {
                    valid = false;
                    break;
                }
                LinkX86InstructionBuilder stub_builder = {.bytes = bytes + current_stub_offset, .capacity = 6};
                BusterX86MetadataPhysicalOperand stub_memory = link_x86_memory_rip(64, 0);
                if (!link_x86_emit(&stub_builder, S8("JMP"), &stub_memory, 1) || stub_builder.count != 6)
                {
                    valid = false;
                    break;
                }
                link_write_u32(bytes, current_stub_offset + 2, (u32)(s32)displacement);
            }
            else
            {
                u64 page_offset = slot_address & 0xfff;
                if (page_offset % 8)
                {
                    valid = false;
                    break;
                }
                link_write_u32(bytes, current_stub_offset, link_aarch64_adrp(16, stub_address, slot_address, &valid));
                link_write_u32(bytes, current_stub_offset + 4, 0xf9400000 | ((u32)(page_offset / 8) << 10) | (16 << 5) | 17);
                link_write_u32(bytes, current_stub_offset + 8, 0xd61f0220);
                link_write_u32(bytes, current_stub_offset + 12, 0xd503201f);
            }
        }
        if (!valid)
        {
            result.error = LINK_ERROR_RELOCATION;
        }
    }
    // The registrar's own call reaches `atexit` the way any call to the C
    // runtime does here: through the import stub laid down above, or straight
    // to the program's definition where it has one.
    u64 atexit_address = 0;
    if (result.error == LINK_ERROR_NONE && runner_size)
    {
        ObjectSymbol* atexit_symbol = &object->symbols[atexit_symbol_index];
        if (atexit_symbol->section == OBJECT_SECTION_UNDEFINED)
        {
            u32 atexit_import_index = import_indices[atexit_symbol_index];
            if (atexit_import_index == UINT32_MAX)
            {
                result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
                result.symbol = atexit_symbol->name;
            }
            else
            {
                atexit_address = text_vm_address + stub_offset + (u64)atexit_import_index * stub_size;
            }
        }
        else if (atexit_symbol->section < OBJECT_SECTION_COUNT)
        {
            atexit_address = image_base + section_offsets[atexit_symbol->section] + atexit_symbol->value;
        }
        else
        {
            result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
            result.symbol = atexit_symbol->name;
        }
    }
    if (result.error == LINK_ERROR_NONE && runner_size)
    {
        memcpy(bytes + runner_offset, runner_bytes, runner_size);
        bool patched = false;
        if (object->target.cpu_arch == CPU_ARCH_X86_64)
        {
            u64 field = runner_offset + runner_atexit_field;
            s64 displacement = (s64)atexit_address - (s64)(image_base + field + 4);
            patched = displacement >= INT32_MIN && displacement <= INT32_MAX;
            if (patched)
            {
                link_write_u32(bytes, field, (u32)(s32)displacement);
            }
            patched = patched && link_x86_patch_initializer_calls(bytes, object, &plan, section_offsets, image_base, runner_offset, runner_destructor_fields);
        }
        else
        {
            u64 offset = runner_offset + (u64)runner_atexit_field * sizeof(u32);
            u32 instruction = 0;
            patched = link_aarch64_branch_encode(A64_OPCODE_BL, (s64)atexit_address - (s64)(image_base + offset), &instruction);
            if (patched)
            {
                link_write_u32(bytes, offset, instruction);
            }
            patched =
                patched && link_aarch64_patch_initializer_calls(bytes, object, &plan, section_offsets, image_base, runner_offset, runner_destructor_fields);
        }
        // The slot link_mach_initializer_prepare prepended, which is the one
        // dyld reaches first and therefore the registration that lands behind
        // every handler the program registers itself.  It carries no
        // relocation, so its value is written here and its address is named
        // directly in the rebase stream.
        if (patched)
        {
            link_write_u64(bytes, section_offsets[OBJECT_SECTION_INIT_ARRAY], image_base + runner_offset);
        }
        else
        {
            result.error = LINK_ERROR_RELOCATION;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        if (thread_local_count)
        {
            u32 bootstrap_import_index = import_indices[bootstrap_symbol_index];
            if (bootstrap_import_index == UINT32_MAX)
            {
                result.error = LINK_ERROR_UNRESOLVED_SYMBOL;
                result.symbol = S8("_tlv_bootstrap");
            }
            u64 bootstrap_address = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                bootstrap_address = text_vm_address + stub_offset + (u64)bootstrap_import_index * stub_size;
                for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
                {
                    u32 thread_local_index = thread_local_indices[symbol_index];
                    if (thread_local_index == UINT32_MAX)
                    {
                        continue;
                    }
                    ObjectSymbol* symbol = &object->symbols[symbol_index];
                    u64 descriptor_offset = thread_local_variables_offset + (u64)thread_local_index * 3 * sizeof(u64);
                    u64 descriptor_address = image_base + descriptor_offset;
                    u64 initializer_offset = symbol->section == OBJECT_SECTION_THREAD_LOCAL_ZERO
                                                 ? section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO] - section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA] + symbol->value
                                                 : symbol->value;
                    u64 pointer_offset = got_offset + ((u64)import_count + thread_local_index) * sizeof(u64);
                    link_write_u64(bytes, pointer_offset, descriptor_address);
                    link_write_u64(bytes, descriptor_offset, bootstrap_address);
                    link_write_u64(bytes, descriptor_offset + 2 * sizeof(u64), initializer_offset);
                }
            }
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        // Debug sections are not part of the executable's load policy, so their
        // relocations are resolved here rather than through dyld: address slots
        // take link-time virtual addresses, range/location text slots stay
        // section-relative DWARF 4 offsets, and 32-bit slots take offsets into the
        // target debug section.
        for (u32 index = 0; has_dwarf && index < object->relocation_count && result.error == LINK_ERROR_NONE; index += 1)
        {
            ObjectRelocation* relocation = &object->relocations[index];
            if (relocation->section >= OBJECT_SECTION_COUNT || !object_section_kind_is_debug((ObjectSectionKind)relocation->section) ||
                relocation->symbol >= object->symbol_count)
            {
                continue;
            }
            u32 debug_index = 0;
            while (debug_index < BUSTER_ARRAY_LENGTH(dwarf_kinds) && dwarf_kinds[debug_index] != (ObjectSectionKind)relocation->section)
            {
                debug_index += 1;
            }
            if (debug_index >= BUSTER_ARRAY_LENGTH(dwarf_kinds))
            {
                continue;
            }
            ObjectSection* section = &object->sections[relocation->section];
            ObjectSymbol* symbol = &object->symbols[relocation->symbol];
            u64 width = relocation->kind == OBJECT_RELOCATION_ABSOLUTE64 ? 8 : 4;
            if (relocation->offset > section->data.length || width > section->data.length - relocation->offset || symbol->section >= OBJECT_SECTION_COUNT)
            {
                result.error = LINK_ERROR_RELOCATION;
            }
            u64 slot = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                slot = dwarf_file_offsets[debug_index] + relocation->offset;
                if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
                {
                    bool relative_text_range = (relocation->section == OBJECT_SECTION_DEBUG_LOC || relocation->section == OBJECT_SECTION_DEBUG_RANGES) &&
                                               symbol->section == OBJECT_SECTION_TEXT;
                    u64 value = 0;
                    if (relative_text_range)
                    {
                        if (!link_address_addend(symbol->value, relocation->addend, &value))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                        }
                    }
                    else if (!link_u64_add(image_base, section_offsets[symbol->section], &value) ||
                             !link_u64_add(value, symbol->value, &value) || !link_address_addend(value, relocation->addend, &value))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u64(bytes, slot, value);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE32 && object_section_kind_is_debug((ObjectSectionKind)symbol->section))
                {
                    u64 value = 0;
                    if (!link_address_addend(symbol->value, relocation->addend, &value) || value > UINT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, slot, (u32)value);
                    }
                }
                else
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
        }
        for (u32 index = 0; index < object->relocation_count && result.error == LINK_ERROR_NONE; index += 1)
        {
            ObjectRelocation* relocation = &object->relocations[index];
            if (relocation->section < OBJECT_SECTION_COUNT && object_section_kind_is_debug((ObjectSectionKind)relocation->section))
            {
                continue;
            }
            if (relocation->section >= OBJECT_SECTION_COUNT || relocation->symbol >= object->symbol_count)
            {
                result.error = LINK_ERROR_RELOCATION;
            }
            ObjectSection*section = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                section = &object->sections[relocation->section];
            }
            u64 width = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                width = relocation->kind == OBJECT_RELOCATION_ABSOLUTE64 ? 8 : 4;
                if (relocation->offset > section->data.length || width > section->data.length - relocation->offset)
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
            ObjectSymbol*symbol = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                symbol = &object->symbols[relocation->symbol];
            }
            u64 symbol_address = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                symbol_address = 0;
            }
            bool thread_local_pointer = false;
            if (result.error == LINK_ERROR_NONE)
            {
                thread_local_pointer = relocation->kind == OBJECT_RELOCATION_X86_64_MACH_TLV_PC32 ||
                                            relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGE21 ||
                                            relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGEOFF12;
                if (thread_local_pointer)
                {
                    u32 thread_local_index = thread_local_indices[relocation->symbol];
                    if (thread_local_index == UINT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    u64 slot_index = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        slot_index = 0;
                        if (!link_u64_add(import_count, thread_local_index, &slot_index) || slot_index > UINT64_MAX / sizeof(u64) ||
                            !link_u64_add(image_base, got_offset, &symbol_address) || !link_u64_add(symbol_address, slot_index * sizeof(u64), &symbol_address))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                }
                else if (symbol->section == OBJECT_SECTION_UNDEFINED)
                {
                    if ((relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_PAGE21 || relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12) &&
                        symbol->kind == OBJECT_SYMBOL_DATA)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    u32 import_index = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        import_index = import_indices[relocation->symbol];
                        if (import_index == UINT32_MAX)
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        if (!link_u64_add(text_vm_address, stub_offset, &symbol_address) || import_index > UINT64_MAX / stub_size ||
                            !link_u64_add(symbol_address, (u64)import_index * stub_size, &symbol_address))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                }
                else if (symbol->section < OBJECT_SECTION_COUNT)
                {
                    if (!link_u64_add(image_base, section_offsets[symbol->section], &symbol_address) ||
                        !link_u64_add(symbol_address, symbol->value, &symbol_address))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                }
                else
                {
                    result.error = LINK_ERROR_RELOCATION;
                    result.symbol = symbol->name;
                }
            }
            u64 output_offset = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                output_offset = section_offsets[relocation->section] + relocation->offset;
            }
            u64 place_address = 0;
            if (result.error == LINK_ERROR_NONE)
            {
                place_address = image_base + output_offset;
                if (relocation->kind == OBJECT_RELOCATION_X86_64_PC32 || relocation->kind == OBJECT_RELOCATION_X86_64_MACH_TLV_PC32 ||
                    relocation->kind == OBJECT_RELOCATION_AARCH64_PREL32)
                {
                    s64 value = 0;
                    bool value_valid = relocation->kind == OBJECT_RELOCATION_AARCH64_PREL32
                                           ? section->alignment >= 4 && !(place_address & 3) && link_address_difference(symbol_address, place_address, relocation->addend, &value)
                                           : true;
                    if (relocation->kind != OBJECT_RELOCATION_AARCH64_PREL32)
                    {
                        value_valid = link_address_difference(symbol_address, place_address, relocation->addend, &value);
                    }
                    if (!value_valid || value < INT32_MIN || value > INT32_MAX)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, (u32)(s32)value);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_CALL26 || relocation->kind == OBJECT_RELOCATION_AARCH64_JUMP26)
                {
                    s64 displacement = 0;
                    u32 instruction = link_read_u32(object->sections[relocation->section].data.pointer, relocation->offset);
                    u32 patched = 0;
                    if ((place_address & 3) || (symbol->section == OBJECT_SECTION_UNDEFINED && relocation->addend) ||
                        !link_address_difference(symbol_address, place_address, relocation->addend, &displacement) ||
                        !link_aarch64_branch_relocate(relocation->kind, instruction, displacement, &patched))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, patched);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGE21 || relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_PAGE21)
                {
                    u32 instruction = 0;
                    memcpy(&instruction, bytes + output_offset, sizeof(instruction));
                    u32 destination = instruction & 31;
                    if ((place_address & 3) || !link_aarch64_page21_instruction_valid(instruction))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    u64 target_address = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        target_address = symbol_address;
                        if (relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_PAGE21 && !link_address_addend(symbol_address, relocation->addend, &target_address))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        if (relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGE21)
                        {
                            if (!link_address_addend(symbol_address, relocation->addend, &target_address))
                            {
                                result.error = LINK_ERROR_RELOCATION;
                                result.symbol = symbol->name;
                            }
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        link_write_u32(bytes, output_offset, link_aarch64_adrp(destination, place_address, target_address, &valid));
                        if (!valid)
                        {
                            result.error = LINK_ERROR_RELOCATION;
                        }
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_TLVP_PAGEOFF12)
                {
                    u64 address = 0;
                    if (!link_address_addend(symbol_address, relocation->addend, &address))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    u64 page_offset = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        page_offset = address & 0xfff;
                    }
                    u32 instruction = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        instruction = 0;
                    }
                    u32 shift = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        shift = 0;
                        memcpy(&instruction, bytes + output_offset, sizeof(instruction));
                        if (!link_aarch64_pageoff12_shift(instruction, &shift) || shift != 3 ||
                            (instruction & UINT32_C(0xffc00000)) != UINT32_C(0xf9400000) || (page_offset & ((1u << shift) - 1)))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        instruction &= ~(UINT32_C(0xfff) << 10);
                        instruction |= (u32)(page_offset >> shift) << 10;
                        link_write_u32(bytes, output_offset, instruction);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12)
                {
                    if (place_address & 3)
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    u64 address = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        address = 0;
                        if (!link_address_addend(symbol_address, relocation->addend, &address))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                    u32 page_offset = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        page_offset = (u32)(address & 0xfff);
                    }
                    u32 instruction = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        instruction = 0;
                        memcpy(&instruction, bytes + output_offset, sizeof(instruction));
                    }
                    u32 shift = 0;
                    if (result.error == LINK_ERROR_NONE)
                    {
                        shift = 0;
                        if (!link_aarch64_pageoff12_shift(instruction, &shift) || (page_offset & ((1u << shift) - 1)))
                        {
                            result.error = LINK_ERROR_RELOCATION;
                            result.symbol = symbol->name;
                        }
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        instruction &= ~(UINT32_C(0xfff) << 10);
                        instruction |= (page_offset >> shift) << 10;
                        link_write_u32(bytes, output_offset, instruction);
                    }
                }
                else if (relocation->kind == OBJECT_RELOCATION_ABSOLUTE64)
                {
                    u64 address = 0;
                    if (!link_address_addend(symbol_address, relocation->addend, &address))
                    {
                        result.error = LINK_ERROR_RELOCATION;
                        result.symbol = symbol->name;
                    }
                    if (result.error == LINK_ERROR_NONE)
                    {
                        if (object->target.cpu_arch == CPU_ARCH_AARCH64 && relocation->section == OBJECT_SECTION_TEXT)
                        {
                            if (relocation->offset < 8)
                            {
                                result.error = LINK_ERROR_RELOCATION;
                            }
                            u64 load_offset = output_offset - 8;
                            u64 branch_offset = output_offset - 4;
                            u32 load = 0;
                            u32 branch = 0;
                            memcpy(&load, bytes + load_offset, sizeof(load));
                            memcpy(&branch, bytes + branch_offset, sizeof(branch));
                            if ((load & UINT32_C(0xffffffe0)) != UINT32_C(0x58000040) || branch != UINT32_C(0x14000003))
                            {
                                result.error = LINK_ERROR_RELOCATION;
                            }
                            u32 destination = load & 31;
                            u64 load_address = image_base + load_offset;
                            link_write_u32(bytes, load_offset, link_aarch64_adrp(destination, load_address, address, &valid));
                            link_write_u32(bytes, branch_offset, UINT32_C(0x91000000) | ((u32)(address & 0xfff) << 10) | (destination << 5) | destination);
                            link_write_u32(bytes, output_offset, UINT32_C(0x14000002));
                            link_write_u32(bytes, output_offset + sizeof(u32), 0);
                            if (!valid)
                            {
                                result.error = LINK_ERROR_RELOCATION;
                            }
                        }
                        else
                        {
                            link_write_u64(bytes, output_offset, address);
                        }
                    }
                }
                else
                {
                    result.error = LINK_ERROR_RELOCATION;
                }
            }
        }
        link_write_u32(bytes, 0, 0xfeedfacf);
    }
    if (result.error == LINK_ERROR_NONE)
    {
        link_write_u32(bytes, 4, object->target.cpu_arch == CPU_ARCH_X86_64 ? 0x01000007 : 0x0100000c);
        link_write_u32(bytes, 8, object->target.cpu_arch == CPU_ARCH_X86_64 ? 3 : 0);
        link_write_u32(bytes, 12, 2);
        link_write_u32(bytes, 16, MACH_BASE_COMMAND_COUNT + options.dynamic_library_count + (has_dwarf ? 1 : 0));
        link_write_u32(bytes, 20, (u32)command_size);
        link_write_u32(bytes, 24, 0x200084 | (thread_local_count ? 0x800000 : 0));
    }
    u64 command = 0;
    u64 uuid_command_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        command = MACH_HEADER_SIZE;
    #define BUSTER_LINK_MACH_SEGMENT(name, vm_address, vm_size, file_offset, file_segment_size, maximum, initial)                                                  \
        do                                                                                                                                                         \
        {                                                                                                                                                          \
            link_write_u32(bytes, command, 0x19);                                                                                                                  \
            link_write_u32(bytes, command + 4, MACH_SEGMENT_COMMAND_SIZE);                                                                                         \
            link_mach_name_write(bytes, command + 8, (name));                                                                                                      \
            link_write_u64(bytes, command + 24, (vm_address));                                                                                                     \
            link_write_u64(bytes, command + 32, (vm_size));                                                                                                        \
            link_write_u64(bytes, command + 40, (file_offset));                                                                                                    \
            link_write_u64(bytes, command + 48, (file_segment_size));                                                                                              \
            link_write_u32(bytes, command + 56, (maximum));                                                                                                        \
            link_write_u32(bytes, command + 60, (initial));                                                                                                        \
            command += MACH_SEGMENT_COMMAND_SIZE;                                                                                                                  \
        } while (0)
        BUSTER_LINK_MACH_SEGMENT("__PAGEZERO", 0, image_base, 0, 0, 0, 0);
        link_write_u32(bytes, command, 0x19);
        link_write_u32(bytes, command + 4, (u32)text_command_size);
        link_mach_name_write(bytes, command + 8, "__TEXT");
        link_write_u64(bytes, command + 24, image_base);
        link_write_u64(bytes, command + 32, data_file_offset);
        link_write_u64(bytes, command + 48, data_file_offset);
        link_write_u32(bytes, command + 56, 5);
        link_write_u32(bytes, command + 60, 5);
        link_write_u32(bytes, command + 64, has_unwind ? 2 : 1);
        link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE, "__text", "__TEXT", image_base + section_offsets[OBJECT_SECTION_TEXT],
                                stub_end - section_offsets[OBJECT_SECTION_TEXT], (u32)section_offsets[OBJECT_SECTION_TEXT], 4, 0x80000400, 0, 0);
        if (has_unwind)
        {
            link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + MACH_SECTION_SIZE, "__eh_frame", "__TEXT",
                                    image_base + section_offsets[OBJECT_SECTION_UNWIND], object->sections[OBJECT_SECTION_UNWIND].data.length,
                                    (u32)section_offsets[OBJECT_SECTION_UNWIND], 3, 0x6800000b, 0, 0);
        }
        command += text_command_size;
        link_write_u32(bytes, command, 0x19);
        link_write_u32(bytes, command + 4, (u32)data_command_size);
        link_mach_name_write(bytes, command + 8, "__DATA");
        link_write_u64(bytes, command + 24, data_vm_address);
        link_write_u64(bytes, command + 32, data_vm_end - data_file_offset);
        link_write_u64(bytes, command + 40, data_file_offset);
        link_write_u64(bytes, command + 48, data_end - data_file_offset);
        link_write_u32(bytes, command + 56, 3);
        link_write_u32(bytes, command + 60, 3);
        link_write_u32(bytes, command + 64, data_section_count);
        link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE, "__data", "__DATA", data_vm_address, object->sections[OBJECT_SECTION_DATA].data.length,
                                (u32)data_file_offset, 3, 0, 0, 0);
        // S_MOD_INIT_FUNC_POINTERS: the section type is the whole contract,
        // because it is what makes dyld call the pointers rather than merely
        // map them.  There is no S_MOD_TERM_FUNC_POINTERS section beside it --
        // dyld does not call one in a main executable, so the destructors are
        // reached through the registrar the first slot names instead.
        if (has_initializer_array)
        {
            link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + MACH_SECTION_SIZE, "__mod_init_func", "__DATA",
                                    image_base + section_offsets[OBJECT_SECTION_INIT_ARRAY], object->sections[OBJECT_SECTION_INIT_ARRAY].data.length,
                                    (u32)section_offsets[OBJECT_SECTION_INIT_ARRAY],
                                    link_mach_alignment_power(object->sections[OBJECT_SECTION_INIT_ARRAY].alignment), 0x9, 0, 0);
        }
    }
    u32 read_only_alignment_power = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        read_only_alignment_power = 0;
        for (u32 read_only_alignment = object->sections[OBJECT_SECTION_READ_ONLY_DATA].alignment; read_only_alignment > 1; read_only_alignment >>= 1)
        {
            read_only_alignment_power += 1;
        }
        // Every section after __data is displaced by however many initializer
        // arrays this image carries; the section commands must stay in the
        // order the file lays the sections out in.
        link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + (1 + (u64)initializer_section_count) * MACH_SECTION_SIZE, "__const", "__DATA",
                                image_base + section_offsets[OBJECT_SECTION_READ_ONLY_DATA], object->sections[OBJECT_SECTION_READ_ONLY_DATA].data.length,
                                (u32)section_offsets[OBJECT_SECTION_READ_ONLY_DATA],
                                read_only_alignment_power, 0, 0, 0);
        link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + (2 + (u64)initializer_section_count) * MACH_SECTION_SIZE, "__got", "__DATA",
                                image_base + got_offset, got_count * sizeof(u64), (u32)got_offset, 3, 0, 0, 0);
        if (thread_local_count)
        {
            link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + (3 + (u64)initializer_section_count) * MACH_SECTION_SIZE, "__thread_vars", "__DATA",
                                    image_base + thread_local_variables_offset, thread_local_variables_size, (u32)thread_local_variables_offset, 3, 0x13, 0, 0);
            link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + (4 + (u64)initializer_section_count) * MACH_SECTION_SIZE, "__thread_data", "__DATA",
                                    image_base + section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA], object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length,
                                    (u32)section_offsets[OBJECT_SECTION_THREAD_LOCAL_DATA], 4, 0x11, 0, 0);
            link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + (5 + (u64)initializer_section_count) * MACH_SECTION_SIZE, "__thread_bss", "__DATA",
                                    image_base + section_offsets[OBJECT_SECTION_THREAD_LOCAL_ZERO], object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size,
                                    0, 4, 0x12, 0, 0);
        }
    }
    u32 zero_alignment_power = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        zero_alignment_power = 0;
        for (u32 zero_alignment = object->sections[OBJECT_SECTION_ZERO].alignment; zero_alignment > 1; zero_alignment >>= 1)
        {
            zero_alignment_power += 1;
        }
    }
    u32 zero_section_index = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        zero_section_index = 3u + initializer_section_count + (thread_local_count ? 3u : 0u);
        link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + (u64)zero_section_index * MACH_SECTION_SIZE, "__bss", "__DATA",
                                image_base + section_offsets[OBJECT_SECTION_ZERO], object->sections[OBJECT_SECTION_ZERO].virtual_size, 0, zero_alignment_power, 1, 0, 0);
        command += data_command_size;
        if (has_dwarf)
        {
            // dyld refuses a segment whose filesize exceeds its vmsize, so the
            // debug segment is a read-only mapping between __DATA and __LINKEDIT
            // rather than an unmapped one. It is never touched at run time.
            link_write_u32(bytes, command, 0x19);
            link_write_u32(bytes, command + 4, (u32)dwarf_command_size);
            link_mach_name_write(bytes, command + 8, "__DWARF");
            link_write_u64(bytes, command + 24, image_base + dwarf_vm_offset);
            link_write_u64(bytes, command + 32, align_forward(dwarf_vm_cursor - dwarf_vm_offset, MACH_PAGE_SIZE));
            link_write_u64(bytes, command + 40, dwarf_file_offset);
            link_write_u64(bytes, command + 48, dwarf_file_cursor - dwarf_file_offset);
            link_write_u32(bytes, command + 56, 1);
            link_write_u32(bytes, command + 60, 1);
            link_write_u32(bytes, command + 64, BUSTER_ARRAY_LENGTH(dwarf_kinds));
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(dwarf_kinds); index += 1)
            {
                // Each section must sit inside its segment's address range or
                // dyld rejects the image.
                link_mach_section_write(bytes, command + MACH_SEGMENT_COMMAND_SIZE + (u64)index * MACH_SECTION_SIZE, dwarf_section_names[index], "__DWARF",
                                        image_base + dwarf_vm_offsets[index], object->sections[dwarf_kinds[index]].data.length, (u32)dwarf_file_offsets[index], 0,
                                        0x02000000, 0, 0);
            }
            command += dwarf_command_size;
        }
        BUSTER_LINK_MACH_SEGMENT("__LINKEDIT", image_base + linkedit_vm_offset, align_forward(file_size - linkedit_file_offset, MACH_PAGE_SIZE), linkedit_file_offset,
                                 file_size - linkedit_file_offset, 1, 1);
    #undef BUSTER_LINK_MACH_SEGMENT
        link_write_u32(bytes, command, 0x80000022);
        link_write_u32(bytes, command + 4, MACH_DYLD_INFO_COMMAND_SIZE);
        link_write_u32(bytes, command + 8, rebase_count ? (u32)linkedit_file_offset : 0);
        link_write_u32(bytes, command + 12, (u32)rebase_size);
        link_write_u32(bytes, command + 16, import_count ? (u32)bind_offset : 0);
        link_write_u32(bytes, command + 20, (u32)bind_size);
        command += MACH_DYLD_INFO_COMMAND_SIZE;
        link_write_u32(bytes, command, 0xe);
        link_write_u32(bytes, command + 4, MACH_DYLINKER_COMMAND_SIZE);
        link_write_u32(bytes, command + 8, 12);
        memcpy(bytes + command + 12, dyld_path, sizeof(dyld_path));
        command += MACH_DYLINKER_COMMAND_SIZE;
        link_write_u32(bytes, command, 0xc);
        link_write_u32(bytes, command + 4, MACH_DYLIB_COMMAND_SIZE);
        link_write_u32(bytes, command + 8, 24);
        link_write_u32(bytes, command + 16, 0x10000);
        link_write_u32(bytes, command + 20, 0x10000);
        memcpy(bytes + command + 24, system_path, sizeof(system_path));
        command += MACH_DYLIB_COMMAND_SIZE;
        for (u32 library_index = 0; library_index < options.dynamic_library_count; library_index += 1)
        {
            String8 library = options.dynamic_libraries[library_index].name;
            u32 dylib_command_size = (u32)align_forward(24 + library.length + 1, 8);
            link_write_u32(bytes, command, 0xc);
            link_write_u32(bytes, command + 4, dylib_command_size);
            link_write_u32(bytes, command + 8, 24);
            link_write_u32(bytes, command + 16, 0x10000);
            link_write_u32(bytes, command + 20, 0x10000);
            memcpy(bytes + command + 24, library.pointer, library.length);
            bytes[command + 24 + library.length] = 0;
            command += dylib_command_size;
        }
    }
    ObjectSymbol*entry_symbol = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_symbol = &object->symbols[entry_symbol_index];
    }
    u64 entry_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        entry_offset = section_offsets[entry_symbol->section] + entry_symbol->value;
        link_write_u32(bytes, command, 0x80000028);
        link_write_u32(bytes, command + 4, MACH_MAIN_COMMAND_SIZE);
        link_write_u64(bytes, command + 8, entry_offset);
        command += MACH_MAIN_COMMAND_SIZE;
        link_write_u32(bytes, command, 0x32);
        link_write_u32(bytes, command + 4, MACH_BUILD_VERSION_COMMAND_SIZE);
        link_write_u32(bytes, command + 8,
                       object->target.os == OPERATING_SYSTEM_IOS ?
    #if BUSTER_IOS_SIMULATOR
                                                                 7
                                                                 :
    #else
                                                                 2
                                                                 : 1);
    #endif
    #if BUSTER_IOS_SIMULATOR
                                                                 1);
    #endif
        link_write_u32(bytes, command + 12, 0x000d0000);
        link_write_u32(bytes, command + 16, 0x000d0000);
        command += MACH_BUILD_VERSION_COMMAND_SIZE;
        link_write_u32(bytes, command, 0x2);
        link_write_u32(bytes, command + 4, MACH_SYMTAB_COMMAND_SIZE);
        link_write_u32(bytes, command + 8, (u32)symbol_table_offset);
        link_write_u32(bytes, command + 12, import_count);
        link_write_u32(bytes, command + 16, (u32)string_table_offset);
        link_write_u32(bytes, command + 20, (u32)string_table_size);
        command += MACH_SYMTAB_COMMAND_SIZE;
        link_write_u32(bytes, command, 0xb);
        link_write_u32(bytes, command + 4, MACH_DYSYMTAB_COMMAND_SIZE);
        link_write_u32(bytes, command + 24, 0);
        link_write_u32(bytes, command + 28, import_count);
        command += MACH_DYSYMTAB_COMMAND_SIZE;
        // dyld_info in newer command-line tools refuses to report on an
        // image without LC_UUID.  The sixteen bytes stay zero here and are
        // filled from a hash of the finished image just before the code
        // directory below hashes its pages, so identical inputs keep
        // producing identical binaries.
        uuid_command_offset = command;
        link_write_u32(bytes, command, 0x1b);
        link_write_u32(bytes, command + 4, MACH_UUID_COMMAND_SIZE);
        command += MACH_UUID_COMMAND_SIZE;
        link_write_u32(bytes, command, 0x1d);
        link_write_u32(bytes, command + 4, MACH_CODE_SIGNATURE_COMMAND_SIZE);
        link_write_u32(bytes, command + 8, (u32)signature_offset);
        link_write_u32(bytes, command + 12, (u32)signature_size);
        command += MACH_CODE_SIGNATURE_COMMAND_SIZE;
        if (command != header_end)
        {
            result.error = LINK_ERROR_INVALID_INPUT;
        }
    }
    if (result.error == LINK_ERROR_NONE)
    {
        // Everything up to the signature is final and the uuid bytes are
        // still zero, so this hash is deterministic; the code directory
        // below then hashes pages that already carry the finished uuid.
        u64 uuid_low = buster_hash_64(bytes, signature_offset);
        u64 uuid_high = buster_hash_64((u8*)&uuid_low, sizeof(uuid_low)) ^ signature_offset;
        link_write_u64(bytes, uuid_command_offset + 8, uuid_low);
        link_write_u64(bytes, uuid_command_offset + 16, uuid_high);
        // RFC 4122 version and variant bits, the way ld64 stamps its
        // content-derived uuids.
        bytes[uuid_command_offset + 8 + 6] = (u8)((bytes[uuid_command_offset + 8 + 6] & 0x0f) | 0x40);
        bytes[uuid_command_offset + 8 + 8] = (u8)((bytes[uuid_command_offset + 8 + 8] & 0x3f) | 0x80);
    }
    u64 code_directory = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        code_directory = signature_offset + 20;
        link_write_u32_be(bytes, signature_offset, 0xfade0cc0);
        link_write_u32_be(bytes, signature_offset + 4, (u32)signature_size);
        link_write_u32_be(bytes, signature_offset + 8, 1);
        link_write_u32_be(bytes, signature_offset + 12, 0);
        link_write_u32_be(bytes, signature_offset + 16, 20);
        link_write_u32_be(bytes, code_directory, 0xfade0c02);
        link_write_u32_be(bytes, code_directory + 4, (u32)code_directory_size);
        link_write_u32_be(bytes, code_directory + 8, 0x20100);
        link_write_u32_be(bytes, code_directory + 12, 2);
        link_write_u32_be(bytes, code_directory + 16, MACH_CODE_DIRECTORY_HEADER_SIZE + MACH_CODE_DIRECTORY_IDENTIFIER_SIZE);
        link_write_u32_be(bytes, code_directory + 20, MACH_CODE_DIRECTORY_HEADER_SIZE);
        link_write_u32_be(bytes, code_directory + 28, (u32)code_slot_count);
        link_write_u32_be(bytes, code_directory + 32, (u32)signature_offset);
        bytes[code_directory + 36] = 32;
        bytes[code_directory + 37] = 2;
        bytes[code_directory + 39] = 12;
        memcpy(bytes + code_directory + MACH_CODE_DIRECTORY_HEADER_SIZE, "buster", MACH_CODE_DIRECTORY_IDENTIFIER_SIZE);
    }
    u64 hash_offset = 0;
    if (result.error == LINK_ERROR_NONE)
    {
        hash_offset = code_directory + MACH_CODE_DIRECTORY_HEADER_SIZE + MACH_CODE_DIRECTORY_IDENTIFIER_SIZE;
        for (u64 slot = 0; slot < code_slot_count; slot += 1)
        {
            u64 page_offset = slot * MACH_CODE_PAGE_SIZE;
            u64 page_size = BUSTER_MIN((u64)MACH_CODE_PAGE_SIZE, signature_offset - page_offset);
            link_sha256(arena, bytes + page_offset, page_size, bytes + hash_offset + slot * 32);
        }
        if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
        {
            result.error = LINK_ERROR_FILE_WRITE;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_android_elf64(Arena* arena, ObjectFile* object, NativeExecutableLinkOptions options, LinkElfIndex* exports)
{
    static char8 const interpreter[] = "/system/bin/linker64";
    static char8 const library[] = "libc.so";
    NativeExecutableLinkOptions staging_options = options;
    staging_options.output_path = (String8){0};
    ObjectFile staging_object = *object;
    staging_object.target.os = OPERATING_SYSTEM_LINUX;
    bool has_import = options.dynamic_library_count != 0;
    for (u32 index = 0; index < object->symbol_count; index += 1)
    {
        if (link_elf_symbol_needs_dynamic_import(exports, &object->symbols[index]))
        {
            has_import = true;
            break;
        }
    }
    NativeExecutableLinkResult result = {0};
    if (object->target.cpu_arch == CPU_ARCH_X86_64)
    {
        result = has_import ? link_native_executable_elf64_x86_64_dynamic(arena, &staging_object, staging_options, exports)
                            : link_native_executable_elf64_x86_64(arena, &staging_object, staging_options);
    }
    else if (object->target.cpu_arch == CPU_ARCH_AARCH64)
    {
        result = has_import ? link_native_executable_elf64_aarch64_dynamic(arena, &staging_object, staging_options, exports)
                            : link_native_executable_elf64_aarch64(arena, &staging_object, staging_options);
    }
    else
    {
        result.error = LINK_ERROR_UNSUPPORTED_HOST;
    }
    if (result.error == LINK_ERROR_NONE)
    {
        u8* bytes = result.executable.pointer;
        link_write_u16(bytes, 16, 3);
        if (has_import)
        {
            u64 interpreter_program_header = ELF_HEADER_SIZE + ELF_PROGRAM_HEADER_SIZE;
            u64 interpreter_offset = link_read_u64(bytes, interpreter_program_header + 8);
            u64 interpreter_size = link_read_u64(bytes, interpreter_program_header + 32);
            if (sizeof(interpreter) > interpreter_size)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            memset(bytes + interpreter_offset, 0, interpreter_size);
            memcpy(bytes + interpreter_offset, interpreter, sizeof(interpreter));
            u64 dynamic_program_header = ELF_HEADER_SIZE + 4 * ELF_PROGRAM_HEADER_SIZE;
            u64 dynamic_offset = link_read_u64(bytes, dynamic_program_header + 8);
            u64 string_table_offset = 0;
            u64 dynamic_count = link_read_u64(bytes, dynamic_program_header + 32) / ELF_DYNAMIC_SIZE;
            for (u64 index = 0; index < dynamic_count && !string_table_offset; index += 1)
            {
                u64 entry = dynamic_offset + index * ELF_DYNAMIC_SIZE;
                u64 tag = link_read_u64(bytes, entry);
                if (!tag)
                {
                    break;
                }
                if (tag == 5)
                {
                    string_table_offset = link_read_u64(bytes, entry + 8) - UINT64_C(0x400000);
                }
            }
            if (!string_table_offset)
            {
                result.error = LINK_ERROR_INVALID_INPUT;
                return result;
            }
            memset(bytes + string_table_offset + 1, 0, sizeof("libc.so.6"));
            memcpy(bytes + string_table_offset + 1, library, sizeof(library));
        }
        if (options.output_path.length && !link_write_executable_file(options.output_path, result.executable))
        {
            result.error = LINK_ERROR_FILE_WRITE;
        }
    }

    return result;
}

String8 link_error_name(LinkError error)
{
    static String8 const names[LINK_ERROR_COUNT] = {
        S8_INITIALIZER("none"),
        S8_INITIALIZER("invalid input"),
        S8_INITIALIZER("target mismatch"),
        S8_INITIALIZER("duplicate symbol"),
        S8_INITIALIZER("COMDAT selection mismatch"),
        S8_INITIALIZER("COMDAT size mismatch"),
        S8_INITIALIZER("COMDAT exact-match mismatch"),
        S8_INITIALIZER("unresolved symbol"),
        S8_INITIALIZER("object write"),
        S8_INITIALIZER("file write"),
        S8_INITIALIZER("process spawn"),
        S8_INITIALIZER("process failed"),
        S8_INITIALIZER("unsupported host"),
        S8_INITIALIZER("unsupported feature"),
        S8_INITIALIZER("entry symbol"),
        S8_INITIALIZER("relocation"),
        S8_INITIALIZER("no default version for symbol"),
        S8_INITIALIZER("TLS/non-TLS symbol mismatch"),
    };

    return error < LINK_ERROR_COUNT ? names[error] : S8("unknown error");
}

// GCC's x86-64 PIC objects carry this reserved undefined marker even when
// their GOTPCREL relocations name only the actual data symbols. An unused
// marker requests no GOT address. Remove it from a private symbol view before
// selecting the writer; real references and explicit entry requests stay strict.
BUSTER_GLOBAL_LOCAL LinkObjectResult link_elf_without_unused_got_marker(Arena* arena, ObjectFile* object, NativeExecutableLinkOptions options)
{
    LinkObjectResult result = {.object = *object};
    String8 marker = S8("_GLOBAL_OFFSET_TABLE_");
    bool has_marker = false;
    for (u32 index = 0; !has_marker && index < object->symbol_count; index += 1)
    {
        ObjectSymbol* symbol = object->symbols + index;
        has_marker = symbol->global && symbol->section == OBJECT_SECTION_UNDEFINED && string_equal(symbol->name, marker);
    }
    if (has_marker && !string_equal(options.entry_symbol, marker))
    {
        TemporalArena temporary = scratch_begin(&arena, 1);
        u32* remap = arena_allocate(temporary.arena, u32, object->symbol_count);
        for (u32 index = 0; index < object->symbol_count; index += 1)
        {
            ObjectSymbol* symbol = object->symbols + index;
            bool unused_marker = symbol->global && symbol->section == OBJECT_SECTION_UNDEFINED && string_equal(symbol->name, marker);
            remap[index] = unused_marker ? UINT32_MAX : 0;
        }
        for (u32 index = 0; result.error == LINK_ERROR_NONE && index < object->relocation_count; index += 1)
        {
            u32 symbol = object->relocations[index].symbol;
            if (symbol >= object->symbol_count)
            {
                result.error = LINK_ERROR_RELOCATION;
            }
            else
            {
                remap[symbol] = 0;
            }
        }
        u32 retained = 0;
        for (u32 index = 0; result.error == LINK_ERROR_NONE && index < object->symbol_count; index += 1)
        {
            if (remap[index] != UINT32_MAX)
            {
                remap[index] = retained++;
            }
        }
        if (result.error == LINK_ERROR_NONE && retained != object->symbol_count)
        {
            result.object.symbols = arena_allocate(arena, ObjectSymbol, retained);
            result.object.symbol_count = retained;
            result.object.relocations = arena_allocate(arena, ObjectRelocation, object->relocation_count);
            for (u32 index = 0; index < object->symbol_count; index += 1)
            {
                if (remap[index] != UINT32_MAX)
                {
                    result.object.symbols[remap[index]] = object->symbols[index];
                }
            }
            for (u32 index = 0; index < object->relocation_count; index += 1)
            {
                ObjectRelocation relocation = object->relocations[index];
                relocation.symbol = remap[relocation.symbol];
                result.object.relocations[index] = relocation;
            }
        }
        scratch_end(temporary);
    }

    return result;
}

BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_native_executable_with_scratch(Arena* arena, Arena* temporary, ObjectFile* object, NativeExecutableLinkOptions options)
{
    NativeExecutableLinkResult result = {0};
    LinkElfIndex elf_index = {0};
    LinkElfIndex* exports = &elf_index;
    if (!arena || !object || object->error != OBJECT_ERROR_NONE || object->section_count != OBJECT_SECTION_COUNT || !object->sections ||
        (object->symbol_count && !object->symbols) || (object->relocation_count && !object->relocations) ||
        (options.library_path_count && !options.library_paths) || (options.framework_path_count && !options.framework_paths) ||
        (options.framework_count && !options.frameworks) || (options.linker_argument_count && !options.linker_arguments))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
    }
    else if ((object->target.os == OPERATING_SYSTEM_LINUX || object->target.os == OPERATING_SYSTEM_ANDROID) &&
             !link_elf_index_initialize(temporary, options, exports))
    {
        result.error = LINK_ERROR_INVALID_INPUT;
    }
    else if (object->target.os == OPERATING_SYSTEM_LINUX &&
             (object->target.cpu_arch == CPU_ARCH_X86_64 || object->target.cpu_arch == CPU_ARCH_AARCH64))
    {
        LinkObjectResult normalized = {.object = *object};
        if (object->target.cpu_arch == CPU_ARCH_X86_64)
        {
            normalized = link_elf_without_unused_got_marker(arena, object, options);
        }
        result.error = normalized.error;
        if (result.error == LINK_ERROR_NONE)
        {
            object = &normalized.object;
            bool dynamic_image = options.dynamic_library_count || object->sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data.length ||
                                 object->sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size;
            for (u32 index = 0; !dynamic_image && index < object->symbol_count; index += 1)
            {
                dynamic_image = link_elf_symbol_needs_dynamic_import(exports, object->symbols + index);
            }
            if (object->target.cpu_arch == CPU_ARCH_X86_64)
            {
                result = dynamic_image ? link_native_executable_elf64_x86_64_dynamic(arena, object, options, exports)
                                       : link_native_executable_elf64_x86_64(arena, object, options);
            }
            else
            {
                result = dynamic_image ? link_native_executable_elf64_aarch64_dynamic(arena, object, options, exports)
                                       : link_native_executable_elf64_aarch64(arena, object, options);
            }
        }
    }
    else if (object->target.os == OPERATING_SYSTEM_WINDOWS && (object->target.cpu_arch == CPU_ARCH_X86_64 || object->target.cpu_arch == CPU_ARCH_AARCH64))
    {
        result = link_native_executable_pe64(arena, object, options);
    }
    else if (object->target.os == OPERATING_SYSTEM_UEFI && (object->target.cpu_arch == CPU_ARCH_X86_64 || object->target.cpu_arch == CPU_ARCH_AARCH64))
    {
        result = link_native_executable_uefi_pe64(arena, object, options);
    }
    else if ((object->target.os == OPERATING_SYSTEM_MACOS || object->target.os == OPERATING_SYSTEM_IOS) &&
             (object->target.cpu_arch == CPU_ARCH_X86_64 || object->target.cpu_arch == CPU_ARCH_AARCH64))
    {
        result = link_native_executable_mach_o64(arena, object, options);
    }
    else if (object->target.os == OPERATING_SYSTEM_ANDROID && (object->target.cpu_arch == CPU_ARCH_X86_64 || object->target.cpu_arch == CPU_ARCH_AARCH64))
    {
        result = link_native_executable_android_elf64(arena, object, options, exports);
    }
    else
    {
        result.error = LINK_ERROR_UNSUPPORTED_HOST;
    }

    return result;
}

NativeExecutableLinkResult link_native_executable(Arena* arena, ObjectFile* object, NativeExecutableLinkOptions options)
{
    TemporalArena temporary = scratch_begin(&arena, 1);
    NativeExecutableLinkResult result = link_native_executable_with_scratch(arena, temporary.arena, object, options);
    scratch_end(temporary);
    return result;
}

#if BUSTER_INCLUDE_TESTS
NativeExecutableLinkResult link_elf_test_executable(Arena* arena, Arena* temporary, ObjectFile* object, NativeExecutableLinkOptions options)
{
    TemporalArena scope = arena_begin_temporal(temporary);
    NativeExecutableLinkResult result = link_native_executable_with_scratch(arena, temporary, object, options);
    scratch_end(scope);
    return result;
}

NativeExecutableLinkResult link_elf_test_section_table_append(Arena* arena, ByteSlice image, ObjectFile* object)
{
    NativeExecutableLinkResult result = {.executable = image};
    u64 section_offsets[OBJECT_SECTION_COUNT] = {0};
    link_elf_section_table_append(arena, &result, object, ELF_IMAGE_BASE, section_offsets, (LinkElfSectionTableLayout){0});
    return result;
}
#endif
