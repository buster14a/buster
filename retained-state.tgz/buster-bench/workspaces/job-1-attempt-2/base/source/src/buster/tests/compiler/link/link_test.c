#include <buster/tests/compiler/link/link_test.h>
#if BUSTER_INCLUDE_TESTS

#include <buster/lib/compiler/driver/driver.h>
#include <buster/lib/compiler/link/link_internal.h>
#include <buster/lib/compiler/assembly/aarch64_encoding.h>
#include <buster/lib/file.h>
#include <buster/lib/hash.h>
#include <buster/lib/time.h>

BUSTER_GLOBAL_LOCAL String8 link_test_temporary_executable_path(Arena* arena, String8 name, String8 suffix)
{
#if BUSTER_ANDROID || BUSTER_IOS
    BUSTER_UNUSED(arena);
    BUSTER_UNUSED(name);
    BUSTER_UNUSED(suffix);
    return (String8){0};
#else
    return buster_test_temporary_path(arena, name, suffix);
#endif
}

BUSTER_GLOBAL_LOCAL ObjectFile link_test_object_make(Arena* arena, Target target, ByteSlice text, ObjectSymbol* symbols, u32 symbol_count,
                                                     ObjectRelocation* relocations, u32 relocation_count)
{
    ObjectSection* sections = arena_allocate(arena, ObjectSection, OBJECT_SECTION_COUNT);
    for (u32 kind = 0; kind < OBJECT_SECTION_COUNT; kind += 1)
    {
        sections[kind] = (ObjectSection){
            .name = object_section_name_for_kind((ObjectSectionKind)kind),
            .kind = (ObjectSectionKind)kind,
            .alignment = object_section_default_alignment((ObjectSectionKind)kind),
        };
    }
    sections[OBJECT_SECTION_TEXT].data = text;
    return (ObjectFile){
        .sections = sections,
        .symbols = symbols,
        .relocations = relocations,
        .target = target,
        .section_count = OBJECT_SECTION_COUNT,
        .symbol_count = symbol_count,
        .relocation_count = relocation_count,
    };
}


BUSTER_GLOBAL_LOCAL ObjectFile link_test_comdat_object(Arena* arena, Target target, ByteSlice text,
                                                       ObjectSymbol* symbols, u32 symbol_count,
                                                       ObjectRelocation* relocations, u32 relocation_count,
                                                       ObjectComdat* comdats, u32 comdat_count)
{
    ObjectFile result = link_test_object_make(arena, target, text, symbols, symbol_count, relocations, relocation_count);
    result.comdats = comdats;
    result.comdat_count = comdat_count;
    return result;
}

BUSTER_GLOBAL_LOCAL u32 link_test_comdat_symbol_find(ObjectFile* object, String8 name)
{
    u32 result = UINT32_MAX;
    for (u32 index = 0; object && result == UINT32_MAX && index < object->symbol_count; index += 1)
    {
        if (string_equal(object->symbols[index].name, name))
        {
            result = index;
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL ObjectFile link_test_single_comdat(Arena* arena, Target target, ByteSlice bytes, String8 key,
                                                       ObjectComdatSelection selection, ObjectSymbol* symbols,
                                                       u32 symbol_count, ObjectRelocation* relocations, u32 relocation_count)
{
    ObjectComdat* comdat = arena_allocate(arena, ObjectComdat, 1);
    *comdat = (ObjectComdat){
        .key = key,
        .size = bytes.length,
        .section = OBJECT_SECTION_TEXT,
        .associated = OBJECT_COMDAT_ASSOCIATED_NONE,
        .first_relocation = 0,
        .relocation_count = relocation_count,
        .selection = selection,
    };
    symbols[0].comdat = 1;
    symbols[0].weak = selection != OBJECT_COMDAT_SELECTION_NO_DUPLICATES;
    for (u32 index = 0; index < relocation_count; index += 1)
    {
        relocations[index].comdat = 1;
    }
    return link_test_comdat_object(arena, target, bytes, symbols, symbol_count, relocations, relocation_count, comdat, 1);
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_thread_local_symbol_identity(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX};
    u8 ordinary_data[] = {1, 2, 3, 4};
    u8 thread_local_data[] = {5, 6, 7, 8};
    ObjectSymbol thread_local_reference = {
        .name = S8("shared_value"),
        .section = OBJECT_SECTION_UNDEFINED,
        .kind = OBJECT_SYMBOL_DATA,
        .global = true,
        .thread_local_state = OBJECT_SYMBOL_THREAD_LOCAL_YES,
    };
    ObjectSymbol ordinary_definition = {
        .name = S8("shared_value"),
        .size = sizeof(ordinary_data),
        .section = OBJECT_SECTION_DATA,
        .kind = OBJECT_SYMBOL_DATA,
        .global = true,
        .thread_local_state = OBJECT_SYMBOL_THREAD_LOCAL_NO,
    };
    ObjectFile mismatched_objects[] = {
        link_test_object_make(arguments->arena, target, (ByteSlice){0}, &thread_local_reference, 1, 0, 0),
        link_test_object_make(arguments->arena, target, (ByteSlice){0}, &ordinary_definition, 1, 0, 0),
    };
    mismatched_objects[1].sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(ordinary_data);
    mismatched_objects[1].sections[OBJECT_SECTION_DATA].virtual_size = sizeof(ordinary_data);
    LinkObjectResult mismatch = link_objects(arguments->arena, mismatched_objects, BUSTER_ARRAY_LENGTH(mismatched_objects), (LinkOptions){0});
    BUSTER_TEST(arguments, mismatch.error == LINK_ERROR_TLS_SYMBOL_MISMATCH);
    BUSTER_STRING_TEST(arguments, mismatch.symbol, S8("shared_value"));
    BUSTER_STRING_TEST(arguments, link_error_name(mismatch.error), S8("TLS/non-TLS symbol mismatch"));

    ObjectSymbol unknown_reference = thread_local_reference;
    unknown_reference.thread_local_state = OBJECT_SYMBOL_THREAD_LOCAL_UNKNOWN;
    ObjectSymbol thread_local_definition = {
        .name = S8("shared_value"),
        .size = sizeof(thread_local_data),
        .section = OBJECT_SECTION_THREAD_LOCAL_DATA,
        .kind = OBJECT_SYMBOL_DATA,
        .global = true,
        .thread_local_state = OBJECT_SYMBOL_THREAD_LOCAL_YES,
    };
    ObjectFile resolved_objects[] = {
        link_test_object_make(arguments->arena, target, (ByteSlice){0}, &unknown_reference, 1, 0, 0),
        link_test_object_make(arguments->arena, target, (ByteSlice){0}, &thread_local_definition, 1, 0, 0),
    };
    resolved_objects[1].sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(thread_local_data);
    resolved_objects[1].sections[OBJECT_SECTION_THREAD_LOCAL_DATA].virtual_size = sizeof(thread_local_data);
    LinkObjectResult resolved = link_objects(arguments->arena, resolved_objects, BUSTER_ARRAY_LENGTH(resolved_objects), (LinkOptions){0});
    BUSTER_TEST(arguments, resolved.error == LINK_ERROR_NONE && resolved.object.symbol_count == 1);
    if (resolved.error == LINK_ERROR_NONE && resolved.object.symbol_count == 1)
    {
        BUSTER_TEST(arguments, resolved.object.symbols[0].section == OBJECT_SECTION_THREAD_LOCAL_DATA);
        BUSTER_TEST(arguments, resolved.object.symbols[0].thread_local_state == OBJECT_SYMBOL_THREAD_LOCAL_YES);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_coff_comdat_selection(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Arena* arena = arena_create((ArenaCreation){0});
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS};
    {
        u8 left_bytes[] = {0x11, 0x12};
        u8 right_bytes[] = {0x21, 0x22};
        ObjectSymbol left_symbols[] = {{.name = S8("same"), .size = 2, .section = OBJECT_SECTION_TEXT,
                                        .kind = OBJECT_SYMBOL_FUNCTION, .global = true}};
        ObjectSymbol right_symbols[] = {{.name = S8("same"), .size = 2, .section = OBJECT_SECTION_TEXT,
                                         .kind = OBJECT_SYMBOL_FUNCTION, .global = true}};
        ObjectFile objects[] = {
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(left_bytes), S8("same"), OBJECT_COMDAT_SELECTION_SAME_SIZE,
                                    left_symbols, BUSTER_ARRAY_LENGTH(left_symbols), 0, 0),
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(right_bytes), S8("same"), OBJECT_COMDAT_SELECTION_SAME_SIZE,
                                    right_symbols, BUSTER_ARRAY_LENGTH(right_symbols), 0, 0),
        };
        LinkObjectResult linked = link_objects(arena, objects, BUSTER_ARRAY_LENGTH(objects), (LinkOptions){0});
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
        u32 symbol = link_test_comdat_symbol_find(&linked.object, S8("same"));
        BUSTER_TEST(arguments, symbol != UINT32_MAX && linked.object.symbols[symbol].size == 2 &&
                               linked.object.sections[OBJECT_SECTION_TEXT].data.pointer[linked.object.symbols[symbol].value] == 0x11);
        arena_reset_to_start(arena);
    }
    {
        u8 left_bytes[] = {1};
        u8 right_bytes[] = {2, 3};
        ObjectSymbol left_symbols[] = {{.name = S8("same_size_bad"), .size = 1, .section = OBJECT_SECTION_TEXT,
                                        .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectSymbol right_symbols[] = {{.name = S8("same_size_bad"), .size = 2, .section = OBJECT_SECTION_TEXT,
                                         .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectFile objects[] = {
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(left_bytes), S8("same_size_bad"), OBJECT_COMDAT_SELECTION_SAME_SIZE,
                                    left_symbols, 1, 0, 0),
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(right_bytes), S8("same_size_bad"), OBJECT_COMDAT_SELECTION_SAME_SIZE,
                                    right_symbols, 1, 0, 0),
        };
        LinkObjectResult linked = link_objects(arena, objects, 2, (LinkOptions){0});
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_COMDAT_SIZE_MISMATCH && string_equal(linked.symbol, S8("same_size_bad")));
        arena_reset_to_start(arena);
    }
    {
        u8 left_bytes[] = {4, 5};
        u8 right_bytes[] = {4, 6};
        ObjectSymbol left_symbols[] = {{.name = S8("exact_bad"), .size = 2, .section = OBJECT_SECTION_TEXT,
                                        .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectSymbol right_symbols[] = {{.name = S8("exact_bad"), .size = 2, .section = OBJECT_SECTION_TEXT,
                                         .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectFile objects[] = {
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(left_bytes), S8("exact_bad"), OBJECT_COMDAT_SELECTION_EXACT_MATCH,
                                    left_symbols, 1, 0, 0),
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(right_bytes), S8("exact_bad"), OBJECT_COMDAT_SELECTION_EXACT_MATCH,
                                    right_symbols, 1, 0, 0),
        };
        LinkObjectResult linked = link_objects(arena, objects, 2, (LinkOptions){0});
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_COMDAT_EXACT_MATCH && string_equal(linked.symbol, S8("exact_bad")));
        arena_reset_to_start(arena);
    }
    {
        u8 bytes[] = {0, 0, 0, 0};
        ObjectSymbol left_symbols[] = {
            {.name = S8("exact_reloc"), .size = 4, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_DATA, .global = true},
            {.name = S8("target_a"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
        };
        ObjectSymbol right_symbols[] = {
            {.name = S8("exact_reloc"), .size = 4, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_DATA, .global = true},
            {.name = S8("target_b"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
        };
        ObjectRelocation left_relocations[] = {{.section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE32}};
        ObjectRelocation right_relocations[] = {{.section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE32}};
        ObjectFile objects[] = {
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(bytes), S8("exact_reloc"), OBJECT_COMDAT_SELECTION_EXACT_MATCH,
                                    left_symbols, 2, left_relocations, 1),
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(bytes), S8("exact_reloc"), OBJECT_COMDAT_SELECTION_EXACT_MATCH,
                                    right_symbols, 2, right_relocations, 1),
        };
        LinkObjectResult linked = link_objects(arena, objects, 2, (LinkOptions){.allow_undefined_symbols = true});
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_COMDAT_EXACT_MATCH);
        arena_reset_to_start(arena);
    }
    for (u32 order = 0; order < 2; order += 1)
    {
        u8 small_bytes[] = {0x31};
        u8 large_bytes[] = {0x42, 0x43, 0x44};
        ObjectSymbol small_symbols[] = {{.name = S8("largest"), .size = 1, .section = OBJECT_SECTION_TEXT,
                                         .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectSymbol large_symbols[] = {{.name = S8("largest"), .size = 3, .section = OBJECT_SECTION_TEXT,
                                         .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectFile small = link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(small_bytes), S8("largest"), OBJECT_COMDAT_SELECTION_LARGEST,
                                                    small_symbols, 1, 0, 0);
        ObjectFile large = link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(large_bytes), S8("largest"), OBJECT_COMDAT_SELECTION_LARGEST,
                                                    large_symbols, 1, 0, 0);
        ObjectFile objects[2] = {order ? large : small, order ? small : large};
        LinkObjectResult linked = link_objects(arena, objects, 2, (LinkOptions){0});
        u32 symbol = link_test_comdat_symbol_find(&linked.object, S8("largest"));
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE && symbol != UINT32_MAX && linked.object.symbols[symbol].size == 3);
        if (linked.error == LINK_ERROR_NONE && symbol != UINT32_MAX)
        {
            BUSTER_TEST(arguments, linked.object.sections[OBJECT_SECTION_TEXT].data.pointer[linked.object.symbols[symbol].value] == 0x42);
        }
        arena_reset_to_start(arena);
    }
    {
        u8 left_bytes[] = {0x51, 0xa1};
        u8 right_bytes[] = {0x62, 0x63, 0xb2};
        ObjectSymbol left_symbols[] = {
            {.name = S8("assoc_parent"), .size = 1, .section = OBJECT_SECTION_TEXT, .comdat = 1,
             .kind = OBJECT_SYMBOL_DATA, .global = true, .weak = true},
            {.name = S8("assoc_child"), .value = 1, .size = 1, .section = OBJECT_SECTION_TEXT, .comdat = 2,
             .kind = OBJECT_SYMBOL_DATA, .global = true, .weak = true},
            {.name = S8("loser_target"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
        };
        ObjectSymbol right_symbols[] = {
            {.name = S8("assoc_parent"), .size = 2, .section = OBJECT_SECTION_TEXT, .comdat = 1,
             .kind = OBJECT_SYMBOL_DATA, .global = true, .weak = true},
            {.name = S8("assoc_child"), .value = 2, .size = 1, .section = OBJECT_SECTION_TEXT, .comdat = 2,
             .kind = OBJECT_SYMBOL_DATA, .global = true, .weak = true},
            {.name = S8("winner_target"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
        };
        ObjectRelocation left_relocations[] = {{.offset = 1, .section = OBJECT_SECTION_TEXT, .symbol = 2, .comdat = 2,
                                                 .kind = OBJECT_RELOCATION_ABSOLUTE32}};
        ObjectRelocation right_relocations[] = {{.offset = 2, .section = OBJECT_SECTION_TEXT, .symbol = 2, .comdat = 2,
                                                  .kind = OBJECT_RELOCATION_ABSOLUTE32}};
        ObjectComdat left_comdats[] = {
            {.key = S8("assoc_parent"), .size = 1, .section = OBJECT_SECTION_TEXT, .associated = OBJECT_COMDAT_ASSOCIATED_NONE,
             .selection = OBJECT_COMDAT_SELECTION_LARGEST},
            {.offset = 1, .size = 1, .section = OBJECT_SECTION_TEXT, .associated = 0, .first_relocation = 0, .relocation_count = 1,
             .selection = OBJECT_COMDAT_SELECTION_ASSOCIATIVE},
        };
        ObjectComdat right_comdats[] = {
            {.key = S8("assoc_parent"), .size = 2, .section = OBJECT_SECTION_TEXT, .associated = OBJECT_COMDAT_ASSOCIATED_NONE,
             .selection = OBJECT_COMDAT_SELECTION_LARGEST},
            {.offset = 2, .size = 1, .section = OBJECT_SECTION_TEXT, .associated = 0, .first_relocation = 0, .relocation_count = 1,
             .selection = OBJECT_COMDAT_SELECTION_ASSOCIATIVE},
        };
        ObjectFile objects[] = {
            link_test_comdat_object(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(left_bytes), left_symbols, 3, left_relocations, 1, left_comdats, 2),
            link_test_comdat_object(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(right_bytes), right_symbols, 3, right_relocations, 1, right_comdats, 2),
        };
        LinkObjectResult linked = link_objects(arena, objects, 2, (LinkOptions){.allow_undefined_symbols = true});
        u32 child = link_test_comdat_symbol_find(&linked.object, S8("assoc_child"));
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE && child != UINT32_MAX && linked.object.relocation_count == 1);
        if (linked.error == LINK_ERROR_NONE && child != UINT32_MAX)
        {
            BUSTER_TEST(arguments, linked.object.sections[OBJECT_SECTION_TEXT].data.pointer[linked.object.symbols[child].value] == 0xb2);
            ObjectRelocation relocation = linked.object.relocations[0];
            BUSTER_TEST(arguments, string_equal(linked.object.symbols[relocation.symbol].name, S8("winner_target")));
        }
        arena_reset_to_start(arena);
    }
    {
        u8 bytes[] = {1};
        ObjectSymbol left_symbols[] = {{.name = S8("mode_bad"), .size = 1, .section = OBJECT_SECTION_TEXT,
                                        .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectSymbol right_symbols[] = {{.name = S8("mode_bad"), .size = 1, .section = OBJECT_SECTION_TEXT,
                                         .kind = OBJECT_SYMBOL_DATA, .global = true}};
        ObjectFile objects[] = {
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(bytes), S8("mode_bad"), OBJECT_COMDAT_SELECTION_ANY,
                                    left_symbols, 1, 0, 0),
            link_test_single_comdat(arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(bytes), S8("mode_bad"), OBJECT_COMDAT_SELECTION_LARGEST,
                                    right_symbols, 1, 0, 0),
        };
        LinkObjectResult linked = link_objects(arena, objects, 2, (LinkOptions){0});
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_COMDAT_SELECTION_MISMATCH);
        arena_reset_to_start(arena);
    }
    arena_destroy(arena, 1);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_initializer_order(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u32 counts[] = {0, 1, 2, 17, 17, 18, 4097};
    u32 sparse[] = {UINT32_MAX, 0x01000000, 256, 0, 65536, 1, UINT32_MAX, 0x80000000, 0x00ffffff,
                    257, 65535, 255, 0x7fffffff, 0x01000001, 256, 65536, 1, 0};
    Arena* arena = arena_create((ArenaCreation){0});
    for (u32 shape = 0; shape < BUSTER_ARRAY_LENGTH(counts); shape += 1)
    {
        u32 count = counts[shape];
        u32* priorities = arena_allocate(arena, u32, count);
        u32* destinations = arena_allocate(arena, u32, count);
        for (u32 entry = 0; entry < count; entry += 1)
        {
            priorities[entry] = shape == 4 ? UINT32_MAX : shape == 5 ? sparse[entry] : shape == 6 ? count - entry : entry;
            destinations[entry] = shape == 6 ? count - entry - 1 : entry;
        }
        // Independent stable-rank oracle for sparse priorities: exercise all
        // four key bytes, unsigned ordering, repeated keys and the NONE sentinel.
        if (shape == 5)
        {
            for (u32 entry = 0; entry < count; entry += 1)
            {
                u32 rank = 0;
                for (u32 other = 0; other < count; other += 1)
                {
                    rank += priorities[other] < priorities[entry] || (priorities[other] == priorities[entry] && other < entry);
                }
                destinations[entry] = rank;
            }
        }
        u8 text[8] = {0};
        u32 text_symbol = 2 * count + 2;
        ObjectSymbol* symbols = arena_allocate(arena, ObjectSymbol, text_symbol + 1);
        ObjectRelocation* relocations = arena_allocate(arena, ObjectRelocation, 2 * count + 1);
        ObjectFile object = link_test_object_make(arena, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
                                                  (ByteSlice)BUSTER_ARRAY_TO_SLICE(text), symbols, text_symbol + 1,
                                                  relocations, 2 * count + 1);
        for (u32 slot = 0; slot < 2; slot += 1)
        {
            ObjectSectionKind kind = slot ? OBJECT_SECTION_FINI_ARRAY : OBJECT_SECTION_INIT_ARRAY;
            u8* data = arena_allocate(arena, u8, (u64)count * OBJECT_INITIALIZER_ENTRY_SIZE);
            object.sections[kind].data = (ByteSlice){.pointer = data, .length = (u64)count * OBJECT_INITIALIZER_ENTRY_SIZE};
            object.initializer_priorities[slot] = priorities;
            for (u32 entry = 0; entry < count; entry += 1)
            {
                u64 value = UINT64_C(0x0101010101010101) * (entry + 1) ^ ((u64)slot << 63);
                memcpy(data + (u64)entry * OBJECT_INITIALIZER_ENTRY_SIZE, &value, sizeof(value));
                symbols[slot * count + entry] = (ObjectSymbol){
                    .name = S8("array_entry"), .section = (u32)kind, .kind = OBJECT_SYMBOL_DATA,
                    .value = (u64)entry * OBJECT_INITIALIZER_ENTRY_SIZE + entry % OBJECT_INITIALIZER_ENTRY_SIZE, .size = 1,
                };
                relocations[slot * count + entry] = (ObjectRelocation){
                    .section = (u32)kind, .symbol = text_symbol, .kind = OBJECT_RELOCATION_ABSOLUTE32,
                    .offset = (u64)entry * OBJECT_INITIALIZER_ENTRY_SIZE + entry % 5, .addend = -(s64)entry,
                };
            }
            symbols[2 * count + slot] = (ObjectSymbol){
                .name = S8("array_end"), .section = (u32)kind, .kind = OBJECT_SYMBOL_DATA,
                .value = (u64)count * OBJECT_INITIALIZER_ENTRY_SIZE,
            };
        }
        symbols[text_symbol] = (ObjectSymbol){.name = S8("text"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .value = 1};
        relocations[2 * count] = (ObjectRelocation){.section = OBJECT_SECTION_TEXT, .symbol = text_symbol,
                                                    .kind = OBJECT_RELOCATION_ABSOLUTE32, .offset = 2, .addend = -7};
        LinkObjectResult linked = link_objects(arena, &object, 1, (LinkOptions){0});
        BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
        if (linked.error == LINK_ERROR_NONE)
        {
            BUSTER_TEST(arguments, linked.object.symbol_count == object.symbol_count);
            BUSTER_TEST(arguments, linked.object.relocation_count == object.relocation_count);
            for (u32 slot = 0; slot < 2; slot += 1)
            {
                ObjectSectionKind kind = slot ? OBJECT_SECTION_FINI_ARRAY : OBJECT_SECTION_INIT_ARRAY;
                BUSTER_TEST(arguments, linked.object.sections[kind].data.length == object.sections[kind].data.length);
                BUSTER_TEST(arguments, linked.object.symbols[2 * count + slot].value == (u64)count * OBJECT_INITIALIZER_ENTRY_SIZE);
                for (u32 entry = 0; entry < count; entry += 1)
                {
                    u32 destination = destinations[entry];
                    u64 value = 0;
                    memcpy(&value, linked.object.sections[kind].data.pointer + (u64)destination * OBJECT_INITIALIZER_ENTRY_SIZE, sizeof(value));
                    BUSTER_TEST(arguments, value == (UINT64_C(0x0101010101010101) * (entry + 1) ^ ((u64)slot << 63)));
                    BUSTER_TEST(arguments, linked.object.initializer_priorities[slot][destination] == priorities[entry]);
                    ObjectSymbol symbol = linked.object.symbols[slot * count + entry];
                    ObjectRelocation relocation = linked.object.relocations[slot * count + entry];
                    BUSTER_TEST(arguments, symbol.section == (u32)kind && symbol.value == (u64)destination * OBJECT_INITIALIZER_ENTRY_SIZE + entry % OBJECT_INITIALIZER_ENTRY_SIZE);
                    BUSTER_TEST(arguments, relocation.section == (u32)kind && relocation.offset == (u64)destination * OBJECT_INITIALIZER_ENTRY_SIZE + entry % 5);
                    BUSTER_TEST(arguments, relocation.symbol == text_symbol && relocation.kind == OBJECT_RELOCATION_ABSOLUTE32 && relocation.addend == -(s64)entry);
                    // Linking must leave the input metadata and section bytes intact.
                    memcpy(&value, object.sections[kind].data.pointer + (u64)entry * OBJECT_INITIALIZER_ENTRY_SIZE, sizeof(value));
                    BUSTER_TEST(arguments, value == (UINT64_C(0x0101010101010101) * (entry + 1) ^ ((u64)slot << 63)));
                    BUSTER_TEST(arguments, symbols[slot * count + entry].value == (u64)entry * OBJECT_INITIALIZER_ENTRY_SIZE + entry % OBJECT_INITIALIZER_ENTRY_SIZE);
                    BUSTER_TEST(arguments, relocations[slot * count + entry].offset == (u64)entry * OBJECT_INITIALIZER_ENTRY_SIZE + entry % 5);
                }
            }
            BUSTER_TEST(arguments, linked.object.symbols[text_symbol].section == OBJECT_SECTION_TEXT && linked.object.symbols[text_symbol].value == 1);
            ObjectRelocation text_relocation = linked.object.relocations[2 * count];
            BUSTER_TEST(arguments, text_relocation.section == OBJECT_SECTION_TEXT && text_relocation.offset == 2 &&
                                   text_relocation.symbol == text_symbol && text_relocation.addend == -7);
        }
        arena_reset_to_start(arena);
    }
    arena_destroy(arena, 1);
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_single_input_alias(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u8 text[] = {0x55, 0x48, 0x89, 0xe5, 0x5d, 0xc3};
    ObjectSymbol symbol = {
        .name = S8("single_input_alias"),
        .size = sizeof(text),
        .section = OBJECT_SECTION_TEXT,
        .kind = OBJECT_SYMBOL_FUNCTION,
    };
    ObjectFile object = link_test_object_make(
        arguments->arena, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        (ByteSlice)BUSTER_ARRAY_TO_SLICE(text), &symbol, 1, 0, 0);
    LinkObjectResult copied = link_objects(arguments->arena, &object, 1, (LinkOptions){0});
    BUSTER_TEST(arguments, copied.error == LINK_ERROR_NONE);
    if (copied.error == LINK_ERROR_NONE)
    {
        BUSTER_TEST(arguments, copied.object.sections[OBJECT_SECTION_TEXT].data.pointer != text);
        BUSTER_TEST(arguments, copied.object.sections[OBJECT_SECTION_TEXT].data.length == sizeof(text));
        BUSTER_TEST(arguments, memcmp(copied.object.sections[OBJECT_SECTION_TEXT].data.pointer, text, sizeof(text)) == 0);
    }
    LinkObjectResult aliased = link_objects(
        arguments->arena, &object, 1, (LinkOptions){.alias_single_input_sections = true});
    BUSTER_TEST(arguments, aliased.error == LINK_ERROR_NONE);
    if (aliased.error == LINK_ERROR_NONE)
    {
        BUSTER_TEST(arguments, aliased.object.sections[OBJECT_SECTION_TEXT].data.pointer == text);
        BUSTER_TEST(arguments, aliased.object.symbols != object.symbols);
        BUSTER_TEST(arguments, aliased.object.symbol_count == 1 && string_equal(aliased.object.symbols[0].name, symbol.name));
    }

    ObjectFile virtual_tail = object;
    ObjectSection* virtual_sections = arena_allocate(arguments->arena, ObjectSection, object.section_count);
    memcpy(virtual_sections, object.sections, object.section_count * sizeof(*virtual_sections));
    virtual_tail.sections = virtual_sections;
    virtual_tail.sections[OBJECT_SECTION_TEXT].virtual_size = sizeof(text) + 4;
    LinkObjectResult padded = link_objects(
        arguments->arena, &virtual_tail, 1, (LinkOptions){.alias_single_input_sections = true});
    BUSTER_TEST(arguments, padded.error == LINK_ERROR_NONE);
    if (padded.error == LINK_ERROR_NONE)
    {
        ObjectSection* section = padded.object.sections + OBJECT_SECTION_TEXT;
        BUSTER_TEST(arguments, section->data.pointer != text && section->data.length == sizeof(text) + 4);
        BUSTER_TEST(arguments, memcmp(section->data.pointer, text, sizeof(text)) == 0);
        BUSTER_TEST(arguments, section->data.pointer[sizeof(text)] == 0 && section->data.pointer[sizeof(text) + 3] == 0);
    }

    u8 first_text[] = {1, 2, 3};
    u8 second_text[] = {4, 5};
    ObjectFile inputs[] = {
        link_test_object_make(arguments->arena, object.target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(first_text), 0, 0, 0, 0),
        link_test_object_make(arguments->arena, object.target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(second_text), 0, 0, 0, 0),
    };
    inputs[0].sections[OBJECT_SECTION_TEXT].alignment = 1;
    inputs[1].sections[OBJECT_SECTION_TEXT].alignment = 1;
    LinkObjectResult merged = link_objects(
        arguments->arena, inputs, BUSTER_ARRAY_LENGTH(inputs), (LinkOptions){.alias_single_input_sections = true});
    BUSTER_TEST(arguments, merged.error == LINK_ERROR_NONE);
    if (merged.error == LINK_ERROR_NONE)
    {
        ObjectSection* section = merged.object.sections + OBJECT_SECTION_TEXT;
        u8 expected[] = {1, 2, 3, 4, 5};
        BUSTER_TEST(arguments, section->data.pointer != first_text && section->data.pointer != second_text);
        BUSTER_TEST(arguments, section->data.length == sizeof(expected));
        BUSTER_TEST(arguments, memcmp(section->data.pointer, expected, sizeof(expected)) == 0);
    }
    return result;
}

#if BUSTER_CPU_ARCH_X86_64
BUSTER_GLOBAL_LOCAL u32 link_test_symbol_find(ObjectFile* object, String8 name)
{
    for (u32 symbol_index = 0; object && symbol_index < object->symbol_count; symbol_index += 1)
    {
        if (string_equal(object->symbols[symbol_index].name, name))
        {
            return symbol_index;
        }
    }
    return UINT32_MAX;
}
#endif

BUSTER_GLOBAL_LOCAL String8 link_test_symbol_name_write(char8* destination, u32 value)
{
    static char8 const hexadecimal[] = "0123456789abcdef";
    destination[0] = 's';
    for (u32 digit = 0; digit < 8; digit += 1)
    {
        u32 shift = (7 - digit) * 4;
        destination[digit + 1] = hexadecimal[(value >> shift) & 15];
    }
    return (String8){.pointer = destination, .length = 9};
}

BUSTER_GLOBAL_LOCAL bool link_test_elf_section_find(ByteSlice image, String8 name, u32* section_index, u64* section_header)
{
    if (image.length >= 64 && image.pointer[0] == 0x7f && image.pointer[1] == 'E' && image.pointer[2] == 'L' && image.pointer[3] == 'F')
    {
        u64 table_offset = link_read_u64(image.pointer, 40);
        u16 header_size = 0;
        u16 section_count = 0;
        u16 string_index = 0;
        memcpy(&header_size, image.pointer + 58, sizeof(header_size));
        memcpy(&section_count, image.pointer + 60, sizeof(section_count));
        memcpy(&string_index, image.pointer + 62, sizeof(string_index));
        if (!table_offset || header_size < 64 || string_index >= section_count || table_offset > image.length ||
            (u64)section_count > (image.length - table_offset) / header_size)
        {
            return false;
        }
        u64 string_header = table_offset + (u64)string_index * header_size;
        u64 string_offset = link_read_u64(image.pointer, string_header + 24);
        u64 string_size = link_read_u64(image.pointer, string_header + 32);
        if (string_offset <= image.length && string_size <= image.length - string_offset)
        {
            for (u32 index = 1; index < section_count; index += 1)
            {
                u64 header = table_offset + (u64)index * header_size;
                u32 name_offset = link_read_u32(image.pointer, header);
                if (name_offset >= string_size)
                {
                    continue;
                }
                u64 length = 0;
                while ((u64)name_offset + length < string_size && image.pointer[string_offset + name_offset + length])
                {
                    length += 1;
                }
                if ((u64)name_offset + length < string_size && string_equal(
                                                                      (String8){
                                                                          .pointer = (char8*)image.pointer + string_offset + name_offset,
                                                                          .length = length,
                                                                      },
                                                                      name))
                {
                    if (section_index)
                    {
                        *section_index = index;
                    }
                    if (section_header)
                    {
                        *section_header = header;
                    }
                    return true;
                }
            }
        }
    }

    return false;
}

typedef struct LinkTestElfSymbol LinkTestElfSymbol;
struct LinkTestElfSymbol
{
    u64 value;
    u64 size;
    u32 index;
    u16 section;
    u8 info;
    u8 other;
};

// One ordinary (non-dynamic) symbol of a linked ELF image, by name.  The
// section table itself supplies the relationship between .symtab and .strtab;
// a same-named string in an unrelated table cannot satisfy this lookup.
BUSTER_GLOBAL_LOCAL bool link_test_elf_symbol(ByteSlice image, String8 name, LinkTestElfSymbol* symbol)
{
    bool result = false;
    u32 string_index = 0;
    u64 symbol_header = 0;
    u64 string_header = 0;
    if (link_test_elf_section_find(image, S8(".symtab"), 0, &symbol_header) &&
        link_test_elf_section_find(image, S8(".strtab"), &string_index, &string_header) &&
        link_read_u32(image.pointer, symbol_header + 4) == 2 && link_read_u32(image.pointer, symbol_header + 40) == string_index &&
        link_read_u64(image.pointer, symbol_header + 56) == 24)
    {
        u64 table_offset = link_read_u64(image.pointer, symbol_header + 24);
        u64 table_size = link_read_u64(image.pointer, symbol_header + 32);
        u64 string_offset = link_read_u64(image.pointer, string_header + 24);
        u64 string_size = link_read_u64(image.pointer, string_header + 32);
        if (table_offset <= image.length && table_size <= image.length - table_offset && table_size % 24 == 0 && string_offset <= image.length &&
            string_size <= image.length - string_offset)
        {
            for (u64 entry = 24; !result && entry + 24 <= table_size; entry += 24)
            {
                u32 name_offset = link_read_u32(image.pointer, table_offset + entry);
                if (!name_offset || name_offset >= string_size)
                {
                    continue;
                }
                u64 length = 0;
                while ((u64)name_offset + length < string_size && image.pointer[string_offset + name_offset + length])
                {
                    length += 1;
                }
                if ((u64)name_offset + length < string_size && string_equal(
                                                                      (String8){
                                                                          .pointer = (char8*)image.pointer + string_offset + name_offset,
                                                                          .length = length,
                                                                      },
                                                                      name))
                {
                    *symbol = (LinkTestElfSymbol){
                        .value = link_read_u64(image.pointer, table_offset + entry + 8),
                        .size = link_read_u64(image.pointer, table_offset + entry + 16),
                        .index = (u32)(entry / 24),
                        .info = image.pointer[table_offset + entry + 4],
                        .other = image.pointer[table_offset + entry + 5],
                    };
                    memcpy(&symbol->section, image.pointer + table_offset + entry + 6, sizeof(symbol->section));
                    result = true;
                }
            }
        }
    }

    return result;
}

// One dynamic symbol of a linked ELF image, by name.  Copy relocations are
// checked through this: the alias set they define is a set of dynamic symbols
// at one address, which is not visible anywhere else in the image.
BUSTER_GLOBAL_LOCAL bool link_test_elf_dynamic_symbol(ByteSlice image, String8 name, u64* value, u64* size, u16* section)
{
    bool result = false;
    u64 symbol_header = 0;
    u64 string_header = 0;
    u64 symbol_offset = 0;
    u64 symbol_size = 0;
    u64 string_offset = 0;
    u64 string_size = 0;
    if (link_test_elf_section_find(image, S8(".dynsym"), 0, &symbol_header) && link_test_elf_section_find(image, S8(".dynstr"), 0, &string_header))
    {
        symbol_offset = link_read_u64(image.pointer, symbol_header + 24);
        symbol_size = link_read_u64(image.pointer, symbol_header + 32);
        string_offset = link_read_u64(image.pointer, string_header + 24);
        string_size = link_read_u64(image.pointer, string_header + 32);
        if (symbol_offset > image.length || symbol_size > image.length - symbol_offset || string_offset > image.length ||
            string_size > image.length - string_offset)
        {
            symbol_size = 0;
        }
    }
    for (u64 entry = 0; !result && entry + 24 <= symbol_size; entry += 24)
    {
        u32 name_offset = link_read_u32(image.pointer, symbol_offset + entry);
        if (!name_offset || name_offset >= string_size)
        {
            continue;
        }
        u64 length = 0;
        while ((u64)name_offset + length < string_size && image.pointer[string_offset + name_offset + length])
        {
            length += 1;
        }
        String8 entry_name = {.pointer = (char8*)image.pointer + string_offset + name_offset, .length = length};
        if (!string_equal(entry_name, name))
        {
            continue;
        }
        if (value)
        {
            *value = link_read_u64(image.pointer, symbol_offset + entry + 8);
        }
        if (size)
        {
            *size = link_read_u64(image.pointer, symbol_offset + entry + 16);
        }
        if (section)
        {
            u16 entry_section = 0;
            memcpy(&entry_section, image.pointer + symbol_offset + entry + 6, sizeof(entry_section));
            *section = entry_section;
        }
        result = true;
    }

    return result;
}

// The value one dynamic array tag holds, read out of .dynamic.  False means
// the image does not publish that tag at all.
BUSTER_GLOBAL_LOCAL bool link_test_elf_dynamic_entry(ByteSlice image, u64 tag, u64* value)
{
    bool result = false;
    u64 header = 0;
    if (link_test_elf_section_find(image, S8(".dynamic"), 0, &header))
    {
        u64 offset = link_read_u64(image.pointer, header + 24);
        u64 size = link_read_u64(image.pointer, header + 32);
        for (u64 entry = 0; !result && entry + 16 <= size; entry += 16)
        {
            u64 entry_tag = link_read_u64(image.pointer, offset + entry);
            if (!entry_tag)
            {
                break;
            }
            if (entry_tag == tag)
            {
                if (value)
                {
                    *value = link_read_u64(image.pointer, offset + entry + 8);
                }
                result = true;
            }
        }
    }

    return result;
}

// The name a dynamic string table holds at one offset.
BUSTER_GLOBAL_LOCAL String8 link_test_elf_dynamic_string(ByteSlice image, u64 string_offset, u64 string_size, u32 name_offset)
{
    String8 result = {0};
    if (name_offset && name_offset < string_size)
    {
        u64 length = 0;
        while ((u64)name_offset + length < string_size && image.pointer[string_offset + name_offset + length])
        {
            length += 1;
        }
        result = (String8){.pointer = (char8*)image.pointer + string_offset + name_offset, .length = length};
    }

    return result;
}

// The symbol version an image records for one dynamic symbol, and the library
// it names that version from.  Three sections have to agree for a versioned
// reference to mean anything: .dynsym gives the symbol its index, .gnu.version
// gives that index a version number, and .gnu.version_r is where the number
// gets a name and a library.  False means the image binds the name without a
// version, which is what an unversioned library's symbols get.
BUSTER_GLOBAL_LOCAL bool link_test_elf_symbol_version(ByteSlice image, String8 name, String8* version, String8* library)
{
    bool result = false;
    u64 symbol_header = 0;
    u64 string_header = 0;
    u64 version_header = 0;
    u64 need_header = 0;
    if (!link_test_elf_section_find(image, S8(".dynsym"), 0, &symbol_header) || !link_test_elf_section_find(image, S8(".dynstr"), 0, &string_header) ||
        !link_test_elf_section_find(image, S8(".gnu.version"), 0, &version_header) || !link_test_elf_section_find(image, S8(".gnu.version_r"), 0, &need_header))
    {
        return result;
    }
    u64 symbol_offset = link_read_u64(image.pointer, symbol_header + 24);
    u64 symbol_size = link_read_u64(image.pointer, symbol_header + 32);
    u64 string_offset = link_read_u64(image.pointer, string_header + 24);
    u64 string_size = link_read_u64(image.pointer, string_header + 32);
    u64 version_offset = link_read_u64(image.pointer, version_header + 24);
    u64 version_size = link_read_u64(image.pointer, version_header + 32);
    u64 need_offset = link_read_u64(image.pointer, need_header + 24);
    u32 need_count = link_read_u32(image.pointer, need_header + 44);
    if (symbol_size / 24 != version_size / sizeof(u16))
    {
        return result;
    }
    u16 index = 0;
    for (u64 entry = 0; !index && entry + 24 <= symbol_size; entry += 24)
    {
        u32 name_offset = link_read_u32(image.pointer, symbol_offset + entry);
        if (string_equal(link_test_elf_dynamic_string(image, string_offset, string_size, name_offset), name))
        {
            memcpy(&index, image.pointer + version_offset + entry / 24 * sizeof(u16), sizeof(index));
        }
    }
    u64 need = need_offset;
    for (u32 need_index = 0; !result && need_index < need_count; need_index += 1)
    {
        u16 auxiliary_count = 0;
        u32 file_name = link_read_u32(image.pointer, need + 4);
        memcpy(&auxiliary_count, image.pointer + need + 2, sizeof(auxiliary_count));
        u64 auxiliary = need + link_read_u32(image.pointer, need + 8);
        for (u16 auxiliary_index = 0; !result && auxiliary_index < auxiliary_count; auxiliary_index += 1)
        {
            u16 other = 0;
            memcpy(&other, image.pointer + auxiliary + 6, sizeof(other));
            if (index && other == index)
            {
                if (version)
                {
                    *version = link_test_elf_dynamic_string(image, string_offset, string_size, link_read_u32(image.pointer, auxiliary + 8));
                }
                if (library)
                {
                    *library = link_test_elf_dynamic_string(image, string_offset, string_size, file_name);
                }
                result = true;
            }
            auxiliary += link_read_u32(image.pointer, auxiliary + 12);
        }
        need += link_read_u32(image.pointer, need + 12);
    }

    return result;
}

// What a PC-relative relocation in .text resolved to, read back out of the
// linked image: the field holds S - P + A, so the symbol address the linker
// decided on is the field plus this place and less the addend it was given.
// UINT64_MAX means the image has no .text to read, which no caller expects.
BUSTER_GLOBAL_LOCAL BUSTER_UNUSED_DECL u64 link_test_elf_relative_symbol_address(ByteSlice image, u64 text_offset, s64 addend)
{
    u64 result = UINT64_MAX;
    u64 header = 0;
    if (link_test_elf_section_find(image, S8(".text"), 0, &header))
    {
        u64 text_address = link_read_u64(image.pointer, header + 16);
        u64 text_file_offset = link_read_u64(image.pointer, header + 24);
        if (text_file_offset + text_offset + 4 <= image.length)
        {
            s32 field = 0;
            memcpy(&field, image.pointer + text_file_offset + text_offset, sizeof(field));
            result = (u64)((s64)text_address + (s64)text_offset + field - addend);
        }
    }
    return result;
}


// How many relocations of one type the image carries.  The ELF writer keeps
// its jump-slot and copy relocations in one `.rela.plt`.
BUSTER_GLOBAL_LOCAL u32 link_test_elf_relocation_count(ByteSlice image, u32 type)
{
    u32 result = 0;
    u64 relocation_header = 0;
    u64 offset = 0;
    u64 size = 0;
    if (link_test_elf_section_find(image, S8(".rela.plt"), 0, &relocation_header))
    {
        offset = link_read_u64(image.pointer, relocation_header + 24);
        size = link_read_u64(image.pointer, relocation_header + 32);
        if (offset > image.length || size > image.length - offset)
        {
            size = 0;
        }
    }
    for (u64 entry = 0; entry + 24 <= size; entry += 24)
    {
        result += (u32)(link_read_u64(image.pointer, offset + entry + 8) & 0xffffffff) == type;
    }

    return result;
}

// The same question for an AArch64 BL, whose displacement is a signed 26-bit
// word count rather than a byte field.
BUSTER_GLOBAL_LOCAL BUSTER_UNUSED_DECL u64 link_test_elf_branch_symbol_address(ByteSlice image, u64 text_offset)
{
    u64 result = UINT64_MAX;
    u64 header = 0;
    if (link_test_elf_section_find(image, S8(".text"), 0, &header))
    {
        u64 text_address = link_read_u64(image.pointer, header + 16);
        u64 text_file_offset = link_read_u64(image.pointer, header + 24);
        if (text_file_offset + text_offset + 4 <= image.length)
        {
            u32 instruction = link_read_u32(image.pointer, text_file_offset + text_offset);
            u32 immediate = instruction & UINT32_C(0x3ffffff);
            s64 words = immediate >= UINT32_C(0x2000000) ? (s64)immediate - (s64)UINT32_C(0x4000000) : (s64)immediate;
            result = (u64)((s64)text_address + (s64)text_offset + words * 4);
        }
    }
    return result;
}


BUSTER_GLOBAL_LOCAL bool link_test_mach_section_find(ByteSlice image, String8 segment_name, String8 section_name, u64* section_header)
{
    if (image.length >= 32 && link_read_u32(image.pointer, 0) == 0xfeedfacf)
    {
        u32 command_count = link_read_u32(image.pointer, 16);
        u64 command = 32;
        for (u32 command_index = 0; command_index < command_count; command_index += 1)
        {
            if (command > image.length || 8 > image.length - command)
            {
                return false;
            }
            u32 kind = link_read_u32(image.pointer, command);
            u32 size = link_read_u32(image.pointer, command + 4);
            if (size < 8 || size > image.length - command)
            {
                return false;
            }
            if (kind == 0x19 && size >= 72)
            {
                u32 section_count = link_read_u32(image.pointer, command + 64);
                if ((u64)section_count > (size - 72) / 80)
                {
                    return false;
                }
                for (u32 index = 0; index < section_count; index += 1)
                {
                    u64 section = command + 72 + (u64)index * 80;
                    String8 candidate_section = {.pointer = (char8*)image.pointer + section, .length = 0};
                    String8 candidate_segment = {.pointer = (char8*)image.pointer + section + 16, .length = 0};
                    while (candidate_section.length < 16 && candidate_section.pointer[candidate_section.length])
                    {
                        candidate_section.length += 1;
                    }
                    while (candidate_segment.length < 16 && candidate_segment.pointer[candidate_segment.length])
                    {
                        candidate_segment.length += 1;
                    }
                    if (string_equal(candidate_segment, segment_name) && string_equal(candidate_section, section_name))
                    {
                        if (section_header)
                        {
                            *section_header = section;
                        }
                        return true;
                    }
                }
            }
            command += size;
        }
    }

    return false;
}

// dyld will not read the fixups of an image whose __LINKEDIT blobs are
// mis-aligned or out of order: `dyld_info` answers "mis-aligned LINKEDIT
// content 'bind opcodes'" instead of the table, and a signing pass reads the
// same layout.  Every blob but the string table starts on an eight-byte
// boundary, each one lies inside the segment, and none overlaps its
// neighbour.  Blobs carry their own sizes, so the gaps that alignment leaves
// are read by nothing.
BUSTER_GLOBAL_LOCAL UnitTestResult link_test_mach_linkedit_layout(UnitTestArguments* arguments, ByteSlice image, bool expect_fixups, bool* bind_padded)
{
    UnitTestResult result = {0};
    u64 linkedit_offset = 0;
    u64 linkedit_size = 0;
    u64 rebase_offset = 0;
    u64 rebase_size = 0;
    u64 bind_offset = 0;
    u64 bind_size = 0;
    u64 symbol_table_offset = 0;
    u64 symbol_table_size = 0;
    u64 string_table_offset = 0;
    u64 string_table_size = 0;
    u64 signature_offset = 0;
    u64 signature_size = 0;
    bool mach_header_valid = image.length >= 32 && link_read_u32(image.pointer, 0) == 0xfeedfacf;
    BUSTER_TEST(arguments, mach_header_valid);
    u32 command_count = mach_header_valid ? link_read_u32(image.pointer, 16) : 0;
    u64 command = 32;
    for (u32 command_index = 0; command_index < command_count && command + 8 <= image.length; command_index += 1)
    {
        u32 kind = link_read_u32(image.pointer, command);
        u32 size = link_read_u32(image.pointer, command + 4);
        if (size < 8 || size > image.length - command)
        {
            break;
        }
        if (kind == 0x19 && size >= 72 && memcmp(image.pointer + command + 8, "__LINKEDIT", 11) == 0)
        {
            linkedit_offset = link_read_u64(image.pointer, command + 40);
            linkedit_size = link_read_u64(image.pointer, command + 48);
        }
        if (kind == 0x80000022 && size >= 24)
        {
            rebase_offset = link_read_u32(image.pointer, command + 8);
            rebase_size = link_read_u32(image.pointer, command + 12);
            bind_offset = link_read_u32(image.pointer, command + 16);
            bind_size = link_read_u32(image.pointer, command + 20);
        }
        if (kind == 0x2 && size >= 24)
        {
            symbol_table_offset = link_read_u32(image.pointer, command + 8);
            symbol_table_size = (u64)link_read_u32(image.pointer, command + 12) * 16;
            string_table_offset = link_read_u32(image.pointer, command + 16);
            string_table_size = link_read_u32(image.pointer, command + 20);
        }
        if (kind == 0x1d && size >= 16)
        {
            signature_offset = link_read_u32(image.pointer, command + 8);
            signature_size = link_read_u32(image.pointer, command + 12);
        }
        command += size;
    }
    BUSTER_TEST(arguments, linkedit_offset && linkedit_size && signature_size);
    // The blob whose start the rebase stream's length used to decide.
    BUSTER_TEST(arguments, !expect_fixups || (rebase_size && bind_size));
    BUSTER_TEST(arguments, rebase_offset % 8 == 0);
    BUSTER_TEST(arguments, bind_offset % 8 == 0);
    BUSTER_TEST(arguments, symbol_table_offset % 8 == 0);
    BUSTER_TEST(arguments, signature_offset % 8 == 0);
    u64 blob_offsets[] = {rebase_offset, bind_offset, symbol_table_offset, string_table_offset, signature_offset};
    u64 blob_sizes[] = {rebase_size, bind_size, symbol_table_size, string_table_size, signature_size};
    u64 linkedit_end = linkedit_offset + linkedit_size;
    u64 blob_cursor = linkedit_offset;
    bool blobs_contained = linkedit_offset && linkedit_size && linkedit_end <= image.length;
    for (u32 blob_index = 0; blob_index < BUSTER_ARRAY_LENGTH(blob_offsets); blob_index += 1)
    {
        if (!blob_sizes[blob_index])
        {
            continue;
        }
        blobs_contained = blobs_contained && blob_offsets[blob_index] >= blob_cursor && blob_offsets[blob_index] <= linkedit_end &&
                          blob_sizes[blob_index] <= linkedit_end - blob_offsets[blob_index];
        blob_cursor = blob_offsets[blob_index] + blob_sizes[blob_index];
    }
    BUSTER_TEST(arguments, blobs_contained);
    if (bind_padded)
    {
        // The shape the refusal came from: a rebase stream that does not end
        // on a boundary, with bind opcodes behind it.
        *bind_padded = rebase_size && bind_size && (rebase_offset + rebase_size) % 8 != 0;
    }
    return result;
}

#if BUSTER_LINUX || BUSTER_WINDOWS || BUSTER_CPU_ARCH_X86_64
BUSTER_GLOBAL_LOCAL bool link_test_pe_section_find(ByteSlice image, String8 name, u32* virtual_address, u32* raw_offset)
{
    if (image.length >= 0x40 && image.pointer[0] == 'M' && image.pointer[1] == 'Z')
    {
        u32 pe_offset = link_read_u32(image.pointer, 0x3c);
        if (pe_offset <= image.length && image.length - pe_offset >= 24 && memcmp(image.pointer + pe_offset, "PE\0\0", 4) == 0)
        {
            u16 section_count = 0;
            u16 optional_size = 0;
            memcpy(&section_count, image.pointer + pe_offset + 6, sizeof(section_count));
            memcpy(&optional_size, image.pointer + pe_offset + 20, sizeof(optional_size));
            u64 section_table = (u64)pe_offset + 24 + optional_size;
            if (section_table <= image.length && (u64)section_count <= (image.length - section_table) / 40)
            {
                for (u16 section_index = 0; section_index < section_count; section_index += 1)
                {
                    u64 section = section_table + (u64)section_index * 40;
                    String8 candidate = {.pointer = (char8*)image.pointer + section, .length = 0};
                    while (candidate.length < 8 && candidate.pointer[candidate.length])
                    {
                        candidate.length += 1;
                    }
                    if (!string_equal(candidate, name))
                    {
                        continue;
                    }
                    if (virtual_address)
                    {
                        *virtual_address = link_read_u32(image.pointer, section + 12);
                    }
                    if (raw_offset)
                    {
                        *raw_offset = link_read_u32(image.pointer, section + 20);
                    }
                    return true;
                }
            }
        }
    }

    return false;
}
#endif

#if BUSTER_CPU_ARCH_X86_64 || (BUSTER_CPU_ARCH_AARCH64 && BUSTER_LINUX)
BUSTER_GLOBAL_LOCAL bool link_test_pe_import_matches(ByteSlice executable, String8 library, String8 symbol)
{
    if (executable.length >= 0x40 && executable.pointer[0] == 'M' && executable.pointer[1] == 'Z')
    {
        u32 pe_offset = link_read_u32(executable.pointer, 0x3c);
        if (pe_offset <= executable.length && executable.length - pe_offset >= 24 && memcmp(executable.pointer + pe_offset, "PE\0\0", 4) == 0)
        {
            u16 section_count = 0;
            u16 optional_size = 0;
            memcpy(&section_count, executable.pointer + pe_offset + 6, sizeof(section_count));
            memcpy(&optional_size, executable.pointer + pe_offset + 20, sizeof(optional_size));
            u64 optional = pe_offset + 24;
            if (optional <= executable.length && optional_size <= executable.length - optional && optional_size >= 128)
            {
                u32 import_rva = link_read_u32(executable.pointer, optional + 120);
                u32 import_size = link_read_u32(executable.pointer, optional + 124);
                if (import_size && !(import_size % 20))
                {
                    u64 section_table = optional + optional_size;
                    u64 import_offset = 0;
                    bool import_mapped = false;
                    for (u16 section_index = 0; section_index < section_count; section_index += 1)
                    {
                        u64 section = section_table + (u64)section_index * 40;
                        if (section > executable.length || 40 > executable.length - section)
                        {
                            return false;
                        }
                        u32 virtual_size = link_read_u32(executable.pointer, section + 8);
                        u32 virtual_address = link_read_u32(executable.pointer, section + 12);
                        u32 raw_size = link_read_u32(executable.pointer, section + 16);
                        u32 raw_offset = link_read_u32(executable.pointer, section + 20);
                        u64 span = BUSTER_MAX(virtual_size, raw_size);
                        if (import_rva >= virtual_address && (u64)import_rva - virtual_address < span)
                        {
                            import_offset = raw_offset + ((u64)import_rva - virtual_address);
                            import_mapped = import_offset < executable.length;
                            break;
                        }
                    }
                    if (import_mapped)
                    {
                        for (u32 descriptor_index = 0; descriptor_index < import_size / 20; descriptor_index += 1)
                        {
                            u64 descriptor = import_offset + (u64)descriptor_index * 20;
                            if (descriptor > executable.length || 20 > executable.length - descriptor)
                            {
                                return false;
                            }
                            u32 lookup_rva = link_read_u32(executable.pointer, descriptor);
                            u32 name_rva = link_read_u32(executable.pointer, descriptor + 12);
                            if (!lookup_rva && !name_rva)
                            {
                                return false;
                            }
                            u64 name_offset = 0;
                            u64 lookup_offset = 0;
                            bool name_mapped = false;
                            bool lookup_mapped = false;
                            for (u16 section_index = 0; section_index < section_count; section_index += 1)
                            {
                                u64 section = section_table + (u64)section_index * 40;
                                u32 virtual_size = link_read_u32(executable.pointer, section + 8);
                                u32 virtual_address = link_read_u32(executable.pointer, section + 12);
                                u32 raw_size = link_read_u32(executable.pointer, section + 16);
                                u32 raw_offset = link_read_u32(executable.pointer, section + 20);
                                u64 span = BUSTER_MAX(virtual_size, raw_size);
                                if (name_rva >= virtual_address && (u64)name_rva - virtual_address < span)
                                {
                                    name_offset = raw_offset + ((u64)name_rva - virtual_address);
                                    name_mapped = name_offset < executable.length;
                                }
                                if (lookup_rva >= virtual_address && (u64)lookup_rva - virtual_address < span)
                                {
                                    lookup_offset = raw_offset + ((u64)lookup_rva - virtual_address);
                                    lookup_mapped = lookup_offset < executable.length;
                                }
                            }
                            if (!name_mapped || !lookup_mapped)
                            {
                                return false;
                            }
                            u64 name_length = 0;
                            while (name_offset + name_length < executable.length && executable.pointer[name_offset + name_length])
                            {
                                name_length += 1;
                            }
                            if (name_offset + name_length >= executable.length || !string_equal(
                                                                                      (String8){
                                                                                          .pointer = (char8*)executable.pointer + name_offset,
                                                                                          .length = name_length,
                                                                                      },
                                                                                      library))
                            {
                                continue;
                            }
                            for (u32 thunk_index = 0; lookup_offset + (u64)thunk_index * 8 + sizeof(u64) <= executable.length; thunk_index += 1)
                            {
                                u64 name_entry = link_read_u64(executable.pointer, lookup_offset + (u64)thunk_index * 8);
                                if (!name_entry)
                                {
                                    return false;
                                }
                                if (name_entry >> 63)
                                {
                                    continue;
                                }
                                u64 symbol_offset = 0;
                                bool symbol_mapped = false;
                                for (u16 section_index = 0; section_index < section_count; section_index += 1)
                                {
                                    u64 section = section_table + (u64)section_index * 40;
                                    u32 virtual_size = link_read_u32(executable.pointer, section + 8);
                                    u32 virtual_address = link_read_u32(executable.pointer, section + 12);
                                    u32 raw_size = link_read_u32(executable.pointer, section + 16);
                                    u32 raw_offset = link_read_u32(executable.pointer, section + 20);
                                    u64 span = BUSTER_MAX(virtual_size, raw_size);
                                    if (name_entry >= virtual_address && name_entry - virtual_address < span)
                                    {
                                        symbol_offset = raw_offset + (name_entry - virtual_address) + 2;
                                        symbol_mapped = symbol_offset < executable.length;
                                        break;
                                    }
                                }
                                if (!symbol_mapped)
                                {
                                    return false;
                                }
                                u64 symbol_length = 0;
                                while (symbol_offset + symbol_length < executable.length && executable.pointer[symbol_offset + symbol_length])
                                {
                                    symbol_length += 1;
                                }
                                if (symbol_offset + symbol_length >= executable.length)
                                {
                                    return false;
                                }
                                if (string_equal(
                                        (String8){
                                            .pointer = (char8*)executable.pointer + symbol_offset,
                                            .length = symbol_length,
                                        },
                                        symbol))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return false;
}
#endif

BUSTER_GLOBAL_LOCAL void link_test_runtime_stack_walk_skip(UnitTestArguments* arguments, String8 reason)
{
    arguments->show(arguments, S8("SKIP runtime stack walk: {S8}\n"), reason);
}

#if !BUSTER_SANITIZE && !BUSTER_ANDROID && !BUSTER_IOS && (BUSTER_LINUX || BUSTER_MACOS || BUSTER_WINDOWS) && (BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64)
BUSTER_GLOBAL_LOCAL String8 link_test_runtime_stack_walk_source(Arena* arena)
{
#if BUSTER_WINDOWS && BUSTER_CPU_ARCH_AARCH64
    String8 parts[] = {
        S8("typedef unsigned long long RuntimeU64;"
              "typedef unsigned int RuntimeU32;"
              "extern unsigned short RtlCaptureStackBackTrace(unsigned long skip, unsigned long count, void** buffer, unsigned long* hash);"
              "typedef struct RuntimeFunction RuntimeFunction;"
              "struct RuntimeFunction { RuntimeU32 begin_address; RuntimeU32 unwind_data; };"
              "extern RuntimeFunction* RtlLookupFunctionEntry(RuntimeU64 control_pc, RuntimeU64* image_base, void* history);"
              "extern void* GetStdHandle(int standard_handle);"
              "extern int WriteFile(void* handle, void* buffer, unsigned long byte_count, unsigned long* written, void* overlapped);"
              "int main(void);"
              "static RuntimeU64 runtime_body_status; static RuntimeU64 runtime_large_body_status;"
              "static int runtime_unwind_body(void* function)"
              "{"
              "    RuntimeU64 image_base = 0;"
              "    RuntimeFunction* function_entry = RtlLookupFunctionEntry((RuntimeU64)function + 1, &image_base, 0);"
              "    return function_entry && image_base && function_entry->begin_address == (RuntimeU32)((RuntimeU64)function - image_base);"
              "}"
              "static void runtime_touch_bytes(unsigned char* bytes, int size)"
              "{ bytes[0] ^= 0x5a; bytes[size - 1] ^= 0xa5; }"
              "typedef __builtin_va_list va_list;"
              "int stack_walk_normal(void** buffer, int size, int marker, ...)"
              "{"
              "    int dynamic_size = marker + 157; unsigned char dynamic_padding[dynamic_size];"
              "    va_list arguments; __builtin_va_start(arguments, marker); int extra = __builtin_va_arg(arguments, int); __builtin_va_end(arguments);"
              "    RuntimeU64 pressure = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 + 11 + 12 + 13 + 14 + 15 + 16;"
              "    dynamic_padding[0] = (unsigned char)pressure; dynamic_padding[32] = (unsigned char)(pressure ^ 0x3c);"
              "    dynamic_padding[dynamic_size - 1] = (unsigned char)(pressure >> 8); runtime_touch_bytes(dynamic_padding, dynamic_size);"
              "    if (marker != 100 || extra != 23) return -1;"
              "    runtime_body_status = (RuntimeU64)runtime_unwind_body((void*)stack_walk_normal);"
              "    int count = (int)RtlCaptureStackBackTrace(0, (unsigned long)size, buffer, 0);"
              "    if (dynamic_padding[0] != (unsigned char)(pressure ^ 0x5a) || dynamic_padding[32] != (unsigned char)(pressure ^ 0x3c) ||"
              "        dynamic_padding[dynamic_size - 1] != (unsigned char)((pressure >> 8) ^ 0xa5)) return -2;"
              "    return count;"
              "}"),
        S8("typedef struct RuntimeBig RuntimeBig; struct RuntimeBig { RuntimeU64 first; RuntimeU64 second; RuntimeU64 third; };"
              "int stack_walk_large(void** buffer, int size, int first, int second, int third, RuntimeBig incoming)"
              "{"
              "    unsigned char padding[40000]; int dynamic_size = first + 256; unsigned char dynamic_padding[dynamic_size];"
              "    RuntimeU64 pressure = 17 + 18 + 19 + 20 + 21 + 22 + 23 + 24;"
              "    padding[0] = (unsigned char)pressure; padding[39999] = (unsigned char)(pressure >> 8);"
              "    dynamic_padding[0] = (unsigned char)pressure; dynamic_padding[32] = (unsigned char)(pressure ^ 0x3c);"
              "    dynamic_padding[dynamic_size - 1] = (unsigned char)(pressure >> 8); runtime_touch_bytes(dynamic_padding, dynamic_size);"
              "    if (first != 1 || second != 2 || third != 3 || incoming.first != 4 || incoming.second != 5 || incoming.third != 6) return -1;"
              "    runtime_large_body_status = (RuntimeU64)runtime_unwind_body((void*)stack_walk_large);"
              "    int count = (int)RtlCaptureStackBackTrace(0, (unsigned long)size, buffer, 0);"
              "    if (dynamic_padding[0] != (unsigned char)(pressure ^ 0x5a) || dynamic_padding[32] != (unsigned char)(pressure ^ 0x3c) ||"
              "        dynamic_padding[dynamic_size - 1] != (unsigned char)((pressure >> 8) ^ 0xa5) ||"
              "        padding[0] != (unsigned char)pressure || padding[39999] != (unsigned char)(pressure >> 8)) return -2;"
              "    return count;"
              "}"
              "typedef struct RuntimeReport RuntimeReport;"
              "struct RuntimeReport {"
              "    void* normal_entry; void* large_entry; void* main_entry; RuntimeU64 normal_count; RuntimeU64 large_count;"
              "    RuntimeU64 semantic_status; RuntimeU64 body_status; RuntimeU64 large_body_status;"
              "    RuntimeU64 epilog_status; RuntimeU64 epilog_unwind_pc; RuntimeU64 large_epilog_status; RuntimeU64 large_epilog_unwind_pc;"
              "    void* normal_frames[64]; void* large_frames[64];"
              "};"
              "int main(void)"
              "{"
              "    RuntimeReport report = {0};"
              "    report.normal_entry = (void*)stack_walk_normal; report.large_entry = (void*)stack_walk_large; report.main_entry = (void*)main;"
              "    int normal_count = stack_walk_normal(report.normal_frames, 64, 100, 23);"
              "    int large_count = stack_walk_large(report.large_frames, 64, 1, 2, 3, (RuntimeBig){4, 5, 6});"
              "    report.normal_count = normal_count > 0 ? (RuntimeU64)normal_count : 0;"
              "    report.large_count = large_count > 0 ? (RuntimeU64)large_count : 0;"
              "    report.semantic_status = large_count > 0 ? 0x535441434b434f50ULL : 0;"
              "    report.body_status = runtime_body_status; report.large_body_status = runtime_large_body_status;"
              "    unsigned long written = 0; WriteFile(GetStdHandle(-11), &report, sizeof(report), &written, 0);"
              "    return normal_count > 0 && large_count > 0 && report.semantic_status != 0 &&"
              "           report.body_status != 0 && report.large_body_status != 0 ? 0 : 1;"
              "}"),
    };
    return string_join_arena(arena, (SliceString8)BUSTER_ARRAY_TO_SLICE(parts), false);
#elif BUSTER_WINDOWS
    String8 parts[] = {
        S8("typedef unsigned long long RuntimeU64;"
              "typedef unsigned int RuntimeU32;"
              "typedef unsigned short RuntimeU16;"
              "extern unsigned short RtlCaptureStackBackTrace(unsigned long skip, unsigned long count, void** buffer, unsigned long* hash);"
              "typedef struct RuntimeContext RuntimeContext;"
              "struct RuntimeContext {"
              "    RuntimeU64 p1_home; RuntimeU64 p2_home; RuntimeU64 p3_home; RuntimeU64 p4_home; RuntimeU64 p5_home; RuntimeU64 p6_home;"
              "    RuntimeU32 context_flags; RuntimeU32 mxcsr;"
              "    RuntimeU16 seg_cs; RuntimeU16 seg_ds; RuntimeU16 seg_es; RuntimeU16 seg_fs; RuntimeU16 seg_gs; RuntimeU16 seg_ss;"
              "    RuntimeU32 eflags;"
              "    RuntimeU64 dr0; RuntimeU64 dr1; RuntimeU64 dr2; RuntimeU64 dr3; RuntimeU64 dr6; RuntimeU64 dr7;"
              "    RuntimeU64 rax; RuntimeU64 rcx; RuntimeU64 rdx; RuntimeU64 rbx; RuntimeU64 rsp; RuntimeU64 rbp; RuntimeU64 rsi; RuntimeU64 rdi;"
              "    RuntimeU64 r8; RuntimeU64 r9; RuntimeU64 r10; RuntimeU64 r11; RuntimeU64 r12; RuntimeU64 r13; RuntimeU64 r14; RuntimeU64 r15; RuntimeU64 rip;"
              "    RuntimeU64 extended[122];"
              "};"
              "typedef struct RuntimeFunction RuntimeFunction;"
              "struct RuntimeFunction { RuntimeU32 begin_address; RuntimeU32 end_address; RuntimeU32 unwind_data; };"
              "extern RuntimeFunction* RtlLookupFunctionEntry(RuntimeU64 control_pc, RuntimeU64* image_base, void* history);"
              "extern void RtlCaptureContext(RuntimeContext* context);"
              "extern void* RtlVirtualUnwind(unsigned long handler_type, RuntimeU64 image_base, RuntimeU64 control_pc, RuntimeFunction* function_entry,"
              "                                 RuntimeContext* context, void** handler_data, RuntimeU64* establisher_frame, void* context_pointers);"
              "extern void* GetStdHandle(int standard_handle);"
              "extern int WriteFile(void* handle, void* buffer, unsigned long byte_count, unsigned long* written, void* overlapped);"
              "int main(void);"
              "static RuntimeU64 runtime_epilog_status;"
              "static RuntimeU64 runtime_epilog_unwind_pc;"
              "static RuntimeU64 runtime_large_epilog_status;"
              "static RuntimeU64 runtime_large_epilog_unwind_pc;"
              "static RuntimeU64 runtime_body_status;"
              "static RuntimeU64 runtime_large_body_status;"
              "static RuntimeU32 runtime_unwind_read_u16(unsigned char* bytes)"),
        S8(
              "{ return (RuntimeU32)bytes[0] | ((RuntimeU32)bytes[1] << 8); }"
              "static RuntimeU64 runtime_unwind_read_u32(unsigned char* bytes)"
              "{ return (RuntimeU64)bytes[0] | ((RuntimeU64)bytes[1] << 8) | ((RuntimeU64)bytes[2] << 16) | ((RuntimeU64)bytes[3] << 24); }"
              "static RuntimeU64 runtime_find_epilog(void* function, int* result_length, RuntimeU32* result_pop_count)"
              "{"
              "    unsigned char* bytes = (unsigned char*)function;"
              "    RuntimeU64 function_base = 0;"
              "    RuntimeFunction* target_entry = RtlLookupFunctionEntry((RuntimeU64)function + 1, &function_base, 0);"
              "    RuntimeU64 function_offset = (RuntimeU64)function - function_base;"
              "    RuntimeU64 function_length = target_entry && (RuntimeU64)target_entry->end_address > function_offset ? (RuntimeU64)target_entry->end_address - function_offset : 0;"
              "    RuntimeU64 result = 0; int found_length = 0; RuntimeU32 found_pop_count = 0;"
              "    for (RuntimeU64 offset = 0; offset + 6 <= function_length; offset += 1)"
              "    {"
              "        int length = 0;"
              "        if (offset + 4 <= function_length && bytes[offset] == 0x48 && bytes[offset + 1] == 0x83 && bytes[offset + 2] == 0xc4)"
              "        { length = 4; }"
              "        if (offset + 7 <= function_length && bytes[offset] == 0x48 && bytes[offset + 1] == 0x81 && bytes[offset + 2] == 0xc4)"
              "        { length = 7; }"
              "        if (offset + 4 <= function_length && bytes[offset] == 0x48 && bytes[offset + 1] == 0x8d && bytes[offset + 2] == 0x65)"
              "        { length = 4; }"
              "        if (offset + 7 <= function_length && bytes[offset] == 0x48 && bytes[offset + 1] == 0x8d && bytes[offset + 2] == 0xa5)"
              "        { length = 7; }"
              "        RuntimeU64 cursor = offset + (RuntimeU64)length; RuntimeU32 pop_count = 0; RuntimeU32 frame_pop_count = 0; RuntimeU32 popped_mask = 0;"
              "        while (length && cursor < function_length)"
              "        {"
              "            RuntimeU32 rex = bytes[cursor] == 0x41 ? 8 : 0; cursor += rex ? 1 : 0;"
              "            if (cursor >= function_length || bytes[cursor] < 0x58 || bytes[cursor] > 0x5f) { break; }"
              "            RuntimeU32 reg = (bytes[cursor] & 7) + rex;"
              "            if (!(reg == 3 || reg == 5 || reg == 6 || reg == 7 || reg >= 12) || (popped_mask & (1u << reg))) { break; }"
              "            popped_mask |= 1u << reg; pop_count += 1; frame_pop_count += reg == 5; cursor += 1;"
              "        }"
              "        if (!length || !pop_count || frame_pop_count != 1 || cursor >= function_length || bytes[cursor] != 0xc3) { length = 0; }"
              "        if (length)"
              "        {"
              "            RuntimeU64 candidate_base = 0;"
              "            RuntimeFunction* candidate_entry = RtlLookupFunctionEntry((RuntimeU64)(bytes + offset) + 1, &candidate_base, 0);"),
        S8(
              "            if (candidate_entry == target_entry && candidate_base == function_base)"
              "            { result = (RuntimeU64)(bytes + offset); found_length = length; found_pop_count = pop_count; }"
              "        }"
              "    }"
              "    *result_length = found_length; *result_pop_count = found_pop_count; return result;"
              "}"
              "static int runtime_unwind_body(void* function, void* expected_main, RuntimeContext* context)"
              "{"
              "    RuntimeU64 image_base = 0;"
              "    RuntimeFunction* function_entry = RtlLookupFunctionEntry((RuntimeU64)function + 1, &image_base, 0);"
              "    if (!function_entry || !image_base) { return 0; }"
              "    unsigned char* unwind = (unsigned char*)(image_base + function_entry->unwind_data);"
              "    RuntimeU32 unwind_header = unwind[0]; RuntimeU32 prolog_size = unwind[1]; RuntimeU32 code_count = unwind[2];"
              "    RuntimeU32 frame_header = unwind[3]; RuntimeU32 fixed_size = 0;"
              "    RuntimeU32 push_count = 0; RuntimeU32 frame_push_count = 0; RuntimeU32 allocate_count = 0; RuntimeU32 frame_count = 0;"
              "    if ((unwind_header & 7) != 1 || (unwind_header >> 3) != 0 || (frame_header & 0xf) != 5 || (frame_header >> 4) != 0 || code_count > 64) { return 0; }"
              "    for (RuntimeU32 slot = 0; slot < code_count; slot += 1)"
              "    {"
              "        unsigned char* code = unwind + 4 + slot * 2;"
              "        RuntimeU32 operation = code[1] & 0xf; RuntimeU32 info = code[1] >> 4;"
              "        if (operation == 0)"
              "        {"
              "            if (!(info == 3 || info == 5 || info == 6 || info == 7 || info >= 12)) { return 0; }"
              "            push_count += 1; frame_push_count += info == 5;"
              "        }"
              "        else if (operation == 1)"
              "        {"
              "            if (info == 0)"
              "            {"
              "                if (slot + 1 >= code_count) { return 0; }"),
        S8(
              "                RuntimeU32 size = 8 * runtime_unwind_read_u16(unwind + 4 + (slot + 1) * 2);"
              "                if (!size || fixed_size > 0xffffffffU - size) { return 0; }"
              "                fixed_size += size; slot += 1;"
              "            }"
              "            else if (info == 1)"
              "            {"
              "                if (slot + 2 >= code_count) { return 0; }"
              "                RuntimeU64 size = runtime_unwind_read_u32(unwind + 4 + (slot + 1) * 2);"
              "                if (!size || size > 0xffffffffU || fixed_size > 0xffffffffU - (RuntimeU32)size) { return 0; }"
              "                fixed_size += (RuntimeU32)size; slot += 2;"
              "            }"
              "            else { return 0; }"
              "            allocate_count += 1;"
              "        }"
              "        else if (operation == 2)"
              "        {"
              "            RuntimeU32 size = (info + 1) * 8;"
              "            if (fixed_size > 0xffffffffU - size) { return 0; }"
              "            fixed_size += size; allocate_count += 1;"
              "        }"
              "        else if (operation == 3)"
              "        {"
              "            if (info != 0) { return 0; }"
              "            frame_count += 1;"
              "        }"
              "        else { return 0; }"
              "    }"
              "    RuntimeU64 function_offset = (RuntimeU64)function - image_base;"
              "    RuntimeU64 function_begin = image_base + function_entry->begin_address;"
              "    RuntimeU64 function_end = image_base + function_entry->end_address;"),
        S8(
              "    if (!context || function_begin > 0xffffffffffffffffULL - prolog_size) { return 0; }"
              "    RuntimeU64 prolog_end = function_begin + prolog_size;"
              "    RuntimeU64 captured_pc = context->rip; RuntimeU64 captured_base = 0;"
              "    RuntimeFunction* captured_entry = RtlLookupFunctionEntry(captured_pc, &captured_base, 0);"
              "    if (!push_count || frame_push_count != 1 || allocate_count != 1 || frame_count != 1 || !fixed_size || fixed_size % 8 ||"
              "        function_offset != function_entry->begin_address || function_end <= function_begin || captured_entry != function_entry ||"
              "        captured_base != image_base || captured_pc < prolog_end || captured_pc >= function_end)"
              "    { return 0; }"
              "    RuntimeU64 frame = context->rbp;"
              "    RuntimeU64 saved_offset = (RuntimeU64)fixed_size + (RuntimeU64)(push_count - 1) * 8;"
              "    if (frame > 0xffffffffffffffffULL - saved_offset - 16) { return 0; }"
              "    RuntimeU64 saved_address = frame + saved_offset;"
              "    RuntimeU64 saved_rbp = *(RuntimeU64*)(saved_address); RuntimeU64 saved_rip = *(RuntimeU64*)(saved_address + 8);"
              "    RuntimeU64 expected_rsp = saved_address + 16;"
              "    context->rip = captured_pc;"
              "    void* handler_data = 0; RuntimeU64 establisher_frame = 0;"
              "    RtlVirtualUnwind(0, image_base, context->rip, function_entry, context, &handler_data, &establisher_frame, 0);"
              "    return context->rip == saved_rip && context->rip >= (RuntimeU64)expected_main && context->rip < (RuntimeU64)expected_main + 4096 &&"
              "           context->rsp == expected_rsp && context->rbp == saved_rbp && establisher_frame == frame;"
              "}"
              "static int runtime_unwind_epilog(void* function, void* expected_main)"
              "{"
              "    int add_length = 0; RuntimeU32 pop_count = 0; RuntimeU64 control_pc = runtime_find_epilog(function, &add_length, &pop_count);"
              "    RuntimeU64 image_base = 0;"
              "    RuntimeFunction* function_entry = control_pc ? RtlLookupFunctionEntry(control_pc + (RuntimeU64)add_length, &image_base, 0) : 0;"
              "    if (!function_entry) { return 0; }"
              "    RuntimeU64 fake_stack[16]; RuntimeU64 context_storage[156];"
              "    for (RuntimeU32 index = 0; index < 16; index += 1) { fake_stack[index] = 0x1122334455667788ULL + index; }"
              "    for (RuntimeU32 index = 0; index < 156; index += 1) { context_storage[index] = 0; }"
              "    RuntimeContext* context = (RuntimeContext*)(((RuntimeU64)(void*)&context_storage[0] + 15) & ~(RuntimeU64)15);"
              "    fake_stack[pop_count] = (RuntimeU64)expected_main + 16;"
              "    context->context_flags = 0x0010001f; context->rsp = (RuntimeU64)&fake_stack[0]; context->rip = control_pc + (RuntimeU64)add_length;"),
        S8(
              "    void* handler_data = 0;"
              "    RuntimeU64 establisher_frame = 0;"
              "    RtlVirtualUnwind(0, image_base, context->rip, function_entry, context, &handler_data, &establisher_frame, 0);"
              "    runtime_epilog_unwind_pc = context->rip;"
              "    return pop_count <= 8 && context->rip >= (RuntimeU64)expected_main && context->rip < (RuntimeU64)expected_main + 4096 &&"
              "           context->rsp == (RuntimeU64)(void*)&fake_stack[pop_count + 1];"
              "}"
              "static void runtime_touch_bytes(unsigned char* bytes, int size)"
              "{ bytes[0] ^= 0x5a; bytes[size - 1] ^= 0xa5; }"
              "typedef __builtin_va_list va_list;"
              "int stack_walk_normal(void** buffer, int size, int marker, ...)"
              "{"
              "    int dynamic_size = marker + 157; unsigned char dynamic_padding[dynamic_size];"
              "    va_list arguments; int extra = 0;"
              "    RuntimeU64 body_context_storage[156];"
              "    RuntimeContext* body_context = (RuntimeContext*)(((RuntimeU64)(void*)&body_context_storage[0] + 15) & ~(RuntimeU64)15);"
              "    RuntimeU64 a0 = 1; RuntimeU64 a1 = 2; RuntimeU64 a2 = 3; RuntimeU64 a3 = 4;"
              "    RuntimeU64 a4 = 5; RuntimeU64 a5 = 6; RuntimeU64 a6 = 7; RuntimeU64 a7 = 8;"
              "    RuntimeU64 a8 = 9; RuntimeU64 a9 = 10; RuntimeU64 a10 = 11; RuntimeU64 a11 = 12;"
              "    RuntimeU64 a12 = 13; RuntimeU64 a13 = 14; RuntimeU64 a14 = 15; RuntimeU64 a15 = 16;"
              "    RuntimeU64 pressure = a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15;"
              "    __builtin_va_start(arguments, marker); extra = __builtin_va_arg(arguments, int); __builtin_va_end(arguments);"
              "    dynamic_padding[0] = (unsigned char)pressure; dynamic_padding[32] = (unsigned char)(pressure ^ 0x3c);"
              "    dynamic_padding[dynamic_size - 1] = (unsigned char)(pressure >> 8);"
              "    runtime_touch_bytes(dynamic_padding, dynamic_size);"
              "    if (marker != 100 || extra != 23 || pressure == 0) { a0 = pressure; return -1; }"
              "    RtlCaptureContext(body_context);"
              "    runtime_body_status = (RuntimeU64)runtime_unwind_body((void*)stack_walk_normal, (void*)main, body_context);"
              "    runtime_epilog_status = (RuntimeU64)runtime_unwind_epilog((void*)stack_walk_normal, (void*)main);"
              "    int frame_count = (int)RtlCaptureStackBackTrace(0, (unsigned long)size, buffer, 0);"
              "    if (dynamic_padding[0] != (unsigned char)(pressure ^ 0x5a) || dynamic_padding[32] != (unsigned char)(pressure ^ 0x3c) ||"),
        S8(
              "        dynamic_padding[dynamic_size - 1] != (unsigned char)((pressure >> 8) ^ 0xa5)) { return -2; }"
              "    return frame_count;"
              "}"
              "typedef struct RuntimeBig RuntimeBig;"
              "struct RuntimeBig { RuntimeU64 first; RuntimeU64 second; RuntimeU64 third; };"
              "static int runtime_add_one(int value) { return value + 1; }"
              "static int runtime_add_many(int a, int b, int c, int d, int e) { return a + b + c + d + e; }"
              "static void runtime_mutate_register(RuntimeBig value) { value.first += 9; }"
              "static void runtime_mutate_stack(int a, int b, int c, int d, RuntimeBig value)"
              "{ value.first += (RuntimeU64)(a + b + c + d); }"
              "static RuntimeBig runtime_make_big(RuntimeU64 first, RuntimeU64 second, RuntimeU64 third)"
              "{ return (RuntimeBig){first, second, third}; }"
              "static RuntimeBig runtime_transform_big(RuntimeBig value)"
              "{ value.first += 1; return value; }"
              "static RuntimeBig runtime_dynamic_make_big(RuntimeU64 first, RuntimeU64 second, RuntimeU64 third)"
              "{"
              "    int dynamic_size = (int)first + 256; unsigned char dynamic_padding[dynamic_size];"
              "    dynamic_padding[0] = (unsigned char)first; dynamic_padding[dynamic_size - 1] = (unsigned char)third;"
              "    runtime_touch_bytes(dynamic_padding, dynamic_size);"
              "    return (RuntimeBig){first, second, third};"
              "}"
              "static int runtime_copy_semantics(void)"
              "{"
              "    RuntimeBig original = (RuntimeBig){1, 2, 3};"
              "    RuntimeBig made = runtime_make_big(4, 5, 6);"
              "    RuntimeBig transformed = runtime_transform_big(original);"
              "    runtime_mutate_register(original);"
              "    runtime_mutate_stack(1, 2, 3, 4, original);"
              "    return runtime_add_one(0) == 1 && runtime_add_many(1, 2, 3, 4, 5) == 15 &&"
              "           original.first == 1 && original.second == 2 && original.third == 3 &&"),
        S8(
              "           made.first == 4 && made.second == 5 && made.third == 6 && transformed.first == 2;"
              "}"
              "int stack_walk_large(void** buffer, int size, int first, int second, int third, RuntimeBig incoming)"
              "{"
              "    unsigned char padding[40000];"
              "    int dynamic_size = first + 256; unsigned char dynamic_padding[dynamic_size];"
              "    RuntimeU64 body_context_storage[156];"
              "    RuntimeContext* body_context = (RuntimeContext*)(((RuntimeU64)(void*)&body_context_storage[0] + 15) & ~(RuntimeU64)15);"
              "    RuntimeU64 a0 = 17; RuntimeU64 a1 = 18; RuntimeU64 a2 = 19; RuntimeU64 a3 = 20;"
              "    RuntimeU64 a4 = 21; RuntimeU64 a5 = 22; RuntimeU64 a6 = 23; RuntimeU64 a7 = 24;"
              "    RuntimeU64 pressure = a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7;"
              "    padding[0] = (unsigned char)pressure; padding[39999] = (unsigned char)(pressure >> 8);"
              "    dynamic_padding[0] = (unsigned char)pressure; dynamic_padding[32] = (unsigned char)(pressure ^ 0x3c);"
              "    dynamic_padding[dynamic_size - 1] = (unsigned char)(pressure >> 8);"
              "    runtime_touch_bytes(dynamic_padding, dynamic_size);"
              "    if (first != 1 || second != 2 || third != 3 || incoming.first != 4 || incoming.second != 5 || incoming.third != 6) { return -1; }"
              "    if (runtime_add_many(1, 2, 3, 4, 5) != 15) { return -1; }"
              "    RuntimeBig dynamic_original = (RuntimeBig){1, 2, 3};"
              "    runtime_mutate_stack(1, 2, 3, 4, dynamic_original);"
              "    if (dynamic_original.first != 1 || dynamic_original.second != 2 || dynamic_original.third != 3) { return -1; }"
              "    RuntimeBig dynamic_made = runtime_dynamic_make_big(7, 11, 13);"
              "    if (dynamic_made.first != 7 || dynamic_made.second != 11 || dynamic_made.third != 13) { return -1; }"
              "    if (!runtime_copy_semantics()) { return -1; }"
              "    RtlCaptureContext(body_context);"
              "    runtime_large_body_status = (RuntimeU64)runtime_unwind_body((void*)stack_walk_large, (void*)main, body_context);"
              "    runtime_large_epilog_status = (RuntimeU64)runtime_unwind_epilog((void*)stack_walk_large, (void*)main);"
              "    runtime_large_epilog_unwind_pc = runtime_epilog_unwind_pc;"
              "    int frame_count = (int)RtlCaptureStackBackTrace(0, (unsigned long)size, buffer, 0);"
              "    if (dynamic_padding[0] != (unsigned char)(pressure ^ 0x5a) || dynamic_padding[32] != (unsigned char)(pressure ^ 0x3c) ||"
              "        dynamic_padding[dynamic_size - 1] != (unsigned char)((pressure >> 8) ^ 0xa5) ||"),
        S8(
              "        padding[0] != (unsigned char)pressure || padding[39999] != (unsigned char)(pressure >> 8)) { return -2; }"
              "    return frame_count;"
              "}"
              ""),
        S8("/* Native Windows checks use instruction bytes, not unwind codes, to construct\n"
              "   each interrupted context. No test code executes on the synthetic stack. */\n"
              "static RuntimeU64 runtime_fixed_boundaries;\n"
              "static RuntimeU64 runtime_fixed_saved_mask;\n"
              "static RuntimeU64 runtime_fixed_failure;\n"
              "static RuntimeU64 runtime_fixed_original(RuntimeU32 reg)\n"
              "{\n"
              "    return 0x12340000ULL + reg;\n"
              "}\n"
              "static int runtime_fixed_at(RuntimeFunction* entry, RuntimeU64 image, RuntimeU64 pc, RuntimeU64* registers, RuntimeU64 entry_sp)\n"
              "{\n"
              "    RuntimeU64 storage[156];\n"
              "    RuntimeContext* context = (RuntimeContext*)(((RuntimeU64)(void*)storage + 15) & ~(RuntimeU64)15);\n"
              "    unsigned char* bytes = (unsigned char*)context;\n"
              "    for (RuntimeU32 index = 0; index < sizeof(*context); index += 1) { bytes[index] = 0; }\n"
              "    context->context_flags = 0x10000b;\n"
              "    context->rbx = registers[3]; context->rsp = registers[4]; context->rbp = registers[5];\n"
              "    context->rsi = registers[6]; context->rdi = registers[7];\n"
              "    context->r12 = registers[12]; context->r13 = registers[13]; context->r14 = registers[14]; context->r15 = registers[15];\n"
              "    context->rip = pc;\n"
              "    void* handler_data = 0;\n"
              "    RuntimeU64 establisher_frame = 0;\n"
              "    RtlVirtualUnwind(0, image, pc, entry, context, &handler_data, &establisher_frame, 0);\n"
              "    runtime_fixed_boundaries += 1;\n"
              "    int valid = context->rip == (RuntimeU64)(void*)main + 16 && context->rsp == entry_sp + 8 &&\n"
              "                context->rbx == runtime_fixed_original(3) && context->rbp == runtime_fixed_original(5) &&\n"
              "                context->rsi == runtime_fixed_original(6) && context->rdi == runtime_fixed_original(7) &&\n"
              "                context->r12 == runtime_fixed_original(12) && context->r13 == runtime_fixed_original(13) &&\n"
              "                context->r14 == runtime_fixed_original(14) && context->r15 == runtime_fixed_original(15);\n"
              "    if (!valid) { runtime_fixed_failure = pc - image - entry->begin_address + 1; }\n"
              "    return valid;\n"
              "}\n"
              "static int runtime_fixed_function(void* function)\n"
              "{\n"
              "    RuntimeU64 image = 0;\n"
              "    RuntimeFunction* entry = RtlLookupFunctionEntry((RuntimeU64)function + 1, &image, 0);\n"
              "    int valid = entry != 0 && image != 0;\n"
              "    if (valid)\n"
              "    {\n"
              "        unsigned char* code = (unsigned char*)(image + entry->begin_address);\n"
              "        unsigned char* unwind = (unsigned char*)(image + entry->unwind_data);\n"
              "        RuntimeU32 prolog = unwind[1];\n"),
        S8("        RuntimeU32 length = entry->end_address - entry->begin_address;\n"
              "        RuntimeU64 stack[2050];\n"
              "        for (RuntimeU32 index = 0; index < 2050; index += 1) { stack[index] = (RuntimeU64)(void*)main + 16; }\n"
              "        RuntimeU64 low = (RuntimeU64)(void*)stack;\n"
              "        RuntimeU64 entry_sp = ((RuntimeU64)(void*)(stack + 2048) & ~(RuntimeU64)15) - 8;\n"
              "        RuntimeU64 registers[16];\n"
              "        for (RuntimeU32 reg = 0; reg < 16; reg += 1) { registers[reg] = runtime_fixed_original(reg); }\n"
              "        registers[4] = entry_sp;\n"
              "        RuntimeU32 pushed[16]; RuntimeU32 push_count = 0;\n"
              "        RuntimeU32 pushed_mask = 0; RuntimeU32 saved_mask = 0;\n"
              "        RuntimeU64 allocation = 0;\n"
              "        RuntimeU32 offset = 0;\n"
              "        valid = prolog > 0 && prolog < length;\n"
              "        while (valid && offset <= prolog)\n"
              "        {\n"
              "            valid = runtime_fixed_at(entry, image, (RuntimeU64)(void*)(code + offset), registers, entry_sp);\n"
              "            if (offset == prolog) { break; }\n"
              "            RuntimeU32 cursor = offset;\n"
              "            RuntimeU32 rex = 0;\n"
              "            if (code[cursor] >= 0x40 && code[cursor] <= 0x4f) { rex = code[cursor++]; }\n"
              "            valid = valid && cursor < prolog;\n"
              "            if (valid && code[cursor] >= 0x50 && code[cursor] <= 0x57)\n"
              "            {\n"
              "                RuntimeU32 reg = (code[cursor] & 7) + ((rex & 1) ? 8 : 0);\n"
              "                valid = push_count < 16 && registers[4] >= low + 8;\n"
              "                if (valid)\n"
              "                {\n"
              "                    registers[4] -= 8;\n"
              "                    *(RuntimeU64*)registers[4] = registers[reg];\n"
              "                    pushed[push_count++] = reg;\n"
              "                    pushed_mask |= 1u << reg;\n"
              "                    offset = cursor + 1;\n"
              "                }\n"
              "            }\n"
              "            else if (valid && rex == 0x48 && cursor + 2 <= prolog && code[cursor] == 0x89 && code[cursor + 1] == 0xe5)\n"
              "            {\n"
              "                registers[5] = registers[4]; offset = cursor + 2;\n"
              "            }\n"
              "            else if (valid && rex == 0x48 && cursor + 3 <= prolog &&\n"
              "                     (code[cursor] == 0x81 || code[cursor] == 0x83) && code[cursor + 1] == 0xec)\n"
              "            {\n"
              "                RuntimeU32 immediate_size = code[cursor] == 0x81 ? 4 : 1;\n"
              "                valid = cursor + 2 + immediate_size <= prolog;\n"
              "                if (valid)\n"
              "                {\n"),
        S8("                    RuntimeU64 amount = immediate_size == 4 ? runtime_unwind_read_u32(code + cursor + 2) : code[cursor + 2];\n"
              "                    valid = amount > 0 && amount <= registers[4] - low;\n"
              "                    if (valid) { registers[4] -= amount; allocation += amount; offset = cursor + 2 + immediate_size; }\n"
              "                }\n"
              "            }\n"
              "            else if (valid && !rex && cursor + 4 <= prolog && code[cursor] == 0xf6 && code[cursor + 1] == 4 && code[cursor + 2] == 0x24 && code[cursor + 3] == 0)\n"
              "            {\n"
              "                offset = cursor + 4;\n"
              "            }\n"
              "            else if (valid && (rex == 0x48 || rex == 0x4c) && cursor + 3 <= prolog && code[cursor] == 0x89 &&\n"
              "                     ((code[cursor + 1] & 0xc7) == 0x45 || (code[cursor + 1] & 0xc7) == 0x85))\n"
              "            {\n"
              "                RuntimeU32 displacement_size = (code[cursor + 1] & 0xc0) == 0x40 ? 1 : 4;\n"
              "                valid = cursor + 2 + displacement_size <= prolog;\n"
              "                if (valid)\n"
              "                {\n"
              "                    int displacement = displacement_size == 1 ? (int)(signed char)code[cursor + 2] : (int)runtime_unwind_read_u32(code + cursor + 2);\n"
              "                    RuntimeU32 reg = ((code[cursor + 1] >> 3) & 7) + ((rex & 4) ? 8 : 0);\n"
              "                    RuntimeU64 address = registers[5] + (RuntimeU64)(long long)displacement;\n"
              "                    valid = address >= low && address <= entry_sp - 8 && address % 8 == 0;\n"
              "                    if (valid)\n"
              "                    {\n"
              "                        *(RuntimeU64*)address = registers[reg]; saved_mask |= 1u << reg;\n"
              "                        offset = cursor + 2 + displacement_size;\n"
              "                    }\n"
              "                }\n"
              "            }\n"
              "            else { valid = 0; }\n"
              "        }\n"
              "        if (valid)\n"
              "        {\n"
              "            // The body may clobber saved registers; unwinding must recover\n"
              "            // their originals from the actual push/store locations.\n"
              "            for (RuntimeU32 reg = 0; reg < 16; reg += 1)\n"
              "            {\n"
              "                if (reg != 5 && ((pushed_mask | saved_mask) & (1u << reg))) { registers[reg] ^= 0x56780000ULL; }\n"
              "            }\n"
              "            runtime_fixed_saved_mask |= pushed_mask | saved_mask;\n"
              "            valid = allocation > 0 && unwind[3] == 0 && runtime_fixed_at(entry, image, (RuntimeU64)(void*)(code + prolog), registers, entry_sp);\n"
              "        }\n"
              "        RuntimeU32 epilog = 0;\n"),
        S8("        RuntimeU32 add_size = allocation <= 127 ? 4 : 7;\n"
              "        // Match the actual fixed-stack epilogue, including every saved GPR.\n"
              "        for (RuntimeU32 start = prolog; valid && start + add_size < length; start += 1)\n"
              "        {\n"
              "            RuntimeU32 cursor = start + add_size;\n"
              "            int matches = code[start] == 0x48 && code[start + 1] == (add_size == 4 ? 0x83 : 0x81) && code[start + 2] == 0xc4 &&\n"
              "                          (add_size == 4 ? code[start + 3] : runtime_unwind_read_u32(code + start + 3)) == allocation;\n"
              "            for (RuntimeU32 index = push_count; matches && index > 0; index -= 1)\n"
              "            {\n"
              "                RuntimeU32 reg = pushed[index - 1];\n"
              "                if (reg >= 8) { matches = cursor < length && code[cursor++] == 0x41; }\n"
              "                matches = matches && cursor < length && code[cursor++] == 0x58 + (reg & 7);\n"
              "            }\n"
              "            if (matches && cursor < length && code[cursor] == 0xc3) { epilog = start; }\n"
              "        }\n"
              "        if (valid)\n"
              "        {\n"
              "            valid = epilog != 0;\n"
              "            for (RuntimeU32 reg = 0; reg < 16; reg += 1)\n"
              "            {\n"
              "                if (saved_mask & (1u << reg)) { registers[reg] = runtime_fixed_original(reg); }\n"
              "            }\n"
              "            if (valid) { valid = runtime_fixed_at(entry, image, (RuntimeU64)(void*)(code + epilog), registers, entry_sp); }\n"
              "            registers[4] += allocation;\n"
              "            RuntimeU32 cursor = epilog + add_size;\n"
              "            for (RuntimeU32 index = push_count; valid && index > 0; index -= 1)\n"
              "            {\n"
              "                valid = runtime_fixed_at(entry, image, (RuntimeU64)(void*)(code + cursor), registers, entry_sp);\n"
              "                RuntimeU32 reg = pushed[index - 1];\n"
              "                registers[reg] = *(RuntimeU64*)registers[4]; registers[4] += 8;\n"
              "                cursor += reg >= 8 ? 2 : 1;\n"
              "            }\n"
              "            if (valid) { valid = runtime_fixed_at(entry, image, (RuntimeU64)(void*)(code + cursor), registers, entry_sp); }\n"
              "        }\n"
              "        if (!valid && !runtime_fixed_failure) { runtime_fixed_failure = 0x10000 + offset; }\n"
              "    }\n"
              "    return valid;\n"
              "}\n"
              "long long runtime_fixed_small(long long x)\n"
              "{\n"
              "    volatile long long y = x;\n"
              "    return y + 1;\n"
              "}\n"
              "long long runtime_fixed_saved(long long x)\n"
              "{\n"
              "    return runtime_fixed_small(x) + x + runtime_fixed_small(x + 1);\n"
              "}\n"
              "long long runtime_fixed_large(long long x)\n"
              "{\n"
              "    volatile unsigned char padding[512];\n"),
        S8("    padding[0] = (unsigned char)x; padding[511] = 7;\n"
              "    return padding[0] + padding[511];\n"
              "}\n"
              "__int128 runtime_fixed_wide(__int128 x)\n"
              "{\n"
              "    return x * x;\n"
              "}\n"
              "/* CPUID requires an RBX save independently of allocator choices.\n"
              "   Wide arithmetic can now stay in MIR without any extra GPR save. */\n"
              "unsigned int runtime_fixed_cpu_query(unsigned int leaf)\n"
              "{\n"
              "    unsigned int a, b, c, d;\n"
              "    __asm__ volatile(\"cpuid\" : \"=a\"(a), \"=b\"(b), \"=c\"(c), \"=d\"(d) : \"a\"(leaf), \"c\"(0u));\n"
              "    return a ^ b ^ c ^ d;\n"
              "}\n"
              "static int runtime_fixed_frames(void)\n"
              "{\n"
              "    int valid = runtime_fixed_function((void*)runtime_fixed_small);\n"
              "    valid = valid && runtime_fixed_function((void*)runtime_fixed_saved);\n"
              "    valid = valid && runtime_fixed_function((void*)runtime_fixed_large);\n"
              "    valid = valid && runtime_fixed_function((void*)runtime_fixed_wide);\n"
              "    valid = valid && runtime_fixed_function((void*)runtime_fixed_cpu_query);\n"
              "    valid = valid && (runtime_fixed_saved_mask & ~(1u << 5)) != 0;\n"
              "    return valid;\n"
              "}\n"),
        S8(
              "typedef struct RuntimeReport RuntimeReport;"
              "struct RuntimeReport"
              "{"
              "    void* normal_entry; void* large_entry; void* main_entry;"
              "    RuntimeU64 normal_count; RuntimeU64 large_count;"
              "    RuntimeU64 semantic_status;"
              "    RuntimeU64 body_status; RuntimeU64 large_body_status;"
              "    RuntimeU64 epilog_status; RuntimeU64 epilog_unwind_pc;"
              "    RuntimeU64 large_epilog_status; RuntimeU64 large_epilog_unwind_pc;"
              "    RuntimeU64 fixed_status; RuntimeU64 fixed_boundaries; RuntimeU64 fixed_saved_mask; RuntimeU64 fixed_failure;"
              "    void* normal_frames[64]; void* large_frames[64];"
              "};"
              "int main(void)"
              "{"
              "    RuntimeReport report;"
              "    report.fixed_status = runtime_fixed_frames(); report.fixed_boundaries = runtime_fixed_boundaries;"
              "    report.fixed_saved_mask = runtime_fixed_saved_mask; report.fixed_failure = runtime_fixed_failure;"
              "    report.normal_entry = (void*)stack_walk_normal; report.large_entry = (void*)stack_walk_large; report.main_entry = (void*)main;"
              "    int normal_count = stack_walk_normal(report.normal_frames, 64, 100, 23);"
              "    int large_count = stack_walk_large(report.large_frames, 64, 1, 2, 3, (RuntimeBig){4, 5, 6});"
              "    report.normal_count = normal_count > 0 ? (RuntimeU64)normal_count : 0;"
              "    report.large_count = large_count > 0 ? (RuntimeU64)large_count : 0;"
              "    report.semantic_status = large_count > 0 ? 0x535441434b434f50ULL : 0;"
              "    report.body_status = runtime_body_status; report.large_body_status = runtime_large_body_status;"
              "    report.epilog_status = runtime_epilog_status; report.epilog_unwind_pc = runtime_epilog_unwind_pc;"
              "    report.large_epilog_status = runtime_large_epilog_status; report.large_epilog_unwind_pc = runtime_large_epilog_unwind_pc;"
              "    unsigned long written = 0;"
              "    WriteFile(GetStdHandle(-11), &report, sizeof(report), &written, 0);"
              "    return normal_count > 0 && large_count > 0 && report.semantic_status != 0 && report.body_status != 0 && report.large_body_status != 0 &&"
              "           report.epilog_status != 0 && report.large_epilog_status != 0 && report.fixed_status == 1 ? 0 : 1;"
              "}"),
    };
    return string_join_arena(arena, (SliceString8)BUSTER_ARRAY_TO_SLICE(parts), false);
#elif BUSTER_LINUX || BUSTER_MACOS
    BUSTER_UNUSED(arena);
    return S8("typedef unsigned long long RuntimeU64;"
              "extern int backtrace(void** buffer, int size);"
              "extern long write(int file_descriptor, void* buffer, unsigned long byte_count);"
              "int stack_walk_normal(void** buffer, int size)"
              "{"
              "    RuntimeU64 a0 = 1; RuntimeU64 a1 = 2; RuntimeU64 a2 = 3; RuntimeU64 a3 = 4;"
              "    RuntimeU64 a4 = 5; RuntimeU64 a5 = 6; RuntimeU64 a6 = 7; RuntimeU64 a7 = 8;"
              "    RuntimeU64 a8 = 9; RuntimeU64 a9 = 10; RuntimeU64 a10 = 11; RuntimeU64 a11 = 12;"
              "    RuntimeU64 a12 = 13; RuntimeU64 a13 = 14; RuntimeU64 a14 = 15; RuntimeU64 a15 = 16;"
              "    RuntimeU64 pressure = a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15;"
              "    if (pressure == 0) { a0 = pressure; }"
              "    return backtrace(buffer, size);"
              "}"
              "int stack_walk_large(void** buffer, int size)"
              "{"
              "    unsigned char padding[40000];"
              "    RuntimeU64 a0 = 17; RuntimeU64 a1 = 18; RuntimeU64 a2 = 19; RuntimeU64 a3 = 20;"
              "    RuntimeU64 a4 = 21; RuntimeU64 a5 = 22; RuntimeU64 a6 = 23; RuntimeU64 a7 = 24;"
              "    RuntimeU64 pressure = a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7;"
              "    padding[0] = (unsigned char)pressure; padding[39999] = (unsigned char)(pressure >> 8);"
              "    return backtrace(buffer, size);"
              "}"
              "typedef struct RuntimeReport RuntimeReport;"
              "struct RuntimeReport"
              "{"
              "    void* normal_entry; void* large_entry; void* main_entry;"
              "    RuntimeU64 normal_count; RuntimeU64 large_count;"
              "    void* normal_frames[64]; void* large_frames[64];"
              "};"
              "int main(void)"
              "{"
              "    RuntimeReport report;"
              "    report.normal_entry = (void*)stack_walk_normal; report.large_entry = (void*)stack_walk_large; report.main_entry = (void*)main;"
              "    int normal_count = stack_walk_normal(report.normal_frames, 64);"
              "    int large_count = stack_walk_large(report.large_frames, 64);"
              "    report.normal_count = normal_count > 0 ? (RuntimeU64)normal_count : 0;"
              "    report.large_count = large_count > 0 ? (RuntimeU64)large_count : 0;"
              "    write(1, &report, sizeof(report));"
              "    return normal_count > 0 && large_count > 0 ? 0 : 1;"
              "}");
#else
    BUSTER_UNUSED(arena);
    return (String8){0};
#endif
}

typedef struct LinkTestRuntimeReport LinkTestRuntimeReport;
struct LinkTestRuntimeReport
{
    u64 normal_entry;
    u64 large_entry;
    u64 main_entry;
    u64 normal_count;
    u64 large_count;
#if BUSTER_WINDOWS
    u64 semantic_status;
    u64 body_status;
    u64 large_body_status;
    u64 epilog_status;
    u64 epilog_unwind_pc;
    u64 large_epilog_status;
    u64 large_epilog_unwind_pc;
#if BUSTER_CPU_ARCH_X86_64
    u64 fixed_status;
    u64 fixed_boundaries;
    u64 fixed_saved_mask;
    u64 fixed_failure;
#endif
#endif
    u64 normal_frames[64];
    u64 large_frames[64];
};

BUSTER_GLOBAL_LOCAL bool link_test_runtime_symbol_find(ObjectFile* object, String8 name, u64* value, u64* size)
{
    if (object && object->symbols)
    {
        for (u32 symbol_index = 0; symbol_index < object->symbol_count; symbol_index += 1)
        {
            ObjectSymbol* symbol = &object->symbols[symbol_index];
            if (symbol->kind == OBJECT_SYMBOL_FUNCTION && symbol->section == OBJECT_SECTION_TEXT && string_equal(symbol->name, name))
            {
                if (value)
                {
                    *value = symbol->value;
                }
                if (size)
                {
                    *size = symbol->size;
                }
                return true;
            }
        }
    }

    return false;
}

#if BUSTER_WINDOWS
BUSTER_GLOBAL_LOCAL bool link_test_runtime_windows_arm64_xdata(ObjectFile* object, bool* has_frame_register, bool* has_large_allocation)
{
    ByteSlice xdata = object->sections[OBJECT_SECTION_WINDOWS_XDATA].data;
    u32 record_count = 0;
    for (u32 relocation_index = 0; relocation_index < object->relocation_count; relocation_index += 1)
    {
        ObjectRelocation* relocation = object->relocations + relocation_index;
        if (relocation->section != OBJECT_SECTION_WINDOWS_PDATA || relocation->offset % 8 != 4 || relocation->addend < 0)
        {
            continue;
        }
        u64 xdata_offset = (u64)relocation->addend;
        if (xdata_offset % 4 || xdata_offset > xdata.length || xdata.length - xdata_offset < 4)
        {
            return false;
        }
        u8 const* record = xdata.pointer + xdata_offset;
        u32 header = 0;
        memcpy(&header, record, sizeof(header));
        if (!(header & ((1u << 18) - 1)) || ((header >> 18) & 3) != 0 || (header & (1u << 20)))
        {
            return false;
        }
        bool epilog_packed = (header & (1u << 21)) != 0;
        u32 epilog_count = (header >> 22) & 31;
        u32 code_words = header >> 27;
        u32 header_size = 4;
        if (!(header >> 22))
        {
            if (xdata.length - xdata_offset < 8)
            {
                return false;
            }
            u32 extension = 0;
            memcpy(&extension, record + 4, sizeof(extension));
            if (extension >> 24)
            {
                return false;
            }
            epilog_count = extension & 0xffff;
            code_words = (extension >> 16) & 0xff;
            header_size = 8;
        }
        u64 scope_bytes = epilog_packed ? 0 : (u64)epilog_count * 4;
        u64 code_bytes = (u64)code_words * 4;
        u64 record_bytes = (u64)header_size + scope_bytes + code_bytes;
        if (!code_words || record_bytes > xdata.length - xdata_offset)
        {
            return false;
        }
        u8 const* codes = record + header_size + scope_bytes;
        if (!epilog_packed)
        {
            for (u32 epilog = 0; epilog < epilog_count; epilog += 1)
            {
                u32 scope = 0;
                memcpy(&scope, record + header_size + (u64)epilog * 4, sizeof(scope));
                if ((scope & (15u << 18)) || (scope >> 22) >= code_bytes)
                {
                    return false;
                }
            }
        }
        for (u32 cursor = 0; cursor < code_bytes;)
        {
            u8 operation = codes[cursor];
            u32 operation_bytes = 0;
            // SAVE_FPLR_X carries a six-bit allocation immediate. MIR's
            // compact save prefix is larger than the canonical 16 bytes.
            if (operation <= 0x1f || (operation & 0xc0) == 0x80 || operation == 0xe1 || operation == 0xe3 || operation == 0xe4)
            {
                operation_bytes = 1;
            }
            else if ((operation & 0xf8) == 0xc0 || (operation >= 0xd0 && operation <= 0xd2) || operation == 0xe2)
            {
                operation_bytes = 2;
            }
            else if (operation == 0xe0)
            {
                operation_bytes = 4;
            }
            else
            {
                return false;
            }
            if (operation_bytes > code_bytes - cursor)
            {
                return false;
            }
            if (operation == 0xe1 || operation == 0xe2)
            {
                *has_frame_register = true;
            }
            if (operation == 0xe0)
            {
                u32 units = (u32)codes[cursor + 1] << 16 | (u32)codes[cursor + 2] << 8 | codes[cursor + 3];
                *has_large_allocation |= units * 16 > 4096;
            }
            else if ((operation & 0xf8) == 0xc0)
            {
                u32 units = ((u32)operation & 7) << 8 | codes[cursor + 1];
                *has_large_allocation |= units * 16 > 4096;
            }
            cursor += operation_bytes;
            if (operation == 0xe4)
            {
                bool padding = true;
                for (u32 tail = cursor; tail < code_bytes; tail += 1)
                {
                    padding &= codes[tail] == 0;
                }
                if (padding)
                {
                    break;
                }
            }
        }
        record_count += 1;
    }
    return record_count != 0 && *has_frame_register && *has_large_allocation;
}

BUSTER_GLOBAL_LOCAL bool link_test_runtime_windows_xdata(ObjectFile* object, bool* has_frame_register, bool* has_large_allocation)
{
    if (!object || !object->sections || !has_frame_register || !has_large_allocation)
    {
        return false;
    }
    *has_frame_register = false;
    *has_large_allocation = false;
    if (object->target.cpu_arch == CPU_ARCH_AARCH64)
    {
        return link_test_runtime_windows_arm64_xdata(object, has_frame_register, has_large_allocation);
    }
    ByteSlice xdata = object->sections[OBJECT_SECTION_WINDOWS_XDATA].data;
    u32 record_count = 0;
    for (u32 relocation_index = 0; relocation_index < object->relocation_count; relocation_index += 1)
    {
        ObjectRelocation* relocation = object->relocations + relocation_index;
        if (relocation->section != OBJECT_SECTION_WINDOWS_PDATA || relocation->offset % 12 != 8 || relocation->addend < 0)
        {
            continue;
        }
        u64 xdata_offset = (u64)relocation->addend;
        if (xdata_offset % 4 || xdata_offset > xdata.length || xdata.length - xdata_offset < 4)
        {
            return false;
        }
        u8 const* record = xdata.pointer + xdata_offset;
        u64 record_bytes = 4 + (u64)record[2] * 2;
        if (record_bytes > xdata.length - xdata_offset)
        {
            return false;
        }
        record_count += 1;
        if ((record[3] & 15) == 5 && (record[3] >> 4) == 0)
        {
            *has_frame_register = true;
        }
        for (u32 code_index = 0; code_index < record[2];)
        {
            u8 unwind = record[5 + code_index * 2];
            u8 operation = unwind & 15;
            u8 information = unwind >> 4;
            if (operation == 0 || operation == 2 || operation == 3)
            {
                code_index += 1;
            }
            else if ((operation == 1 && information == 0) || operation == 4)
            {
                if (code_index + 1 >= record[2])
                {
                    return false;
                }
                u16 scaled = 0;
                memcpy(&scaled, record + 6 + code_index * 2, sizeof(scaled));
                *has_large_allocation |= operation == 1 && (u32)scaled * 8 > 4096;
                code_index += 2;
            }
            else if ((operation == 1 && information == 1) || operation == 5)
            {
                if (code_index + 2 >= record[2])
                {
                    return false;
                }
                u32 size = 0;
                memcpy(&size, record + 6 + code_index * 2, sizeof(size));
                *has_large_allocation |= operation == 1 && size > 4096;
                code_index += 3;
            }
            else
            {
                return false;
            }
        }
    }
    return record_count != 0 && *has_frame_register && *has_large_allocation;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_runtime_windows_arm64_xdata_frame_prefix(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    // One packed-epilogue record: ALLOC_M 4112, SET_FP, SAVE_REG X28 at
    // SP+16, SAVE_FPLR_X, END, padding. The record is independent of the
    // object writer, so changing a producer cannot change the expected bytes.
    u8 record[] = {0x10, 0, 0x20, 0x10, 0xc1, 1, 0xe1, 0xd2, 0x42, 0x83, 0xe4, 0};
    ObjectRelocation relocation = {.section = OBJECT_SECTION_WINDOWS_PDATA, .offset = 4};
    ObjectFile object = link_test_object_make(arguments->arena, (Target){.cpu_arch = CPU_ARCH_AARCH64}, (ByteSlice){0},
                                              0, 0, &relocation, 1);
    ObjectSection* xdata = object.sections + OBJECT_SECTION_WINDOWS_XDATA;
    xdata->data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(record);
    bool has_frame_register = false;
    bool has_large_allocation = false;
    for (u32 prefix = 0x80; prefix <= 0xbf; prefix += 1)
    {
        record[9] = (u8)prefix;
        BUSTER_TEST(arguments, link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
    }
    // A save-prefix immediate must not satisfy the large-allocation gate.
    record[4] = 0xc0;
    BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
    BUSTER_TEST(arguments, has_frame_register && !has_large_allocation);
    record[4] = 0xc1;
    record[9] = 0xe7; // Reserved operation remains invalid.
    BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
    record[9] = 0x83;
    xdata->data.length -= 1;
    BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
    xdata->data.length = sizeof(record);
    record[11] = 0xd2; // A two-byte save is truncated at the code-array end.
    BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
    record[11] = 0xe0; // A four-byte allocation is also truncated there.
    BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_runtime_windows_xdata_save_slots(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    // The first record preserves the dynamic-frame and large-allocation
    // prerequisites. The second exercises fixed-frame register saves without
    // mistaking their stack offsets for allocation sizes.
    u8 records[] = {
        1, 12, 4, 5, 12, 3, 8, 1, 1, 4, 1, 0x50,
        1, 8, 3, 0, 8, 0x34, 0, 0, 0, 0, 0, 0,
    };
    ObjectRelocation relocations[] = {
        {.section = OBJECT_SECTION_WINDOWS_PDATA, .offset = 8},
        {.section = OBJECT_SECTION_WINDOWS_PDATA, .offset = 20, .addend = 12},
    };
    ObjectFile object = link_test_object_make(arguments->arena, (Target){.cpu_arch = CPU_ARCH_X86_64}, (ByteSlice){0},
                                              0, 0, relocations, BUSTER_ARRAY_LENGTH(relocations));
    ObjectSection* xdata = object.sections + OBJECT_SECTION_WINDOWS_XDATA;
    xdata->data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(records);
    bool has_frame_register = false;
    bool has_large_allocation = false;
    for (u8 slots = 2; slots <= 3; slots += 1)
    {
        records[14] = slots;
        records[17] = (u8)(0x30 | (slots == 2 ? 4 : 5));
        records[18] = 0xff;
        records[19] = 0xff;
        BUSTER_TEST(arguments, link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
        // A save offset alone must not satisfy the allocation prerequisite.
        records[9] = 0;
        BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
        BUSTER_TEST(arguments, has_frame_register && !has_large_allocation);
        records[9] = 4;
        for (u8 available = 1; available < slots; available += 1)
        {
            records[14] = available;
            BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
        }
        records[14] = slots;
        xdata->data.length = 16 + (u64)slots * 2 - 1;
        BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
        xdata->data.length = sizeof(records);
    }
    records[17] = 6; // Reserved unwind operation remains invalid.
    BUSTER_TEST(arguments, !link_test_runtime_windows_xdata(&object, &has_frame_register, &has_large_allocation));
    return result;
}
#endif

#if BUSTER_LINUX
BUSTER_GLOBAL_LOCAL bool link_test_runtime_has_eh_frame_header(ByteSlice image)
{
    u32 section_index = 0;
    u64 section_header = 0;
    if (!link_test_elf_section_find(image, S8(".eh_frame_hdr"), &section_index, &section_header))
    {
        return false;
    }
    u64 program_header_offset = link_read_u64(image.pointer, 32);
    u16 program_header_size = 0;
    u16 program_header_count = 0;
    memcpy(&program_header_size, image.pointer + 54, sizeof(program_header_size));
    memcpy(&program_header_count, image.pointer + 56, sizeof(program_header_count));
    if (program_header_size < 56 || program_header_offset > image.length ||
        (u64)program_header_count > (image.length - program_header_offset) / program_header_size)
    {
        return false;
    }
    bool found_program_header = false;
    for (u32 index = 0; index < program_header_count; index += 1)
    {
        u64 program_header = program_header_offset + (u64)index * program_header_size;
        if (link_read_u32(image.pointer, program_header) == 0x6474e550 && link_read_u64(image.pointer, program_header + 32) != 0)
        {
            found_program_header = true;
        }
    }
    return found_program_header;
}
#endif

BUSTER_GLOBAL_LOCAL bool link_test_runtime_frame_contains(u64 const* frames, u64 count, u64 begin, u64 size)
{
    if (frames && size)
    {
        for (u64 index = 0; index < count; index += 1)
        {
            u64 address = frames[index];
            if (address >= begin && address - begin < size)
            {
                return true;
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_runtime_stack_walk_variant(UnitTestArguments* arguments, String8 source_path, String8 output_path,
                                                                          bool debug_info, String8 allocator_option)
{
    UnitTestResult result = {0};
    String8 command_line[8] = {0};
    u32 command_count = 0;
    command_line[command_count++] = debug_info ? S8("-g") : S8("-g0");
    command_line[command_count++] = allocator_option;
#if BUSTER_WINDOWS
    command_line[command_count++] = S8("-l");
    command_line[command_count++] = S8("ntdll");
#endif
    command_line[command_count++] = S8("-o");
    command_line[command_count++] = output_path;
    command_line[command_count++] = source_path;
    CompilerDriverInvocation invocation = compiler_driver_parse_arguments(arguments->arena, (SliceString8){command_line, command_count});
    CompilerDriverResult compiled = compiler_driver_execute_invocation(arguments->arena, invocation);
    if (compiled.error != COMPILER_DRIVER_ERROR_NONE)
    {
        arguments->show(arguments, S8("runtime stack-walk child compilation failed: {S8}\n"), compiled.diagnostic);
    }
    BUSTER_TEST(arguments, compiled.error == COMPILER_DRIVER_ERROR_NONE);
    if (compiled.error == COMPILER_DRIVER_ERROR_NONE)
    {
        BUSTER_TEST(arguments, compiled.has_object);
        BUSTER_TEST(arguments, compiled.native_link.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, compiled.native_link.executable.length != 0);
        BUSTER_TEST(arguments, compiled.codegen_statistics.function_count >= 3);
        BUSTER_TEST(arguments, compiled.codegen_statistics.stack_value_bytes != 0);
        BUSTER_TEST(arguments, compiled.codegen_statistics.maximum_stack_frame_bytes > 4096);
        if (compiled.has_object && compiled.native_link.error == LINK_ERROR_NONE && compiled.native_link.executable.length)
        {
            ObjectSectionKind debug_kinds[] = {
                OBJECT_SECTION_DEBUG_INFO,
                OBJECT_SECTION_DEBUG_ABBREV,
                OBJECT_SECTION_DEBUG_LINE,
                OBJECT_SECTION_DEBUG_STR,
                OBJECT_SECTION_DEBUG_LOC,
                OBJECT_SECTION_DEBUG_RANGES,
                OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS,
                OBJECT_SECTION_DEBUG_CODEVIEW_TYPES,
            };
            bool has_debug = false;
            for (u32 kind_index = 0; kind_index < BUSTER_ARRAY_LENGTH(debug_kinds); kind_index += 1)
            {
                has_debug |= compiled.object.sections[debug_kinds[kind_index]].data.length != 0;
            }
            BUSTER_TEST(arguments, has_debug == debug_info);

            ByteSlice image = compiled.native_link.executable;
            bool has_unwind = false;
#if BUSTER_LINUX
            u32 unwind_section_index = 0;
            u64 unwind_section_header = 0;
            bool unwind_found = link_test_elf_section_find(image, S8(".eh_frame"), &unwind_section_index, &unwind_section_header);
            bool unwind_header_found = link_test_elf_section_find(image, S8(".eh_frame_hdr"), 0, 0);
            has_unwind = unwind_found && unwind_header_found && link_test_runtime_has_eh_frame_header(image);
#elif BUSTER_MACOS
            has_unwind = link_test_mach_section_find(image, S8("__TEXT"), S8("__eh_frame"), 0);
#elif BUSTER_WINDOWS
            bool pdata_found = link_test_pe_section_find(image, S8(".pdata"), 0, 0);
            bool xdata_found = link_test_pe_section_find(image, S8(".xdata"), 0, 0);
            has_unwind = pdata_found && xdata_found;
            bool has_frame_register = false;
            bool has_large_allocation = false;
            bool xdata_metadata_valid = link_test_runtime_windows_xdata(&compiled.object, &has_frame_register, &has_large_allocation);
            BUSTER_TEST(arguments, xdata_metadata_valid && has_frame_register && has_large_allocation);
#endif
            BUSTER_TEST(arguments, has_unwind);

            u64 normal_value = 0;
            u64 normal_size = 0;
            u64 large_value = 0;
            u64 large_size = 0;
            u64 main_value = 0;
            u64 main_size = 0;
            bool normal_symbol_found = link_test_runtime_symbol_find(&compiled.object, S8("stack_walk_normal"), &normal_value, &normal_size);
            bool large_symbol_found = link_test_runtime_symbol_find(&compiled.object, S8("stack_walk_large"), &large_value, &large_size);
            bool main_symbol_found = link_test_runtime_symbol_find(&compiled.object, S8("main"), &main_value, &main_size);
            BUSTER_TEST(arguments, normal_symbol_found && normal_size != 0);
            BUSTER_TEST(arguments, large_symbol_found && large_size != 0);
            BUSTER_TEST(arguments, main_symbol_found && main_size != 0);
            if (normal_symbol_found && normal_size && large_symbol_found && large_size && main_symbol_found && main_size)
            {
                String8 run_arguments[] = {output_path};
                ProcessSpawnResult spawn = os_process_spawn((SliceString8)BUSTER_ARRAY_TO_SLICE(run_arguments), (SliceString8){0}, (SliceString8){0},
                                                            (ProcessSpawnOptions){
                                                                .capture = (u64)1 << STANDARD_STREAM_OUTPUT,
                                                                .use_process_environment = true, .search_path = true,
                                                            });
                BUSTER_TEST(arguments, spawn.handle != 0);
                if (!spawn.handle)
                {
                    return result;
                }
                ProcessWaitResult wait = os_process_wait_sync(arguments->arena, spawn);
                ByteSlice output = wait.streams[STANDARD_STREAM_OUTPUT];
                LinkTestRuntimeReport report = {0};
                bool report_size_valid = output.length == sizeof(report);
                if (report_size_valid)
                {
                    memcpy(&report, output.pointer, sizeof(report));
                }
                if (wait.result != PROCESS_RESULT_SUCCESS)
                {
#if BUSTER_WINDOWS
                    arguments->show(arguments, S8("runtime stack-walk child failed: result={u32} platform_status={u32:x} output_bytes={u64} "
                                                  "normal={u64} large={u64} semantic={u64:x} body={u64} large_body={u64}\n"),
                                    (u32)wait.result, wait.platform_status, output.length, report.normal_count, report.large_count,
                                    report.semantic_status, report.body_status, report.large_body_status);
#else
                    arguments->show(arguments, S8("runtime stack-walk child failed: result={u32} platform_status={u32:x} output_bytes={u64} "
                                                  "normal={u64} large={u64}\n"),
                                    (u32)wait.result, wait.platform_status, output.length, report.normal_count, report.large_count);
#endif
                }
#if BUSTER_WINDOWS && BUSTER_CPU_ARCH_X86_64
                if (wait.result != PROCESS_RESULT_SUCCESS)
                {
                    arguments->show(arguments, S8("fixed-stack unwind failure: status={u64} boundaries={u64} saved_mask={u64:x} offset={u64:x}\n"),
                                    report.fixed_status, report.fixed_boundaries, report.fixed_saved_mask, report.fixed_failure);
                }
#endif
                BUSTER_TEST(arguments, wait.result == PROCESS_RESULT_SUCCESS);
                BUSTER_TEST(arguments, report_size_valid);
                if (wait.result != PROCESS_RESULT_SUCCESS || !report_size_valid)
                {
                    return result;
                }
                BUSTER_TEST(arguments, report.normal_entry != 0 && report.large_entry != 0 && report.main_entry != 0);
                BUSTER_TEST(arguments, report.normal_count != 0 && report.normal_count <= BUSTER_ARRAY_LENGTH(report.normal_frames));
                BUSTER_TEST(arguments, report.large_count != 0 && report.large_count <= BUSTER_ARRAY_LENGTH(report.large_frames));
#if BUSTER_WINDOWS
                BUSTER_TEST(arguments, report.semantic_status == UINT64_C(0x535441434b434f50));
                BUSTER_TEST(arguments, report.body_status == 1 && report.large_body_status == 1);
#if BUSTER_CPU_ARCH_X86_64
                arguments->show(arguments, S8("fixed-stack unwind: status={u64} boundaries={u64} saved_mask={u64:x} failure={u64:x}\n"),
                                report.fixed_status, report.fixed_boundaries, report.fixed_saved_mask, report.fixed_failure);
                BUSTER_TEST(arguments, report.fixed_status == 1 && report.fixed_boundaries != 0 && report.fixed_failure == 0);
                BUSTER_TEST(arguments, (report.fixed_saved_mask & ~(UINT64_C(1) << 5)) != 0);
                BUSTER_TEST(arguments, report.epilog_status == 1 && report.epilog_unwind_pc != 0);
                BUSTER_TEST(arguments, report.large_epilog_status == 1 && report.large_epilog_unwind_pc != 0);
#endif
#endif
                if (!report.normal_entry || !report.large_entry || !report.main_entry || !report.normal_count || !report.large_count ||
                    report.normal_count > BUSTER_ARRAY_LENGTH(report.normal_frames) || report.large_count > BUSTER_ARRAY_LENGTH(report.large_frames))
                {
                    return result;
                }

                bool base_ranges_valid = report.normal_entry >= normal_value && report.large_entry >= large_value && report.main_entry >= main_value;
                u64 normal_base = report.normal_entry - normal_value;
                u64 large_base = report.large_entry - large_value;
                u64 main_base = report.main_entry - main_value;
                base_ranges_valid &= normal_base == large_base && normal_base == main_base;
                BUSTER_TEST(arguments, base_ranges_valid);
                if (!base_ranges_valid)
                {
                    return result;
                }
                u64 normal_begin = normal_base + normal_value;
                u64 large_begin = normal_base + large_value;
                u64 main_begin = normal_base + main_value;
#if BUSTER_WINDOWS && BUSTER_CPU_ARCH_X86_64
                bool epilog_unwind_reached_main = report.epilog_unwind_pc >= main_begin && report.epilog_unwind_pc < main_begin + main_size;
                BUSTER_TEST(arguments, epilog_unwind_reached_main);
                bool large_epilog_unwind_reached_main = report.large_epilog_unwind_pc >= main_begin && report.large_epilog_unwind_pc < main_begin + main_size;
                BUSTER_TEST(arguments, large_epilog_unwind_reached_main);
#endif
                bool normal_contains_normal = link_test_runtime_frame_contains(report.normal_frames, report.normal_count, normal_begin, normal_size);
                bool normal_contains_main = link_test_runtime_frame_contains(report.normal_frames, report.normal_count, main_begin, main_size);
                bool large_contains_large = link_test_runtime_frame_contains(report.large_frames, report.large_count, large_begin, large_size);
                bool large_contains_main = link_test_runtime_frame_contains(report.large_frames, report.large_count, main_begin, main_size);
                BUSTER_TEST(arguments, normal_contains_normal && normal_contains_main);
                BUSTER_TEST(arguments, large_contains_large && large_contains_main);
            }
        }
    }

    return result;
}
#endif

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_runtime_stack_walk(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
#if BUSTER_SANITIZE
    link_test_runtime_stack_walk_skip(arguments, S8("sanitizer builds do not execute generated native child code"));
#elif BUSTER_ANDROID
    link_test_runtime_stack_walk_skip(arguments, S8("Android runtime execution is device-managed and has no host child-executable gate"));
#elif BUSTER_IOS
    link_test_runtime_stack_walk_skip(arguments, S8("iOS runtime execution is simulator-managed and has no host child-executable gate"));
#elif BUSTER_LINUX && !(BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64)
    link_test_runtime_stack_walk_skip(arguments, S8("Linux runtime stack walking is only enabled for native x86-64 and AArch64"));
#elif BUSTER_MACOS && !(BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64)
    link_test_runtime_stack_walk_skip(arguments, S8("macOS runtime stack walking is only enabled for native x86-64 and AArch64"));
#elif BUSTER_WINDOWS && !(BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64)
    link_test_runtime_stack_walk_skip(arguments, S8("Windows runtime stack walking is only enabled for native x64 and AArch64"));
#elif !BUSTER_SANITIZE && !BUSTER_ANDROID && !BUSTER_IOS && (BUSTER_LINUX || BUSTER_MACOS || BUSTER_WINDOWS) && (BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64)
    String8 source = link_test_runtime_stack_walk_source(arguments->arena);
    String8 source_path = link_test_temporary_executable_path(arguments->arena, S8("buster-runtime-stack-walk"), S8(".c"));
#if BUSTER_WINDOWS
    String8 output_suffix = S8(".exe");
    UnitTestResult save_slots = link_test_runtime_windows_xdata_save_slots(arguments);
    UnitTestResult frame_prefix = link_test_runtime_windows_arm64_xdata_frame_prefix(arguments);
    result.succeeded_test_count += save_slots.succeeded_test_count + frame_prefix.succeeded_test_count;
    result.test_count += save_slots.test_count + frame_prefix.test_count;
#else
    String8 output_suffix = S8("");
#endif
    BUSTER_TEST(arguments, source.length != 0 && source_path.length != 0);
    if (source.length && source_path.length && file_write(source_path, BUSTER_SLICE_TO_BYTE_SLICE(source)))
    {
        String8 debug_output = link_test_temporary_executable_path(arguments->arena, S8("buster-runtime-stack-walk-debug"), output_suffix);
        String8 no_debug_output = link_test_temporary_executable_path(arguments->arena, S8("buster-runtime-stack-walk-g0"), output_suffix);
        String8 allocator_options[] = {
            S8("-fregister-allocator=fast"),
#if BUSTER_WINDOWS && BUSTER_CPU_ARCH_X86_64
            S8("-fregister-allocator=none"), S8("-fregister-allocator=mir-stack"), S8("-fregister-allocator=quality"),
#endif
        };
        for (u32 mode = 0; mode < BUSTER_ARRAY_LENGTH(allocator_options); mode += 1)
        {
            UnitTestResult debug_result = link_test_runtime_stack_walk_variant(arguments, source_path, debug_output, true, allocator_options[mode]);
            UnitTestResult no_debug_result = link_test_runtime_stack_walk_variant(arguments, source_path, no_debug_output, false, allocator_options[mode]);
            result.succeeded_test_count += debug_result.succeeded_test_count + no_debug_result.succeeded_test_count;
            result.test_count += debug_result.test_count + no_debug_result.test_count;
        }
    }
    else
    {
        link_test_runtime_stack_walk_skip(arguments, S8("could not create the native runtime source artifact"));
        BUSTER_TEST(arguments, false);
    }
#else
    link_test_runtime_stack_walk_skip(arguments, S8("native runtime stack walking is not implemented for this target operating system"));
#endif
    return result;
}


typedef struct LinkTestUefiPeSection LinkTestUefiPeSection;
struct LinkTestUefiPeSection
{
    u32 virtual_size;
    u32 virtual_address;
    u32 raw_size;
    u32 raw_offset;
    u32 characteristics;
};

BUSTER_GLOBAL_LOCAL u16 link_test_uefi_read_u16(ByteSlice image, u64 offset)
{
    u16 value = 0;
    if (offset <= image.length && sizeof(value) <= image.length - offset)
    {
        memcpy(&value, image.pointer + offset, sizeof(value));
    }
    return value;
}

BUSTER_GLOBAL_LOCAL bool link_test_uefi_pe_section_find(ByteSlice image, String8 name, LinkTestUefiPeSection* result)
{
    if (result && image.length >= 0x40 && image.pointer[0] == 'M' && image.pointer[1] == 'Z')
    {
        u32 pe_offset = link_read_u32(image.pointer, 0x3c);
        if (pe_offset <= image.length && 24 <= image.length - pe_offset && memcmp(image.pointer + pe_offset, "PE\0\0", 4) == 0)
        {
            u16 section_count = link_test_uefi_read_u16(image, pe_offset + 6);
            u16 optional_size = link_test_uefi_read_u16(image, pe_offset + 20);
            u64 section_table = (u64)pe_offset + 24 + optional_size;
            if (section_table <= image.length && (u64)section_count <= (image.length - section_table) / 40)
            {
                for (u32 section_index = 0; section_index < section_count; section_index += 1)
                {
                    u64 header = section_table + (u64)section_index * 40;
                    String8 candidate = {.pointer = (char8*)image.pointer + header};
                    while (candidate.length < 8 && candidate.pointer[candidate.length])
                    {
                        candidate.length += 1;
                    }
                    if (string_equal(candidate, name))
                    {
                        *result = (LinkTestUefiPeSection){
                            .virtual_size = link_read_u32(image.pointer, header + 8),
                            .virtual_address = link_read_u32(image.pointer, header + 12),
                            .raw_size = link_read_u32(image.pointer, header + 16),
                            .raw_offset = link_read_u32(image.pointer, header + 20),
                            .characteristics = link_read_u32(image.pointer, header + 36),
                        };
                        return result->raw_offset <= image.length && result->raw_size <= image.length - result->raw_offset;
                    }
                }
            }
        }
    }

    return false;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_uefi_pe64(UnitTestArguments* arguments, CpuArch architecture)
{
    UnitTestResult result = {0};
    bool aarch64 = architecture == CPU_ARCH_AARCH64;
    Target target = {
        .cpu_arch = architecture,
        .cpu_model = CPU_MODEL_BASELINE,
        .os = OPERATING_SYSTEM_UEFI,
    };
    u8 x64_text[] = {0xc3};
    u8 aarch64_text[] = {0xc0, 0x03, 0x5f, 0xd6};
    ByteSlice text = aarch64 ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(aarch64_text) : (ByteSlice)BUSTER_ARRAY_TO_SLICE(x64_text);
    u8 data[8] = {0};
    u8 pdata[12] = {0};
    u8 xdata[4] = {1, 0, 0, 0};
    ObjectSymbol symbols[] = {
        {
            .name = S8("UefiMain"),
            .size = text.length,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8(".Luefi_xdata"),
            .size = sizeof(xdata),
            .section = OBJECT_SECTION_WINDOWS_XDATA,
            .kind = OBJECT_SYMBOL_DATA,
        },
    };
    ObjectRelocation relocations[4] = {
        {
            .offset = 0,
            .section = OBJECT_SECTION_DATA,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        },
        {
            .offset = 0,
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        },
        {
            .addend = aarch64 ? 0 : (s64)text.length,
            .offset = 4,
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .symbol = aarch64 ? 1 : 0,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        },
        {
            .offset = 8,
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        },
    };
    u32 relocation_count = aarch64 ? 3 : 4;
    if (aarch64)
    {
        relocations[2].addend = 0;
        relocations[2].symbol = 1;
    }
    ObjectFile object = link_test_object_make(arguments->arena, target, text, symbols, BUSTER_ARRAY_LENGTH(symbols), relocations, relocation_count);
    object.sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(data);
    object.sections[OBJECT_SECTION_DATA].virtual_size = sizeof(data);
    object.sections[OBJECT_SECTION_WINDOWS_PDATA].data = (ByteSlice){.pointer = pdata, .length = aarch64 ? 8 : sizeof(pdata)};
    object.sections[OBJECT_SECTION_WINDOWS_PDATA].virtual_size = object.sections[OBJECT_SECTION_WINDOWS_PDATA].data.length;
    object.sections[OBJECT_SECTION_WINDOWS_XDATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(xdata);
    object.sections[OBJECT_SECTION_WINDOWS_XDATA].virtual_size = sizeof(xdata);

    NativeExecutableLinkResult linked = link_native_executable(arguments->arena, &object, (NativeExecutableLinkOptions){0});
    BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
    bool pe_valid = linked.executable.length >= 0x80 && linked.executable.pointer[0] == 'M' && linked.executable.pointer[1] == 'Z';
    BUSTER_TEST(arguments, pe_valid);
    if (pe_valid)
    {
        u32 pe_offset = link_read_u32(linked.executable.pointer, 0x3c);
        pe_valid = pe_offset <= linked.executable.length && 24 + 240 <= linked.executable.length - pe_offset &&
                   memcmp(linked.executable.pointer + pe_offset, "PE\0\0", 4) == 0;
        BUSTER_TEST(arguments, pe_valid);
        if (pe_valid)
        {
            u64 optional = (u64)pe_offset + 24;
            u16 expected_machine = aarch64 ? 0xaa64 : 0x8664;
            BUSTER_TEST(arguments, link_test_uefi_read_u16(linked.executable, pe_offset + 4) == expected_machine);
            BUSTER_TEST(arguments, link_test_uefi_read_u16(linked.executable, optional) == 0x20b);
            BUSTER_TEST(arguments, link_test_uefi_read_u16(linked.executable, optional + 68) == 10);
            BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, optional + 108) == 16);
            BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, optional + 120) == 0);
            BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, optional + 124) == 0);
            u32 entry_rva = link_read_u32(linked.executable.pointer, optional + 16);
            u64 image_base = link_read_u64(linked.executable.pointer, optional + 24);
            BUSTER_TEST(arguments, entry_rva != 0 && image_base == UINT64_C(0x140000000));

            LinkTestUefiPeSection text_section = {0};
            LinkTestUefiPeSection data_section = {0};
            LinkTestUefiPeSection pdata_section = {0};
            LinkTestUefiPeSection xdata_section = {0};
            LinkTestUefiPeSection relocation_section = {0};
            bool sections_valid = link_test_uefi_pe_section_find(linked.executable, S8(".text"), &text_section) &&
                                  link_test_uefi_pe_section_find(linked.executable, S8(".data"), &data_section) &&
                                  link_test_uefi_pe_section_find(linked.executable, S8(".pdata"), &pdata_section) &&
                                  link_test_uefi_pe_section_find(linked.executable, S8(".xdata"), &xdata_section) &&
                                  link_test_uefi_pe_section_find(linked.executable, S8(".reloc"), &relocation_section);
            BUSTER_TEST(arguments, sections_valid);
            if (sections_valid)
            {
                BUSTER_TEST(arguments, entry_rva == text_section.virtual_address);
                BUSTER_TEST(arguments, link_read_u64(linked.executable.pointer, data_section.raw_offset) == image_base + entry_rva);
                BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, optional + 136) == pdata_section.virtual_address);
                BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, optional + 140) == pdata_section.virtual_size);
                BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, optional + 152) == relocation_section.virtual_address);
                BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, optional + 156) == relocation_section.virtual_size);
                BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, pdata_section.raw_offset) == text_section.virtual_address);
                if (aarch64)
                {
                    BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, pdata_section.raw_offset + 4) == xdata_section.virtual_address);
                }
                else
                {
                    BUSTER_TEST(arguments,
                                link_read_u32(linked.executable.pointer, pdata_section.raw_offset + 4) == text_section.virtual_address + text.length);
                    BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, pdata_section.raw_offset + 8) == xdata_section.virtual_address);
                }
                u32 relocation_page = link_read_u32(linked.executable.pointer, relocation_section.raw_offset);
                u32 relocation_block_size = link_read_u32(linked.executable.pointer, relocation_section.raw_offset + 4);
                u16 relocation_entry = link_test_uefi_read_u16(linked.executable, relocation_section.raw_offset + 8);
                BUSTER_TEST(arguments, relocation_page == (data_section.virtual_address & ~UINT32_C(0xfff)));
                BUSTER_TEST(arguments, relocation_block_size == 12);
                BUSTER_TEST(arguments, (relocation_entry >> 12) == 10);
                BUSTER_TEST(arguments, (relocation_entry & 0xfff) == (data_section.virtual_address & 0xfff));
            }
        }
    }

    if (aarch64)
    {
        u32 page_text[] = {UINT32_C(0x90000008), UINT32_C(0x91000100), UINT32_C(0x90000009), UINT32_C(0xfd400120), UINT32_C(0xd65f03c0)};
        u8 page_data[256] = {0};
        ObjectSymbol page_symbols[] = {
            {.name = S8("UefiMain"), .size = sizeof(page_text), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
            {.name = S8("page_data"), .value = 104, .size = 8, .section = OBJECT_SECTION_DATA, .kind = OBJECT_SYMBOL_DATA},
        };
        ObjectRelocation page_relocations[] = {
            {.addend = 7, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21},
            {.addend = 7, .offset = 4, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A},
            {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21},
            {.offset = 12, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L},
        };
        ByteSlice page_text_bytes = {.pointer = (u8*)page_text, .length = sizeof(page_text)};
        ObjectFile page_object = link_test_object_make(arguments->arena, target, page_text_bytes, page_symbols, BUSTER_ARRAY_LENGTH(page_symbols),
                                                       page_relocations, BUSTER_ARRAY_LENGTH(page_relocations));
        page_object.sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(page_data);
        page_object.sections[OBJECT_SECTION_DATA].virtual_size = sizeof(page_data);
        NativeExecutableLinkResult page_linked = link_native_executable(arguments->arena, &page_object, (NativeExecutableLinkOptions){0});
        LinkTestUefiPeSection page_text_section = {0};
        LinkTestUefiPeSection page_data_section = {0};
        bool page_valid = page_linked.error == LINK_ERROR_NONE &&
                          link_test_uefi_pe_section_find(page_linked.executable, S8(".text"), &page_text_section) &&
                          link_test_uefi_pe_section_find(page_linked.executable, S8(".data"), &page_data_section);
        BUSTER_TEST(arguments, page_valid);
        if (page_valid)
        {
            A64MCInst page = {0};
            A64MCInst load_page = {0};
            u32 low = 0;
            BUSTER_TEST(arguments, a64_mc_decode(link_read_u32(page_linked.executable.pointer, page_text_section.raw_offset), &page) &&
                                       page.opcode == A64_OPCODE_ADRP);
            BUSTER_TEST(arguments, a64_add_lo12_read(link_read_u32(page_linked.executable.pointer, page_text_section.raw_offset + 4), &low));
            u64 actual = ((u64)page_text_section.virtual_address & ~UINT64_C(0xfff)) + (u64)page.operands[1].value + low;
            BUSTER_TEST(arguments, actual == (u64)page_data_section.virtual_address + 111 && low == 111);
            u32 load_word = link_read_u32(page_linked.executable.pointer, page_text_section.raw_offset + 12);
            BUSTER_TEST(arguments, a64_mc_decode(link_read_u32(page_linked.executable.pointer, page_text_section.raw_offset + 8), &load_page) &&
                                       load_page.opcode == A64_OPCODE_ADRP);
            u64 load_actual = ((u64)page_text_section.virtual_address & ~UINT64_C(0xfff)) + (u64)load_page.operands[1].value +
                              (((load_word >> 10) & A64_IMM12_MAX) << 3);
            BUSTER_TEST(arguments, load_actual == (u64)page_data_section.virtual_address + 104 &&
                                       (load_word & ~(A64_IMM12_MAX << 10)) == UINT32_C(0xfd400120));
        }
        page_text[1] = UINT32_C(0x91400100);
        NativeExecutableLinkResult malformed = link_native_executable(arguments->arena, &page_object, (NativeExecutableLinkOptions){0});
        BUSTER_TEST(arguments, malformed.error == LINK_ERROR_RELOCATION && !malformed.executable.length);
        page_text[1] = UINT32_C(0x91000100);
        page_text[3] = UINT32_C(0xfc400120);
        malformed = link_native_executable(arguments->arena, &page_object, (NativeExecutableLinkOptions){0});
        BUSTER_TEST(arguments, malformed.error == LINK_ERROR_RELOCATION && !malformed.executable.length);
    }

    NativeExecutableLinkResult missing_entry =
        link_native_executable(arguments->arena, &object, (NativeExecutableLinkOptions){.entry_symbol = S8("MissingEntry")});
    BUSTER_TEST(arguments, missing_entry.error == LINK_ERROR_ENTRY_SYMBOL);

    ObjectSymbol unresolved_symbols[3];
    memcpy(unresolved_symbols, symbols, sizeof(symbols));
    unresolved_symbols[2] = (ObjectSymbol){
        .name = S8("FirmwareImport"),
        .section = OBJECT_SECTION_UNDEFINED,
        .kind = OBJECT_SYMBOL_DATA,
        .global = true,
    };
    ObjectRelocation unresolved_relocations[4];
    memcpy(unresolved_relocations, relocations, sizeof(relocations));
    unresolved_relocations[0].symbol = 2;
    ObjectFile unresolved_object = object;
    unresolved_object.symbols = unresolved_symbols;
    unresolved_object.symbol_count = BUSTER_ARRAY_LENGTH(unresolved_symbols);
    unresolved_object.relocations = unresolved_relocations;
    NativeExecutableLinkResult unresolved = link_native_executable(arguments->arena, &unresolved_object, (NativeExecutableLinkOptions){0});
    BUSTER_TEST(arguments, unresolved.error == LINK_ERROR_UNRESOLVED_SYMBOL);

    u8 tls_byte = 0;
    ObjectSection tls_sections[OBJECT_SECTION_COUNT];
    memcpy(tls_sections, object.sections, sizeof(tls_sections));
    tls_sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data = (ByteSlice){.pointer = &tls_byte, .length = 1};
    tls_sections[OBJECT_SECTION_THREAD_LOCAL_DATA].virtual_size = 1;
    ObjectFile tls_object = object;
    tls_object.sections = tls_sections;
    NativeExecutableLinkResult tls = link_native_executable(arguments->arena, &tls_object, (NativeExecutableLinkOptions){0});
    BUSTER_TEST(arguments, tls.error == LINK_ERROR_UNSUPPORTED_FEATURE);

    u8 bss_byte = 0;
    ObjectSection bss_sections[OBJECT_SECTION_COUNT];
    memcpy(bss_sections, object.sections, sizeof(bss_sections));
    bss_sections[OBJECT_SECTION_ZERO].data = (ByteSlice){.pointer = &bss_byte, .length = 1};
    bss_sections[OBJECT_SECTION_ZERO].virtual_size = 1;
    ObjectFile invalid_bss_object = object;
    invalid_bss_object.sections = bss_sections;
    NativeExecutableLinkResult invalid_bss = link_native_executable(arguments->arena, &invalid_bss_object, (NativeExecutableLinkOptions){0});
    BUSTER_TEST(arguments, invalid_bss.error == LINK_ERROR_INVALID_INPUT);

    NativeDynamicLibrary dynamic_library = {0};
    NativeExecutableLinkResult dynamic = link_native_executable(arguments->arena, &object,
                                                                (NativeExecutableLinkOptions){
                                                                    .dynamic_libraries = &dynamic_library,
                                                                    .dynamic_library_count = 1,
                                                                });
    BUSTER_TEST(arguments, dynamic.error == LINK_ERROR_UNSUPPORTED_FEATURE);
    return result;
}

// Inspect both ELF writers on every host; runtime fixtures separately check
// that the C frontend's alignment survives linking a real object file.
BUSTER_GLOBAL_LOCAL UnitTestResult link_test_elf_data_alignment(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    u32 alignments[] = {16, 8192, 65536, 8 * 1024 * 1024};
    for (u32 arch = 0; arch < BUSTER_ARRAY_LENGTH(architectures); arch += 1)
    {
        for (u32 hosted = 0; hosted < 2; hosted += 1)
        {
            for (u32 alignment_index = 0; alignment_index < BUSTER_ARRAY_LENGTH(alignments); alignment_index += 1)
            {
                TemporalArena temporary = scratch_begin(&arguments->arena, 1);
                Arena* arena = temporary.arena;
                u8 text[] = {0x31, 0xc0, 0xc3, 0};
                u32 aarch64_text[] = {0x52800000, 0xd65f03c0};
                ByteSlice code = architectures[arch] == CPU_ARCH_X86_64 ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(text)
                                                                       : (ByteSlice){.pointer = (u8*)aarch64_text, .length = sizeof(aarch64_text)};
                ObjectSymbol symbol = {.name = S8("main"), .size = code.length, .section = OBJECT_SECTION_TEXT,
                                       .kind = OBJECT_SYMBOL_FUNCTION, .global = true};
                ObjectFile object = link_test_object_make(arena, (Target){.cpu_arch = architectures[arch], .os = OPERATING_SYSTEM_LINUX},
                                                          code, &symbol, 1, 0, 0);
                u8 data[] = {7, 0, 0, 0};
                object.sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(data);
                object.sections[OBJECT_SECTION_DATA].alignment = alignments[alignment_index];
                object.sections[OBJECT_SECTION_ZERO].virtual_size = 4;
                object.sections[OBJECT_SECTION_ZERO].alignment = alignments[alignment_index];
                NativeDynamicLibrary library = {.name = S8("libalignmentprobe.so")};
                NativeExecutableLinkResult linked = link_native_executable(arena, &object, (NativeExecutableLinkOptions){
                    .dynamic_libraries = &library, .dynamic_library_count = hosted,
                });
                BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
                if (linked.error == LINK_ERROR_NONE)
                {
                    ObjectSectionKind kinds[] = {OBJECT_SECTION_DATA, OBJECT_SECTION_ZERO};
                    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(kinds); index += 1)
                    {
                        u64 header = 0;
                        bool found = link_test_elf_section_find(linked.executable, object_section_name_for_kind(kinds[index]), 0, &header);
                        BUSTER_TEST(arguments, found);
                        if (found)
                        {
                            u64 alignment = object.sections[kinds[index]].alignment;
                            BUSTER_TEST(arguments, link_read_u64(linked.executable.pointer, header + 48) == alignment);
                            BUSTER_TEST(arguments, link_read_u64(linked.executable.pointer, header + 16) % alignment == 0);
                        }
                    }
                    if (hosted)
                    {
                        BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, S8("__cxa_atexit"), 0, 0, 0));
                    }
                }
                scratch_end(temporary);
            }
        }
    }
    return result;
}

// Merged file-backed bytes must not depend on previous arena users. Check
// whole section contents and serialized artifacts, including both kinds of
// unwritten span: alignment gaps and virtual bytes past an input's data.
BUSTER_GLOBAL_LOCAL UnitTestResult link_test_merged_section_initialization(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_WINDOWS, OPERATING_SYSTEM_MACOS};
    ObjectSectionKind kinds[] = {OBJECT_SECTION_TEXT, OBJECT_SECTION_DATA, OBJECT_SECTION_READ_ONLY_DATA};
    u8 first_bytes[] = {0x11, 0x22, 0x33};
    u8 second_bytes[] = {0x44, 0x55};
    u8 expected[43] = {0};
    memcpy(expected, first_bytes, sizeof(first_bytes));
    memcpy(expected + 32, second_bytes, sizeof(second_bytes));
    u8 poison_values[] = {0, 0xa5, 0x3c};
    for (u32 arch = 0; arch < BUSTER_ARRAY_LENGTH(architectures); arch += 1)
    {
        for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
        {
            Target target = {.cpu_arch = architectures[arch], .os = systems[system]};
            ObjectSymbol first_symbol = {.name = S8("first"), .section = OBJECT_SECTION_TEXT, .size = sizeof(first_bytes),
                                         .kind = OBJECT_SYMBOL_FUNCTION, .global = true};
            ObjectSymbol second_symbol = {.name = S8("second"), .section = OBJECT_SECTION_TEXT, .size = sizeof(second_bytes),
                                          .kind = OBJECT_SYMBOL_FUNCTION, .global = true};
            ObjectFile objects[] = {
                link_test_object_make(arguments->arena, target, (ByteSlice){0}, &first_symbol, 1, 0, 0),
                link_test_object_make(arguments->arena, target, (ByteSlice){0}, &second_symbol, 1, 0, 0),
            };
            for (u32 kind_index = 0; kind_index < BUSTER_ARRAY_LENGTH(kinds); kind_index += 1)
            {
                ObjectSectionKind kind = kinds[kind_index];
                objects[0].sections[kind].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(first_bytes);
                objects[0].sections[kind].virtual_size = 7;
                objects[0].sections[kind].alignment = 8;
                objects[1].sections[kind].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(second_bytes);
                objects[1].sections[kind].virtual_size = 11;
                objects[1].sections[kind].alignment = 32;
            }
            objects[0].sections[OBJECT_SECTION_ZERO].virtual_size = 7;
            objects[0].sections[OBJECT_SECTION_ZERO].alignment = 8;
            objects[1].sections[OBJECT_SECTION_ZERO].virtual_size = 11;
            objects[1].sections[OBJECT_SECTION_ZERO].alignment = 32;
            Arena* arena = arena_create((ArenaCreation){.reserved_size = BUSTER_MB(1), .flags = {.no_pool = 1}});
            BUSTER_TEST(arguments, arena != 0);
            if (arena)
            {
                ByteSlice reference = {0};
                for (u32 run = 0; run < BUSTER_ARRAY_LENGTH(poison_values); run += 1)
                {
                    arena_reset_to_start(arena);
                    if (run)
                    {
                        memset(arena_allocate(arena, u8, BUSTER_KB(64)), poison_values[run], BUSTER_KB(64));
                        arena_reset_to_start(arena);
                    }
                    LinkObjectResult merged = link_objects(arena, objects, BUSTER_ARRAY_LENGTH(objects), (LinkOptions){0});
                    BUSTER_TEST(arguments, merged.error == LINK_ERROR_NONE);
                    if (merged.error == LINK_ERROR_NONE)
                    {
                        for (u32 kind_index = 0; kind_index < BUSTER_ARRAY_LENGTH(kinds); kind_index += 1)
                        {
                            ObjectSection* section = merged.object.sections + kinds[kind_index];
                            BUSTER_TEST(arguments, section->data.length == sizeof(expected));
                            BUSTER_TEST(arguments, section->virtual_size == sizeof(expected));
                            BUSTER_TEST(arguments, section->alignment == 32);
                            BUSTER_TEST(arguments, section->data.length == sizeof(expected) &&
                                                       memcmp(section->data.pointer, expected, sizeof(expected)) == 0);
                        }
                        ObjectSection* zero = merged.object.sections + OBJECT_SECTION_ZERO;
                        BUSTER_TEST(arguments, zero->data.pointer == 0 && zero->data.length == 0 && zero->virtual_size == sizeof(expected));
                        BUSTER_TEST(arguments, merged.object.symbol_count == 2 && merged.object.symbols[0].value == 0 &&
                                                   merged.object.symbols[1].value == 32);
                        ObjectArtifact artifact = object_write(arena, &merged.object, object_format_for_target(target));
                        BUSTER_TEST(arguments, artifact.error == OBJECT_ERROR_NONE);
                        if (artifact.error == OBJECT_ERROR_NONE)
                        {
                            if (!run)
                            {
                                reference.length = artifact.bytes.length;
                                reference.pointer = arena_allocate(arguments->arena, u8, reference.length);
                                memcpy(reference.pointer, artifact.bytes.pointer, reference.length);
                            }
                            else
                            {
                                BUSTER_TEST(arguments, artifact.bytes.length == reference.length &&
                                                           memcmp(artifact.bytes.pointer, reference.pointer, reference.length) == 0);
                            }
                            ObjectFile decoded = object_read(arena, artifact.bytes, target);
                            BUSTER_TEST(arguments, decoded.error == OBJECT_ERROR_NONE);
                            if (decoded.error == OBJECT_ERROR_NONE)
                            {
                                for (u32 kind_index = 0; kind_index < BUSTER_ARRAY_LENGTH(kinds); kind_index += 1)
                                {
                                    ObjectSection* section = decoded.sections + kinds[kind_index];
                                    BUSTER_TEST(arguments, section->data.length >= sizeof(expected) &&
                                                               memcmp(section->data.pointer, expected, sizeof(expected)) == 0);
                                }
                            }
                        }
                        BUSTER_TEST(arguments, arena->position <= arena_minimum_position + BUSTER_KB(64));
                    }
                }
                BUSTER_TEST(arguments, arena_destroy(arena, 1));
            }
        }
    }
    return result;
}

// Places a synthetic image at the start of `arena` and appends the production
// ELF section table to it. Unless `dirty_tail` is UINT64_MAX, the arena bytes
// below that offset into the appended tail are poisoned and rewound first, so
// on a fresh arena the dirty high-water mark lies exactly there and the storage
// above it has never been written. `copy` allocates one byte after the image,
// so the append cannot grow the image in place and takes its copying path.
BUSTER_GLOBAL_LOCAL NativeExecutableLinkResult link_test_section_table_place(Arena* arena, ByteSlice prefix, ObjectFile* object, u64 dirty_tail, u8 poison,
                                                                             bool copy, u8** image)
{
    arena_reset_to_start(arena);
    if (dirty_tail != UINT64_MAX)
    {
        u64 dirty = (copy ? prefix.length * 2 + 1 : prefix.length) + dirty_tail;
        memset(arena_allocate(arena, u8, dirty), poison, dirty);
        arena_reset_to_start(arena);
    }
    *image = arena_allocate(arena, u8, prefix.length);
    memcpy(*image, prefix.pointer, prefix.length);
    if (copy)
    {
        *arena_allocate(arena, u8, 1) = 0xee;
    }
    return link_elf_test_section_table_append(arena, (ByteSlice){.pointer = *image, .length = prefix.length}, object);
}

// A copy-relocated definition must be discoverable from the ordinary table
// without loading a DSO. Its actual address and size come from .dynsym, but its
// ordinary section index must name allocated NOBITS storage that contains it.
BUSTER_GLOBAL_LOCAL bool link_test_elf_copy_symbol(ByteSlice image, String8 name, u8 info)
{
    LinkTestElfSymbol symbol = {0};
    u64 dynamic_value = 0;
    u64 dynamic_size = 0;
    u32 zero_section = 0;
    u64 zero_header = 0;
    u64 symbol_header = 0;
    bool result = link_test_elf_symbol(image, name, &symbol) &&
                  link_test_elf_dynamic_symbol(image, name, &dynamic_value, &dynamic_size, 0) &&
                  link_test_elf_section_find(image, S8(".bss"), &zero_section, &zero_header) &&
                  link_test_elf_section_find(image, S8(".symtab"), 0, &symbol_header);
    if (result)
    {
        u64 zero_address = link_read_u64(image.pointer, zero_header + 16);
        u64 zero_size = link_read_u64(image.pointer, zero_header + 32);
        result = symbol.value == dynamic_value && symbol.size == dynamic_size && symbol.section == zero_section &&
                 symbol.info == info && symbol.other == 0 && symbol.index >= link_read_u32(image.pointer, symbol_header + 44) &&
                 link_read_u32(image.pointer, zero_header + 4) == 8 && link_read_u64(image.pointer, zero_header + 8) == 3 &&
                 symbol.value >= zero_address && symbol.value - zero_address <= zero_size &&
                 symbol.size <= zero_size - (symbol.value - zero_address);
    }
    return result;
}

// Cover the shared hosted layout and both overlays, including aliases already
// imported, duplicate library aliases, an executable-owned name, weak imports,
// true undefined symbols, and copy slots following nonempty ordinary BSS.
BUSTER_GLOBAL_LOCAL UnitTestResult link_test_elf_copy_symbol_table(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_ANDROID};
    u8 x86_64_text[] = {0x31, 0xc0, 0xc3};
    u32 aarch64_text[] = {0x52800000, 0xd65f03c0};
    NativeDynamicDataSymbol exports[] = {
        {.name = S8("copy_data"), .address = 0x1000, .size = 32},
        {.name = S8("copy_pair"), .address = 0x1000, .size = 32},
        {.name = S8("copy_alias"), .address = 0x1000, .size = 32},
        {.name = S8("copy_alias"), .address = 0x1000, .size = 32},
        {.name = S8("copy_shadow"), .address = 0x1000, .size = 32},
        {.name = S8("weak_copy"), .address = 0x2000, .size = 16},
        {.name = S8("weak_alias"), .address = 0x2000, .size = 16},
        {.name = S8("unused_data"), .address = 0x3000, .size = 8},
    };
    String8 linker_argument = S8("--export-dynamic");
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
    {
        ByteSlice text = architectures[architecture] == CPU_ARCH_X86_64
                             ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(x86_64_text)
                             : (ByteSlice){.pointer = (u8*)aarch64_text, .length = sizeof(aarch64_text)};
        for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
        {
            ObjectSymbol symbols[] = {
                {.name = S8("main"), .size = text.length, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
                {.name = S8("local_zero"), .value = 1, .size = 4, .section = OBJECT_SECTION_ZERO, .kind = OBJECT_SYMBOL_DATA},
                {.name = S8("copy_data"), .size = 1, .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
                {.name = S8("copy_pair"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
                {.name = S8("weak_copy"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true, .weak = true},
                {.name = S8("missing"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true, .weak = true, .hidden = true},
                {.name = S8("function_import"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
                {.name = S8("copy_shadow"), .value = 5, .size = 4, .section = OBJECT_SECTION_ZERO, .kind = OBJECT_SYMBOL_DATA, .global = true},
            };
            ObjectFile object = link_test_object_make(arguments->arena,
                (Target){.cpu_arch = architectures[architecture], .os = systems[system]}, text, symbols, BUSTER_ARRAY_LENGTH(symbols), 0, 0);
            object.sections[OBJECT_SECTION_ZERO].virtual_size = 9;
            NativeExecutableLinkResult linked = link_native_executable(arguments->arena, &object,
                (NativeExecutableLinkOptions){
                    .entry_symbol = S8("main"),
                    .runtime_data_symbols = exports,
                    .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(exports),
                    .linker_arguments = &linker_argument,
                    .linker_argument_count = 1,
                });
            if (BUSTER_REQUIRE(arguments, linked.error == LINK_ERROR_NONE))
            {
                BUSTER_TEST(arguments, link_test_elf_copy_symbol(linked.executable, S8("copy_data"), 0x11));
                BUSTER_TEST(arguments, link_test_elf_copy_symbol(linked.executable, S8("copy_pair"), 0x11));
                BUSTER_TEST(arguments, link_test_elf_copy_symbol(linked.executable, S8("copy_alias"), 0x11));
                BUSTER_TEST(arguments, link_test_elf_copy_symbol(linked.executable, S8("weak_copy"), 0x21));
                BUSTER_TEST(arguments, link_test_elf_copy_symbol(linked.executable, S8("weak_alias"), 0x11));
                LinkTestElfSymbol data_symbol = {0};
                LinkTestElfSymbol pair_symbol = {0};
                LinkTestElfSymbol alias_symbol = {0};
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("copy_data"), &data_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("copy_pair"), &pair_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("copy_alias"), &alias_symbol));
                BUSTER_TEST(arguments, data_symbol.value == pair_symbol.value && data_symbol.value == alias_symbol.value && data_symbol.size == 32);
                LinkTestElfSymbol missing_symbol = {0};
                LinkTestElfSymbol function_symbol = {0};
                LinkTestElfSymbol unused_symbol = {0};
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("missing"), &missing_symbol));
                BUSTER_TEST(arguments, missing_symbol.section == 0 && missing_symbol.value == 0 && missing_symbol.size == 0 &&
                                           missing_symbol.info == 0x21 && missing_symbol.other == 2);
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("function_import"), &function_symbol));
                BUSTER_TEST(arguments, function_symbol.section == 0 && function_symbol.value == 0 && function_symbol.info == 0x12);
                BUSTER_TEST(arguments, !link_test_elf_symbol(linked.executable, S8("unused_data"), &unused_symbol));
                u64 zero_header = 0;
                u64 symbol_header = 0;
                u32 zero_section = 0;
                if (BUSTER_REQUIRE(arguments, link_test_elf_section_find(linked.executable, S8(".bss"), &zero_section, &zero_header) &&
                                              link_test_elf_section_find(linked.executable, S8(".symtab"), 0, &symbol_header)))
                {
                    LinkTestElfSymbol local_symbol = {0};
                    LinkTestElfSymbol shadow_symbol = {0};
                    BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("local_zero"), &local_symbol));
                    BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("copy_shadow"), &shadow_symbol));
                    u64 zero_address = link_read_u64(linked.executable.pointer, zero_header + 16);
                    BUSTER_TEST(arguments, local_symbol.section == zero_section && local_symbol.value == zero_address + 1 &&
                                               local_symbol.size == 4 && local_symbol.info == 0x01 && local_symbol.index == 1);
                    BUSTER_TEST(arguments, shadow_symbol.section == zero_section && shadow_symbol.value == zero_address + 5 &&
                                               shadow_symbol.size == 4 && shadow_symbol.value != data_symbol.value);
                    // Eight inputs, two hosted imports, two generated aliases,
                    // and the null entry. Neither a repeated library alias nor
                    // an already retained name may produce a duplicate entry.
                    BUSTER_TEST(arguments, link_read_u64(linked.executable.pointer, symbol_header + 32) == 13 * 24 &&
                                               link_read_u32(linked.executable.pointer, symbol_header + 44) == 2);
                }
            }
            BUSTER_TEST(arguments, symbols[2].section == OBJECT_SECTION_UNDEFINED && symbols[2].size == 1 && symbols[2].value == 0 &&
                                       symbols[3].section == OBJECT_SECTION_UNDEFINED && symbols[4].section == OBJECT_SECTION_UNDEFINED &&
                                       object.sections[OBJECT_SECTION_ZERO].virtual_size == 9);
        }
    }
    return result;
}

// Every ELF executable form carries the same non-loaded static-symbol
// contract.  Exercise both instruction sets, static and hosted layouts, and
// Linux and Android policy over interleaved local/global symbols, aliases,
// zero-fill, TLS, visibility and an unresolved weak definition.
BUSTER_GLOBAL_LOCAL UnitTestResult link_test_elf_symbol_table(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    OperatingSystem systems[] = {OPERATING_SYSTEM_LINUX, OPERATING_SYSTEM_ANDROID};
    u8 x86_64_text[] = {0x31, 0xc0, 0xc3};
    u32 aarch64_text[] = {0x52800000, 0xd65f03c0};
    u8 data[] = {0x91, 0x37, 0xc4, 0x5a};
    u8 thread_local_data[] = {0x4d, 0x22, 0xe1};
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
    {
        ByteSlice text = architectures[architecture] == CPU_ARCH_X86_64
                             ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(x86_64_text)
                             : (ByteSlice){.pointer = (u8*)aarch64_text, .length = sizeof(aarch64_text)};
        u64 local_function_value = architectures[architecture] == CPU_ARCH_X86_64 ? 2 : 4;
        for (u32 system = 0; system < BUSTER_ARRAY_LENGTH(systems); system += 1)
        {
            for (u32 hosted = 0; hosted < 2; hosted += 1)
            {
                ObjectSymbol symbols[] = {
                    {.name = S8("main"), .size = text.length, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
                    {.name = S8("local_data"), .value = 1, .size = 2, .section = OBJECT_SECTION_DATA, .kind = OBJECT_SYMBOL_DATA},
                    {.name = S8("weak_hidden"), .value = local_function_value, .size = text.length - local_function_value,
                     .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true, .weak = true, .hidden = true},
                    {.name = S8("local_function"), .value = local_function_value, .size = text.length - local_function_value,
                     .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION},
                    {.name = S8("global_zero"), .value = 3, .size = 5, .section = OBJECT_SECTION_ZERO,
                     .kind = OBJECT_SYMBOL_DATA, .global = true},
                    // An uninspected DSO may define a default-visible weak
                    // name. Hidden weak stays genuinely unresolved instead.
                    {.name = S8("missing_weak"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA,
                     .global = true, .weak = true, .hidden = true},
                    // Initializer arrays are transformed into entry-stub code and
                    // have no output section, so their input-only symbols cannot
                    // be published with a false section index.
                    {.name = S8("input_only_initializer"), .section = OBJECT_SECTION_INIT_ARRAY, .kind = OBJECT_SYMBOL_DATA},
                    {.name = S8("exit"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
                    {.name = S8("__cxa_atexit"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
                    {.name = S8("tls_data"), .value = 1, .size = 1, .section = OBJECT_SECTION_THREAD_LOCAL_DATA,
                     .kind = OBJECT_SYMBOL_DATA, .global = true},
                    {.name = S8("tls_zero"), .value = 2, .size = 3, .section = OBJECT_SECTION_THREAD_LOCAL_ZERO, .kind = OBJECT_SYMBOL_DATA},
                };
                u32 symbol_count = hosted ? BUSTER_ARRAY_LENGTH(symbols) : BUSTER_ARRAY_LENGTH(symbols) - 2;
                ObjectFile object = link_test_object_make(arguments->arena,
                    (Target){.cpu_arch = architectures[architecture], .os = systems[system]}, text, symbols, symbol_count, 0, 0);
                object.sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(data);
                object.sections[OBJECT_SECTION_ZERO].virtual_size = 16;
                if (hosted)
                {
                    object.sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(thread_local_data);
                    object.sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size = 9;
                    object.sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].alignment = 8;
                }
                NativeDynamicLibrary library = {.name = S8("libsymbol-probe.so")};
                NativeExecutableLinkOptions options = {
                    .entry_symbol = S8("main"),
                    .dynamic_libraries = &library,
                    .dynamic_library_count = hosted,
                };
                NativeExecutableLinkResult linked = link_native_executable(arguments->arena, &object, options);
                if (BUSTER_REQUIRE(arguments, linked.error == LINK_ERROR_NONE))
                {
                    u32 symbol_section = 0;
                    u32 string_section = 0;
                    u64 symbol_header = 0;
                    u64 string_header = 0;
                    BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".symtab"), &symbol_section, &symbol_header));
                    BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".strtab"), &string_section, &string_header));
                    if (BUSTER_REQUIRE(arguments, symbol_header && string_header))
                    {
                        u64 symbol_offset = link_read_u64(linked.executable.pointer, symbol_header + 24);
                        u64 symbol_size = link_read_u64(linked.executable.pointer, symbol_header + 32);
                        u64 string_offset = link_read_u64(linked.executable.pointer, string_header + 24);
                        u64 string_size = link_read_u64(linked.executable.pointer, string_header + 32);
                        u32 first_global = link_read_u32(linked.executable.pointer, symbol_header + 44);
                        u32 expected_first_global = hosted ? 4 : 3;
                        u32 expected_symbol_count = hosted ? 11 : 9;
                        BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, symbol_header + 4) == 2 &&
                                                   link_read_u64(linked.executable.pointer, symbol_header + 8) == 0 &&
                                                   link_read_u64(linked.executable.pointer, symbol_header + 16) == 0 &&
                                                   link_read_u32(linked.executable.pointer, symbol_header + 40) == string_section &&
                                                   first_global == expected_first_global &&
                                                   link_read_u64(linked.executable.pointer, symbol_header + 48) == 8 &&
                                                   link_read_u64(linked.executable.pointer, symbol_header + 56) == 24);
                        BUSTER_TEST(arguments, link_read_u32(linked.executable.pointer, string_header + 4) == 3 &&
                                                   link_read_u64(linked.executable.pointer, string_header + 8) == 0 &&
                                                   link_read_u64(linked.executable.pointer, string_header + 16) == 0 &&
                                                   link_read_u64(linked.executable.pointer, string_header + 48) == 1);
                        BUSTER_TEST(arguments, symbol_offset % 8 == 0 && symbol_size == (u64)expected_symbol_count * 24 &&
                                                   string_offset == symbol_offset + symbol_size && string_size > 1 &&
                                                   string_offset <= linked.executable.length && string_size <= linked.executable.length - string_offset);
                        u64 null_nonzero = 0;
                        for (u32 byte = 0; byte < 24; byte += 1)
                        {
                            null_nonzero += linked.executable.pointer[symbol_offset + byte] != 0;
                        }
                        BUSTER_TEST(arguments, null_nonzero == 0);
                        for (u32 index = 1; index < expected_symbol_count; index += 1)
                        {
                            u8 binding = linked.executable.pointer[symbol_offset + (u64)index * 24 + 4] >> 4;
                            BUSTER_TEST(arguments, index < first_global ? binding == 0 : binding == 1 || binding == 2);
                        }
                        u32 text_section = 0;
                        u32 data_section = 0;
                        u32 zero_section = 0;
                        u64 text_header = 0;
                        u64 data_header = 0;
                        u64 zero_header = 0;
                        BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".text"), &text_section, &text_header));
                        BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".data"), &data_section, &data_header));
                        BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".bss"), &zero_section, &zero_header));
                        u64 text_address = link_read_u64(linked.executable.pointer, text_header + 16);
                        u64 data_address = link_read_u64(linked.executable.pointer, data_header + 16);
                        u64 zero_address = link_read_u64(linked.executable.pointer, zero_header + 16);
                        u64 text_offset = link_read_u64(linked.executable.pointer, text_header + 24);
                        u64 data_offset = link_read_u64(linked.executable.pointer, data_header + 24);
                        BUSTER_TEST(arguments, text_offset <= linked.executable.length && text.length <= linked.executable.length - text_offset &&
                                                   memcmp(linked.executable.pointer + text_offset, text.pointer, text.length) == 0);
                        BUSTER_TEST(arguments, data_offset <= linked.executable.length && sizeof(data) <= linked.executable.length - data_offset &&
                                                   memcmp(linked.executable.pointer + data_offset, data, sizeof(data)) == 0);
                        LinkTestElfSymbol main_symbol = {0};
                        LinkTestElfSymbol local_data_symbol = {0};
                        LinkTestElfSymbol weak_hidden_symbol = {0};
                        LinkTestElfSymbol local_function_symbol = {0};
                        LinkTestElfSymbol global_zero_symbol = {0};
                        LinkTestElfSymbol missing_weak_symbol = {0};
                        BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("main"), &main_symbol));
                        BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("local_data"), &local_data_symbol));
                        BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("weak_hidden"), &weak_hidden_symbol));
                        BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("local_function"), &local_function_symbol));
                        BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("global_zero"), &global_zero_symbol));
                        BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("missing_weak"), &missing_weak_symbol));
                        LinkTestElfSymbol omitted_symbol = {0};
                        BUSTER_TEST(arguments, !link_test_elf_symbol(linked.executable, S8("input_only_initializer"), &omitted_symbol));
                        BUSTER_TEST(arguments, main_symbol.value == text_address && main_symbol.size == text.length &&
                                                   main_symbol.index == first_global && main_symbol.section == text_section && main_symbol.info == 0x12 &&
                                                   main_symbol.other == 0);
                        BUSTER_TEST(arguments, local_data_symbol.value == data_address + 1 && local_data_symbol.size == 2 &&
                                                   local_data_symbol.index == 1 && local_data_symbol.section == data_section &&
                                                   local_data_symbol.info == 0x01 && local_data_symbol.other == 0);
                        BUSTER_TEST(arguments, weak_hidden_symbol.value == text_address + local_function_value &&
                                                   weak_hidden_symbol.size == text.length - local_function_value &&
                                                   weak_hidden_symbol.index == first_global + 1 && weak_hidden_symbol.section == text_section &&
                                                   weak_hidden_symbol.info == 0x22 && weak_hidden_symbol.other == 2);
                        BUSTER_TEST(arguments, local_function_symbol.value == text_address + local_function_value &&
                                                   local_function_symbol.size == text.length - local_function_value && local_function_symbol.index == 2 &&
                                                   local_function_symbol.section == text_section && local_function_symbol.info == 0x02 &&
                                                   local_function_symbol.other == 0);
                        BUSTER_TEST(arguments, global_zero_symbol.value == zero_address + 3 && global_zero_symbol.size == 5 &&
                                                   global_zero_symbol.index == first_global + 2 && global_zero_symbol.section == zero_section &&
                                                   global_zero_symbol.info == 0x11 && global_zero_symbol.other == 0);
                        BUSTER_TEST(arguments, missing_weak_symbol.value == 0 && missing_weak_symbol.size == 0 &&
                                                   missing_weak_symbol.index == first_global + 3 && missing_weak_symbol.section == 0 &&
                                                   missing_weak_symbol.info == 0x21 && missing_weak_symbol.other == 2);
                        if (hosted)
                        {
                            u32 thread_local_data_section = 0;
                            u32 thread_local_zero_section = 0;
                            u64 thread_local_data_header = 0;
                            u64 thread_local_zero_header = 0;
                            BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".tdata"), &thread_local_data_section,
                                                                             &thread_local_data_header));
                            BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".tbss"), &thread_local_zero_section,
                                                                             &thread_local_zero_header));
                            LinkTestElfSymbol thread_local_data_symbol = {0};
                            LinkTestElfSymbol thread_local_zero_symbol = {0};
                            BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("tls_data"), &thread_local_data_symbol));
                            BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("tls_zero"), &thread_local_zero_symbol));
                            u64 thread_local_data_address = link_read_u64(linked.executable.pointer, thread_local_data_header + 16);
                            u64 thread_local_zero_address = link_read_u64(linked.executable.pointer, thread_local_zero_header + 16);
                            BUSTER_TEST(arguments, thread_local_data_symbol.value == 1 && thread_local_data_symbol.size == 1 &&
                                                       thread_local_data_symbol.index == first_global + 6 &&
                                                       thread_local_data_symbol.section == thread_local_data_section &&
                                                       thread_local_data_symbol.info == 0x16 && thread_local_data_symbol.other == 0);
                            BUSTER_TEST(arguments, thread_local_zero_address >= thread_local_data_address &&
                                                       thread_local_zero_symbol.value == thread_local_zero_address - thread_local_data_address + 2 &&
                                                       thread_local_zero_symbol.size == 3 && thread_local_zero_symbol.index == 3 &&
                                                       thread_local_zero_symbol.section == thread_local_zero_section &&
                                                       thread_local_zero_symbol.info == 0x06 && thread_local_zero_symbol.other == 0);
                        }
                        u64 program_header_offset = link_read_u64(linked.executable.pointer, 32);
                        u16 program_header_size = 0;
                        u16 program_header_count = 0;
                        memcpy(&program_header_size, linked.executable.pointer + 54, sizeof(program_header_size));
                        memcpy(&program_header_count, linked.executable.pointer + 56, sizeof(program_header_count));
                        BUSTER_TEST(arguments, program_header_size == 56 && program_header_offset <= symbol_offset &&
                                                   (u64)program_header_count <= (symbol_offset - program_header_offset) / program_header_size);
                        for (u32 index = 0; index < program_header_count; index += 1)
                        {
                            u64 header = program_header_offset + (u64)index * program_header_size;
                            u64 file_offset = link_read_u64(linked.executable.pointer, header + 8);
                            u64 file_size = link_read_u64(linked.executable.pointer, header + 32);
                            BUSTER_TEST(arguments, file_offset <= symbol_offset && file_size <= symbol_offset - file_offset);
                        }
                        if (hosted)
                        {
                            u32 dynamic_symbol_section = 0;
                            BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".dynsym"), &dynamic_symbol_section, 0));
                            BUSTER_TEST(arguments, dynamic_symbol_section != symbol_section);
                        }
                    }
                }
            }
        }
    }

    return result;
}

// A final executable names addresses in the merged ObjectFile, not the
// per-input offsets.  Use two independently aligned inputs and symbols in
// loaded, unwind and non-loaded sections so a table copied from either input
// cannot satisfy the expected values.
BUSTER_GLOBAL_LOCAL UnitTestResult link_test_elf_merged_symbol_table(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX};
    u8 first_text[] = {0x31, 0xc0, 0xc3};
    u8 second_text[] = {0x90, 0x31, 0xc0, 0xc3};
    u8 first_read_only[] = {0x13, 0x27, 0x51};
    u8 second_read_only[] = {0x7b, 0x91};
    u8 first_debug[] = {0x49, 0x21, 0x68, 0x33, 0xa5};
    u8 second_debug[] = {0xc7, 0x18, 0xe2};
    ObjectSymbol first_symbols[] = {
        {.name = S8("main"), .size = sizeof(first_text), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
        {.name = S8("first_rodata"), .value = 1, .size = 2, .section = OBJECT_SECTION_READ_ONLY_DATA, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("first_unwind"), .section = OBJECT_SECTION_UNWIND, .kind = OBJECT_SYMBOL_DATA},
    };
    ObjectSymbol second_symbols[] = {
        {.name = S8("second_function"), .value = 1, .size = 3, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
        {.name = S8("second_rodata"), .value = 1, .size = 1, .section = OBJECT_SECTION_READ_ONLY_DATA, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("second_unwind"), .section = OBJECT_SECTION_UNWIND, .kind = OBJECT_SYMBOL_DATA},
        {.name = S8("second_debug"), .value = 1, .size = 2, .section = OBJECT_SECTION_DEBUG_INFO, .kind = OBJECT_SYMBOL_DATA},
    };
    CodegenFunctionDescriptor first_descriptor = {.code_size = sizeof(first_text)};
    CodegenFunctionDescriptor second_descriptor = {.code_size = sizeof(second_text)};
    DwarfCfiResult first_cfi = dwarf_cfi_build(arguments->arena, (DwarfCfiInput){
                                                                     .functions = &first_descriptor,
                                                                     .target = target,
                                                                     .function_count = 1,
                                                                 });
    DwarfCfiResult second_cfi = dwarf_cfi_build(arguments->arena, (DwarfCfiInput){
                                                                      .functions = &second_descriptor,
                                                                      .target = target,
                                                                      .function_count = 1,
                                                                  });
    if (BUSTER_REQUIRE(arguments, first_cfi.valid && first_cfi.relocation_count == 1 && second_cfi.valid && second_cfi.relocation_count == 1))
    {
        first_symbols[2].size = first_cfi.bytes.length;
        second_symbols[2].size = second_cfi.bytes.length;
        ObjectRelocation first_relocation = {
            .offset = first_cfi.relocations[0].offset,
            .section = OBJECT_SECTION_UNWIND,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_X86_64_PC32,
        };
        ObjectRelocation second_relocation = {
            .offset = second_cfi.relocations[0].offset,
            .section = OBJECT_SECTION_UNWIND,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_X86_64_PC32,
        };
        ObjectFile objects[] = {
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(first_text), first_symbols,
                                  BUSTER_ARRAY_LENGTH(first_symbols), &first_relocation, 1),
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(second_text), second_symbols,
                                  BUSTER_ARRAY_LENGTH(second_symbols), &second_relocation, 1),
        };
        objects[0].sections[OBJECT_SECTION_READ_ONLY_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(first_read_only);
        objects[1].sections[OBJECT_SECTION_READ_ONLY_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(second_read_only);
        objects[0].sections[OBJECT_SECTION_UNWIND].data = first_cfi.bytes;
        objects[1].sections[OBJECT_SECTION_UNWIND].data = second_cfi.bytes;
        objects[0].sections[OBJECT_SECTION_DEBUG_INFO].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(first_debug);
        objects[1].sections[OBJECT_SECTION_DEBUG_INFO].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(second_debug);
        LinkObjectResult merged = link_objects(arguments->arena, objects, BUSTER_ARRAY_LENGTH(objects), (LinkOptions){0});
        if (BUSTER_REQUIRE(arguments, merged.error == LINK_ERROR_NONE))
        {
            NativeExecutableLinkResult linked = link_native_executable(arguments->arena, &merged.object,
                                                                       (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
            if (BUSTER_REQUIRE(arguments, linked.error == LINK_ERROR_NONE))
            {
                u32 text_section = 0;
                u32 read_only_section = 0;
                u32 unwind_section = 0;
                u32 debug_section = 0;
                u64 text_header = 0;
                u64 read_only_header = 0;
                u64 unwind_header = 0;
                u64 debug_header = 0;
                BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".text"), &text_section, &text_header));
                BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".rodata"), &read_only_section, &read_only_header));
                BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".eh_frame"), &unwind_section, &unwind_header));
                BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".debug_info"), &debug_section, &debug_header));
                LinkTestElfSymbol main_symbol = {0};
                LinkTestElfSymbol second_function_symbol = {0};
                LinkTestElfSymbol first_read_only_symbol = {0};
                LinkTestElfSymbol second_read_only_symbol = {0};
                LinkTestElfSymbol first_unwind_symbol = {0};
                LinkTestElfSymbol second_unwind_symbol = {0};
                LinkTestElfSymbol second_debug_symbol = {0};
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("main"), &main_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("second_function"), &second_function_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("first_rodata"), &first_read_only_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("second_rodata"), &second_read_only_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("first_unwind"), &first_unwind_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("second_unwind"), &second_unwind_symbol));
                BUSTER_TEST(arguments, link_test_elf_symbol(linked.executable, S8("second_debug"), &second_debug_symbol));
                u64 text_address = link_read_u64(linked.executable.pointer, text_header + 16);
                u64 read_only_address = link_read_u64(linked.executable.pointer, read_only_header + 16);
                u64 unwind_address = link_read_u64(linked.executable.pointer, unwind_header + 16);
                u64 second_text_offset = align_forward(sizeof(first_text), object_section_default_alignment(OBJECT_SECTION_TEXT));
                u64 second_read_only_offset = align_forward(sizeof(first_read_only), object_section_default_alignment(OBJECT_SECTION_READ_ONLY_DATA));
                u64 second_unwind_offset = align_forward(first_cfi.bytes.length, object_section_default_alignment(OBJECT_SECTION_UNWIND));
                u64 second_debug_offset = align_forward(sizeof(first_debug), object_section_default_alignment(OBJECT_SECTION_DEBUG_INFO));
                BUSTER_TEST(arguments, main_symbol.value == text_address && main_symbol.section == text_section && main_symbol.info == 0x12);
                BUSTER_TEST(arguments, second_function_symbol.value == text_address + second_text_offset + 1 &&
                                           second_function_symbol.size == 3 && second_function_symbol.section == text_section &&
                                           second_function_symbol.info == 0x12);
                BUSTER_TEST(arguments, first_read_only_symbol.value == read_only_address + 1 && first_read_only_symbol.size == 2 &&
                                           first_read_only_symbol.section == read_only_section && first_read_only_symbol.info == 0x01);
                BUSTER_TEST(arguments, second_read_only_symbol.value == read_only_address + second_read_only_offset + 1 &&
                                           second_read_only_symbol.size == 1 && second_read_only_symbol.section == read_only_section &&
                                           second_read_only_symbol.info == 0x01);
                BUSTER_TEST(arguments, first_unwind_symbol.value == unwind_address && first_unwind_symbol.size == first_cfi.bytes.length &&
                                           first_unwind_symbol.section == unwind_section && first_unwind_symbol.info == 0x01);
                BUSTER_TEST(arguments, second_unwind_symbol.value == unwind_address + second_unwind_offset &&
                                           second_unwind_symbol.size == second_cfi.bytes.length && second_unwind_symbol.section == unwind_section &&
                                           second_unwind_symbol.info == 0x01);
                BUSTER_TEST(arguments, second_debug_symbol.value == second_debug_offset + 1 && second_debug_symbol.size == 2 &&
                                           second_debug_symbol.section == debug_section && second_debug_symbol.info == 0x01);
            }
        }
    }
    return result;
}

// The ELF section-table append zeroes its tail through the arena's dirty-aware
// allocation, so no byte of its image may depend on what the arena held. A
// fresh mapping, a dirty high-water mark at each boundary inside the tail, the
// copying growth path and repeated reuse all reproduce the fresh bump's image;
// the image prefix survives, and the bytes nothing writes are zero.
BUSTER_GLOBAL_LOCAL UnitTestResult link_test_elf_section_table_tail(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    // Every link_elf_debug_kinds entry, in its order.
    ObjectSectionKind debug_kinds[] = {
        OBJECT_SECTION_DEBUG_INFO,     OBJECT_SECTION_DEBUG_ABBREV,   OBJECT_SECTION_DEBUG_LINE,     OBJECT_SECTION_DEBUG_STR,
        OBJECT_SECTION_DEBUG_LOC,      OBJECT_SECTION_DEBUG_RANGES,   OBJECT_SECTION_DEBUG_ADDR,     OBJECT_SECTION_DEBUG_STR_OFFSETS,
        OBJECT_SECTION_DEBUG_LINE_STR, OBJECT_SECTION_DEBUG_RNGLISTS, OBJECT_SECTION_DEBUG_LOCLISTS,
    };
    // Neither pattern contains a zero byte, so a cleared byte cannot pass for
    // a preserved one.
    u8 debug_bytes[64] = {0};
    for (u32 index = 0; index < sizeof(debug_bytes); index += 1)
    {
        debug_bytes[index] = (u8)(0x41 + index * 7);
    }
    u8 prefix_bytes[136] = {0};
    for (u32 index = 0; index < sizeof(prefix_bytes); index += 1)
    {
        prefix_bytes[index] = (u8)(0x80 | index);
    }
    // link_test_elf_section_find reads only an image with the ELF magic.
    memcpy(prefix_bytes, "\x7f" "ELF", 4);
    u8 poisons[] = {0xa5, 0x5a};
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX};
    ArenaCreation creation = {.reserved_size = BUSTER_MB(1), .flags = {.no_pool = 1}};
    // One arena for every repeated append: each is handed the poison and the
    // images of every earlier shape and length as its dirty storage.
    Arena* reused = arena_create(creation);
    if (BUSTER_REQUIRE(arguments, reused != 0))
    {
        memset(arena_allocate(reused, u8, BUSTER_KB(16)), 0xc3, BUSTER_KB(16));
        arena_reset_to_start(reused);
        for (u32 shape = 0; shape < 2; shape += 1)
        {
            ObjectFile object = link_test_object_make(arguments->arena, target, (ByteSlice){0}, 0, 0, 0, 0);
            for (u32 index = 0; shape && index < BUSTER_ARRAY_LENGTH(debug_kinds); index += 1)
            {
                object.sections[debug_kinds[index]].data = (ByteSlice){.pointer = debug_bytes + index, .length = (u64)index * 3 + 1};
            }
            // Eight prefix lengths give the padding before the section table
            // every width from none to seven bytes.
            for (u64 length = 128; length < sizeof(prefix_bytes); length += 1)
            {
                ByteSlice prefix = {.pointer = prefix_bytes, .length = length};
                Arena* fresh = arena_create(creation);
                if (BUSTER_REQUIRE(arguments, fresh != 0))
                {
                    u8* image = 0;
                    NativeExecutableLinkResult reference = link_test_section_table_place(fresh, prefix, &object, UINT64_MAX, 0, false, &image);
                    ByteSlice expected = reference.executable;
                    if (BUSTER_REQUIRE(arguments, reference.error == LINK_ERROR_NONE && expected.pointer == image && expected.length > length + 64))
                    {
                        u64 table = link_read_u64(expected.pointer, 40);
                        u16 section_count = 0;
                        u16 string_index = 0;
                        memcpy(&section_count, expected.pointer + 60, sizeof(section_count));
                        memcpy(&string_index, expected.pointer + 62, sizeof(string_index));
                        if (BUSTER_REQUIRE(arguments, table >= length && table <= expected.length && (u32)string_index + 1 == (u32)section_count &&
                                                          expected.length - table == (u64)section_count * 64))
                        {
                            u64 string_header = table + (u64)string_index * 64;
                            u64 string_offset = link_read_u64(expected.pointer, string_header + 24);
                            u64 string_size = link_read_u64(expected.pointer, string_header + 32);
                            if (BUSTER_REQUIRE(arguments,
                                               string_offset >= length && string_size != 0 && string_offset <= table && string_size <= table - string_offset))
                            {
                                u64 string_end = string_offset + string_size;
                                // The prefix survives except for the ELF header's section-table fields.
                                BUSTER_TEST(arguments, memcmp(expected.pointer, prefix.pointer, 40) == 0);
                                BUSTER_TEST(arguments, memcmp(expected.pointer + 48, prefix.pointer + 48, 10) == 0);
                                BUSTER_TEST(arguments, memcmp(expected.pointer + 64, prefix.pointer + 64, length - 64) == 0);
                                // Nothing writes the padding, the null section header, the
                                // string separators or the string table header's unused fields.
                                u64 nonzero = 0;
                                u32 separators = 0;
                                for (u64 offset = string_end; offset < table + 64; offset += 1)
                                {
                                    nonzero += expected.pointer[offset] != 0;
                                }
                                for (u64 offset = string_offset; offset < string_end; offset += 1)
                                {
                                    separators += expected.pointer[offset] == 0;
                                }
                                BUSTER_TEST(arguments, table == align_forward(string_end, 8));
                                BUSTER_TEST(arguments, nonzero == 0);
                                BUSTER_TEST(arguments, expected.pointer[string_offset] == 0 && separators == (u32)section_count);
                                BUSTER_TEST(arguments, link_read_u64(expected.pointer, string_header + 8) == 0 &&
                                                           link_read_u64(expected.pointer, string_header + 16) == 0 &&
                                                           link_read_u32(expected.pointer, string_header + 40) == 0 &&
                                                           link_read_u32(expected.pointer, string_header + 44) == 0 &&
                                                           link_read_u64(expected.pointer, string_header + 56) == 0);
                                for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(debug_kinds); index += 1)
                                {
                                    ByteSlice data = object.sections[debug_kinds[index]].data;
                                    u64 header = 0;
                                    bool found = link_test_elf_section_find(expected, object_section_name_for_kind(debug_kinds[index]), 0, &header);
                                    // Without input bytes only the DWARF 4 family keeps its empty section.
                                    BUSTER_TEST(arguments, found == (shape != 0 || debug_kinds[index] < OBJECT_SECTION_DEBUG_ADDR));
                                    if (found)
                                    {
                                        u64 offset = link_read_u64(expected.pointer, header + 24);
                                        u64 size = link_read_u64(expected.pointer, header + 32);
                                        BUSTER_TEST(arguments, size == data.length && offset >= length && offset <= string_offset &&
                                                                   size <= string_offset - offset &&
                                                                   (size == 0 || memcmp(expected.pointer + offset, data.pointer, size) == 0));
                                    }
                                }
                                u64 tail = expected.length - length;
                                u64 boundaries[] = {
                                    0, 1, string_end - length, string_end - length + 1, table - length + 1, tail - 1, tail, tail + BUSTER_KB(4),
                                };
                                for (u32 copy = 0; copy < 2; copy += 1)
                                {
                                    for (u32 boundary = 0; boundary < BUSTER_ARRAY_LENGTH(boundaries); boundary += 1)
                                    {
                                        Arena* dirty = arena_create(creation);
                                        if (BUSTER_REQUIRE(arguments, dirty != 0))
                                        {
                                            u8* placed = 0;
                                            NativeExecutableLinkResult linked = link_test_section_table_place(dirty, prefix, &object, boundaries[boundary],
                                                                                                              poisons[boundary % 2], copy != 0, &placed);
                                            u8* grown = copy ? placed + length + 1 : placed;
                                            BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE && linked.executable.pointer == grown &&
                                                                       linked.executable.length == expected.length &&
                                                                       memcmp(linked.executable.pointer, expected.pointer, expected.length) == 0);
                                            // Copying leaves the original image and the allocation after it alone.
                                            BUSTER_TEST(arguments, !copy || (memcmp(placed, prefix.pointer, length) == 0 && placed[length] == 0xee));
                                            BUSTER_TEST(arguments, arena_destroy(dirty, 1));
                                        }
                                    }
                                }
                                for (u32 copy = 0; copy < 2; copy += 1)
                                {
                                    BUSTER_TEST(arguments, arena_dirty_position(reused) >= arena_minimum_position + length * 2 + 1 + tail);
                                    u8* placed = 0;
                                    NativeExecutableLinkResult linked =
                                        link_test_section_table_place(reused, prefix, &object, UINT64_MAX, 0, copy != 0, &placed);
                                    u8* grown = copy ? placed + length + 1 : placed;
                                    BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE && linked.executable.pointer == grown &&
                                                               linked.executable.length == expected.length &&
                                                               memcmp(linked.executable.pointer, expected.pointer, expected.length) == 0);
                                }
                            }
                        }
                    }
                    BUSTER_TEST(arguments, arena_destroy(fresh, 1));
                }
            }
        }
        BUSTER_TEST(arguments, arena_destroy(reused, 1));
    }

    // The production writers reach the append on its bump path. Every debug
    // section survives into their images, and relinking over a poisoned output
    // arena reproduces the fresh image exactly.
    CpuArch architectures[] = {CPU_ARCH_X86_64, CPU_ARCH_AARCH64};
    u8 x86_64_text[] = {0x31, 0xc0, 0xc3};
    u8 aarch64_text[] = {0x00, 0x00, 0x80, 0x52, 0xc0, 0x03, 0x5f, 0xd6};
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(architectures); architecture += 1)
    {
        ByteSlice text =
            architectures[architecture] == CPU_ARCH_AARCH64 ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(aarch64_text) : (ByteSlice)BUSTER_ARRAY_TO_SLICE(x86_64_text);
        ObjectSymbol symbols[] = {
            {.name = S8("main"), .kind = OBJECT_SYMBOL_FUNCTION, .section = OBJECT_SECTION_TEXT, .size = text.length, .global = true},
        };
        Target writer_target = {.cpu_arch = architectures[architecture], .os = OPERATING_SYSTEM_LINUX};
        ObjectFile object = link_test_object_make(arguments->arena, writer_target, text, symbols, BUSTER_ARRAY_LENGTH(symbols), 0, 0);
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(debug_kinds); index += 1)
        {
            object.sections[debug_kinds[index]].data = (ByteSlice){.pointer = debug_bytes + index, .length = (u64)index * 3 + 1};
        }
        Arena* output = arena_create((ArenaCreation){.reserved_size = BUSTER_MB(64), .flags = {.no_pool = 1}});
        Arena* temporary = arena_create((ArenaCreation){.reserved_size = BUSTER_MB(64), .flags = {.no_pool = 1}});
        if (BUSTER_REQUIRE(arguments, output != 0 && temporary != 0))
        {
            ByteSlice first = {0};
            for (u32 iteration = 0; iteration < 1 + BUSTER_ARRAY_LENGTH(poisons); iteration += 1)
            {
                if (iteration)
                {
                    u64 poisoned = arena_dirty_position(output) - arena_minimum_position + BUSTER_KB(64);
                    memset(arena_allocate(output, u8, poisoned), poisons[iteration - 1], poisoned);
                    arena_reset_to_start(output);
                }
                NativeExecutableLinkOptions options = {.entry_symbol = S8("main")};
                NativeExecutableLinkResult linked = link_elf_test_executable(output, temporary, &object, options);
                if (BUSTER_REQUIRE(arguments, linked.error == LINK_ERROR_NONE))
                {
                    if (!iteration)
                    {
                        first.length = linked.executable.length;
                        first.pointer = arena_allocate(arguments->arena, u8, first.length);
                        memcpy(first.pointer, linked.executable.pointer, first.length);
                        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(debug_kinds); index += 1)
                        {
                            ByteSlice data = object.sections[debug_kinds[index]].data;
                            u64 header = 0;
                            BUSTER_TEST(arguments, link_test_elf_section_find(first, object_section_name_for_kind(debug_kinds[index]), 0, &header));
                            u64 offset = link_read_u64(first.pointer, header + 24);
                            u64 size = link_read_u64(first.pointer, header + 32);
                            BUSTER_TEST(arguments, header != 0 && size == data.length && offset <= first.length && size <= first.length - offset &&
                                                       memcmp(first.pointer + offset, data.pointer, size) == 0);
                        }
                    }
                    else
                    {
                        BUSTER_TEST(arguments, linked.executable.length == first.length && memcmp(linked.executable.pointer, first.pointer, first.length) == 0);
                    }
                }
                arena_reset_to_start(output);
            }
        }
        BUSTER_TEST(arguments, !output || arena_destroy(output, 1));
        BUSTER_TEST(arguments, !temporary || arena_destroy(temporary, 1));
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_unused_got_marker(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    Target target = {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX};
    u8 text[] = {0xe8, 0, 0, 0, 0, 0xc3, 0x31, 0xc0, 0xc3};
    ObjectSymbol symbols[] = {
        {.name = S8("main"), .size = 6, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
        {.name = S8("_GLOBAL_OFFSET_TABLE_"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
        {.name = S8("helper"), .value = 6, .size = 3, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION},
        {.name = S8("_GLOBAL_OFFSET_TABLE_"), .section = OBJECT_SECTION_UNDEFINED, .kind = OBJECT_SYMBOL_DATA, .global = true},
    };
    ObjectRelocation relocation = {.offset = 1, .addend = -4, .section = OBJECT_SECTION_TEXT, .symbol = 2,
                                   .kind = OBJECT_RELOCATION_X86_64_PC32};
    ObjectFile object = link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(text),
                                             symbols, BUSTER_ARRAY_LENGTH(symbols), &relocation, 1);
    ObjectSymbol original_symbols[BUSTER_ARRAY_LENGTH(symbols)];
    memcpy(original_symbols, symbols, sizeof(symbols));
    NativeExecutableLinkOptions options = {.entry_symbol = S8("main"), .runtime_exports_known = true};
    ObjectSymbol reference_symbols[] = {symbols[0], symbols[2]};
    ObjectRelocation reference_relocation = relocation;
    reference_relocation.symbol = 1;
    ObjectFile reference = object;
    reference.symbols = reference_symbols;
    reference.symbol_count = BUSTER_ARRAY_LENGTH(reference_symbols);
    reference.relocations = &reference_relocation;
    NativeExecutableLinkResult expected = link_native_executable(arguments->arena, &reference, options);
    NativeExecutableLinkResult actual = link_native_executable(arguments->arena, &object, options);
    BUSTER_TEST(arguments, expected.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, actual.error == LINK_ERROR_NONE);
    if (expected.error == LINK_ERROR_NONE && actual.error == LINK_ERROR_NONE)
    {
        BUSTER_TEST(arguments, expected.executable.length == actual.executable.length);
        if (expected.executable.length == actual.executable.length)
        {
            BUSTER_TEST(arguments, memory_compare(expected.executable.pointer, actual.executable.pointer, actual.executable.length));
        }
    }
    BUSTER_TEST(arguments, object.symbols == symbols && object.symbol_count == BUSTER_ARRAY_LENGTH(symbols));
    BUSTER_TEST(arguments, object.relocations == &relocation && relocation.symbol == 2);
    BUSTER_TEST(arguments, memory_compare(symbols, original_symbols, sizeof(symbols)));

    // An actual GOT-base reference must retain its unresolved-symbol error.
    relocation.symbol = 1;
    NativeExecutableLinkResult referenced = link_native_executable(arguments->arena, &object, options);
    BUSTER_TEST(arguments, referenced.error == LINK_ERROR_UNRESOLVED_SYMBOL);
    BUSTER_TEST(arguments, string_equal(referenced.symbol, S8("_GLOBAL_OFFSET_TABLE_")));
    relocation.symbol = 2;
    NativeExecutableLinkOptions explicit_entry = options;
    explicit_entry.entry_symbol = S8("_GLOBAL_OFFSET_TABLE_");
    BUSTER_TEST(arguments, link_native_executable(arguments->arena, &object, explicit_entry).error == LINK_ERROR_UNRESOLVED_SYMBOL);

    // Only the reserved undefined marker is removable, not ordinary imports
    // or a real definition bearing the same name.
    symbols[1].name = S8("ordinary_missing_symbol");
    NativeExecutableLinkResult ordinary = link_native_executable(arguments->arena, &object, options);
    BUSTER_TEST(arguments, ordinary.error == LINK_ERROR_UNRESOLVED_SYMBOL);
    BUSTER_TEST(arguments, string_equal(ordinary.symbol, symbols[1].name));
    symbols[1] = symbols[2];
    symbols[1].name = S8("_GLOBAL_OFFSET_TABLE_");
    symbols[1].global = true;
    relocation.symbol = 1;
    BUSTER_TEST(arguments, link_native_executable(arguments->arena, &object, options).error == LINK_ERROR_NONE);

    memcpy(symbols, original_symbols, sizeof(symbols));
    relocation.symbol = object.symbol_count;
    BUSTER_TEST(arguments, link_native_executable(arguments->arena, &object, options).error == LINK_ERROR_RELOCATION);
    relocation.symbol = 2;
    object.target.cpu_arch = CPU_ARCH_AARCH64;
    BUSTER_TEST(arguments, link_native_executable(arguments->arena, &object, options).error == LINK_ERROR_UNRESOLVED_SYMBOL);

    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_elf_data_indexes(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    bool benchmark = os_get_environment_variable(S8("BUSTER_ELF_DATA_BENCH")).length != 0;
    u32 counts[] = {0, 1, 8, 32, 128, 512, 1024, 2048, 4096};
    for (u32 shape = 0; shape < 2; shape += 1)
    {
        for (u32 population = 0; population < BUSTER_ARRAY_LENGTH(counts); population += 1)
        {
            u32 count = counts[population];
            if (!benchmark && count > 128) continue;
            TemporalArena fixture = arena_begin_temporal(arguments->arena);
            Arena* arena = arguments->arena;
            u32 groups = shape ? (count != 0) : count;
            u32 export_count = shape ? count * 2 : count * 4;
            u32 import_count = shape ? groups : count * 2;
            NativeDynamicDataSymbol* data = arena_allocate(arena, NativeDynamicDataSymbol, export_count);
            NativeDynamicVersionedSymbol* versions = arena_allocate(arena, NativeDynamicVersionedSymbol, export_count);
            ObjectSymbol* symbols = arena_allocate_zeroed(arena, ObjectSymbol, (u64)import_count + count + 1);
            u8 text[] = {0x31, 0xc0, 0xc3};
            symbols[0] = (ObjectSymbol){.name = S8("main"), .kind = OBJECT_SYMBOL_FUNCTION,
                .section = OBJECT_SECTION_TEXT, .size = sizeof(text), .global = true};
            for (u32 entry = 0; entry < export_count; entry += 1)
            {
                u32 group = shape ? 0 : entry / 4;
                u32 alias = shape ? entry / 2 : BUSTER_MIN(entry % 4, 2u);
                String8 name = string_format(arena, S8("data_{u32}_{u32}"), group, alias);
                u64 size = shape ? (entry % 2 ? 65536 : 16) : entry % 4 == 0 ? 8 : entry % 4 == 1 ? 32 : entry % 4 == 2 ? 16 : 65536;
                data[entry] = (NativeDynamicDataSymbol){.name = name, .address = 0x1000 + (u64)group * 64, .size = size};
                versions[entry] = (NativeDynamicVersionedSymbol){.name = name,
                    .version = string_format(arena, S8("DATA_{u32}"), group), .has_default = true};
            }
            for (u32 entry = 0; entry < import_count; entry += 1)
            {
                symbols[entry + 1] = (ObjectSymbol){.name = data[shape ? 0 : entry / 2 * 4 + entry % 2].name,
                    .kind = OBJECT_SYMBOL_DATA, .section = OBJECT_SECTION_UNDEFINED, .global = true};
            }
            // Unrelated globals made the old alias membership scan I*S. They
            // stay local to the object and are deliberately not exported.
            for (u32 entry = 0; entry < count; entry += 1)
            {
                symbols[import_count + entry + 1] = (ObjectSymbol){.name = string_format(arena, S8("global_{u32}"), entry),
                    .kind = OBJECT_SYMBOL_DATA, .section = OBJECT_SECTION_ZERO, .global = true};
            }
            ObjectFile object = link_test_object_make(arena, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
                (ByteSlice)BUSTER_ARRAY_TO_SLICE(text), symbols, import_count + count + 1, 0, 0);
            NativeDynamicLibrary library = {.name = S8("libdatafixture.so"), .exported_data_symbols = data,
                .exported_data_symbol_count = export_count, .versioned_symbols = versions, .versioned_symbol_count = export_count};
            NativeExecutableLinkOptions options = {.dynamic_libraries = &library, .dynamic_library_count = 1};
            Arena* output = arena_create((ArenaCreation){.reserved_size = BUSTER_MB(64)});
            Arena* temporary = arena_create((ArenaCreation){.reserved_size = BUSTER_MB(64)});
            u64 first_hash = 0;
            for (u32 iteration = 0; iteration < (benchmark ? 8u : 2u); iteration += 1)
            {
                u64 output_position = output->position;
                u64 temporary_position = temporary->position;
                TimeDataType start = timestamp_take();
                NativeExecutableLinkResult linked = link_elf_test_executable(output, temporary, &object, options);
                u64 ns = timestamp_ns_between(start, timestamp_take());
                BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
                BUSTER_TEST(arguments, temporary->position == temporary_position);
                BUSTER_TEST(arguments, link_test_elf_relocation_count(linked.executable, 5) == groups);
                u64 hash = buster_hash_64(linked.executable.pointer, linked.executable.length);
                if (!iteration) first_hash = hash;
                BUSTER_TEST(arguments, hash == first_hash);
                if (!iteration)
                {
                    u64 previous = 0;
                    for (u32 group = 0; group < groups; group += 1)
                    {
                        u64 address = 0;
                        u64 size = 0;
                        BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, data[shape ? 0 : group * 4].name, &address, &size, 0));
                        BUSTER_TEST(arguments, address && address != previous && size == 16);
                        if (count <= 128 || group == 0 || group + 1 == groups)
                        {
                            String8 version = {0};
                            String8 version_library = {0};
                            BUSTER_TEST(arguments, link_test_elf_symbol_version(linked.executable, data[shape ? 0 : group * 4].name,
                                &version, &version_library));
                            BUSTER_STRING_TEST(arguments, version, versions[shape ? 0 : group * 4].version);
                            BUSTER_STRING_TEST(arguments, version_library, library.name);
                        }
                        previous = address;
                        if (!shape)
                        {
                            u64 pair = 0;
                            BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, data[group * 4 + 1].name, &pair, 0, 0));
                            BUSTER_TEST(arguments, pair == address);
                        }
                    }
                    u64 header = 0;
                    BUSTER_TEST(arguments, link_test_elf_section_find(linked.executable, S8(".dynsym"), 0, &header));
                    u32 aliases = shape ? count - groups : count;
                    // Null entry, the two hosted-runtime imports, data imports,
                    // and unique aliases. No global definition is exported here.
                    BUSTER_TEST(arguments, header && link_read_u64(linked.executable.pointer, header + 32) / 24 == 3 + import_count + aliases);
                }
                if (benchmark && iteration)
                {
                    string_print(S8("BENCH_ELF_DATA shape={u32} count={u32} imports={u32} exports={u32} iteration={u32} ns={u64} bytes={u64} retained={u64} temporary={u64} hash={u64}\n"),
                        shape, count, import_count, export_count, iteration, ns, linked.executable.length,
                        output->position - output_position, arena_dirty_position(temporary) - temporary_position, hash);
                }
                arena_set_position(output, output_position);
            }
            arena_destroy(temporary, 1);
            arena_destroy(output, 1);
            scratch_end(fixture);
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL UnitTestResult link_test_elf_data_precedence(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    u8 text[] = {0x31, 0xc0, 0xc3};
    ObjectSymbol symbols[] = {
        {.name = S8("main"), .kind = OBJECT_SYMBOL_FUNCTION, .section = OBJECT_SECTION_TEXT, .size = sizeof(text), .global = true},
        {.name = S8("first"), .kind = OBJECT_SYMBOL_DATA, .section = OBJECT_SECTION_UNDEFINED, .global = true},
        {.name = S8("second"), .kind = OBJECT_SYMBOL_DATA, .section = OBJECT_SECTION_UNDEFINED, .global = true},
        {.name = S8("own"), .kind = OBJECT_SYMBOL_DATA, .section = OBJECT_SECTION_ZERO, .global = true},
        {.name = S8("local"), .kind = OBJECT_SYMBOL_DATA, .section = OBJECT_SECTION_ZERO},
    };
    NativeDynamicDataSymbol runtime[] = {
        {.name = S8("first"), .address = 0x1000, .size = 8},
        {.name = S8("own"), .address = 0x1000, .size = 65536},
        {.name = S8("local"), .address = 0x1000, .size = 16},
        {.name = S8("local"), .address = 0x1000, .size = 65536},
        {.name = S8("first"), .address = 0x2000, .size = 65536},
    };
    NativeDynamicDataSymbol other[] = {
        {.name = S8("first"), .address = 0x1000, .size = 65536},
        {.name = S8("second"), .address = 0x1000, .size = 32},
        {.name = S8("other_alias"), .address = 0x1000, .size = 32},
    };
    NativeDynamicLibrary library = {.name = S8("libsecond.so"), .exported_data_symbols = other,
        .exported_data_symbol_count = BUSTER_ARRAY_LENGTH(other)};
    NativeDynamicVersionedSymbol runtime_versions[] = {
        {.name = S8("first"), .version = S8("HIDDEN")},
        {.name = S8("first"), .version = S8("RUNTIME"), .has_default = true},
        {.name = S8("first"), .version = S8("LATER"), .has_default = true},
        {.name = S8("second"), .version = S8("HIDDEN")},
    };
    NativeDynamicVersionedSymbol library_versions[] = {
        {.name = S8("first"), .version = S8("LIBRARY"), .has_default = true},
        {.name = S8("second"), .version = S8("LIBRARY"), .has_default = true},
    };
    library.versioned_symbols = library_versions;
    library.versioned_symbol_count = BUSTER_ARRAY_LENGTH(library_versions);
    NativeExecutableLinkOptions options = {.runtime_data_symbols = runtime, .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(runtime),
        .dynamic_libraries = &library, .dynamic_library_count = 1, .runtime_versioned_symbols = runtime_versions,
        .runtime_versioned_symbol_count = BUSTER_ARRAY_LENGTH(runtime_versions)};
    ObjectFile object = link_test_object_make(arguments->arena, (Target){.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},
        (ByteSlice)BUSTER_ARRAY_TO_SLICE(text), symbols, BUSTER_ARRAY_LENGTH(symbols), 0, 0);
    NativeExecutableLinkResult linked = link_native_executable(arguments->arena, &object, options);
    BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
    u64 first = 0;
    u64 second = 0;
    u64 local = 0;
    u64 first_size = 0;
    u64 second_size = 0;
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, S8("first"), &first, &first_size, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, S8("second"), &second, &second_size, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, S8("local"), &local, 0, 0));
    BUSTER_TEST(arguments, first && first != second && local == first && first_size == 16 && second_size == 32);
    BUSTER_TEST(arguments, !link_test_elf_dynamic_symbol(linked.executable, S8("own"), 0, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_relocation_count(linked.executable, 5) == 2);
    String8 version = {0};
    String8 version_library = {0};
    BUSTER_TEST(arguments, link_test_elf_symbol_version(linked.executable, S8("first"), &version, &version_library));
    BUSTER_STRING_TEST(arguments, version, S8("RUNTIME"));
    BUSTER_STRING_TEST(arguments, version_library, S8("libc.so.6"));
    BUSTER_TEST(arguments, link_test_elf_symbol_version(linked.executable, S8("second"), &version, &version_library));
    BUSTER_STRING_TEST(arguments, version, S8("LIBRARY"));
    BUSTER_STRING_TEST(arguments, version_library, S8("libsecond.so"));
    // Identical backing tables, with different view lengths, still denote one
    // object. Only the first imported definition's view supplies its aliases.
    other[0] = (NativeDynamicDataSymbol){.name = S8("first"), .address = 0x1000, .size = 8};
    options.runtime_data_symbols = other;
    options.runtime_data_symbol_count = 1;
    linked = link_native_executable(arguments->arena, &object, options);
    BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, S8("first"), &first, &first_size, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(linked.executable, S8("second"), &second, 0, 0));
    BUSTER_TEST(arguments, first == second && first_size == 8);
    BUSTER_TEST(arguments, !link_test_elf_dynamic_symbol(linked.executable, S8("other_alias"), 0, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_relocation_count(linked.executable, 5) == 1);
    // Reject aggregate sizing and missing-table errors before walking exports.
    NativeExecutableLinkOptions invalid[] = {
        {.runtime_data_symbols = runtime, .runtime_data_symbol_count = UINT32_MAX},
        {.runtime_versioned_symbol_count = 1},
        {.runtime_data_symbol_count = 1},
        {.dynamic_libraries = &library, .dynamic_library_count = UINT32_MAX},
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(invalid); index += 1)
    {
        BUSTER_TEST(arguments, link_native_executable(arguments->arena, &object, invalid[index]).error == LINK_ERROR_INVALID_INPUT);
    }
    options.runtime_data_symbol_count = UINT32_MAX / 2;
    library.exported_data_symbol_count = UINT32_MAX / 2;
    BUSTER_TEST(arguments, link_native_executable(arguments->arena, &object, options).error == LINK_ERROR_INVALID_INPUT);
    return result;
}

UnitTestResult link_tests(UnitTestArguments* arguments)
{
    UnitTestResult result = {0};
    UnitTestResult single_input_alias = link_test_single_input_alias(arguments);
    result.succeeded_test_count += single_input_alias.succeeded_test_count;
    result.test_count += single_input_alias.test_count;
    UnitTestResult data_indexes = link_test_elf_data_indexes(arguments);
    result.succeeded_test_count += data_indexes.succeeded_test_count;
    result.test_count += data_indexes.test_count;
    UnitTestResult data_precedence = link_test_elf_data_precedence(arguments);
    result.succeeded_test_count += data_precedence.succeeded_test_count;
    result.test_count += data_precedence.test_count;
    UnitTestResult comdat_selection = link_test_coff_comdat_selection(arguments);
    result.succeeded_test_count += comdat_selection.succeeded_test_count;
    result.test_count += comdat_selection.test_count;
    UnitTestResult thread_local_identity = link_test_thread_local_symbol_identity(arguments);
    result.succeeded_test_count += thread_local_identity.succeeded_test_count;
    result.test_count += thread_local_identity.test_count;
    UnitTestResult initializer_order = link_test_initializer_order(arguments);
    result.succeeded_test_count += initializer_order.succeeded_test_count;
    result.test_count += initializer_order.test_count;
    UnitTestResult got_marker = link_test_unused_got_marker(arguments);
    result.succeeded_test_count += got_marker.succeeded_test_count;
    result.test_count += got_marker.test_count;
    UnitTestResult initialized = link_test_merged_section_initialization(arguments);
    result.succeeded_test_count += initialized.succeeded_test_count;
    result.test_count += initialized.test_count;
    UnitTestResult copy_symbol_table = link_test_elf_copy_symbol_table(arguments);
    result.succeeded_test_count += copy_symbol_table.succeeded_test_count;
    result.test_count += copy_symbol_table.test_count;
    UnitTestResult symbol_table = link_test_elf_symbol_table(arguments);
    result.succeeded_test_count += symbol_table.succeeded_test_count;
    result.test_count += symbol_table.test_count;
    UnitTestResult merged_symbol_table = link_test_elf_merged_symbol_table(arguments);
    result.succeeded_test_count += merged_symbol_table.succeeded_test_count;
    result.test_count += merged_symbol_table.test_count;
    UnitTestResult section_table_tail = link_test_elf_section_table_tail(arguments);
    result.succeeded_test_count += section_table_tail.succeeded_test_count;
    result.test_count += section_table_tail.test_count;
    UnitTestResult alignment = link_test_elf_data_alignment(arguments);
    result.succeeded_test_count += alignment.succeeded_test_count;
    result.test_count += alignment.test_count;
    static u8 const sha256_abc[32] = {
        0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea, 0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
        0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c, 0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad,
    };
    u8 sha256_result[32] = {0};
    link_sha256(arguments->arena, (u8 const*)"abc", 3, sha256_result);
    BUSTER_TEST(arguments, memcmp(sha256_result, sha256_abc, sizeof(sha256_abc)) == 0);
    UnitTestResult uefi_x64 = link_test_uefi_pe64(arguments, CPU_ARCH_X86_64);
    result.succeeded_test_count += uefi_x64.succeeded_test_count;
    result.test_count += uefi_x64.test_count;
    UnitTestResult uefi_aarch64 = link_test_uefi_pe64(arguments, CPU_ARCH_AARCH64);
    result.succeeded_test_count += uefi_aarch64.succeeded_test_count;
    result.test_count += uefi_aarch64.test_count;
    {
        ObjectSectionKind symbol_sections[] = {
            OBJECT_SECTION_TEXT,
            OBJECT_SECTION_READ_ONLY_DATA,
            OBJECT_SECTION_DATA,
            OBJECT_SECTION_ZERO,
            OBJECT_SECTION_THREAD_LOCAL_DATA,
            OBJECT_SECTION_THREAD_LOCAL_ZERO,
        };
        u32 expected_output_sections[] = {0, 1, 2, 3, 4, 4};
        u64 expected_section_offsets[] = {0x40, 0x10, 0x20, 0x30, 0x50, 0x90};
        u8 codeview_bytes[BUSTER_ARRAY_LENGTH(symbol_sections) * 8] = {0};
        ObjectSection sections[OBJECT_SECTION_COUNT] = {0};
        sections[OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(codeview_bytes);
        ObjectSymbol symbols[BUSTER_ARRAY_LENGTH(symbol_sections)] = {0};
        ObjectRelocation relocations[BUSTER_ARRAY_LENGTH(symbol_sections) * 2] = {0};
        u32 object_output_sections[OBJECT_SECTION_COUNT];
        u64 object_section_offsets[OBJECT_SECTION_COUNT] = {0};
        memset(object_output_sections, 0xff, sizeof(object_output_sections));
        for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(symbol_sections); index += 1)
        {
            ObjectSectionKind section = symbol_sections[index];
            symbols[index] = (ObjectSymbol){
                .value = 0x100 + (u64)index * 0x10,
                .section = (u32)section,
                .kind = OBJECT_SYMBOL_DATA,
            };
            relocations[index * 2] = (ObjectRelocation){
                .addend = (s64)index - 2,
                .offset = (u64)index * 8,
                .section = OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS,
                .symbol = index,
                .kind = OBJECT_RELOCATION_COFF_SECREL32,
            };
            relocations[index * 2 + 1] = (ObjectRelocation){
                .addend = index,
                .offset = (u64)index * 8 + 4,
                .section = OBJECT_SECTION_DEBUG_CODEVIEW_SYMBOLS,
                .symbol = index,
                .kind = OBJECT_RELOCATION_COFF_SECTION16,
            };
            object_output_sections[section] = expected_output_sections[index];
            object_section_offsets[section] = expected_section_offsets[index];
        }
        ObjectDebugModule debug_module = {.symbols_size = sizeof(codeview_bytes)};
        ObjectFile object = {
            .sections = sections,
            .symbols = symbols,
            .relocations = relocations,
            .section_count = OBJECT_SECTION_COUNT,
            .symbol_count = BUSTER_ARRAY_LENGTH(symbols),
            .relocation_count = BUSTER_ARRAY_LENGTH(relocations),
        };
        ByteSlice resolved = link_pe_resolved_codeview(arguments->arena, &object, &debug_module, object_output_sections,
                                                       object_section_offsets, 5);
        BUSTER_TEST(arguments, resolved.length == sizeof(codeview_bytes));
        if (resolved.length == sizeof(codeview_bytes))
        {
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(symbol_sections); index += 1)
            {
                u32 section_offset = 0;
                u16 section_number = 0;
                memcpy(&section_offset, resolved.pointer + (u64)index * 8, sizeof(section_offset));
                memcpy(&section_number, resolved.pointer + (u64)index * 8 + 4, sizeof(section_number));
                s64 addend = (s64)index - 2;
                u32 expected_section_offset = (u32)((s64)symbols[index].value + (s64)expected_section_offsets[index] + addend);
                BUSTER_TEST(arguments, section_offset == expected_section_offset);
                BUSTER_TEST(arguments, section_number == expected_output_sections[index] + 1 + index);
            }
        }
        object_output_sections[OBJECT_SECTION_DATA] = UINT32_MAX;
        BUSTER_TEST(arguments,
                    link_pe_resolved_codeview(arguments->arena, &object, &debug_module, object_output_sections, object_section_offsets, 5).length == 0);
        object_output_sections[OBJECT_SECTION_DATA] = expected_output_sections[2];
        relocations[1].addend = UINT16_MAX;
        BUSTER_TEST(arguments,
                    link_pe_resolved_codeview(arguments->arena, &object, &debug_module, object_output_sections, object_section_offsets, 5).length == 0);
    }
    Target target = target_native;
    {
        u8 first_text[24] = {0};
        u8 second_text[32] = {0};
        u8 third_text[16] = {0};
        ObjectSymbol first_symbols[] = {
            {
                .name = S8("upgrade"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
            {
                .name = S8("private"),
                .value = 1,
                .size = 1,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_DATA,
            },
            {
                .name = S8("first"),
                .value = 2,
                .size = 1,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
        };
        ObjectSymbol second_symbols[] = {
            {
                .name = S8("upgrade"),
                .value = 3,
                .size = 1,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_DATA,
                .global = true,
            },
            {
                .name = S8("private"),
                .value = 4,
                .size = 1,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_DATA,
            },
            {
                .name = S8("first"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
            {
                .name = S8("private"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
        };
        ObjectSymbol third_symbols[] = {
            {
                .name = S8("upgrade"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
            {
                .name = S8("private"),
                .value = 1,
                .size = 1,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_DATA,
                .global = true,
            },
        };
        ObjectRelocation first_relocations[] = {
            {.section = OBJECT_SECTION_TEXT, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 16, .section = OBJECT_SECTION_TEXT, .symbol = 2, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        };
        ObjectRelocation second_relocations[] = {
            {.section = OBJECT_SECTION_TEXT, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 16, .section = OBJECT_SECTION_TEXT, .symbol = 2, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 24, .section = OBJECT_SECTION_TEXT, .symbol = 3, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        };
        ObjectRelocation third_relocations[] = {
            {.section = OBJECT_SECTION_TEXT, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        };
        ObjectFile ordered_objects[] = {
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(first_text), first_symbols,
                                  BUSTER_ARRAY_LENGTH(first_symbols), first_relocations, BUSTER_ARRAY_LENGTH(first_relocations)),
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(second_text), second_symbols,
                                  BUSTER_ARRAY_LENGTH(second_symbols), second_relocations, BUSTER_ARRAY_LENGTH(second_relocations)),
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(third_text), third_symbols,
                                  BUSTER_ARRAY_LENGTH(third_symbols), third_relocations, BUSTER_ARRAY_LENGTH(third_relocations)),
        };
        LinkObjectResult ordered = link_objects(arguments->arena, ordered_objects, BUSTER_ARRAY_LENGTH(ordered_objects), (LinkOptions){0});
        BUSTER_TEST(arguments, ordered.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, ordered.object.symbol_count == 5);
        BUSTER_TEST(arguments, ordered.object.relocation_count == 9);
        if (ordered.error == LINK_ERROR_NONE && ordered.object.symbol_count == 5 && ordered.object.relocation_count == 9)
        {
            String8 expected_names[] = {
                S8("upgrade"),
                S8("private"),
                S8("first"),
                S8("private"),
                S8("private"),
            };
            u32 expected_relocation_symbols[] = {0, 1, 2, 0, 3, 2, 4, 0, 4};
            bool names_match = true;
            bool relocations_match = true;
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(expected_names); index += 1)
            {
                names_match = names_match && string_equal(ordered.object.symbols[index].name, expected_names[index]);
            }
            for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(expected_relocation_symbols); index += 1)
            {
                relocations_match = relocations_match && ordered.object.relocations[index].symbol == expected_relocation_symbols[index];
            }
            u64 second_text_offset = align_forward(sizeof(first_text), object_section_default_alignment(OBJECT_SECTION_TEXT));
            u64 third_text_offset = align_forward(second_text_offset + sizeof(second_text), object_section_default_alignment(OBJECT_SECTION_TEXT));
            BUSTER_TEST(arguments, names_match);
            BUSTER_TEST(arguments, relocations_match);
            BUSTER_TEST(arguments, ordered.object.symbols[0].section == OBJECT_SECTION_TEXT && ordered.object.symbols[0].kind == OBJECT_SYMBOL_DATA &&
                                       ordered.object.symbols[0].value == second_text_offset + 3 && ordered.object.symbols[0].size == 1);
            BUSTER_TEST(arguments, !ordered.object.symbols[1].global && !ordered.object.symbols[3].global &&
                                       ordered.object.symbols[1].value == 1 && ordered.object.symbols[3].value == second_text_offset + 4);
            BUSTER_TEST(arguments, ordered.object.symbols[4].global && ordered.object.symbols[4].section == OBJECT_SECTION_TEXT &&
                                       ordered.object.symbols[4].value == third_text_offset + 1);
        }
    }
    {
        enum
        {
            LINK_TEST_COLLISION_SYMBOL_COUNT = 32,
            LINK_TEST_COLLISION_NAME_LENGTH = 9,
        };
        u64 table_capacity = 1;
        u64 total_symbols = LINK_TEST_COLLISION_SYMBOL_COUNT * 2;
        while (table_capacity < total_symbols * 2)
        {
            table_capacity *= 2;
        }
        char8 collision_names[LINK_TEST_COLLISION_SYMBOL_COUNT][LINK_TEST_COLLISION_NAME_LENGTH];
        u32 collision_name_count = 0;
        for (u32 candidate = 0; candidate < (1u << 20) && collision_name_count < LINK_TEST_COLLISION_SYMBOL_COUNT; candidate += 1)
        {
            char8 candidate_name[LINK_TEST_COLLISION_NAME_LENGTH];
            String8 name = link_test_symbol_name_write(candidate_name, candidate);
            if ((buster_hash_64((u8*)name.pointer, name.length) & (table_capacity - 1)) ==
                table_capacity - LINK_TEST_COLLISION_SYMBOL_COUNT / 2)
            {
                memcpy(collision_names[collision_name_count], candidate_name, sizeof(candidate_name));
                collision_name_count += 1;
            }
        }
        BUSTER_TEST(arguments, collision_name_count == LINK_TEST_COLLISION_SYMBOL_COUNT);
        if (collision_name_count == LINK_TEST_COLLISION_SYMBOL_COUNT)
        {
            ObjectSymbol definition_symbols[LINK_TEST_COLLISION_SYMBOL_COUNT];
            ObjectSymbol reference_symbols[LINK_TEST_COLLISION_SYMBOL_COUNT];
            ObjectRelocation reference_relocations[LINK_TEST_COLLISION_SYMBOL_COUNT];
            u8 reference_text[LINK_TEST_COLLISION_SYMBOL_COUNT * 8] = {0};
            for (u32 index = 0; index < LINK_TEST_COLLISION_SYMBOL_COUNT; index += 1)
            {
                u32 reverse = LINK_TEST_COLLISION_SYMBOL_COUNT - 1 - index;
                definition_symbols[index] = (ObjectSymbol){
                    .name = {.pointer = collision_names[index], .length = LINK_TEST_COLLISION_NAME_LENGTH},
                    .section = OBJECT_SECTION_TEXT,
                    .kind = OBJECT_SYMBOL_FUNCTION,
                    .global = true,
                };
                reference_symbols[index] = (ObjectSymbol){
                    .name = {.pointer = collision_names[reverse], .length = LINK_TEST_COLLISION_NAME_LENGTH},
                    .section = OBJECT_SECTION_UNDEFINED,
                    .kind = OBJECT_SYMBOL_FUNCTION,
                    .global = true,
                };
                reference_relocations[index] = (ObjectRelocation){
                    .offset = (u64)index * 8,
                    .section = OBJECT_SECTION_TEXT,
                    .symbol = index,
                    .kind = OBJECT_RELOCATION_ABSOLUTE64,
                };
            }
            ObjectFile collision_objects[] = {
                link_test_object_make(arguments->arena, target, (ByteSlice){0}, definition_symbols, BUSTER_ARRAY_LENGTH(definition_symbols), 0, 0),
                link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(reference_text), reference_symbols,
                                      BUSTER_ARRAY_LENGTH(reference_symbols), reference_relocations, BUSTER_ARRAY_LENGTH(reference_relocations)),
            };
            LinkObjectResult collision = link_objects(arguments->arena, collision_objects, BUSTER_ARRAY_LENGTH(collision_objects), (LinkOptions){0});
            BUSTER_TEST(arguments, collision.error == LINK_ERROR_NONE);
            BUSTER_TEST(arguments, collision.object.symbol_count == LINK_TEST_COLLISION_SYMBOL_COUNT);
            BUSTER_TEST(arguments, collision.object.relocation_count == LINK_TEST_COLLISION_SYMBOL_COUNT);
            if (collision.error == LINK_ERROR_NONE && collision.object.symbol_count == LINK_TEST_COLLISION_SYMBOL_COUNT &&
                collision.object.relocation_count == LINK_TEST_COLLISION_SYMBOL_COUNT)
            {
                bool collision_results_match = true;
                for (u32 index = 0; index < LINK_TEST_COLLISION_SYMBOL_COUNT; index += 1)
                {
                    collision_results_match = collision_results_match &&
                                              string_equal(collision.object.symbols[index].name,
                                                           (String8){.pointer = collision_names[index], .length = LINK_TEST_COLLISION_NAME_LENGTH}) &&
                                              collision.object.relocations[index].symbol == LINK_TEST_COLLISION_SYMBOL_COUNT - 1 - index;
                }
                BUSTER_TEST(arguments, collision_results_match);
            }
        }
    }
    {
        enum
        {
            LINK_TEST_STRESS_SYMBOL_COUNT = 4097,
            LINK_TEST_STRESS_NAME_LENGTH = 9,
        };
        char8* name_storage = arena_allocate(arguments->arena, char8, (u64)LINK_TEST_STRESS_SYMBOL_COUNT * LINK_TEST_STRESS_NAME_LENGTH);
        ObjectSymbol* definition_symbols = arena_allocate(arguments->arena, ObjectSymbol, LINK_TEST_STRESS_SYMBOL_COUNT);
        ObjectSymbol* reference_symbols = arena_allocate(arguments->arena, ObjectSymbol, LINK_TEST_STRESS_SYMBOL_COUNT);
        for (u32 index = 0; index < LINK_TEST_STRESS_SYMBOL_COUNT; index += 1)
        {
            char8* name = name_storage + (u64)index * LINK_TEST_STRESS_NAME_LENGTH;
            String8 symbol_name = link_test_symbol_name_write(name, index);
            definition_symbols[index] = (ObjectSymbol){
                .name = symbol_name,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            };
            reference_symbols[index] = (ObjectSymbol){
                .name = {.pointer = name_storage + (u64)(LINK_TEST_STRESS_SYMBOL_COUNT - 1 - index) * LINK_TEST_STRESS_NAME_LENGTH,
                         .length = LINK_TEST_STRESS_NAME_LENGTH},
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            };
        }
        ObjectFile stress_objects[] = {
            link_test_object_make(arguments->arena, target, (ByteSlice){0}, definition_symbols, LINK_TEST_STRESS_SYMBOL_COUNT, 0, 0),
            link_test_object_make(arguments->arena, target, (ByteSlice){0}, reference_symbols, LINK_TEST_STRESS_SYMBOL_COUNT, 0, 0),
        };
        LinkObjectResult stress = link_objects(arguments->arena, stress_objects, BUSTER_ARRAY_LENGTH(stress_objects), (LinkOptions){0});
        BUSTER_TEST(arguments, stress.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, stress.object.symbol_count == LINK_TEST_STRESS_SYMBOL_COUNT);
        if (stress.error == LINK_ERROR_NONE && stress.object.symbol_count == LINK_TEST_STRESS_SYMBOL_COUNT)
        {
            bool order_matches = true;
            for (u32 index = 0; index < LINK_TEST_STRESS_SYMBOL_COUNT; index += 1)
            {
                order_matches = order_matches && string_equal(stress.object.symbols[index].name, definition_symbols[index].name);
            }
            BUSTER_TEST(arguments, order_matches);
        }
    }
    {
        u8 text[1] = {0};
        ObjectSymbol first = {
            .name = S8("duplicate"),
            .size = 1,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        };
        ObjectSymbol second = first;
        ObjectFile duplicate_objects[] = {
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(text), &first, 1, 0, 0),
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(text), &second, 1, 0, 0),
        };
        LinkObjectResult duplicate = link_objects(arguments->arena, duplicate_objects, BUSTER_ARRAY_LENGTH(duplicate_objects), (LinkOptions){0});
        BUSTER_TEST(arguments, duplicate.error == LINK_ERROR_DUPLICATE_SYMBOL);
        BUSTER_STRING_TEST(arguments, duplicate.symbol, S8("duplicate"));

        // Replaceable definitions — COFF selectany COMDAT, ELF weak, Mach-O
        // N_WEAK_DEF — resolve instead of colliding.  Two of them keep the
        // first input; a strong one wins from either side; the losing bytes
        // stay in the merged section, so only the retained symbol's value
        // moves.
        u8 replaceable_text[16] = {0};
        ObjectSymbol weak_first = {
            .name = S8("replaceable"),
            .size = 1,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
            .weak = true,
        };
        ObjectSymbol weak_second = weak_first;
        weak_second.value = 8;
        ObjectSymbol strong = weak_first;
        strong.weak = false;
        strong.value = 4;
        ByteSlice replaceable_slice = (ByteSlice)BUSTER_ARRAY_TO_SLICE(replaceable_text);
        ObjectFile weak_pair[] = {
            link_test_object_make(arguments->arena, target, replaceable_slice, &weak_first, 1, 0, 0),
            link_test_object_make(arguments->arena, target, replaceable_slice, &weak_second, 1, 0, 0),
        };
        LinkObjectResult weak_only = link_objects(arguments->arena, weak_pair, BUSTER_ARRAY_LENGTH(weak_pair), (LinkOptions){0});
        BUSTER_TEST(arguments, weak_only.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, weak_only.error == LINK_ERROR_NONE && weak_only.object.symbol_count == 1);
        if (weak_only.error == LINK_ERROR_NONE && weak_only.object.symbol_count == 1)
        {
            BUSTER_TEST(arguments, weak_only.object.symbols[0].value == 0 && weak_only.object.symbols[0].weak);
        }
        ObjectFile weak_then_strong[] = {
            link_test_object_make(arguments->arena, target, replaceable_slice, &weak_first, 1, 0, 0),
            link_test_object_make(arguments->arena, target, replaceable_slice, &strong, 1, 0, 0),
        };
        LinkObjectResult strong_last = link_objects(arguments->arena, weak_then_strong, BUSTER_ARRAY_LENGTH(weak_then_strong), (LinkOptions){0});
        BUSTER_TEST(arguments, strong_last.error == LINK_ERROR_NONE && strong_last.object.symbol_count == 1);
        if (strong_last.error == LINK_ERROR_NONE && strong_last.object.symbol_count == 1)
        {
            // The second object's text follows the first, so the strong
            // definition keeps its own offset rather than the weak one's.
            BUSTER_TEST(arguments, !strong_last.object.symbols[0].weak);
            BUSTER_TEST(arguments, strong_last.object.symbols[0].value == sizeof(replaceable_text) + 4);
        }
        ObjectFile strong_then_weak[] = {
            link_test_object_make(arguments->arena, target, replaceable_slice, &strong, 1, 0, 0),
            link_test_object_make(arguments->arena, target, replaceable_slice, &weak_second, 1, 0, 0),
        };
        LinkObjectResult strong_first = link_objects(arguments->arena, strong_then_weak, BUSTER_ARRAY_LENGTH(strong_then_weak), (LinkOptions){0});
        BUSTER_TEST(arguments, strong_first.error == LINK_ERROR_NONE && strong_first.object.symbol_count == 1);
        if (strong_first.error == LINK_ERROR_NONE && strong_first.object.symbol_count == 1)
        {
            BUSTER_TEST(arguments, !strong_first.object.symbols[0].weak && strong_first.object.symbols[0].value == 4);
        }
        ObjectFile strong_pair[] = {
            link_test_object_make(arguments->arena, target, replaceable_slice, &strong, 1, 0, 0),
            link_test_object_make(arguments->arena, target, replaceable_slice, &strong, 1, 0, 0),
        };
        LinkObjectResult strong_duplicate = link_objects(arguments->arena, strong_pair, BUSTER_ARRAY_LENGTH(strong_pair), (LinkOptions){0});
        BUSTER_TEST(arguments, strong_duplicate.error == LINK_ERROR_DUPLICATE_SYMBOL);
        BUSTER_STRING_TEST(arguments, strong_duplicate.symbol, S8("replaceable"));
        // A replaceable definition still answers an undefined reference.
        ObjectSymbol replaceable_reference = {
            .name = S8("replaceable"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        };
        ObjectFile reference_then_weak[] = {
            link_test_object_make(arguments->arena, target, (ByteSlice){0}, &replaceable_reference, 1, 0, 0),
            link_test_object_make(arguments->arena, target, replaceable_slice, &weak_first, 1, 0, 0),
        };
        LinkObjectResult resolved = link_objects(arguments->arena, reference_then_weak, BUSTER_ARRAY_LENGTH(reference_then_weak), (LinkOptions){0});
        BUSTER_TEST(arguments, resolved.error == LINK_ERROR_NONE && resolved.object.symbol_count == 1);
        if (resolved.error == LINK_ERROR_NONE && resolved.object.symbol_count == 1)
        {
            BUSTER_TEST(arguments, resolved.object.symbols[0].section == OBJECT_SECTION_TEXT && resolved.object.symbols[0].weak);
        }

        ObjectSymbol empty_name = {
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        };
        ObjectFile empty_name_object = link_test_object_make(arguments->arena, target, (ByteSlice){0}, &empty_name, 1, 0, 0);
        LinkObjectResult empty = link_objects(arguments->arena, &empty_name_object, 1,
                                              (LinkOptions){
                                                  .allow_undefined_symbols = true,
                                              });
        BUSTER_TEST(arguments, empty.error == LINK_ERROR_INVALID_INPUT);

        ObjectFile no_symbols_object = link_test_object_make(arguments->arena, target, (ByteSlice){0}, 0, 0, 0, 0);
        LinkObjectResult no_symbols = link_objects(arguments->arena, &no_symbols_object, 1, (LinkOptions){0});
        BUSTER_TEST(arguments, no_symbols.error == LINK_ERROR_NONE && no_symbols.object.symbol_count == 0);

        // Initializer arrays merge in GNU's whole-program order rather than by
        // concatenation (issue 789): every priority ahead of every entry that
        // named none, ascending, and equal priorities -- including the run
        // that named none -- in link order.  Two objects are the smallest
        // shape that shows it, because each one's own array is already sorted.
        // The entries carry a distinct byte each so the data permutation is
        // observable beside the relocations, and the second object defines a
        // symbol *inside* its array (crtbegin's
        // `__frame_dummy_init_array_entry` is the real one) so the merge is
        // pinned to move those with the entry too.
        u8 first_initializer_entries[2 * OBJECT_INITIALIZER_ENTRY_SIZE] = {0x20, 0, 0, 0, 0, 0, 0, 0, 0x40};
        u8 second_initializer_entries[3 * OBJECT_INITIALIZER_ENTRY_SIZE] = {0x10, 0, 0, 0, 0, 0, 0, 0, 0x30, 0, 0, 0, 0, 0, 0, 0, 0x50};
        u32 first_initializer_priorities[] = {120, IR_INITIALIZER_PRIORITY_NONE};
        u32 second_initializer_priorities[] = {101, 150, IR_INITIALIZER_PRIORITY_NONE};
        ObjectSymbol first_initializer_symbols[] = {
            {.name = S8("first_middle"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION},
            {.name = S8("first_plain"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION},
        };
        ObjectSymbol second_initializer_symbols[] = {
            {.name = S8("second_earliest"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION},
            {.name = S8("second_latest"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION},
            {.name = S8("second_plain"), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION},
            {
                .name = S8("second_array_entry"),
                .value = 2 * OBJECT_INITIALIZER_ENTRY_SIZE,
                .size = OBJECT_INITIALIZER_ENTRY_SIZE,
                .section = OBJECT_SECTION_INIT_ARRAY,
                .kind = OBJECT_SYMBOL_DATA,
            },
        };
        ObjectRelocation first_initializer_relocations[] = {
            {.section = OBJECT_SECTION_INIT_ARRAY, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = OBJECT_INITIALIZER_ENTRY_SIZE, .section = OBJECT_SECTION_INIT_ARRAY, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        };
        ObjectRelocation second_initializer_relocations[] = {
            {.section = OBJECT_SECTION_INIT_ARRAY, .symbol = 0, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = OBJECT_INITIALIZER_ENTRY_SIZE, .section = OBJECT_SECTION_INIT_ARRAY, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
            {.offset = 2 * OBJECT_INITIALIZER_ENTRY_SIZE, .section = OBJECT_SECTION_INIT_ARRAY, .symbol = 2, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        };
        u8 initializer_text[] = {0, 0, 0, 0, 0, 0, 0, 0};
        ObjectFile initializer_objects[] = {
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(initializer_text), first_initializer_symbols,
                                  BUSTER_ARRAY_LENGTH(first_initializer_symbols), first_initializer_relocations,
                                  BUSTER_ARRAY_LENGTH(first_initializer_relocations)),
            link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(initializer_text), second_initializer_symbols,
                                  BUSTER_ARRAY_LENGTH(second_initializer_symbols), second_initializer_relocations,
                                  BUSTER_ARRAY_LENGTH(second_initializer_relocations)),
        };
        initializer_objects[0].sections[OBJECT_SECTION_INIT_ARRAY].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(first_initializer_entries);
        initializer_objects[0].initializer_priorities[0] = first_initializer_priorities;
        initializer_objects[1].sections[OBJECT_SECTION_INIT_ARRAY].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(second_initializer_entries);
        initializer_objects[1].initializer_priorities[0] = second_initializer_priorities;
        LinkObjectResult initializer_merge =
            link_objects(arguments->arena, initializer_objects, BUSTER_ARRAY_LENGTH(initializer_objects), (LinkOptions){0});
        BUSTER_TEST(arguments, initializer_merge.error == LINK_ERROR_NONE);
        if (initializer_merge.error == LINK_ERROR_NONE)
        {
            String8 expected_initializer_names[] = {
                S8("second_earliest"), S8("first_middle"), S8("second_latest"), S8("first_plain"), S8("second_plain"),
            };
            u32 expected_initializer_priorities[] = {101, 120, 150, IR_INITIALIZER_PRIORITY_NONE, IR_INITIALIZER_PRIORITY_NONE};
            u8 expected_initializer_entries[] = {0x10, 0x20, 0x30, 0x40, 0x50};
            ObjectSection merged = initializer_merge.object.sections[OBJECT_SECTION_INIT_ARRAY];
            BUSTER_TEST(arguments, merged.data.length == BUSTER_ARRAY_LENGTH(expected_initializer_names) * OBJECT_INITIALIZER_ENTRY_SIZE);
            u32 initializer_entries_found = 0;
            for (u32 relocation_index = 0; relocation_index < initializer_merge.object.relocation_count; relocation_index += 1)
            {
                ObjectRelocation relocation = initializer_merge.object.relocations[relocation_index];
                u64 entry = relocation.offset / OBJECT_INITIALIZER_ENTRY_SIZE;
                if (relocation.section != OBJECT_SECTION_INIT_ARRAY || entry >= BUSTER_ARRAY_LENGTH(expected_initializer_names))
                {
                    continue;
                }
                BUSTER_TEST(arguments, string_equal(initializer_merge.object.symbols[relocation.symbol].name, expected_initializer_names[entry]));
                initializer_entries_found += 1;
            }
            BUSTER_TEST(arguments, initializer_entries_found == BUSTER_ARRAY_LENGTH(expected_initializer_names));
            for (u64 entry = 0; entry < BUSTER_ARRAY_LENGTH(expected_initializer_names); entry += 1)
            {
                BUSTER_TEST(arguments, initializer_merge.object.initializer_priorities[0][entry] == expected_initializer_priorities[entry]);
                BUSTER_TEST(arguments, merged.data.pointer[entry * OBJECT_INITIALIZER_ENTRY_SIZE] == expected_initializer_entries[entry]);
            }
            // `second_plain` is the last entry of the merged array, and the
            // symbol that named its slot has to have followed it there from
            // the third slot of its own object.
            u32 array_entry_index = UINT32_MAX;
            for (u32 symbol_index = 0; symbol_index < initializer_merge.object.symbol_count; symbol_index += 1)
            {
                if (string_equal(initializer_merge.object.symbols[symbol_index].name, S8("second_array_entry")))
                {
                    array_entry_index = symbol_index;
                }
            }
            BUSTER_TEST(arguments, array_entry_index != UINT32_MAX);
            if (array_entry_index != UINT32_MAX)
            {
                BUSTER_TEST(arguments, initializer_merge.object.symbols[array_entry_index].value == 4 * OBJECT_INITIALIZER_ENTRY_SIZE);
            }
        }
    }
#if BUSTER_CPU_ARCH_X86_64
    u8 answer_text[] = {
        0xb8, 42, 0, 0, 0, 0xc3,
    };
    u8 main_text[] = {
        0xe8, 0, 0, 0, 0, 0x83, 0xe8, 42, 0xc3,
    };
    ByteSlice answer_bytes = (ByteSlice)BUSTER_ARRAY_TO_SLICE(answer_text);
    ByteSlice main_bytes = (ByteSlice)BUSTER_ARRAY_TO_SLICE(main_text);
    ObjectRelocation main_relocation = {
        .addend = -4,
        .offset = 1,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_PC32,
    };
#elif BUSTER_CPU_ARCH_AARCH64
    u32 answer_instructions[] = {
        0x52800540,
        0xd65f03c0,
    };
    u32 main_instructions[] = {
        0xa9bf7bfd, 0x910003fd, 0x94000000, 0x5100a800, 0xa8c17bfd, 0xd65f03c0,
    };
    ByteSlice answer_bytes = {
        .pointer = (u8*)answer_instructions,
        .length = sizeof(answer_instructions),
    };
    ByteSlice main_bytes = {
        .pointer = (u8*)main_instructions,
        .length = sizeof(main_instructions),
    };
    ObjectRelocation main_relocation = {
        .offset = 8,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_AARCH64_CALL26,
    };
#endif
#if BUSTER_CPU_ARCH_X86_64 || BUSTER_CPU_ARCH_AARCH64
    ObjectSymbol answer_symbols[] = {
        {
            .name = S8("answer"),
            .size = answer_bytes.length,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectSymbol main_symbols[] = {
        {
            .name = S8("main"),
            .size = main_bytes.length,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("answer"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectFile objects[] = {
        link_test_object_make(arguments->arena, target, answer_bytes, answer_symbols, BUSTER_ARRAY_LENGTH(answer_symbols), 0, 0),
        link_test_object_make(arguments->arena, target, main_bytes, main_symbols, BUSTER_ARRAY_LENGTH(main_symbols), &main_relocation, 1),
    };
#if BUSTER_LINUX
    CodegenUnwindAction main_unwind_actions[4] = {0};
    u32 main_unwind_action_count = 0;
#if BUSTER_CPU_ARCH_AARCH64
    main_unwind_actions[0] = (CodegenUnwindAction){.code_offset = 4, .value = 16, .kind = CODEGEN_UNWIND_ACTION_ALLOCATE_STACK};
    main_unwind_actions[1] = (CodegenUnwindAction){.code_offset = 4, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 29};
    main_unwind_actions[2] = (CodegenUnwindAction){.code_offset = 4, .value = 8, .kind = CODEGEN_UNWIND_ACTION_SAVE_REGISTER, .register_index = 30};
    main_unwind_actions[3] = (CodegenUnwindAction){.code_offset = 8, .kind = CODEGEN_UNWIND_ACTION_SET_FRAME_POINTER, .register_index = 29};
    main_unwind_action_count = BUSTER_ARRAY_LENGTH(main_unwind_actions);
#endif
    CodegenFunctionDescriptor answer_descriptor = {
        .code_size = (u32)answer_bytes.length,
    };
    CodegenFunctionDescriptor main_descriptor = {
        .unwind_actions = main_unwind_actions,
        .code_size = (u32)main_bytes.length,
        .prolog_size = main_unwind_action_count ? 8 : 0,
        .unwind_action_count = main_unwind_action_count,
    };
    DwarfCfiResult answer_cfi = dwarf_cfi_build(arguments->arena, (DwarfCfiInput){
                                                                      .functions = &answer_descriptor,
                                                                      .target = target,
                                                                      .function_count = 1,
                                                                  });
    DwarfCfiResult main_cfi = dwarf_cfi_build(arguments->arena, (DwarfCfiInput){
                                                                    .functions = &main_descriptor,
                                                                    .target = target,
                                                                    .function_count = 1,
                                                                });
    BUSTER_TEST(arguments, answer_cfi.valid && answer_cfi.relocation_count == 1);
    BUSTER_TEST(arguments, main_cfi.valid && main_cfi.relocation_count == 1);
    ObjectRelocation answer_relocation = {
        .offset = answer_cfi.relocations[0].offset,
        .section = OBJECT_SECTION_UNWIND,
        .symbol = 0,
        .kind = target.cpu_arch == CPU_ARCH_X86_64 ? OBJECT_RELOCATION_X86_64_PC32 : OBJECT_RELOCATION_AARCH64_PREL32,
    };
    ObjectRelocation main_relocations[] = {
        main_relocation,
        {
            .offset = main_cfi.relocations[0].offset,
            .section = OBJECT_SECTION_UNWIND,
            .symbol = 0,
            .kind = target.cpu_arch == CPU_ARCH_X86_64 ? OBJECT_RELOCATION_X86_64_PC32 : OBJECT_RELOCATION_AARCH64_PREL32,
        },
    };
    ObjectFile cfi_objects[] = {
        link_test_object_make(arguments->arena, target, answer_bytes, answer_symbols, BUSTER_ARRAY_LENGTH(answer_symbols), &answer_relocation, 1),
        link_test_object_make(arguments->arena, target, main_bytes, main_symbols, BUSTER_ARRAY_LENGTH(main_symbols), main_relocations,
                              BUSTER_ARRAY_LENGTH(main_relocations)),
    };
    cfi_objects[0].sections[OBJECT_SECTION_UNWIND].data = answer_cfi.bytes;
    cfi_objects[1].sections[OBJECT_SECTION_UNWIND].data = main_cfi.bytes;
    LinkObjectResult cfi_linked = link_objects(arguments->arena, cfi_objects, BUSTER_ARRAY_LENGTH(cfi_objects), (LinkOptions){0});
    BUSTER_TEST(arguments, cfi_linked.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, cfi_linked.object.relocation_count == 3);
    BUSTER_TEST(arguments, cfi_linked.object.sections[OBJECT_SECTION_UNWIND].data.length == answer_cfi.bytes.length + main_cfi.bytes.length);

    Target a64_elf_target = {
        .cpu_arch = CPU_ARCH_AARCH64,
        .os = OPERATING_SYSTEM_LINUX,
    };
    u32 a64_return = 0xd65f03c0;
    ObjectSymbol a64_main_symbol = {
        .name = S8("main"),
        .size = sizeof(a64_return),
        .section = OBJECT_SECTION_TEXT,
        .kind = OBJECT_SYMBOL_FUNCTION,
        .global = true,
    };
    CodegenFunctionDescriptor a64_descriptor = {
        .code_size = sizeof(a64_return),
    };
    DwarfCfiResult a64_cfi = dwarf_cfi_build(arguments->arena, (DwarfCfiInput){
                                                                    .functions = &a64_descriptor,
                                                                    .target = a64_elf_target,
                                                                    .function_count = 1,
                                                                });
    BUSTER_TEST(arguments, a64_cfi.valid && a64_cfi.relocation_count == 1);
    ObjectRelocation a64_cfi_relocation = {
        .offset = a64_cfi.relocations[0].offset,
        .section = OBJECT_SECTION_UNWIND,
        .symbol = 0,
        .kind = OBJECT_RELOCATION_AARCH64_PREL32,
    };
    ObjectFile a64_elf_object = link_test_object_make(arguments->arena, a64_elf_target,
                                                      (ByteSlice){
                                                          .pointer = (u8*)&a64_return,
                                                          .length = sizeof(a64_return),
                                                      },
                                                      &a64_main_symbol, 1, &a64_cfi_relocation, 1);
    a64_elf_object.sections[OBJECT_SECTION_UNWIND].data = a64_cfi.bytes;
    NativeExecutableLinkResult a64_elf_executable = link_native_executable(arguments->arena, &a64_elf_object,
                                                                           (NativeExecutableLinkOptions){
                                                                               .entry_symbol = S8("main"),
                                                                           });
    BUSTER_TEST(arguments, a64_elf_executable.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, a64_elf_executable.executable.length >= 64);
    if (a64_elf_executable.error == LINK_ERROR_NONE)
    {
        u32 a64_header_index = 0;
        u64 a64_header = 0;
        BUSTER_TEST(arguments, a64_elf_executable.executable.pointer[18] == 183 && a64_elf_executable.executable.pointer[19] == 0);
        BUSTER_TEST(arguments, link_test_elf_section_find(a64_elf_executable.executable, S8(".eh_frame_hdr"), &a64_header_index, &a64_header));
    }

    Target a64_pe_target = {
        .cpu_arch = CPU_ARCH_AARCH64,
        .os = OPERATING_SYSTEM_WINDOWS,
    };
    u32 a64_pe_code[] = {
        0xa9bf7bfd,
        0x910003fd,
        0xa8c17bfd,
        0xd65f03c0,
    };
    u8 a64_pe_pdata[8] = {0};
    u8 a64_pe_xdata[] = {
        0x04, 0x00, 0x40, 0x08, 0x02, 0x00, 0x40, 0x00, 0xe1, 0x81, 0xe4, 0x00,
    };
    ObjectSymbol a64_pe_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(a64_pe_code),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8(".La64_xdata"),
            .size = sizeof(a64_pe_xdata),
            .section = OBJECT_SECTION_WINDOWS_XDATA,
            .kind = OBJECT_SYMBOL_DATA,
        },
    };
    ObjectRelocation a64_pe_relocations[] = {
        {
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        },
        {
            .offset = 4,
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        },
    };
    ObjectFile a64_pe_object = link_test_object_make(arguments->arena, a64_pe_target,
                                                     (ByteSlice){
                                                         .pointer = (u8*)a64_pe_code,
                                                         .length = sizeof(a64_pe_code),
                                                     },
                                                     a64_pe_symbols, BUSTER_ARRAY_LENGTH(a64_pe_symbols), a64_pe_relocations,
                                                     BUSTER_ARRAY_LENGTH(a64_pe_relocations));
    a64_pe_object.sections[OBJECT_SECTION_WINDOWS_PDATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(a64_pe_pdata);
    a64_pe_object.sections[OBJECT_SECTION_WINDOWS_PDATA].virtual_size = sizeof(a64_pe_pdata);
    a64_pe_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(a64_pe_xdata);
    a64_pe_object.sections[OBJECT_SECTION_WINDOWS_XDATA].virtual_size = sizeof(a64_pe_xdata);
    NativeExecutableLinkResult a64_pe_executable = link_native_executable(arguments->arena, &a64_pe_object,
                                                                          (NativeExecutableLinkOptions){
                                                                              .entry_symbol = S8("main"),
                                                                          });
    BUSTER_TEST(arguments, a64_pe_executable.error == LINK_ERROR_NONE);
    u32 a64_pdata_rva = 0;
    u32 a64_pdata_raw = 0;
    u32 a64_xdata_rva = 0;
    u32 a64_xdata_raw = 0;
    BUSTER_TEST(arguments, link_test_pe_section_find(a64_pe_executable.executable, S8(".pdata"), &a64_pdata_rva, &a64_pdata_raw));
    BUSTER_TEST(arguments, link_test_pe_section_find(a64_pe_executable.executable, S8(".xdata"), &a64_xdata_rva, &a64_xdata_raw));
    BUSTER_TEST(arguments, a64_pe_executable.executable.length > 0x128 && link_read_u32(a64_pe_executable.executable.pointer, 0x120) == a64_pdata_rva &&
                               link_read_u32(a64_pe_executable.executable.pointer, 0x124) == 16);
    BUSTER_TEST(arguments, link_test_pe_import_matches(a64_pe_executable.executable, S8("ucrtbase.dll"), S8("_configure_narrow_argv")));
    BUSTER_TEST(arguments, link_test_pe_import_matches(a64_pe_executable.executable, S8("ucrtbase.dll"), S8("__p___argc")));
    BUSTER_TEST(arguments, link_test_pe_import_matches(a64_pe_executable.executable, S8("ucrtbase.dll"), S8("__p___argv")));
    if (a64_pdata_raw <= a64_pe_executable.executable.length && 16 <= a64_pe_executable.executable.length - a64_pdata_raw)
    {
        BUSTER_TEST(arguments, link_read_u32(a64_pe_executable.executable.pointer, a64_pdata_raw + 4) == a64_xdata_rva);
        BUSTER_TEST(arguments, link_read_u32(a64_pe_executable.executable.pointer, a64_pdata_raw + 12) == a64_xdata_rva + 8);
    }
    if (a64_xdata_raw <= a64_pe_executable.executable.length && 8 <= a64_pe_executable.executable.length - a64_xdata_raw)
    {
        BUSTER_TEST(arguments, link_read_u32(a64_pe_executable.executable.pointer, a64_xdata_raw) == (12u | (1u << 27)));
        BUSTER_TEST(arguments, a64_pe_executable.executable.pointer[a64_xdata_raw + 4] == 0x81 &&
                                   a64_pe_executable.executable.pointer[a64_xdata_raw + 5] == 0xcc &&
                                   a64_pe_executable.executable.pointer[a64_xdata_raw + 6] == 0x01 &&
                                   a64_pe_executable.executable.pointer[a64_xdata_raw + 7] == 0xe4);
    }
    {
        u32 page_code[] = {
            0x90000008, // adrp x8, target
            0x91000100, // add x0, x8, :lo12:target
            0x52800000, // mov w0, #0
            0xd65f03c0, // ret
        };
        u8 page_data[8192] = {0};
        u8 page_marker[] = {0x71, 0x4b, 0x29, 0xd3, 0x5e, 0x86, 0xa1, 0x0c};
        memcpy(page_data + 4093, page_marker, sizeof(page_marker));
        ObjectSymbol page_symbols[] = {
            {.name = S8("main"), .size = sizeof(page_code), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
            {.name = S8("page_data"), .value = 4093, .size = sizeof(page_marker), .section = OBJECT_SECTION_DATA, .kind = OBJECT_SYMBOL_DATA},
        };
        ObjectRelocation page_relocations[] = {
            {.addend = 0x7000, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21},
            {.addend = 7, .offset = 4, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A},
        };
        ByteSlice page_code_bytes = {.pointer = (u8*)page_code, .length = sizeof(page_code)};
        ObjectFile page_object = link_test_object_make(arguments->arena, a64_pe_target, page_code_bytes, page_symbols,
                                                       BUSTER_ARRAY_LENGTH(page_symbols), page_relocations, BUSTER_ARRAY_LENGTH(page_relocations));
        page_object.sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(page_data);
        page_object.sections[OBJECT_SECTION_DATA].virtual_size = sizeof(page_data);
        NativeExecutableLinkResult page_linked = link_native_executable(arguments->arena, &page_object,
                                                                        (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
        BUSTER_TEST(arguments, page_linked.error == LINK_ERROR_NONE);
        u32 text_rva = 0;
        u32 text_raw = 0;
        u32 data_rva = 0;
        u32 data_raw = 0;
        bool sections_found = page_linked.error == LINK_ERROR_NONE &&
                              link_test_pe_section_find(page_linked.executable, S8(".text"), &text_rva, &text_raw) &&
                              link_test_pe_section_find(page_linked.executable, S8(".data"), &data_rva, &data_raw);
        BUSTER_TEST(arguments, sections_found);
        if (sections_found)
        {
            u32 code_raw = UINT32_MAX;
            for (u32 offset = text_raw; offset + 16 <= page_linked.executable.length; offset += 4)
            {
                u32 candidate_page = link_read_u32(page_linked.executable.pointer, offset);
                u32 candidate_low = link_read_u32(page_linked.executable.pointer, offset + 4);
                if ((candidate_page & UINT32_C(0x9f00001f)) == UINT32_C(0x90000008) &&
                    (candidate_low & UINT32_C(0xffc003ff)) == UINT32_C(0x91000100) &&
                    link_read_u32(page_linked.executable.pointer, offset + 8) == UINT32_C(0x52800000) &&
                    link_read_u32(page_linked.executable.pointer, offset + 12) == UINT32_C(0xd65f03c0))
                {
                    code_raw = offset;
                    break;
                }
            }
            BUSTER_TEST(arguments, code_raw != UINT32_MAX);
            u32 page_word = code_raw != UINT32_MAX ? link_read_u32(page_linked.executable.pointer, code_raw) : 0;
            u32 low_word = code_raw != UINT32_MAX ? link_read_u32(page_linked.executable.pointer, code_raw + 4) : 0;
            A64MCInst page_instruction = {0};
            u32 low = 0;
            bool decoded = a64_mc_decode(page_word, &page_instruction) && page_instruction.opcode == A64_OPCODE_ADRP &&
                           a64_add_lo12_read(low_word, &low);
            BUSTER_TEST(arguments, decoded);
            if (decoded)
            {
                u64 place_rva = (u64)text_rva + code_raw - text_raw;
                u64 actual = (place_rva & ~UINT64_C(0xfff)) + (u64)page_instruction.operands[1].value + low;
                String8 data_contents = {(char8*)page_linked.executable.pointer + data_raw, page_linked.executable.length - data_raw};
                String8 marker = {(char8*)page_marker, sizeof(page_marker)};
                u64 marker_raw = string_first_sequence(data_contents, marker);
                BUSTER_TEST(arguments, marker_raw != BUSTER_STRING_NO_MATCH);
                if (marker_raw != BUSTER_STRING_NO_MATCH)
                {
                    u64 target_address = (u64)data_rva + marker_raw;
                    u64 expected = ((target_address + 0x7000) & ~UINT64_C(0xfff)) + ((target_address + 7) & UINT64_C(0xfff));
                    BUSTER_TEST(arguments, actual == expected);
                    BUSTER_TEST(arguments, (page_word & 31) == 8 && (low_word & 31) == 0 && ((low_word >> 5) & 31) == 8 &&
                                               low == (((u64)data_rva + marker_raw + 7) & A64_IMM12_MAX));
                }
            }
        }

        u32 helper_word = 0;
        BUSTER_TEST(arguments,
                    !object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21, UINT32_C(0x90000008), 0x1000,
                                                      UINT64_C(0x100001000), 0, &helper_word));
        BUSTER_TEST(arguments,
                    !object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21, UINT32_C(0x90000008), 1, 0x1000, 0,
                                                      &helper_word));
        BUSTER_TEST(arguments,
                    object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21, UINT32_C(0x90000008), 0x1000, 0x2fff, 1,
                                                     &helper_word));
        BUSTER_TEST(arguments,
                    !object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A, UINT32_C(0x91000100), 0, 0, -1,
                                                      &helper_word));
        BUSTER_TEST(arguments,
                    object_aarch64_pe_page_relocate(OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12A, UINT32_C(0x91000100), 0, 0xfff, 1,
                                                     &helper_word) &&
                        a64_add_lo12_read(helper_word, &text_rva) && text_rva == 0);

        page_code[1] = UINT32_C(0x91400100);
        String8 failed_output = link_test_temporary_executable_path(arguments->arena, S8("buster-arm64-page-failure"), S8(".exe"));
        String8 sentinel_text = S8("existing output survives ARM64 relocation failure");
        ByteSlice sentinel = {.pointer = (u8*)sentinel_text.pointer, .length = sentinel_text.length};
        BUSTER_TEST(arguments, file_write(failed_output, sentinel));
        NativeExecutableLinkResult malformed = link_native_executable(arguments->arena, &page_object,
                                                                       (NativeExecutableLinkOptions){
                                                                           .output_path = failed_output,
                                                                           .entry_symbol = S8("main"),
                                                                       });
        BUSTER_TEST(arguments, malformed.error == LINK_ERROR_RELOCATION && !malformed.executable.length);
        ByteSlice retained = file_read(arguments->arena, failed_output, (FileReadOptions){0});
        BUSTER_TEST(arguments, retained.length == sentinel.length && memory_compare(retained.pointer, sentinel.pointer, sentinel.length));
        page_code[1] = UINT32_C(0x91000100);
        page_symbols[1].section = OBJECT_SECTION_UNDEFINED;
        page_symbols[1].global = true;
        NativeExecutableLinkResult undefined = link_native_executable(arguments->arena, &page_object,
                                                                       (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
        BUSTER_TEST(arguments, undefined.error == LINK_ERROR_RELOCATION && !undefined.executable.length);

        u32 load_code[] = {UINT32_C(0x90000009), UINT32_C(0xfd400123), UINT32_C(0x9000000a), UINT32_C(0x3d800144),
                           UINT32_C(0x9000000b), UINT32_C(0xf9800160), UINT32_C(0xd65f03c0)};
        u8 load_data[4096] = {0};
        u8 load_marker[] = {0xc3, 0x28, 0x7a, 0x4f, 0x95, 0xe1, 0x06, 0xbd, 0x37, 0x62, 0xaa, 0x18, 0x40, 0xd9, 0x5e, 0xf1};
        memcpy(load_data + 4080, load_marker, sizeof(load_marker));
        ObjectSymbol load_symbols[] = {
            {.name = S8("main"), .size = sizeof(load_code), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
            {.name = S8("load_data"), .value = 4080, .size = sizeof(load_marker), .section = OBJECT_SECTION_DATA, .kind = OBJECT_SYMBOL_DATA},
        };
        ObjectRelocation load_relocations[] = {
            {.section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21},
            {.offset = 4, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L},
            {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21},
            {.offset = 12, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L},
            {.offset = 16, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEBASE_REL21},
            {.offset = 20, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_PAGEOFFSET_12L},
        };
        ObjectFile load_object = link_test_object_make(arguments->arena, a64_pe_target,
                                                       (ByteSlice){.pointer = (u8*)load_code, .length = sizeof(load_code)}, load_symbols,
                                                       BUSTER_ARRAY_LENGTH(load_symbols), load_relocations, BUSTER_ARRAY_LENGTH(load_relocations));
        load_object.sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(load_data);
        load_object.sections[OBJECT_SECTION_DATA].virtual_size = sizeof(load_data);
        String8 load_output = link_test_temporary_executable_path(arguments->arena, S8("buster-arm64-page-load"), S8(".exe"));
        NativeExecutableLinkOptions load_options = {.output_path = load_output, .entry_symbol = S8("main")};
        NativeExecutableLinkResult load_linked = link_native_executable(arguments->arena, &load_object, load_options);
        u32 load_text_rva = 0;
        u32 load_text_raw = 0;
        u32 load_data_rva = 0;
        u32 load_data_raw = 0;
        bool load_sections = load_linked.error == LINK_ERROR_NONE &&
                             link_test_pe_section_find(load_linked.executable, S8(".text"), &load_text_rva, &load_text_raw) &&
                             link_test_pe_section_find(load_linked.executable, S8(".data"), &load_data_rva, &load_data_raw);
        BUSTER_TEST(arguments, load_sections);
        if (load_sections)
        {
            u32 code_raw = UINT32_MAX;
            for (u32 offset = load_text_raw; offset + 28 <= load_linked.executable.length; offset += 4)
            {
                u32 candidate_load_page = link_read_u32(load_linked.executable.pointer, offset);
                u32 candidate_load = link_read_u32(load_linked.executable.pointer, offset + 4);
                u32 candidate_store_page = link_read_u32(load_linked.executable.pointer, offset + 8);
                u32 candidate_store = link_read_u32(load_linked.executable.pointer, offset + 12);
                u32 candidate_prefetch_page = link_read_u32(load_linked.executable.pointer, offset + 16);
                u32 candidate_prefetch = link_read_u32(load_linked.executable.pointer, offset + 20);
                if ((candidate_load_page & UINT32_C(0x9f00001f)) == UINT32_C(0x90000009) &&
                    (candidate_load & ~(A64_IMM12_MAX << 10)) == UINT32_C(0xfd400123) &&
                    (candidate_store_page & UINT32_C(0x9f00001f)) == UINT32_C(0x9000000a) &&
                    (candidate_store & ~(A64_IMM12_MAX << 10)) == UINT32_C(0x3d800144) &&
                    (candidate_prefetch_page & UINT32_C(0x9f00001f)) == UINT32_C(0x9000000b) &&
                    (candidate_prefetch & ~(A64_IMM12_MAX << 10)) == UINT32_C(0xf9800160) &&
                    link_read_u32(load_linked.executable.pointer, offset + 24) == UINT32_C(0xd65f03c0))
                {
                    code_raw = offset;
                    break;
                }
            }
            BUSTER_TEST(arguments, code_raw != UINT32_MAX);
            A64MCInst load_page = {0};
            A64MCInst store_page = {0};
            A64MCInst prefetch_page = {0};
            u32 load_word = code_raw != UINT32_MAX ? link_read_u32(load_linked.executable.pointer, code_raw + 4) : 0;
            u32 store_word = code_raw != UINT32_MAX ? link_read_u32(load_linked.executable.pointer, code_raw + 12) : 0;
            u32 prefetch_word = code_raw != UINT32_MAX ? link_read_u32(load_linked.executable.pointer, code_raw + 20) : 0;
            String8 load_contents = {(char8*)load_linked.executable.pointer + load_data_raw, load_linked.executable.length - load_data_raw};
            u64 marker_raw = string_first_sequence(load_contents, (String8){(char8*)load_marker, sizeof(load_marker)});
            bool load_page_decoded = code_raw != UINT32_MAX && a64_mc_decode(link_read_u32(load_linked.executable.pointer, code_raw), &load_page) &&
                                     load_page.opcode == A64_OPCODE_ADRP;
            bool store_page_decoded = code_raw != UINT32_MAX && a64_mc_decode(link_read_u32(load_linked.executable.pointer, code_raw + 8), &store_page) &&
                                      store_page.opcode == A64_OPCODE_ADRP;
            bool prefetch_page_decoded = code_raw != UINT32_MAX &&
                                         a64_mc_decode(link_read_u32(load_linked.executable.pointer, code_raw + 16), &prefetch_page) &&
                                         prefetch_page.opcode == A64_OPCODE_ADRP;
            bool marker_found = marker_raw != BUSTER_STRING_NO_MATCH;
            bool load_decoded = load_page_decoded && store_page_decoded && prefetch_page_decoded && marker_found;
            BUSTER_TEST(arguments, load_page_decoded);
            BUSTER_TEST(arguments, store_page_decoded);
            BUSTER_TEST(arguments, prefetch_page_decoded);
            BUSTER_TEST(arguments, marker_found);
            BUSTER_TEST(arguments, load_decoded);
            if (load_decoded)
            {
                u64 load_place_rva = (u64)load_text_rva + code_raw - load_text_raw;
                u64 store_place_rva = load_place_rva + 8;
                u64 prefetch_place_rva = load_place_rva + 16;
                u64 actual = (load_place_rva & ~UINT64_C(0xfff)) + (u64)load_page.operands[1].value +
                             (((load_word >> 10) & A64_IMM12_MAX) << 3);
                u64 store_actual = (store_place_rva & ~UINT64_C(0xfff)) + (u64)store_page.operands[1].value +
                                   (((store_word >> 10) & A64_IMM12_MAX) << 4);
                u64 prefetch_actual = (prefetch_place_rva & ~UINT64_C(0xfff)) + (u64)prefetch_page.operands[1].value +
                                      (((prefetch_word >> 10) & A64_IMM12_MAX) << 3);
                BUSTER_TEST(arguments, actual == (u64)load_data_rva + marker_raw &&
                                           store_actual == (u64)load_data_rva + marker_raw &&
                                           prefetch_actual == (u64)load_data_rva + marker_raw &&
                                           (load_word & ~(A64_IMM12_MAX << 10)) == UINT32_C(0xfd400123) &&
                                           (store_word & ~(A64_IMM12_MAX << 10)) == UINT32_C(0x3d800144) &&
                                           (prefetch_word & ~(A64_IMM12_MAX << 10)) == UINT32_C(0xf9800160));
            }
        }
        load_code[1] = UINT32_C(0xfc400123);
        ByteSlice load_sentinel = BUSTER_SLICE_TO_BYTE_SLICE(S8("existing output survives malformed PAGEOFFSET_12L"));
        BUSTER_TEST(arguments, file_write(load_output, load_sentinel));
        NativeExecutableLinkResult malformed_load = link_native_executable(arguments->arena, &load_object, load_options);
        ByteSlice retained_load = file_read(arguments->arena, load_output, (FileReadOptions){0});
        BUSTER_TEST(arguments, malformed_load.error == LINK_ERROR_RELOCATION && !malformed_load.executable.length &&
                                   retained_load.length == load_sentinel.length &&
                                   memory_compare(retained_load.pointer, load_sentinel.pointer, load_sentinel.length));
        load_code[1] = UINT32_C(0xfd400123);
        load_symbols[1].value = 4081;
        malformed_load = link_native_executable(arguments->arena, &load_object, load_options);
        BUSTER_TEST(arguments, malformed_load.error == LINK_ERROR_RELOCATION && !malformed_load.executable.length);
        load_symbols[1].value = 4080;
        load_symbols[1].section = OBJECT_SECTION_UNDEFINED;
        load_symbols[1].global = true;
        malformed_load = link_native_executable(arguments->arena, &load_object, load_options);
        BUSTER_TEST(arguments, malformed_load.error == LINK_ERROR_RELOCATION && !malformed_load.executable.length);

        u32 tls_code[] = {
            UINT32_C(0x90000009), UINT32_C(0xb9400129), UINT32_C(0xf9402e4a), UINT32_C(0xf8697949),
            UINT32_C(0x91000129), UINT32_C(0x52800000), UINT32_C(0xd65f03c0),
        };
        u32 tls_value = 1;
        ObjectSymbol tls_symbols[] = {
            {.name = S8("main"), .size = sizeof(tls_code), .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
            {.name = S8("tls_value"), .size = sizeof(tls_value), .section = OBJECT_SECTION_THREAD_LOCAL_DATA, .kind = OBJECT_SYMBOL_DATA, .global = true},
        };
        ObjectRelocation tls_relocations[] = {
            {.section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_ADRP},
            {.offset = 4, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_TLS_INDEX_LO12},
            {.offset = 16, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PE_TLS_OFFSET12},
        };
        ByteSlice tls_code_bytes = {.pointer = (u8*)tls_code, .length = sizeof(tls_code)};
        ObjectFile tls_object = link_test_object_make(arguments->arena, a64_pe_target, tls_code_bytes, tls_symbols, BUSTER_ARRAY_LENGTH(tls_symbols),
                                                      tls_relocations, BUSTER_ARRAY_LENGTH(tls_relocations));
        tls_object.sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data = (ByteSlice){.pointer = (u8*)&tls_value, .length = sizeof(tls_value)};
        tls_object.sections[OBJECT_SECTION_THREAD_LOCAL_DATA].virtual_size = sizeof(tls_value);
        ObjectArtifact tls_artifact = object_write(arguments->arena, &tls_object, OBJECT_FORMAT_COFF);
        ObjectFile tls_roundtrip = object_read(arguments->arena, tls_artifact.bytes, a64_pe_target);
        bool tls_bound = tls_artifact.error == OBJECT_ERROR_NONE && tls_roundtrip.error == OBJECT_ERROR_NONE &&
                         tls_roundtrip.relocation_count == 3 &&
                         string_equal(tls_roundtrip.symbols[tls_roundtrip.relocations[0].symbol].name, S8("__tls_index")) &&
                         string_equal(tls_roundtrip.symbols[tls_roundtrip.relocations[1].symbol].name, S8("__tls_index")) &&
                         string_equal(tls_roundtrip.symbols[tls_roundtrip.relocations[2].symbol].name, S8("tls_value"));
        BUSTER_TEST(arguments, tls_bound);
        if (tls_bound)
        {
            NativeExecutableLinkResult tls_linked = link_native_executable(arguments->arena, &tls_roundtrip,
                                                                            (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
            BUSTER_TEST(arguments, tls_linked.error == LINK_ERROR_NONE && tls_linked.executable.length);
        }
    }
#endif
    LinkObjectResult linked = link_objects(arguments->arena, objects, BUSTER_ARRAY_LENGTH(objects), (LinkOptions){0});
    BUSTER_TEST(arguments, linked.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, linked.object.symbol_count == 2);
    BUSTER_TEST(arguments, linked.object.relocation_count == 1);
    bool linked_text_size_matches = false;
    if (linked.object.sections && linked.object.section_count > OBJECT_SECTION_TEXT)
    {
        linked_text_size_matches = linked.object.sections[OBJECT_SECTION_TEXT].data.length == align_forward(answer_bytes.length, 16) + main_bytes.length;
    }
    BUSTER_TEST(arguments, linked_text_size_matches);
    ObjectFile duplicate_objects[] = {
        objects[0],
        objects[0],
    };
    LinkObjectResult duplicate = link_objects(arguments->arena, duplicate_objects, BUSTER_ARRAY_LENGTH(duplicate_objects), (LinkOptions){0});
    BUSTER_TEST(arguments, duplicate.error == LINK_ERROR_DUPLICATE_SYMBOL);
    BUSTER_STRING_TEST(arguments, duplicate.symbol, S8("answer"));
    ObjectFile unresolved_object = objects[1];
    LinkObjectResult unresolved = link_objects(arguments->arena, &unresolved_object, 1, (LinkOptions){0});
    BUSTER_TEST(arguments, unresolved.error == LINK_ERROR_UNRESOLVED_SYMBOL);
    BUSTER_STRING_TEST(arguments, unresolved.symbol, S8("answer"));
    LinkObjectResult permitted = link_objects(arguments->arena, &unresolved_object, 1,
                                              (LinkOptions){
                                                  .allow_undefined_symbols = true,
                                              });
    BUSTER_TEST(arguments, permitted.error == LINK_ERROR_NONE);
#if BUSTER_CPU_ARCH_X86_64
    // The hosted Windows runtime supplies compiler marker data that UCRT does
    // not export.  Keep it in the executable-link input policy: a weak
    // definition resolves Clang objects, yields to an application/CRT strong
    // definition, and does not hide any unrelated unresolved symbol.
    Target windows_runtime_target = linked.object.target;
    windows_runtime_target.os = OPERATING_SYSTEM_WINDOWS;
    windows_runtime_target.cpu_arch = CPU_ARCH_X86_64;
    ObjectFile windows_runtime = link_windows_runtime_object(arguments->arena, windows_runtime_target);
    BUSTER_TEST(arguments, windows_runtime.error == OBJECT_ERROR_NONE);
    BUSTER_TEST(arguments, windows_runtime.symbol_count == 1 && windows_runtime.symbols && windows_runtime.symbols[0].weak &&
                               string_equal(windows_runtime.symbols[0].name, S8("_fltused")) &&
                               windows_runtime.symbols[0].section == OBJECT_SECTION_DATA && windows_runtime.sections[OBJECT_SECTION_DATA].data.length == sizeof(u32));
    Target windows_runtime_linux_target = windows_runtime_target;
    windows_runtime_linux_target.os = OPERATING_SYSTEM_LINUX;
    ObjectFile windows_runtime_linux = link_windows_runtime_object(arguments->arena, windows_runtime_linux_target);
    BUSTER_TEST(arguments, windows_runtime_linux.error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    Target windows_runtime_uefi_target = windows_runtime_target;
    windows_runtime_uefi_target.os = OPERATING_SYSTEM_UEFI;
    ObjectFile windows_runtime_uefi = link_windows_runtime_object(arguments->arena, windows_runtime_uefi_target);
    BUSTER_TEST(arguments, windows_runtime_uefi.error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    u8 windows_runtime_text_bytes[] = {0xc3};
    ObjectSymbol windows_runtime_undefined_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(windows_runtime_text_bytes),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("_fltused"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectFile windows_runtime_undefined =
        link_test_object_make(arguments->arena, windows_runtime_target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_runtime_text_bytes),
                              windows_runtime_undefined_symbols, BUSTER_ARRAY_LENGTH(windows_runtime_undefined_symbols), 0, 0);
    ObjectFile windows_runtime_inputs[] = {windows_runtime_undefined, windows_runtime};
    LinkObjectResult windows_runtime_link = link_objects(arguments->arena, windows_runtime_inputs, BUSTER_ARRAY_LENGTH(windows_runtime_inputs), (LinkOptions){0});
    BUSTER_TEST(arguments, windows_runtime_link.error == LINK_ERROR_NONE);
    u32 windows_runtime_symbol_index = link_test_symbol_find(&windows_runtime_link.object, S8("_fltused"));
    BUSTER_TEST(arguments, windows_runtime_symbol_index != UINT32_MAX && windows_runtime_link.object.symbols[windows_runtime_symbol_index].section == OBJECT_SECTION_DATA &&
                               windows_runtime_link.object.symbols[windows_runtime_symbol_index].weak);
    u8 windows_runtime_strong_data[] = {7, 0, 0, 0};
    ObjectSection* windows_runtime_strong_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
    memcpy(windows_runtime_strong_sections, windows_runtime_undefined.sections, (u64)OBJECT_SECTION_COUNT * sizeof(*windows_runtime_strong_sections));
    windows_runtime_strong_sections[OBJECT_SECTION_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_runtime_strong_data);
    windows_runtime_strong_sections[OBJECT_SECTION_DATA].virtual_size = sizeof(windows_runtime_strong_data);
    ObjectSymbol windows_runtime_strong_symbols[] = {
        windows_runtime_undefined_symbols[0],
        {
            .name = S8("_fltused"),
            .size = sizeof(windows_runtime_strong_data),
            .section = OBJECT_SECTION_DATA,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectFile windows_runtime_strong = windows_runtime_undefined;
    windows_runtime_strong.sections = windows_runtime_strong_sections;
    windows_runtime_strong.symbols = windows_runtime_strong_symbols;
    windows_runtime_strong.symbol_count = BUSTER_ARRAY_LENGTH(windows_runtime_strong_symbols);
    ObjectFile windows_runtime_strong_inputs[] = {windows_runtime_strong, windows_runtime};
    LinkObjectResult windows_runtime_strong_link =
        link_objects(arguments->arena, windows_runtime_strong_inputs, BUSTER_ARRAY_LENGTH(windows_runtime_strong_inputs), (LinkOptions){0});
    BUSTER_TEST(arguments, windows_runtime_strong_link.error == LINK_ERROR_NONE);
    u32 windows_runtime_strong_index = link_test_symbol_find(&windows_runtime_strong_link.object, S8("_fltused"));
    BUSTER_TEST(arguments, windows_runtime_strong_index != UINT32_MAX && windows_runtime_strong_link.object.symbols[windows_runtime_strong_index].section == OBJECT_SECTION_DATA &&
                               !windows_runtime_strong_link.object.symbols[windows_runtime_strong_index].weak &&
                               windows_runtime_strong_link.object.symbols[windows_runtime_strong_index].value == 0);
    ObjectSymbol windows_runtime_missing_symbols[] = {
        windows_runtime_undefined_symbols[0],
        {
            .name = S8("missing_runtime_symbol"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectFile windows_runtime_missing = windows_runtime_undefined;
    windows_runtime_missing.symbols = windows_runtime_missing_symbols;
    ObjectFile windows_runtime_missing_inputs[] = {windows_runtime_missing, windows_runtime};
    LinkObjectResult windows_runtime_missing_link =
        link_objects(arguments->arena, windows_runtime_missing_inputs, BUSTER_ARRAY_LENGTH(windows_runtime_missing_inputs), (LinkOptions){0});
    BUSTER_TEST(arguments, windows_runtime_missing_link.error == LINK_ERROR_UNRESOLVED_SYMBOL);
    BUSTER_STRING_TEST(arguments, windows_runtime_missing_link.symbol, S8("missing_runtime_symbol"));

    // #792: `atexit` and `at_quick_exit` are not ucrtbase.dll exports either
    // -- UCRT keeps them in its import library as one call to `_crt_atexit`
    // and `_crt_at_quick_exit` -- so a PE link resolved them nowhere.  The
    // second Windows runtime object supplies exactly those two names as weak
    // tail branches.  This is the shape both architectures produce; the driver
    // test links and runs it.
    u8 windows_libc_x86_64_text[] = {
        0xe9, 0x00, 0x00, 0x00, 0x00, // jmp rel32 _crt_atexit
        0xe9, 0x00, 0x00, 0x00, 0x00, // jmp rel32 _crt_at_quick_exit
    };
    u8 windows_libc_aarch64_text[] = {
        0x00, 0x00, 0x00, 0x14, // b _crt_atexit
        0x00, 0x00, 0x00, 0x14, // b _crt_at_quick_exit
    };
    String8 windows_libc_stub_names[] = {S8_INITIALIZER("atexit"), S8_INITIALIZER("at_quick_exit")};
    String8 windows_libc_target_names[] = {S8_INITIALIZER("_crt_atexit"), S8_INITIALIZER("_crt_at_quick_exit")};
    Target windows_libc_targets[] = {windows_runtime_target, windows_runtime_target};
    windows_libc_targets[1].cpu_arch = CPU_ARCH_AARCH64;
    for (u32 architecture = 0; architecture < BUSTER_ARRAY_LENGTH(windows_libc_targets); architecture += 1)
    {
        bool architecture_x86_64 = windows_libc_targets[architecture].cpu_arch == CPU_ARCH_X86_64;
        ByteSlice expected_text = architecture_x86_64 ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_libc_x86_64_text)
                                                      : (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_libc_aarch64_text);
        u64 thunk_size = expected_text.length / BUSTER_ARRAY_LENGTH(windows_libc_stub_names);
        ObjectFile windows_libc = link_windows_libc_runtime_object(arguments->arena, windows_libc_targets[architecture]);
        BUSTER_TEST(arguments, windows_libc.error == OBJECT_ERROR_NONE);
        BUSTER_TEST(arguments, windows_libc.symbol_count == 2 * BUSTER_ARRAY_LENGTH(windows_libc_stub_names) &&
                                   windows_libc.relocation_count == BUSTER_ARRAY_LENGTH(windows_libc_stub_names));
        BUSTER_TEST(arguments, windows_libc.sections[OBJECT_SECTION_TEXT].data.length == expected_text.length &&
                                   memcmp(windows_libc.sections[OBJECT_SECTION_TEXT].data.pointer, expected_text.pointer, expected_text.length) == 0);
        for (u32 stub_index = 0; stub_index < BUSTER_ARRAY_LENGTH(windows_libc_stub_names); stub_index += 1)
        {
            ObjectSymbol stub = windows_libc.symbols[stub_index * 2];
            ObjectSymbol imported = windows_libc.symbols[stub_index * 2 + 1];
            ObjectRelocation relocation = windows_libc.relocations[stub_index];
            BUSTER_TEST(arguments, string_equal(stub.name, windows_libc_stub_names[stub_index]) && stub.weak && stub.global &&
                                       stub.section == OBJECT_SECTION_TEXT && stub.kind == OBJECT_SYMBOL_FUNCTION && stub.value == stub_index * thunk_size &&
                                       stub.size == thunk_size);
            BUSTER_TEST(arguments, string_equal(imported.name, windows_libc_target_names[stub_index]) && imported.global && !imported.weak &&
                                       imported.section == OBJECT_SECTION_UNDEFINED && imported.kind == OBJECT_SYMBOL_FUNCTION);
            // The branch is the last instruction of the body: one opcode byte
            // into it on x86-64, the whole word on AArch64.  A PC32 field is
            // measured from its own end, which the -4 addend restores.
            BUSTER_TEST(arguments, relocation.section == OBJECT_SECTION_TEXT && relocation.symbol == stub_index * 2 + 1 &&
                                       relocation.offset == stub_index * thunk_size + (architecture_x86_64 ? 1 : 0) &&
                                       relocation.addend == (architecture_x86_64 ? -4 : 0) &&
                                       relocation.kind == (architecture_x86_64 ? OBJECT_RELOCATION_X86_64_PC32 : OBJECT_RELOCATION_AARCH64_JUMP26));
        }
    }
    Target windows_libc_linux_target = windows_runtime_target;
    windows_libc_linux_target.os = OPERATING_SYSTEM_LINUX;
    BUSTER_TEST(arguments, link_windows_libc_runtime_object(arguments->arena, windows_libc_linux_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    Target windows_libc_uefi_target = windows_runtime_target;
    windows_libc_uefi_target.os = OPERATING_SYSTEM_UEFI;
    BUSTER_TEST(arguments, link_windows_libc_runtime_object(arguments->arena, windows_libc_uefi_target).error == OBJECT_ERROR_UNSUPPORTED_TARGET);
    // The ELF object shares the builder and keeps its own shape: two more
    // instructions ahead of the branch, because `__cxa_atexit` takes the null
    // argument and null DSO handle that `atexit` does not.
    Target elf_libc_target = windows_runtime_target;
    elf_libc_target.os = OPERATING_SYSTEM_LINUX;
    ObjectFile elf_libc = link_elf_libc_runtime_object(arguments->arena, elf_libc_target);
    u8 elf_libc_x86_64_text[] = {
        0x31, 0xf6, 0x31, 0xd2, 0xe9, 0x00, 0x00, 0x00, 0x00, // xor esi, esi; xor edx, edx; jmp rel32 __cxa_atexit
        0x31, 0xf6, 0x31, 0xd2, 0xe9, 0x00, 0x00, 0x00, 0x00, // the same for __cxa_at_quick_exit
    };
    BUSTER_TEST(arguments, elf_libc.error == OBJECT_ERROR_NONE);
    BUSTER_TEST(arguments, elf_libc.sections[OBJECT_SECTION_TEXT].data.length == sizeof(elf_libc_x86_64_text) &&
                               memcmp(elf_libc.sections[OBJECT_SECTION_TEXT].data.pointer, elf_libc_x86_64_text, sizeof(elf_libc_x86_64_text)) == 0);
    BUSTER_TEST(arguments, string_equal(elf_libc.symbols[0].name, S8("atexit")) && elf_libc.symbols[0].weak &&
                               string_equal(elf_libc.symbols[1].name, S8("__cxa_atexit")) && elf_libc.relocations[0].offset == 5 &&
                               elf_libc.relocations[1].offset == 14);
    // A reference resolves to the weak stub, and a program's own definition
    // replaces it -- the two properties the driver's archive-member selection
    // rests on.
    ObjectFile windows_libc_object = link_windows_libc_runtime_object(arguments->arena, windows_runtime_target);
    ObjectSymbol windows_libc_reference_symbols[] = {
        windows_runtime_undefined_symbols[0],
        {
            .name = S8("atexit"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectFile windows_libc_reference =
        link_test_object_make(arguments->arena, windows_runtime_target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(windows_runtime_text_bytes),
                              windows_libc_reference_symbols, BUSTER_ARRAY_LENGTH(windows_libc_reference_symbols), 0, 0);
    ObjectFile windows_libc_reference_inputs[] = {windows_libc_reference, windows_libc_object};
    LinkObjectResult windows_libc_reference_link = link_objects(arguments->arena, windows_libc_reference_inputs,
                                                               BUSTER_ARRAY_LENGTH(windows_libc_reference_inputs),
                                                               (LinkOptions){
                                                                   .allow_undefined_symbols = true,
                                                               });
    BUSTER_TEST(arguments, windows_libc_reference_link.error == LINK_ERROR_NONE);
    u32 windows_libc_reference_index = link_test_symbol_find(&windows_libc_reference_link.object, S8("atexit"));
    BUSTER_TEST(arguments, windows_libc_reference_index != UINT32_MAX &&
                               windows_libc_reference_link.object.symbols[windows_libc_reference_index].section == OBJECT_SECTION_TEXT &&
                               windows_libc_reference_link.object.symbols[windows_libc_reference_index].weak);
    ObjectSymbol windows_libc_own_symbols[] = {
        windows_runtime_undefined_symbols[0],
        {
            .name = S8("atexit"),
            .value = 0,
            .size = sizeof(windows_runtime_text_bytes),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectFile windows_libc_own = windows_libc_reference;
    windows_libc_own.symbols = windows_libc_own_symbols;
    ObjectFile windows_libc_own_inputs[] = {windows_libc_own, windows_libc_object};
    LinkObjectResult windows_libc_own_link = link_objects(arguments->arena, windows_libc_own_inputs, BUSTER_ARRAY_LENGTH(windows_libc_own_inputs),
                                                         (LinkOptions){
                                                             .allow_undefined_symbols = true,
                                                         });
    BUSTER_TEST(arguments, windows_libc_own_link.error == LINK_ERROR_NONE);
    u32 windows_libc_own_index = link_test_symbol_find(&windows_libc_own_link.object, S8("atexit"));
    BUSTER_TEST(arguments, windows_libc_own_index != UINT32_MAX && windows_libc_own_link.object.symbols[windows_libc_own_index].section == OBJECT_SECTION_TEXT &&
                               !windows_libc_own_link.object.symbols[windows_libc_own_index].weak &&
                               windows_libc_own_link.object.symbols[windows_libc_own_index].value == 0);
    ObjectFile windows_object = linked.object;
    windows_object.target.os = OPERATING_SYSTEM_WINDOWS;
    windows_object.sections = arena_allocate(arguments->arena, ObjectSection, linked.object.section_count);
    memcpy(windows_object.sections, linked.object.sections, (u64)linked.object.section_count * sizeof(*windows_object.sections));
    u8 pe_unwind_pdata[12] = {0};
    u8 pe_unwind_xdata[] = {1, 0, 0, 0};
    windows_object.sections[OBJECT_SECTION_WINDOWS_PDATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(pe_unwind_pdata);
    windows_object.sections[OBJECT_SECTION_WINDOWS_PDATA].virtual_size = sizeof(pe_unwind_pdata);
    windows_object.sections[OBJECT_SECTION_WINDOWS_XDATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(pe_unwind_xdata);
    windows_object.sections[OBJECT_SECTION_WINDOWS_XDATA].virtual_size = sizeof(pe_unwind_xdata);
    windows_object.symbols = arena_allocate(arguments->arena, ObjectSymbol, linked.object.symbol_count + 1);
    memcpy(windows_object.symbols, linked.object.symbols, (u64)linked.object.symbol_count * sizeof(*windows_object.symbols));
    u32 pe_main_symbol = UINT32_MAX;
    for (u32 symbol_index = 0; symbol_index < linked.object.symbol_count; symbol_index += 1)
    {
        if (string_equal(windows_object.symbols[symbol_index].name, S8("main")))
        {
            pe_main_symbol = symbol_index;
            break;
        }
    }
    u32 pe_xdata_symbol = windows_object.symbol_count++;
    windows_object.symbols[pe_xdata_symbol] = (ObjectSymbol){
        .name = S8(".Lpe_xdata"),
        .size = sizeof(pe_unwind_xdata),
        .section = OBJECT_SECTION_WINDOWS_XDATA,
        .kind = OBJECT_SYMBOL_DATA,
    };
    windows_object.relocations = arena_allocate(arguments->arena, ObjectRelocation, linked.object.relocation_count + 3);
    memcpy(windows_object.relocations, linked.object.relocations, (u64)linked.object.relocation_count * sizeof(*windows_object.relocations));
    windows_object.relocation_count = linked.object.relocation_count;
    if (pe_main_symbol != UINT32_MAX)
    {
        windows_object.relocations[windows_object.relocation_count++] = (ObjectRelocation){
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .symbol = pe_main_symbol,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        };
        windows_object.relocations[windows_object.relocation_count++] = (ObjectRelocation){
            .addend = (s64)windows_object.symbols[pe_main_symbol].size,
            .offset = 4,
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .symbol = pe_main_symbol,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        };
        windows_object.relocations[windows_object.relocation_count++] = (ObjectRelocation){
            .offset = 8,
            .section = OBJECT_SECTION_WINDOWS_PDATA,
            .symbol = pe_xdata_symbol,
            .kind = OBJECT_RELOCATION_COFF_ADDR32NB,
        };
    }
    BUSTER_TEST(arguments, pe_main_symbol != UINT32_MAX);
    String8 pe_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-link-test"), S8(".exe"));
    NativeExecutableLinkResult pe_executable = link_native_executable(arguments->arena, &windows_object,
                                                                      (NativeExecutableLinkOptions){
                                                                          .output_path = pe_output_path,
                                                                          .entry_symbol = S8("main"),
                                                                      });
    BUSTER_TEST(arguments, pe_executable.error == LINK_ERROR_NONE);
    bool pe_header_valid = pe_executable.executable.length > 0x84 && pe_executable.executable.pointer[0] == 'M' && pe_executable.executable.pointer[1] == 'Z' &&
                           memcmp(pe_executable.executable.pointer + 0x80, "PE\0\0", 4) == 0 && (pe_executable.executable.pointer[0x96] & 0x01) != 0;
    BUSTER_TEST(arguments, pe_header_valid);
    BUSTER_TEST(arguments, pe_executable.executable.length > 0xe8 && link_read_u64(pe_executable.executable.pointer, 0xe0) == LINK_TEST_PE_STACK_RESERVE);
    u32 pe_pdata_rva = 0;
    u32 pe_pdata_raw = 0;
    u32 pe_xdata_rva = 0;
    BUSTER_TEST(arguments, link_test_pe_section_find(pe_executable.executable, S8(".pdata"), &pe_pdata_rva, &pe_pdata_raw));
    BUSTER_TEST(arguments, link_test_pe_section_find(pe_executable.executable, S8(".xdata"), &pe_xdata_rva, 0));
    BUSTER_TEST(arguments, pe_executable.executable.length > 0x128 && link_read_u32(pe_executable.executable.pointer, 0x120) == pe_pdata_rva &&
                               link_read_u32(pe_executable.executable.pointer, 0x124) == sizeof(pe_unwind_pdata) + 12);
    BUSTER_TEST(arguments, pe_pdata_raw <= pe_executable.executable.length && sizeof(pe_unwind_pdata) + 12 <= pe_executable.executable.length - pe_pdata_raw);
    if (pe_pdata_raw <= pe_executable.executable.length && sizeof(pe_unwind_pdata) + 12 <= pe_executable.executable.length - pe_pdata_raw &&
        pe_main_symbol != UINT32_MAX)
    {
        u32 startup_rva = link_read_u32(pe_executable.executable.pointer, pe_pdata_raw);
        u32 startup_end_rva = link_read_u32(pe_executable.executable.pointer, pe_pdata_raw + 4);
        u32 startup_unwind_rva = link_read_u32(pe_executable.executable.pointer, pe_pdata_raw + 8);
        u32 function_rva = link_read_u32(pe_executable.executable.pointer, pe_pdata_raw + 12);
        u32 function_end_rva = link_read_u32(pe_executable.executable.pointer, pe_pdata_raw + 16);
        u32 unwind_rva = link_read_u32(pe_executable.executable.pointer, pe_pdata_raw + 20);
        BUSTER_TEST(arguments, startup_end_rva > startup_rva && startup_unwind_rva == pe_xdata_rva);
        BUSTER_TEST(arguments, function_end_rva - function_rva == windows_object.symbols[pe_main_symbol].size);
        BUSTER_TEST(arguments, unwind_rva == pe_xdata_rva + 8);
    }
    u8 const pe_argv_mode_prefix[] = {
        0x48, 0x83, 0xec, 0x38, 0x31, 0xc9, 0xff, 0xc1,
    };
    bool pe_argv_mode_valid = pe_executable.executable.length >= 0x400 + sizeof(pe_argv_mode_prefix) &&
                              memcmp(pe_executable.executable.pointer + 0x400, pe_argv_mode_prefix, sizeof(pe_argv_mode_prefix)) == 0;
    BUSTER_TEST(arguments, pe_argv_mode_valid);
    u8 pe_libc_main_text[] = {
        0x48, 0x83, 0xec, 0x28, 0xb9, 0xd6, 0xff, 0xff, 0xff, 0xe8, 0, 0, 0, 0, 0x83, 0xe8, 42, 0x48, 0x83, 0xc4, 0x28, 0xc3,
    };
    ObjectSymbol pe_libc_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(pe_libc_main_text),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("abs"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectRelocation pe_libc_relocation = {
        .addend = -4,
        .offset = 10,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_PC32,
    };
    ObjectFile pe_libc_object = link_test_object_make(arguments->arena, windows_object.target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(pe_libc_main_text),
                                                      pe_libc_symbols, BUSTER_ARRAY_LENGTH(pe_libc_symbols), &pe_libc_relocation, 1);
    String8 pe_libc_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-libc-link-test"), S8(".exe"));
    NativeExecutableLinkResult pe_libc_executable = link_native_executable(arguments->arena, &pe_libc_object,
                                                                           (NativeExecutableLinkOptions){
                                                                               .output_path = pe_libc_output_path,
                                                                               .entry_symbol = S8("main"),
                                                                           });
    BUSTER_TEST(arguments, pe_libc_executable.error == LINK_ERROR_NONE);
    String8 external_exports[] = {
        S8("external_value"),
    };
    NativeDynamicLibrary external_library = {
        .name = S8("external.dll"),
        .exported_symbols = external_exports,
        .exported_symbol_count = BUSTER_ARRAY_LENGTH(external_exports),
    };
    pe_libc_symbols[1].name = S8("external_value");
    NativeExecutableLinkResult pe_external_executable = link_native_executable(arguments->arena, &pe_libc_object,
                                                                               (NativeExecutableLinkOptions){
                                                                                   .entry_symbol = S8("main"),
                                                                                   .dynamic_libraries = &external_library,
                                                                                   .dynamic_library_count = 1,
                                                                               });
    BUSTER_TEST(arguments, pe_external_executable.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, link_test_pe_import_matches(pe_external_executable.executable, S8("external.dll"), S8("external_value")));
    BUSTER_TEST(arguments, !link_test_pe_import_matches(pe_external_executable.executable, S8("ucrtbase.dll"), S8("external_value")));
    u8 pe_data_main_text[] = {
        0x48, 0x8d, 0x05, 0, 0, 0, 0, 0xc3,
    };
    ObjectSymbol pe_data_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(pe_data_main_text),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("external_value"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectRelocation pe_data_relocation = {
        .addend = -4,
        .offset = 3,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_PC32,
    };
    ObjectFile pe_data_object = link_test_object_make(arguments->arena, windows_object.target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(pe_data_main_text),
                                                       pe_data_symbols, BUSTER_ARRAY_LENGTH(pe_data_symbols), &pe_data_relocation, 1);
    NativeExecutableLinkResult pe_data_executable = link_native_executable(arguments->arena, &pe_data_object,
                                                                            (NativeExecutableLinkOptions){
                                                                                .entry_symbol = S8("main"),
                                                                                .dynamic_libraries = &external_library,
                                                                                .dynamic_library_count = 1,
                                                                            });
    BUSTER_TEST(arguments, pe_data_executable.error == LINK_ERROR_NONE);
    u64 pe_data_text_offset = 0x400 + align_forward(54, 16);
    BUSTER_TEST(arguments, pe_data_executable.executable.length > pe_data_text_offset + 2 && pe_data_executable.executable.pointer[pe_data_text_offset] == 0x48 &&
                           pe_data_executable.executable.pointer[pe_data_text_offset + 1] == 0x8b);
    BUSTER_TEST(arguments, link_test_pe_import_matches(pe_data_executable.executable, S8("external.dll"), S8("external_value")));
    pe_libc_symbols[1].name = S8("missing_value");
    NativeExecutableLinkResult pe_missing_external = link_native_executable(arguments->arena, &pe_libc_object,
                                                                            (NativeExecutableLinkOptions){
                                                                                .entry_symbol = S8("main"),
                                                                                .dynamic_libraries = &external_library,
                                                                                .dynamic_library_count = 1,
                                                                            });
    BUSTER_TEST(arguments, pe_missing_external.error == LINK_ERROR_UNRESOLVED_SYMBOL);
    BUSTER_STRING_TEST(arguments, pe_missing_external.symbol, S8("missing_value"));

    enum
    {
        LINK_PE_LOOKUP_LIBRARY_COUNT = 64,
        LINK_PE_LOOKUP_EXPORTS_PER_LIBRARY = 16,
        LINK_PE_LOOKUP_IMPORT_COUNT = 256,
    };
    NativeDynamicLibrary* lookup_libraries = arena_allocate(arguments->arena, NativeDynamicLibrary, LINK_PE_LOOKUP_LIBRARY_COUNT);
    String8* lookup_exports =
        arena_allocate(arguments->arena, String8, LINK_PE_LOOKUP_LIBRARY_COUNT * LINK_PE_LOOKUP_EXPORTS_PER_LIBRARY);
    for (u32 library_index = 0; library_index < LINK_PE_LOOKUP_LIBRARY_COUNT; library_index += 1)
    {
        lookup_libraries[library_index] = (NativeDynamicLibrary){
            .name = string_format(arguments->arena, S8("lookup-{u32}.dll"), library_index),
            .exported_symbols = lookup_exports + library_index * LINK_PE_LOOKUP_EXPORTS_PER_LIBRARY,
            .exported_symbol_count = LINK_PE_LOOKUP_EXPORTS_PER_LIBRARY,
            .exports_known = true,
        };
        for (u32 export_index = 0; export_index < LINK_PE_LOOKUP_EXPORTS_PER_LIBRARY; export_index += 1)
        {
            lookup_libraries[library_index].exported_symbols[export_index] =
                string_format(arguments->arena, S8("lookup_{u32}_{u32}"), library_index, export_index);
        }
    }
    String8 shared_lookup_export = S8("lookup_shared");
    lookup_libraries[2].exported_symbols[7] = shared_lookup_export;
    lookup_libraries[10].exported_symbols[9] = shared_lookup_export;
    String8 runtime_lookup_exports[] = {
        S8("lookup_runtime"),
    };
    ObjectSymbol* lookup_symbols = arena_allocate(arguments->arena, ObjectSymbol, LINK_PE_LOOKUP_IMPORT_COUNT + 3);
    memset(lookup_symbols, 0, sizeof(*lookup_symbols) * (LINK_PE_LOOKUP_IMPORT_COUNT + 3));
    lookup_symbols[0] = (ObjectSymbol){
        .name = S8("main"),
        .size = 1,
        .section = OBJECT_SECTION_TEXT,
        .kind = OBJECT_SYMBOL_FUNCTION,
        .global = true,
    };
    for (u32 import_index = 0; import_index < LINK_PE_LOOKUP_IMPORT_COUNT; import_index += 1)
    {
        u32 library_index = LINK_PE_LOOKUP_LIBRARY_COUNT - 1 - import_index % 16;
        u32 export_index = (import_index / 16) % LINK_PE_LOOKUP_EXPORTS_PER_LIBRARY;
        lookup_symbols[import_index + 1] = (ObjectSymbol){
            .name = lookup_libraries[library_index].exported_symbols[export_index],
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        };
    }
    lookup_symbols[LINK_PE_LOOKUP_IMPORT_COUNT + 1] = (ObjectSymbol){
        .name = shared_lookup_export,
        .section = OBJECT_SECTION_UNDEFINED,
        .kind = OBJECT_SYMBOL_FUNCTION,
        .global = true,
    };
    lookup_symbols[LINK_PE_LOOKUP_IMPORT_COUNT + 2] = (ObjectSymbol){
        .name = runtime_lookup_exports[0],
        .section = OBJECT_SECTION_UNDEFINED,
        .kind = OBJECT_SYMBOL_FUNCTION,
        .global = true,
    };
    u8 lookup_main_text[] = {0xc3};
    ObjectFile lookup_object = link_test_object_make(arguments->arena, windows_object.target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(lookup_main_text),
                                                     lookup_symbols, LINK_PE_LOOKUP_IMPORT_COUNT + 3, 0, 0);
    NativeExecutableLinkResult lookup_executable = link_native_executable(arguments->arena, &lookup_object,
                                                                           (NativeExecutableLinkOptions){
                                                                               .entry_symbol = S8("main"),
                                                                               .dynamic_libraries = lookup_libraries,
                                                                               .runtime_exported_symbols = runtime_lookup_exports,
                                                                               .dynamic_library_count = LINK_PE_LOOKUP_LIBRARY_COUNT,
                                                                               .runtime_exported_symbol_count = BUSTER_ARRAY_LENGTH(runtime_lookup_exports),
                                                                               .runtime_exports_known = true,
                                                                           });
    BUSTER_TEST(arguments, lookup_executable.error == LINK_ERROR_NONE);
    for (u32 import_index = 0; import_index < LINK_PE_LOOKUP_IMPORT_COUNT; import_index += 37)
    {
        u32 library_index = LINK_PE_LOOKUP_LIBRARY_COUNT - 1 - import_index % 16;
        BUSTER_TEST(arguments,
                    link_test_pe_import_matches(lookup_executable.executable, lookup_libraries[library_index].name,
                                                lookup_symbols[import_index + 1].name));
    }
    BUSTER_TEST(arguments, link_test_pe_import_matches(lookup_executable.executable, lookup_libraries[2].name, shared_lookup_export));
    BUSTER_TEST(arguments, !link_test_pe_import_matches(lookup_executable.executable, lookup_libraries[10].name, shared_lookup_export));
    BUSTER_TEST(arguments, link_test_pe_import_matches(lookup_executable.executable, S8("ucrtbase.dll"), runtime_lookup_exports[0]));
#endif
    u32 aarch64_main_instructions[] = {
        0x52800000,
        0xd65f03c0,
    };
    ObjectSymbol aarch64_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(aarch64_main_instructions),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    Target aarch64_target = target;
    aarch64_target.cpu_arch = CPU_ARCH_AARCH64;
    aarch64_target.os = OPERATING_SYSTEM_LINUX;
    ObjectFile aarch64_object = link_test_object_make(arguments->arena, aarch64_target,
                                                      (ByteSlice){
                                                          .pointer = (u8*)aarch64_main_instructions,
                                                          .length = sizeof(aarch64_main_instructions),
                                                      },
                                                      aarch64_symbols, BUSTER_ARRAY_LENGTH(aarch64_symbols), 0, 0);
    String8 aarch64_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-aarch64-link-test"), S8(""));
    NativeExecutableLinkResult aarch64_executable = link_native_executable(arguments->arena, &aarch64_object,
                                                                           (NativeExecutableLinkOptions){
                                                                               .output_path = aarch64_output_path,
                                                                               .entry_symbol = S8("main"),
                                                                           });
    BUSTER_TEST(arguments, aarch64_executable.error == LINK_ERROR_NONE);
    bool aarch64_header_valid = aarch64_executable.executable.length > 20 && aarch64_executable.executable.pointer[0] == 0x7f &&
                                aarch64_executable.executable.pointer[1] == 'E' && aarch64_executable.executable.pointer[18] == 183;
    BUSTER_TEST(arguments, aarch64_header_valid);
    u64 aarch64_text_header = 0;
    u64 aarch64_bss_header = 0;
    u64 aarch64_debug_info_header = 0;
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_executable.executable, S8(".text"), 0, &aarch64_text_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_executable.executable, S8(".bss"), 0, &aarch64_bss_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_executable.executable, S8(".debug_info"), 0, &aarch64_debug_info_header));
    BUSTER_TEST(arguments, aarch64_text_header && link_read_u32(aarch64_executable.executable.pointer, aarch64_text_header + 4) == 1);
    BUSTER_TEST(arguments, aarch64_bss_header && link_read_u32(aarch64_executable.executable.pointer, aarch64_bss_header + 4) == 8);
    BUSTER_TEST(arguments, aarch64_debug_info_header && link_read_u64(aarch64_executable.executable.pointer, aarch64_debug_info_header + 32) == 0);
    // The address oracle derives the result from ELF section addresses,
    // independently of the relocation input. Text targets precede the pair;
    // read-only targets follow it, covering both signs of the page delta.
    s64 page_addends[] = {-1, 0, 1, 4095, 4096};
    for (u32 data_section = 0; data_section < 2; data_section += 1)
    {
        for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(page_addends); addend_index += 1)
        {
            u32 page_text[1028] = {0};
            page_text[1024] = UINT32_C(0x90000008);
            page_text[1025] = UINT32_C(0x91000108);
            page_text[1026] = UINT32_C(0x52800000);
            page_text[1027] = UINT32_C(0xd65f03c0);
            u8 page_data[8192] = {0};
            ObjectSymbol page_symbols[] = {
                {.name = S8("main"), .value = 4096, .size = 16, .section = OBJECT_SECTION_TEXT, .kind = OBJECT_SYMBOL_FUNCTION, .global = true},
                {.name = S8("page_data"), .value = 1, .size = 1, .section = data_section, .kind = OBJECT_SYMBOL_DATA},
            };
            ObjectRelocation page_relocations[] = {
                {.offset = 4096, .section = OBJECT_SECTION_TEXT, .symbol = 1, .addend = page_addends[addend_index], .kind = OBJECT_RELOCATION_AARCH64_ELF_PAGE21},
                {.offset = 4100, .section = OBJECT_SECTION_TEXT, .symbol = 1, .addend = page_addends[addend_index], .kind = OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12},
            };
            ObjectFile page_object = link_test_object_make(arguments->arena, aarch64_target,
                (ByteSlice){.pointer = (u8*)page_text, .length = sizeof(page_text)}, page_symbols, 2, page_relocations, 2);
            page_object.sections[OBJECT_SECTION_READ_ONLY_DATA].data = (ByteSlice)BUSTER_ARRAY_TO_SLICE(page_data);
            NativeExecutableLinkResult page_linked = link_native_executable(arguments->arena, &page_object,
                                                                       (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
            u64 text_header = 0;
            u64 data_header = 0;
            bool valid = page_linked.error == LINK_ERROR_NONE &&
                         link_test_elf_section_find(page_linked.executable, S8(".text"), 0, &text_header) &&
                         link_test_elf_section_find(page_linked.executable, data_section ? S8(".rodata") : S8(".text"), 0, &data_header);
            BUSTER_TEST(arguments, valid);
            if (valid)
            {
                u64 text_address = link_read_u64(page_linked.executable.pointer, text_header + 16);
                u64 text_offset = link_read_u64(page_linked.executable.pointer, text_header + 24);
                u64 expected = link_read_u64(page_linked.executable.pointer, data_header + 16) + 1 + (u64)page_addends[addend_index];
                A64MCInst page = {0};
                u32 low = 0;
                BUSTER_TEST(arguments, a64_mc_decode(link_read_u32(page_linked.executable.pointer, text_offset + 4096), &page) && page.opcode == A64_OPCODE_ADRP);
                BUSTER_TEST(arguments, a64_add_lo12_read(link_read_u32(page_linked.executable.pointer, text_offset + 4100), &low));
                u64 actual = ((text_address + 4096) & ~UINT64_C(0xfff)) + (u64)page.operands[1].value + low;
                BUSTER_TEST(arguments, actual == expected);
            }
            u32 saved_word = page_text[1025];
            page_text[1025] = UINT32_C(0x91400108);
            BUSTER_TEST(arguments, link_native_executable(arguments->arena, &page_object,
                (NativeExecutableLinkOptions){.entry_symbol = S8("main")}).error == LINK_ERROR_RELOCATION);
            page_text[1025] = saved_word;
            page_relocations[0].offset += 1;
            BUSTER_TEST(arguments, link_native_executable(arguments->arena, &page_object,
                (NativeExecutableLinkOptions){.entry_symbol = S8("main")}).error == LINK_ERROR_RELOCATION);
        }
    }

    u32 aarch64_jump_instructions[] = {
        0x14000000, 0xd4200000, 0x52800000, 0xd65f03c0,
    };
    ObjectSymbol aarch64_jump_symbols[] = {
        {
            .name = S8("main"),
            .size = 2 * sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("jump_target"),
            .value = 2 * sizeof(u32),
            .size = 2 * sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
        },
    };
    ObjectRelocation aarch64_jump_relocation = {
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_AARCH64_JUMP26,
    };
    ObjectFile aarch64_jump_object = link_test_object_make(arguments->arena, aarch64_target,
                                                           (ByteSlice){
                                                               .pointer = (u8*)aarch64_jump_instructions,
                                                               .length = sizeof(aarch64_jump_instructions),
                                                           },
                                                           aarch64_jump_symbols, BUSTER_ARRAY_LENGTH(aarch64_jump_symbols), &aarch64_jump_relocation, 1);
    NativeExecutableLinkResult aarch64_jump_executable =
        link_native_executable(arguments->arena, &aarch64_jump_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    u64 aarch64_jump_text_header = 0;
    bool aarch64_jump_text_found = aarch64_jump_executable.error == LINK_ERROR_NONE &&
                                   link_test_elf_section_find(aarch64_jump_executable.executable, S8(".text"), 0, &aarch64_jump_text_header);
    BUSTER_TEST(arguments, aarch64_jump_text_found);
    if (aarch64_jump_text_found)
    {
        u64 aarch64_jump_text_offset = link_read_u64(aarch64_jump_executable.executable.pointer, aarch64_jump_text_header + 24);
        BUSTER_TEST(arguments, link_read_u32(aarch64_jump_executable.executable.pointer, aarch64_jump_text_offset) == UINT32_C(0x14000002));
    }
    u8 aarch64_misaligned_text[12] = {0};
    u32 aarch64_misaligned_branch = UINT32_C(0x14000000);
    memcpy(aarch64_misaligned_text + 1, &aarch64_misaligned_branch, sizeof(aarch64_misaligned_branch));
    ObjectSymbol aarch64_misaligned_symbols[] = {
        {
            .name = S8("main"),
            .size = 5,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("misaligned_target"),
            .value = 5,
            .size = 4,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
        },
    };
    ObjectRelocation aarch64_misaligned_relocation = {
        .offset = 1,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_AARCH64_JUMP26,
    };
    ObjectFile aarch64_misaligned_object =
        link_test_object_make(arguments->arena, aarch64_target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(aarch64_misaligned_text),
                              aarch64_misaligned_symbols, BUSTER_ARRAY_LENGTH(aarch64_misaligned_symbols), &aarch64_misaligned_relocation, 1);
    BUSTER_TEST(arguments,
                link_native_executable(arguments->arena, &aarch64_misaligned_object,
                                       (NativeExecutableLinkOptions){.entry_symbol = S8("main")})
                        .error == LINK_ERROR_RELOCATION);
    u32 aarch64_libc_instructions[] = {
        0xa9bf7bfd, 0x910003fd, 0x52800540, 0x94000000, 0x5100a800, 0xa8c17bfd, 0xd65f03c0,
    };
    ObjectSymbol aarch64_libc_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(aarch64_libc_instructions),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("abs"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectRelocation aarch64_libc_relocation = {
        .offset = 3 * sizeof(u32),
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_AARCH64_CALL26,
    };
    ObjectFile aarch64_libc_object = link_test_object_make(arguments->arena, aarch64_target,
                                                           (ByteSlice){
                                                               .pointer = (u8*)aarch64_libc_instructions,
                                                               .length = sizeof(aarch64_libc_instructions),
                                                           },
                                                           aarch64_libc_symbols, BUSTER_ARRAY_LENGTH(aarch64_libc_symbols), &aarch64_libc_relocation, 1);
    String8 aarch64_libc_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-aarch64-libc-link-test"), S8(""));
    NativeExecutableLinkResult aarch64_libc_executable = link_native_executable(arguments->arena, &aarch64_libc_object,
                                                                                (NativeExecutableLinkOptions){
                                                                                    .output_path = aarch64_libc_output_path,
                                                                                    .entry_symbol = S8("main"),
                                                                                });
    BUSTER_TEST(arguments, aarch64_libc_executable.error == LINK_ERROR_NONE);
    ObjectRelocationKind imported_aarch64_branch_kinds[] = {OBJECT_RELOCATION_AARCH64_CALL26, OBJECT_RELOCATION_AARCH64_JUMP26};
    u32 imported_aarch64_branch_words[] = {UINT32_C(0x94000000), UINT32_C(0x14000000)};
    for (u32 branch_index = 0; branch_index < BUSTER_ARRAY_LENGTH(imported_aarch64_branch_kinds); branch_index += 1)
    {
        aarch64_libc_relocation.kind = imported_aarch64_branch_kinds[branch_index];
        aarch64_libc_relocation.addend = 4;
        aarch64_libc_instructions[3] = imported_aarch64_branch_words[branch_index];
        NativeExecutableLinkResult imported_addend = link_native_executable(arguments->arena, &aarch64_libc_object,
                                                                             (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
        BUSTER_TEST(arguments, imported_addend.error == LINK_ERROR_RELOCATION);
    }
    aarch64_libc_relocation.kind = OBJECT_RELOCATION_AARCH64_CALL26;
    aarch64_libc_relocation.addend = 0;
    aarch64_libc_instructions[3] = UINT32_C(0x94000000);
    String8 dynamic_section_names[] = {
        S8(".interp"), S8(".plt"), S8(".dynstr"), S8(".dynsym"), S8(".hash"), S8(".rela.plt"), S8(".got.plt"), S8(".dynamic"),
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(dynamic_section_names); index += 1)
    {
        BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_libc_executable.executable, dynamic_section_names[index], 0, 0));
    }
    u32 dynamic_string_index = 0;
    u32 dynamic_symbol_index = 0;
    u32 got_index = 0;
    u64 dynamic_symbol_header = 0;
    u64 hash_header = 0;
    u64 relocation_header = 0;
    u64 dynamic_header = 0;
    BUSTER_TEST(arguments,
                link_test_elf_section_find(aarch64_libc_executable.executable, S8(".dynstr"), &dynamic_string_index, 0));
    BUSTER_TEST(arguments,
                link_test_elf_section_find(aarch64_libc_executable.executable, S8(".dynsym"), &dynamic_symbol_index, &dynamic_symbol_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_libc_executable.executable, S8(".got.plt"), &got_index, 0));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_libc_executable.executable, S8(".hash"), 0, &hash_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_libc_executable.executable, S8(".rela.plt"), 0, &relocation_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_libc_executable.executable, S8(".dynamic"), 0, &dynamic_header));
    BUSTER_TEST(arguments, dynamic_symbol_header && link_read_u32(aarch64_libc_executable.executable.pointer, dynamic_symbol_header + 40) == dynamic_string_index);
    BUSTER_TEST(arguments, hash_header && link_read_u32(aarch64_libc_executable.executable.pointer, hash_header + 40) == dynamic_symbol_index);
    BUSTER_TEST(arguments, relocation_header && link_read_u32(aarch64_libc_executable.executable.pointer, relocation_header + 40) == dynamic_symbol_index &&
                               link_read_u32(aarch64_libc_executable.executable.pointer, relocation_header + 44) == got_index);
    BUSTER_TEST(arguments, dynamic_header && link_read_u32(aarch64_libc_executable.executable.pointer, dynamic_header + 40) == dynamic_string_index);
    // Copy relocations against a shared library whose symbol table the driver
    // read.  The reservation stands for the library's object, so every name
    // the library exports at that address is defined at the slot, the slot is
    // the library's own size rather than a pointer, and two imported names for
    // one object share one slot and one relocation.  Without the alias set,
    // glibc's post-startup store through `__environ` misses the executable's
    // copy of `environ` and the program reads null.
    Target copy_alias_target = {
        .cpu_arch = CPU_ARCH_X86_64,
        .os = OPERATING_SYSTEM_LINUX,
    };
    u8 copy_alias_text[] = {
        0x48, 0x8b, 0x05, 0, 0, 0, 0, 0x48, 0x8b, 0x0d, 0, 0, 0, 0, 0xc3,
    };
    ObjectSymbol copy_alias_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(copy_alias_text),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("environ"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
        {
            .name = S8("tzname"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectRelocation copy_alias_relocations[] = {
        {
            .addend = -4,
            .offset = 3,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_X86_64_PC32,
        },
        {
            .addend = -4,
            .offset = 10,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 2,
            .kind = OBJECT_RELOCATION_X86_64_PC32,
        },
    };
    NativeDynamicDataSymbol copy_alias_exports[] = {
        {.name = S8("environ"), .address = 0x220de8, .size = 8},
        {.name = S8("_environ"), .address = 0x220de8, .size = 8},
        {.name = S8("__environ"), .address = 0x220de8, .size = 8},
        {.name = S8("tzname"), .address = 0x221240, .size = 16},
        {.name = S8("__tzname"), .address = 0x221240, .size = 16},
        // A versioned object appears once per version symbol under the same
        // name, and glibc has four of `sys_errlist`.  One alias, not four.
        {.name = S8("__tzname"), .address = 0x221240, .size = 16},
        {.name = S8("stdout"), .address = 0x221300, .size = 8},
    };
    ObjectFile copy_alias_object =
        link_test_object_make(arguments->arena, copy_alias_target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(copy_alias_text), copy_alias_symbols,
                              BUSTER_ARRAY_LENGTH(copy_alias_symbols), copy_alias_relocations, BUSTER_ARRAY_LENGTH(copy_alias_relocations));
    NativeExecutableLinkResult copy_alias_executable = link_native_executable(arguments->arena, &copy_alias_object,
                                                                             (NativeExecutableLinkOptions){
                                                                                 .entry_symbol = S8("main"),
                                                                                 .runtime_data_symbols = copy_alias_exports,
                                                                                 .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_exports),
                                                                             });
    BUSTER_TEST(arguments, copy_alias_executable.error == LINK_ERROR_NONE);
    u64 copy_alias_environ = 0;
    u64 copy_alias_environ_alias = 0;
    u64 copy_alias_environ_underscore = 0;
    u64 copy_alias_environ_size = 0;
    u16 copy_alias_environ_section = 0;
    u64 copy_alias_tzname = 0;
    u64 copy_alias_tzname_alias = 0;
    u64 copy_alias_tzname_size = 0;
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_executable.executable, S8("environ"), &copy_alias_environ, &copy_alias_environ_size,
                                                        &copy_alias_environ_section));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_executable.executable, S8("__environ"), &copy_alias_environ_alias, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_executable.executable, S8("_environ"), &copy_alias_environ_underscore, 0, 0));
    BUSTER_TEST(arguments, copy_alias_environ && copy_alias_environ == copy_alias_environ_alias && copy_alias_environ == copy_alias_environ_underscore);
    BUSTER_TEST(arguments, copy_alias_environ_size == 8 && copy_alias_environ_section == 0xfff1);
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_executable.executable, S8("tzname"), &copy_alias_tzname, &copy_alias_tzname_size, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_executable.executable, S8("__tzname"), &copy_alias_tzname_alias, 0, 0));
    BUSTER_TEST(arguments, copy_alias_tzname && copy_alias_tzname == copy_alias_tzname_alias && copy_alias_tzname_size == 16);
    // Ordinary symbols describe final copy-slot definitions, including the
    // aliases synthesized by the writer, even when the input BSS was empty.
    BUSTER_TEST(arguments, link_test_elf_copy_symbol(copy_alias_executable.executable, S8("environ"), 0x11));
    BUSTER_TEST(arguments, link_test_elf_copy_symbol(copy_alias_executable.executable, S8("_environ"), 0x11));
    BUSTER_TEST(arguments, link_test_elf_copy_symbol(copy_alias_executable.executable, S8("__environ"), 0x11));
    BUSTER_TEST(arguments, link_test_elf_copy_symbol(copy_alias_executable.executable, S8("tzname"), 0x11));
    BUSTER_TEST(arguments, link_test_elf_copy_symbol(copy_alias_executable.executable, S8("__tzname"), 0x11));
    // A name the library exports but this program does not reference, and
    // whose address no import names, stays out of the image.
    BUSTER_TEST(arguments, !link_test_elf_dynamic_symbol(copy_alias_executable.executable, S8("stdout"), 0, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_relocation_count(copy_alias_executable.executable, 5) == 2);
    u64 copy_alias_hash_header = 0;
    u64 copy_alias_symbol_header = 0;
    BUSTER_TEST(arguments, link_test_elf_section_find(copy_alias_executable.executable, S8(".hash"), 0, &copy_alias_hash_header) &&
                               link_test_elf_section_find(copy_alias_executable.executable, S8(".dynsym"), 0, &copy_alias_symbol_header));
    if (copy_alias_hash_header && copy_alias_symbol_header)
    {
        u64 copy_alias_hash_offset = link_read_u64(copy_alias_executable.executable.pointer, copy_alias_hash_header + 24);
        u64 copy_alias_symbol_size = link_read_u64(copy_alias_executable.executable.pointer, copy_alias_symbol_header + 32);
        // Four imports — environ, tzname, exit and __cxa_atexit — three
        // aliases and the null entry: the hash table has to grow with the
        // alias set or the loader stops walking before it reaches one.
        BUSTER_TEST(arguments, copy_alias_symbol_size / 24 == 8);
        BUSTER_TEST(arguments, link_read_u32(copy_alias_executable.executable.pointer, copy_alias_hash_offset + 4) == copy_alias_symbol_size / 24);
    }
    // Both names of one object imported: one slot, one relocation, and no
    // second dynamic symbol for the alias.
    ObjectSymbol copy_alias_pair_symbols[] = {
        copy_alias_symbols[0],
        copy_alias_symbols[1],
        {
            .name = S8("__environ"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectFile copy_alias_pair_object = copy_alias_object;
    copy_alias_pair_object.symbols = copy_alias_pair_symbols;
    NativeExecutableLinkResult copy_alias_pair_executable =
        link_native_executable(arguments->arena, &copy_alias_pair_object,
                               (NativeExecutableLinkOptions){
                                   .entry_symbol = S8("main"),
                                   .runtime_data_symbols = copy_alias_exports,
                                   .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_exports),
                               });
    BUSTER_TEST(arguments, copy_alias_pair_executable.error == LINK_ERROR_NONE);
    u64 copy_alias_pair_first = 0;
    u64 copy_alias_pair_second = 0;
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_pair_executable.executable, S8("environ"), &copy_alias_pair_first, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_pair_executable.executable, S8("__environ"), &copy_alias_pair_second, 0, 0));
    BUSTER_TEST(arguments, copy_alias_pair_first && copy_alias_pair_first == copy_alias_pair_second);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(copy_alias_pair_executable.executable, 5) == 1);
    // A name the program defines itself is left alone: the executable must
    // not carry two definitions of one name, and the program's own is the one
    // it means to use.
    ObjectSymbol copy_alias_defined_symbols[] = {
        copy_alias_symbols[0],
        copy_alias_symbols[1],
        copy_alias_symbols[2],
        {
            .name = S8("_environ"),
            .size = sizeof(u64),
            .section = OBJECT_SECTION_ZERO,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectFile copy_alias_defined_object = copy_alias_object;
    ObjectSection* copy_alias_defined_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
    memcpy(copy_alias_defined_sections, copy_alias_object.sections, (u64)OBJECT_SECTION_COUNT * sizeof(*copy_alias_defined_sections));
    copy_alias_defined_sections[OBJECT_SECTION_ZERO].virtual_size = sizeof(u64);
    copy_alias_defined_object.sections = copy_alias_defined_sections;
    copy_alias_defined_object.symbols = copy_alias_defined_symbols;
    copy_alias_defined_object.symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_defined_symbols);
    NativeExecutableLinkResult copy_alias_defined_executable =
        link_native_executable(arguments->arena, &copy_alias_defined_object,
                               (NativeExecutableLinkOptions){
                                   .entry_symbol = S8("main"),
                                   .runtime_data_symbols = copy_alias_exports,
                                   .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_exports),
                               });
    BUSTER_TEST(arguments, copy_alias_defined_executable.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_defined_executable.executable, S8("__environ"), 0, 0, 0));
    BUSTER_TEST(arguments, !link_test_elf_dynamic_symbol(copy_alias_defined_executable.executable, S8("_environ"), 0, 0, 0));
    // A library the driver could not read keeps the pointer-sized slot the
    // writer reserved before alias sets existed.
    NativeExecutableLinkResult copy_alias_unknown_executable =
        link_native_executable(arguments->arena, &copy_alias_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, copy_alias_unknown_executable.error == LINK_ERROR_NONE);
    u64 copy_alias_unknown_size = 0;
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(copy_alias_unknown_executable.executable, S8("tzname"), 0, &copy_alias_unknown_size, 0));
    BUSTER_TEST(arguments, copy_alias_unknown_size == 8);
    BUSTER_TEST(arguments, !link_test_elf_dynamic_symbol(copy_alias_unknown_executable.executable, S8("__tzname"), 0, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_relocation_count(copy_alias_unknown_executable.executable, 5) == 2);
    // The same image for AArch64.  That writer builds by patching the x86-64
    // writer's output, and its fix-up loop walks the PLT range only, so a copy
    // relocation left behind keeps R_X86_64_COPY -- type 5, which numbered as
    // an AArch64 type is a 16-bit absolute move the loader would apply over
    // the slot rather than filling it from the library.
    //
    // How many entries that range holds is the number of slots and not the
    // number of data imports, so `environ` and `__environ` are both imported
    // here: they share one object, one slot, and one relocation.  The alias
    // dynamic symbols the slot defines carry no relocation at all, which a
    // recount over dynamic symbols rather than over the copy range would walk
    // into.
    u32 aarch64_copy_words[] = {
        0xd65f03c0, 0xd503201f, 0, 0, 0, 0, 0, 0,
    };
    ObjectSymbol aarch64_copy_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(aarch64_copy_words),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("environ"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
        {
            .name = S8("tzname"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
        {
            .name = S8("__environ"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectRelocation aarch64_copy_relocations[] = {
        {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        {.offset = 16, .section = OBJECT_SECTION_TEXT, .symbol = 2, .kind = OBJECT_RELOCATION_ABSOLUTE64},
        {.offset = 24, .section = OBJECT_SECTION_TEXT, .symbol = 3, .kind = OBJECT_RELOCATION_ABSOLUTE64},
    };
    ObjectFile aarch64_copy_object = link_test_object_make(arguments->arena, aarch64_target,
                                                          (ByteSlice){
                                                              .pointer = (u8*)aarch64_copy_words,
                                                              .length = sizeof(aarch64_copy_words),
                                                          },
                                                          aarch64_copy_symbols, BUSTER_ARRAY_LENGTH(aarch64_copy_symbols), aarch64_copy_relocations,
                                                          BUSTER_ARRAY_LENGTH(aarch64_copy_relocations));
    NativeExecutableLinkResult aarch64_copy_executable = link_native_executable(arguments->arena, &aarch64_copy_object,
                                                                               (NativeExecutableLinkOptions){
                                                                                   .entry_symbol = S8("main"),
                                                                                   .runtime_data_symbols = copy_alias_exports,
                                                                                   .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_exports),
                                                                               });
    BUSTER_TEST(arguments, aarch64_copy_executable.error == LINK_ERROR_NONE);
    // Two slots -- environ with tzname -- and one jump slot per import, the
    // three data names plus the hosted stub's `exit` and `__cxa_atexit`.  No x86-64 type of
    // either kind survives.
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_copy_executable.executable, 1024) == 2);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_copy_executable.executable, 1026) == 5);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_copy_executable.executable, 5) == 0);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_copy_executable.executable, 7) == 0);
    u64 aarch64_copy_environ = 0;
    u64 aarch64_copy_environ_pair = 0;
    u64 aarch64_copy_environ_alias = 0;
    u64 aarch64_copy_tzname = 0;
    u64 aarch64_copy_tzname_size = 0;
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(aarch64_copy_executable.executable, S8("environ"), &aarch64_copy_environ, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(aarch64_copy_executable.executable, S8("__environ"), &aarch64_copy_environ_pair, 0, 0));
    BUSTER_TEST(arguments, link_test_elf_dynamic_symbol(aarch64_copy_executable.executable, S8("_environ"), &aarch64_copy_environ_alias, 0, 0));
    BUSTER_TEST(arguments, aarch64_copy_environ && aarch64_copy_environ == aarch64_copy_environ_pair && aarch64_copy_environ == aarch64_copy_environ_alias);
    BUSTER_TEST(arguments,
                link_test_elf_dynamic_symbol(aarch64_copy_executable.executable, S8("tzname"), &aarch64_copy_tzname, &aarch64_copy_tzname_size, 0));
    BUSTER_TEST(arguments, aarch64_copy_tzname && aarch64_copy_tzname != aarch64_copy_environ && aarch64_copy_tzname_size == 16);
    // ADRP/ADD references to imported data must use the staging writer's
    // copy slot (including aliases), never the function PLT thunk.
    for (u32 import_symbol = 1; import_symbol < BUSTER_ARRAY_LENGTH(aarch64_copy_symbols); import_symbol += 1)
    {
        u32 page_words[] = {UINT32_C(0x52800000), UINT32_C(0xd65f03c0), UINT32_C(0x90000017), UINT32_C(0x910002f7)};
        ObjectRelocation page_relocations[] = {
            {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = import_symbol, .addend = 1, .kind = OBJECT_RELOCATION_AARCH64_ELF_PAGE21},
            {.offset = 12, .section = OBJECT_SECTION_TEXT, .symbol = import_symbol, .addend = 1, .kind = OBJECT_RELOCATION_AARCH64_ELF_ADD_LO12},
        };
        ObjectFile page_object = link_test_object_make(arguments->arena, aarch64_target,
            (ByteSlice){.pointer = (u8*)page_words, .length = sizeof(page_words)}, aarch64_copy_symbols,
            BUSTER_ARRAY_LENGTH(aarch64_copy_symbols), page_relocations, 2);
        NativeExecutableLinkResult page_linked = link_native_executable(arguments->arena, &page_object,
            (NativeExecutableLinkOptions){.entry_symbol = S8("main"), .runtime_data_symbols = copy_alias_exports,
                                          .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_exports)});
        u64 text_header = 0;
        u64 copy_address = 0;
        bool valid = page_linked.error == LINK_ERROR_NONE && link_test_elf_section_find(page_linked.executable, S8(".text"), 0, &text_header) &&
                     link_test_elf_dynamic_symbol(page_linked.executable, aarch64_copy_symbols[import_symbol].name, &copy_address, 0, 0);
        BUSTER_TEST(arguments, valid);
        if (valid)
        {
            u64 text_offset = link_read_u64(page_linked.executable.pointer, text_header + 24);
            u64 text_address = link_read_u64(page_linked.executable.pointer, text_header + 16);
            A64MCInst page = {0};
            u32 low = 0;
            BUSTER_TEST(arguments, a64_mc_decode(link_read_u32(page_linked.executable.pointer, text_offset + 8), &page) && page.opcode == A64_OPCODE_ADRP);
            BUSTER_TEST(arguments, a64_add_lo12_read(link_read_u32(page_linked.executable.pointer, text_offset + 12), &low));
            BUSTER_TEST(arguments, ((text_address + 8) & ~UINT64_C(0xfff)) + (u64)page.operands[1].value + low == copy_address + 1);
        }
        page_words[2] = UINT32_C(0xd503201f);
        BUSTER_TEST(arguments, link_native_executable(arguments->arena, &page_object,
            (NativeExecutableLinkOptions){.entry_symbol = S8("main"), .runtime_data_symbols = copy_alias_exports,
                .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_exports)}).error == LINK_ERROR_RELOCATION);
    }

    // The same object without an export table: the driver could not read the
    // library, so each import keeps a pointer-sized slot of its own -- three
    // slots, three copy relocations, still the AArch64 type.
    NativeExecutableLinkResult aarch64_copy_unknown = link_native_executable(arguments->arena, &aarch64_copy_object,
                                                                            (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_copy_unknown.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_copy_unknown.executable, 1024) == 3);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_copy_unknown.executable, 1026) == 5);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_copy_unknown.executable, 5) == 0);
    // An AArch64 image with no imported data at all keeps its jump slots and
    // gains no copy range: the dynamic array is two entries shorter there, and
    // walking it to DT_NULL is what keeps both lengths readable.
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_libc_executable.executable, 1024) == 0);
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_libc_executable.executable, 1026) == 3);
    // Symbol versions.  A shared library publishes a name under a version, and
    // an image that binds to it has to record which one: .gnu.version indexes
    // every dynamic symbol, .gnu.version_r names the versions per library, and
    // DT_VERSYM/DT_VERNEED/DT_VERNEEDNUM publish both to the loader.  The
    // alias names a copy slot defines are versioned too, because each of them
    // is a name the library publishes.
    NativeDynamicVersionedSymbol copy_version_exports[] = {
        {.name = S8("environ"), .version = S8("GLIBC_2.2.5"), .has_default = true},
        {.name = S8("_environ"), .version = S8("GLIBC_2.2.5"), .has_default = true},
        {.name = S8("__environ"), .version = S8("GLIBC_2.2.5"), .has_default = true},
        {.name = S8("tzname"), .version = S8("GLIBC_2.2.5"), .has_default = true},
        {.name = S8("__tzname"), .version = S8("GLIBC_2.2.5"), .has_default = true},
        {.name = S8("exit"), .version = S8("GLIBC_2.34"), .has_default = true},
        {.name = S8("__cxa_atexit"), .version = S8("GLIBC_2.2.5"), .has_default = true},
        // glibc publishes sys_errlist once per historical layout and every one
        // of them is a non-default `name@VER`.
        {.name = S8("sys_errlist"), .version = S8("GLIBC_2.2.5")},
        {.name = S8("sys_errlist"), .version = S8("GLIBC_2.4")},
    };
    NativeExecutableLinkOptions copy_version_options = {
        .entry_symbol = S8("main"),
        .runtime_data_symbols = copy_alias_exports,
        .runtime_versioned_symbols = copy_version_exports,
        .runtime_data_symbol_count = BUSTER_ARRAY_LENGTH(copy_alias_exports),
        .runtime_versioned_symbol_count = BUSTER_ARRAY_LENGTH(copy_version_exports),
    };
    NativeExecutableLinkResult copy_version_executable = link_native_executable(arguments->arena, &copy_alias_object, copy_version_options);
    BUSTER_TEST(arguments, copy_version_executable.error == LINK_ERROR_NONE);
    String8 copy_version_names[] = {S8("environ"), S8("_environ"), S8("__environ"), S8("tzname"), S8("__tzname"), S8("exit")};
    String8 copy_version_expected[] = {
        S8("GLIBC_2.2.5"), S8("GLIBC_2.2.5"), S8("GLIBC_2.2.5"), S8("GLIBC_2.2.5"), S8("GLIBC_2.2.5"), S8("GLIBC_2.34"),
    };
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(copy_version_names); index += 1)
    {
        String8 recorded = {0};
        String8 recorded_library = {0};
        BUSTER_TEST(arguments, link_test_elf_symbol_version(copy_version_executable.executable, copy_version_names[index], &recorded, &recorded_library));
        BUSTER_TEST(arguments, string_equal(recorded, copy_version_expected[index]) && string_equal(recorded_library, S8("libc.so.6")));
    }
    u64 copy_version_symbol_header = 0;
    u64 copy_version_header = 0;
    u64 copy_version_need_header = 0;
    BUSTER_TEST(arguments, link_test_elf_section_find(copy_version_executable.executable, S8(".dynsym"), 0, &copy_version_symbol_header) &&
                               link_test_elf_section_find(copy_version_executable.executable, S8(".gnu.version"), 0, &copy_version_header) &&
                               link_test_elf_section_find(copy_version_executable.executable, S8(".gnu.version_r"), 0, &copy_version_need_header));
    if (copy_version_symbol_header && copy_version_header && copy_version_need_header)
    {
        u32 copy_version_symbol_index = 0;
        u32 copy_version_string_index = 0;
        BUSTER_TEST(arguments, link_test_elf_section_find(copy_version_executable.executable, S8(".dynsym"), &copy_version_symbol_index, 0) &&
                                   link_test_elf_section_find(copy_version_executable.executable, S8(".dynstr"), &copy_version_string_index, 0));
        // One index per dynamic symbol, or the loader reads a version off the
        // wrong one.
        BUSTER_TEST(arguments, link_read_u64(copy_version_executable.executable.pointer, copy_version_header + 32) ==
                                   link_read_u64(copy_version_executable.executable.pointer, copy_version_symbol_header + 32) / 24 * sizeof(u16));
        BUSTER_TEST(arguments, link_read_u32(copy_version_executable.executable.pointer, copy_version_header + 40) == copy_version_symbol_index);
        BUSTER_TEST(arguments, link_read_u32(copy_version_executable.executable.pointer, copy_version_need_header + 40) == copy_version_string_index);
        BUSTER_TEST(arguments, link_read_u32(copy_version_executable.executable.pointer, copy_version_need_header + 44) == 1);
    }
    u64 copy_version_symbol_tag = 0;
    u64 copy_version_need_tag = 0;
    u64 copy_version_need_count = 0;
    BUSTER_TEST(arguments, link_test_elf_dynamic_entry(copy_version_executable.executable, 0x6ffffff0, &copy_version_symbol_tag) &&
                               link_test_elf_dynamic_entry(copy_version_executable.executable, 0x6ffffffe, &copy_version_need_tag) &&
                               link_test_elf_dynamic_entry(copy_version_executable.executable, 0x6fffffff, &copy_version_need_count));
    BUSTER_TEST(arguments, copy_version_need_count == 1 && copy_version_symbol_tag && copy_version_need_tag);
    if (copy_version_header && copy_version_need_header)
    {
        BUSTER_TEST(arguments, copy_version_symbol_tag == link_read_u64(copy_version_executable.executable.pointer, copy_version_header + 16) &&
                                   copy_version_need_tag == link_read_u64(copy_version_executable.executable.pointer, copy_version_need_header + 16));
    }
    // A second library gets its own .gnu.version_r entry, and a name the
    // runtime does not define is looked for there.
    ObjectSymbol copy_version_library_symbols[] = {
        copy_alias_symbols[0],
        copy_alias_symbols[1],
        copy_alias_symbols[2],
        {
            .name = S8("sqrt"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    NativeDynamicVersionedSymbol copy_version_math_exports[] = {
        {.name = S8("sqrt"), .version = S8("GLIBC_2.2.5"), .has_default = true},
    };
    NativeDynamicLibrary copy_version_libraries[] = {
        {
            .name = S8("libm.so.6"),
            .versioned_symbols = copy_version_math_exports,
            .versioned_symbol_count = BUSTER_ARRAY_LENGTH(copy_version_math_exports),
        },
    };
    ObjectFile copy_version_library_object = copy_alias_object;
    copy_version_library_object.symbols = copy_version_library_symbols;
    copy_version_library_object.symbol_count = BUSTER_ARRAY_LENGTH(copy_version_library_symbols);
    NativeExecutableLinkOptions copy_version_library_options = copy_version_options;
    copy_version_library_options.dynamic_libraries = copy_version_libraries;
    copy_version_library_options.dynamic_library_count = BUSTER_ARRAY_LENGTH(copy_version_libraries);
    NativeExecutableLinkResult copy_version_library_executable =
        link_native_executable(arguments->arena, &copy_version_library_object, copy_version_library_options);
    BUSTER_TEST(arguments, copy_version_library_executable.error == LINK_ERROR_NONE);
    String8 copy_version_math_version = {0};
    String8 copy_version_math_library = {0};
    BUSTER_TEST(arguments,
                link_test_elf_symbol_version(copy_version_library_executable.executable, S8("sqrt"), &copy_version_math_version, &copy_version_math_library));
    BUSTER_TEST(arguments, string_equal(copy_version_math_version, S8("GLIBC_2.2.5")) && string_equal(copy_version_math_library, S8("libm.so.6")));
    copy_version_need_count = 0;
    BUSTER_TEST(arguments, link_test_elf_dynamic_entry(copy_version_library_executable.executable, 0x6fffffff, &copy_version_need_count) &&
                               copy_version_need_count == 2);
    // The same version string from two libraries is two records, because the
    // loader matches a version per library.
    String8 copy_version_environ_library = {0};
    BUSTER_TEST(arguments, link_test_elf_symbol_version(copy_version_library_executable.executable, S8("environ"), 0, &copy_version_environ_library) &&
                               string_equal(copy_version_environ_library, S8("libc.so.6")));
    // A name whose every definition is a non-default `name@VER` has no default
    // to bind to.  GNU ld reports it undefined rather than linking it, because
    // an image that links it anyway leaves the answer to whichever version the
    // running loader picks -- which is the mechanism's whole purpose.
    ObjectSymbol copy_version_hidden_symbols[] = {
        copy_alias_symbols[0],
        copy_alias_symbols[1],
        {
            .name = S8("sys_errlist"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectFile copy_version_hidden_object = copy_alias_object;
    copy_version_hidden_object.symbols = copy_version_hidden_symbols;
    NativeExecutableLinkResult copy_version_hidden_executable = link_native_executable(arguments->arena, &copy_version_hidden_object, copy_version_options);
    BUSTER_TEST(arguments, copy_version_hidden_executable.error == LINK_ERROR_SYMBOL_VERSION);
    BUSTER_TEST(arguments, string_equal(copy_version_hidden_executable.symbol, S8("sys_errlist")));
    // A library that publishes its names without versions needs no records at
    // all, and the image keeps the shape it had before versions existed.
    NativeDynamicVersionedSymbol copy_version_plain_exports[] = {
        {.name = S8("environ"), .has_default = true},
        {.name = S8("_environ"), .has_default = true},
        {.name = S8("__environ"), .has_default = true},
        {.name = S8("tzname"), .has_default = true},
        {.name = S8("__tzname"), .has_default = true},
        {.name = S8("exit"), .has_default = true},
        {.name = S8("__cxa_atexit"), .has_default = true},
    };
    NativeExecutableLinkOptions copy_version_plain_options = copy_version_options;
    copy_version_plain_options.runtime_versioned_symbols = copy_version_plain_exports;
    copy_version_plain_options.runtime_versioned_symbol_count = BUSTER_ARRAY_LENGTH(copy_version_plain_exports);
    NativeExecutableLinkResult copy_version_plain_executable = link_native_executable(arguments->arena, &copy_alias_object, copy_version_plain_options);
    BUSTER_TEST(arguments, copy_version_plain_executable.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, !link_test_elf_section_find(copy_version_plain_executable.executable, S8(".gnu.version"), 0, 0));
    BUSTER_TEST(arguments, !link_test_elf_section_find(copy_version_plain_executable.executable, S8(".gnu.version_r"), 0, 0));
    BUSTER_TEST(arguments, !link_test_elf_dynamic_entry(copy_version_plain_executable.executable, 0x6ffffff0, 0));
    BUSTER_TEST(arguments, copy_alias_executable.executable.length == copy_version_plain_executable.executable.length);
    // AArch64 reaches the same writer and then patches the dynamic array it
    // produced, so the version entries have to leave that patch intact.
    NativeDynamicVersionedSymbol aarch64_version_exports[] = {
        {.name = S8("abs"), .version = S8("GLIBC_2.2.5"), .has_default = true},
        {.name = S8("exit"), .version = S8("GLIBC_2.34"), .has_default = true},
        {.name = S8("__cxa_atexit"), .version = S8("GLIBC_2.2.5"), .has_default = true},
    };
    NativeExecutableLinkResult aarch64_version_executable = link_native_executable(arguments->arena, &aarch64_libc_object,
                                                                                  (NativeExecutableLinkOptions){
                                                                                      .entry_symbol = S8("main"),
                                                                                      .runtime_versioned_symbols = aarch64_version_exports,
                                                                                      .runtime_versioned_symbol_count =
                                                                                          BUSTER_ARRAY_LENGTH(aarch64_version_exports),
                                                                                  });
    BUSTER_TEST(arguments, aarch64_version_executable.error == LINK_ERROR_NONE);
    String8 aarch64_version_recorded = {0};
    BUSTER_TEST(arguments, link_test_elf_symbol_version(aarch64_version_executable.executable, S8("abs"), &aarch64_version_recorded, 0) &&
                               string_equal(aarch64_version_recorded, S8("GLIBC_2.2.5")));
    BUSTER_TEST(arguments, link_test_elf_dynamic_entry(aarch64_version_executable.executable, 0x6ffffff0, 0));
    // R_AARCH64_JUMP_SLOT, still written over the x86-64 writer's entries.
    BUSTER_TEST(arguments, link_test_elf_relocation_count(aarch64_version_executable.executable, 1026) == 3);
    ObjectFile aarch64_tls_object = aarch64_libc_object;
    ObjectSection* aarch64_tls_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
    memcpy(aarch64_tls_sections, aarch64_libc_object.sections, sizeof(*aarch64_tls_sections) * OBJECT_SECTION_COUNT);
    aarch64_tls_object.sections = aarch64_tls_sections;
    u32 initialized_thread_local = 42;
    aarch64_tls_sections[OBJECT_SECTION_THREAD_LOCAL_DATA].data = (ByteSlice){
        .pointer = (u8*)&initialized_thread_local,
        .length = sizeof(initialized_thread_local),
    };
    aarch64_tls_sections[OBJECT_SECTION_THREAD_LOCAL_ZERO].virtual_size = 32;
    NativeExecutableLinkResult aarch64_tls_executable = link_native_executable(arguments->arena, &aarch64_tls_object,
                                                                                (NativeExecutableLinkOptions){
                                                                                    .entry_symbol = S8("main"),
                                                                                });
    BUSTER_TEST(arguments, aarch64_tls_executable.error == LINK_ERROR_NONE);
    u64 thread_local_data_header = 0;
    u64 thread_local_zero_header = 0;
    u64 tls_got_header = 0;
    u64 tls_dynamic_header = 0;
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_tls_executable.executable, S8(".tdata"), 0, &thread_local_data_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_tls_executable.executable, S8(".tbss"), 0, &thread_local_zero_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_tls_executable.executable, S8(".got.plt"), 0, &tls_got_header));
    BUSTER_TEST(arguments, link_test_elf_section_find(aarch64_tls_executable.executable, S8(".dynamic"), 0, &tls_dynamic_header));
    u64 thread_local_data_address = thread_local_data_header ? link_read_u64(aarch64_tls_executable.executable.pointer, thread_local_data_header + 16) : 0;
    u64 thread_local_data_size = thread_local_data_header ? link_read_u64(aarch64_tls_executable.executable.pointer, thread_local_data_header + 32) : 0;
    u64 thread_local_zero_address = thread_local_zero_header ? link_read_u64(aarch64_tls_executable.executable.pointer, thread_local_zero_header + 16) : 0;
    u64 thread_local_zero_size = thread_local_zero_header ? link_read_u64(aarch64_tls_executable.executable.pointer, thread_local_zero_header + 32) : 0;
    u64 tls_got_address = tls_got_header ? link_read_u64(aarch64_tls_executable.executable.pointer, tls_got_header + 16) : 0;
    u64 tls_got_size = tls_got_header ? link_read_u64(aarch64_tls_executable.executable.pointer, tls_got_header + 32) : 0;
    u64 tls_dynamic_address = tls_dynamic_header ? link_read_u64(aarch64_tls_executable.executable.pointer, tls_dynamic_header + 16) : 0;
    u64 tls_dynamic_size = tls_dynamic_header ? link_read_u64(aarch64_tls_executable.executable.pointer, tls_dynamic_header + 32) : 0;
    BUSTER_TEST(arguments, thread_local_data_header && link_read_u32(aarch64_tls_executable.executable.pointer, thread_local_data_header + 4) == 1 &&
                               (link_read_u64(aarch64_tls_executable.executable.pointer, thread_local_data_header + 8) & UINT64_C(0x403)) == UINT64_C(0x403));
    BUSTER_TEST(arguments, thread_local_zero_header && link_read_u32(aarch64_tls_executable.executable.pointer, thread_local_zero_header + 4) == 8 &&
                               (link_read_u64(aarch64_tls_executable.executable.pointer, thread_local_zero_header + 8) & UINT64_C(0x403)) == UINT64_C(0x403));
    BUSTER_TEST(arguments, tls_got_address + tls_got_size <= tls_dynamic_address);
    BUSTER_TEST(arguments, tls_dynamic_address + tls_dynamic_size <= thread_local_data_address);
    BUSTER_TEST(arguments, thread_local_data_address + thread_local_data_size <= thread_local_zero_address);
    BUSTER_TEST(arguments, thread_local_zero_size == 32);
    u32 aarch64_data_main_instructions[] = {
        0x58000049, 0x14000003, 0, 0,
    };
    ObjectSymbol aarch64_data_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(aarch64_data_main_instructions),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("external_value"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectRelocation aarch64_data_relocation = {
        .offset = 2 * sizeof(u32),
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_ABSOLUTE64,
    };
    ObjectFile aarch64_data_object = link_test_object_make(arguments->arena, (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_WINDOWS},
                                                            (ByteSlice){
                                                                .pointer = (u8*)aarch64_data_main_instructions,
                                                                .length = sizeof(aarch64_data_main_instructions),
                                                            },
                                                            aarch64_data_symbols, BUSTER_ARRAY_LENGTH(aarch64_data_symbols), &aarch64_data_relocation, 1);
    String8 aarch64_data_exports[] = {
        S8("external_value"),
    };
    NativeDynamicLibrary aarch64_data_library = {
        .name = S8("external.dll"),
        .exported_symbols = aarch64_data_exports,
        .exported_symbol_count = BUSTER_ARRAY_LENGTH(aarch64_data_exports),
    };
    NativeExecutableLinkResult aarch64_data_executable = link_native_executable(arguments->arena, &aarch64_data_object,
                                                                                  (NativeExecutableLinkOptions){
                                                                                      .entry_symbol = S8("main"),
                                                                                      .dynamic_libraries = &aarch64_data_library,
                                                                                      .dynamic_library_count = 1,
                                                                                  });
    BUSTER_TEST(arguments, aarch64_data_executable.error == LINK_ERROR_NONE);
    // The hosted ARM64 stub is twelve words: its two-pair frame, three UCRT
    // argv queries, main/exit and the terminating trap.
    u64 aarch64_data_text_offset = 0x400 + align_forward(12 * sizeof(u32), 16);
    BUSTER_TEST(arguments, aarch64_data_executable.executable.length > aarch64_data_text_offset + 12 &&
                           link_read_u32(aarch64_data_executable.executable.pointer, aarch64_data_text_offset + 8) == UINT32_C(0x14000002));
    // An undefined weak symbol is worth address zero, not a dynamic import.
    // That is ELF's answer for a reference nothing defines, and reading it is
    // how musl's startup tells a static program from a dynamic one -- it
    // takes the address of a weak hidden `_DYNAMIC` and finds zero.
    //
    // Which party answers is the question of whether the reference can be
    // preempted, so the same object is put through both shapes. A hidden
    // reference is settled here and must not be what drags a dynamic loader
    // into the image; a default-visibility one is left in .dynsym for the
    // loader, bound weakly so that finding no definition leaves it zero
    // instead of failing the load.
    {
        // lea weak_absent(%rip), %rdi ; ret
        u8 weak_text[] = {0x48, 0x8d, 0x3d, 0, 0, 0, 0, 0xc3};
        ObjectSymbol weak_symbols[] = {
            {
                .name = S8("main"),
                .size = sizeof(weak_text),
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
            {
                .name = S8("weak_absent"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_DATA,
                .global = true,
                .weak = true,
                .hidden = true,
            },
            {
                .name = S8("imported"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
        };
        ObjectRelocation weak_relocation = {
            .addend = -4,
            .offset = 3,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_X86_64_PC32,
        };
        Target weak_target = target;
        weak_target.cpu_arch = CPU_ARCH_X86_64;
        weak_target.os = OPERATING_SYSTEM_LINUX;
        ObjectFile weak_object = link_test_object_make(arguments->arena, weak_target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(weak_text), weak_symbols, 2,
                                                       &weak_relocation, 1);
        NativeExecutableLinkResult weak_static = link_native_executable(arguments->arena, &weak_object,
                                                                       (NativeExecutableLinkOptions){
                                                                           .entry_symbol = S8("main"),
                                                                       });
        BUSTER_TEST(arguments, weak_static.error == LINK_ERROR_NONE);
        // The reference is the image's only undefined symbol, so a linker that
        // imported it would have produced the dynamic shape instead.
        BUSTER_TEST(arguments, !link_test_elf_section_find(weak_static.executable, S8(".dynsym"), 0, 0));
        BUSTER_TEST(arguments, link_test_elf_relative_symbol_address(weak_static.executable, weak_relocation.offset, weak_relocation.addend) == 0);

        // The same reference in an image that does need the loader, because
        // something else in it is a real import.
        ObjectFile weak_hosted_object = weak_object;
        weak_hosted_object.symbol_count = BUSTER_ARRAY_LENGTH(weak_symbols);
        NativeExecutableLinkResult weak_hosted = link_native_executable(arguments->arena, &weak_hosted_object,
                                                                        (NativeExecutableLinkOptions){
                                                                            .entry_symbol = S8("main"),
                                                                        });
        BUSTER_TEST(arguments, weak_hosted.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, link_test_elf_relative_symbol_address(weak_hosted.executable, weak_relocation.offset, weak_relocation.addend) == 0);
        u64 weak_hosted_dynamic_symbols = 0;
        BUSTER_TEST(arguments, link_test_elf_section_find(weak_hosted.executable, S8(".dynsym"), 0, &weak_hosted_dynamic_symbols));
        if (weak_hosted_dynamic_symbols)
        {
            // The null entry, `imported`, `__cxa_atexit` and the `exit` the hosted entry stub
            // calls -- and not `weak_absent`, which would make a fifth
            // 24-byte ELF64 symbol.
            BUSTER_TEST(arguments, link_read_u64(weak_hosted.executable.pointer, weak_hosted_dynamic_symbols + 32) == 4 * 24);
        }

        // Default visibility instead, in a link that knows nothing about what
        // its libraries export -- these options name none, so `exports_known`
        // is false and an absent name is ignorance rather than evidence. The
        // reference stays an import, and it is STB_WEAK (0x2 over STT_OBJECT)
        // so that a loader which finds no definition answers zero rather than
        // refusing the image.
        ObjectSymbol weak_visible_symbols[BUSTER_ARRAY_LENGTH(weak_symbols)];
        memcpy(weak_visible_symbols, weak_symbols, sizeof(weak_symbols));
        weak_visible_symbols[1].hidden = false;
        ObjectFile weak_visible_object = weak_object;
        weak_visible_object.symbols = weak_visible_symbols;
        NativeExecutableLinkResult weak_visible = link_native_executable(arguments->arena, &weak_visible_object,
                                                                         (NativeExecutableLinkOptions){
                                                                             .entry_symbol = S8("main"),
                                                                         });
        BUSTER_TEST(arguments, weak_visible.error == LINK_ERROR_NONE);
        u64 weak_visible_dynamic_symbols = 0;
        BUSTER_TEST(arguments, link_test_elf_section_find(weak_visible.executable, S8(".dynsym"), 0, &weak_visible_dynamic_symbols));
        if (weak_visible_dynamic_symbols)
        {
            // Entry one, the first import, past the null entry an ELF symbol
            // table opens with; 24 is the ELF64 symbol size and 4 the offset
            // of st_info within it.
            u64 dynamic_symbol_offset = link_read_u64(weak_visible.executable.pointer, weak_visible_dynamic_symbols + 24);
            BUSTER_TEST(arguments, link_read_u64(weak_visible.executable.pointer, weak_visible_dynamic_symbols + 32) == 4 * 24);
            BUSTER_TEST(arguments, weak_visible.executable.pointer[dynamic_symbol_offset + 24 + 4] == 0x21);
        }

        // The same reference once the link has read its libraries. Nothing
        // exports `weak_absent`, so there is no loader to ask and the linker
        // owes it the zero `ld` gives it: it leaves .dynsym entirely, which
        // is what keeps its own copy slot from being the non-zero answer
        // (issue #656). `imported` is strong, so a complete export list must
        // now publish it -- and `exit`, which the hosted entry stub's own
        // call appends -- or the link is refused as unresolved rather than
        // silently deferred to the loader.
        NativeDynamicVersionedSymbol weak_known_exports[] = {
            {.name = S8("unrelated"), .has_default = true},
            {.name = S8("imported"), .has_default = true},
            {.name = S8("exit"), .has_default = true},
            {.name = S8("__cxa_atexit"), .has_default = true},
            {.name = S8("atexit"), .has_default = true},
        };
        NativeExecutableLinkOptions weak_known_options = {
            .entry_symbol = S8("main"),
            .runtime_versioned_symbols = weak_known_exports,
            .runtime_versioned_symbol_count = BUSTER_ARRAY_LENGTH(weak_known_exports),
            .runtime_exports_known = true,
        };
        // Three symbols, so that `imported` keeps the image dynamic whatever
        // the weak reference resolves to: this is a test about which of them
        // reaches .dynsym, not about which writer runs.
        ObjectFile weak_visible_hosted_object = weak_visible_object;
        weak_visible_hosted_object.symbol_count = BUSTER_ARRAY_LENGTH(weak_visible_symbols);
        NativeExecutableLinkResult weak_known = link_native_executable(arguments->arena, &weak_visible_hosted_object, weak_known_options);
        BUSTER_TEST(arguments, weak_known.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, link_test_elf_relative_symbol_address(weak_known.executable, weak_relocation.offset, weak_relocation.addend) == 0);
        u64 weak_known_dynamic_symbols = 0;
        BUSTER_TEST(arguments, link_test_elf_section_find(weak_known.executable, S8(".dynsym"), 0, &weak_known_dynamic_symbols));
        if (weak_known_dynamic_symbols)
        {
            BUSTER_TEST(arguments, link_read_u64(weak_known.executable.pointer, weak_known_dynamic_symbols + 32) == 4 * 24);
        }

        // And a library that does define it: the loader can answer, so the
        // reference is promoted back to an import. This is the half that must
        // not regress -- a weak reference to `puts` still has to reach libc.
        NativeDynamicVersionedSymbol weak_defined_exports[] = {
            {.name = S8("weak_absent"), .has_default = true},
            {.name = S8("imported"), .has_default = true},
            {.name = S8("exit"), .has_default = true},
            {.name = S8("__cxa_atexit"), .has_default = true},
            {.name = S8("atexit"), .has_default = true},
        };
        NativeExecutableLinkOptions weak_defined_options = weak_known_options;
        weak_defined_options.runtime_versioned_symbols = weak_defined_exports;
        weak_defined_options.runtime_versioned_symbol_count = BUSTER_ARRAY_LENGTH(weak_defined_exports);
        NativeExecutableLinkResult weak_defined = link_native_executable(arguments->arena, &weak_visible_hosted_object, weak_defined_options);
        BUSTER_TEST(arguments, weak_defined.error == LINK_ERROR_NONE);
        u64 weak_defined_dynamic_symbols = 0;
        BUSTER_TEST(arguments, link_test_elf_section_find(weak_defined.executable, S8(".dynsym"), 0, &weak_defined_dynamic_symbols));
        if (weak_defined_dynamic_symbols)
        {
            u64 dynamic_symbol_offset = link_read_u64(weak_defined.executable.pointer, weak_defined_dynamic_symbols + 24);
            BUSTER_TEST(arguments, link_read_u64(weak_defined.executable.pointer, weak_defined_dynamic_symbols + 32) == 5 * 24);
            BUSTER_TEST(arguments, weak_defined.executable.pointer[dynamic_symbol_offset + 24 + 4] == 0x21);
        }

        // A definition an unversioned reference cannot bind to is not a
        // definition. Every `name@VER` glibc publishes for `sys_errlist` is
        // non-default, and a strong reference to such a name is refused with
        // LINK_ERROR_SYMBOL_VERSION; a weak one is worth zero instead, which
        // is the same answer as for a name no library has at all.
        NativeDynamicVersionedSymbol weak_hidden_version_exports[] = {
            {.name = S8("weak_absent"), .version = S8("GLIBC_2.2.5")},
            {.name = S8("imported"), .has_default = true},
            {.name = S8("exit"), .has_default = true},
            {.name = S8("__cxa_atexit"), .has_default = true},
            {.name = S8("atexit"), .has_default = true},
        };
        NativeExecutableLinkOptions weak_hidden_version_options = weak_known_options;
        weak_hidden_version_options.runtime_versioned_symbols = weak_hidden_version_exports;
        weak_hidden_version_options.runtime_versioned_symbol_count = BUSTER_ARRAY_LENGTH(weak_hidden_version_exports);
        NativeExecutableLinkResult weak_hidden_version = link_native_executable(arguments->arena, &weak_visible_hosted_object, weak_hidden_version_options);
        BUSTER_TEST(arguments, weak_hidden_version.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments,
                    link_test_elf_relative_symbol_address(weak_hidden_version.executable, weak_relocation.offset, weak_relocation.addend) == 0);

        // A strong reference is owed the opposite answer: with every export
        // list read and no library publishing `imported`, the link is
        // refused with the name -- ld's "undefined reference" -- rather than
        // emitted as a .dynsym entry the loader will fault on.  Every
        // autoconf AC_CHECK_FUNC probe reads this difference.
        NativeDynamicVersionedSymbol strong_absent_exports[] = {
            {.name = S8("weak_absent"), .has_default = true},
            {.name = S8("exit"), .has_default = true},
            {.name = S8("__cxa_atexit"), .has_default = true},
            {.name = S8("atexit"), .has_default = true},
        };
        NativeExecutableLinkOptions strong_absent_options = weak_known_options;
        strong_absent_options.runtime_versioned_symbols = strong_absent_exports;
        strong_absent_options.runtime_versioned_symbol_count = BUSTER_ARRAY_LENGTH(strong_absent_exports);
        NativeExecutableLinkResult strong_absent = link_native_executable(arguments->arena, &weak_visible_hosted_object, strong_absent_options);
        BUSTER_TEST(arguments, strong_absent.error == LINK_ERROR_UNRESOLVED_SYMBOL);
        BUSTER_TEST(arguments, string_equal(strong_absent.symbol, S8("imported")));

        // A library the driver could not read is what `exports_known` is for:
        // one unread library and the link is back to not knowing, whatever
        // the runtime's own list says.
        NativeDynamicLibrary weak_unread_library = {
            .name = S8("libunread.so.1"),
        };
        NativeExecutableLinkOptions weak_unread_options = weak_known_options;
        weak_unread_options.dynamic_libraries = &weak_unread_library;
        weak_unread_options.dynamic_library_count = 1;
        NativeExecutableLinkResult weak_unread = link_native_executable(arguments->arena, &weak_visible_hosted_object, weak_unread_options);
        BUSTER_TEST(arguments, weak_unread.error == LINK_ERROR_NONE);
        u64 weak_unread_dynamic_symbols = 0;
        BUSTER_TEST(arguments, link_test_elf_section_find(weak_unread.executable, S8(".dynsym"), 0, &weak_unread_dynamic_symbols));
        if (weak_unread_dynamic_symbols)
        {
            BUSTER_TEST(arguments, link_read_u64(weak_unread.executable.pointer, weak_unread_dynamic_symbols + 32) == 5 * 24);
        }

        // AArch64 asks the question of two more writers. The static one
        // relocates a 32-bit PC-relative word against zero; the dynamic one
        // must branch to zero rather than through a PLT thunk it did not
        // reserve.
        u32 weak_aarch64_instructions[] = {
            0x94000000,
            0xd65f03c0,
            0,
        };
        ObjectSymbol weak_aarch64_symbols[] = {
            {
                .name = S8("main"),
                .size = 8,
                .section = OBJECT_SECTION_TEXT,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
            {
                .name = S8("weak_absent"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
                .weak = true,
                .hidden = true,
            },
            {
                .name = S8("imported"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_FUNCTION,
                .global = true,
            },
        };
        ObjectRelocation weak_aarch64_relocations[] = {
            {.section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_CALL26},
            {.offset = 8, .section = OBJECT_SECTION_TEXT, .symbol = 1, .kind = OBJECT_RELOCATION_AARCH64_PREL32},
        };
        Target weak_aarch64_target = target;
        weak_aarch64_target.cpu_arch = CPU_ARCH_AARCH64;
        weak_aarch64_target.os = OPERATING_SYSTEM_LINUX;
        ObjectFile weak_aarch64_object = link_test_object_make(arguments->arena, weak_aarch64_target,
                                                               (ByteSlice){
                                                                   .pointer = (u8*)weak_aarch64_instructions,
                                                                   .length = sizeof(weak_aarch64_instructions),
                                                               },
                                                               weak_aarch64_symbols, 2, weak_aarch64_relocations,
                                                               BUSTER_ARRAY_LENGTH(weak_aarch64_relocations));
        NativeExecutableLinkResult weak_aarch64_static = link_native_executable(arguments->arena, &weak_aarch64_object,
                                                                                (NativeExecutableLinkOptions){
                                                                                    .entry_symbol = S8("main"),
                                                                                });
        BUSTER_TEST(arguments, weak_aarch64_static.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, !link_test_elf_section_find(weak_aarch64_static.executable, S8(".dynsym"), 0, 0));
        BUSTER_TEST(arguments, link_test_elf_relative_symbol_address(weak_aarch64_static.executable, 8, 0) == 0);
        BUSTER_TEST(arguments, link_test_elf_branch_symbol_address(weak_aarch64_static.executable, 0) == 0);
        ObjectFile weak_aarch64_hosted_object = weak_aarch64_object;
        weak_aarch64_hosted_object.symbol_count = BUSTER_ARRAY_LENGTH(weak_aarch64_symbols);
        NativeExecutableLinkResult weak_aarch64_hosted = link_native_executable(arguments->arena, &weak_aarch64_hosted_object,
                                                                                (NativeExecutableLinkOptions){
                                                                                    .entry_symbol = S8("main"),
                                                                                });
        BUSTER_TEST(arguments, weak_aarch64_hosted.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, link_test_elf_relative_symbol_address(weak_aarch64_hosted.executable, 8, 0) == 0);
        BUSTER_TEST(arguments, link_test_elf_branch_symbol_address(weak_aarch64_hosted.executable, 0) == 0);
        // Default visibility and a read export list that lacks the name, on
        // the writer that re-derives the x86-64 writer's import numbering:
        // the branch has to reach zero here too, and it can only do that if
        // both writers agreed the reference is not an import.
        ObjectSymbol weak_aarch64_visible_symbols[BUSTER_ARRAY_LENGTH(weak_aarch64_symbols)];
        memcpy(weak_aarch64_visible_symbols, weak_aarch64_symbols, sizeof(weak_aarch64_symbols));
        weak_aarch64_visible_symbols[1].hidden = false;
        ObjectFile weak_aarch64_visible_object = weak_aarch64_hosted_object;
        weak_aarch64_visible_object.symbols = weak_aarch64_visible_symbols;
        NativeExecutableLinkResult weak_aarch64_known = link_native_executable(arguments->arena, &weak_aarch64_visible_object, weak_known_options);
        BUSTER_TEST(arguments, weak_aarch64_known.error == LINK_ERROR_NONE);
        BUSTER_TEST(arguments, link_test_elf_relative_symbol_address(weak_aarch64_known.executable, 8, 0) == 0);
        BUSTER_TEST(arguments, link_test_elf_branch_symbol_address(weak_aarch64_known.executable, 0) == 0);

        // What merging inputs does with the two bits. One strong reference is
        // what makes a symbol required, whichever object it arrives in, and a
        // single hidden occurrence keeps the symbol out of .dynsym.
        ObjectSymbol weak_merge_first[] = {
            {
                .name = S8("both_weak"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_DATA,
                .global = true,
                .weak = true,
                .hidden = true,
            },
            {
                .name = S8("weak_then_strong"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_DATA,
                .global = true,
                .weak = true,
                .hidden = true,
            },
        };
        ObjectSymbol weak_merge_second[] = {
            {
                .name = S8("both_weak"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_DATA,
                .global = true,
                .weak = true,
            },
            {
                .name = S8("weak_then_strong"),
                .section = OBJECT_SECTION_UNDEFINED,
                .kind = OBJECT_SYMBOL_DATA,
                .global = true,
            },
        };
        u8 weak_merge_text[8] = {0};
        ObjectFile weak_merge_objects[] = {
            link_test_object_make(arguments->arena, weak_target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(weak_merge_text), weak_merge_first,
                                  BUSTER_ARRAY_LENGTH(weak_merge_first), 0, 0),
            link_test_object_make(arguments->arena, weak_target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(weak_merge_text), weak_merge_second,
                                  BUSTER_ARRAY_LENGTH(weak_merge_second), 0, 0),
        };
        LinkObjectResult weak_merged = link_objects(arguments->arena, weak_merge_objects, BUSTER_ARRAY_LENGTH(weak_merge_objects),
                                                     (LinkOptions){
                                                         .allow_undefined_symbols = true,
                                                     });
        BUSTER_TEST(arguments, weak_merged.error == LINK_ERROR_NONE && weak_merged.object.symbol_count == 2);
        if (weak_merged.error == LINK_ERROR_NONE && weak_merged.object.symbol_count == 2)
        {
            BUSTER_TEST(arguments, weak_merged.object.symbols[0].weak && weak_merged.object.symbols[0].hidden);
            BUSTER_TEST(arguments, !weak_merged.object.symbols[1].weak && weak_merged.object.symbols[1].hidden);
        }
    }
    ObjectFile aarch64_pe_object = aarch64_object;
    aarch64_pe_object.target.os = OPERATING_SYSTEM_WINDOWS;
    String8 aarch64_pe_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-aarch64-pe-test"), S8(".exe"));
    NativeExecutableLinkResult aarch64_pe_executable = link_native_executable(arguments->arena, &aarch64_pe_object,
                                                                              (NativeExecutableLinkOptions){
                                                                                  .output_path = aarch64_pe_output_path,
                                                                                  .entry_symbol = S8("main"),
                                                                              });
    BUSTER_TEST(arguments, aarch64_pe_executable.error == LINK_ERROR_NONE);
    bool aarch64_pe_header_valid = aarch64_pe_executable.executable.length > 0x88 && aarch64_pe_executable.executable.pointer[0x84] == 0x64 &&
                                   aarch64_pe_executable.executable.pointer[0x85] == 0xaa;
    BUSTER_TEST(arguments, aarch64_pe_header_valid);
    ObjectFile aarch64_pe_libc_object = aarch64_libc_object;
    aarch64_pe_libc_object.target.os = OPERATING_SYSTEM_WINDOWS;
    NativeExecutableLinkResult aarch64_pe_libc_executable = link_native_executable(arguments->arena, &aarch64_pe_libc_object,
                                                                                   (NativeExecutableLinkOptions){
                                                                                       .entry_symbol = S8("main"),
                                                                                   });
    BUSTER_TEST(arguments, aarch64_pe_libc_executable.error == LINK_ERROR_NONE);
    aarch64_libc_relocation.addend = 4;
    NativeExecutableLinkResult aarch64_pe_import_addend =
        link_native_executable(arguments->arena, &aarch64_pe_libc_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_pe_import_addend.error == LINK_ERROR_RELOCATION);
    aarch64_libc_relocation.addend = 0;
    ObjectFile android_object = aarch64_libc_object;
    android_object.target.os = OPERATING_SYSTEM_ANDROID;
    String8 android_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-android-test"), S8(""));
    NativeExecutableLinkResult android_executable = link_native_executable(arguments->arena, &android_object,
                                                                           (NativeExecutableLinkOptions){
                                                                               .output_path = android_output_path,
                                                                               .entry_symbol = S8("main"),
                                                                           });
    BUSTER_TEST(arguments, android_executable.error == LINK_ERROR_NONE);
    bool android_header_valid =
        android_executable.executable.length > 18 && android_executable.executable.pointer[16] == 3 && android_executable.executable.pointer[17] == 0;
    BUSTER_TEST(arguments, android_header_valid);
    ObjectFile aarch64_mach_object = aarch64_object;
    aarch64_mach_object.target.os = OPERATING_SYSTEM_MACOS;
    String8 aarch64_mach_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-aarch64-macho-test"), S8(""));
    NativeExecutableLinkResult aarch64_mach_executable = link_native_executable(arguments->arena, &aarch64_mach_object,
                                                                                (NativeExecutableLinkOptions){
                                                                                    .output_path = aarch64_mach_output_path,
                                                                                    .entry_symbol = S8("main"),
                                                                                });
    BUSTER_TEST(arguments, aarch64_mach_executable.error == LINK_ERROR_NONE);
    bool aarch64_mach_header_valid = aarch64_mach_executable.executable.length > 32 && aarch64_mach_executable.executable.pointer[0] == 0xcf &&
                                     aarch64_mach_executable.executable.pointer[1] == 0xfa && aarch64_mach_executable.executable.pointer[2] == 0xed &&
                                     aarch64_mach_executable.executable.pointer[3] == 0xfe && (aarch64_mach_executable.executable.pointer[26] & 0x20) != 0;
    BUSTER_TEST(arguments, aarch64_mach_header_valid);
    CodegenFunctionDescriptor aarch64_mach_cfi_descriptor = {
        .code_size = (u32)sizeof(aarch64_main_instructions),
    };
    DwarfCfiResult aarch64_mach_cfi = dwarf_cfi_build(arguments->arena, (DwarfCfiInput){
                                                                            .functions = &aarch64_mach_cfi_descriptor,
                                                                            .target = aarch64_mach_object.target,
                                                                            .function_count = 1,
                                                                        });
    BUSTER_TEST(arguments, aarch64_mach_cfi.valid && aarch64_mach_cfi.relocation_count == 1);
    ObjectRelocation aarch64_mach_cfi_relocation = {
        .offset = aarch64_mach_cfi.relocations[0].offset,
        .section = OBJECT_SECTION_UNWIND,
        .symbol = 0,
        .kind = OBJECT_RELOCATION_AARCH64_PREL32,
    };
    ObjectFile aarch64_mach_cfi_object = aarch64_mach_object;
    ObjectSection* aarch64_mach_cfi_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
    memcpy(aarch64_mach_cfi_sections, aarch64_mach_object.sections, sizeof(*aarch64_mach_cfi_sections) * OBJECT_SECTION_COUNT);
    aarch64_mach_cfi_object.sections = aarch64_mach_cfi_sections;
    aarch64_mach_cfi_sections[OBJECT_SECTION_UNWIND].data = aarch64_mach_cfi.bytes;
    aarch64_mach_cfi_object.relocations = &aarch64_mach_cfi_relocation;
    aarch64_mach_cfi_object.relocation_count = 1;
    NativeExecutableLinkResult aarch64_mach_cfi_executable = link_native_executable(arguments->arena, &aarch64_mach_cfi_object,
                                                                                   (NativeExecutableLinkOptions){
                                                                                       .entry_symbol = S8("main"),
                                                                                   });
    BUSTER_TEST(arguments, aarch64_mach_cfi_executable.error == LINK_ERROR_NONE);
    u64 aarch64_mach_cfi_section = 0;
    bool aarch64_mach_cfi_found =
        link_test_mach_section_find(aarch64_mach_cfi_executable.executable, S8("__TEXT"), S8("__eh_frame"), &aarch64_mach_cfi_section);
    BUSTER_TEST(arguments, aarch64_mach_cfi_found);
    if (aarch64_mach_cfi_found)
    {
        BUSTER_TEST(arguments, link_read_u32(aarch64_mach_cfi_executable.executable.pointer, aarch64_mach_cfi_section + 64) == 0x6800000b);
        u64 unwind_address = link_read_u64(aarch64_mach_cfi_executable.executable.pointer, aarch64_mach_cfi_section + 32);
        u64 unwind_offset = link_read_u32(aarch64_mach_cfi_executable.executable.pointer, aarch64_mach_cfi_section + 48);
        s32 function_displacement = 0;
        memcpy(&function_displacement, aarch64_mach_cfi_executable.executable.pointer + unwind_offset + aarch64_mach_cfi.relocations[0].offset,
               sizeof(function_displacement));
        BUSTER_TEST(arguments, (s64)unwind_address + (s64)aarch64_mach_cfi.relocations[0].offset + function_displacement ==
                                   (s64)UINT64_C(0x100000000) + (s64)align_forward(32 + link_read_u32(aarch64_mach_cfi_executable.executable.pointer, 20), 16));
    }
    u32 aarch64_mach_data_instructions[] = {
        0x58000049, 0x14000003, 0, 0, 0x52800000, 0xd65f03c0,
    };
    u64 aarch64_mach_data_value = 42;
    ObjectSymbol aarch64_mach_data_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(aarch64_mach_data_instructions),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("data"),
            .size = sizeof(aarch64_mach_data_value),
            .section = OBJECT_SECTION_DATA,
            .kind = OBJECT_SYMBOL_DATA,
            .global = true,
        },
    };
    ObjectRelocation aarch64_mach_data_relocation = {
        .offset = 2 * sizeof(u32),
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_ABSOLUTE64,
    };
    ObjectFile aarch64_mach_data_object =
        link_test_object_make(arguments->arena, aarch64_mach_object.target,
                              (ByteSlice){
                                  .pointer = (u8*)aarch64_mach_data_instructions,
                                  .length = sizeof(aarch64_mach_data_instructions),
                              },
                              aarch64_mach_data_symbols, BUSTER_ARRAY_LENGTH(aarch64_mach_data_symbols), &aarch64_mach_data_relocation, 1);
    aarch64_mach_data_object.sections[OBJECT_SECTION_DATA].data = (ByteSlice){
        .pointer = (u8*)&aarch64_mach_data_value,
        .length = sizeof(aarch64_mach_data_value),
    };
    String8 aarch64_mach_data_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-aarch64-macho-data-test"), S8(""));
    NativeExecutableLinkResult aarch64_mach_data_executable = link_native_executable(arguments->arena, &aarch64_mach_data_object,
                                                                                     (NativeExecutableLinkOptions){
                                                                                         .output_path = aarch64_mach_data_output_path,
                                                                                         .entry_symbol = S8("main"),
                                                                                     });
    BUSTER_TEST(arguments, aarch64_mach_data_executable.error == LINK_ERROR_NONE);
    u32 aarch64_mach_data_adrp = 0;
    u32 aarch64_mach_data_add = 0;
    u32 aarch64_mach_data_branch = 0;
    if (aarch64_mach_data_executable.error == LINK_ERROR_NONE && aarch64_mach_data_executable.executable.length > 32)
    {
        u64 aarch64_mach_data_text_offset = align_forward(32 + link_read_u32(aarch64_mach_data_executable.executable.pointer, 20), 16);
        if (aarch64_mach_data_text_offset <= aarch64_mach_data_executable.executable.length &&
            3 * sizeof(u32) <= aarch64_mach_data_executable.executable.length - aarch64_mach_data_text_offset)
        {
            aarch64_mach_data_adrp = link_read_u32(aarch64_mach_data_executable.executable.pointer, aarch64_mach_data_text_offset);
            aarch64_mach_data_add = link_read_u32(aarch64_mach_data_executable.executable.pointer, aarch64_mach_data_text_offset + sizeof(u32));
            aarch64_mach_data_branch = link_read_u32(aarch64_mach_data_executable.executable.pointer, aarch64_mach_data_text_offset + 2 * sizeof(u32));
        }
    }
    BUSTER_TEST(arguments, (aarch64_mach_data_adrp & UINT32_C(0x9f00001f)) == UINT32_C(0x90000009));
    BUSTER_TEST(arguments, (aarch64_mach_data_add & UINT32_C(0xffc003ff)) == UINT32_C(0x91000129));
    BUSTER_TEST(arguments, aarch64_mach_data_branch == UINT32_C(0x14000002));
    // ABS64 addends are signed at the object boundary but the patched slot
    // is an unsigned address.  Exercise the exact two's-complement limits
    // and the valid -1 case through the final Darwin linker.
    s64 aarch64_mach_abs64_addends[] = {INT64_MIN, INT64_MAX, -1};
    for (u32 addend_index = 0; addend_index < BUSTER_ARRAY_LENGTH(aarch64_mach_abs64_addends); addend_index += 1)
    {
        aarch64_mach_data_relocation.addend = aarch64_mach_abs64_addends[addend_index];
        NativeExecutableLinkResult abs64_addend_link = link_native_executable(
            arguments->arena, &aarch64_mach_data_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
        if (aarch64_mach_abs64_addends[addend_index] == -1)
        {
            BUSTER_TEST(arguments, abs64_addend_link.error == LINK_ERROR_NONE);
        }
        else
        {
            BUSTER_TEST(arguments, abs64_addend_link.error == LINK_ERROR_RELOCATION);
        }
    }
    aarch64_mach_data_relocation.addend = 0;
    u32 aarch64_mach_direct_instructions[] = {
        UINT32_C(0x90000009), UINT32_C(0x91000129), UINT32_C(0x14000002), UINT32_C(0xd65f03c0),
    };
    ObjectRelocation aarch64_mach_direct_relocations[] = {
        {
            .offset = 0,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGE21,
        },
        {
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12,
        },
    };
    ObjectFile aarch64_mach_direct_object = link_test_object_make(
        arguments->arena, aarch64_mach_object.target,
        (ByteSlice){.pointer = (u8*)aarch64_mach_direct_instructions, .length = sizeof(aarch64_mach_direct_instructions)},
        aarch64_mach_data_symbols, BUSTER_ARRAY_LENGTH(aarch64_mach_data_symbols), aarch64_mach_direct_relocations,
        BUSTER_ARRAY_LENGTH(aarch64_mach_direct_relocations));
    aarch64_mach_direct_object.sections[OBJECT_SECTION_DATA].data = (ByteSlice){
        .pointer = (u8*)&aarch64_mach_data_value,
        .length = sizeof(aarch64_mach_data_value),
    };
    NativeExecutableLinkResult aarch64_mach_direct_executable =
        link_native_executable(arguments->arena, &aarch64_mach_direct_object,
                               (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_direct_executable.error == LINK_ERROR_NONE);
    if (aarch64_mach_direct_executable.error == LINK_ERROR_NONE && aarch64_mach_direct_executable.executable.length > 32)
    {
        u64 direct_text_offset = align_forward(32 + link_read_u32(aarch64_mach_direct_executable.executable.pointer, 20), 16);
        u32 direct_adrp = link_read_u32(aarch64_mach_direct_executable.executable.pointer, direct_text_offset);
        u32 direct_add = link_read_u32(aarch64_mach_direct_executable.executable.pointer, direct_text_offset + sizeof(u32));
        BUSTER_TEST(arguments, (direct_adrp & UINT32_C(0x9f00001f)) == UINT32_C(0x90000009));
        BUSTER_TEST(arguments, (direct_add & UINT32_C(0xffc003ff)) == UINT32_C(0x91000129));
    }

    u32 aarch64_mach_function_roundtrip_instructions[] = {
        UINT32_C(0x90000009), UINT32_C(0x91000129), UINT32_C(0xd65f03c0),
    };
    ObjectSymbol aarch64_mach_function_roundtrip_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(aarch64_mach_function_roundtrip_instructions),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("function_address_import"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectRelocation aarch64_mach_function_roundtrip_relocations[] = {
        {
            .offset = 0,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGE21,
        },
        {
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12,
        },
    };
    ObjectFile aarch64_mach_function_roundtrip_object = link_test_object_make(
        arguments->arena, aarch64_mach_object.target,
        (ByteSlice){.pointer = (u8*)aarch64_mach_function_roundtrip_instructions,
                    .length = sizeof(aarch64_mach_function_roundtrip_instructions)},
        aarch64_mach_function_roundtrip_symbols, BUSTER_ARRAY_LENGTH(aarch64_mach_function_roundtrip_symbols),
        aarch64_mach_function_roundtrip_relocations, BUSTER_ARRAY_LENGTH(aarch64_mach_function_roundtrip_relocations));
    NativeExecutableLinkResult aarch64_mach_function_in_memory_link = link_native_executable(
        arguments->arena, &aarch64_mach_function_roundtrip_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_function_in_memory_link.error == LINK_ERROR_NONE);
    ObjectArtifact aarch64_mach_function_roundtrip_artifact =
        object_write(arguments->arena, &aarch64_mach_function_roundtrip_object, OBJECT_FORMAT_MACH_O64);
    ObjectFile aarch64_mach_function_roundtrip_read = object_read(
        arguments->arena, aarch64_mach_function_roundtrip_artifact.bytes,
        (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    BUSTER_TEST(arguments, aarch64_mach_function_roundtrip_artifact.error == OBJECT_ERROR_NONE &&
                               aarch64_mach_function_roundtrip_read.error == OBJECT_ERROR_NONE &&
                               aarch64_mach_function_roundtrip_read.symbol_count >= 2 &&
                               aarch64_mach_function_roundtrip_read.symbols[1].kind == OBJECT_SYMBOL_DATA);
    NativeExecutableLinkResult aarch64_mach_function_roundtrip_link = link_native_executable(
        arguments->arena, &aarch64_mach_function_roundtrip_read, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_function_roundtrip_link.error != LINK_ERROR_NONE);
    aarch64_mach_function_roundtrip_symbols[1].kind = OBJECT_SYMBOL_DATA;
    ObjectArtifact aarch64_mach_data_roundtrip_artifact =
        object_write(arguments->arena, &aarch64_mach_function_roundtrip_object, OBJECT_FORMAT_MACH_O64);
    ObjectFile aarch64_mach_data_roundtrip_read = object_read(
        arguments->arena, aarch64_mach_data_roundtrip_artifact.bytes,
        (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    NativeExecutableLinkResult aarch64_mach_data_roundtrip_link = link_native_executable(
        arguments->arena, &aarch64_mach_data_roundtrip_read, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_data_roundtrip_artifact.error == OBJECT_ERROR_NONE &&
                               aarch64_mach_data_roundtrip_read.error == OBJECT_ERROR_NONE &&
                               aarch64_mach_data_roundtrip_read.symbols[1].kind == OBJECT_SYMBOL_DATA &&
                               aarch64_mach_data_roundtrip_link.error != LINK_ERROR_NONE);
    aarch64_mach_function_roundtrip_symbols[1].kind = OBJECT_SYMBOL_FUNCTION;
    aarch64_mach_function_roundtrip_read.symbols[1].kind = OBJECT_SYMBOL_FUNCTION;
    aarch64_mach_function_roundtrip_read.relocations[0].addend = INT64_MAX;
    NativeExecutableLinkResult aarch64_mach_page_overflow = link_native_executable(
        arguments->arena, &aarch64_mach_function_roundtrip_read, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_page_overflow.error == LINK_ERROR_RELOCATION);
    aarch64_mach_function_roundtrip_read.relocations[0].addend = INT64_MIN;
    NativeExecutableLinkResult aarch64_mach_page_underflow = link_native_executable(
        arguments->arena, &aarch64_mach_function_roundtrip_read, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_page_underflow.error == LINK_ERROR_RELOCATION);
    aarch64_mach_function_roundtrip_read.relocations[0].addend = 0;

    // A serialized PAGE-only reference remains ambiguous, but a coexisting
    // BRANCH26 relocation safely upgrades the imported symbol to a function.
    u32 saved_branch_assisted_instruction = aarch64_mach_function_roundtrip_instructions[2];
    ObjectRelocation aarch64_mach_branch_assisted_relocations[] = {
        aarch64_mach_function_roundtrip_relocations[0],
        aarch64_mach_function_roundtrip_relocations[1],
        {
            .offset = 2 * sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_CALL26,
        },
    };
    aarch64_mach_function_roundtrip_instructions[2] = UINT32_C(0x94000000);
    ObjectFile aarch64_mach_branch_assisted_object = aarch64_mach_function_roundtrip_object;
    aarch64_mach_branch_assisted_object.relocations = aarch64_mach_branch_assisted_relocations;
    aarch64_mach_branch_assisted_object.relocation_count = BUSTER_ARRAY_LENGTH(aarch64_mach_branch_assisted_relocations);
    ObjectArtifact aarch64_mach_branch_assisted_artifact =
        object_write(arguments->arena, &aarch64_mach_branch_assisted_object, OBJECT_FORMAT_MACH_O64);
    ObjectFile aarch64_mach_branch_assisted_read = object_read(
        arguments->arena, aarch64_mach_branch_assisted_artifact.bytes,
        (Target){.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS});
    BUSTER_TEST(arguments, aarch64_mach_branch_assisted_artifact.error == OBJECT_ERROR_NONE &&
                               aarch64_mach_branch_assisted_read.error == OBJECT_ERROR_NONE &&
                               aarch64_mach_branch_assisted_read.symbol_count >= 2 &&
                               aarch64_mach_branch_assisted_read.symbols[1].kind == OBJECT_SYMBOL_FUNCTION);
    NativeExecutableLinkResult aarch64_mach_branch_assisted_link = link_native_executable(
        arguments->arena, &aarch64_mach_branch_assisted_read, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_branch_assisted_link.error == LINK_ERROR_NONE);
    aarch64_mach_function_roundtrip_instructions[2] = saved_branch_assisted_instruction;

    // PAGE21/PAGEOFF12 are independent fixups.  Exercise LLVM's unsigned
    // LD/ST scaling (including Q registers), non-matching ADD registers,
    // separated places, and unequal addends without any synthetic pair.
    u32 aarch64_mach_page_link_instructions[] = {
        UINT32_C(0x91000041), // add x1, x2, #0
        UINT32_C(0xf9400083), // ldr x3, [x4]
        UINT32_C(0x394000c5), // ldrb w5, [x6]
        UINT32_C(0x79400107), // ldrh w7, [x8]
        UINT32_C(0x39800149), // ldrsb x9, [x10]
        UINT32_C(0x79c0018b), // ldrsh w11, [x12]
        UINT32_C(0xb98001cd), // ldrsw x13, [x14]
        UINT32_C(0x3dc0020f), // ldr q15, [x16]
        UINT32_C(0x3d80024f), // str q15, [x18]
        UINT32_C(0x9100003f), // add sp, x1, #0
        UINT32_C(0x90000003), // adrp x3, #0 (standalone)
    };
    s64 aarch64_mach_page_link_addends[] = {4, 8, 9, 10, 11, 12, 16, 32, 48, 5, 0x1000};
    u32 aarch64_mach_page_link_shifts[] = {0, 3, 0, 1, 0, 1, 2, 4, 4, 0, 0};
    ObjectRelocation aarch64_mach_page_link_relocations[BUSTER_ARRAY_LENGTH(aarch64_mach_page_link_instructions)];
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(aarch64_mach_page_link_relocations); index += 1)
    {
        aarch64_mach_page_link_relocations[index] = (ObjectRelocation){
            .addend = aarch64_mach_page_link_addends[index],
            .offset = index * sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = index + 1 == BUSTER_ARRAY_LENGTH(aarch64_mach_page_link_relocations)
                        ? OBJECT_RELOCATION_AARCH64_MACH_PAGE21
                        : OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12,
        };
    }
    ObjectFile aarch64_mach_page_link_object = link_test_object_make(
        arguments->arena, aarch64_mach_object.target,
        (ByteSlice){.pointer = (u8*)aarch64_mach_page_link_instructions, .length = sizeof(aarch64_mach_page_link_instructions)},
        aarch64_mach_data_symbols, BUSTER_ARRAY_LENGTH(aarch64_mach_data_symbols), aarch64_mach_page_link_relocations,
        BUSTER_ARRAY_LENGTH(aarch64_mach_page_link_relocations));
    aarch64_mach_page_link_object.sections[OBJECT_SECTION_DATA].data = (ByteSlice){
        .pointer = (u8*)&aarch64_mach_data_value,
        .length = sizeof(aarch64_mach_data_value),
    };
    NativeExecutableLinkResult aarch64_mach_page_link_executable =
        link_native_executable(arguments->arena, &aarch64_mach_page_link_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_page_link_executable.error == LINK_ERROR_NONE);
    if (aarch64_mach_page_link_executable.error == LINK_ERROR_NONE)
    {
        u64 text_header = 0;
        u64 data_header = 0;
        bool text_found = link_test_mach_section_find(aarch64_mach_page_link_executable.executable, S8("__TEXT"), S8("__text"), &text_header);
        bool data_found = link_test_mach_section_find(aarch64_mach_page_link_executable.executable, S8("__DATA"), S8("__data"), &data_header);
        BUSTER_TEST(arguments, text_found && data_found);
        if (text_found && data_found)
        {
            u64 text_address = link_read_u64(aarch64_mach_page_link_executable.executable.pointer, text_header + 32);
            u64 data_address = link_read_u64(aarch64_mach_page_link_executable.executable.pointer, data_header + 32);
            u64 text_file_offset = link_read_u32(aarch64_mach_page_link_executable.executable.pointer, text_header + 48);
            for (u32 index = 0; index < 10; index += 1)
            {
                u32 actual = link_read_u32(aarch64_mach_page_link_executable.executable.pointer, text_file_offset + index * sizeof(u32));
                u32 expected_immediate = (u32)(((data_address + (u64)aarch64_mach_page_link_addends[index]) & 0xfff) >>
                                                aarch64_mach_page_link_shifts[index]);
                BUSTER_TEST(arguments, ((actual >> 10) & 0xfff) == expected_immediate);
            }
            u32 expected_adrp = 0;
            bool expected_adrp_valid = a64_adrp_encode(3, text_address + 10 * sizeof(u32), data_address + 0x1000, &expected_adrp);
            u32 actual_adrp = link_read_u32(aarch64_mach_page_link_executable.executable.pointer, text_file_offset + 10 * sizeof(u32));
            BUSTER_TEST(arguments, expected_adrp_valid && actual_adrp == expected_adrp);
        }
    }
    u32 valid_pageoff_bases[] = {
        UINT32_C(0x91000000),
        UINT32_C(0x39000000), UINT32_C(0x39400000), UINT32_C(0x39800000), UINT32_C(0x39c00000),
        UINT32_C(0x79000000), UINT32_C(0x79400000), UINT32_C(0x79800000), UINT32_C(0x79c00000),
        UINT32_C(0xb9000000), UINT32_C(0xb9400000), UINT32_C(0xb9800000),
        UINT32_C(0xf9000000), UINT32_C(0xf9400000), UINT32_C(0xf9800000),
        UINT32_C(0x3d000000), UINT32_C(0x3d400000), UINT32_C(0x3d800000), UINT32_C(0x3dc00000),
        UINT32_C(0x7d000000), UINT32_C(0x7d400000),
        UINT32_C(0xbd000000), UINT32_C(0xbd400000),
        UINT32_C(0xfd000000), UINT32_C(0xfd400000),
    };
    u32 invalid_pageoff_bases[] = {
        UINT32_C(0x91800000),
        UINT32_C(0xb9c00000), UINT32_C(0xf9c00000),
        UINT32_C(0x7d800000), UINT32_C(0x7dc00000),
        UINT32_C(0xbd800000), UINT32_C(0xbdc00000),
        UINT32_C(0xfd800000), UINT32_C(0xfdc00000),
    };
    u32 saved_page_link_instruction = aarch64_mach_page_link_instructions[0];
    u32 saved_page_link_relocation_count = aarch64_mach_page_link_object.relocation_count;
    ObjectRelocation saved_page_link_relocation = aarch64_mach_page_link_relocations[0];
    aarch64_mach_page_link_object.relocation_count = 1;
    aarch64_mach_page_link_relocations[0].kind = OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12;
    aarch64_mach_page_link_relocations[0].addend = 0;
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(valid_pageoff_bases); index += 1)
    {
        aarch64_mach_page_link_instructions[0] = valid_pageoff_bases[index];
        NativeExecutableLinkResult valid_pageoff_link = link_native_executable(
            arguments->arena, &aarch64_mach_page_link_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
        BUSTER_TEST(arguments, valid_pageoff_link.error == LINK_ERROR_NONE);
    }
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(invalid_pageoff_bases); index += 1)
    {
        aarch64_mach_page_link_instructions[0] = invalid_pageoff_bases[index];
        NativeExecutableLinkResult invalid_pageoff_link = link_native_executable(
            arguments->arena, &aarch64_mach_page_link_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
        BUSTER_TEST(arguments, invalid_pageoff_link.error == LINK_ERROR_RELOCATION);
    }
    aarch64_mach_page_link_object.relocation_count = saved_page_link_relocation_count;
    aarch64_mach_page_link_relocations[0] = saved_page_link_relocation;
    aarch64_mach_page_link_instructions[0] = saved_page_link_instruction;
    u32 saved_page_link_page21 = aarch64_mach_page_link_instructions[10];
    aarch64_mach_page_link_instructions[10] = UINT32_C(0x9000001f);
    NativeExecutableLinkResult page21_xzr_link = link_native_executable(
        arguments->arena, &aarch64_mach_page_link_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, page21_xzr_link.error == LINK_ERROR_NONE);
    aarch64_mach_page_link_instructions[10] = saved_page_link_page21;
    ObjectFile aarch64_mach_libc_object = aarch64_libc_object;
    aarch64_mach_libc_object.target.os = OPERATING_SYSTEM_MACOS;
    String8 aarch64_mach_libc_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-aarch64-macho-libc-test"), S8(""));
    NativeExecutableLinkResult aarch64_mach_libc_executable = link_native_executable(arguments->arena, &aarch64_mach_libc_object,
                                                                                     (NativeExecutableLinkOptions){
                                                                                         .output_path = aarch64_mach_libc_output_path,
                                                                                         .entry_symbol = S8("main"),
                                                                                     });
    BUSTER_TEST(arguments, aarch64_mach_libc_executable.error == LINK_ERROR_NONE);
    aarch64_libc_relocation.addend = 4;
    NativeExecutableLinkResult aarch64_mach_import_addend =
        link_native_executable(arguments->arena, &aarch64_mach_libc_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, aarch64_mach_import_addend.error == LINK_ERROR_RELOCATION);
    aarch64_libc_relocation.addend = 0;
    // Debug sections must reach the Mach-O image in an unmapped __DWARF
    // segment, with their address relocations resolved statically.
    ObjectFile mach_debug_object = aarch64_mach_object;
    ObjectSection* mach_debug_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
    memcpy(mach_debug_sections, mach_debug_object.sections, OBJECT_SECTION_COUNT * sizeof(*mach_debug_sections));
    mach_debug_object.sections = mach_debug_sections;
    u8 mach_debug_info[16] = {0};
    u8 mach_debug_line[8] = {0};
    mach_debug_sections[OBJECT_SECTION_DEBUG_INFO].data = (ByteSlice){
        .pointer = mach_debug_info,
        .length = sizeof(mach_debug_info),
    };
    mach_debug_sections[OBJECT_SECTION_DEBUG_LINE].data = (ByteSlice){
        .pointer = mach_debug_line,
        .length = sizeof(mach_debug_line),
    };
    ObjectRelocation mach_debug_relocation = {
        .offset = 0,
        .section = OBJECT_SECTION_DEBUG_INFO,
        .symbol = 0,
        .kind = OBJECT_RELOCATION_ABSOLUTE64,
    };
    mach_debug_object.relocations = &mach_debug_relocation;
    mach_debug_object.relocation_count = 1;
    NativeExecutableLinkResult mach_debug_executable = link_native_executable(arguments->arena, &mach_debug_object,
                                                                             (NativeExecutableLinkOptions){
                                                                                 .entry_symbol = S8("main"),
                                                                             });
    BUSTER_TEST(arguments, mach_debug_executable.error == LINK_ERROR_NONE);
    if (mach_debug_executable.error == LINK_ERROR_NONE)
    {
        ByteSlice image = mach_debug_executable.executable;
        BUSTER_TEST(arguments, image.length > 32 && link_read_u32(image.pointer, 0) == 0xfeedfacf);
        u32 mach_command_count = link_read_u32(image.pointer, 16);
        u64 mach_command = 32;
        bool found_dwarf = false;
        u64 dwarf_file_offset = 0;
        u32 dwarf_section_count = 0;
        for (u32 command_index = 0; command_index < mach_command_count && mach_command + 8 <= image.length; command_index += 1)
        {
            u32 command_kind = link_read_u32(image.pointer, mach_command);
            u32 command_length = link_read_u32(image.pointer, mach_command + 4);
            if (!command_length || mach_command + command_length > image.length)
            {
                break;
            }
            if (command_kind == 0x19 && memcmp(image.pointer + mach_command + 8, "__DWARF", 8) == 0)
            {
                found_dwarf = true;
                dwarf_file_offset = link_read_u64(image.pointer, mach_command + 40);
                dwarf_section_count = link_read_u32(image.pointer, mach_command + 64);
                // dyld rejects a segment whose file size exceeds its virtual
                // size, so the debug segment covers its bytes with a page
                // rounded read-only mapping.
                BUSTER_TEST(arguments, link_read_u64(image.pointer, mach_command + 48) == sizeof(mach_debug_info) + sizeof(mach_debug_line));
                BUSTER_TEST(arguments, link_read_u64(image.pointer, mach_command + 32) == 0x4000);
                BUSTER_TEST(arguments, link_read_u64(image.pointer, mach_command + 24) == UINT64_C(0x100000000) + dwarf_file_offset);
                BUSTER_TEST(arguments, link_read_u32(image.pointer, mach_command + 60) == 1);
                for (u32 section_index = 0; section_index < dwarf_section_count; section_index += 1)
                {
                    u64 section_command = mach_command + 72 + (u64)section_index * 80;
                    BUSTER_TEST(arguments, memcmp(image.pointer + section_command + 16, "__DWARF", 8) == 0);
                    BUSTER_TEST(arguments, (link_read_u32(image.pointer, section_command + 64) & 0x02000000) != 0);
                    // Sections must stay inside the address range of the
                    // segment that carries them.
                    BUSTER_TEST(arguments, link_read_u64(image.pointer, section_command + 32) ==
                                               UINT64_C(0x100000000) + link_read_u32(image.pointer, section_command + 48));
                }
            }
            mach_command += command_length;
        }
        BUSTER_TEST(arguments, found_dwarf);
        BUSTER_TEST(arguments, dwarf_section_count == 6);
        // The kernel loader refuses images with segments that are not page
        // aligned in the file.
        BUSTER_TEST(arguments, dwarf_file_offset % 0x4000 == 0);
        // The resolved slot must hold the link-time address of "main".
        BUSTER_TEST(arguments, dwarf_file_offset + 8 <= image.length);
        if (dwarf_file_offset + 8 <= image.length)
        {
            BUSTER_TEST(arguments, link_read_u64(image.pointer, dwarf_file_offset) >= UINT64_C(0x100000000));
        }
    }
    // __attribute__((constructor)) reaches a Mach-O image as the section dyld
    // dispatches on rather than as a refusal (issue 779), and a destructor
    // reaches it as the registration dyld does not offer (issue 798).  dyld
    // runs a main executable's `__DATA,__mod_init_func` and does not run its
    // `__mod_term_func` -- measured on macOS 26.3.2 against an image the
    // system linker wrote -- so this image carries no terminator array at all,
    // and the slot prepended ahead of the program's own constructors names a
    // registrar that hands a runner over the destructors to `atexit`.  The
    // structure that makes that work is what is checked here: one
    // S_MOD_INIT_FUNC_POINTERS section and no S_MOD_TERM_FUNC_POINTERS one,
    // inside the writable __DATA segment, holding the registrar and then the
    // link-time address of the function the program's slot named, both named
    // by the rebase stream so a slid image still calls the right code, an
    // `atexit` import for the registrar to reach, and real code where the
    // registrar's slot points.
    ObjectFile mach_initializer_object = aarch64_mach_object;
    ObjectSection* mach_initializer_sections = arena_allocate(arguments->arena, ObjectSection, OBJECT_SECTION_COUNT);
    memcpy(mach_initializer_sections, mach_initializer_object.sections, OBJECT_SECTION_COUNT * sizeof(*mach_initializer_sections));
    mach_initializer_object.sections = mach_initializer_sections;
    u8 mach_initializer_entry[OBJECT_INITIALIZER_ENTRY_SIZE] = {0};
    u8 mach_terminator_entry[OBJECT_INITIALIZER_ENTRY_SIZE] = {0};
    mach_initializer_sections[OBJECT_SECTION_INIT_ARRAY].data = (ByteSlice){
        .pointer = mach_initializer_entry,
        .length = sizeof(mach_initializer_entry),
    };
    mach_initializer_sections[OBJECT_SECTION_FINI_ARRAY].data = (ByteSlice){
        .pointer = mach_terminator_entry,
        .length = sizeof(mach_terminator_entry),
    };
    // A symbol defined *inside* the initializer array -- crtbegin's
    // `__frame_dummy_init_array_entry` is the one that exists in the wild --
    // and a pointer to it, which is how its address becomes observable at all:
    // this writer's symbol table carries imports and nothing else.  The
    // prepended slot has to move the symbol with the entry it names, so the
    // pointer must come out holding the *second* slot.
    u8 mach_initializer_pointer[8] = {0};
    mach_initializer_sections[OBJECT_SECTION_DATA].data = (ByteSlice){
        .pointer = mach_initializer_pointer,
        .length = sizeof(mach_initializer_pointer),
    };
    ObjectSymbol* mach_initializer_symbols = arena_allocate(arguments->arena, ObjectSymbol, mach_initializer_object.symbol_count + 1);
    memcpy(mach_initializer_symbols, mach_initializer_object.symbols, mach_initializer_object.symbol_count * sizeof(*mach_initializer_symbols));
    mach_initializer_symbols[mach_initializer_object.symbol_count] = (ObjectSymbol){
        .name = S8("array_entry"),
        .size = OBJECT_INITIALIZER_ENTRY_SIZE,
        .section = OBJECT_SECTION_INIT_ARRAY,
        .kind = OBJECT_SYMBOL_DATA,
    };
    u32 mach_initializer_entry_symbol = mach_initializer_object.symbol_count;
    mach_initializer_object.symbols = mach_initializer_symbols;
    mach_initializer_object.symbol_count += 1;
    ObjectRelocation mach_initializer_relocations[] = {
        {
            .offset = 0,
            .section = OBJECT_SECTION_INIT_ARRAY,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        },
        {
            .offset = 0,
            .section = OBJECT_SECTION_FINI_ARRAY,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        },
        {
            .offset = 0,
            .section = OBJECT_SECTION_DATA,
            .symbol = mach_initializer_entry_symbol,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        },
    };
    mach_initializer_object.relocations = mach_initializer_relocations;
    mach_initializer_object.relocation_count = BUSTER_ARRAY_LENGTH(mach_initializer_relocations);
    NativeExecutableLinkResult mach_initializer_executable = link_native_executable(arguments->arena, &mach_initializer_object,
                                                                                   (NativeExecutableLinkOptions){
                                                                                       .entry_symbol = S8("main"),
                                                                                   });
    BUSTER_TEST(arguments, mach_initializer_executable.error == LINK_ERROR_NONE);
    if (mach_initializer_executable.error == LINK_ERROR_NONE)
    {
        ByteSlice image = mach_initializer_executable.executable;
        BUSTER_TEST(arguments, image.length > 32 && link_read_u32(image.pointer, 0) == 0xfeedfacf);
        u32 mach_initializer_command_count = link_read_u32(image.pointer, 16);
        u64 mach_initializer_command = 32;
        u32 mach_initializer_found = 0;
        u32 mach_terminator_found = 0;
        u64 mach_initializer_slot = 0;
        u64 mach_initializer_data_file_offset = 0;
        u64 mach_initializer_data_vm_address = 0;
        u64 mach_initializer_entry_offset = 0;
        u64 mach_initializer_rebase_offset = 0;
        u64 mach_initializer_rebase_size = 0;
        u64 mach_initializer_string_offset = 0;
        u64 mach_initializer_string_size = 0;
        for (u32 command_index = 0; command_index < mach_initializer_command_count && mach_initializer_command + 8 <= image.length; command_index += 1)
        {
            u32 command_kind = link_read_u32(image.pointer, mach_initializer_command);
            u32 command_length = link_read_u32(image.pointer, mach_initializer_command + 4);
            if (!command_length || mach_initializer_command + command_length > image.length)
            {
                break;
            }
            if (command_kind == 0x80000028)
            {
                mach_initializer_entry_offset = link_read_u64(image.pointer, mach_initializer_command + 8);
            }
            if (command_kind == 0x80000022)
            {
                mach_initializer_rebase_offset = link_read_u32(image.pointer, mach_initializer_command + 8);
                mach_initializer_rebase_size = link_read_u32(image.pointer, mach_initializer_command + 12);
            }
            if (command_kind == 0x2)
            {
                mach_initializer_string_offset = link_read_u32(image.pointer, mach_initializer_command + 16);
                mach_initializer_string_size = link_read_u32(image.pointer, mach_initializer_command + 20);
            }
            if (command_kind == 0x19 && memcmp(image.pointer + mach_initializer_command + 8, "__DATA", 7) == 0)
            {
                u64 segment_vm_address = link_read_u64(image.pointer, mach_initializer_command + 24);
                u64 segment_file_offset = link_read_u64(image.pointer, mach_initializer_command + 40);
                u64 segment_file_size = link_read_u64(image.pointer, mach_initializer_command + 48);
                u32 segment_section_count = link_read_u32(image.pointer, mach_initializer_command + 64);
                mach_initializer_data_file_offset = segment_file_offset;
                mach_initializer_data_vm_address = segment_vm_address;
                // A pointer dyld has to write is only reachable from a
                // writable segment.
                BUSTER_TEST(arguments, link_read_u32(image.pointer, mach_initializer_command + 60) == 3);
                for (u32 section_index = 0; section_index < segment_section_count; section_index += 1)
                {
                    u64 section_command = mach_initializer_command + 72 + (u64)section_index * 80;
                    bool is_terminator = memcmp(image.pointer + section_command, "__mod_term_func", 16) == 0;
                    mach_terminator_found += is_terminator;
                    if (memcmp(image.pointer + section_command, "__mod_init_func", 16) != 0)
                    {
                        continue;
                    }
                    u64 section_address = link_read_u64(image.pointer, section_command + 32);
                    u64 section_size = link_read_u64(image.pointer, section_command + 40);
                    u64 section_file_offset = link_read_u32(image.pointer, section_command + 48);
                    mach_initializer_found += 1;
                    // The section type is the whole contract: it is what makes
                    // dyld call the pointers instead of merely mapping them.
                    BUSTER_TEST(arguments, (link_read_u32(image.pointer, section_command + 64) & 0xff) == 0x9u);
                    BUSTER_TEST(arguments, memcmp(image.pointer + section_command + 16, "__DATA", 7) == 0);
                    // The registrar's slot ahead of the program's own.
                    BUSTER_TEST(arguments, section_size == 2 * OBJECT_INITIALIZER_ENTRY_SIZE);
                    BUSTER_TEST(arguments, section_address % OBJECT_INITIALIZER_ENTRY_SIZE == 0);
                    BUSTER_TEST(arguments, section_address == UINT64_C(0x100000000) + section_file_offset);
                    BUSTER_TEST(arguments, section_address >= segment_vm_address && section_file_offset >= segment_file_offset &&
                                               section_file_offset + section_size <= segment_file_offset + segment_file_size);
                    mach_initializer_slot = section_file_offset;
                }
            }
            mach_initializer_command += command_length;
        }
        BUSTER_TEST(arguments, mach_initializer_found == 1);
        // dyld never calls one, so an image that carried it would carry
        // storage nothing reads and destructors nothing runs.
        BUSTER_TEST(arguments, mach_terminator_found == 0);
        BUSTER_TEST(arguments, mach_initializer_slot && mach_initializer_entry_offset && mach_initializer_string_size);
        u64 mach_initializer_target = UINT64_C(0x100000000) + mach_initializer_entry_offset;
        u64 mach_registrar_slot = mach_initializer_slot;
        u64 mach_constructor_slot = mach_initializer_slot + OBJECT_INITIALIZER_ENTRY_SIZE;
        if (mach_constructor_slot + 8 <= image.length)
        {
            // The program's own slot still holds the address "main" was laid
            // out at, which is also what LC_MAIN points the process at.
            BUSTER_TEST(arguments, link_read_u64(image.pointer, mach_constructor_slot) == mach_initializer_target);
            // The registrar is code this writer synthesized, in the executable
            // segment ahead of __DATA and not in the program at all, and it
            // opens with the frame its call to `atexit` returns through.
            u64 registrar = link_read_u64(image.pointer, mach_registrar_slot);
            BUSTER_TEST(arguments, registrar != mach_initializer_target && registrar > UINT64_C(0x100000000) && registrar < mach_initializer_data_vm_address);
            BUSTER_TEST(arguments, registrar - UINT64_C(0x100000000) + 4 <= image.length &&
                                       link_read_u32(image.pointer, registrar - UINT64_C(0x100000000)) == 0xa9bf7bfdu);
        }
        // The pointer at the top of __data names the array entry, which the
        // prepended slot moved eight bytes along with everything else in the
        // section.  __data is the first section of the segment, so the
        // segment's own file offset is where it starts.
        if (mach_initializer_data_file_offset + 8 <= image.length)
        {
            BUSTER_TEST(arguments, link_read_u64(image.pointer, mach_initializer_data_file_offset) == UINT64_C(0x100000000) + mach_constructor_slot);
        }
        // The registrar has nothing to register with unless the image imports
        // `atexit`, which this program never named itself.
        bool mach_initializer_imports_atexit = false;
        for (u64 cursor = mach_initializer_string_offset;
             cursor + 8 <= mach_initializer_string_offset + mach_initializer_string_size && cursor + 8 <= image.length; cursor += 1)
        {
            mach_initializer_imports_atexit = mach_initializer_imports_atexit || memcmp(image.pointer + cursor, "_atexit", 8) == 0;
        }
        BUSTER_TEST(arguments, mach_initializer_imports_atexit);
        // The image is position independent, so a slot dyld does not rebase
        // holds a stale address in every process that loads at a slide.  Both
        // must appear in the rebase stream against __DATA, which is segment
        // two behind __PAGEZERO and __TEXT.
        bool mach_registrar_rebased = false;
        bool mach_constructor_rebased = false;
        u64 rebase_cursor = mach_initializer_rebase_offset;
        u64 rebase_end = mach_initializer_rebase_offset + mach_initializer_rebase_size;
        u8 rebase_segment = 0;
        u64 rebase_segment_offset = 0;
        while (rebase_cursor < rebase_end && rebase_end <= image.length)
        {
            u8 opcode = image.pointer[rebase_cursor++];
            if ((opcode & 0xf0) == 0x20)
            {
                rebase_segment = (u8)(opcode & 0x0f);
                rebase_segment_offset = 0;
                u32 shift = 0;
                while (rebase_cursor < rebase_end)
                {
                    u8 piece = image.pointer[rebase_cursor++];
                    rebase_segment_offset |= (u64)(piece & 0x7f) << shift;
                    shift += 7;
                    if (!(piece & 0x80))
                    {
                        break;
                    }
                }
            }
            else if ((opcode & 0xf0) == 0x50)
            {
                for (u32 repeat = 0; repeat < (u32)(opcode & 0x0f); repeat += 1)
                {
                    u64 rebased = mach_initializer_data_file_offset + rebase_segment_offset;
                    mach_registrar_rebased = mach_registrar_rebased || (rebase_segment == 2 && rebased == mach_registrar_slot);
                    mach_constructor_rebased = mach_constructor_rebased || (rebase_segment == 2 && rebased == mach_constructor_slot);
                    rebase_segment_offset += sizeof(u64);
                }
            }
        }
        BUSTER_TEST(arguments, mach_registrar_rebased && mach_constructor_rebased);
    }
    // A single rebased pointer is five opcode bytes, so an image that also
    // imports something puts its bind opcodes behind a rebase stream that
    // ends mid-word.  That is the layout dyld refuses to read.
    u32 mach_linkedit_instructions[] = {
        UINT32_C(0x90000009), UINT32_C(0x91000129), UINT32_C(0xd65f03c0),
    };
    u64 mach_linkedit_pointer = 0;
    ObjectSymbol mach_linkedit_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(mach_linkedit_instructions),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("linkedit_import"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectRelocation mach_linkedit_relocations[] = {
        {
            .offset = 0,
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGE21,
        },
        {
            .offset = sizeof(u32),
            .section = OBJECT_SECTION_TEXT,
            .symbol = 1,
            .kind = OBJECT_RELOCATION_AARCH64_MACH_PAGEOFF12,
        },
        {
            .offset = 0,
            .section = OBJECT_SECTION_DATA,
            .symbol = 0,
            .kind = OBJECT_RELOCATION_ABSOLUTE64,
        },
    };
    ObjectFile mach_linkedit_object = link_test_object_make(
        arguments->arena, aarch64_mach_object.target,
        (ByteSlice){.pointer = (u8*)mach_linkedit_instructions, .length = sizeof(mach_linkedit_instructions)}, mach_linkedit_symbols,
        BUSTER_ARRAY_LENGTH(mach_linkedit_symbols), mach_linkedit_relocations, BUSTER_ARRAY_LENGTH(mach_linkedit_relocations));
    mach_linkedit_object.sections[OBJECT_SECTION_DATA].data = (ByteSlice){
        .pointer = (u8*)&mach_linkedit_pointer,
        .length = sizeof(mach_linkedit_pointer),
    };
    String8 mach_linkedit_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-aarch64-macho-linkedit-test"), S8(""));
    NativeExecutableLinkResult mach_linkedit_executable = link_native_executable(arguments->arena, &mach_linkedit_object,
                                                                                 (NativeExecutableLinkOptions){
                                                                                     .output_path = mach_linkedit_output_path,
                                                                                     .entry_symbol = S8("main"),
                                                                                 });
    BUSTER_TEST(arguments, mach_linkedit_executable.error == LINK_ERROR_NONE);
    ByteSlice mach_linkedit_images[] = {
        aarch64_mach_executable.executable,
        aarch64_mach_data_executable.executable,
        aarch64_mach_libc_executable.executable,
        mach_initializer_executable.executable,
        mach_linkedit_executable.executable,
    };
    bool mach_linkedit_fixups[] = {
        false, false, false, true, true,
    };
    bool mach_linkedit_bind_padded = false;
    for (u32 image_index = 0; image_index < BUSTER_ARRAY_LENGTH(mach_linkedit_images); image_index += 1)
    {
        bool image_bind_padded = false;
        UnitTestResult mach_linkedit =
            link_test_mach_linkedit_layout(arguments, mach_linkedit_images[image_index], mach_linkedit_fixups[image_index], &image_bind_padded);
        mach_linkedit_bind_padded = mach_linkedit_bind_padded || image_bind_padded;
        result.succeeded_test_count += mach_linkedit.succeeded_test_count;
        result.test_count += mach_linkedit.test_count;
    }
    // Without an image whose rebase stream ends mid-word the alignment above
    // would hold by accident, so the fixtures must keep producing one.
    BUSTER_TEST(arguments, mach_linkedit_bind_padded);
    ObjectFile ios_mach_object = aarch64_mach_object;
    ios_mach_object.target.os = OPERATING_SYSTEM_IOS;
    String8 ios_mach_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-ios-macho-test"), S8(""));
    NativeExecutableLinkResult ios_mach_executable = link_native_executable(arguments->arena, &ios_mach_object,
                                                                            (NativeExecutableLinkOptions){
                                                                                .output_path = ios_mach_output_path,
                                                                                .entry_symbol = S8("main"),
                                                                            });
    BUSTER_TEST(arguments, ios_mach_executable.error == LINK_ERROR_NONE);
#if BUSTER_CPU_ARCH_X86_64
    ObjectFile x86_mach_object = linked.object;
    x86_mach_object.target.os = OPERATING_SYSTEM_MACOS;
    String8 x86_mach_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-x86-macho-test"), S8(""));
    NativeExecutableLinkResult x86_mach_executable = link_native_executable(arguments->arena, &x86_mach_object,
                                                                            (NativeExecutableLinkOptions){
                                                                                .output_path = x86_mach_output_path,
                                                                                .entry_symbol = S8("main"),
                                                                            });
    BUSTER_TEST(arguments, x86_mach_executable.error == LINK_ERROR_NONE);
    u8 x86_mach_libc_text[] = {
        0x48, 0x83, 0xec, 0x08, 0xbf, 0xd6, 0xff, 0xff, 0xff, 0xe8, 0, 0, 0, 0, 0x83, 0xe8, 42, 0x48, 0x83, 0xc4, 0x08, 0xc3,
    };
    ObjectSymbol x86_mach_libc_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(x86_mach_libc_text),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("abs"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectRelocation x86_mach_libc_relocation = {
        .addend = -4,
        .offset = 10,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_PC32,
    };
    ObjectFile x86_mach_libc_object = link_test_object_make(arguments->arena, x86_mach_object.target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(x86_mach_libc_text),
                                                            x86_mach_libc_symbols, BUSTER_ARRAY_LENGTH(x86_mach_libc_symbols), &x86_mach_libc_relocation, 1);
    String8 x86_mach_libc_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-x86-macho-libc-test"), S8(""));
    NativeExecutableLinkResult x86_mach_libc_executable = link_native_executable(arguments->arena, &x86_mach_libc_object,
                                                                                 (NativeExecutableLinkOptions){
                                                                                     .output_path = x86_mach_libc_output_path,
                                                                                     .entry_symbol = S8("main"),
                                                                                 });
    BUSTER_TEST(arguments, x86_mach_libc_executable.error == LINK_ERROR_NONE);
    ByteSlice x86_mach_linkedit_images[] = {
        x86_mach_executable.executable,
        x86_mach_libc_executable.executable,
    };
    for (u32 image_index = 0; image_index < BUSTER_ARRAY_LENGTH(x86_mach_linkedit_images); image_index += 1)
    {
        UnitTestResult x86_mach_linkedit = link_test_mach_linkedit_layout(arguments, x86_mach_linkedit_images[image_index], false, 0);
        result.succeeded_test_count += x86_mach_linkedit.succeeded_test_count;
        result.test_count += x86_mach_linkedit.test_count;
    }
#endif
#if BUSTER_MACOS
    String8* native_mach_paths = 0;
    u32 native_mach_path_count = 0;
#if BUSTER_CPU_ARCH_X86_64
    String8 x86_native_mach_paths[] = {
        x86_mach_output_path,
        x86_mach_libc_output_path,
    };
    native_mach_paths = x86_native_mach_paths;
    native_mach_path_count = BUSTER_ARRAY_LENGTH(x86_native_mach_paths);
#elif BUSTER_CPU_ARCH_AARCH64
    String8 aarch64_native_mach_paths[] = {
        aarch64_mach_output_path,
        aarch64_mach_data_output_path,
        aarch64_mach_libc_output_path,
    };
    native_mach_paths = aarch64_native_mach_paths;
    native_mach_path_count = BUSTER_ARRAY_LENGTH(aarch64_native_mach_paths);
#endif
    // dyld_info runs dyld's own __LINKEDIT layout check before it prints
    // anything, so it is the tool that refuses an image this writer laid out
    // wrong -- "mis-aligned LINKEDIT content 'bind opcodes'" in place of the
    // fixup table.  The image linked above is the one whose bind opcodes sit
    // behind an odd-length rebase stream.  The tool comes with the command
    // line tools any macOS host that can build this compiler already has, and
    // a skipped check would look exactly like a passing one, so its absence
    // is a failure rather than a skip.
    String8 dyld_info_arguments[] = {
        S8("dyld_info"),
        S8("-fixups"),
        mach_linkedit_output_path,
    };
    ProcessSpawnResult dyld_info = os_process_spawn((SliceString8)BUSTER_ARRAY_TO_SLICE(dyld_info_arguments), (SliceString8){0}, (SliceString8){0},
                                                    (ProcessSpawnOptions){
                                                        .capture = ((u64)1 << STANDARD_STREAM_OUTPUT) | ((u64)1 << STANDARD_STREAM_ERROR),
                                                        .use_process_environment = true, .search_path = true,
                                                    });
    BUSTER_TEST(arguments, dyld_info.handle != 0);
    if (dyld_info.handle)
    {
        ProcessWaitResult dyld_info_wait = os_process_wait_sync(arguments->arena, dyld_info);
        String8 dyld_info_output = {
            .pointer = (char8*)dyld_info_wait.streams[STANDARD_STREAM_OUTPUT].pointer,
            .length = dyld_info_wait.streams[STANDARD_STREAM_OUTPUT].length,
        };
        String8 dyld_info_error = {
            .pointer = (char8*)dyld_info_wait.streams[STANDARD_STREAM_ERROR].pointer,
            .length = dyld_info_wait.streams[STANDARD_STREAM_ERROR].length,
        };
        BUSTER_TEST(arguments, string_first_sequence(dyld_info_output, S8("mis-aligned")) == BUSTER_STRING_NO_MATCH);
        BUSTER_TEST(arguments, string_first_sequence(dyld_info_error, S8("mis-aligned")) == BUSTER_STRING_NO_MATCH);
        // The table itself, which is what the refusal used to replace.
        bool dyld_info_lists_data_segment = string_first_sequence(dyld_info_output, S8("__DATA")) != BUSTER_STRING_NO_MATCH;
        if (!dyld_info_lists_data_segment)
        {
            // dyld_info's report format follows the host's dyld release, so
            // keep the tool's own words in the failure; a format drift on a
            // newer macOS must be diagnosable from a CI log alone.
            String8 output_head = dyld_info_output;
            output_head.length = output_head.length > 1500 ? 1500 : output_head.length;
            String8 error_head = dyld_info_error;
            error_head.length = error_head.length > 500 ? 500 : error_head.length;
            arguments->show(arguments, S8("LINK_TEST dyld_info stdout head: {S8}\nLINK_TEST dyld_info stderr head: {S8}\n"), output_head, error_head);
        }
        BUSTER_TEST(arguments, dyld_info_lists_data_segment);
    }
    for (u32 path_index = 0; path_index < native_mach_path_count; path_index += 1)
    {
        String8 run_arguments[] = {
            native_mach_paths[path_index],
        };
        ProcessSpawnResult spawn = os_process_spawn((SliceString8)BUSTER_ARRAY_TO_SLICE(run_arguments), (SliceString8){0}, (SliceString8){0},
                                                    (ProcessSpawnOptions){
                                                        .use_process_environment = true, .search_path = true,
                                                    });
        BUSTER_TEST(arguments, spawn.handle != 0);
        if (spawn.handle)
        {
            ProcessWaitResult wait = os_process_wait_sync(arguments->arena, spawn);
            BUSTER_TEST(arguments, wait.result == PROCESS_RESULT_SUCCESS);
        }
    }
#endif
#if BUSTER_LINUX && BUSTER_CPU_ARCH_X86_64
    // R_X86_64_32S is a signed field, unlike the unsigned ABS32 form.  A
    // symbol just beyond INT32_MAX must therefore fail the native image link
    // instead of silently truncating its address.
    u8 absolute32s_text[] = {0xc3, 0, 0, 0, 0};
    ObjectSymbol absolute32s_symbols[] = {
        {
            .name = S8("main"),
            .size = 1,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("far_target"),
            .value = INT32_MAX,
            .size = 1,
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_DATA,
        },
    };
    ObjectRelocation absolute32s_relocation = {
        .offset = 1,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_ABSOLUTE32S,
    };
    ObjectFile absolute32s_object = link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(absolute32s_text),
                                                           absolute32s_symbols, BUSTER_ARRAY_LENGTH(absolute32s_symbols), &absolute32s_relocation, 1);
    NativeExecutableLinkResult absolute32s_overflow = link_native_executable(
        arguments->arena, &absolute32s_object, (NativeExecutableLinkOptions){.entry_symbol = S8("main")});
    BUSTER_TEST(arguments, absolute32s_overflow.error == LINK_ERROR_RELOCATION);
    String8 native_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-link-test"), S8(""));
    NativeExecutableLinkResult native_executable = link_native_executable(arguments->arena, &cfi_linked.object,
                                                                          (NativeExecutableLinkOptions){
                                                                              .output_path = native_output_path,
                                                                              .entry_symbol = S8("main"),
                                                                          });
    BUSTER_TEST(arguments, native_executable.error == LINK_ERROR_NONE);
    BUSTER_TEST(arguments, native_executable.executable.length >= 4);
    if (native_executable.error == LINK_ERROR_NONE)
    {
        u32 unwind_section_index = 0;
        u64 unwind_section_header = 0;
        u32 unwind_header_section_index = 0;
        u64 unwind_header_section_header = 0;
        u32 text_section_index = 0;
        u64 text_section_header = 0;
        bool unwind_section_found = link_test_elf_section_find(native_executable.executable, S8(".eh_frame"), &unwind_section_index, &unwind_section_header);
        bool unwind_header_section_found =
            link_test_elf_section_find(native_executable.executable, S8(".eh_frame_hdr"), &unwind_header_section_index, &unwind_header_section_header);
        bool text_section_found = link_test_elf_section_find(native_executable.executable, S8(".text"), &text_section_index, &text_section_header);
        BUSTER_TEST(arguments, unwind_section_found);
        BUSTER_TEST(arguments, unwind_header_section_found);
        BUSTER_TEST(arguments, text_section_found);
        if (unwind_section_found && unwind_header_section_found && text_section_found)
        {
            u64 unwind_flags = link_read_u64(native_executable.executable.pointer, unwind_section_header + 8);
            u64 unwind_address = link_read_u64(native_executable.executable.pointer, unwind_section_header + 16);
            u64 unwind_offset = link_read_u64(native_executable.executable.pointer, unwind_section_header + 24);
            u64 unwind_size = link_read_u64(native_executable.executable.pointer, unwind_section_header + 32);
            u64 unwind_header_address = link_read_u64(native_executable.executable.pointer, unwind_header_section_header + 16);
            u64 unwind_header_offset = link_read_u64(native_executable.executable.pointer, unwind_header_section_header + 24);
            u64 unwind_header_size = link_read_u64(native_executable.executable.pointer, unwind_header_section_header + 32);
            u64 text_address = link_read_u64(native_executable.executable.pointer, text_section_header + 16);
            BUSTER_TEST(arguments, unwind_flags == 0x2);
            BUSTER_TEST(arguments, unwind_size == cfi_linked.object.sections[OBJECT_SECTION_UNWIND].data.length);
            BUSTER_TEST(arguments, unwind_header_size == 28);
            if (unwind_header_offset + unwind_header_size <= native_executable.executable.length)
            {
                u8* header = native_executable.executable.pointer + unwind_header_offset;
                BUSTER_TEST(arguments, header[0] == 1 && header[1] == 0x1b && header[2] == 0x03 && header[3] == 0x3b);
                BUSTER_TEST(arguments, link_read_u32(header, 8) == 2);
                s32 frame_displacement = 0;
                s32 first_function = 0;
                s32 first_fde = 0;
                s32 second_function = 0;
                s32 second_fde = 0;
                memcpy(&frame_displacement, header + 4, sizeof(frame_displacement));
                memcpy(&first_function, header + 12, sizeof(first_function));
                memcpy(&first_fde, header + 16, sizeof(first_fde));
                memcpy(&second_function, header + 20, sizeof(second_function));
                memcpy(&second_fde, header + 24, sizeof(second_fde));
                BUSTER_TEST(arguments, (s64)unwind_header_address + 4 + frame_displacement == (s64)unwind_address);
                BUSTER_TEST(arguments, first_function < second_function);
                BUSTER_TEST(arguments,
                            (s64)unwind_header_address + first_fde ==
                                (s64)unwind_address + (s64)answer_cfi.relocations[0].offset - 8);
                BUSTER_TEST(arguments,
                            (s64)unwind_header_address + second_fde ==
                                (s64)unwind_address + (s64)answer_cfi.bytes.length + (s64)main_cfi.relocations[0].offset - 8);
            }
            else
            {
                BUSTER_TEST(arguments, false);
            }
            bool unwind_program_header_found = false;
            u64 program_header_offset = link_read_u64(native_executable.executable.pointer, 32);
            u32 program_header_size = native_executable.executable.pointer[54] | ((u32)native_executable.executable.pointer[55] << 8);
            u32 program_header_count = native_executable.executable.pointer[56] | ((u32)native_executable.executable.pointer[57] << 8);
            for (u32 program_header_index = 0; program_header_index < program_header_count; program_header_index += 1)
            {
                u64 header_offset = program_header_offset + (u64)program_header_index * program_header_size;
                if (header_offset + program_header_size <= native_executable.executable.length &&
                    link_read_u32(native_executable.executable.pointer, header_offset) == 0x6474e550)
                {
                    unwind_program_header_found = link_read_u64(native_executable.executable.pointer, header_offset + 8) == unwind_header_offset &&
                                                  link_read_u64(native_executable.executable.pointer, header_offset + 32) == unwind_header_size;
                }
            }
            BUSTER_TEST(arguments, unwind_program_header_found);
            if (unwind_offset + answer_cfi.relocations[0].offset + 4 <= native_executable.executable.length)
            {
                s32 displacement = 0;
                memcpy(&displacement, native_executable.executable.pointer + unwind_offset + answer_cfi.relocations[0].offset, sizeof(displacement));
                BUSTER_TEST(arguments,
                            (s64)unwind_address + (s64)answer_cfi.relocations[0].offset + displacement ==
                                (s64)text_address + (s64)cfi_linked.object.symbols[0].value);
            }
            else
            {
                BUSTER_TEST(arguments, false);
            }
        }
        String8 run_arguments[] = {
            native_output_path,
        };
        ProcessSpawnResult spawn = os_process_spawn((SliceString8)BUSTER_ARRAY_TO_SLICE(run_arguments), (SliceString8){0}, (SliceString8){0},
                                                    (ProcessSpawnOptions){
                                                        .use_process_environment = true, .search_path = true,
                                                    });
        BUSTER_TEST(arguments, spawn.handle != 0);
        if (spawn.handle)
        {
            ProcessWaitResult wait = os_process_wait_sync(arguments->arena, spawn);
            BUSTER_TEST(arguments, wait.result == PROCESS_RESULT_SUCCESS);
        }
    }
    NativeExecutableLinkResult unresolved_native = link_native_executable(arguments->arena, &permitted.object, (NativeExecutableLinkOptions){0});
    BUSTER_TEST(arguments, unresolved_native.error == LINK_ERROR_NONE);
    u8 libc_main_text[] = {
        0x48, 0x83, 0xec, 0x08, 0xbf, 0xd6, 0xff, 0xff, 0xff, 0xe8, 0, 0, 0, 0, 0x83, 0xe8, 42, 0x48, 0x83, 0xc4, 0x08, 0xc3,
    };
    ObjectSymbol libc_symbols[] = {
        {
            .name = S8("main"),
            .size = sizeof(libc_main_text),
            .section = OBJECT_SECTION_TEXT,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
        {
            .name = S8("abs"),
            .section = OBJECT_SECTION_UNDEFINED,
            .kind = OBJECT_SYMBOL_FUNCTION,
            .global = true,
        },
    };
    ObjectRelocation libc_relocation = {
        .addend = -4,
        .offset = 10,
        .section = OBJECT_SECTION_TEXT,
        .symbol = 1,
        .kind = OBJECT_RELOCATION_X86_64_PC32,
    };
    ObjectFile libc_object = link_test_object_make(arguments->arena, target, (ByteSlice)BUSTER_ARRAY_TO_SLICE(libc_main_text), libc_symbols,
                                                   BUSTER_ARRAY_LENGTH(libc_symbols), &libc_relocation, 1);
    String8 libc_output_path = link_test_temporary_executable_path(arguments->arena, S8("buster-native-libc-link-test"), S8(""));
    NativeExecutableLinkResult libc_executable = link_native_executable(arguments->arena, &libc_object,
                                                                        (NativeExecutableLinkOptions){
                                                                            .output_path = libc_output_path,
                                                                            .entry_symbol = S8("main"),
                                                                        });
    BUSTER_TEST(arguments, libc_executable.error == LINK_ERROR_NONE);
    if (libc_executable.error == LINK_ERROR_NONE)
    {
        String8 run_arguments[] = {
            libc_output_path,
        };
        ProcessSpawnResult spawn = os_process_spawn((SliceString8)BUSTER_ARRAY_TO_SLICE(run_arguments), (SliceString8){0}, (SliceString8){0},
                                                    (ProcessSpawnOptions){
                                                        .use_process_environment = true, .search_path = true,
                                                    });
        BUSTER_TEST(arguments, spawn.handle != 0);
        if (spawn.handle)
        {
            ProcessWaitResult wait = os_process_wait_sync(arguments->arena, spawn);
            BUSTER_TEST(arguments, wait.result == PROCESS_RESULT_SUCCESS);
        }
    }
#endif
#else
    BUSTER_UNUSED(target);
#endif
    UnitTestResult runtime_stack_walk = link_test_runtime_stack_walk(arguments);
    result.succeeded_test_count += runtime_stack_walk.succeeded_test_count;
    result.test_count += runtime_stack_walk.test_count;
    return result;
}
#endif
