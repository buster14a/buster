// x86-64 machine selection, MIR_STACK placement, and encoding. Included by
// machine.c in the backend-implementation-file pattern; not a standalone
// translation unit. The stage-2 subset covers scalar integer functions:
// arguments/constants/casts/unary/binary arithmetic and comparisons, direct
// locals and pointer dereference, branches, and scalar returns. Everything
// else is an explicit unsupported result, never a silent misselection.

// machine_x86_64_predicate.c finishes compare/masked dataflow selection;
// machine_x64_emit_exact_sequence supplies allocated predicate operands to
// existing exact forms, and machine_x64_emit_predicate_row/frame/constant own
// explicit integer bridges, K operations, spills and rematerialization.
// machine_x64_select_inline_hint maps fixed NOP/PAUSE literals to explicit
// rows whose encoder emits through checked instruction metadata.
// machine_x64_value_shape and the call/return/argument selectors carry
// frame-backed wide vectors through explicit XMM/YMM/ZMM ABI transfer rows.
// machine_x64_select_i128_divide emits scalar MIR loop blocks; optional
// block_entries/block_exits preserve canonical control-flow destinations.
// MachineX64ValueUse is the hot value-use projection; MachineX64LocalUse
// holds sparse local-promotion store and alias state during selection.

#include <buster/lib/compiler/codegen/machine.h>
#include <buster/lib/compiler/codegen/machine_x86_64_internal.h>
#include <buster/lib/compiler/codegen/codegen.h>
#include <buster/lib/compiler/codegen/codegen_internal.h>
#include <buster/lib/compiler/assembly/assembly.h>
#include <buster/lib/compiler/assembly/x86_64_metadata.h>
#include <buster/lib/compiler/object/object.h>
#include <buster/lib/os.h>
#include <buster/lib/string.h>
#include <buster/lib/integer.h>

// The register shape of one argument or result under the subset: scalar
// values occupy one integer register; small integer-class aggregates occupy
// one or two, with the part offsets taken from the IR-owned System V
// classification. Anything else (floats, memory or indirect classes) is
// outside the subset.
typedef struct MachineX64ValueShape MachineX64ValueShape;
struct MachineX64ValueShape
{
    u32 part_offsets[4];
    u8 part_is_float[4];
    u8 part_sizes[4];
    u32 part_count;
    u32 byte_size;
    bool aggregate;
    // Memory-class argument: passed by value in outgoing stack eightbytes.
    bool force_stack;
    // Indirect result: returned through a hidden pointer in RDI.
    bool indirect;
    // One 64-byte vector value in a ZMM register. System V places its direct
    // part in the floating register sequence. Win64 arguments carry this
    // value through an indirect pointer part; results use ZMM0 directly.
    bool vector;
    u8 f80_result;
    // The System V argument-area alignment of the value's stack home in
    // bytes when it exceeds the eightbyte floor: 16 for the __int128 pair
    // and sixteen-aligned memory-class aggregates, 64 for a whole ZMM
    // vector, zero for the plain eightbyte floor. The placement rounds the
    // stack cursor up to it — the same padding eightbytes the canonical
    // layout counts on both sides of a call. Win64 indirect arguments reuse
    // this field for their private copy's alignment, with a sixteen-byte floor.
    u32 stack_alignment;
    // For a sub-32-bit scalar integer argument, the MOVSX/MOVZX opcode that
    // widens it into its argument register: the de-facto System V contract
    // clang's callers implement extends such arguments to 32 bits, and
    // callees exist that read the widened register directly. Zero when a
    // plain move suffices.
    u16 scalar_extend_opcode;
    // A frame-backed sixteen-byte value occupies one whole XMM ABI register.
    bool xmm128;
    // Frame-backed vectors split into consecutive XMM/YMM/ZMM ABI parts.
    // Scalar/aggregate parts include the three-lane padded-vector return.
    // Vector offsets are still part_index * vector_part_bytes and need no extra storage.
    u8 vector_part_bytes;
    // A GNU padded vector can expose scalar Win64 lanes instead of one
    // by-reference vector part. The lane size drives sized frame transfers;
    // floating lanes occupy the positional XMM file.
    u8 windows_scalar_lane_size;
    bool windows_scalar_float;
    // A three-lane double result uses XMM0/XMM1 and ST(0). The first two
    // parts retain part_is_float; the third is bridged explicitly through x87.
    bool x87_f64_result;
    // The unrounded size of an indirect result. byte_size is rounded up to
    // whole eightbytes for the value's own slot; the store through the
    // caller's hidden pointer must not write the rounding — the caller
    // allocated exactly the type, and clang puts its stack canary right
    // after.
    u32 exact_byte_size;
};
BUSTER_CT_CHECK(sizeof(MachineX64ValueShape) == 56);

// One argument's placement after running register assignment: either its
// shape's parts in consecutive per-class registers, or the whole value in
// consecutive eightbytes of the outgoing stack area.
typedef struct MachineX64ArgumentPlacement MachineX64ArgumentPlacement;
struct MachineX64ArgumentPlacement
{
    u16 first_integer;
    u16 first_float;
    u32 first_stack_part;
    u32 stack_part_count;
    bool on_stack;
    // Win64 vectors wider than the target's widest register consume one
    // pointer slot per register-sized piece. The prefix can occupy the
    // remaining argument GPRs while the tail continues on the stack.
    u8 register_part_count;
    u8 reserved[2];
};
BUSTER_CT_CHECK(sizeof(MachineX64ArgumentPlacement) == 16);

// A conditional branch whose condition chain folded into the branch: the
// terminator re-selects the innermost comparison as CMP (or the truthiness
// test as TEST) immediately before JCC, and every absorbed chain member
// selects into nothing. Indexed by the block whose terminator it is, since a
// block ends in at most one branch; a zero condition nibble means no fusion
// (the mapping never produces 0), and the terminator checks that the
// condition value is the one the fusion pass planned for.
typedef struct MachineX64BranchFusion MachineX64BranchFusion;
struct MachineX64BranchFusion
{
    u32 left;  // value the CMP/TEST reads
    u32 right; // CMP's second value, or UINT32_MAX for the TEST form
    u32 condition_value;
    u8 condition;
    u8 wide;
    u8 reserved[2];
};

// What defines a place operand, as far as the load, store and address paths
// ask: a LOCAL, an address-producing row (DEREFERENCE, GLOBAL, INDEX, FIELD),
// a FUNCTION reference, some other row, or no row at all. Written per value
// by the classification pass, which holds the row anyway, so a place operand
// costs one byte instead of its defining row's line.
typedef enum MachineX64PlaceKind
{
    MACHINE_X64_PLACE_NONE,
    MACHINE_X64_PLACE_LOCAL,
    MACHINE_X64_PLACE_ADDRESSED,
    MACHINE_X64_PLACE_FUNCTION,
    MACHINE_X64_PLACE_OTHER,
} MachineX64PlaceKind;

// The facts the one row walk scatters per operand, interleaved so that an
// operand touches one line: the use count, the one block that uses the value,
// the last use ordinal, and the index of the sparse local-use row (zero for
// nonlocals). All zero at rest: the block is stored plus
// one so that zero means unused, and MACHINE_SELECTION_MULTIPLE_BLOCKS once a
// second block uses the value.
typedef struct MachineX64ValueUse MachineX64ValueUse;
struct MachineX64ValueUse
{
    u32 use_count;
    u32 use_block;
    u32 last_use_ordinal;
    u32 local_use;
};
BUSTER_CT_CHECK(sizeof(MachineX64ValueUse) == 16);

// Only promotable local places need store/alias state. Value rows carry a
// one-based index; entry zero is the nonlocal sentinel.
typedef struct MachineX64LocalUse MachineX64LocalUse;
struct MachineX64LocalUse
{
    u32 value;
    u32 width;
    u32 store_count;
    u32 next_store_ordinal;
    u32 next_store_epoch;
};

// One stack slot as the selector appends it: the size and the power-of-two
// alignment travel as one row, and the two public columns are written from
// that record at finish, so they cannot drift apart.
typedef struct MachineX64StackSlot MachineX64StackSlot;
struct MachineX64StackSlot
{
    u32 size;
    u32 alignment;
};

// One call-target row with the MachineSymbolReference form that names it
// beside it, split into the two public columns at finish for the same reason.
typedef struct MachineX64CallTarget MachineX64CallTarget;
struct MachineX64CallTarget
{
    IrSymbolId symbol;
    u8 reference;
    u8 reserved[3];
};

typedef struct MachineX64Selector MachineX64Selector;
struct MachineX64Selector
{
    Arena* arena;
    IrProgram* program;
    IrFunction* function;
    MachineFunctionBuilder builder;
    u64 reserved_selection_layout[MACHINE_SELECTION_RESERVED_LAYOUT_WORDS];
    // The side streams rows append to, each through a typed cursor/end pair
    // in the machine_stream_cursor_* shape: the hot append is a pointer bump
    // and the row store, and only a full chunk reaches the refill.
    MachineBuilderStream immediates;
    u64* immediate_cursor;
    u64* immediate_end;
    MachineBuilderStream stack_slots;
    MachineX64StackSlot* stack_slot_cursor;
    MachineX64StackSlot* stack_slot_end;
    MachineBuilderStream call_targets;
    MachineX64CallTarget* call_target_cursor;
    MachineX64CallTarget* call_target_end;
    MachineBuilderStream switch_cases;
    MachineSwitchCase* switch_case_cursor;
    MachineSwitchCase* switch_case_end;
    // Variadic metadata rows are rare enough to keep the generic append.
    MachineBuilderStream va_args;
    MachineBuilderStream inline_assemblies;
    MachineBuilderStream inline_assembly_operands;
    MachineBuilderStream inline_assembly_relocations;
    // Per IrValue: virtual register index, stack slot index, or UINT32_MAX.
    u32* value_virtual_registers;
    MachineCanonicalPair* value_pairs;
    u32* value_stack_slots;
    // Per IrValue: the padded raw-storage slot of an over-aligned local, or
    // UINT32_MAX. Such a local mirrors the canonical frame layout: its
    // virtual register holds a runtime-aligned pointer into this slot, the
    // slot itself stays out of value_stack_slots so no consumer can read it
    // as data, and every access dispatches down the same pointer paths a
    // GLOBAL's address takes.
    u32* value_indirect_slots;
    MachineSelectionAddressCache address_cache;
    // -fPIC, resolved for this target by the caller: it picks the thread-local
    // model, and an interposable symbol is addressed through its GOT slot and
    // called through its procedure linkage entry.
    bool position_independent;
    // Result value per argument index, captured at entry before any scratch
    // register can clobber the incoming fixed registers; IR_ID_UNDERLYING_INVALID
    // when the function has no such argument.
    u32* argument_values;
    u32 parameter_count;
    // Register shape and placement per parameter, plus the return shape,
    // computed once from the IR-owned ABI classification.
    MachineX64ValueShape* parameter_shapes;
    MachineX64ArgumentPlacement* parameter_placements;
    MachineX64ValueShape return_shape;
    // One reusable call workspace, sized by the existing canonical row walk.
    u32 call_argument_capacity;
    u32* call_argument_registers;
    u32* call_argument_slots;
    // Frame slot holding the incoming hidden result pointer, or UINT32_MAX.
    u32 hidden_return_slot;
    // SysV variadic save area.  The row is emitted before incoming argument
    // captures, so the six GP and eight XMM registers are preserved before
    // any selector scratch can overwrite them.
    u32 va_register_save_slot;
    // Win64 outgoing argument area: the slot every call writes its shadow
    // space and stack arguments into, sized to the widest call in the
    // function. Created on the first call selected and patched to its final
    // size once selection is done, because the size is only known then.
    u32 outgoing_slot;
    u32 outgoing_bytes;
    bool dynamic_stack;
    // The classification virtual registers' rows — the builder's first
    // chunk, where machine_x64_define writes a definition point in place.
    // The rows past that chunk's capacity are reached by the chunk walk,
    // which nineteen functions in twenty never need.
    MachineVirtualRegister* classification_registers;
    // Per block: the fusion its BRANCH_IF terminator selects, and the block
    // the main loop is selecting.
    MachineX64BranchFusion* branch_fusions;
    u32 current_block;
    // Allocated only when wide division splits canonical blocks. Branches
    // enter the original entry; canonical outgoing edges leave the last split.
    u32* block_entries;
    u32* block_exits;
    // Per canonical block, the first of target_count asm-goto continuations,
    // or UINT32_MAX. Each path publishes output places before entering its
    // canonical successor.
    u32* asm_goto_continuations;
    MachineBlock open_block;
    // i128 CMPXCHG16B materializes its ZF result immediately, so later
    // aggregate expected-value copies never rely on flags surviving IR rows.
    // Allocated only when the function's opcode summary admits the atomic;
    // null otherwise, which every reader takes as "no such source".
    u32* atomic_success_registers;
    // Per IrValue: a branch-fusion chain member that selects into nothing.
    u8* fused_dead;
    // Per IrValue: its MachineX64PlaceKind.
    u8* place_kinds;
    u32 virtual_register_count;
    // The compile target, for the AVX-512 feature gates on the vector rows,
    // and the one gate every vector load, store and local asks — the 512-bit
    // vocabulary's F and BW features — answered once per function.
    Target target;
    bool vector_registers_supported;
    // The module's context: its per-type projection, which the row path
    // reads instead of the IrType record, and the per-signature call plans.
    MachineSelectionModule* module;
    MachineTypeClass const* type_classes;
    u32 type_class_count;
    IrOpcode failed_opcode;
    bool supported;
};

// The reference form a symbol takes in this module. An undefined ELF
// function uses the PLT even in the default model, so an external linker can
// place the -c object in a PIE. Under -fPIC, any interposable function uses
// the PLT and any interposable address uses the GOT.
BUSTER_GLOBAL_LOCAL u8 machine_x64_symbol_reference(MachineX64Selector* selector, IrSymbolId symbol, bool call_site)
{
    IrSymbol* record = ir_symbol_from_id(&selector->program->symbols, symbol);
    bool elf_external_call = call_site && record && !record->is_definition &&
                             object_format_for_target(selector->target) == OBJECT_FORMAT_ELF64;
    bool indirect = elf_external_call ||
                    (selector->position_independent && ir_symbol_is_interposable(record));
    return (u8)(!indirect ? MACHINE_SYMBOL_REFERENCE_DIRECT : call_site ? MACHINE_SYMBOL_REFERENCE_PLT : MACHINE_SYMBOL_REFERENCE_GOT);
}

// One call-target row and the reference form beside it, which are appended
// together everywhere or the two columns stop being parallel.
BUSTER_GLOBAL_LOCAL u32 machine_x64_call_target(MachineX64Selector* selector, IrSymbolId symbol, u8 reference)
{
    u32 target_index = selector->call_targets.total_count;
    MachineX64CallTarget* row = selector->call_target_cursor;
    if (row == selector->call_target_end)
    {
        row = (MachineX64CallTarget*)machine_stream_cursor_refill(selector->arena, &selector->call_targets);
        selector->call_target_end = row + selector->call_targets.chunk_capacity;
    }
    selector->call_target_cursor = row + 1;
    selector->call_targets.total_count = target_index + 1;
    *row = (MachineX64CallTarget){.symbol = symbol, .reference = reference};
    return target_index;
}

BUSTER_GLOBAL_LOCAL u8 const machine_x64_system_v_arguments[6] = {
    MACHINE_X64_RDI, MACHINE_X64_RSI, MACHINE_X64_RDX, MACHINE_X64_RCX, MACHINE_X64_R8, MACHINE_X64_R9,
};

BUSTER_CT_CHECK(MACHINE_X64_REGISTER_COUNT <= MACHINE_TARGET_REGISTER_LIMIT);

// The register file and special-opcode identities the shared allocators
// consume; RSP and RBP are reserved. The callee-saved members cost one
// push/pop pair per function that binds them, and their pushes carry
// unwind actions.
BUSTER_GLOBAL_LOCAL MachineTargetDescription const machine_x86_64_description = {
    .allocatable_mask = (1u << MACHINE_X64_RAX) | (1u << MACHINE_X64_RCX) | (1u << MACHINE_X64_RDX) | (1u << MACHINE_X64_RSI) | (1u << MACHINE_X64_RDI) |
                        (1u << MACHINE_X64_R8) | (1u << MACHINE_X64_R9) | (1u << MACHINE_X64_R10) | (1u << MACHINE_X64_R11) | (1u << MACHINE_X64_RBX) |
                        (1u << MACHINE_X64_R12) | (1u << MACHINE_X64_R13) | (1u << MACHINE_X64_R14) | (1u << MACHINE_X64_R15),
    .callee_saved_mask =
        (1u << MACHINE_X64_RBX) | (1u << MACHINE_X64_R12) | (1u << MACHINE_X64_R13) | (1u << MACHINE_X64_R14) | (1u << MACHINE_X64_R15),
    .register_count = MACHINE_X64_REGISTER_COUNT,
    .predicate_allocatable_mask = MACHINE_PREDICATE_ALLOCATABLE_MASK,
    .slot_scratch = {MACHINE_X64_RAX, MACHINE_X64_RCX, MACHINE_X64_RDX, MACHINE_X64_RSI},
    .copy_opcode = MACHINE_X64_MOV_RR,
    .constant_opcode = MACHINE_X64_MOV_RI,
    .indirect_call_opcode = MACHINE_X64_CALL_INDIRECT,
    .unconditional_branch_opcode = MACHINE_X64_JMP,
    .frame_address_opcode = MACHINE_X64_LEA_FRAME,
    .switch_opcode = MACHINE_X64_SWITCH,
    .float_bridge_opcode = MACHINE_X64_MOVQ_TO_XMM,
    .indirect_call_register = MACHINE_X64_R10,
    .float_bridge_register = MACHINE_X64_RAX,
    // The whole callee-saved file, highest register first so the pins
    // collide last with the local scan's own callee-saved bindings, which
    // probe in register order from RBX up.
    .quality_pin_registers = {MACHINE_X64_R15, MACHINE_X64_R14, MACHINE_X64_R13, MACHINE_X64_R12, MACHINE_X64_RBX},
    .quality_pin_register_count = 5,
    // ZMM0-31 at unified indices 16-47; System V keeps every one
    // caller-saved, so the call flush spills the whole vector file. The
    // full file rides in the static description because it is reachable
    // only through vector virtual registers, which the selector produces
    // only under the AVX512F gate — the same gate that makes ZMM16-31
    // architectural.
    .vector_register_mask = 0xffffffffull << MACHINE_X64_ZMM0,
    .vector_allocatable_mask = 0xffffffffull << MACHINE_X64_ZMM0,
    .vector_copy_opcode = MACHINE_X64_VMOV_RR,
    .vector_slot_scratch = {MACHINE_X64_ZMM0, MACHINE_X64_ZMM1, MACHINE_X64_ZMM2, MACHINE_X64_ZMM3},
};

MachineTargetDescription const* machine_target_x86_64(void)
{
    return &machine_x86_64_description;
}

// Win64's four positional argument registers. Slot i takes this register for
// an integer part or XMM i for a float part — never both files at once, which
// is the whole difference from the System V sequences above.
BUSTER_GLOBAL_LOCAL u8 const machine_x64_windows_arguments[4] = {
    MACHINE_X64_RCX,
    MACHINE_X64_RDX,
    MACHINE_X64_R8,
    MACHINE_X64_R9,
};

// The same allocatable file as System V; the ABI moves RSI and RDI into the
// callee-saved half, so a call preserves them and binding one costs a
// prologue push. The vector class keeps only the registers Win64 leaves
// volatile: XMM6-15's low halves are callee-saved and the allocator has no
// shape for saving them, so ZMM6-15 stay out of the file entirely.
// The scratch slots avoid RSI for the same reason — MIR_STACK writes them
// without recording a save.
BUSTER_GLOBAL_LOCAL MachineTargetDescription const machine_x86_64_windows_description = {
    .allocatable_mask = (1u << MACHINE_X64_RAX) | (1u << MACHINE_X64_RCX) | (1u << MACHINE_X64_RDX) | (1u << MACHINE_X64_RSI) | (1u << MACHINE_X64_RDI) |
                        (1u << MACHINE_X64_R8) | (1u << MACHINE_X64_R9) | (1u << MACHINE_X64_R10) | (1u << MACHINE_X64_R11) | (1u << MACHINE_X64_RBX) |
                        (1u << MACHINE_X64_R12) | (1u << MACHINE_X64_R13) | (1u << MACHINE_X64_R14) | (1u << MACHINE_X64_R15),
    .callee_saved_mask = (1u << MACHINE_X64_RBX) | (1u << MACHINE_X64_RSI) | (1u << MACHINE_X64_RDI) | (1u << MACHINE_X64_R12) | (1u << MACHINE_X64_R13) |
                         (1u << MACHINE_X64_R14) | (1u << MACHINE_X64_R15),
    .register_count = MACHINE_X64_REGISTER_COUNT,
    .predicate_allocatable_mask = MACHINE_PREDICATE_ALLOCATABLE_MASK,
    .slot_scratch = {MACHINE_X64_RAX, MACHINE_X64_RCX, MACHINE_X64_RDX, MACHINE_X64_R11},
    .copy_opcode = MACHINE_X64_MOV_RR,
    .constant_opcode = MACHINE_X64_MOV_RI,
    .indirect_call_opcode = MACHINE_X64_CALL_INDIRECT,
    .unconditional_branch_opcode = MACHINE_X64_JMP,
    .frame_address_opcode = MACHINE_X64_LEA_FRAME,
    .switch_opcode = MACHINE_X64_SWITCH,
    .float_bridge_opcode = MACHINE_X64_MOVQ_TO_XMM,
    .indirect_call_register = MACHINE_X64_R10,
    .float_bridge_register = MACHINE_X64_RAX,
    .quality_pin_registers = {MACHINE_X64_R15, MACHINE_X64_R14, MACHINE_X64_R13, MACHINE_X64_R12, MACHINE_X64_RDI, MACHINE_X64_RSI, MACHINE_X64_RBX},
    .quality_pin_register_count = 7,
    .vector_register_mask = 0xffffffffull << MACHINE_X64_ZMM0,
    .vector_allocatable_mask = (0x3full << MACHINE_X64_ZMM0) | (0xffffull << MACHINE_X64_ZMM16),
    .vector_copy_opcode = MACHINE_X64_VMOV_RR,
    .saves_precede_frame_pointer = 1,
    .vector_slot_scratch = {MACHINE_X64_ZMM0, MACHINE_X64_ZMM1, MACHINE_X64_ZMM2, MACHINE_X64_ZMM3},
};

BUSTER_F_DECL MachineTargetDescription const* machine_target_x86_64_windows(void)
{
    return &machine_x86_64_windows_description;
}

// Win64 covers the Windows and UEFI targets, matching ir_target_abi_convention.
BUSTER_GLOBAL_LOCAL bool machine_x64_target_is_windows(Target target)
{
    return target.os == OPERATING_SYSTEM_WINDOWS || target.os == OPERATING_SYSTEM_UEFI;
}

BUSTER_GLOBAL_LOCAL IrAbiConvention machine_x64_abi_convention(Target target)
{
    return machine_x64_target_is_windows(target) ? IR_ABI_CONVENTION_WIN64_X86_64 : IR_ABI_CONVENTION_SYSTEMV_X86_64;
}

// Win64 and x86-64 UEFI represent va_list as the address of the current
// argument. Keep that ABI-visible eight-byte object in the ordinary integer
// register path; VA_START/VA_COPY still own their frame-backed temporary and
// Windows VA_ARG continues to consume the pointer it loads from that slot.
BUSTER_GLOBAL_LOCAL bool machine_x64_type_is_windows_va_list(IrType* type, Target target)
{
    return machine_x64_target_is_windows(target) && type && type->layout.resolved && type->kind == IR_TYPE_VA_LIST && type->layout.size == 8;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_type_is_scalar_register(IrType* type)
{
    bool result;
    if (!type || !type->layout.resolved || type->layout.size > 8)
    {
        result = false;
    }
    else
    {
        result = type->kind == IR_TYPE_BOOLEAN || type->kind == IR_TYPE_INTEGER || type->kind == IR_TYPE_POINTER || type->kind == IR_TYPE_ENUM;
    }

    return result;
}

// The vector subset is the target-fixed 512-bit vocabulary: 64-byte vector
// values travel in ZMM-class virtual registers. Other vector values use their
// exact frame image, with sized transfers at ABI boundaries.
BUSTER_GLOBAL_LOCAL bool machine_x64_type_is_vector_register(IrProgram* program, IrType* type)
{
    bool result = program && type && type->layout.resolved && type->kind == IR_TYPE_VECTOR && type->layout.size == 64;
    if (result)
    {
        IrType* element = ir_type_from_id(&program->types, type->element_type);
        result = element && element->layout.resolved && element->layout.size &&
                 type->element_count <= UINT64_MAX / element->layout.size &&
                 type->element_count * element->layout.size == type->layout.size;
    }
    return result;
}

// The projected class of a type id, or the null class for an id the table
// does not hold: the same answer the predicates above give a null record.
BUSTER_GLOBAL_LOCAL BUSTER_INLINE MachineTypeClass machine_x64_type_class(MachineX64Selector const* selector, IrTypeId type_id)
{
    MachineTypeClass result;
    if (type_id.value < selector->type_class_count)
    {
        result = selector->type_classes[type_id.value];
    }
    else
    {
        result = MACHINE_TYPE_CLASS_NONE;
    }
    return result;
}

// The register width a scalar type occupies, over the projection: booleans
// are bytes, enums are 32 bits, pointers and functions 64, an integer its
// own width — from the class when that is a power of two, from the record
// for the rare other width — and anything else is zero.
BUSTER_GLOBAL_LOCAL u32 machine_x64_class_scalar_bit_width(MachineX64Selector const* selector, IrTypeId type_id, MachineTypeClass type_class)
{
    u32 result;
    switch (type_class.kind)
    {
    case IR_TYPE_BOOLEAN:
        result = 8;
        break;
    case IR_TYPE_INTEGER:
        result = type_class.bit_width_log2 != MACHINE_TYPE_CLASS_NO_LOG2 ? 1u << type_class.bit_width_log2
                                                                          : ir_type_from_id(&selector->program->types, type_id)->bit_width;
        break;
    case IR_TYPE_ENUM:
        result = 32;
        break;
    case IR_TYPE_POINTER:
    case IR_TYPE_FUNCTION:
        result = 64;
        break;
    default:
        result = 0;
        break;
    }
    return result;
}

// The only sixteen-byte scalar float carried here is resolved SysV f80.
// AArch64 binary128 and Win64 long double remain their own target shapes.
BUSTER_GLOBAL_LOCAL bool machine_x64_type_is_f80(MachineX64Selector const* selector, IrTypeId type_id)
{
    MachineTypeClass type_class = machine_x64_type_class(selector, type_id);
    bool result = !machine_x64_target_is_windows(selector->target) && type_class.kind == IR_TYPE_FLOAT && type_class.size_log2 == 4;
    if (result)
    {
        result = codegen_canonical_x64_type_is_f80(ir_type_from_id(&selector->program->types, type_id));
    }
    return result;
}

// Darwin caps bare vector ABI alignment at the CPU's available width.
// ELF retains the type's alignment even when transport splits to memory.
BUSTER_GLOBAL_LOCAL u32 machine_x64_vector_stack_alignment(IrType* type, Target target)
{
    u32 result = codegen_canonical_x64_stack_argument_alignment(type);
    if (target.os == OPERATING_SYSTEM_MACOS || target.os == OPERATING_SYSTEM_IOS)
    {
        result = BUSTER_MIN(result, target_vector_register_size(target));
    }
    return result;
}

typedef struct MachineX64PaddedVector MachineX64PaddedVector;
struct MachineX64PaddedVector
{
    u32 lane_count;
    u32 lane_size;
    u32 storage_size;
    bool floating;
};

// GNU vector_size preserves the requested logical lane count while rounding
// the object image to the next power of two. Keep both facts explicit at the
// machine boundary: lane operations use lane_count/lane_size, while placement,
// spills and copies always reserve storage_size bytes.
BUSTER_GLOBAL_LOCAL bool machine_x64_padded_vector(IrProgram* program, IrType* type, MachineX64PaddedVector* info)
{
    bool result = false;
    IrType* element = program && type && type->kind == IR_TYPE_VECTOR ? ir_type_from_id(&program->types, type->element_type) : 0;
    if (program && info && type && type->layout.resolved && type->layout.size && type->layout.size <= UINT32_MAX &&
        type->element_count && type->element_count <= UINT32_MAX && element && element->layout.resolved && element->layout.size &&
        element->layout.size <= 8 && (element->kind == IR_TYPE_INTEGER || element->kind == IR_TYPE_FLOAT) &&
        (element->kind != IR_TYPE_FLOAT || element->layout.size == 2 || element->layout.size == 4 || element->layout.size == 8) &&
        type->element_count <= UINT64_MAX / element->layout.size)
    {
        u64 logical_size = type->element_count * element->layout.size;
        result = logical_size < type->layout.size && type->layout.size == next_power_of_two(logical_size);
        if (result)
        {
            *info = (MachineX64PaddedVector){
                .lane_count = (u32)type->element_count,
                .lane_size = (u32)element->layout.size,
                .storage_size = (u32)type->layout.size,
                .floating = element->kind == IR_TYPE_FLOAT,
            };
        }
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_padded_vector_native(Target target, MachineX64PaddedVector* info)
{
    u32 native_width = BUSTER_MAX(16u, target_vector_register_size(target));
    return info && info->storage_size <= native_width;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_windows_padded_vector_indirect(Target target, MachineX64PaddedVector* info)
{
    bool result = false;
    if (info)
    {
        u32 native_width = BUSTER_MAX(16u, target_vector_register_size(target));
        result = (info->floating && info->lane_size == 2) ||
                 (info->storage_size >= 16 && info->storage_size <= native_width);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_value_shape(IrProgram* program, IrTypeId type_id, IrAbiUse use, Target target, MachineX64ValueShape* shape)
{
    IrType* type = ir_type_from_id(&program->types, type_id);
    IrAbiConvention convention = machine_x64_abi_convention(target);
    if (machine_x64_type_is_windows_va_list(type, target))
    {
        *shape = (MachineX64ValueShape){.part_count = 1, .byte_size = 8, .exact_byte_size = 8};
        return true;
    }
    MachineX64PaddedVector padded = {0};
    if (machine_x64_padded_vector(program, type, &padded))
    {
        bool windows = convention == IR_ABI_CONVENTION_WIN64_X86_64;
        bool native = windows ? machine_x64_windows_padded_vector_indirect(target, &padded)
                              : machine_x64_padded_vector_native(target, &padded);
        u32 stack_alignment = machine_x64_vector_stack_alignment(type, target);
        if (use == IR_ABI_USE_RESULT)
        {
            if (native && padded.storage_size >= 16)
            {
                *shape = (MachineX64ValueShape){
                    .part_count = 1,
                    .byte_size = padded.storage_size,
                    .exact_byte_size = padded.storage_size,
                    .aggregate = true,
                    .vector_part_bytes = (u8)padded.storage_size,
                    .stack_alignment = stack_alignment,
                };
                return true;
            }
            if (!native && padded.lane_count == 3 && (!padded.floating || padded.lane_size == 8))
            {
                *shape = (MachineX64ValueShape){
                    .part_offsets = {0, padded.lane_size, padded.lane_size * 2},
                    .part_is_float = {padded.floating, padded.floating, 0},
                    .part_sizes = {(u8)padded.lane_size, (u8)padded.lane_size, (u8)padded.lane_size},
                    .part_count = 3,
                    .byte_size = padded.storage_size,
                    .exact_byte_size = padded.storage_size,
                    .aggregate = true,
                    .x87_f64_result = padded.floating,
                    .stack_alignment = stack_alignment,
                };
                return true;
            }
            if (!native)
            {
                *shape = (MachineX64ValueShape){
                    .byte_size = padded.storage_size,
                    .exact_byte_size = padded.storage_size,
                    .aggregate = true,
                    .indirect = true,
                    .stack_alignment = stack_alignment,
                };
                return true;
            }
        }
        else if (windows)
        {
            if (native)
            {
                *shape = (MachineX64ValueShape){
                    .part_count = 1,
                    .byte_size = padded.storage_size,
                    .exact_byte_size = padded.storage_size,
                    .aggregate = true,
                    .indirect = true,
                    .stack_alignment = BUSTER_MAX(stack_alignment, 16u),
                };
            }
            else
            {
                *shape = (MachineX64ValueShape){
                    .part_count = padded.lane_count,
                    .byte_size = padded.storage_size,
                    .exact_byte_size = padded.storage_size,
                    .aggregate = true,
                    .windows_scalar_lane_size = (u8)padded.lane_size,
                    .windows_scalar_float = padded.floating,
                    .stack_alignment = 8,
                };
            }
            return true;
        }
        else if (!native)
        {
            *shape = (MachineX64ValueShape){
                .byte_size = padded.storage_size,
                .exact_byte_size = padded.storage_size,
                .aggregate = true,
                .force_stack = true,
                .stack_alignment = stack_alignment,
            };
            return true;
        }
        else if (padded.storage_size >= 16)
        {
            *shape = (MachineX64ValueShape){
                .part_count = 1,
                .byte_size = padded.storage_size,
                .exact_byte_size = padded.storage_size,
                .aggregate = true,
                .vector_part_bytes = (u8)padded.storage_size,
                .stack_alignment = stack_alignment,
            };
            return true;
        }
    }
    if (machine_x64_type_is_vector_register(program, type) && ir_simd_operation_supported(target, IR_SIMD_SPLAT_BYTE))
    {
        // Native 512-bit values retain their existing ZMM dataflow. Other
        // CPU models use the frame-backed transport below.
        IrAbiValue vector_abi = ir_type_abi_value(program, type_id, convention, use);
        bool indirect = convention == IR_ABI_CONVENTION_WIN64_X86_64 && use != IR_ABI_USE_RESULT;
        if (vector_abi.indirect != indirect || vector_abi.memory || vector_abi.part_count != 1 ||
            (!indirect && (vector_abi.parts[0].abi_class != IR_ABI_CLASS_VECTOR || vector_abi.parts[0].size != 64)))
        {
            return false;
        }
        *shape = (MachineX64ValueShape){
            .part_is_float = {indirect ? 0 : 1},
            .part_count = 1,
            .byte_size = 64,
            .exact_byte_size = 64,
            .vector = true,
            .indirect = indirect,
            .stack_alignment = 64,
        };
        return true;
    }
    if (type && type->layout.resolved && type->kind == IR_TYPE_VECTOR &&
        ((type->layout.size == 32 || type->layout.size == 64) ||
         (convention == IR_ABI_CONVENTION_WIN64_X86_64 && type->layout.size >= 32 && type->layout.size <= UINT32_MAX &&
          !(type->layout.size & (type->layout.size - 1)))))
    {
        IrAbiValue abi = ir_type_abi_value(program, type_id, convention, use);
        u32 part_bytes = BUSTER_MIN((u32)type->layout.size, target_vector_register_size(target));
        bool indirect = convention == IR_ABI_CONVENTION_WIN64_X86_64 && use != IR_ABI_USE_RESULT;
        u32 reference_piece_bytes = 0;
        u32 reference_pieces = indirect ? codegen_canonical_x64_windows_vector_argument_pieces(&target, type, &reference_piece_bytes) : 0;
        u32 result_register_bytes = 0;
        u32 result_registers = !indirect && convention == IR_ABI_CONVENTION_WIN64_X86_64
                                   ? codegen_canonical_x64_vector_part_registers(&target, (u32)type->layout.size, &result_register_bytes)
                                   : 0;
        bool indirect_result = !indirect && convention == IR_ABI_CONVENTION_WIN64_X86_64 && type->layout.size > 64 &&
                               (!result_registers || result_registers > 4);
        bool direct_result_override = !indirect && convention == IR_ABI_CONVENTION_WIN64_X86_64 && type->layout.size > 64 &&
                                      result_registers && result_registers <= 4;
        bool direct_abi = !abi.indirect && !abi.memory && abi.part_count == 1 &&
                          abi.parts[0].abi_class == IR_ABI_CLASS_VECTOR && abi.parts[0].size == type->layout.size;
        bool supported = part_bytes && (part_bytes == 16 || part_bytes == 32 || part_bytes == 64) && !abi.memory &&
                         ((indirect && abi.indirect && abi.part_count == 1 && reference_pieces) ||
                          (indirect_result && abi.indirect) || (!indirect_result && (direct_abi || direct_result_override)));
        if (supported)
        {
            if (indirect_result)
            {
                *shape = (MachineX64ValueShape){
                    .byte_size = (u32)type->layout.size,
                    .exact_byte_size = (u32)type->layout.size,
                    .aggregate = true,
                    .indirect = true,
                    .stack_alignment = machine_x64_vector_stack_alignment(type, target),
                };
            }
            else
            {
                // A split result owns consecutive vector registers. A split
                // System V argument instead uses memory, preserving the current
                // direct ABI and Clang's caller/consumer contract.
                bool force_stack = !indirect && use != IR_ABI_USE_RESULT && part_bytes < type->layout.size;
                *shape = (MachineX64ValueShape){
                    .part_count = indirect ? reference_pieces : force_stack ? 0u : (u32)type->layout.size / part_bytes,
                    .byte_size = (u32)type->layout.size,
                    .exact_byte_size = (u32)type->layout.size,
                    .aggregate = true,
                    .indirect = indirect,
                    .vector_part_bytes = force_stack ? 0 : (u8)(indirect && reference_pieces > 1 ? reference_piece_bytes : part_bytes),
                    .force_stack = force_stack,
                    .stack_alignment = machine_x64_vector_stack_alignment(type, target),
                };
                if (indirect && reference_pieces == 1)
                {
                    shape->vector_part_bytes = 0;
                }
            }
        }
        return supported;
    }
    if (machine_x64_type_is_scalar_register(type))
    {
        u16 extend_opcode = 0;
        if (type->kind == IR_TYPE_BOOLEAN || (type->kind == IR_TYPE_INTEGER && type->bit_width == 8))
        {
            extend_opcode = type->kind == IR_TYPE_INTEGER && type->is_signed ? MACHINE_X64_MOVSX8_RR : MACHINE_X64_MOVZX8_RR;
        }
        else if (type->kind == IR_TYPE_INTEGER && type->bit_width == 16)
        {
            extend_opcode = type->is_signed ? MACHINE_X64_MOVSX16_RR : MACHINE_X64_MOVZX16_RR;
        }
        *shape = (MachineX64ValueShape){
            .part_count = 1,
            .byte_size = 8,
            .scalar_extend_opcode = extend_opcode,
        };
        return true;
    }
    if (type && type->layout.resolved && type->kind == IR_TYPE_FLOAT &&
        ((type->bit_width == 16 && type->float_format == IR_FLOAT_FORMAT_IEEE) || type->bit_width == 32 || type->bit_width == 64))
    {
        *shape = (MachineX64ValueShape){
            .part_is_float = {1},
            .part_count = 1,
            .byte_size = 8,
        };
        return true;
    }
    if (convention == IR_ABI_CONVENTION_SYSTEMV_X86_64 && codegen_canonical_x64_type_is_f80(type))
    {
        *shape = (MachineX64ValueShape){.byte_size = 16, .aggregate = true,
            .force_stack = use != IR_ABI_USE_RESULT, .f80_result = use == IR_ABI_USE_RESULT, .stack_alignment = 16};
        return true;
    }
    // A 128-bit integer is the System V two-eightbyte INTEGER pair — RAX:RDX
    // as a result, two consecutive GPRs or whole-value stack eightbytes as an
    // argument — the same parts the canonical integer-aggregate rule builds,
    // carried by the aggregate machinery over the value's 16-byte slot.
    if (type && type->layout.resolved && type->kind == IR_TYPE_INTEGER && type->bit_width == 128)
    {
        bool windows = convention == IR_ABI_CONVENTION_WIN64_X86_64;
        // Clang's Win64 ABI passes i128 through one pointer slot and returns
        // all sixteen bytes in XMM0. Keep the value frame-backed on both
        // sides so ordinary i128 arithmetic continues to consume its limbs.
        *shape = (MachineX64ValueShape){
            .part_offsets = {0, 8},
            .part_count = windows ? 1 : 2,
            .byte_size = 16,
            .exact_byte_size = 16,
            .aggregate = true,
            .indirect = windows && use != IR_ABI_USE_RESULT,
            .xmm128 = windows && use == IR_ABI_USE_RESULT,
            .stack_alignment = 16,
        };
        return true;
    }
    if (!type || !type->layout.resolved || (type->kind != IR_TYPE_STRUCT && type->kind != IR_TYPE_UNION && type->kind != IR_TYPE_SLICE &&
                                           !(type->kind == IR_TYPE_VECTOR && type->layout.size <= 16)))
    {
        return false;
    }
    IrAbiValue abi = ir_type_abi_value(program, type_id, convention, use);
    if (use == IR_ABI_USE_RESULT && convention == IR_ABI_CONVENTION_SYSTEMV_X86_64 && !abi.memory && !abi.indirect &&
        ((abi.part_count == 2 && type->layout.size == 16 && abi.parts[0].abi_class == IR_ABI_CLASS_X87 &&
          abi.parts[1].abi_class == IR_ABI_CLASS_X87_UP) || ir_abi_value_is_complex_x87_result(program, type_id, convention)))
    {
        *shape = (MachineX64ValueShape){.byte_size = (u32)type->layout.size, .aggregate = true, .stack_alignment = 16,
            .f80_result = (u8)(abi.part_count / 2)};
        return true;
    }
    if (abi.indirect || abi.memory || !abi.part_count || abi.part_count > 2)
    {
        if (type->layout.size > UINT32_MAX - 7)
        {
            return false;
        }
        if ((use == IR_ABI_USE_RESULT && (abi.indirect || abi.memory)) ||
            (use != IR_ABI_USE_RESULT && convention == IR_ABI_CONVENTION_WIN64_X86_64 && abi.indirect))
        {
            // Large results use a hidden pointer. Win64 aggregate arguments
            // use one pointer slot, backed by a private copy meeting the type's
            // alignment and the outgoing area's sixteen-byte floor.
            *shape = (MachineX64ValueShape){
                .part_count = use == IR_ABI_USE_RESULT ? 0 : 1,
                .byte_size = (u32)((type->layout.size + 7) & ~(u64)7),
                .exact_byte_size = (u32)type->layout.size,
                .aggregate = true,
                .indirect = true,
                .stack_alignment = use == IR_ABI_USE_RESULT ? 0 : BUSTER_MAX(codegen_canonical_x64_stack_argument_alignment(type), 16u),
            };
            return true;
        }
        if (use != IR_ABI_USE_RESULT && abi.memory && !abi.indirect)
        {
            // Memory-class arguments pass by value on the stack.
            *shape = (MachineX64ValueShape){
                .byte_size = (u32)((type->layout.size + 7) & ~(u64)7),
                .aggregate = true,
                .force_stack = true,
                .stack_alignment = codegen_canonical_x64_stack_argument_alignment(type),
            };
            return true;
        }
        return false;
    }
    if (type->layout.size > UINT32_MAX - 7)
    {
        return false;
    }
    MachineX64ValueShape built = {
        .part_count = abi.part_count,
        .byte_size = (u32)((type->layout.size + 7) & ~(u64)7),
        .aggregate = true,
        .stack_alignment = codegen_canonical_x64_stack_argument_alignment(type),
        .xmm128 = abi.part_count == 1 && abi.parts[0].abi_class == IR_ABI_CLASS_VECTOR && abi.parts[0].size == 16,
    };
    for (u32 part_index = 0; part_index < abi.part_count; part_index += 1)
    {
        bool part_float = abi.parts[part_index].abi_class == IR_ABI_CLASS_FLOAT || abi.parts[part_index].abi_class == IR_ABI_CLASS_VECTOR;
        if ((abi.parts[part_index].abi_class != IR_ABI_CLASS_INTEGER && abi.parts[part_index].abi_class != IR_ABI_CLASS_POINTER && !part_float) ||
            (abi.parts[part_index].size > 8 && !built.xmm128))
        {
            return false;
        }
        built.part_offsets[part_index] = abi.parts[part_index].value_offset;
        built.part_is_float[part_index] = part_float ? 1 : 0;
        built.part_sizes[part_index] = (u8)abi.parts[part_index].size;
    }
    *shape = built;
    return true;
}

// Consecutive-register assignment per class: integer parts take the next
// System V general register, float parts the next XMM register.
BUSTER_GLOBAL_LOCAL u32 machine_x64_shape_class_parts(MachineX64ValueShape* shape, bool floats)
{
    u32 count = 0;
    if (shape->windows_scalar_lane_size)
    {
        count = shape->windows_scalar_float == floats ? shape->part_count : 0;
    }
    else if (shape->vector_part_bytes)
    {
        // Direct vector pieces consume the float register file; split
        // by-reference pieces are pointers and consume the integer file.
        count = (shape->indirect ? !floats : floats) ? shape->part_count : 0;
    }
    else
    {
        for (u32 part_index = 0; part_index < shape->part_count; part_index += 1)
        {
            count += (shape->part_is_float[part_index] != 0) == floats;
        }
    }
    return count;
}

// Incoming and outgoing addressing use signed 32-bit frame displacements.
// Check in bytes before placement narrows or advances any stack cursor.
BUSTER_GLOBAL_LOCAL bool machine_x64_argument_area_fits(MachineX64ValueShape* shape, u32 stack_parts)
{
    u64 bytes = shape->windows_scalar_lane_size ? (u64)shape->part_count * 8u
                                               : shape->indirect ? (u64)shape->part_count * 8u : shape->byte_size;
    return (u64)stack_parts * 8u + bytes + shape->stack_alignment + 32u <= INT32_MAX;
}

// Assigns one argument to registers when its whole shape fits the remaining
// per-class sequences, otherwise to consecutive outgoing stack eightbytes —
// the canonical all-or-nothing rule.
BUSTER_GLOBAL_LOCAL void machine_x64_place_argument(MachineX64ValueShape* shape, bool windows, u32* integer_count, u32* float_count, u32* stack_part_count,
                                                    MachineX64ArgumentPlacement* placement)
{
    u32 integer_parts = machine_x64_shape_class_parts(shape, false);
    u32 float_parts = machine_x64_shape_class_parts(shape, true);
    if (windows)
    {
        // Ordinary arguments occupy one positional slot. Split references
        // are the Win64 exception: each piece is a pointer slot, and a value
        // can straddle the remaining GPRs and the outgoing stack tail.
        u32 slot = BUSTER_MAX(*integer_count, *float_count);
        if (shape->windows_scalar_lane_size)
        {
            u32 available = slot < BUSTER_ARRAY_LENGTH(machine_x64_windows_arguments)
                                ? BUSTER_ARRAY_LENGTH(machine_x64_windows_arguments) - slot
                                : 0;
            u32 register_parts = BUSTER_MIN(shape->part_count, available);
            u32 stack_parts = shape->part_count - register_parts;
            *placement = (MachineX64ArgumentPlacement){
                .first_integer = (u16)slot,
                .first_float = (u16)slot,
                .first_stack_part = *stack_part_count,
                .stack_part_count = stack_parts,
                .on_stack = stack_parts != 0,
                .register_part_count = (u8)register_parts,
            };
            *integer_count = slot + register_parts;
            *float_count = slot + register_parts;
            *stack_part_count += stack_parts;
        }
        else if (shape->indirect && shape->vector_part_bytes)
        {
            u32 available = slot < BUSTER_ARRAY_LENGTH(machine_x64_windows_arguments)
                                ? BUSTER_ARRAY_LENGTH(machine_x64_windows_arguments) - slot
                                : 0;
            u32 register_parts = BUSTER_MIN(shape->part_count, available);
            u32 stack_parts = shape->part_count - register_parts;
            *placement = (MachineX64ArgumentPlacement){
                .first_integer = (u16)slot,
                .first_float = (u16)slot,
                .first_stack_part = *stack_part_count,
                .stack_part_count = stack_parts,
                .on_stack = stack_parts != 0,
                .register_part_count = (u8)register_parts,
            };
            *integer_count = slot + register_parts;
            *float_count = slot + register_parts;
            *stack_part_count += stack_parts;
        }
        else if (shape->force_stack || shape->part_count != 1 || slot >= BUSTER_ARRAY_LENGTH(machine_x64_windows_arguments))
        {
            u32 parts = shape->indirect ? 1 : shape->byte_size / 8;
            *placement = (MachineX64ArgumentPlacement){
                .first_stack_part = *stack_part_count,
                .stack_part_count = parts,
                .on_stack = true,
            };
            *stack_part_count += parts;
            *integer_count = slot + 1;
            *float_count = slot + 1;
        }
        else
        {
            *placement = (MachineX64ArgumentPlacement){
                .first_integer = (u16)slot,
                .first_float = (u16)slot,
                .register_part_count = 1,
            };
            *integer_count = slot + 1;
            *float_count = slot + 1;
        }
    }
    else if (shape->force_stack || *integer_count + integer_parts > BUSTER_ARRAY_LENGTH(machine_x64_system_v_arguments) ||
             *float_count + float_parts > 8)
    {
        // A stack home starts at the offset its type's argument-area
        // alignment asks for — a 64-byte vector at a 64-aligned offset, the
        // System V __int128 pair and a sixteen-aligned memory-class
        // aggregate at a sixteen-aligned one. The canonical layout pads the
        // cursor with eightbytes the callee never reads, and both sides
        // must count them.
        u32 alignment_parts = shape->stack_alignment / 8;
        if (alignment_parts > 1)
        {
            *stack_part_count = (*stack_part_count + alignment_parts - 1u) & ~(alignment_parts - 1u);
        }
        *placement = (MachineX64ArgumentPlacement){
            .first_stack_part = *stack_part_count,
            .stack_part_count = (shape->byte_size / 8),
            .on_stack = true,
        };
        *stack_part_count += shape->byte_size / 8;
    }
    else
    {
        *placement = (MachineX64ArgumentPlacement){
            .first_integer = (u16)*integer_count,
            .first_float = (u16)*float_count,
        };
        *integer_count += integer_parts;
        *float_count += float_parts;
    }
}

// The integer register an argument slot occupies under the running ABI.
// Placement above guarantees the index is inside its own file.
BUSTER_GLOBAL_LOCAL u32 machine_x64_argument_register(bool windows, u32 index)
{
    return windows ? machine_x64_windows_arguments[index] : machine_x64_system_v_arguments[index];
}

// The integer ALU encodings are physically two-address, but their selected
// rows carry an explicit SSA destination, first source, and second source.
// Fixed-register shifts and divide/remainder remain on their legacy
// constrained shape until their slot constraints are fully target-metadata
// driven.
BUSTER_GLOBAL_LOCAL bool machine_x64_opcode_is_ssa_two_address(u16 opcode)
{
    bool result;
    switch (opcode)
    {
    case MACHINE_X64_ADD32:
    case MACHINE_X64_ADD64:
    case MACHINE_X64_SUB32:
    case MACHINE_X64_SUB64:
    case MACHINE_X64_AND32:
    case MACHINE_X64_AND64:
    case MACHINE_X64_OR32:
    case MACHINE_X64_OR64:
    case MACHINE_X64_XOR32:
    case MACHINE_X64_XOR64:
    case MACHINE_X64_IMUL32:
    case MACHINE_X64_IMUL64:
        result = true;
        break;
    default:
        result = false;
        break;
    }

    return result;
}

// Address-producing place definitions: their machine vreg holds an 8-byte
// address regardless of the value's declared canonical type, exactly like
// the canonical path stores an address in the value's slot.
BUSTER_GLOBAL_LOCAL bool machine_x64_opcode_produces_address(IrOpcode opcode)
{
    return opcode == IR_OPCODE_GLOBAL || opcode == IR_OPCODE_INDEX || opcode == IR_OPCODE_FIELD || opcode == IR_OPCODE_DEREFERENCE ||
           opcode == IR_OPCODE_ADDRESS_OF || opcode == IR_OPCODE_FUNCTION;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_operand_register(MachineX64Selector* selector, IrValueId value, u32* register_out)
{
    bool result;
    if (value.value >= selector->function->value_count || selector->value_virtual_registers[value.value] == UINT32_MAX)
    {
        result = false;
    }
    else
    {
        *register_out = selector->value_virtual_registers[value.value];
        result = true;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_select_row(MachineX64Selector* selector, MachineInstruction instruction)
{
    machine_builder_classify_instruction_mutability(&selector->builder, &instruction);
    return machine_builder_instruction(&selector->builder, instruction);
}

BUSTER_GLOBAL_LOCAL void machine_x64_define(MachineX64Selector* selector, u32 virtual_register, u32 machine_index)
{
    // Selection-synthesized vregs sit past the classification count and
    // carry their definition point from creation.
    if (virtual_register < selector->virtual_register_count)
    {
        u32 chunk_capacity = selector->builder.virtual_registers.chunk_capacity;
        MachineVirtualRegister* row;
        if (virtual_register < chunk_capacity)
        {
            row = selector->classification_registers + virtual_register;
        }
        else
        {
            MachineBuilderChunk* chunk = selector->builder.virtual_registers.first;
            u32 remaining = virtual_register;
            while (remaining >= chunk_capacity)
            {
                remaining -= chunk_capacity;
                chunk = chunk->next;
            }
            row = (MachineVirtualRegister*)(chunk + 1) + remaining;
        }
        if (row->definition_point == MACHINE_POINT_INVALID)
        {
            row->definition_point = machine_point_make(machine_index, MACHINE_POINT_AFTER);
        }
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_reject(MachineX64Selector* selector, IrOpcode opcode)
{
    selector->supported = false;
    selector->failed_opcode = opcode;
}

// The x86 condition nibble for an integer/pointer/boolean comparison, or 0
// (never a comparison's nibble) for everything else. The nibbles pair as
// exact complements, so negation is condition ^ 1.
BUSTER_GLOBAL_LOCAL u32 machine_x64_condition_from_comparison(IrBinaryOperation operation)
{
    u32 result;
    switch (operation)
    {
    case IR_BINARY_INTEGER_EQUAL:
    case IR_BINARY_POINTER_EQUAL:
    case IR_BINARY_BOOLEAN_EQUAL:
        result = MACHINE_X64_CONDITION_EQUAL;
        break;
    case IR_BINARY_INTEGER_NOT_EQUAL:
    case IR_BINARY_POINTER_NOT_EQUAL:
    case IR_BINARY_BOOLEAN_NOT_EQUAL:
        result = MACHINE_X64_CONDITION_NOT_EQUAL;
        break;
    case IR_BINARY_SIGNED_LESS:
        result = MACHINE_X64_CONDITION_LESS;
        break;
    case IR_BINARY_SIGNED_LESS_EQUAL:
        result = MACHINE_X64_CONDITION_LESS_EQUAL;
        break;
    case IR_BINARY_SIGNED_GREATER:
        result = MACHINE_X64_CONDITION_GREATER;
        break;
    case IR_BINARY_SIGNED_GREATER_EQUAL:
        result = MACHINE_X64_CONDITION_GREATER_EQUAL;
        break;
    case IR_BINARY_UNSIGNED_LESS:
        result = MACHINE_X64_CONDITION_BELOW;
        break;
    case IR_BINARY_UNSIGNED_LESS_EQUAL:
        result = MACHINE_X64_CONDITION_BELOW_EQUAL;
        break;
    case IR_BINARY_UNSIGNED_GREATER:
        result = MACHINE_X64_CONDITION_ABOVE;
        break;
    case IR_BINARY_UNSIGNED_GREATER_EQUAL:
        result = MACHINE_X64_CONDITION_ABOVE_EQUAL;
        break;
    default:
        result = 0;
        break;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_append_slot(MachineX64Selector* selector, u32 size, u32 alignment)
{
    u32 slot_index = selector->stack_slots.total_count;
    MachineX64StackSlot* row = selector->stack_slot_cursor;
    if (row == selector->stack_slot_end)
    {
        row = (MachineX64StackSlot*)machine_stream_cursor_refill(selector->arena, &selector->stack_slots);
        selector->stack_slot_end = row + selector->stack_slots.chunk_capacity;
    }
    selector->stack_slot_cursor = row + 1;
    selector->stack_slots.total_count = slot_index + 1;
    *row = (MachineX64StackSlot){.size = size, .alignment = alignment};
    return slot_index;
}

BUSTER_GLOBAL_LOCAL void machine_x64_append_switch_case(MachineX64Selector* selector, MachineSwitchCase switch_case)
{
    MachineSwitchCase* row = selector->switch_case_cursor;
    if (row == selector->switch_case_end)
    {
        row = (MachineSwitchCase*)machine_stream_cursor_refill(selector->arena, &selector->switch_cases);
        selector->switch_case_end = row + selector->switch_cases.chunk_capacity;
    }
    selector->switch_case_cursor = row + 1;
    selector->switch_cases.total_count += 1;
    *row = switch_case;
}

// The index of a fresh immediate row: MOV_RI and the immediate ALU forms
// name their constant through it.
BUSTER_GLOBAL_LOCAL u32 machine_x64_append_immediate(MachineX64Selector* selector, u64 value)
{
    u32 index = selector->immediates.total_count;
    u64* row = selector->immediate_cursor;
    if (row == selector->immediate_end)
    {
        row = (u64*)machine_stream_cursor_refill(selector->arena, &selector->immediates);
        selector->immediate_end = row + selector->immediates.chunk_capacity;
    }
    selector->immediate_cursor = row + 1;
    selector->immediates.total_count = index + 1;
    *row = value;
    return index;
}

// The SysV va_list register-save offsets are measured in bytes from the
// save-area pointer: six eightbyte GP slots followed by eight sixteen-byte
// XMM slots.  Return the fixed named-parameter cursors that VA_START seeds.
BUSTER_GLOBAL_LOCAL void machine_x64_va_named_cursors(MachineX64Selector* selector, u32* integer_count, u32* float_count, u32* stack_end)
{
    *integer_count = selector->return_shape.indirect ? 1u : 0u;
    *float_count = 0;
    *stack_end = 0;
    IrType* function_type = ir_type_from_id(&selector->program->types, selector->function->canonical_type);
    if (!function_type || function_type->kind != IR_TYPE_FUNCTION)
    {
        return;
    }
    for (u32 argument = 0; argument < function_type->parameter_count; argument += 1)
    {
        MachineX64ValueShape* shape = selector->parameter_shapes + argument;
        MachineX64ArgumentPlacement* placement = selector->parameter_placements + argument;
        if (placement->on_stack)
        {
            *stack_end = BUSTER_MAX(*stack_end, ((u32)placement->first_stack_part + placement->stack_part_count) * 8u);
        }
        else
        {
            *integer_count = BUSTER_MAX(*integer_count, (u32)placement->first_integer + machine_x64_shape_class_parts(shape, false));
            *float_count = BUSTER_MAX(*float_count, (u32)placement->first_float + machine_x64_shape_class_parts(shape, true));
        }
    }
}

// Translate the IR-owned SysV variadic ABI classification into the compact
// side data consumed by MACHINE_X64_VA_ARG.  This deliberately handles only
// the scalar/two-eightbyte classes the machine subset can materialize; larger
// memory values still use one bounded overflow copy.
BUSTER_GLOBAL_LOCAL bool machine_x64_va_arg_metadata(MachineX64Selector* selector, IrType* type, u32 result_slot, bool result_is_frame,
                                                     MachineVaArg* metadata)
{
    bool result;
    if (type && type->layout.resolved && type->kind == IR_TYPE_VECTOR && result_is_frame &&
        (type->layout.size == 32 || type->layout.size == 64))
    {
        *metadata = (MachineVaArg){.size = (u32)type->layout.size, .alignment = machine_x64_vector_stack_alignment(type, selector->target),
            .stack_size = (u32)type->layout.size, .part_count = 1, .scalar_size = 8,
            .result_slot = result_slot, .result_is_frame = true, .parts = {{.size = 8, .is_memory = 1}}};
        result = true;
    }
    else if (!type || !type->layout.resolved || !type->layout.size || type->layout.size > UINT32_MAX || type->layout.alignment > 16)
    {
        result = false;
    }
    else if (codegen_canonical_x64_type_is_f80(type))
    {
        *metadata = (MachineVaArg){.size = 10, .alignment = 16, .stack_size = 16, .part_count = 2, .scalar_size = 8,
            .result_slot = result_slot, .result_is_frame = result_is_frame,
            .parts = {{.size = 8, .is_memory = 1}, {.value_offset = 8, .size = 2, .is_memory = 1}}};
        result = true;
    }
    else
    {
        IrTypeId type_id = {.value = (u32)(type - selector->program->types.types)};
        IrAbiValue abi = ir_type_abi_value(selector->program, type_id, IR_ABI_CONVENTION_SYSTEMV_X86_64, IR_ABI_USE_VARIADIC_ARGUMENT);
        result = abi.part_count && abi.part_count <= MACHINE_VA_ARG_PART_LIMIT;
        MachineVaArg value = {
            .size = (u32)type->layout.size,
            .alignment = BUSTER_MAX(type->layout.alignment, 8u),
            .stack_size = ((u32)type->layout.size + 7u) & ~7u,
            .part_count = abi.part_count,
            .result_slot = result_slot,
            .result_is_frame = result_is_frame,
            .scalar_size = (u8)BUSTER_MIN(type->layout.size, 8u),
        };
        u32 gp_index = 0;
        u32 fp_index = 0;
        for (u32 part_index = 0; result && part_index < abi.part_count; part_index += 1)
        {
            IrAbiPart* part = abi.parts + part_index;
            MachineVaArgPart* output = value.parts + part_index;
            output->value_offset = part->value_offset;
            output->size = (u8)(part->abi_class == IR_ABI_CLASS_VECTOR && part->size == 16 ? 16u : BUSTER_MIN(part->size, 8u));
            output->is_memory = part->abi_class == IR_ABI_CLASS_MEMORY;
            if (part->abi_class == IR_ABI_CLASS_FLOAT || part->abi_class == IR_ABI_CLASS_VECTOR)
            {
                output->is_float = 1;
                // The va_list fp_offset already includes the 48-byte GP save
                // area.  Unlike the fixed-parameter placement index, each
                // variadic part adds this relative offset exactly once to the
                // live fp cursor.
                output->save_offset = fp_index * 16u;
                fp_index += 1;
            }
            else if (part->abi_class == IR_ABI_CLASS_INTEGER || part->abi_class == IR_ABI_CLASS_POINTER)
            {
                output->save_offset = gp_index * 8u;
                gp_index += 1;
            }
            else if (!output->is_memory)
            {
                result = false;
            }
        }
        if (result) { *metadata = value; }
    }
    return result;
}

// Mirrors the canonical emitter's indirect-place test: an over-aligned
// local's virtual register holds a runtime-aligned pointer, so the local
// reads and writes exactly like a GLOBAL's address, never like a direct
// frame slot and never like a promoted register value.
BUSTER_GLOBAL_LOCAL bool machine_x64_local_is_indirect(MachineX64Selector* selector, IrValueId value)
{
    return value.value < selector->function->value_count && selector->value_indirect_slots[value.value] != UINT32_MAX;
}

BUSTER_GLOBAL_LOCAL MachineSelectionAddress machine_x64_address(MachineX64Selector* selector, IrValueId value)
{
    return machine_selection_address(selector->arena, selector->program, selector->function, &selector->address_cache, value);
}

// Emits the row computing the address (or pointer value) of `base` into
// `destination_register` and defines it: a direct local's frame-slot
// address, or a copy of any vreg-held value — mirroring the canonical
// path's lea-or-slot-load base handling. Returns false outside the subset.
// Places the address of `base` plus a constant byte offset in one row:
// a direct local folds the offset into its frame displacement, and a
// pointer folds it into a lea. Only a zero offset on a pointer stays a
// plain copy, which the allocator can then coalesce away.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_place_address_offset(MachineX64Selector* selector, IrValueId base, u32 destination_register, u32 byte_offset)
{
    IrFunction* function = selector->function;
    if (base.value >= function->value_count)
    {
        return false;
    }
    MachineSelectionAddress address = machine_x64_address(selector, base);
    // A zero-offset copy reuses the already materialized SSA address.
    // Recomputing it from the root would add encoding work at every use.
    if (byte_offset && address.index_value.value == IR_ID_UNDERLYING_INVALID && address.base_value.value != base.value &&
        address.displacement <= INT32_MAX && byte_offset <= (u32)INT32_MAX - address.displacement)
    {
        MachineSelectionAddress root = machine_x64_address(selector, address.base_value);
        bool promoted = root.opcode == IR_OPCODE_LOCAL && selector->value_virtual_registers[address.base_value.value] != UINT32_MAX &&
                        !machine_x64_local_is_indirect(selector, address.base_value);
        if (!promoted)
        {
            base = address.base_value;
            byte_offset += (u32)address.displacement;
            address = root;
        }
    }
    IrValue* value = function->values + base.value;
    u8 place_kind = selector->place_kinds[base.value];
    if (place_kind == MACHINE_X64_PLACE_NONE)
    {
        return false;
    }
    u32 slot = selector->value_stack_slots[base.value];
    if (place_kind == MACHINE_X64_PLACE_LOCAL && selector->value_virtual_registers[base.value] != UINT32_MAX &&
        !machine_x64_local_is_indirect(selector, base))
    {
        // A promoted local has no address. The promotability scan proved
        // no use needs one, so a request here is a selector hole — refuse
        // to the canonical fallback rather than hand a register's value
        // out as an address. An over-aligned local's register is the
        // aligned pointer itself and falls through to the pointer path.
        return false;
    }
    // An array or vector *value* is its storage, exactly like the
    // canonical INDEX base rule: its slot address is the base address.
    // Slices and struct values stay on the loaded-pointer path below,
    // matching the canonical emitter's per-opcode base handling.
    MachineTypeClass value_class = machine_x64_type_class(selector, value->canonical_type);
    bool storage_value = (address.flags & MACHINE_SELECTION_ADDRESS_STORAGE) != 0;
    if (storage_value && slot != UINT32_MAX)
    {
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, destination_register),
                                                                    machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
                                                       .payload = byte_offset,
                                                       .opcode = MACHINE_X64_LEA_FRAME,
                                                   });
        machine_x64_define(selector, destination_register, row);
        return true;
    }
    // A vreg-held value is copied as a pointer below, which only means
    // anything for a general-class register. A 512-bit rvalue's register is
    // not an address — an INDEX into one, reachable now that vector-ABI
    // calls and signatures select, snapshots the immutable SSA value into a
    // dedicated 64-byte slot and hands out that slot's address instead.
    if (value_class.flags & MACHINE_TYPE_CLASS_VECTOR_REGISTER)
    {
        u32 vector_register;
        if (!machine_x64_operand_register(selector, base, &vector_register))
        {
            return false;
        }
        u32 snapshot_slot = machine_x64_append_slot(selector, 64, 16);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, snapshot_slot),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, vector_register)},
                                             .opcode = MACHINE_X64_VSTORE_FRAME,
                                         });
        u32 snapshot_row = machine_x64_select_row(selector, (MachineInstruction){
                                                                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, destination_register),
                                                                             machine_ref_make(MACHINE_REF_STACK_SLOT, snapshot_slot)},
                                                                .payload = byte_offset,
                                                                .opcode = MACHINE_X64_LEA_FRAME,
                                                            });
        machine_x64_define(selector, destination_register, snapshot_row);
        return true;
    }
    u32 address_register;
    if (!machine_x64_operand_register(selector, base, &address_register))
    {
        return false;
    }
    u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                   .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, destination_register),
                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register)},
                                                   .payload = byte_offset,
                                                   .opcode = (u16)(byte_offset ? MACHINE_X64_LEA_OFFSET : MACHINE_X64_MOV_RR),
                                               });
    machine_x64_define(selector, destination_register, row);
    return true;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_place_address(MachineX64Selector* selector, IrValueId base, u32 destination_register)
{
    return machine_x64_select_place_address_offset(selector, base, destination_register, 0);
}

// A selection-synthesized temporary vreg, defined at the next row to be
// emitted so no post-pass definition patching is needed.
BUSTER_GLOBAL_LOCAL u32 machine_x64_synthesize_register(MachineX64Selector* selector)
{
    return machine_builder_virtual_register(&selector->builder, (MachineVirtualRegister){
                                                                    .definition_point =
                                                                        machine_point_make(selector->builder.instructions.total_count, MACHINE_POINT_AFTER),
                                                                    .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                    .typed_origin = IR_ID_UNDERLYING_INVALID,
                                                                });
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_select_immediate_register(MachineX64Selector* selector, u64 value)
{
    u32 result = machine_x64_synthesize_register(selector);
    u32 immediate = machine_x64_append_immediate(selector, value);
    machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result),
                                                          machine_ref_make(MACHINE_REF_IMMEDIATE, immediate)},
                                             .opcode = MACHINE_X64_MOV_RI,
                                         });
    return result;
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_select_frame_load64(MachineX64Selector* selector, u32 slot, u32 payload)
{
    u32 result = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result),
                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
                                             .payload = payload,
                                             .opcode = MACHINE_X64_LOAD_FRAME,
                                         });
    return result;
}

BUSTER_GLOBAL_LOCAL void machine_x64_select_frame_store64(MachineX64Selector* selector, u32 slot, u32 payload, u32 value)
{
    machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value)},
                                             .payload = payload,
                                             .opcode = MACHINE_X64_STORE_FRAME64,
                                         });
}

BUSTER_GLOBAL_LOCAL bool machine_x64_constant_shift_amount(MachineX64Selector* selector, IrValueId value, u32* amount_out)
{
    IrFunction* function = selector->function;
    // The frontend normally leaves a shift count as one integer constant,
    // optionally wrapped in a short cast chain while applying the usual
    // arithmetic conversions.  Keep this walk explicitly bounded: an
    // immediate machine lowering must never turn arbitrary IR into a
    // compile-time search.
    for (u32 depth = 0; depth < 4; depth += 1)
    {
        if (value.value >= function->value_count)
        {
            return false;
        }
        IrValue* ir_value = function->values + value.value;
        if (ir_value->definition.value >= function->instruction_count)
        {
            return false;
        }
        IrInstruction* definition = function->instructions + ir_value->definition.value;
        if (definition->opcode == IR_OPCODE_CONSTANT_INTEGER)
        {
            if (!definition->immediate_count || !definition->immediates || definition->immediate_is_negative || definition->immediates[0] > 127)
            {
                return false;
            }
            *amount_out = (u32)definition->immediates[0];
            return true;
        }
        if (definition->opcode != IR_OPCODE_CAST || definition->operand_count < 1 || !definition->operands)
        {
            return false;
        }
        if (definition->operands[0].value >= function->value_count)
        {
            return false;
        }
        IrType* source_type = ir_type_from_id(&selector->program->types, function->values[definition->operands[0].value].canonical_type);
        IrType* target_type = ir_type_from_id(&selector->program->types, definition->canonical_type);
        if (!source_type || !target_type || source_type->kind != IR_TYPE_INTEGER ||
            target_type->kind != IR_TYPE_INTEGER || target_type->bit_width < 8)
        {
            return false;
        }
        bool cast_preserves_small_nonnegative = definition->conversion_operation == IR_CONVERSION_IDENTITY ||
                                                definition->conversion_operation == IR_CONVERSION_INTEGER_REINTERPRET ||
                                                definition->conversion_operation == IR_CONVERSION_INTEGER_SIGN_EXTEND ||
                                                definition->conversion_operation == IR_CONVERSION_INTEGER_ZERO_EXTEND ||
                                                (definition->conversion_operation == IR_CONVERSION_INTEGER_TRUNCATE && target_type->bit_width >= 8);
        if (!cast_preserves_small_nonnegative)
        {
            return false;
        }
        value = definition->operands[0];
    }
    return false;
}

// The two shift directions beside the unsigned right one, over the same
// slot-backed pair and by the same bounded constant amount. Each is the two
// halves shifted in place plus one cross term: a left shift carries the low
// half's top bits into the high one, and both right shifts carry the high
// half's low bits down. The registers the frame loads produce are freshly
// synthesized, which is what licenses the in-place shift rows below -- the same
// shape machine_x64_select_i128_unsigned_shift_right already uses.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_shift_left(MachineX64Selector* selector, IrInstruction* instruction, u32 amount)
{
    IrFunction* function = selector->function;

    bool selected = instruction->operand_count >= 2 && instruction->result.value < function->value_count &&
                    instruction->operands[0].value < function->value_count && amount <= 127;
    u32 source_slot = selected ? selector->value_stack_slots[instruction->operands[0].value] : UINT32_MAX;
    u32 result_slot = selected ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
    selected = selected && source_slot != UINT32_MAX && result_slot != UINT32_MAX;
    if (selected && amount == 0)
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot)},
                                             .payload = 16,
                                             .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME,
                                         });
    }
    else if (selected && amount < 64)
    {
        u32 low = machine_x64_select_frame_load64(selector, source_slot, 0);
        u32 high = machine_x64_select_frame_load64(selector, source_slot, 8);
        u32 cross = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low)},
                                             .opcode = MACHINE_X64_MOV_RR,
                                         });
        u32 count = machine_x64_select_immediate_register(selector, amount);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                             .opcode = MACHINE_X64_SHL64,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                             .opcode = MACHINE_X64_SHL64,
                                         });
        u32 cross_count = machine_x64_select_immediate_register(selector, 64 - amount);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross_count)},
                                             .opcode = MACHINE_X64_SHR64,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross)},
                                             .opcode = MACHINE_X64_OR64,
                                         });
        machine_x64_select_frame_store64(selector, result_slot, 0, low);
        machine_x64_select_frame_store64(selector, result_slot, 8, high);
    }
    else if (selected)
    {
        u32 high = machine_x64_select_frame_load64(selector, source_slot, 0);
        if (amount > 64)
        {
            u32 count = machine_x64_select_immediate_register(selector, amount - 64);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                                 .opcode = MACHINE_X64_SHL64,
                                             });
        }
        machine_x64_select_frame_store64(selector, result_slot, 8, high);
        machine_x64_select_frame_store64(selector, result_slot, 0, machine_x64_select_immediate_register(selector, 0));
    }

    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_signed_shift_right(MachineX64Selector* selector, IrInstruction* instruction, u32 amount)
{
    IrFunction* function = selector->function;

    bool selected = instruction->operand_count >= 2 && instruction->result.value < function->value_count &&
                    instruction->operands[0].value < function->value_count && amount <= 127;
    u32 source_slot = selected ? selector->value_stack_slots[instruction->operands[0].value] : UINT32_MAX;
    u32 result_slot = selected ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
    selected = selected && source_slot != UINT32_MAX && result_slot != UINT32_MAX;
    if (selected && amount == 0)
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot)},
                                             .payload = 16,
                                             .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME,
                                         });
    }
    else if (selected && amount < 64)
    {
        u32 low = machine_x64_select_frame_load64(selector, source_slot, 0);
        u32 high = machine_x64_select_frame_load64(selector, source_slot, 8);
        u32 cross = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high)},
                                             .opcode = MACHINE_X64_MOV_RR,
                                         });
        u32 count = machine_x64_select_immediate_register(selector, amount);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                             .opcode = MACHINE_X64_SHR64,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                             .opcode = MACHINE_X64_SAR64,
                                         });
        u32 cross_count = machine_x64_select_immediate_register(selector, 64 - amount);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross_count)},
                                             .opcode = MACHINE_X64_SHL64,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross)},
                                             .opcode = MACHINE_X64_OR64,
                                         });
        machine_x64_select_frame_store64(selector, result_slot, 0, low);
        machine_x64_select_frame_store64(selector, result_slot, 8, high);
    }
    else if (selected)
    {
        // Past the halfway point the high half becomes the low one and the
        // sign fills what is left, which is that half shifted right by 63.
        u32 low = machine_x64_select_frame_load64(selector, source_slot, 8);
        u32 sign = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, sign),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low)},
                                             .opcode = MACHINE_X64_MOV_RR,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, sign),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, machine_x64_select_immediate_register(selector, 63))},
                                             .opcode = MACHINE_X64_SAR64,
                                         });
        if (amount > 64)
        {
            u32 count = machine_x64_select_immediate_register(selector, amount - 64);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                                 .opcode = MACHINE_X64_SAR64,
                                             });
        }
        machine_x64_select_frame_store64(selector, result_slot, 0, low);
        machine_x64_select_frame_store64(selector, result_slot, 8, sign);
    }

    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_unsigned_shift_right(MachineX64Selector* selector, IrInstruction* instruction, u32 amount)
{
    IrFunction* function = selector->function;
    if (instruction->operand_count < 2 || instruction->result.value >= function->value_count || instruction->operands[0].value >= function->value_count || amount > 127)
    {
        return false;
    }
    u32 source_slot = selector->value_stack_slots[instruction->operands[0].value];
    u32 result_slot = selector->value_stack_slots[instruction->result.value];
    if (source_slot == UINT32_MAX || result_slot == UINT32_MAX)
    {
        return false;
    }
    if (amount == 0)
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                              machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot)},
                                                 .payload = 16,
                                                 .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME,
                                             });
        return true;
    }
    if (amount < 64)
    {
        u32 low = machine_x64_select_frame_load64(selector, source_slot, 0);
        u32 high = machine_x64_select_frame_load64(selector, source_slot, 8);
        u32 cross = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high)},
                                                 .opcode = MACHINE_X64_MOV_RR,
                                             });
        u32 count = machine_x64_select_immediate_register(selector, amount);
        machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                                 .opcode = MACHINE_X64_SHR64,
                                             });
        machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                                 .opcode = MACHINE_X64_SHR64,
                                             });
        u32 cross_count = machine_x64_select_immediate_register(selector, 64 - amount);
        machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross_count)},
                                                 .opcode = MACHINE_X64_SHL64,
                                             });
        machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cross)},
                                                 .opcode = MACHINE_X64_OR64,
                                             });
        machine_x64_select_frame_store64(selector, result_slot, 0, low);
        machine_x64_select_frame_store64(selector, result_slot, 8, high);
        return true;
    }
    u32 low = machine_x64_select_frame_load64(selector, source_slot, 8);
    if (amount > 64)
    {
        u32 count = machine_x64_select_immediate_register(selector, amount - 64);
        machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                                                 .opcode = MACHINE_X64_SHR64,
                                             });
    }
    machine_x64_select_frame_store64(selector, result_slot, 0, low);
    u32 zero = machine_x64_select_immediate_register(selector, 0);
    machine_x64_select_frame_store64(selector, result_slot, 8, zero);
    return true;
}

// Emits result-vreg definition rows for one typed instruction. Returns false
// when the construct falls outside the selected subset.
// One member of an aggregate or array literal lands in the value's slot
// at `member_offset`: scalar members store sized, slot-backed members
// copy through the member's address.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_member_write(MachineX64Selector* selector, u32 slot, u64 member_offset, u64 member_size, IrValueId operand)
{
    u32 value_register = selector->value_virtual_registers[operand.value];
    u32 value_slot = selector->value_stack_slots[operand.value];
    IrType* value_type = ir_type_from_id(&selector->program->types, selector->function->values[operand.value].canonical_type);
    bool vector = value_register != UINT32_MAX && member_size == 64 && selector->vector_registers_supported &&
                  machine_x64_type_is_vector_register(selector->program, value_type);
    bool selected = member_offset <= INT32_MAX && member_size <= INT32_MAX;
    if (selected && !vector && (value_register != UINT32_MAX || value_slot == UINT32_MAX))
    {
        u16 store_opcode = member_size == 1   ? MACHINE_X64_STORE_FRAME8
                           : member_size == 2 ? MACHINE_X64_STORE_FRAME16
                           : member_size == 4 ? MACHINE_X64_STORE_FRAME32
                           : member_size == 8 ? MACHINE_X64_STORE_FRAME64 : 0;
        selected = store_opcode && machine_x64_operand_register(selector, operand, &value_register);
        if (selected)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                .payload = (u32)member_offset, .opcode = store_opcode,
            });
        }
    }
    else if (selected)
    {
        // A wide vector member is already a complete register image. Address
        // its exact subobject and store it with the ordinary vector memory row.
        u32 address_register = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register), machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
            .payload = (u32)member_offset, .opcode = MACHINE_X64_LEA_FRAME,
        });
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                         machine_ref_make(vector ? MACHINE_REF_VIRTUAL_REGISTER : MACHINE_REF_STACK_SLOT, vector ? value_register : value_slot)},
            .payload = vector ? 0 : (u32)member_size,
            .opcode = (u16)(vector ? MACHINE_X64_VSTORE_PTR : MACHINE_X64_COPY_PTR_FROM_FRAME),
        });
    }
    return selected;
}

// Win64's cursor walks one contiguous eightbyte sequence: register homes
// followed by stack arguments. Indirect aggregates occupy a pointer slot.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_windows_va_arg(MachineX64Selector* selector, IrType* type, u32 list_register,
                                                           u32 result_register, u32 result_slot, bool aggregate)
{
    bool selected = false;
    if (type && type->layout.resolved && type->layout.size && type->layout.size <= UINT32_MAX)
    {
        IrTypeId type_id = {.value = (u32)(type - selector->program->types.types)};
        IrAbiValue abi = ir_type_abi_value(selector->program, type_id, IR_ABI_CONVENTION_WIN64_X86_64, IR_ABI_USE_VARIADIC_ARGUMENT);
        bool vector = selector->vector_registers_supported && machine_x64_type_is_vector_register(selector->program, type);
        if (abi.part_count == 1 && !abi.memory && (aggregate || vector || type->layout.size <= 8))
        {
            u32 cursor = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cursor), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, list_register)},
                .opcode = MACHINE_X64_LOAD_PTR64,
            });
            u32 next = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, next), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cursor)},
                .payload = 8,
                .opcode = MACHINE_X64_LEA_OFFSET,
            });
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, list_register), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, next)},
                .opcode = MACHINE_X64_STORE_PTR64,
            });
            u32 address = cursor;
            if (abi.indirect)
            {
                address = machine_x64_synthesize_register(selector);
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cursor)},
                    .opcode = MACHINE_X64_LOAD_PTR64,
                });
            }
            if (aggregate)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address)},
                    .payload = (u32)type->layout.size,
                    .opcode = MACHINE_X64_COPY_FRAME_FROM_PTR,
                });
            }
            else
            {
                u16 opcode = vector ? MACHINE_X64_VLOAD_PTR : type->layout.size == 1 ? MACHINE_X64_LOAD_PTR8 : type->layout.size == 2 ? MACHINE_X64_LOAD_PTR16
                             : type->layout.size == 4 ? MACHINE_X64_LOAD_PTR32 : MACHINE_X64_LOAD_PTR64;
                u32 row = machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address)},
                    .opcode = opcode,
                });
                machine_x64_define(selector, result_register, row);
            }
            selected = true;
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_va_arg(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    bool selected = false;
    u32 source_register;
    if (instruction->operand_count >= 1 && instruction->result.value < function->value_count &&
        machine_x64_operand_register(selector, instruction->operands[0], &source_register))
    {
        IrType* value_type = ir_type_from_id(&program->types, instruction->canonical_type);
        u32 result_slot = selector->value_stack_slots[instruction->result.value];
        bool result_is_frame = result_register == UINT32_MAX && result_slot != UINT32_MAX;
        bool scalar = machine_x64_type_is_scalar_register(value_type) ||
                      (value_type && value_type->kind == IR_TYPE_FLOAT && (value_type->bit_width == 32 || value_type->bit_width == 64));
        bool aggregate = value_type && value_type->layout.resolved &&
                         (value_type->kind == IR_TYPE_STRUCT || value_type->kind == IR_TYPE_UNION || value_type->kind == IR_TYPE_SLICE ||
                          value_type->kind == IR_TYPE_ARRAY || (value_type->kind == IR_TYPE_VECTOR && result_is_frame) ||
                          (value_type->kind == IR_TYPE_INTEGER && value_type->bit_width == 128) ||
                          machine_x64_type_is_f80(selector, instruction->canonical_type));
        MachineVaArg metadata;
        bool vector = selector->vector_registers_supported && machine_x64_type_is_vector_register(selector->program, value_type);
        if (machine_x64_target_is_windows(selector->target) && (scalar || aggregate || vector) && result_is_frame == aggregate)
        {
            selected = machine_x64_select_windows_va_arg(selector, value_type, source_register, result_register, result_slot, aggregate);
        }
        else if ((scalar || aggregate) && result_is_frame == aggregate &&
            machine_x64_va_arg_metadata(selector, value_type, result_slot, result_is_frame, &metadata))
        {
            u32 metadata_index = selector->va_args.total_count;
            MachineVaArg* metadata_row = (MachineVaArg*)machine_stream_append(selector->arena, &selector->va_args);
            *metadata_row = metadata;
            MachineInstruction row = {
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register),
                             result_is_frame ? machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot)
                                              : machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                .payload = metadata_index,
                .opcode = MACHINE_X64_VA_ARG,
            };
            u32 row_index = machine_x64_select_row(selector, row);
            if (!result_is_frame)
            {
                machine_x64_define(selector, result_register, row_index);
            }
            selected = true;
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_va_start(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;

    u32 result_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
    bool selected = false;
    bool windows = machine_x64_target_is_windows(selector->target);
    IrType* list_type = ir_type_from_id(&selector->program->types, instruction->canonical_type);
    if (result_slot != UINT32_MAX && windows && list_type && list_type->kind == IR_TYPE_VA_LIST && list_type->layout.size == 8)
    {
        IrType* function_type = ir_type_from_id(&selector->program->types, function->canonical_type);
        // The hidden result pointer precedes the named sequence. Ordinary
        // parameters occupy one slot; split vector references occupy one
        // per piece, including pieces whose fixed-argument placement spilled
        // past the four register homes.
        u32 named_slots = selector->return_shape.indirect ? 1u : 0u;
        for (u32 argument = 0; argument < function_type->parameter_count; argument += 1)
        {
            MachineX64ValueShape* shape = selector->parameter_shapes + argument;
            named_slots += shape->windows_scalar_lane_size ? shape->part_count
                           : shape->indirect && shape->vector_part_bytes ? shape->part_count : 1u;
        }
        u32 cursor = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cursor)},
            .payload = named_slots * 8u,
            .opcode = MACHINE_X64_LEA_INCOMING,
        });
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, cursor)},
            .opcode = MACHINE_X64_STORE_FRAME64,
        });
        selected = true;
    }
    else if (result_slot != UINT32_MAX && !windows && selector->va_register_save_slot != UINT32_MAX &&
             list_type && list_type->kind == IR_TYPE_VA_LIST && list_type->layout.size == TARGET_X86_64_SYSV_VA_LIST_SIZE)
    {
        u32 integer_count;
        u32 float_count;
        u32 stack_end;
        machine_x64_va_named_cursors(selector, &integer_count, &float_count, &stack_end);
        u64 offsets = (u64)(integer_count * 8u) | ((u64)(48u + float_count * 16u) << 32);
        u32 packed_register = machine_x64_synthesize_register(selector);
        u32 packed_immediate = machine_x64_append_immediate(selector, offsets);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, packed_register),
                                                          machine_ref_make(MACHINE_REF_IMMEDIATE, packed_immediate)},
                                             .opcode = MACHINE_X64_MOV_RI,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, packed_register)},
                                             .payload = 0,
                                             .opcode = MACHINE_X64_STORE_FRAME64,
                                         });
        u32 overflow_register = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, overflow_register),
                                                          machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RBP)},
                                             .payload = 16u + stack_end,
                                             .opcode = MACHINE_X64_LEA_OFFSET,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, overflow_register)},
                                             .payload = 8,
                                             .opcode = MACHINE_X64_STORE_FRAME64,
                                         });
        u32 save_register = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, save_register),
                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, selector->va_register_save_slot)},
                                             .opcode = MACHINE_X64_LEA_FRAME,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, save_register)},
                                             .payload = 16,
                                             .opcode = MACHINE_X64_STORE_FRAME64,
                                         });
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_va_copy(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;

    u32 result_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
    u32 source_register;
    bool selected = false;
    IrType* list_type = ir_type_from_id(&selector->program->types, instruction->canonical_type);
    u32 bytes = machine_x64_target_is_windows(selector->target) ? 8u : TARGET_X86_64_SYSV_VA_LIST_SIZE;
    if (result_slot != UINT32_MAX && list_type && list_type->kind == IR_TYPE_VA_LIST && list_type->layout.size == bytes &&
        instruction->operand_count >= 1 && machine_x64_operand_register(selector, instruction->operands[0], &source_register))
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                             .payload = bytes,
                                             .opcode = MACHINE_X64_COPY_FRAME_FROM_PTR,
                                         });
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_va_end(MachineX64Selector* selector, IrInstruction* instruction)
{
    // Both x86-64 ABIs use a lifetime marker, not a destructive write.
    // The former private fourth word lies outside the public SysV object.
    // Its operand has already been evaluated; keep validating its address.
    u32 source_register;
    bool selected = instruction->operand_count >= 1 &&
                    machine_x64_operand_register(selector, instruction->operands[0], &source_register);
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_local(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    // Direct locals produce no code: the stack slot recorded during
    // classification is the storage, exactly like the canonical path —
    // or, promoted, the virtual register is. An over-aligned local
    // computes its runtime-aligned pointer here, the same lea/add/and
    // the canonical emitter runs at its LOCAL instruction.
    bool selected;
    u32 indirect_slot = selector->value_indirect_slots[instruction->result.value];
    if (indirect_slot != UINT32_MAX)
    {
        u32 pointer_register = selector->value_virtual_registers[instruction->result.value];
        IrValue* local_value = function->values + instruction->result.value;
        IrType* local_type = ir_type_from_id(&program->types, local_value->canonical_type);
        u32 local_alignment = BUSTER_MAX(BUSTER_MAX(local_value->alignment, local_type ? local_type->layout.alignment : 0), 8u);
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer_register),
                                                                    machine_ref_make(MACHINE_REF_STACK_SLOT, indirect_slot)},
                                                       .payload = local_alignment - 1,
                                                       .opcode = MACHINE_X64_LEA_FRAME,
                                                   });
        machine_x64_define(selector, pointer_register, row);
        u32 mask_register = machine_x64_synthesize_register(selector);
        u32 immediate_index = machine_x64_append_immediate(selector, 0 - (u64)local_alignment);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask_register),
                                                          machine_ref_make(MACHINE_REF_IMMEDIATE, immediate_index)},
                                             .opcode = MACHINE_X64_MOV_RI,
                                         });
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer_register),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer_register),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask_register)},
                                             .opcode = MACHINE_X64_AND64,
                                         });
        selected = true;
    }
    else
    {
        selected = selector->value_stack_slots[instruction->result.value] != UINT32_MAX ||
                   selector->value_virtual_registers[instruction->result.value] != UINT32_MAX;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_stack_save(MachineX64Selector* selector, u32 result_register)
{
    // RSP is a physical operand, so the scheduler and allocators keep
    // this checkpoint ordered with every stack-affecting row. The value
    // remains an ordinary virtual register and is spilled around calls
    // when its lifetime crosses one.
    bool selected = false;
    if (result_register != UINT32_MAX)
    {
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                    machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RSP)},
                                                       .opcode = MACHINE_X64_MOV_RR,
                                                   });
        machine_x64_define(selector, result_register, row);
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_stack_allocate(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    bool selected = false;
    u32 size_register;
    if (result_register != UINT32_MAX && instruction->immediate_count && instruction->immediates)
    {
        u64 requested_alignment = instruction->immediates[0];
        // An out-of-range request lands on zero, which the power-of-two test
        // below rejects along with every other unusable alignment.
        u32 stack_alignment = requested_alignment <= UINT32_MAX ? BUSTER_MAX((u32)requested_alignment, 16u) : 0;
        if (stack_alignment && (stack_alignment & (stack_alignment - 1u)) == 0 &&
            machine_x64_operand_register(selector, instruction->operands[0], &size_register))
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, size_register)},
                                                           .payload = stack_alignment,
                                                           .opcode = MACHINE_X64_STACK_ALLOCATE,
                                                       });
            machine_x64_define(selector, result_register, row);
            selected = true;
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_stack_restore(MachineX64Selector* selector, IrInstruction* instruction)
{
    bool selected = false;
    u32 saved_register;
    if (machine_x64_operand_register(selector, instruction->operands[0], &saved_register))
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RSP),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, saved_register)},
                                             .opcode = MACHINE_X64_MOV_RR,
                                         });
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_argument(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    // The typed ARGUMENT can appear anywhere the frontend first used the
    // parameter; the value itself was captured by the entry rows before
    // any scratch register could clobber the incoming fixed registers.
    bool selected = false;
    if (instruction->immediate_count && instruction->immediates)
    {
        u32 argument_index = (u32)instruction->immediates[0];
        selected = argument_index < selector->parameter_count &&
                   (result_register != UINT32_MAX || selector->value_stack_slots[instruction->result.value] != UINT32_MAX) &&
                   selector->argument_values[argument_index] == instruction->result.value;
    }
    return selected;
}

// Build the zero/2^63 correction as two initialized frame words. The mask is
// zero or all ones; padding and the exponent are zero when the bias is zero.
BUSTER_GLOBAL_LOCAL u32 machine_x64_select_f80_u64_bias(MachineX64Selector* selector, u32 slot, u32 mask)
{
    u32 sign_bit = machine_x64_select_immediate_register(selector, UINT64_C(0x8000000000000000));
    u32 exponent_bits = machine_x64_select_immediate_register(selector, UINT64_C(0x403e));
    u32 significand = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, significand), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask),
                     machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, sign_bit)}, .opcode = MACHINE_X64_AND64});
    u32 exponent = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, exponent), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask),
                     machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, exponent_bits)}, .opcode = MACHINE_X64_AND64});
    machine_x64_select_frame_store64(selector, slot, 0, significand);
    machine_x64_select_frame_store64(selector, slot, 8, exponent);
    return significand;
}

// Unsigned eightbytes need only signed conversions plus an exact correction.
// With the backend's extended-precision x87 contract, both corrections are
// exact for every defined input and leave the caller's rounding mode intact.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_f80_unsigned64_cast(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrFunction* function = selector->function;
    IrValueId source = instruction->operands[0];
    IrType* source_type = ir_type_from_id(&selector->program->types, function->values[source.value].canonical_type);
    IrType* result_type = ir_type_from_id(&selector->program->types, instruction->canonical_type);
    bool from_unsigned = instruction->conversion_operation == IR_CONVERSION_UNSIGNED_INTEGER_TO_FLOAT &&
                         source_type && source_type->kind == IR_TYPE_INTEGER && source_type->bit_width == 64 &&
                         machine_x64_type_is_f80(selector, instruction->canonical_type);
    bool to_unsigned = instruction->conversion_operation == IR_CONVERSION_FLOAT_TO_UNSIGNED_INTEGER &&
                       result_type && result_type->kind == IR_TYPE_INTEGER && result_type->bit_width == 64 &&
                       machine_x64_type_is_f80(selector, function->values[source.value].canonical_type);
    u32 source_slot = selector->value_stack_slots[source.value];
    u32 result_slot = selector->value_stack_slots[instruction->result.value];
    u32 source_register = UINT32_MAX;
    bool selected = (from_unsigned && result_slot != UINT32_MAX && machine_x64_operand_register(selector, source, &source_register)) ||
                    (to_unsigned && source_slot != UINT32_MAX && result_register != UINT32_MAX);
    if (selected)
    {
        u32 bias = machine_x64_append_slot(selector, 16, 16);
        u32 integer = machine_x64_append_slot(selector, 8, 8);
        u32 scratch = machine_x64_append_slot(selector, 8, 8);
        u32 mask;
        if (from_unsigned)
        {
            u32 count = machine_x64_select_immediate_register(selector, 63);
            mask = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                .opcode = MACHINE_X64_MOV_RR});
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count)},
                .opcode = MACHINE_X64_SAR64});
            u32 low_mask = machine_x64_select_immediate_register(selector, UINT64_C(0x7fffffffffffffff));
            u32 low = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low_mask)}, .opcode = MACHINE_X64_AND64});
            machine_x64_select_frame_store64(selector, integer, 0, low);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot), machine_ref_make(MACHINE_REF_STACK_SLOT, integer),
                             machine_ref_make(MACHINE_REF_STACK_SLOT, scratch)}, .payload = 4, .opcode = MACHINE_X64_F80_CONVERT});
        }
        else
        {
            machine_x64_select_frame_store64(selector, bias, 0, machine_x64_select_immediate_register(selector, UINT64_C(0x8000000000000000)));
            machine_x64_select_frame_store64(selector, bias, 8, machine_x64_select_immediate_register(selector, UINT64_C(0x403e)));
            u32 high = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high), machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot),
                             machine_ref_make(MACHINE_REF_STACK_SLOT, bias)}, .payload = 5, .opcode = MACHINE_X64_F80_COMPARE});
            u32 zero = machine_x64_select_immediate_register(selector, 0);
            mask = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, zero),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high)}, .opcode = MACHINE_X64_SUB64});
        }
        u32 high_bit = machine_x64_select_f80_u64_bias(selector, bias, mask);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, from_unsigned ? result_slot : bias),
                         machine_ref_make(MACHINE_REF_STACK_SLOT, from_unsigned ? result_slot : source_slot),
                         machine_ref_make(MACHINE_REF_STACK_SLOT, bias)},
            .payload = from_unsigned ? 0u : 1u, .opcode = MACHINE_X64_F80_BINARY});
        if (to_unsigned)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, integer), machine_ref_make(MACHINE_REF_STACK_SLOT, bias),
                             machine_ref_make(MACHINE_REF_STACK_SLOT, scratch)}, .payload = 5, .opcode = MACHINE_X64_F80_CONVERT});
            u32 low = machine_x64_select_frame_load64(selector, integer, 0);
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high_bit)}, .opcode = MACHINE_X64_OR64});
            machine_x64_define(selector, result_register, row);
        }
    }
    return selected;
}

// f80 transactions never expose the x87 stack to allocation. General
// values cross a conversion through an eight-byte image, and the result
// returns to the ordinary scalar register after the closed transaction.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_f80_cast(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrFunction* function = selector->function;
    IrTypeId source_id = function->values[instruction->operands[0].value].canonical_type;
    IrType* source_type = ir_type_from_id(&selector->program->types, source_id);
    IrType* result_type = ir_type_from_id(&selector->program->types, instruction->canonical_type);
    bool from_f80 = machine_x64_type_is_f80(selector, source_id);
    bool to_f80 = machine_x64_type_is_f80(selector, instruction->canonical_type);
    u32 mode = UINT32_MAX;
    bool source_signed = instruction->conversion_operation == IR_CONVERSION_SIGNED_INTEGER_TO_FLOAT;
    bool from_integer = to_f80 && (source_signed || instruction->conversion_operation == IR_CONVERSION_UNSIGNED_INTEGER_TO_FLOAT);
    if (from_f80 && result_type->kind == IR_TYPE_FLOAT && (result_type->bit_width == 32 || result_type->bit_width == 64))
    {
        mode = result_type->bit_width == 32 ? 2u : 3u;
    }
    else if (to_f80 && source_type->kind == IR_TYPE_FLOAT && (source_type->bit_width == 32 || source_type->bit_width == 64))
    {
        mode = source_type->bit_width == 32 ? 0u : 1u;
    }
    else if (from_integer && source_type->bit_width <= 64 && (source_signed || source_type->bit_width < 64))
    {
        mode = 4;
    }
    else if (from_f80 && result_type->kind == IR_TYPE_INTEGER && result_type->bit_width <= 64 &&
             (result_type->is_signed || result_type->bit_width < 64))
    {
        mode = 5;
    }
    u32 source_slot = selector->value_stack_slots[instruction->operands[0].value];
    u32 result_slot = selector->value_stack_slots[instruction->result.value];
    u32 source_register = UINT32_MAX;
    bool selected = mode != UINT32_MAX && (from_f80 ? source_slot != UINT32_MAX :
                        machine_x64_operand_register(selector, instruction->operands[0], &source_register)) &&
                    (to_f80 ? result_slot != UINT32_MAX : result_register != UINT32_MAX);
    if (selected)
    {
        if (!from_f80)
        {
            if (from_integer && source_type->bit_width < 64)
            {
                u32 bits = source_type->bit_width;
                u16 opcode = (u16)(source_signed ? (bits == 8 ? MACHINE_X64_MOVSX8_RR : bits == 16 ? MACHINE_X64_MOVSX16_RR : MACHINE_X64_MOVSX32_RR)
                                                : (bits == 8 ? MACHINE_X64_MOVZX8_RR : bits == 16 ? MACHINE_X64_MOVZX16_RR : MACHINE_X64_MOV32_RR));
                u32 extended = machine_x64_synthesize_register(selector);
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, extended), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                    .opcode = opcode});
                source_register = extended;
            }
            source_slot = machine_x64_append_slot(selector, 8, 8);
            machine_x64_select_frame_store64(selector, source_slot, 0, source_register);
        }
        if (!to_f80)
        {
            result_slot = machine_x64_append_slot(selector, 8, 8);
        }
        u32 scratch_slot = machine_x64_append_slot(selector, 8, 8);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot), machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot),
                         machine_ref_make(MACHINE_REF_STACK_SLOT, scratch_slot)},
            .payload = mode, .opcode = MACHINE_X64_F80_CONVERT});
        if (!to_f80)
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register), machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot)},
                .opcode = MACHINE_X64_LOAD_FRAME});
            machine_x64_define(selector, result_register, row);
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_f80_binary(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    u32 left = selector->value_stack_slots[instruction->operands[0].value];
    u32 right = selector->value_stack_slots[instruction->operands[1].value];
    u32 destination = selector->value_stack_slots[instruction->result.value];
    u32 operation = UINT32_MAX;
    bool compare = false;
    switch (instruction->binary_operation)
    {
    case IR_BINARY_FLOAT_ADD: operation = 0; break;
    case IR_BINARY_FLOAT_SUBTRACT: operation = 1; break;
    case IR_BINARY_FLOAT_MULTIPLY: operation = 2; break;
    case IR_BINARY_FLOAT_DIVIDE: operation = 3; break;
    case IR_BINARY_FLOAT_EQUAL: operation = 0; compare = true; break;
    case IR_BINARY_FLOAT_NOT_EQUAL: operation = 1; compare = true; break;
    case IR_BINARY_FLOAT_LESS: operation = 2; compare = true; break;
    case IR_BINARY_FLOAT_LESS_EQUAL: operation = 3; compare = true; break;
    case IR_BINARY_FLOAT_GREATER: operation = 4; compare = true; break;
    case IR_BINARY_FLOAT_GREATER_EQUAL: operation = 5; compare = true; break;
    default: break;
    }
    bool selected = operation != UINT32_MAX && left != UINT32_MAX && right != UINT32_MAX &&
                    (compare ? result_register != UINT32_MAX : destination != UINT32_MAX);
    if (selected)
    {
        MachineRef result_ref = compare ? machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register) : machine_ref_make(MACHINE_REF_STACK_SLOT, destination);
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
            .operands = {result_ref, machine_ref_make(MACHINE_REF_STACK_SLOT, left), machine_ref_make(MACHINE_REF_STACK_SLOT, right)},
            .payload = operation, .opcode = (u16)(compare ? MACHINE_X64_F80_COMPARE : MACHINE_X64_F80_BINARY)});
        if (compare)
        {
            machine_x64_define(selector, result_register, row);
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_f80_negate(MachineX64Selector* selector, IrInstruction* instruction)
{
    u32 source = selector->value_stack_slots[instruction->operands[0].value];
    u32 destination = selector->value_stack_slots[instruction->result.value];
    bool selected = instruction->unary_operation == IR_UNARY_FLOAT_NEGATE && source != UINT32_MAX && destination != UINT32_MAX;
    if (selected)
    {
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, destination), machine_ref_make(MACHINE_REF_STACK_SLOT, source)},
            .opcode = MACHINE_X64_F80_NEGATE});
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_constant(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    bool selected = false;
    if (result_register != UINT32_MAX)
    {
        // Float constants carry their IEEE bit pattern in the immediate,
        // exactly like the canonical shared constant path.
        u64 immediate = instruction->immediates[0];
        if (instruction->opcode == IR_OPCODE_CONSTANT_INTEGER && instruction->immediate_is_negative)
        {
            immediate = 0 - immediate;
        }
        u32 immediate_index = machine_x64_append_immediate(selector, immediate);
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                    machine_ref_make(MACHINE_REF_IMMEDIATE, immediate_index)},
                                                       .opcode = MACHINE_X64_MOV_RI,
                                                   });
        machine_x64_define(selector, result_register, row);
        selected = true;
    }
    else if (machine_x64_type_is_f80(selector, instruction->canonical_type) && instruction->immediate_count == 2 &&
             !(instruction->immediates[1] & ~UINT64_C(0xffff)))
    {
        u32 slot = selector->value_stack_slots[instruction->result.value];
        selected = slot != UINT32_MAX;
        if (selected)
        {
            machine_x64_select_frame_store64(selector, slot, 0, machine_x64_select_immediate_register(selector, instruction->immediates[0]));
            machine_x64_select_frame_store64(selector, slot, 8, machine_x64_select_immediate_register(selector, instruction->immediates[1]));
        }
    }
    else if (instruction->opcode == IR_OPCODE_CONSTANT_INTEGER && instruction->result.value != IR_ID_UNDERLYING_INVALID &&
             instruction->result.value < function->value_count && selector->value_stack_slots[instruction->result.value] != UINT32_MAX)
    {
        // A 128-bit integer constant is slot-backed like every i128 value, so
        // it has no result register and is written half by half. The second
        // eightbyte is the canonical emitters' selection: an explicit second
        // immediate when the frontend recorded one, otherwise the negated low
        // half's sign fill. This mirrors machine_a64_select_constant.
        IrType* constant_type = ir_type_from_id(&program->types, instruction->canonical_type);
        if (constant_type && constant_type->kind == IR_TYPE_INTEGER && constant_type->bit_width == 128 && instruction->immediate_count &&
            instruction->immediates)
        {
            u32 result_slot = selector->value_stack_slots[instruction->result.value];
            u64 low = instruction->immediate_is_negative ? 0 - instruction->immediates[0] : instruction->immediates[0];
            u64 high = instruction->immediate_count > 1 ? instruction->immediates[1] : instruction->immediate_is_negative ? UINT64_MAX : 0;
            u64 halves[2] = {low, high};
            for (u32 half_index = 0; half_index < 2; half_index += 1)
            {
                machine_x64_select_frame_store64(selector, result_slot, half_index * 8,
                                                 machine_x64_select_immediate_register(selector, halves[half_index]));
            }
            selected = true;
        }
    }
    return selected;
}

// i128 values use the same two-eightbyte frame representation as aggregate
// values. This path stays direct and bounded: scalar integer extensions and
// truncations use the existing frame rows, a 128-bit reinterpret is a
// byte-preserving frame copy, and other aggregate casts continue through the
// explicit unsupported fallback.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_cast_i128_float(MachineX64Selector* selector, IrInstruction* instruction,
                                                            IrType* source_type, IrType* target_type, u32 result_register);

BUSTER_GLOBAL_LOCAL bool machine_x64_select_cast_i128(MachineX64Selector* selector, IrInstruction* instruction, IrType* source_type,
                                                      IrType* cast_target_type, u32 source_bits, u32 result_register)
{
    IrFunction* function = selector->function;

    bool selected = false;
    if (source_type && cast_target_type && source_type->kind == IR_TYPE_INTEGER && cast_target_type->kind == IR_TYPE_INTEGER)
    {
        bool source_integer128 = source_type->bit_width == 128;
        bool target_integer128 = cast_target_type->bit_width == 128;
        u32 source_slot = selector->value_stack_slots[instruction->operands[0].value];
        u32 target_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
        bool reinterpret_i128 = source_integer128 && target_integer128 &&
                                (instruction->conversion_operation == IR_CONVERSION_INTEGER_REINTERPRET ||
                                 instruction->conversion_operation == IR_CONVERSION_IDENTITY);
        bool truncate_i128 = source_integer128 && !target_integer128 && cast_target_type->bit_width <= 64 &&
                             instruction->conversion_operation == IR_CONVERSION_INTEGER_TRUNCATE;
        bool extend_i128 = target_integer128 && !source_integer128 && source_type->bit_width >= 8 && source_type->bit_width <= 64 &&
                           (instruction->conversion_operation == IR_CONVERSION_INTEGER_SIGN_EXTEND ||
                            instruction->conversion_operation == IR_CONVERSION_INTEGER_ZERO_EXTEND);
        if (reinterpret_i128)
        {
            selected = source_slot != UINT32_MAX && target_slot != UINT32_MAX;
            if (selected)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, target_slot),
                                                                  machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot)},
                                                     .payload = 16,
                                                     .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME,
                                                 });
            }
        }
        else if (truncate_i128)
        {
            selected = result_register != UINT32_MAX && source_slot != UINT32_MAX;
            if (selected)
            {
                u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                               .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                            machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot)},
                                                               .opcode = MACHINE_X64_LOAD_FRAME,
                                                           });
                machine_x64_define(selector, result_register, row);
                if (cast_target_type->bit_width < 64)
                {
                    u16 narrow_opcode = cast_target_type->bit_width == 8   ? MACHINE_X64_MOVZX8_RR
                                        : cast_target_type->bit_width == 16 ? MACHINE_X64_MOVZX16_RR
                                                                             : MACHINE_X64_MOV32_RR;
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                         .opcode = narrow_opcode,
                                                     });
                }
            }
        }
        else if (extend_i128)
        {
            // Only the rows below read this, and only where the operand lookup
            // that fills it succeeded.
            u32 source_register = UINT32_MAX;
            selected = result_register == UINT32_MAX && target_slot != UINT32_MAX && source_bits >= 8 && source_bits <= 64 &&
                       machine_x64_operand_register(selector, instruction->operands[0], &source_register);
            if (selected)
            {
                u32 low_register = source_register;
                if (source_bits < 64)
                {
                    u16 extend_opcode = instruction->conversion_operation == IR_CONVERSION_INTEGER_SIGN_EXTEND
                                            ? (source_bits == 8 ? MACHINE_X64_MOVSX8_RR
                                               : source_bits == 16 ? MACHINE_X64_MOVSX16_RR
                                                                   : MACHINE_X64_MOVSX32_RR)
                                            : (source_bits == 8 ? MACHINE_X64_MOVZX8_RR
                                               : source_bits == 16 ? MACHINE_X64_MOVZX16_RR
                                                                   : MACHINE_X64_MOV32_RR);
                    low_register = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low_register),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                         .opcode = extend_opcode,
                                                     });
                }
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, target_slot),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low_register)},
                                                     .opcode = MACHINE_X64_STORE_FRAME64,
                                                 });
                u32 high_register = machine_x64_synthesize_register(selector);
                if (instruction->conversion_operation == IR_CONVERSION_INTEGER_SIGN_EXTEND)
                {
                    // The high half of a signed 64-to-128 extension is the
                    // sign bit replicated across all 64 bits.  Copy the low
                    // half, then arithmetic-shift it by 63 so the runtime
                    // sign (rather than the static type) chooses all ones or
                    // all zeroes.
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high_register),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, low_register)},
                                                         .opcode = MACHINE_X64_MOV_RR,
                                                     });
                    u32 shift_register = machine_x64_synthesize_register(selector);
                    u32 immediate_index = machine_x64_append_immediate(selector, 63);
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, shift_register),
                                                                      machine_ref_make(MACHINE_REF_IMMEDIATE, immediate_index)},
                                                         .opcode = MACHINE_X64_MOV_RI,
                                                     });
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high_register),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, shift_register)},
                                                         .opcode = MACHINE_X64_SAR64,
                                                     });
                }
                else
                {
                    u32 immediate_index = machine_x64_append_immediate(selector, 0);
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high_register),
                                                                      machine_ref_make(MACHINE_REF_IMMEDIATE, immediate_index)},
                                                         .opcode = MACHINE_X64_MOV_RI,
                                                     });
                }
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, target_slot),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high_register)},
                                                     .payload = 8,
                                                     .opcode = MACHINE_X64_STORE_FRAME64,
                                                 });
            }
        }
    }
    return selected;
}

// The 64-bit convert instructions carry every narrower integer case after an
// extension, and the branchy unsigned-64 sequences stay outside the subset.
// The 64-bit convert instructions carry every narrower integer case after an
// extension; the branchy unsigned-64 sequences have rows of their own.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_cast_integer_to_float(MachineX64Selector* selector, IrInstruction* instruction, IrType* cast_target_type,
                                                                  u32 source_bits, u32 source_register, u32 result_register)
{
    bool selected = false;
    bool cast_signed = instruction->conversion_operation == IR_CONVERSION_SIGNED_INTEGER_TO_FLOAT;
    bool convertible = cast_target_type && cast_target_type->kind == IR_TYPE_FLOAT &&
                       (cast_target_type->bit_width == 32 || cast_target_type->bit_width == 64) && source_bits;
    if (convertible && !cast_signed && source_bits == 64)
    {
        u32 branchy_row = machine_x64_select_row(
            selector, (MachineInstruction){
                          .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                       machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                          .opcode = (u16)(cast_target_type->bit_width == 64 ? MACHINE_X64_CVT_U64_TO_F64 : MACHINE_X64_CVT_U64_TO_F32),
                      });
        machine_x64_define(selector, result_register, branchy_row);
        selected = true;
    }
    else if (convertible)
    {
        u32 extended_register = source_register;
        if (source_bits < 64)
        {
            u16 extend_opcode = (u16)(cast_signed ? (source_bits == 8 ? MACHINE_X64_MOVSX8_RR : source_bits == 16 ? MACHINE_X64_MOVSX16_RR
                                                     : MACHINE_X64_MOVSX32_RR)
                                                  : (source_bits == 8 ? MACHINE_X64_MOVZX8_RR : source_bits == 16 ? MACHINE_X64_MOVZX16_RR
                                                     : MACHINE_X64_MOV32_RR));
            extended_register = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, extended_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                 .opcode = extend_opcode,
                                             });
        }
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, extended_register)},
                                                       .opcode = (u16)(cast_target_type->bit_width == 64 ? MACHINE_X64_CVT_I64_TO_F64
                                                                                                         : MACHINE_X64_CVT_I64_TO_F32),
                                                   });
        machine_x64_define(selector, result_register, row);
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_cast_float_to_integer(MachineX64Selector* selector, IrInstruction* instruction, IrType* source_type,
                                                                  IrType* cast_target_type, u32 source_register, u32 result_register)
{
    bool selected = false;
    bool to_unsigned = instruction->conversion_operation == IR_CONVERSION_FLOAT_TO_UNSIGNED_INTEGER;
    bool convertible = source_type && source_type->kind == IR_TYPE_FLOAT && (source_type->bit_width == 32 || source_type->bit_width == 64);
    if (convertible && to_unsigned && cast_target_type && cast_target_type->kind == IR_TYPE_INTEGER && cast_target_type->bit_width == 64)
    {
        u32 branchy_row = machine_x64_select_row(
            selector, (MachineInstruction){
                          .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                       machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                          .opcode = (u16)(source_type->bit_width == 64 ? MACHINE_X64_CVT_F64_TO_U64 : MACHINE_X64_CVT_F32_TO_U64),
                      });
        machine_x64_define(selector, result_register, branchy_row);
        selected = true;
    }
    else if (convertible)
    {
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                       .opcode = (u16)(source_type->bit_width == 64 ? MACHINE_X64_CVT_F64_TO_I64
                                                                                                    : MACHINE_X64_CVT_F32_TO_I64),
                                                   });
        machine_x64_define(selector, result_register, row);
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_cast(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    bool selected = false;
    if (instruction->operands[0].value < function->value_count)
    {
        IrTypeId source_type_id = function->values[instruction->operands[0].value].canonical_type;
        MachineTypeClass source_class = machine_x64_type_class(selector, source_type_id);
        MachineTypeClass target_class = machine_x64_type_class(selector, instruction->canonical_type);
        u32 source_bits = machine_x64_class_scalar_bit_width(selector, source_type_id, source_class);
        bool source_integer128 = (source_class.flags & MACHINE_TYPE_CLASS_INTEGER128) != 0;
        bool target_integer128 = (target_class.flags & MACHINE_TYPE_CLASS_INTEGER128) != 0;
        // Only the register conversions below read this, and only where the
        // operand lookup that fills it succeeded.
        u32 source_register = UINT32_MAX;
        if (machine_x64_type_is_f80(selector, source_type_id) || machine_x64_type_is_f80(selector, instruction->canonical_type))
        {
            selected = (source_integer128 || target_integer128)
                           ? machine_x64_select_cast_i128_float(selector, instruction, ir_type_from_id(&program->types, source_type_id),
                                                                ir_type_from_id(&program->types, instruction->canonical_type), result_register)
                           : machine_x64_select_f80_unsigned64_cast(selector, instruction, result_register) ||
                                 machine_x64_select_f80_cast(selector, instruction, result_register);
        }
        else if (source_integer128 || target_integer128)
        {
            IrType* source_type = ir_type_from_id(&program->types, source_type_id);
            IrType* target_type = ir_type_from_id(&program->types, instruction->canonical_type);
            selected = (source_type && target_type && (source_type->kind == IR_TYPE_FLOAT || target_type->kind == IR_TYPE_FLOAT))
                           ? machine_x64_select_cast_i128_float(selector, instruction, source_type, target_type, result_register)
                           : machine_x64_select_cast_i128(selector, instruction, source_type, target_type, source_bits, result_register);
        }
        // Float conversions mirror the canonical forms.
        else if (result_register != UINT32_MAX && machine_x64_operand_register(selector, instruction->operands[0], &source_register))
        {
            if (instruction->conversion_operation == IR_CONVERSION_FLOAT_EXTEND || instruction->conversion_operation == IR_CONVERSION_FLOAT_TRUNCATE)
            {
                IrType* source_float = ir_type_from_id(&program->types, source_type_id);
                IrType* target_float = ir_type_from_id(&program->types, instruction->canonical_type);
                bool extend = instruction->conversion_operation == IR_CONVERSION_FLOAT_EXTEND;
                bool ieee = source_float && target_float && source_float->float_format == IR_FLOAT_FORMAT_IEEE &&
                            target_float->float_format == IR_FLOAT_FORMAT_IEEE &&
                            source_float->bit_width == (extend ? 32 : 64) && target_float->bit_width == (extend ? 64 : 32);
                if (ieee)
                {
                    u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                                   .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                                   .opcode = (u16)(extend ? MACHINE_X64_CVT_F32_TO_F64 : MACHINE_X64_CVT_F64_TO_F32),
                                                               });
                    machine_x64_define(selector, result_register, row);
                    selected = true;
                }
            }
            else if (instruction->conversion_operation == IR_CONVERSION_SIGNED_INTEGER_TO_FLOAT ||
                     instruction->conversion_operation == IR_CONVERSION_UNSIGNED_INTEGER_TO_FLOAT)
            {
                selected = machine_x64_select_cast_integer_to_float(selector, instruction, ir_type_from_id(&program->types, instruction->canonical_type),
                                                                    source_bits, source_register, result_register);
            }
            else if (instruction->conversion_operation == IR_CONVERSION_FLOAT_TO_SIGNED_INTEGER ||
                     instruction->conversion_operation == IR_CONVERSION_FLOAT_TO_UNSIGNED_INTEGER)
            {
                selected = machine_x64_select_cast_float_to_integer(selector, instruction, ir_type_from_id(&program->types, source_type_id),
                                                                    ir_type_from_id(&program->types, instruction->canonical_type), source_register,
                                                                    result_register);
            }
            else
            {
                u16 opcode = 0;
                switch (instruction->conversion_operation)
                {
                    break;
                case IR_CONVERSION_IDENTITY:
                case IR_CONVERSION_INTEGER_REINTERPRET:
                case IR_CONVERSION_POINTER_REINTERPRET:
                case IR_CONVERSION_INTEGER_TO_POINTER:
                    opcode = MACHINE_X64_MOV_RR;
                    break;
                case IR_CONVERSION_INTEGER_TRUNCATE:
                case IR_CONVERSION_POINTER_TO_INTEGER:
                {
                    // The register model keeps every value zero-extended to 64
                    // bits, so a narrowing cast must actually clear the discarded
                    // top: a plain 64-bit copy would smuggle the source's high
                    // bits into 64-bit consumers like unsigned index scaling.
                    u32 destination_bits = machine_x64_class_scalar_bit_width(selector, instruction->canonical_type, target_class);
                    opcode = (u16)(destination_bits == 8    ? MACHINE_X64_MOVZX8_RR
                                   : destination_bits == 16 ? MACHINE_X64_MOVZX16_RR
                                   : destination_bits == 32 ? MACHINE_X64_MOV32_RR
                                   : destination_bits == 64 ? MACHINE_X64_MOV_RR
                                                            : 0);
                }
                break;
                case IR_CONVERSION_INTEGER_SIGN_EXTEND:
                    opcode = (u16)(source_bits == 8 ? MACHINE_X64_MOVSX8_RR : source_bits == 16 ? MACHINE_X64_MOVSX16_RR : source_bits == 32 ? MACHINE_X64_MOVSX32_RR
                                   : source_bits == 64 ? MACHINE_X64_MOV_RR : 0);
                    break;
                case IR_CONVERSION_INTEGER_ZERO_EXTEND:
                    opcode = (u16)(source_bits == 8 ? MACHINE_X64_MOVZX8_RR : source_bits == 16 ? MACHINE_X64_MOVZX16_RR : source_bits == 32 ? MACHINE_X64_MOV32_RR
                                   : source_bits == 64 ? MACHINE_X64_MOV_RR : 0);
                    break;
                default:
                    opcode = 0;
                }
                selected = opcode != 0;
                if (selected)
                {
                    u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                                   .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                                   .opcode = opcode,
                                                               });
                    machine_x64_define(selector, result_register, row);
                }
            }
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_unary(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrFunction* function = selector->function;

    bool selected = false;
    u32 source_register;
    if (result_register != UINT32_MAX && machine_x64_operand_register(selector, instruction->operands[0], &source_register))
    {
        MachineTypeClass operand_class = machine_x64_type_class(selector, function->values[instruction->operands[0].value].canonical_type);
        bool wide = (operand_class.flags & MACHINE_TYPE_CLASS_WIDE) != 0;
        if (instruction->unary_operation == IR_UNARY_INTEGER_NEGATE || instruction->unary_operation == IR_UNARY_INTEGER_BITWISE_NOT)
        {
            bool negate = instruction->unary_operation == IR_UNARY_INTEGER_NEGATE;
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                           .opcode = MACHINE_X64_MOV_RR,
                                                       });
            machine_x64_define(selector, result_register, row);
            machine_x64_select_row(selector,
                                   (MachineInstruction){
                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                       .opcode = (u16)(negate ? (wide ? MACHINE_X64_NEG64 : MACHINE_X64_NEG32) : (wide ? MACHINE_X64_NOT64 : MACHINE_X64_NOT32)),
                                   });
            selected = true;
        }
        else if (instruction->unary_operation == IR_UNARY_INTEGER_POPULATION_COUNT)
        {
            selected = target_cpu_feature_has(selector->target, TARGET_CPU_FEATURE_X86_POPCNT);
            if (selected)
            {
                u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                               .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                            machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                               .opcode = (u16)(wide ? MACHINE_X64_POPCNT64 : MACHINE_X64_POPCNT32),
                                                           });
                machine_x64_define(selector, result_register, row);
            }
        }
        else if (instruction->unary_operation == IR_UNARY_INTEGER_COUNT_LEADING_ZEROS || instruction->unary_operation == IR_UNARY_INTEGER_COUNT_TRAILING_ZEROS)
        {
            // Canonical form: bsf for trailing zeros, bsr xor width-1 for
            // leading — both undefined on zero input, exactly like the
            // builtins they lower.
            bool leading = instruction->unary_operation == IR_UNARY_INTEGER_COUNT_LEADING_ZEROS;
            u32 bit_scan_register = leading ? machine_x64_synthesize_register(selector) : result_register;
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bit_scan_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                           .opcode = (u16)(leading ? (wide ? MACHINE_X64_BSR64 : MACHINE_X64_BSR32)
                                                                                   : (wide ? MACHINE_X64_BSF64 : MACHINE_X64_BSF32)),
                                                       });
            machine_x64_define(selector, bit_scan_register, row);
            if (leading)
            {
                u32 flip_immediate = machine_x64_append_immediate(selector, wide ? 63 : 31);
                u32 flip_register = machine_x64_synthesize_register(selector);
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, flip_register),
                                                                  machine_ref_make(MACHINE_REF_IMMEDIATE, flip_immediate)},
                                                     .opcode = MACHINE_X64_MOV_RI,
                                                 });
                u32 flip_row_index = machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bit_scan_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, flip_register)},
                                                                     .opcode = (u16)(wide ? MACHINE_X64_XOR64 : MACHINE_X64_XOR32),
                                                                 });
                machine_x64_define(selector, result_register, flip_row_index);
            }
            selected = true;
        }
        else if (instruction->unary_operation == IR_UNARY_FLOAT_NEGATE)
        {
            selected = (operand_class.flags & MACHINE_TYPE_CLASS_FLOAT_SCALAR) != 0;
            if (selected)
            {
                // Sign-bit flip in the general-register domain is the exact
                // IEEE negation for every input including NaN.
                bool double_width = operand_class.bit_width_log2 == 6;
                u32 mask_register = machine_x64_synthesize_register(selector);
                u32 immediate_index = machine_x64_append_immediate(selector, double_width ? UINT64_C(0x8000000000000000) : UINT64_C(0x80000000));
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask_register),
                                                                  machine_ref_make(MACHINE_REF_IMMEDIATE, immediate_index)},
                                                     .opcode = MACHINE_X64_MOV_RI,
                                                 });
                u32 negate_row = machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask_register)},
                                                     .opcode = (u16)(double_width ? MACHINE_X64_XOR64 : MACHINE_X64_XOR32),
                                                 });
                machine_x64_define(selector, result_register, negate_row);
            }
        }
        else if (instruction->unary_operation == IR_UNARY_BOOLEAN_NOT)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                 .opcode = MACHINE_X64_TEST_RR,
                                             });
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                           .payload = MACHINE_X64_CONDITION_EQUAL,
                                                           .opcode = MACHINE_X64_SETCC,
                                                       });
            machine_x64_define(selector, result_register, row);
            selected = true;
        }
    }
    return selected;
}

// Element-wise integer vector binary as one three-address EVEX row; the payload
// carries the 66 0F map opcode the canonical native path picks by operation and
// lane width, and bit 8 marks the 64-bit-lane forms whose EVEX encodings are W1
// (vpaddq/vpsubq — their W0 encodings #UD on real hardware).
BUSTER_GLOBAL_LOCAL bool machine_x64_select_vector_binary(MachineX64Selector* selector, IrInstruction* instruction, IrType* operand_type, u32 left_register,
                                                          u32 right_register, u32 result_register)
{
    IrProgram* program = selector->program;

    bool selected = false;
    IrType* element = ir_type_from_id(&program->types, operand_type->element_type);
    if (machine_x64_type_is_vector_register(selector->program, operand_type) && selector->vector_registers_supported && element &&
        element->kind == IR_TYPE_INTEGER)
    {
    u32 vector_opcode = 0;
    switch (instruction->binary_operation)
    {
        break;
    case IR_BINARY_VECTOR_INTEGER_ADD:
        vector_opcode = element->bit_width == 8    ? 0xfcu
                        : element->bit_width == 16 ? 0xfdu
                        : element->bit_width == 32 ? 0xfeu
                        : element->bit_width == 64 ? (0xd4u | 0x100u)
                                                   : 0;
        break;
    case IR_BINARY_VECTOR_INTEGER_SUBTRACT:
        vector_opcode = element->bit_width == 8    ? 0xf8u
                        : element->bit_width == 16 ? 0xf9u
                        : element->bit_width == 32 ? 0xfau
                        : element->bit_width == 64 ? (0xfbu | 0x100u)
                                                   : 0;
        break;
    case IR_BINARY_VECTOR_INTEGER_BITWISE_AND:
        vector_opcode = 0xdbu;
        break;
    case IR_BINARY_VECTOR_INTEGER_BITWISE_OR:
        vector_opcode = 0xebu;
        break;
    case IR_BINARY_VECTOR_INTEGER_BITWISE_XOR:
        vector_opcode = 0xefu;
        break;
    default:
        break;
    }
        if (vector_opcode)
        {
    u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                   .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                                   .payload = vector_opcode,
                                                   .opcode = MACHINE_X64_VBINARY,
                                               });
    machine_x64_define(selector, result_register, row);
            selected = true;
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_float_binary(MachineX64Selector* selector, IrInstruction* instruction, IrType* operand_type, u32 left_register,
                                                         u32 right_register, u32 result_register)
{
    bool selected = false;
    if (operand_type->bit_width == 32 || operand_type->bit_width == 64)
    {
    u32 float_wide_bit = operand_type->bit_width == 64 ? 0x100u : 0;
    u32 sse_opcode = 0;
    u32 compare_payload = 0;
    switch (instruction->binary_operation)
    {
        break;
    case IR_BINARY_FLOAT_ADD:
        sse_opcode = 0x58;
        break;
    case IR_BINARY_FLOAT_SUBTRACT:
        sse_opcode = 0x5c;
        break;
    case IR_BINARY_FLOAT_MULTIPLY:
        sse_opcode = 0x59;
        break;
    case IR_BINARY_FLOAT_DIVIDE:
        sse_opcode = 0x5e;
        break;
    case IR_BINARY_FLOAT_EQUAL:
        compare_payload = 0x4u | (1u << 9);
        break;
    case IR_BINARY_FLOAT_NOT_EQUAL:
        compare_payload = 0x5u | (2u << 9);
        break;
    case IR_BINARY_FLOAT_LESS:
        compare_payload = 0x2u | (1u << 9);
        break;
    case IR_BINARY_FLOAT_LESS_EQUAL:
        compare_payload = 0x6u | (1u << 9);
        break;
    case IR_BINARY_FLOAT_GREATER:
        compare_payload = 0x7u;
        break;
    case IR_BINARY_FLOAT_GREATER_EQUAL:
        compare_payload = 0x3u;
        break;
    default:
        return false;
    }
        selected = sse_opcode || compare_payload;
        if (selected)
        {
    u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                   .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                                   .payload = (sse_opcode ? sse_opcode : compare_payload) | float_wide_bit,
                                                   .opcode = (u16)(sse_opcode ? MACHINE_X64_FARITH : MACHINE_X64_FCMP_SET),
                                               });
    machine_x64_define(selector, result_register, row);
        }
    }
    return selected;
}

// `wide` is the operand class's MACHINE_TYPE_CLASS_WIDE: the 64-bit ALU forms
// against the 32-bit ones.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_scalar_binary(MachineX64Selector* selector, IrInstruction* instruction, bool wide, u32 left_register,
                                                          u32 right_register, u32 result_register)
{
    bool selected = false;
    u16 arithmetic = 0;
    switch (instruction->binary_operation)
    {
        break;
    case IR_BINARY_INTEGER_ADD:
        arithmetic = (u16)(wide ? MACHINE_X64_ADD64 : MACHINE_X64_ADD32);
        break;
    case IR_BINARY_INTEGER_SUBTRACT:
        arithmetic = (u16)(wide ? MACHINE_X64_SUB64 : MACHINE_X64_SUB32);
        break;
    case IR_BINARY_INTEGER_MULTIPLY:
        arithmetic = (u16)(wide ? MACHINE_X64_IMUL64 : MACHINE_X64_IMUL32);
        break;
    case IR_BINARY_INTEGER_BITWISE_AND:
    case IR_BINARY_BOOLEAN_AND:
        arithmetic = (u16)(wide ? MACHINE_X64_AND64 : MACHINE_X64_AND32);
        break;
    case IR_BINARY_INTEGER_BITWISE_OR:
    case IR_BINARY_BOOLEAN_OR:
        arithmetic = (u16)(wide ? MACHINE_X64_OR64 : MACHINE_X64_OR32);
        break;
    case IR_BINARY_INTEGER_BITWISE_XOR:
        arithmetic = (u16)(wide ? MACHINE_X64_XOR64 : MACHINE_X64_XOR32);
        break;
    case IR_BINARY_SHIFT_LEFT:
        arithmetic = (u16)(wide ? MACHINE_X64_SHL64 : MACHINE_X64_SHL32);
        break;
    case IR_BINARY_SIGNED_SHIFT_RIGHT:
        arithmetic = (u16)(wide ? MACHINE_X64_SAR64 : MACHINE_X64_SAR32);
        break;
    case IR_BINARY_UNSIGNED_SHIFT_RIGHT:
        arithmetic = (u16)(wide ? MACHINE_X64_SHR64 : MACHINE_X64_SHR32);
        break;
    case IR_BINARY_SIGNED_DIVIDE:
        arithmetic = (u16)(wide ? MACHINE_X64_SDIV64 : MACHINE_X64_SDIV32);
        break;
    case IR_BINARY_UNSIGNED_DIVIDE:
        arithmetic = (u16)(wide ? MACHINE_X64_UDIV64 : MACHINE_X64_UDIV32);
        break;
    case IR_BINARY_SIGNED_REMAINDER:
        arithmetic = (u16)(wide ? MACHINE_X64_SREM64 : MACHINE_X64_SREM32);
        break;
    case IR_BINARY_UNSIGNED_REMAINDER:
        arithmetic = (u16)(wide ? MACHINE_X64_UREM64 : MACHINE_X64_UREM32);
        break;
    default:
        arithmetic = 0;
    }
    if (arithmetic)
    {
        if (machine_x64_opcode_is_ssa_two_address(arithmetic))
        {
            // Keep the physical two-address operation in explicit SSA
            // form: operand 0 defines the result, operand 1 is the first
            // source (tied by opcode metadata), and operand 2 is the
            // second source. The old MOV-plus-RMW pair obscured this
            // relationship from the allocator and scheduler.
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                                           .opcode = arithmetic,
                                                       });
            machine_x64_define(selector, result_register, row);
        }
        else
        {
            // Fixed-register shifts and divide/remainder retain their
            // legacy constrained two-row shape until their target
            // fixed-register contract is represented in metadata.
            u32 copy_row = machine_x64_select_row(selector, (MachineInstruction){
                                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register)},
                                                                 .opcode = MACHINE_X64_MOV_RR,
                                                             });
            machine_x64_define(selector, result_register, copy_row);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                                 .opcode = arithmetic,
                                             });
        }
        selected = true;
    }
    else
    {
        u32 condition = machine_x64_condition_from_comparison(instruction->binary_operation);
        if (condition)
        {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                             .opcode = (u16)(wide ? MACHINE_X64_CMP64 : MACHINE_X64_CMP32),
                                         });
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                       .payload = condition,
                                                       .opcode = MACHINE_X64_SETCC,
                                                   });
            machine_x64_define(selector, result_register, row);
            selected = true;
        }
    }
    return selected;
}

// The CMPXCHG16B success boolean, when this comparison is the one that reads
// it: the atomic row materializes it immediately, and later aggregate copies
// consume that value rather than live flags across unrelated IR rows.
BUSTER_GLOBAL_LOCAL u32 machine_x64_atomic_success_source(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;

    u32 success_register = UINT32_MAX;
    if (selector->atomic_success_registers && instruction->operand_count >= 2 && instruction->binary_operation == IR_BINARY_INTEGER_EQUAL &&
        instruction->operands[0].value < function->value_count && instruction->operands[1].value < function->value_count)
    {
        IrValue* observed_value = function->values + instruction->operands[0].value;
        IrInstruction* atomic_instruction =
            observed_value->definition.value < function->instruction_count ? function->instructions + observed_value->definition.value : 0;
        bool is_atomic_expected_compare = atomic_instruction && atomic_instruction->opcode == IR_OPCODE_ATOMIC_COMPARE_EXCHANGE &&
                                          atomic_instruction->operand_count >= 2 &&
                                          atomic_instruction->operands[1].value == instruction->operands[1].value;
        if (is_atomic_expected_compare)
        {
            success_register = selector->atomic_success_registers[instruction->operands[0].value];
        }
    }
    return success_register;
}

// A 128-bit shift in any of the three directions: the result is 128 bits wide
// too, which is what separates it from the comparisons below, whose operands
// are i128 and whose result is a boolean.
BUSTER_GLOBAL_LOCAL bool machine_x64_binary_is_i128_shift(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;

    bool matched = false;
    if (instruction->operand_count >= 2 && instruction->operands[0].value < function->value_count && instruction->result.value < function->value_count)
    {
        MachineTypeClass left_class = machine_x64_type_class(selector, function->values[instruction->operands[0].value].canonical_type);
        MachineTypeClass result_class = machine_x64_type_class(selector, function->values[instruction->result.value].canonical_type);
        matched = (left_class.flags & result_class.flags & MACHINE_TYPE_CLASS_INTEGER128) != 0 &&
                  (instruction->binary_operation == IR_BINARY_SHIFT_LEFT || instruction->binary_operation == IR_BINARY_SIGNED_SHIFT_RIGHT ||
                   instruction->binary_operation == IR_BINARY_UNSIGNED_SHIFT_RIGHT);
    }
    return matched;
}

// A binary whose *operands* are 128-bit integers, which is the whole class this
// selector dispatches: the shifts and the arithmetic answer 128 bits, the
// comparisons answer a boolean.
BUSTER_GLOBAL_LOCAL bool machine_x64_binary_is_i128(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;

    bool matched = false;
    if (instruction->operand_count >= 2 && instruction->operands[0].value < function->value_count &&
        instruction->operands[1].value < function->value_count)
    {
        MachineTypeClass left_class = machine_x64_type_class(selector, function->values[instruction->operands[0].value].canonical_type);
        matched = (left_class.flags & MACHINE_TYPE_CLASS_INTEGER128) != 0;
    }
    return matched;
}

// Both 128-bit operands as slot-backed pairs: true only when the two value
// slots exist, filling the four half registers.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_halves(MachineX64Selector* selector, IrInstruction* instruction, u32* left_low, u32* left_high,
                                                        u32* right_low, u32* right_high)
{
    IrFunction* function = selector->function;

    bool selected = false;
    u32 left_slot = instruction->operands[0].value < function->value_count ? selector->value_stack_slots[instruction->operands[0].value] : UINT32_MAX;
    u32 right_slot = instruction->operands[1].value < function->value_count ? selector->value_stack_slots[instruction->operands[1].value] : UINT32_MAX;
    if (left_slot != UINT32_MAX && right_slot != UINT32_MAX)
    {
        *left_low = machine_x64_select_frame_load64(selector, left_slot, 0);
        *left_high = machine_x64_select_frame_load64(selector, left_slot, 8);
        *right_low = machine_x64_select_frame_load64(selector, right_slot, 0);
        *right_high = machine_x64_select_frame_load64(selector, right_slot, 8);
        selected = true;
    }
    return selected;
}

// One three-operand SSA row into a fresh synthesized register. Only the
// two-address SSA arithmetic opcodes may be spelled this way; the shifts and
// the divides keep their constrained two-row shape.
BUSTER_GLOBAL_LOCAL u32 machine_x64_select_arithmetic_row(MachineX64Selector* selector, u16 opcode, u32 left_register, u32 right_register)
{
    u32 result = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result),
                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                         .opcode = opcode,
                                     });
    return result;
}

// The constrained sibling of machine_x64_select_arithmetic_row, for an opcode
// whose first slot is used *and* defined: the value is copied into a fresh
// register first and the operation rewrites it in place, which is the two-row
// shape the divides already use and the only one an opcode outside
// machine_x64_opcode_is_ssa_two_address may be spelled with.
BUSTER_GLOBAL_LOCAL u32 machine_x64_select_constrained_row(MachineX64Selector* selector, u16 opcode, u32 left_register, u32 right_register)
{
    u32 result = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result),
                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register)},
                                         .opcode = MACHINE_X64_MOV_RR,
                                     });
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result),
                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                         .opcode = opcode,
                                     });
    return result;
}

// One CMP64 + SETcc pair into a fresh synthesized register. The compare is
// re-issued per SETcc so every flags read sits directly behind its producer,
// which is the shape the scheduler's flag chain already models. SETcc's row is
// a two-step sequence ending in MOVZX, so the boolean it leaves is zero
// extended to sixty-four bits and can be blended with AND64/OR64 below.
BUSTER_GLOBAL_LOCAL u32 machine_x64_select_compare_set(MachineX64Selector* selector, u32 left_register, u32 right_register, u32 condition)
{
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                         .opcode = MACHINE_X64_CMP64,
                                     });
    u32 result = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result)},
                                         .payload = condition,
                                         .opcode = MACHINE_X64_SETCC,
                                     });
    return result;
}

// Complement and negate both limbs with ordinary SSA arithmetic. XOR gives
// complement results one definition; negation propagates a low-limb borrow.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_unary(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;
    u32 source_slot = instruction->operand_count == 1 && instruction->operands[0].value < function->value_count
                          ? selector->value_stack_slots[instruction->operands[0].value] : UINT32_MAX;
    u32 result_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
    bool negate = instruction->unary_operation == IR_UNARY_INTEGER_NEGATE;
    bool selected = (negate || instruction->unary_operation == IR_UNARY_INTEGER_BITWISE_NOT) && source_slot != UINT32_MAX && result_slot != UINT32_MAX;
    if (selected)
    {
        u32 low = machine_x64_select_frame_load64(selector, source_slot, 0);
        u32 high = machine_x64_select_frame_load64(selector, source_slot, 8);
        u32 constant = machine_x64_select_immediate_register(selector, negate ? 0 : UINT64_MAX);
        u16 opcode = negate ? MACHINE_X64_SUB64 : MACHINE_X64_XOR64;
        u32 result_low = machine_x64_select_arithmetic_row(selector, opcode, constant, low);
        u32 result_high = machine_x64_select_arithmetic_row(selector, opcode, constant, high);
        if (negate)
        {
            u32 borrow = machine_x64_select_compare_set(selector, low, constant, MACHINE_X64_CONDITION_NOT_EQUAL);
            result_high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, result_high, borrow);
        }
        machine_x64_select_frame_store64(selector, result_slot, 0, result_low);
        machine_x64_select_frame_store64(selector, result_slot, 8, result_high);
    }
    return selected;
}

// Variable shifts use disjoint masks for counts below/above 64. A separate
// nonzero mask suppresses the cross term at count zero, where the hardware
// shift would otherwise wrap 64 to zero. All defined C counts (0..127) use
// the same bounded straight-line MIR expansion.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_variable_shift(MachineX64Selector* selector, IrInstruction* instruction)
{
    u32 source_slot = selector->value_stack_slots[instruction->operands[0].value];
    u32 result_slot = selector->value_stack_slots[instruction->result.value];
    u32 count_slot = selector->value_stack_slots[instruction->operands[1].value];
    u32 count = UINT32_MAX;
    bool selected = source_slot != UINT32_MAX && result_slot != UINT32_MAX;
    if (selected)
    {
        if (count_slot != UINT32_MAX)
        {
            count = machine_x64_select_frame_load64(selector, count_slot, 0);
        }
        else
        {
            selected = machine_x64_operand_register(selector, instruction->operands[1], &count);
        }
    }
    if (selected)
    {
        u32 low = machine_x64_select_frame_load64(selector, source_slot, 0);
        u32 high = machine_x64_select_frame_load64(selector, source_slot, 8);
        u32 zero = machine_x64_select_immediate_register(selector, 0);
        u32 width = machine_x64_select_immediate_register(selector, 64);
        u32 ones = machine_x64_select_immediate_register(selector, UINT64_MAX);
        u32 small = machine_x64_select_compare_set(selector, count, width, MACHINE_X64_CONDITION_BELOW);
        u32 small_mask = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, zero, small);
        u32 large_mask = machine_x64_select_arithmetic_row(selector, MACHINE_X64_XOR64, small_mask, ones);
        u32 nonzero = machine_x64_select_compare_set(selector, count, zero, MACHINE_X64_CONDITION_NOT_EQUAL);
        u32 nonzero_mask = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, zero, nonzero);
        u32 inverse = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, width, count);
        bool left = instruction->binary_operation == IR_BINARY_SHIFT_LEFT;
        bool signed_right = instruction->binary_operation == IR_BINARY_SIGNED_SHIFT_RIGHT;
        u32 kept = machine_x64_select_constrained_row(selector, left ? MACHINE_X64_SHL64 : (signed_right ? MACHINE_X64_SAR64 : MACHINE_X64_SHR64),
                                                     left ? low : high, count);
        u32 shifted = machine_x64_select_constrained_row(selector, left ? MACHINE_X64_SHL64 : MACHINE_X64_SHR64, left ? high : low, count);
        u32 cross = machine_x64_select_constrained_row(selector, left ? MACHINE_X64_SHR64 : MACHINE_X64_SHL64, left ? low : high, inverse);
        cross = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, cross, nonzero_mask);
        u32 filled = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, shifted, cross);
        filled = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, filled, small_mask);
        u32 transferred = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, kept, large_mask);
        filled = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, filled, transferred);
        u32 surviving = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, kept, small_mask);
        if (signed_right)
        {
            u32 sign_count = machine_x64_select_immediate_register(selector, 63);
            u32 sign = machine_x64_select_constrained_row(selector, MACHINE_X64_SAR64, high, sign_count);
            sign = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, sign, large_mask);
            surviving = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, surviving, sign);
        }
        machine_x64_select_frame_store64(selector, result_slot, 0, left ? surviving : filled);
        machine_x64_select_frame_store64(selector, result_slot, 8, left ? filled : surviving);
    }
    return selected;
}


// A fixed 128-iteration restoring loop remains ordinary scalar MIR. The
// five loop parameters hold dividend/quotient, remainder, and bit count;
// all invariant limbs dominate the loop and evolving values use edge copies.
#define MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT 5u

BUSTER_GLOBAL_LOCAL bool machine_x64_instruction_is_i128_divide(IrProgram* program, IrInstruction* instruction)
{
    IrBinaryOperation operation = instruction->binary_operation;
    bool result = false;
    if (instruction->opcode == IR_OPCODE_BINARY &&
        (operation == IR_BINARY_SIGNED_DIVIDE || operation == IR_BINARY_UNSIGNED_DIVIDE ||
         operation == IR_BINARY_SIGNED_REMAINDER || operation == IR_BINARY_UNSIGNED_REMAINDER))
    {
        IrType* type = ir_type_from_id(&program->types, instruction->canonical_type);
        result = type && type->kind == IR_TYPE_INTEGER && type->bit_width == 128;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL void machine_x64_select_i128_apply_sign(MachineX64Selector* selector, u32 sign, u32* low, u32* high)
{
    u32 inverted_low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_XOR64, *low, sign);
    u32 inverted_high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_XOR64, *high, sign);
    u32 borrow = machine_x64_select_compare_set(selector, inverted_low, sign, MACHINE_X64_CONDITION_BELOW);
    *low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, inverted_low, sign);
    *high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, inverted_high, sign);
    *high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, *high, borrow);
}

// The extra binary modes set x87 precision for one closed frame transaction.
// In particular the final i128 sum rounds once at the destination precision.
BUSTER_GLOBAL_LOCAL void machine_x64_select_f80_binary_slot(MachineX64Selector* selector, u32 destination, u32 left, u32 right, u32 mode)
{
    machine_x64_select_row(selector, (MachineInstruction){
        .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, destination), machine_ref_make(MACHINE_REF_STACK_SLOT, left),
                     machine_ref_make(MACHINE_REF_STACK_SLOT, right)},
        .payload = mode, .opcode = MACHINE_X64_F80_BINARY});
}

BUSTER_GLOBAL_LOCAL void machine_x64_select_f80_convert_slot(MachineX64Selector* selector, u32 destination, u32 source, u32 mode)
{
    u32 scratch = machine_x64_append_slot(selector, 8, 8);
    machine_x64_select_row(selector, (MachineInstruction){
        .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, destination), machine_ref_make(MACHINE_REF_STACK_SLOT, source),
                     machine_ref_make(MACHINE_REF_STACK_SLOT, scratch)},
        .payload = mode, .opcode = MACHINE_X64_F80_CONVERT});
}

// FILD consumes a signed eightbyte. Split the unsigned top bit before it and
// add the exact 2^63 correction under a temporary 64-bit x87 precision mode.
BUSTER_GLOBAL_LOCAL void machine_x64_select_u64_to_f80_slot(MachineX64Selector* selector, u32 value, u32 destination)
{
    u32 sign = machine_x64_select_constrained_row(selector, MACHINE_X64_SAR64, value,
                                                  machine_x64_select_immediate_register(selector, 63));
    u32 low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, value,
                                                machine_x64_select_immediate_register(selector, UINT64_C(0x7fffffffffffffff)));
    u32 integer = machine_x64_append_slot(selector, 8, 8);
    u32 bias = machine_x64_append_slot(selector, 16, 16);
    machine_x64_select_frame_store64(selector, integer, 0, low);
    machine_x64_select_f80_convert_slot(selector, destination, integer, 4);
    machine_x64_select_f80_u64_bias(selector, bias, sign);
    machine_x64_select_f80_binary_slot(selector, destination, destination, bias, MACHINE_X64_F80_ADD_P64);
}

// Compare against 2^63, subtract the exact selected bias, then FISTP under
// truncation. The correction bit is ORed back into the unsigned eightbyte.
BUSTER_GLOBAL_LOCAL u32 machine_x64_select_f80_slot_to_u64(MachineX64Selector* selector, u32 source)
{
    u32 bias = machine_x64_append_slot(selector, 16, 16);
    u32 remainder = machine_x64_append_slot(selector, 16, 16);
    u32 integer = machine_x64_append_slot(selector, 8, 8);
    machine_x64_select_frame_store64(selector, bias, 0,
                                     machine_x64_select_immediate_register(selector, UINT64_C(0x8000000000000000)));
    machine_x64_select_frame_store64(selector, bias, 8, machine_x64_select_immediate_register(selector, UINT64_C(0x403e)));
    u32 high = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high), machine_ref_make(MACHINE_REF_STACK_SLOT, source),
                     machine_ref_make(MACHINE_REF_STACK_SLOT, bias)},
        .payload = 5, .opcode = MACHINE_X64_F80_COMPARE});
    u32 mask = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64,
                                                 machine_x64_select_immediate_register(selector, 0), high);
    u32 high_bit = machine_x64_select_f80_u64_bias(selector, bias, mask);
    machine_x64_select_f80_binary_slot(selector, remainder, source, bias, MACHINE_X64_F80_SUBTRACT_P64);
    machine_x64_select_f80_convert_slot(selector, integer, remainder, 5);
    u32 low = machine_x64_select_frame_load64(selector, integer, 0);
    return machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, low, high_bit);
}

// A two-limb magnitude is exact in f80 until the final add. That add uses
// destination precision (24/53/64 bits) and the caller's rounding mode;
// changing the x87 control word never escapes the binary machine row.
BUSTER_GLOBAL_LOCAL void machine_x64_select_i128_to_float(MachineX64Selector* selector, IrInstruction* instruction,
                                                         IrType* target_type, u32 source_slot, u32 result_register)
{
    bool signed_value = instruction->conversion_operation == IR_CONVERSION_SIGNED_INTEGER_TO_FLOAT;
    u32 low = machine_x64_select_frame_load64(selector, source_slot, 0);
    u32 high = machine_x64_select_frame_load64(selector, source_slot, 8);
    u32 sign = machine_x64_select_immediate_register(selector, 0);
    if (signed_value)
    {
        sign = machine_x64_select_constrained_row(selector, MACHINE_X64_SAR64, high,
                                                  machine_x64_select_immediate_register(selector, 63));
        machine_x64_select_i128_apply_sign(selector, sign, &low, &high);
    }
    u32 low_float = machine_x64_append_slot(selector, 16, 16);
    u32 high_float = machine_x64_append_slot(selector, 16, 16);
    u32 scale = machine_x64_append_slot(selector, 16, 16);
    u32 scaled_high = machine_x64_append_slot(selector, 16, 16);
    u32 sum = machine_x64_append_slot(selector, 16, 16);
    machine_x64_select_u64_to_f80_slot(selector, low, low_float);
    machine_x64_select_u64_to_f80_slot(selector, high, high_float);
    machine_x64_select_frame_store64(selector, scale, 0,
                                     machine_x64_select_immediate_register(selector, UINT64_C(0x8000000000000000)));
    machine_x64_select_frame_store64(selector, scale, 8, machine_x64_select_immediate_register(selector, UINT64_C(0x403f)));
    machine_x64_select_f80_binary_slot(selector, scaled_high, high_float, scale, MACHINE_X64_F80_MULTIPLY_P64);
    if (signed_value)
    {
        // Round a negative sum as a negative x87 value. Flipping the sign
        // after a positive addition would reverse upward/downward rounding.
        u32 sign_bit = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, sign,
                                                         machine_x64_select_immediate_register(selector, UINT64_C(0x8000)));
        u32 halves[] = {scaled_high, low_float};
        for (u32 half = 0; half < BUSTER_ARRAY_LENGTH(halves); half += 1)
        {
            u32 exponent = machine_x64_select_frame_load64(selector, halves[half], 8);
            machine_x64_select_frame_store64(selector, halves[half], 8,
                machine_x64_select_arithmetic_row(selector, MACHINE_X64_XOR64, exponent, sign_bit));
        }
    }
    u32 mode = target_type->bit_width == 32 ? MACHINE_X64_F80_ADD_P24 :
               target_type->bit_width == 64 ? MACHINE_X64_F80_ADD_P53 : MACHINE_X64_F80_ADD_P64;
    machine_x64_select_f80_binary_slot(selector, sum, scaled_high, low_float, mode);
    if (target_type->bit_width == 80)
    {
        u32 destination = selector->value_stack_slots[instruction->result.value];
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, destination), machine_ref_make(MACHINE_REF_STACK_SLOT, sum)},
            .payload = 16, .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME});
    }
    else
    {
        u32 scalar = machine_x64_append_slot(selector, 8, 8);
        machine_x64_select_f80_convert_slot(selector, scalar, sum, target_type->bit_width == 32 ? 2u : 3u);
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register), machine_ref_make(MACHINE_REF_STACK_SLOT, scalar)},
            .opcode = MACHINE_X64_LOAD_FRAME});
        machine_x64_define(selector, result_register, row);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_select_float_to_i128(MachineX64Selector* selector, IrInstruction* instruction,
                                                         IrType* source_type, u32 source_slot, u32 source_register, u32 result_slot)
{
    bool signed_value = instruction->conversion_operation == IR_CONVERSION_FLOAT_TO_SIGNED_INTEGER;
    u32 sign = machine_x64_select_immediate_register(selector, 0);
    u32 magnitude = machine_x64_append_slot(selector, 16, 16);
    if (source_type->bit_width == 80)
    {
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, magnitude), machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot)},
            .payload = 16, .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME});
        u32 exponent = machine_x64_select_frame_load64(selector, source_slot, 8);
        if (signed_value)
        {
            u32 sign_bit = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, exponent,
                                                              machine_x64_select_immediate_register(selector, UINT64_C(0x8000)));
            sign = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, sign,
                machine_x64_select_constrained_row(selector, MACHINE_X64_SHR64, sign_bit,
                                                   machine_x64_select_immediate_register(selector, 15)));
        }
        u32 absolute = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, exponent,
                                                          machine_x64_select_immediate_register(selector, UINT64_C(0x7fff)));
        machine_x64_select_frame_store64(selector, magnitude, 8, absolute);
    }
    else
    {
        u64 sign_mask = source_type->bit_width == 32 ? UINT64_C(0x80000000) : UINT64_C(0x8000000000000000);
        if (signed_value)
        {
            u32 sign_bit = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, source_register,
                                                              machine_x64_select_immediate_register(selector, sign_mask));
            u32 shifted = machine_x64_select_constrained_row(selector, MACHINE_X64_SHR64, sign_bit,
                                machine_x64_select_immediate_register(selector, source_type->bit_width - 1));
            sign = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, sign, shifted);
        }
        u32 absolute = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, source_register,
                                                          machine_x64_select_immediate_register(selector,
                                                              source_type->bit_width == 32 ? UINT64_C(0x7fffffff) : UINT64_C(0x7fffffffffffffff)));
        u32 input = machine_x64_append_slot(selector, 8, 8);
        machine_x64_select_frame_store64(selector, input, 0, absolute);
        machine_x64_select_f80_convert_slot(selector, magnitude, input, source_type->bit_width == 32 ? 0u : 1u);
    }
    u32 inverse_scale = machine_x64_append_slot(selector, 16, 16);
    u32 scaled = machine_x64_append_slot(selector, 16, 16);
    u32 high_float = machine_x64_append_slot(selector, 16, 16);
    u32 scale = machine_x64_append_slot(selector, 16, 16);
    u32 contribution = machine_x64_append_slot(selector, 16, 16);
    u32 residual = machine_x64_append_slot(selector, 16, 16);
    machine_x64_select_frame_store64(selector, inverse_scale, 0,
                                     machine_x64_select_immediate_register(selector, UINT64_C(0x8000000000000000)));
    machine_x64_select_frame_store64(selector, inverse_scale, 8, machine_x64_select_immediate_register(selector, UINT64_C(0x3fbf)));
    machine_x64_select_f80_binary_slot(selector, scaled, magnitude, inverse_scale, MACHINE_X64_F80_MULTIPLY_P64);
    u32 high = machine_x64_select_f80_slot_to_u64(selector, scaled);
    machine_x64_select_u64_to_f80_slot(selector, high, high_float);
    machine_x64_select_frame_store64(selector, scale, 0,
                                     machine_x64_select_immediate_register(selector, UINT64_C(0x8000000000000000)));
    machine_x64_select_frame_store64(selector, scale, 8, machine_x64_select_immediate_register(selector, UINT64_C(0x403f)));
    machine_x64_select_f80_binary_slot(selector, contribution, high_float, scale, MACHINE_X64_F80_MULTIPLY_P64);
    machine_x64_select_f80_binary_slot(selector, residual, magnitude, contribution, MACHINE_X64_F80_SUBTRACT_P64);
    u32 low = machine_x64_select_f80_slot_to_u64(selector, residual);
    if (signed_value)
    {
        machine_x64_select_i128_apply_sign(selector, sign, &low, &high);
    }
    machine_x64_select_frame_store64(selector, result_slot, 0, low);
    machine_x64_select_frame_store64(selector, result_slot, 8, high);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_cast_i128_float(MachineX64Selector* selector, IrInstruction* instruction,
                                                            IrType* source_type, IrType* target_type, u32 result_register)
{
    bool from_integer = source_type && target_type && source_type->kind == IR_TYPE_INTEGER && source_type->bit_width == 128 &&
                        target_type->kind == IR_TYPE_FLOAT &&
                        (instruction->conversion_operation == IR_CONVERSION_SIGNED_INTEGER_TO_FLOAT ||
                         instruction->conversion_operation == IR_CONVERSION_UNSIGNED_INTEGER_TO_FLOAT);
    bool to_integer = source_type && target_type && source_type->kind == IR_TYPE_FLOAT &&
                      target_type->kind == IR_TYPE_INTEGER && target_type->bit_width == 128 &&
                      (instruction->conversion_operation == IR_CONVERSION_FLOAT_TO_SIGNED_INTEGER ||
                       instruction->conversion_operation == IR_CONVERSION_FLOAT_TO_UNSIGNED_INTEGER);
    bool source_float = source_type && (source_type->bit_width == 32 || source_type->bit_width == 64 ||
                                        (source_type->bit_width == 80 && machine_x64_type_is_f80(selector,
                                            selector->function->values[instruction->operands[0].value].canonical_type)));
    bool target_float = target_type && (target_type->bit_width == 32 || target_type->bit_width == 64 ||
                                        (target_type->bit_width == 80 && machine_x64_type_is_f80(selector, instruction->canonical_type)));
    u32 source_slot = selector->value_stack_slots[instruction->operands[0].value];
    u32 result_slot = selector->value_stack_slots[instruction->result.value];
    u32 source_register = UINT32_MAX;
    bool selected = from_integer ? target_float && source_slot != UINT32_MAX &&
                                   (target_type->bit_width == 80 ? result_slot != UINT32_MAX : result_register != UINT32_MAX)
                    : to_integer ? source_float && result_slot != UINT32_MAX &&
                                   (source_type->bit_width == 80 ? source_slot != UINT32_MAX :
                                    machine_x64_operand_register(selector, instruction->operands[0], &source_register))
                                 : false;
    if (selected)
    {
        if (from_integer)
        {
            machine_x64_select_i128_to_float(selector, instruction, target_type, source_slot, result_register);
        }
        else
        {
            machine_x64_select_float_to_i128(selector, instruction, source_type, source_slot, source_register, result_slot);
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL void machine_x64_select_i128_divide_edge(MachineX64Selector* selector, u32 source, u32 destination, u32 const* values)
{
    u32 copy_offset = selector->builder.edge_copy_sources.total_count;
    for (u32 index = 0; index < MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT; index += 1)
    {
        machine_builder_edge_copy_source(&selector->builder, machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[index]));
    }
    machine_builder_edge(&selector->builder, (MachineEdge){.source_block = source, .destination_block = destination,
                                                         .copy_offset = copy_offset, .copy_count = MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT});
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_divide(MachineX64Selector* selector, IrInstruction* instruction, u32 result_slot)
{
    u32 left_low;
    u32 left_high;
    u32 right_low;
    u32 right_high;
    bool selected = false;
    if (result_slot != UINT32_MAX && machine_x64_select_i128_halves(selector, instruction, &left_low, &left_high, &right_low, &right_high))
    {
        bool signed_value = instruction->binary_operation == IR_BINARY_SIGNED_DIVIDE || instruction->binary_operation == IR_BINARY_SIGNED_REMAINDER;
        bool remainder_result = instruction->binary_operation == IR_BINARY_SIGNED_REMAINDER || instruction->binary_operation == IR_BINARY_UNSIGNED_REMAINDER;
        u32 zero = machine_x64_select_immediate_register(selector, 0);
        u32 one = machine_x64_select_immediate_register(selector, 1);
        u32 top_bit = machine_x64_select_immediate_register(selector, 63);
        u32 count = machine_x64_select_immediate_register(selector, 128);
        u32 result_sign = zero;
        if (signed_value)
        {
            u32 left_sign = machine_x64_select_constrained_row(selector, MACHINE_X64_SAR64, left_high, top_bit);
            u32 right_sign = machine_x64_select_constrained_row(selector, MACHINE_X64_SAR64, right_high, top_bit);
            machine_x64_select_i128_apply_sign(selector, left_sign, &left_low, &left_high);
            machine_x64_select_i128_apply_sign(selector, right_sign, &right_low, &right_high);
            result_sign = remainder_result ? left_sign : machine_x64_select_arithmetic_row(selector, MACHINE_X64_XOR64, left_sign, right_sign);
        }
        u32 entry = selector->builder.open_block;
        u32 loop = entry + 1;
        u32 continuation = entry + 2;
        u32 initial[MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT] = {left_low, left_high, zero, zero, count};
        machine_x64_select_i128_divide_edge(selector, entry, loop, initial);
        machine_x64_select_row(selector, (MachineInstruction){.operands = {machine_ref_make(MACHINE_REF_BLOCK, loop)}, .opcode = MACHINE_X64_JMP});
        machine_builder_block_end(&selector->builder, selector->open_block);
        machine_builder_block_begin(&selector->builder);
        selector->open_block = (MachineBlock){.parameter_offset = selector->builder.block_parameters.total_count,
                                             .parameter_count = MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT};
        u32 state[MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT];
        for (u32 index = 0; index < MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT; index += 1)
        {
            state[index] = machine_builder_virtual_register(&selector->builder, (MachineVirtualRegister){.definition_point = MACHINE_POINT_INVALID,
                                                                                                       .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                                                       .typed_origin = IR_ID_UNDERLYING_INVALID});
            machine_builder_block_parameter(&selector->builder, (MachineBlockParameter){.virtual_register = state[index]});
        }
        // Shift one dividend bit into the partial remainder. Its prefix has
        // at most 128 bits, so this shift cannot lose a 129th remainder bit.
        u32 dividend_bit = machine_x64_select_constrained_row(selector, MACHINE_X64_SHR64, state[1], top_bit);
        u32 remainder_cross = machine_x64_select_constrained_row(selector, MACHINE_X64_SHR64, state[2], top_bit);
        u32 remainder_low = machine_x64_select_constrained_row(selector, MACHINE_X64_SHL64, state[2], one);
        remainder_low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, remainder_low, dividend_bit);
        u32 remainder_high = machine_x64_select_constrained_row(selector, MACHINE_X64_SHL64, state[3], one);
        remainder_high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, remainder_high, remainder_cross);
        u32 high_above = machine_x64_select_compare_set(selector, remainder_high, right_high, MACHINE_X64_CONDITION_ABOVE);
        u32 high_equal = machine_x64_select_compare_set(selector, remainder_high, right_high, MACHINE_X64_CONDITION_EQUAL);
        u32 low_enough = machine_x64_select_compare_set(selector, remainder_low, right_low, MACHINE_X64_CONDITION_ABOVE_EQUAL);
        u32 subtract = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, high_equal, low_enough);
        subtract = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, high_above, subtract);
        u32 mask = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, zero, subtract);
        u32 subtract_low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, right_low, mask);
        u32 subtract_high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, right_high, mask);
        u32 borrow = machine_x64_select_compare_set(selector, remainder_low, subtract_low, MACHINE_X64_CONDITION_BELOW);
        u32 next[MACHINE_X64_I128_DIVIDE_PARAMETER_COUNT];
        next[2] = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, remainder_low, subtract_low);
        next[3] = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, remainder_high, subtract_high);
        next[3] = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, next[3], borrow);
        u32 quotient_cross = machine_x64_select_constrained_row(selector, MACHINE_X64_SHR64, state[0], top_bit);
        next[0] = machine_x64_select_constrained_row(selector, MACHINE_X64_SHL64, state[0], one);
        next[0] = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, next[0], subtract);
        next[1] = machine_x64_select_constrained_row(selector, MACHINE_X64_SHL64, state[1], one);
        next[1] = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, next[1], quotient_cross);
        next[4] = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, state[4], one);
        machine_x64_select_row(selector, (MachineInstruction){.operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, next[4]),
                                                                         machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, next[4])},
                                                            .opcode = MACHINE_X64_TEST_RR});
        machine_x64_select_row(selector, (MachineInstruction){.operands = {machine_ref_make(MACHINE_REF_BLOCK, loop),
                                                                         machine_ref_make(MACHINE_REF_BLOCK, continuation)},
                                                            .opcode = MACHINE_X64_JCC, .payload = MACHINE_X64_CONDITION_NOT_EQUAL});
        machine_x64_select_i128_divide_edge(selector, loop, loop, next);
        machine_builder_edge(&selector->builder, (MachineEdge){.source_block = loop, .destination_block = continuation});
        machine_builder_block_end(&selector->builder, selector->open_block);
        machine_builder_block_begin(&selector->builder);
        selector->open_block = (MachineBlock){0};
        u32 result_low = next[remainder_result ? 2 : 0];
        u32 result_high = next[remainder_result ? 3 : 1];
        if (signed_value)
        {
            machine_x64_select_i128_apply_sign(selector, result_sign, &result_low, &result_high);
        }
        machine_x64_select_frame_store64(selector, result_slot, 0, result_low);
        machine_x64_select_frame_store64(selector, result_slot, 8, result_high);
        selected = true;
    }
    return selected;
}

// The 128-bit binary subset over slot-backed pairs, the same one the AArch64
// selector carries and spelled the same way: the three constant-amount shifts,
// the bitwise trio per half, add and subtract per half with the carry and the
// borrow as SETcc booleans off the low halves, equality through per-half XOR,
// and the eight ordered comparisons as the strict high-half relation blended
// with the unsigned low-half one behind high-half equality.
//
// x86 has ADC and SBB, which would carry the flags between the halves in one
// instruction each; the boolean spelling is used instead because it needs no
// flags-pairing row, and a row that produces flags for a *later* row to consume
// is not something MachineInstruction models yet. The multiply is the
// canonical emitter's own three-multiply sequence over MULH64. Division and
// remainder split into the scalar restoring loop above.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_i128_binary(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrFunction* function = selector->function;

    bool selected = false;
    IrBinaryOperation operation = instruction->binary_operation;
    u32 result_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
    u32 left_low = UINT32_MAX;
    u32 left_high = UINT32_MAX;
    u32 right_low = UINT32_MAX;
    u32 right_high = UINT32_MAX;
    if (machine_x64_instruction_is_i128_divide(selector->program, instruction))
    {
        selected = machine_x64_select_i128_divide(selector, instruction, result_slot);
    }
    else if (machine_x64_binary_is_i128_shift(selector, instruction))
    {
        u32 amount;
        selected = machine_x64_constant_shift_amount(selector, instruction->operands[1], &amount);
        if (selected)
        {
            selected = operation == IR_BINARY_SHIFT_LEFT           ? machine_x64_select_i128_shift_left(selector, instruction, amount)
                       : operation == IR_BINARY_SIGNED_SHIFT_RIGHT ? machine_x64_select_i128_signed_shift_right(selector, instruction, amount)
                                                                   : machine_x64_select_i128_unsigned_shift_right(selector, instruction, amount);
        }
        else
        {
            selected = machine_x64_select_i128_variable_shift(selector, instruction);
        }
    }
    else if ((operation == IR_BINARY_INTEGER_BITWISE_AND || operation == IR_BINARY_INTEGER_BITWISE_OR || operation == IR_BINARY_INTEGER_BITWISE_XOR) &&
             result_slot != UINT32_MAX && machine_x64_select_i128_halves(selector, instruction, &left_low, &left_high, &right_low, &right_high))
    {
        u16 opcode = operation == IR_BINARY_INTEGER_BITWISE_AND  ? MACHINE_X64_AND64
                     : operation == IR_BINARY_INTEGER_BITWISE_OR ? MACHINE_X64_OR64
                                                                 : MACHINE_X64_XOR64;
        machine_x64_select_frame_store64(selector, result_slot, 0, machine_x64_select_arithmetic_row(selector, opcode, left_low, right_low));
        machine_x64_select_frame_store64(selector, result_slot, 8, machine_x64_select_arithmetic_row(selector, opcode, left_high, right_high));
        selected = true;
    }
    else if ((operation == IR_BINARY_INTEGER_ADD || operation == IR_BINARY_INTEGER_SUBTRACT) && result_slot != UINT32_MAX &&
             machine_x64_select_i128_halves(selector, instruction, &left_low, &left_high, &right_low, &right_high))
    {
        if (operation == IR_BINARY_INTEGER_ADD)
        {
            // low' = low_a + low_b; the carry is low' <u low_a.
            u32 sum_low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_ADD64, left_low, right_low);
            u32 carry = machine_x64_select_compare_set(selector, sum_low, left_low, MACHINE_X64_CONDITION_BELOW);
            u32 sum_high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_ADD64, left_high, right_high);
            machine_x64_select_frame_store64(selector, result_slot, 0, sum_low);
            machine_x64_select_frame_store64(selector, result_slot, 8, machine_x64_select_arithmetic_row(selector, MACHINE_X64_ADD64, sum_high, carry));
        }
        else
        {
            // The borrow is low_a <u low_b, read before the halves move.
            u32 borrow = machine_x64_select_compare_set(selector, left_low, right_low, MACHINE_X64_CONDITION_BELOW);
            u32 difference_low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, left_low, right_low);
            u32 difference_high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, left_high, right_high);
            machine_x64_select_frame_store64(selector, result_slot, 0, difference_low);
            machine_x64_select_frame_store64(selector, result_slot, 8,
                                             machine_x64_select_arithmetic_row(selector, MACHINE_X64_SUB64, difference_high, borrow));
        }
        selected = true;
    }
    else if (operation == IR_BINARY_INTEGER_MULTIPLY && result_slot != UINT32_MAX &&
             machine_x64_select_i128_halves(selector, instruction, &left_low, &left_high, &right_low, &right_high))
    {
        // low = a.lo * b.lo truncated, which is signedness-blind, so IMUL64
        // serves; high = the *unsigned* high half of that same product plus
        // the two cross terms, which is what MULH64 exists for. The canonical
        // emitter writes the same three multiplies.
        u32 product_high = machine_x64_select_constrained_row(selector, MACHINE_X64_MULH64, left_low, right_low);
        u32 cross_low_high = machine_x64_select_arithmetic_row(selector, MACHINE_X64_IMUL64, left_low, right_high);
        u32 cross_high_low = machine_x64_select_arithmetic_row(selector, MACHINE_X64_IMUL64, left_high, right_low);
        u32 sum = machine_x64_select_arithmetic_row(selector, MACHINE_X64_ADD64, product_high, cross_low_high);
        machine_x64_select_frame_store64(selector, result_slot, 0, machine_x64_select_arithmetic_row(selector, MACHINE_X64_IMUL64, left_low, right_low));
        machine_x64_select_frame_store64(selector, result_slot, 8, machine_x64_select_arithmetic_row(selector, MACHINE_X64_ADD64, sum, cross_high_low));
        selected = true;
    }
    else if ((operation == IR_BINARY_INTEGER_EQUAL || operation == IR_BINARY_INTEGER_NOT_EQUAL) && result_register != UINT32_MAX &&
             machine_x64_select_i128_halves(selector, instruction, &left_low, &left_high, &right_low, &right_high))
    {
        u32 low_difference = machine_x64_select_arithmetic_row(selector, MACHINE_X64_XOR64, left_low, right_low);
        u32 high_difference = machine_x64_select_arithmetic_row(selector, MACHINE_X64_XOR64, left_high, right_high);
        u32 any_difference = machine_x64_select_arithmetic_row(selector, MACHINE_X64_OR64, low_difference, high_difference);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, any_difference),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, machine_x64_select_immediate_register(selector, 0))},
                                             .opcode = MACHINE_X64_CMP64,
                                         });
        u32 row = machine_x64_select_row(
            selector, (MachineInstruction){
                          .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                          .payload = operation == IR_BINARY_INTEGER_EQUAL ? MACHINE_X64_CONDITION_EQUAL : MACHINE_X64_CONDITION_NOT_EQUAL,
                          .opcode = MACHINE_X64_SETCC,
                      });
        machine_x64_define(selector, result_register, row);
        selected = true;
    }
    else if ((operation == IR_BINARY_SIGNED_LESS || operation == IR_BINARY_SIGNED_LESS_EQUAL || operation == IR_BINARY_SIGNED_GREATER ||
              operation == IR_BINARY_SIGNED_GREATER_EQUAL || operation == IR_BINARY_UNSIGNED_LESS || operation == IR_BINARY_UNSIGNED_LESS_EQUAL ||
              operation == IR_BINARY_UNSIGNED_GREATER || operation == IR_BINARY_UNSIGNED_GREATER_EQUAL) &&
             result_register != UINT32_MAX && machine_x64_select_i128_halves(selector, instruction, &left_low, &left_high, &right_low, &right_high))
    {
        // The high halves decide with the signed or unsigned strict relation;
        // only exactly equal high halves defer to the low halves, which always
        // compare unsigned.
        bool less_directed = operation == IR_BINARY_SIGNED_LESS || operation == IR_BINARY_SIGNED_LESS_EQUAL || operation == IR_BINARY_UNSIGNED_LESS ||
                             operation == IR_BINARY_UNSIGNED_LESS_EQUAL;
        bool signed_compare = operation == IR_BINARY_SIGNED_LESS || operation == IR_BINARY_SIGNED_LESS_EQUAL || operation == IR_BINARY_SIGNED_GREATER ||
                              operation == IR_BINARY_SIGNED_GREATER_EQUAL;
        bool or_equal = operation == IR_BINARY_SIGNED_LESS_EQUAL || operation == IR_BINARY_UNSIGNED_LESS_EQUAL ||
                        operation == IR_BINARY_SIGNED_GREATER_EQUAL || operation == IR_BINARY_UNSIGNED_GREATER_EQUAL;
        u32 high_condition = signed_compare ? (less_directed ? MACHINE_X64_CONDITION_LESS : MACHINE_X64_CONDITION_GREATER)
                                            : (less_directed ? MACHINE_X64_CONDITION_BELOW : MACHINE_X64_CONDITION_ABOVE);
        u32 low_condition = less_directed ? (or_equal ? MACHINE_X64_CONDITION_BELOW_EQUAL : MACHINE_X64_CONDITION_BELOW)
                                          : (or_equal ? MACHINE_X64_CONDITION_ABOVE_EQUAL : MACHINE_X64_CONDITION_ABOVE);
        u32 high_decides = machine_x64_select_compare_set(selector, left_high, right_high, high_condition);
        u32 high_equal = machine_x64_select_compare_set(selector, left_high, right_high, MACHINE_X64_CONDITION_EQUAL);
        u32 low_decides = machine_x64_select_compare_set(selector, left_low, right_low, low_condition);
        u32 deferred = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, high_equal, low_decides);
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, high_decides),
                                                                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, deferred)},
                                                       .opcode = MACHINE_X64_OR64,
                                                   });
        machine_x64_define(selector, result_register, row);
        selected = true;
    }
    return selected;
}

// A scalar lane expansion consumes an explicit snapshot of a native ZMM
// value. Existing frame-backed vectors keep their owned storage. The native
// EVEX selector still handles its encodable operations before this path.
BUSTER_GLOBAL_LOCAL u32 machine_x64_select_vector_snapshot(MachineX64Selector* selector, IrValueId value, IrType* vector)
{
    u32 slot = value.value < selector->function->value_count ? selector->value_stack_slots[value.value] : UINT32_MAX;
    u32 value_register = value.value < selector->function->value_count ? selector->value_virtual_registers[value.value] : UINT32_MAX;
    if (slot == UINT32_MAX && value_register != UINT32_MAX && machine_x64_type_is_vector_register(selector->program, vector) && selector->vector_registers_supported)
    {
        slot = machine_x64_append_slot(selector, 64, 16);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot), machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
            .opcode = MACHINE_X64_VSTORE_FRAME,
        });
    }
    return slot;
}

// Exact-width lane loads never read past the vector's slot. Signed narrow
// lanes extend before division, remainder, comparisons, and arithmetic shifts.
BUSTER_GLOBAL_LOCAL u32 machine_x64_select_vector_lane_load(MachineX64Selector* selector, u32 slot, u32 offset, IrType* element)
{
    u32 address = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address),
                                                      machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
                                         .payload = offset,
                                         .opcode = MACHINE_X64_LEA_FRAME,
                                     });
    u32 value = machine_x64_synthesize_register(selector);
    u16 load = element->bit_width == 8   ? MACHINE_X64_LOAD_PTR8
               : element->bit_width == 16 ? MACHINE_X64_LOAD_PTR16
               : element->bit_width == 32 ? MACHINE_X64_LOAD_PTR32
                                          : MACHINE_X64_LOAD_PTR64;
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value),
                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address)},
                                         .opcode = load,
                                     });
    if (element->kind == IR_TYPE_INTEGER && element->is_signed && element->bit_width < 32)
    {
        u32 extended = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, extended),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value)},
                                             .opcode = (u16)(element->bit_width == 8 ? MACHINE_X64_MOVSX8_RR : MACHINE_X64_MOVSX16_RR),
                                         });
        value = extended;
    }
    return value;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_vector_lanes(MachineX64Selector* selector, IrInstruction* instruction, IrType* vector)
{
    IrFunction* function = selector->function;
    IrType* element = ir_type_from_id(&selector->program->types, vector->element_type);
    bool unary = instruction->opcode == IR_OPCODE_UNARY;
    u32 left_slot = machine_x64_select_vector_snapshot(selector, instruction->operands[0], vector);
    u32 right_slot = unary ? UINT32_MAX : machine_x64_select_vector_snapshot(selector, instruction->operands[1], vector);
    u32 result_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
    bool register_result = result_slot == UINT32_MAX && instruction->result.value < function->value_count &&
                           selector->value_virtual_registers[instruction->result.value] != UINT32_MAX &&
                           machine_x64_type_is_vector_register(selector->program, vector) && selector->vector_registers_supported;
    if (register_result)
    {
        result_slot = machine_x64_append_slot(selector, 64, 16);
    }
    bool selected = element && ((element->kind == IR_TYPE_INTEGER &&
                                 (element->bit_width == 8 || element->bit_width == 16 || element->bit_width == 32 || element->bit_width == 64)) ||
                                (element->kind == IR_TYPE_FLOAT && (element->bit_width == 32 || element->bit_width == 64))) &&
                    vector->layout.resolved && vector->layout.size <= INT32_MAX && vector->element_count &&
                    vector->element_count <= UINT64_MAX / (element->bit_width / 8) &&
                    (u64)(element->bit_width / 8) * vector->element_count <= vector->layout.size &&
                    left_slot != UINT32_MAX && (unary || right_slot != UINT32_MAX) && result_slot != UINT32_MAX;
    u8 operation = IR_BINARY_COUNT;
    if (selected && !unary)
    {
        static u8 const scalar_operations[] = {
            IR_BINARY_INTEGER_ADD, IR_BINARY_INTEGER_SUBTRACT, IR_BINARY_INTEGER_MULTIPLY,
            IR_BINARY_SIGNED_DIVIDE, IR_BINARY_UNSIGNED_DIVIDE,
            IR_BINARY_FLOAT_ADD, IR_BINARY_FLOAT_SUBTRACT, IR_BINARY_FLOAT_MULTIPLY, IR_BINARY_FLOAT_DIVIDE,
            IR_BINARY_SIGNED_REMAINDER, IR_BINARY_UNSIGNED_REMAINDER,
            IR_BINARY_SHIFT_LEFT, IR_BINARY_SIGNED_SHIFT_RIGHT, IR_BINARY_UNSIGNED_SHIFT_RIGHT,
            IR_BINARY_INTEGER_BITWISE_AND, IR_BINARY_INTEGER_BITWISE_OR, IR_BINARY_INTEGER_BITWISE_XOR,
            IR_BINARY_INTEGER_EQUAL, IR_BINARY_INTEGER_NOT_EQUAL,
            IR_BINARY_SIGNED_LESS, IR_BINARY_SIGNED_LESS_EQUAL, IR_BINARY_SIGNED_GREATER, IR_BINARY_SIGNED_GREATER_EQUAL,
            IR_BINARY_UNSIGNED_LESS, IR_BINARY_UNSIGNED_LESS_EQUAL, IR_BINARY_UNSIGNED_GREATER, IR_BINARY_UNSIGNED_GREATER_EQUAL,
            IR_BINARY_FLOAT_EQUAL, IR_BINARY_FLOAT_NOT_EQUAL, IR_BINARY_FLOAT_LESS, IR_BINARY_FLOAT_LESS_EQUAL,
            IR_BINARY_FLOAT_GREATER, IR_BINARY_FLOAT_GREATER_EQUAL,
        };
        BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(scalar_operations) == IR_BINARY_VECTOR_FLOAT_GREATER_EQUAL - IR_BINARY_VECTOR_INTEGER_ADD + 1);
        u32 index = (u32)instruction->binary_operation - IR_BINARY_VECTOR_INTEGER_ADD;
        selected = index < BUSTER_ARRAY_LENGTH(scalar_operations);
        if (selected)
        {
            operation = scalar_operations[index];
        }
    }
    IrInstruction scalar = {.binary_operation = operation};
    for (u32 lane = 0; selected && lane < vector->element_count; lane += 1)
    {
        u32 offset = lane * (element->bit_width / 8);
        u32 left = machine_x64_select_vector_lane_load(selector, left_slot, offset, element);
        u32 result_register = UINT32_MAX;
        bool wide = element->bit_width == 64;
        if (unary)
        {
            bool negate = instruction->unary_operation == IR_UNARY_VECTOR_INTEGER_NEGATE;
            bool invert = instruction->unary_operation == IR_UNARY_VECTOR_INTEGER_BITWISE_NOT;
            bool float_negate = instruction->unary_operation == IR_UNARY_VECTOR_FLOAT_NEGATE;
            selected = ((negate || invert) && element->kind == IR_TYPE_INTEGER) || (float_negate && element->kind == IR_TYPE_FLOAT);
            if (selected)
            {
                u64 constant_bits = float_negate ? (wide ? UINT64_C(0x8000000000000000) : UINT64_C(0x80000000))
                                                : negate ? 0 : UINT64_MAX;
                u32 constant = machine_x64_select_immediate_register(selector, constant_bits);
                u16 opcode = negate ? (wide ? MACHINE_X64_SUB64 : MACHINE_X64_SUB32) : (wide ? MACHINE_X64_XOR64 : MACHINE_X64_XOR32);
                result_register = machine_x64_select_arithmetic_row(selector, opcode,
                    negate ? constant : left, negate ? left : constant);
            }
        }
        else
        {
            u32 right = machine_x64_select_vector_lane_load(selector, right_slot, offset, element);
            result_register = machine_x64_synthesize_register(selector);
            MachineVirtualRegister* result_record = selector->builder.virtual_register_cursor - 1;
            u32 definition_row = selector->builder.instructions.total_count;
            bool integer_comparison = element->kind == IR_TYPE_INTEGER && machine_x64_condition_from_comparison(operation) != 0;
            selected = element->kind == IR_TYPE_FLOAT
                ? machine_x64_select_float_binary(selector, &scalar, element, left, right, result_register)
                : machine_x64_select_scalar_binary(selector, &scalar, wide, left, right, result_register);
            if (selected)
            {
                // Integer comparisons emit CMP before their defining SETCC.
                // Constrained shifts/divides define at their initial MOV.
                result_record->definition_point = machine_point_make(definition_row + (integer_comparison ? 1u : 0u), MACHINE_POINT_AFTER);
            }
        }
        if (selected && !unary && instruction->binary_operation >= IR_BINARY_VECTOR_INTEGER_EQUAL)
        {
            // C vector comparisons return an all-ones lane for true.
            u32 zero = machine_x64_select_immediate_register(selector, 0);
            result_register = machine_x64_select_arithmetic_row(selector, wide ? MACHINE_X64_SUB64 : MACHINE_X64_SUB32,
                                                               zero, result_register);
        }
        if (selected)
        {
            u16 store = element->bit_width == 8   ? MACHINE_X64_STORE_FRAME8
                        : element->bit_width == 16 ? MACHINE_X64_STORE_FRAME16
                        : element->bit_width == 32 ? MACHINE_X64_STORE_FRAME32
                                                   : MACHINE_X64_STORE_FRAME64;
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                 .payload = offset,
                                                 .opcode = store,
                                             });
        }
    }
    if (selected && register_result)
    {
        u32 result_register = selector->value_virtual_registers[instruction->result.value];
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register), machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot)},
            .opcode = MACHINE_X64_VLOAD_FRAME,
        });
        machine_x64_define(selector, result_register, row);
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_binary(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    bool selected = false;
    u32 success_register = machine_x64_atomic_success_source(selector, instruction);
    u32 left_register = UINT32_MAX;
    u32 right_register = UINT32_MAX;
    if (result_register != UINT32_MAX && success_register != UINT32_MAX)
    {
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, success_register)},
                                                       .opcode = MACHINE_X64_MOV_RR,
                                                   });
        machine_x64_define(selector, result_register, row);
        selected = true;
    }
    else if (machine_x64_type_is_f80(selector, function->values[instruction->operands[0].value].canonical_type))
    {
        selected = machine_x64_select_f80_binary(selector, instruction, result_register);
    }
    else if (machine_x64_binary_is_i128(selector, instruction))
    {
        // i128 operands are slot-backed with no operand register, so the
        // register path below cannot see them at all: anything this subset
        // refuses refuses here and rides the canonical emitter.
        selected = machine_x64_select_i128_binary(selector, instruction, result_register);
    }
    else if (result_register != UINT32_MAX && machine_x64_operand_register(selector, instruction->operands[0], &left_register) &&
             machine_x64_operand_register(selector, instruction->operands[1], &right_register))
    {
        IrTypeId operand_type_id = function->values[instruction->operands[0].value].canonical_type;
        MachineTypeClass operand_class = machine_x64_type_class(selector, operand_type_id);
        if (operand_class.kind == IR_TYPE_VECTOR)
        {
            selected = machine_x64_select_vector_binary(selector, instruction, ir_type_from_id(&program->types, operand_type_id), left_register,
                                                        right_register, result_register);
        }
        else if (operand_class.kind == IR_TYPE_FLOAT)
        {
            selected = machine_x64_select_float_binary(selector, instruction, ir_type_from_id(&program->types, operand_type_id), left_register,
                                                       right_register, result_register);
        }
        else if (operand_class.flags & MACHINE_TYPE_CLASS_SCALAR_REGISTER)
        {
            selected = machine_x64_select_scalar_binary(selector, instruction, (operand_class.flags & MACHINE_TYPE_CLASS_WIDE) != 0, left_register,
                                                        right_register, result_register);
        }
    }
    if (!selected)
    {
        IrType* operand_type = ir_type_from_id(&program->types, function->values[instruction->operands[0].value].canonical_type);
        if (operand_type && operand_type->kind == IR_TYPE_VECTOR)
        {
            selected = machine_x64_select_vector_lanes(selector, instruction, operand_type);
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_dereference(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    bool selected = false;
    u32 source_register;
    if (result_register != UINT32_MAX && machine_x64_operand_register(selector, instruction->operands[0], &source_register))
    {
        // Aliased through the pointer chain: the dereference is a
        // name for the promoted local, not code.
        if (result_register != source_register)
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                           .opcode = MACHINE_X64_MOV_RR,
                                                       });
            machine_x64_define(selector, result_register, row);
        }
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_global_address(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrProgram* program = selector->program;

    bool selected = false;
    IrSymbol* symbol = ir_symbol_from_id(&program->symbols, instruction->symbol);
    bool darwin = selector->target.os == OPERATING_SYSTEM_MACOS || selector->target.os == OPERATING_SYSTEM_IOS;
    bool windows = selector->target.os == OPERATING_SYSTEM_WINDOWS;
    bool thread_local_supported = symbol && (!symbol->is_thread_local || darwin || windows ||
        selector->target.os == OPERATING_SYSTEM_LINUX || selector->target.os == OPERATING_SYSTEM_ANDROID);
    if (result_register != UINT32_MAX && thread_local_supported)
    {
        // A thread-local address is the loader's to compute whatever the code
        // model is, and the model below says how; the reference form is about
        // the ordinary global, whose definition another object could replace.
        u8 reference =
            symbol->is_thread_local ? (u8)MACHINE_SYMBOL_REFERENCE_DIRECT : machine_x64_symbol_reference(selector, instruction->symbol, false);
        u32 target_index = machine_x64_call_target(selector, instruction->symbol, reference);
        CodegenThreadLocalModel model = symbol->is_thread_local && !darwin && !windows
                                            ? codegen_thread_local_model(selector->position_independent, symbol->is_definition)
                                            : CODEGEN_THREAD_LOCAL_LOCAL_EXEC;
        bool descriptor_call = symbol->is_thread_local && darwin;
        if (model == CODEGEN_THREAD_LOCAL_GENERAL_DYNAMIC || descriptor_call)
        {
            // The address comes back from __tls_get_addr in RAX, so this
            // reads exactly like a direct call: the call row itself defines
            // nothing the allocator names, and a move off the physical
            // result register is what the value is defined by.
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .payload = target_index,
                                                 .opcode = (u16)(descriptor_call ? MACHINE_X64_TLS_DARWIN : MACHINE_X64_TLS_GENERAL_DYNAMIC),
                                             });
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)},
                                                           .opcode = MACHINE_X64_MOV_RR,
                                                       });
            machine_x64_define(selector, result_register, row);
        }
        else
        {
            u16 address_opcode = (u16)(!symbol->is_thread_local
                                           ? (reference == MACHINE_SYMBOL_REFERENCE_GOT ? MACHINE_X64_LOAD_SYMBOL_GOT : MACHINE_X64_LEA_SYMBOL)
                                       : windows ? MACHINE_X64_TLS_WINDOWS
                                       : model == CODEGEN_THREAD_LOCAL_INITIAL_EXEC ? MACHINE_X64_LEA_TLS_INITIAL_EXEC
                                                                                    : MACHINE_X64_LEA_TLS);
            u32 row = machine_x64_select_row(selector,
                                             (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                 .payload = target_index,
                                                 .opcode = address_opcode,
                                             });
            machine_x64_define(selector, result_register, row);
        }
        selected = true;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_address_of(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    return result_register != UINT32_MAX && machine_x64_select_place_address(selector, instruction->operands[0], result_register);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_field(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    MachineSelectionAddress address = machine_x64_address(selector, instruction->result);
    bool selected = false;
    if (result_register != UINT32_MAX && (address.flags & MACHINE_SELECTION_ADDRESS_FIELD) && address.field_offset <= INT32_MAX)
    {
        selected = machine_x64_select_place_address_offset(selector, instruction->operands[0], result_register, (u32)address.field_offset);
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_debug_trap(MachineX64Selector* selector)
{
    machine_x64_select_row(selector, (MachineInstruction){.opcode = MACHINE_X64_INT3});
    return true;
}

// Bit-field members of one storage unit accumulate in a register — mask to
// width, shift to position via a power-of-two multiply, or together — and the
// unit stores once. The register starts from the unit's current bytes rather
// than from zero, because a unit is not the initializer's alone: packing
// slides it back over an ordinary member and can leave two units sharing a
// byte, and a whole-unit store of an accumulator seeded with zero overwrites
// whichever of those the loop reached first. Merging is sound because the slot
// is zero-filled before any member and every bit belongs to exactly one of
// them — the same read-modify-write the canonical emitter spells as OR into
// memory.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_bit_field_unit(MachineX64Selector* selector, IrInstruction* instruction, IrType* type, u32 slot, u32 first,
                                                           u64 field_offset, u64 field_size, u8* member_emitted)
{
    IrFieldAccessPiece pieces[IR_FIELD_ACCESS_PIECE_CAPACITY];
    u32 piece_count = ir_field_access_pieces(field_size, pieces);
    bool selected = piece_count != 0;
    // Packed units may span 3, 5, 6, 7, or 9 bytes. Each legal access merges
    // only its intersection with each sibling, preserving adjacent members.
    // Ordinary units still accumulate all siblings and store just once.
    for (u32 piece_index = 0; piece_index < piece_count && selected; piece_index += 1)
    {
        u32 piece_low = (u32)pieces[piece_index].offset * 8;
        u32 piece_high = piece_low + (u32)pieces[piece_index].size * 8;
        u32 piece_offset = (u32)(field_offset + pieces[piece_index].offset);
        u16 load_opcode = pieces[piece_index].size == 1   ? MACHINE_X64_LOAD_PTR8
                          : pieces[piece_index].size == 2 ? MACHINE_X64_LOAD_PTR16
                          : pieces[piece_index].size == 4 ? MACHINE_X64_LOAD_PTR32
                                                         : MACHINE_X64_LOAD_PTR64;
        u16 store_opcode = pieces[piece_index].size == 1   ? MACHINE_X64_STORE_FRAME8
                           : pieces[piece_index].size == 2 ? MACHINE_X64_STORE_FRAME16
                           : pieces[piece_index].size == 4 ? MACHINE_X64_STORE_FRAME32
                                                          : MACHINE_X64_STORE_FRAME64;
        u32 unit_address = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, unit_address),
                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
                                             .payload = piece_offset,
                                             .opcode = MACHINE_X64_LEA_FRAME,
                                         });
        u32 unit_register = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, unit_register),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, unit_address)},
                                             .opcode = load_opcode,
                                         });
        for (u32 sibling = first; sibling < instruction->operand_count && selected; sibling += 1)
        {
            u64 sibling_field = instruction->immediates[sibling];
            if (!member_emitted[sibling] && sibling_field < type->field_count && type->fields[sibling_field].is_bit_field &&
                type->fields[sibling_field].bit_width && type->fields[sibling_field].offset == field_offset &&
                ir_field_access_size(&selector->program->types, type->fields + sibling_field) == field_size)
            {
                u32 bit_offset = type->fields[sibling_field].bit_offset;
                u32 bit_width = type->fields[sibling_field].bit_width;
                selected = bit_width <= 64 && (u64)bit_offset + bit_width <= field_size * 8;
                u32 low = BUSTER_MAX(piece_low, bit_offset);
                u32 high = BUSTER_MIN(piece_high, bit_offset + bit_width);
                if (selected && low < high)
                {
                    u32 value_register;
                    selected = machine_x64_operand_register(selector, instruction->operands[sibling], &value_register);
                    if (selected)
                    {
                        u32 masked_register = machine_x64_synthesize_register(selector);
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, masked_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                             .opcode = MACHINE_X64_MOV_RR,
                                                         });
                        if (low > bit_offset)
                        {
                            u32 count_register = machine_x64_select_immediate_register(selector, low - bit_offset);
                            machine_x64_select_row(selector, (MachineInstruction){
                                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, masked_register),
                                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, count_register)},
                                                                 .opcode = MACHINE_X64_SHR64,
                                                             });
                        }
                        u32 mask_register = machine_x64_select_immediate_register(selector, high - low == 64 ? UINT64_MAX : (((u64)1 << (high - low)) - 1));
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, masked_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, masked_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask_register)},
                                                             .opcode = MACHINE_X64_AND64,
                                                         });
                        if (low > piece_low)
                        {
                            u32 scale_register = machine_x64_select_immediate_register(selector, (u64)1 << (low - piece_low));
                            machine_x64_select_row(selector, (MachineInstruction){
                                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, masked_register),
                                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, masked_register),
                                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, scale_register)},
                                                                 .opcode = MACHINE_X64_IMUL64,
                                                             });
                        }
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, unit_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, unit_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, masked_register)},
                                                             .opcode = MACHINE_X64_OR64,
                                                         });
                    }
                }
                // Keep the siblings available until every piece has consumed
                // them; the outer initializer loop must then skip them all.
                if (selected && piece_index + 1 == piece_count)
                {
                    member_emitted[sibling] = 1;
                }
            }
        }
        if (selected)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, unit_register)},
                                                 .payload = piece_offset,
                                                 .opcode = store_opcode,
                                             });
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_aggregate(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    // Field-by-field construction into the value's slot, mirroring the
    // canonical path: scalar members store sized at their offsets,
    // aggregate members copy from their own slots through the field's
    // address.
    bool selected = true;
    IrType* type = ir_type_from_id(&program->types, function->values[instruction->result.value].canonical_type);
    u32 slot = selector->value_stack_slots[instruction->result.value];
    bool shaped = type && (type->kind == IR_TYPE_STRUCT || type->kind == IR_TYPE_UNION) && slot != UINT32_MAX &&
                  instruction->immediate_count == instruction->operand_count && (!instruction->operand_count || instruction->immediates) &&
                  type->layout.resolved && type->layout.size <= INT32_MAX;
    if (!shaped)
    {
        selected = false;
    }
    else
    {
        // The operands need not cover the object — a union initializes only
        // one member, and padding is never an operand — so the whole slot is
        // zero-filled first, exactly like the canonical path.
        u32 zero_register = machine_x64_synthesize_register(selector);
        u32 zero_fill_immediate = machine_x64_append_immediate(selector, 0);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, zero_register),
                                                          machine_ref_make(MACHINE_REF_IMMEDIATE, zero_fill_immediate)},
                                             .opcode = MACHINE_X64_MOV_RI,
                                         });
        u64 zero_filled = 0;
        while (zero_filled < type->layout.size)
        {
            u64 zero_remaining = type->layout.size - zero_filled;
            u32 zero_chunk = zero_remaining >= 8 ? 8 : zero_remaining >= 4 ? 4 : zero_remaining >= 2 ? 2 : 1;
            u16 zero_store_opcode = zero_chunk == 1   ? MACHINE_X64_STORE_FRAME8
                                    : zero_chunk == 2 ? MACHINE_X64_STORE_FRAME16
                                    : zero_chunk == 4 ? MACHINE_X64_STORE_FRAME32
                                                      : MACHINE_X64_STORE_FRAME64;
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, zero_register)},
                                                 .payload = (u32)zero_filled,
                                                 .opcode = zero_store_opcode,
                                             });
            zero_filled += zero_chunk;
        }
        u8* member_emitted = arena_allocate(selector->arena, u8, instruction->operand_count ? instruction->operand_count : 1);
        for (u32 index = 0; index < instruction->operand_count; index += 1)
        {
            member_emitted[index] = 0;
        }
        for (u32 index = 0; index < instruction->operand_count && selected; index += 1)
        {
            u64 field_index = instruction->immediates[index];
            if (field_index >= type->field_count)
            {
                selected = false;
            }
            else if (type->fields[field_index].is_bit_field && !type->fields[field_index].bit_width)
            {
                // Zero-width separators affect layout but store no bits.
                member_emitted[index] = 1;
            }
            else if (!member_emitted[index])
            {
                u64 field_offset = type->fields[field_index].offset;
                // The unit a member is written through: a bit-field packing
                // left no room for a declared-type unit of carries a narrower
                // one, and every other field reads its own size back.
                u64 field_size = ir_field_access_size(&program->types, type->fields + field_index);
                if (!field_size || field_offset > INT32_MAX)
                {
                    selected = false;
                }
                else if (!type->fields[field_index].is_bit_field)
                {
                    selected = machine_x64_select_member_write(selector, slot, field_offset, field_size, instruction->operands[index]);
                    if (selected)
                    {
                        member_emitted[index] = 1;
                    }
                }
                else
                {
                    selected = machine_x64_select_bit_field_unit(selector, instruction, type, slot, index, field_offset, field_size, member_emitted);
                }
            }
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_array(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    // Element-by-element construction into the value's slot at scaled
    // offsets; the frontend materializes every element including the
    // zero tail, so position times element size covers the object.
    bool selected = false;
    IrType* type = ir_type_from_id(&program->types, function->values[instruction->result.value].canonical_type);
    u32 slot = selector->value_stack_slots[instruction->result.value];
    u32 result_register = selector->value_virtual_registers[instruction->result.value];
    bool vector = selector->vector_registers_supported && machine_x64_type_is_vector_register(selector->program, type) && result_register != UINT32_MAX;
    if (vector)
    {
        // A vector literal uses the same canonical element constructor as an
        // array. Stage its complete lanes into memory, then define its ZMM value.
        slot = machine_x64_append_slot(selector, 64, 16);
    }
    if (type && (type->kind == IR_TYPE_ARRAY || type->kind == IR_TYPE_VECTOR) && slot != UINT32_MAX)
    {
        IrType* element_type = ir_type_from_id(&program->types, type->element_type);
        u64 element_size = element_type && element_type->layout.resolved ? element_type->layout.size : 0;
        u64 byte_size = (u64)instruction->operand_count * element_size;
        if (element_size && byte_size <= INT32_MAX && (!vector || byte_size == 64))
        {
            selected = true;
            for (u32 index = 0; index < instruction->operand_count && selected; index += 1)
            {
                selected = machine_x64_select_member_write(selector, slot, (u64)index * element_size, element_size, instruction->operands[index]);
            }
        }
    }
    if (selected && vector)
    {
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register), machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
            .opcode = MACHINE_X64_VLOAD_FRAME,
        });
        machine_x64_define(selector, result_register, row);
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_index(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    MachineSelectionAddress address = machine_x64_address(selector, instruction->result);

    bool selected = false;
    u32 index_register;
    if (result_register != UINT32_MAX && instruction->operand_count >= 2 &&
        machine_x64_operand_register(selector, instruction->operands[1], &index_register))
    {
        bool typed = (address.flags & MACHINE_SELECTION_ADDRESS_INDEX) && address.scale <= INT32_MAX;
        // The index extend resolves before the base address: an unsupported
        // index width then fails without emitting rows the rejection would
        // throw away anyway.
        u16 extend_opcode = MACHINE_X64_MOV_RR;
        if (typed && (address.flags & MACHINE_SELECTION_ADDRESS_INDEX_SIGNED))
        {
            u32 index_bits = address.index_bit_width;
            if (index_bits < 64)
            {
                extend_opcode = (u16)(index_bits == 8 ? MACHINE_X64_MOVSX8_RR : index_bits == 16 ? MACHINE_X64_MOVSX16_RR
                                      : index_bits == 32 ? MACHINE_X64_MOVSX32_RR : 0);
            }
        }
                if (typed && extend_opcode && machine_x64_select_place_address(selector, instruction->operands[0], result_register))
                {
                // The scaled index is computed in a synthesized temporary so the
                // read-modify-write multiply never touches the index value's slot.
                u32 scaled_register = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, scaled_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, index_register)},
                                                 .opcode = extend_opcode,
                                             });
            if (address.scale != 1)
            {
                // The element size folds into the multiply the same way.
                u32 immediate_index = machine_x64_append_immediate(selector, address.scale);
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, scaled_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, scaled_register),
                                                                  machine_ref_make(MACHINE_REF_IMMEDIATE, immediate_index)},
                                                     .opcode = MACHINE_X64_IMUL64_RRI,
                                                 });
            }
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, scaled_register)},
                                                 .opcode = MACHINE_X64_ADD64,
                                             });
            selected = true;
        }
    }
    return selected;
}

// A place whose address has to be materialized in a register: an explicit
// pointer expression, or a local the classifier gave indirect storage.
BUSTER_GLOBAL_LOCAL bool machine_x64_place_is_addressed(MachineX64Selector* selector, IrValueId place, u8 place_kind)
{
    return place_kind == MACHINE_X64_PLACE_ADDRESSED || machine_x64_local_is_indirect(selector, place);
}

// The virtual register a direct local was promoted into, or UINT32_MAX when the
// local lives in a frame slot instead.
BUSTER_GLOBAL_LOCAL u32 machine_x64_promoted_local_register(MachineX64Selector* selector, IrValueId place, u8 place_kind)
{
    u32 promoted = UINT32_MAX;
    if (place_kind == MACHINE_X64_PLACE_LOCAL && !machine_x64_local_is_indirect(selector, place))
    {
        promoted = selector->value_virtual_registers[place.value];
    }
    return promoted;
}

// The place kind a defining row gives its result.
BUSTER_GLOBAL_LOCAL MachineX64PlaceKind machine_x64_place_kind_of_opcode(u32 opcode)
{
    MachineX64PlaceKind result;
    switch (opcode)
    {
    case IR_OPCODE_LOCAL:
        result = MACHINE_X64_PLACE_LOCAL;
        break;
    case IR_OPCODE_DEREFERENCE:
    case IR_OPCODE_GLOBAL:
    case IR_OPCODE_INDEX:
    case IR_OPCODE_FIELD:
        result = MACHINE_X64_PLACE_ADDRESSED;
        break;
    case IR_OPCODE_FUNCTION:
        result = MACHINE_X64_PLACE_FUNCTION;
        break;
    default:
        result = MACHINE_X64_PLACE_OTHER;
        break;
    }
    return result;
}

// Aligned x86 loads are already atomic; the atomic form only excludes the
// aggregate and vector paths.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_load(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrFunction* function = selector->function;

    bool selected = false;

    IrValueId value_id = instruction->operands[0];
    IrIdUnderlying index = value_id.value;

    bool value_valid = (index < function->value_count) & (instruction->result.value != IR_ID_UNDERLYING_INVALID);
    if (value_valid)
    {
        u8 place_kind = selector->place_kinds[index];

        if (place_kind != MACHINE_X64_PLACE_NONE)
        {
            IrProgram* program = selector->program;

            u32 slot = selector->value_stack_slots[index];
            u32 result_slot = selector->value_stack_slots[instruction->result.value];
            MachineTypeClass loaded_class = machine_x64_type_class(selector, instruction->canonical_type);

            bool result_register_valid = result_register != UINT32_MAX;
            bool is_vector_load = result_register_valid & ((loaded_class.flags & MACHINE_TYPE_CLASS_VECTOR_REGISTER) != 0);
            bool is_scalar_load = !is_vector_load & result_register_valid;
            bool is_aggregate_load = !is_vector_load & !is_scalar_load & (result_slot != UINT32_MAX);
            bool splat_supported = selector->vector_registers_supported;

            bool register_load_supported = is_scalar_load |
                                           (is_vector_load & (instruction->opcode != IR_OPCODE_ATOMIC_LOAD) & splat_supported);
            if (register_load_supported)
            {
                // Whole-vector load into a ZMM-class register: a promoted vector local aliases
                // or copies, a slot-backed one loads from its frame home, and everything else
                // goes through an address vreg.

                // A promoted scalar local reads as a register, a direct local as a
                // frame load, and anything address-shaped as a sized pointer load.
                u32 operand_register = selector->value_virtual_registers[index];
                bool operand_register_valid = operand_register != UINT32_MAX;
                bool direct_local = place_kind == MACHINE_X64_PLACE_LOCAL;
                bool indirect_local = selector->value_indirect_slots[index] != UINT32_MAX;
                bool promoted_valid = direct_local & !indirect_local & operand_register_valid;
                bool local_slot_valid = direct_local & !indirect_local & !operand_register_valid & (slot != UINT32_MAX);
                bool place_is_addressed = indirect_local | (place_kind == MACHINE_X64_PLACE_ADDRESSED);
                bool pointer_valid = place_is_addressed & operand_register_valid;
                bool source_valid = promoted_valid | local_slot_valid | pointer_valid;
                bool select_and_define = source_valid & !(promoted_valid & (result_register == operand_register));

                selected = source_valid;

                if (select_and_define)
                {
                    BUSTER_CHECK(loaded_class.flags & MACHINE_TYPE_CLASS_RESOLVED);
                    // The class carries the size only when it is a power of two.
                    BUSTER_CHECK(loaded_class.size_log2 != MACHINE_TYPE_CLASS_NO_LOG2);

                    u32 size_log2 = loaded_class.size_log2;
                    u16 scalar_load_opcode = (u16)(MACHINE_X64_LOAD_PTR8 + size_log2);
                    BUSTER_CHECK(is_vector_load || (scalar_load_opcode >= MACHINE_X64_LOAD_PTR8 && scalar_load_opcode <= MACHINE_X64_LOAD_PTR64));
                    u16 pointer_opcode = is_vector_load ? MACHINE_X64_VLOAD_PTR : scalar_load_opcode;
                    u16 local_opcode = is_vector_load ? MACHINE_X64_VLOAD_FRAME : MACHINE_X64_LOAD_FRAME;
                    u16 promoted_opcode = is_vector_load ? MACHINE_X64_VMOV_RR : MACHINE_X64_MOV_RR;
                    u16 opcode = local_slot_valid ? local_opcode : pointer_opcode;
                    opcode = promoted_valid ? promoted_opcode : opcode;

                    MachineRef destination = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register);
                    u32 source_payload = local_slot_valid ? slot : operand_register;
                    MachineRefKind source_kind = local_slot_valid ? MACHINE_REF_STACK_SLOT : MACHINE_REF_VIRTUAL_REGISTER;
                    MachineRef source = machine_ref_make(source_kind, source_payload);
                    u32 row = machine_x64_select_row(selector, (MachineInstruction){ .operands = {destination, source}, .opcode = opcode });
                    machine_x64_define(selector, result_register, row);

                    // A frame load is deliberately a full eight-byte read so
                    // that every direct local uses one compact slot shape.
                    // Narrow objects (notably _Bool values written through a
                    // pointer) occupy only their declared byte width, though;
                    // reading the untouched upper bytes would let stale stack
                    // data escape as part of the scalar value.  Normalize the
                    // register after a direct frame load just as the pointer
                    // load forms do, preserving C's integer/boolean width.
                    u64 unsigned_narrow_opcodes = (u64)MACHINE_X64_MOVZX8_RR | ((u64)MACHINE_X64_MOVZX16_RR << 8) |
                                                  ((u64)MACHINE_X64_MOV32_RR << 16);
                    u64 signed_narrow_opcodes = (u64)MACHINE_X64_MOVSX8_RR | ((u64)MACHINE_X64_MOVSX16_RR << 8) |
                                                ((u64)MACHINE_X64_MOV32_RR << 16);
                    bool integer = loaded_class.kind == IR_TYPE_INTEGER;
                    bool narrow_scalar = integer | (loaded_class.kind == IR_TYPE_BOOLEAN);
                    u64 narrow_opcodes = (integer & ((loaded_class.flags & MACHINE_TYPE_CLASS_SIGNED) != 0)) ? signed_narrow_opcodes : unsigned_narrow_opcodes;
                    narrow_opcodes &= 0 - (u64)narrow_scalar;
                    u16 narrow_opcode = (u16)((narrow_opcodes >> (size_log2 * 8)) & UINT8_MAX);
                    bool normalize_frame_load = local_slot_valid & (narrow_opcode != 0);
                    if (normalize_frame_load)
                    {
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {destination, destination},
                                                             .opcode = narrow_opcode,
                                                         });
                    }

                }
            }
            else if (is_aggregate_load & (instruction->opcode == IR_OPCODE_ATOMIC_LOAD))
            {
                // An atomic aggregate loads through one sized integer access
                // whose width is the place's promoted size (#731), not the
                // loaded value's. The sized pointer load zero-extends, so
                // the full-slot store leaves the value's padding zero
                // exactly like the canonical path.
                BUSTER_CHECK(loaded_class.kind != IR_TYPE_COUNT);
                IrType* place_type = ir_type_from_id(&program->types, function->values[index].canonical_type);
                u64 atomic_width = place_type && place_type->layout.resolved ? place_type->layout.size : 0;
                u32 width_index = atomic_width == 1 ? 0 : atomic_width == 2 ? 1 : atomic_width == 4 ? 2 : atomic_width == 8 ? 3 : UINT32_MAX;
                bool aggregate_kind = loaded_class.kind == IR_TYPE_STRUCT || loaded_class.kind == IR_TYPE_UNION;
                IrType* loaded_type = ir_type_from_id(&program->types, instruction->canonical_type);
                u64 loaded_size = loaded_type && loaded_type->layout.resolved ? loaded_type->layout.size : 0;
                bool integer128 = loaded_class.kind == IR_TYPE_INTEGER && (loaded_class.flags & MACHINE_TYPE_CLASS_INTEGER128) != 0;
                if ((aggregate_kind || integer128) && atomic_width == 16 && loaded_size >= 9 && loaded_size <= 16 &&
                    target_cpu_feature_has(selector->target, TARGET_CPU_FEATURE_X86_CX16))
                {
                    u32 address_register = machine_x64_synthesize_register(selector);
                    selected = machine_x64_select_place_address(selector, value_id, address_register);
                    if (selected)
                    {
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register)},
                                                             .payload = (u32)loaded_size,
                                                             .opcode = MACHINE_X64_ATOMIC_LOAD16,
                                                         });
                    }
                }
                else if (aggregate_kind && width_index != UINT32_MAX)
                {
                    u32 address_register = machine_x64_synthesize_register(selector);
                    selected = machine_x64_select_place_address(selector, value_id, address_register);
                    if (selected)
                    {
                        u32 data_register = machine_x64_synthesize_register(selector);
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, data_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register)},
                                                             .opcode = (u16)(MACHINE_X64_LOAD_PTR8 + width_index),
                                                         });
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, data_register)},
                                                             .opcode = MACHINE_X64_STORE_FRAME64,
                                                         });
                    }
                }
            }
            else if (is_aggregate_load)
            {
                // An aggregate load is an exact-size chunk copy into the result slot,
                // from a direct local's slot or through an address vreg. The
                // record is fetched here for the copy's byte count.
                IrType* loaded_type = ir_type_from_id(&program->types, instruction->canonical_type);
                BUSTER_CHECK(loaded_type);
                bool aggregate_supported = loaded_type->layout.resolved & (loaded_type->layout.size <= UINT32_MAX);
                if (aggregate_supported)
                {
                    bool local_slot_valid = (place_kind == MACHINE_X64_PLACE_LOCAL) & (slot != UINT32_MAX);
                    bool place_is_addressed = machine_x64_place_is_addressed(selector, value_id, place_kind) & !local_slot_valid;

                    // machine_x64_operand_register writes the address vreg
                    // exactly when it reports one, so this flag both chooses
                    // the address-shaped source below and guards reading it;
                    // a frame-backed aggregate never reads it. The call stays
                    // unconditional: the helper only reads selector state and
                    // writes the output, and Clang's conditional-uninitialized
                    // analysis takes the unconditional out-parameter as the
                    // definition it cannot otherwise see through the flag.
                    u32 address_register;
                    bool address_register_selected = machine_x64_operand_register(selector, value_id, &address_register) & place_is_addressed;
                    selected = local_slot_valid | address_register_selected;

                    if (selected)
                    {
                        MachineRef destination = machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot);
                        u32 source_payload = address_register_selected ? address_register : slot;
                        MachineRefKind source_kind = address_register_selected ? MACHINE_REF_VIRTUAL_REGISTER : MACHINE_REF_STACK_SLOT;
                        MachineRef source = machine_ref_make(source_kind, source_payload);
                        u16 opcode = address_register_selected ? MACHINE_X64_COPY_FRAME_FROM_PTR : MACHINE_X64_COPY_FRAME_FROM_FRAME;

                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {destination, source},
                                                             .payload = machine_x64_type_is_f80(selector, instruction->canonical_type) ? 10u : (u32)loaded_type->layout.size,
                                                             .opcode = opcode,
                                                         });
                    }
                }
            }
        }
    }

    return selected;
}

// Sequentially consistent stores exchange, exactly like the canonical path;
// weaker orders are plain x86 stores.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_sequential_atomic_store(MachineX64Selector* selector, IrInstruction* instruction, u64 size)
{
    bool selected = false;
    u32 atomic_value_register;
    if (machine_x64_operand_register(selector, instruction->operands[1], &atomic_value_register) &&
        (size == 1 || size == 2 || size == 4 || size == 8))
    {
        u32 address_register = machine_x64_synthesize_register(selector);
        selected = machine_x64_select_place_address(selector, instruction->operands[0], address_register);
        if (selected)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, atomic_value_register)},
                                                 .payload = (u32)size,
                                                 .opcode = MACHINE_X64_ATOMIC_STORE_XCHG,
                                             });
        }
    }
    return selected;
}

// The aggregate form of a store: an exact-size chunk copy out of the value
// slot, into a direct local's slot or through an address vreg.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_aggregate_store(MachineX64Selector* selector, IrInstruction* instruction, u8 place_kind, u64 size, u32 slot,
                                                            u32 value_slot)
{
    bool selected = false;
    if (instruction->opcode != IR_OPCODE_ATOMIC_STORE && size && size <= UINT32_MAX)
    {
        if (place_kind == MACHINE_X64_PLACE_LOCAL && slot != UINT32_MAX)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                              machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot)},
                                                 .payload = (u32)size,
                                                 .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME,
                                             });
            selected = true;
        }
        else if (machine_x64_place_is_addressed(selector, instruction->operands[0], place_kind))
        {
            u32 address_register;
            selected = machine_x64_operand_register(selector, instruction->operands[0], &address_register);
            if (selected)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                                                                  machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot)},
                                                     .payload = (u32)size,
                                                     .opcode = MACHINE_X64_COPY_PTR_FROM_FRAME,
                                                 });
            }
        }
    }
    return selected;
}

// Whole-vector store out of a ZMM-class register: a promoted vector local takes
// a full 512-bit register copy, a slot-backed one stores to its frame home, and
// everything else goes through an address vreg.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_vector_store(MachineX64Selector* selector, IrInstruction* instruction, u8 place_kind, u32 slot,
                                                         u32 value_register)
{
    bool selected = false;
    u32 place_register = machine_x64_promoted_local_register(selector, instruction->operands[0], place_kind);
    if (instruction->opcode != IR_OPCODE_ATOMIC_STORE && selector->vector_registers_supported)
    {
        if (place_register != UINT32_MAX)
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, place_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                           .opcode = MACHINE_X64_VMOV_RR,
                                                       });
            machine_x64_define(selector, place_register, row);
            selected = true;
        }
        else if (place_kind == MACHINE_X64_PLACE_LOCAL && slot != UINT32_MAX)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                 .opcode = MACHINE_X64_VSTORE_FRAME,
                                             });
            selected = true;
        }
        else if (machine_x64_place_is_addressed(selector, instruction->operands[0], place_kind))
        {
            u32 address_register;
            selected = machine_x64_operand_register(selector, instruction->operands[0], &address_register);
            if (selected)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                     .opcode = MACHINE_X64_VSTORE_PTR,
                                                 });
            }
        }
    }
    return selected;
}

// The scalar form: a promoted local takes a register copy, a direct local a
// full-slot frame store, and anything address-shaped a sized pointer store.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_scalar_store(MachineX64Selector* selector, IrValueId place, u8 place_kind, u64 size, u32 slot,
                                                         u32 value_register)
{
    bool selected = false;
    u32 size_index = size == 1 ? 0 : size == 2 ? 1 : size == 4 ? 2 : size == 8 ? 3 : UINT32_MAX;
    u32 place_register = machine_x64_promoted_local_register(selector, place, place_kind);
    if (size_index != UINT32_MAX)
    {
        if (place_register != UINT32_MAX)
        {
            // Promoted local: the store is a full-width register copy —
            // the same 64-bit image a direct-slot store writes, since the
            // register model keeps every value zero-extended.
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, place_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                           .opcode = MACHINE_X64_MOV_RR,
                                                       });
            machine_x64_define(selector, place_register, row);
            selected = true;
        }
        else if (place_kind == MACHINE_X64_PLACE_LOCAL && slot != UINT32_MAX)
        {
            // Direct-slot stores always write the full eight-byte slot,
            // exactly like the canonical path: the slot is the value's
            // exclusive home, and narrower stores would leave stale upper
            // bytes for the sixty-four-bit slot loads and tests that
            // follow. The pointer stores below stay exactly sized.
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                 .opcode = MACHINE_X64_STORE_FRAME64,
                                             });
            selected = true;
        }
        else if (machine_x64_place_is_addressed(selector, place, place_kind))
        {
            u32 address_register;
            selected = machine_x64_operand_register(selector, place, &address_register);
            if (selected)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                     .opcode = (u16)(MACHINE_X64_STORE_PTR8 + size_index),
                                                 });
            }
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL u16 machine_x64_inline_effect_opcode(IrInstructionExtra extra)
{
    u16 effect_index = 0;
    for (u32 index = 0; index < extra.clobber_count; index += 1)
    {
        effect_index |= string_equal(extra.clobbers[index], S8("memory")) ? 1u : 0u;
        effect_index |= string_equal(extra.clobbers[index], S8("cc")) ? 2u : 0u;
    }
    return (u16)(MACHINE_X64_INLINE_EFFECTS_NONE + effect_index);
}

// Empty templates emit no bytes, but their clobbers remain independent
// scheduler facts: a plain side effect, a memory barrier, a flags definition,
// or both.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_compiler_barrier(MachineX64Selector* selector, IrInstruction* instruction)
{
    bool selected = machine_selection_is_compiler_barrier(selector->function, instruction);
    if (selected)
    {
        IrInstructionExtra extra = ir_instruction_extra(selector->function, ir_instruction_self_id(selector->function, instruction));
        machine_x64_select_row(selector, (MachineInstruction){.opcode = machine_x64_inline_effect_opcode(extra)});
    }
    return selected;
}

#define MACHINE_X64_INLINE_ASSEMBLY_OPERAND_LIMIT 16u

BUSTER_GLOBAL_LOCAL u32 machine_x64_select_block_entry(MachineX64Selector* selector, u32 canonical_block);

typedef enum MachineX64InlineAssemblyBlockRelocationClass
{
    MACHINE_X64_INLINE_ASSEMBLY_BLOCK_UNSUPPORTED,
    MACHINE_X64_INLINE_ASSEMBLY_BLOCK_ADDRESS,
    MACHINE_X64_INLINE_ASSEMBLY_BLOCK_CONTROL,
} MachineX64InlineAssemblyBlockRelocationClass;

BUSTER_GLOBAL_LOCAL MachineX64InlineAssemblyBlockRelocationClass
machine_x64_inline_assembly_block_relocation_class(ByteSlice bytes, AssemblyRelocation relocation)
{
    bool pc32 = relocation.kind == ASSEMBLY_RELOCATION_X86_PC32 && relocation.offset <= bytes.length &&
                sizeof(u32) <= bytes.length - relocation.offset;
    bool jump = pc32 && relocation.offset && bytes.pointer[relocation.offset - 1u] == 0xe9u;
    bool conditional = pc32 && relocation.offset >= 2u && bytes.pointer[relocation.offset - 2u] == 0x0fu &&
                       (bytes.pointer[relocation.offset - 1u] & 0xf0u) == 0x80u;
    bool address = pc32 && relocation.offset >= 2u && bytes.pointer[relocation.offset - 2u] == 0x8du &&
                   (bytes.pointer[relocation.offset - 1u] & 0xc7u) == 0x05u;
    return jump || conditional ? MACHINE_X64_INLINE_ASSEMBLY_BLOCK_CONTROL
           : address           ? MACHINE_X64_INLINE_ASSEMBLY_BLOCK_ADDRESS
                               : MACHINE_X64_INLINE_ASSEMBLY_BLOCK_UNSUPPORTED;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_inline_assembly_source(MachineX64Selector* selector, IrInstruction* instruction,
                                                            IrInstructionExtra extra, X64Register* registers, u32* vector_registers,
                                                            String8* source_out, AssemblyEncodeResult* encoded_out)
{
    String8 resolved = {0};
    bool selected = codegen_inline_assembly_resolve_template(selector->arena, selector->program, selector->function, instruction, extra,
                                                              registers, vector_registers, ASSEMBLY_SYNTAX_ATT, &resolved, 0);
    // Each retained line below gets a newline, including a final unterminated
    // template line. Reserve that byte instead of overwriting the next arena
    // object before the standalone assembler parses it.
    selected = selected && resolved.length != UINT64_MAX;
    char8* instructions = selected ? arena_allocate(selector->arena, char8, resolved.length + 1) : 0;
    u64 instruction_length = 0;
    u64 line_start = 0;
    while (selected && line_start < resolved.length)
    {
        u64 line_end = line_start;
        while (line_end < resolved.length && resolved.pointer[line_end] != '\n')
        {
            line_end += 1;
        }
        String8 line = {.pointer = resolved.pointer + line_start, .length = line_end - line_start};
        while (line.length && (line.pointer[0] == ' ' || line.pointer[0] == '\t'))
        {
            line.pointer += 1;
            line.length -= 1;
        }
        if (line.length && line.pointer[0] == '.')
        {
            bool recognized = false;
            selected = codegen_global_assembly_apply_symbol_directive(selector->program, selector->target, line, extra.literal, &recognized) && recognized;
        }
        else if (line.length)
        {
            memcpy(instructions + instruction_length, line.pointer, line.length);
            instruction_length += line.length;
            instructions[instruction_length++] = '\n';
        }
        line_start = line_end < resolved.length ? line_end + 1 : resolved.length;
    }
    AssemblyEncodeResult encoded = {0};
    if (selected)
    {
        encoded = assembly_encode(selector->arena, (String8){.pointer = instructions, .length = instruction_length},
                                  (AssemblyEncodeOptions){.target = selector->target, .syntax = ASSEMBLY_SYNTAX_ATT,
                                                          .private_inline_labels = true});
        selected = encoded.diagnostic_count == 0;
    }
    if (selected)
    {
        *source_out = resolved;
        *encoded_out = encoded;
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_inline_assembly_outputs(MachineX64Selector* selector, IrInstruction* instruction,
                                                                    u32 const* slots, u8 const* sizes, u8 const* operand_flags)
{
    IrFunction* function = selector->function;
    bool selected = true;
    for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
    {
        if ((operand_flags[index] & (MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_MEMORY)) !=
            MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT)
        {
            continue;
        }
        IrValueId place = instruction->operands[index];
        bool x87 = (operand_flags[index] & (MACHINE_INLINE_ASSEMBLY_OPERAND_X87_TOP | MACHINE_INLINE_ASSEMBLY_OPERAND_X87_BELOW)) != 0;
        if (x87)
        {
            u8 place_kind = place.value < function->value_count ? selector->place_kinds[place.value] : MACHINE_X64_PLACE_NONE;
            u32 place_slot = place.value < function->value_count ? selector->value_stack_slots[place.value] : UINT32_MAX;
            if (place_kind == MACHINE_X64_PLACE_LOCAL && place_slot != UINT32_MAX)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, place_slot),
                                 machine_ref_make(MACHINE_REF_STACK_SLOT, slots[index])},
                    .payload = 10,
                    .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME,
                });
            }
            else
            {
                u32 address = UINT32_MAX;
                selected = machine_x64_place_is_addressed(selector, place, place_kind) &&
                           machine_x64_operand_register(selector, place, &address);
                if (selected)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address),
                                     machine_ref_make(MACHINE_REF_STACK_SLOT, slots[index])},
                        .payload = 10,
                        .opcode = MACHINE_X64_COPY_PTR_FROM_FRAME,
                    });
                }
            }
        }
        else
        {
            u32 value = machine_x64_select_frame_load64(selector, slots[index], 0);
            selected = machine_x64_select_scalar_store(selector, place, selector->place_kinds[place.value], sizes[index],
                                                       selector->value_stack_slots[place.value], value);
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_inline_assembly(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;
    IrInstructionExtra extra = ir_instruction_extra(function, ir_instruction_self_id(function, instruction));
    u32 assembly_target = UINT32_MAX;
    bool simple_goto = false;
    if (instruction->target_count && instruction->targets)
    {
        assembly_target = 0;
        simple_goto = !extra.literal.length || ir_inline_assembly_jump_target(function, instruction, extra.literal, S8("jmp %l"), &assembly_target);
    }
    u32 first_continuation = selector->asm_goto_continuations ? selector->asm_goto_continuations[selector->current_block] : UINT32_MAX;
    bool general_goto = instruction->target_count && first_continuation != UINT32_MAX;
    MachineAssemblyLabelPlan label_plan = {.literal = extra.literal};
    bool labels_planned = !general_goto || machine_selection_assembly_label_plan(selector->arena, function, instruction, extra, &label_plan);
    IrInstructionExtra source_extra = extra;
    source_extra.literal = label_plan.literal;
    bool selected = instruction->operand_count <= MACHINE_X64_INLINE_ASSEMBLY_OPERAND_LIMIT &&
                    instruction->operand_count == instruction->immediate_count &&
                    (!instruction->target_count || simple_goto || general_goto) && labels_planned &&
                    extra.operand_name_count <= instruction->operand_count &&
                    (!instruction->operand_count || (instruction->operands && instruction->immediates)) &&
                    (!extra.operand_name_count || extra.operand_names);
    X64Register registers[MACHINE_X64_INLINE_ASSEMBLY_OPERAND_LIMIT] = {0};
    u32 vector_registers[MACHINE_X64_INLINE_ASSEMBLY_OPERAND_LIMIT] = {0};
    u32 slots[MACHINE_X64_INLINE_ASSEMBLY_OPERAND_LIMIT];
    u8 sizes[MACHINE_X64_INLINE_ASSEMBLY_OPERAND_LIMIT] = {0};
    u8 operand_flags[MACHINE_X64_INLINE_ASSEMBLY_OPERAND_LIMIT] = {0};
    bool used[48] = {0};
    bool reserved[48] = {0};
    bool clobbered[48] = {0};
    u8 fixed_count[48] = {0};
    u8 fixed_output_count[48] = {0};
    u8 fixed_input_count[48] = {0};
    u8 fixed_early_clobber[48] = {0};
    u64 exact_clobbers = 0;
    u8 effects = 0;
    u16 preserved_vector_mask = 0;
    for (u32 index = 0; selected && index < extra.clobber_count; index += 1)
    {
        X64Register clobber = X64_REGISTER_RAX;
        u32 vector_clobber = 0;
        if (string_equal(extra.clobbers[index], S8("memory")))
        {
            effects |= MACHINE_INLINE_ASSEMBLY_EFFECT_MEMORY;
        }
        else if (string_equal(extra.clobbers[index], S8("cc")))
        {
            effects |= MACHINE_INLINE_ASSEMBLY_EFFECT_FLAGS;
        }
        else if (codegen_inline_assembly_clobber_register(extra.clobbers[index], &clobber))
        {
            reserved[clobber] = true;
            clobbered[clobber] = true;
            exact_clobbers |= UINT64_C(1) << clobber;
        }
        else if (codegen_inline_assembly_clobber_vector_register(extra.clobbers[index], &vector_clobber))
        {
            reserved[MACHINE_X64_ZMM0 + vector_clobber] = true;
            exact_clobbers |= UINT64_C(1) << (MACHINE_X64_ZMM0 + vector_clobber);
            if (machine_x64_target_is_windows(selector->target) && vector_clobber >= 6)
            {
                preserved_vector_mask |= (u16)(1u << vector_clobber);
            }
        }
        else if (!string_equal(extra.clobbers[index], S8("st")))
        {
            selected = false;
        }
        else
        {
            effects |= MACHINE_INLINE_ASSEMBLY_EFFECT_X87_POP;
        }
    }
    for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
    {
        X64Register fixed = X64_REGISTER_RAX;
        if (!(instruction->immediates[index] & IR_INLINE_ASSEMBLY_CONSTRAINT_MATCH) &&
            codegen_inline_assembly_constraint_register(instruction->immediates[index], &fixed))
        {
            // GNU asm deliberately permits multiple operands to alias one
            // fixed register (for example `=a` with an `a` input), but the
            // alias is only valid for one output and one input. Keep direct
            // IR fail-closed for duplicate inputs, duplicate outputs, and
            // early-clobber pairs; the C frontend rejects those before this
            // selector, while hand-built IR still needs the same boundary.
            selected = !clobbered[fixed];
            reserved[fixed] = true;
            fixed_count[fixed] = (u8)(fixed_count[fixed] + 1u);
            fixed_output_count[fixed] = (u8)(fixed_output_count[fixed] +
                                             (u8)((instruction->immediates[index] & IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT) != 0));
            fixed_input_count[fixed] = (u8)(fixed_input_count[fixed] +
                                            (u8)((instruction->immediates[index] & IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT) == 0 ||
                                                 (instruction->immediates[index] & IR_INLINE_ASSEMBLY_CONSTRAINT_READ_WRITE) != 0));
            fixed_early_clobber[fixed] |= (u8)((instruction->immediates[index] & IR_INLINE_ASSEMBLY_CONSTRAINT_EARLY_CLOBBER) != 0);
        }
    }
    for (u32 fixed = 0; selected && fixed < 48; fixed += 1)
    {
        bool repeated = fixed_count[fixed] > 1;
        bool valid_alias = fixed_count[fixed] == 2 && fixed_output_count[fixed] == 1 && fixed_input_count[fixed] == 1 && !fixed_early_clobber[fixed];
        selected = !repeated || valid_alias;
    }
    for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
    {
        u64 constraint = instruction->immediates[index];
        u64 constraint_class = constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_CLASS_MASK;
        IrValueId operand = instruction->operands[index];
        IrType* type = operand.value < function->value_count
                           ? ir_type_from_id(&selector->program->types, function->values[operand.value].canonical_type)
                           : 0;
        selected = type && type->layout.resolved && type->layout.size && type->layout.size <= 16 &&
                   constraint_class < IR_INLINE_ASSEMBLY_CONSTRAINT_COUNT;
        bool memory = IR_INLINE_ASSEMBLY_CONSTRAINT_IS_MEMORY(constraint_class);
        bool vector = IR_INLINE_ASSEMBLY_CONSTRAINT_IS_VECTOR(constraint_class);
        bool x87 = IR_INLINE_ASSEMBLY_CONSTRAINT_IS_X87(constraint_class);
        if (selected && (constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_MATCH))
        {
            u32 match = IR_INLINE_ASSEMBLY_CONSTRAINT_MATCH_INDEX(constraint);
            selected = match < index;
            if (selected)
            {
                registers[index] = registers[match];
                vector_registers[index] = vector_registers[match];
                slots[index] = slots[match];
            }
        }
        else if (selected && vector)
        {
            u32 candidate = 0;
            while (candidate < 8 && (used[16 + candidate] || reserved[16 + candidate]))
            {
                candidate += 1;
            }
            selected = candidate < 8;
            if (selected)
            {
                vector_registers[index] = candidate;
                used[16 + candidate] = true;
                exact_clobbers |= UINT64_C(1) << (16 + candidate);
                if (machine_x64_target_is_windows(selector->target) && candidate >= 6)
                {
                    preserved_vector_mask |= (u16)(1u << candidate);
                }
                slots[index] = machine_x64_append_slot(selector, 16, 16);
            }
        }
        else if (selected && x87)
        {
            registers[index] = X64_REGISTER_RAX;
            slots[index] = machine_x64_append_slot(selector, 16, 16);
        }
        else if (selected)
        {
            X64Register fixed = X64_REGISTER_RAX;
            bool has_fixed = codegen_inline_assembly_constraint_register(constraint, &fixed);
            u32 candidate = has_fixed ? (u32)fixed : 0;
            while (!has_fixed && candidate < 16 &&
                   (candidate == MACHINE_X64_RSP || candidate == MACHINE_X64_RBP || used[candidate] || reserved[candidate]))
            {
                candidate += 1;
            }
            selected = candidate < 16 && (has_fixed || !used[candidate]);
            if (selected)
            {
                registers[index] = (X64Register)candidate;
                used[candidate] = true;
                exact_clobbers |= UINT64_C(1) << candidate;
                slots[index] = machine_x64_append_slot(selector, 8, 8);
            }
        }
        if (selected)
        {
            sizes[index] = (u8)(memory ? 8 : type->layout.size);
            operand_flags[index] = (u8)(((constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT) ? MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT : 0) |
                                        (!(constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT) ||
                                                 (constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_READ_WRITE) || memory
                                             ? MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT
                                             : 0) |
                                        (memory ? MACHINE_INLINE_ASSEMBLY_OPERAND_MEMORY : 0) |
                                        (vector ? MACHINE_INLINE_ASSEMBLY_OPERAND_VECTOR : 0) |
                                        (constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_T ? MACHINE_INLINE_ASSEMBLY_OPERAND_X87_TOP : 0) |
                                        (constraint_class == IR_INLINE_ASSEMBLY_CONSTRAINT_U ? MACHINE_INLINE_ASSEMBLY_OPERAND_X87_BELOW : 0) |
                                        ((constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_EARLY_CLOBBER)
                                             ? MACHINE_INLINE_ASSEMBLY_OPERAND_EARLY_CLOBBER
                                             : 0));
            effects |= memory ? MACHINE_INLINE_ASSEMBLY_EFFECT_MEMORY : 0;
        }
    }
    // Stage every input image before any output is published. Matching inputs
    // initialize their output's shared frame slot and therefore preserve
    // permutations without sequential-register aliasing.
    for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
    {
        if (!(operand_flags[index] & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT))
        {
            continue;
        }
        IrValueId source = instruction->operands[index];
        u64 constraint = instruction->immediates[index];
        bool memory = (operand_flags[index] & MACHINE_INLINE_ASSEMBLY_OPERAND_MEMORY) != 0;
        u32 source_register = UINT32_MAX;
        bool x87 = (operand_flags[index] & (MACHINE_INLINE_ASSEMBLY_OPERAND_X87_TOP | MACHINE_INLINE_ASSEMBLY_OPERAND_X87_BELOW)) != 0;
        if (x87)
        {
            u32 source_slot = source.value < function->value_count ? selector->value_stack_slots[source.value] : UINT32_MAX;
            selected = source_slot != UINT32_MAX;
            if (selected && source_slot != slots[index])
            {
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slots[index]),
                                 machine_ref_make(MACHINE_REF_STACK_SLOT, source_slot)},
                    .payload = 10,
                    .opcode = MACHINE_X64_COPY_FRAME_FROM_FRAME,
                });
            }
        }
        else if (memory)
        {
            source_register = machine_x64_synthesize_register(selector);
            selected = machine_x64_select_place_address(selector, source, source_register);
        }
        else if ((constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_READ_WRITE) != 0)
        {
            source_register = machine_x64_synthesize_register(selector);
            IrInstruction load = {.opcode = IR_OPCODE_LOAD, .canonical_type = function->values[source.value].canonical_type,
                                  .operands = &source, .operand_count = 1, .result = source};
            selected = machine_x64_select_load(selector, &load, source_register);
        }
        else
        {
            selected = machine_x64_operand_register(selector, source, &source_register);
        }
        if (selected && !x87)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slots[index]),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                .opcode = MACHINE_X64_STORE_FRAME64,
            });
        }
    }
    String8 source = {0};
    AssemblyEncodeResult encoded = {0};
    if (selected && !simple_goto)
    {
        selected = machine_x64_inline_assembly_source(selector, instruction, source_extra, registers, vector_registers, &source, &encoded);
    }
    u32 reference_capacity = 0;
    selected = selected && machine_selection_assembly_label_reference_capacity(extra.literal, &reference_capacity);
    u32* control_targets = selected && general_goto && reference_capacity ? arena_allocate(selector->arena, u32, reference_capacity) : 0;
    u32 control_count = 0;
    u32 first_relocation = selector->inline_assembly_relocations.total_count;
    for (u32 index = 0; selected && index < encoded.relocation_count; index += 1)
    {
        AssemblyRelocation relocation = encoded.relocations[index];
        selected = relocation.symbol < encoded.symbol_count && !encoded.symbols[relocation.symbol].defined && relocation.offset <= UINT32_MAX;
        String8 name = selected ? encoded.symbols[relocation.symbol].name : (String8){0};
        u32 label_target = UINT32_MAX;
        bool block = selected && machine_selection_assembly_label_target(&label_plan, name, &label_target);
        selected = selected && (block || codegen_assembly_durable_name(extra.literal, &name));
        MachineX64InlineAssemblyBlockRelocationClass block_class =
            block ? machine_x64_inline_assembly_block_relocation_class(encoded.bytes, relocation)
                  : MACHINE_X64_INLINE_ASSEMBLY_BLOCK_UNSUPPORTED;
        bool control = block_class == MACHINE_X64_INLINE_ASSEMBLY_BLOCK_CONTROL;
        selected = selected && (!block || (label_target < instruction->target_count &&
                                           instruction->targets[label_target].value < function->block_count &&
                                           block_class != MACHINE_X64_INLINE_ASSEMBLY_BLOCK_UNSUPPORTED)) &&
                   (!control || control_count < reference_capacity) && (!block || relocation.addend <= INT64_MAX - 4);
        if (selected)
        {
            s64 addend = block ? relocation.addend + 4 : relocation.addend;
            u32 target_block = block ? machine_x64_select_block_entry(selector, instruction->targets[label_target].value) : UINT32_MAX;
            u32 continuation_block = control ? first_continuation + instruction->target_count + control_count : UINT32_MAX;
            MachineInlineAssemblyRelocation* row =
                (MachineInlineAssemblyRelocation*)machine_stream_append(selector->arena, &selector->inline_assembly_relocations);
            *row = (MachineInlineAssemblyRelocation){.symbol = name, .addend = addend, .offset = (u32)relocation.offset,
                                                     .block = target_block, .continuation_block = continuation_block,
                                                     .target_index = block ? label_target : UINT32_MAX,
                                                     .kind = (u8)relocation.kind, .is_block = block, .is_control = control};
            if (control)
            {
                control_targets[control_count++] = label_target;
            }
        }
    }
    selected = selected &&
               (!general_goto || control_count <= (u32)UINT16_MAX - (u32)instruction->target_count);
    if (selected)
    {
        u32 preserved_vector_count = 0;
        for (u32 vector_register = 6; vector_register < 16; vector_register += 1)
        {
            preserved_vector_count += ((u32)preserved_vector_mask >> vector_register) & 1u;
        }
        u32 preserved_vector_slot = preserved_vector_count ? machine_x64_append_slot(selector, 16u * preserved_vector_count, 16) : UINT32_MAX;
        u32 first_operand = selector->inline_assembly_operands.total_count;
        for (u32 index = 0; index < instruction->operand_count; index += 1)
        {
            MachineInlineAssemblyOperand* row =
                (MachineInlineAssemblyOperand*)machine_stream_append(selector->arena, &selector->inline_assembly_operands);
            bool vector = (operand_flags[index] & MACHINE_INLINE_ASSEMBLY_OPERAND_VECTOR) != 0;
            *row = (MachineInlineAssemblyOperand){.stack_slot = slots[index],
                                                  .physical_register = vector ? (u8)(MACHINE_X64_ZMM0 + vector_registers[index])
                                                                              : (u8)registers[index],
                                                  .byte_size = sizes[index],
                                                  .constraint_class = (u8)(instruction->immediates[index] & IR_INLINE_ASSEMBLY_CONSTRAINT_CLASS_MASK),
                                                  .flags = operand_flags[index]};
        }
        u32 descriptor_index = selector->inline_assemblies.total_count;
        MachineInlineAssembly* descriptor = (MachineInlineAssembly*)machine_stream_append(selector->arena, &selector->inline_assemblies);
        *descriptor = (MachineInlineAssembly){.source = source, .bytes = encoded.bytes, .clobber_mask = exact_clobbers,
                                              .first_operand = first_operand, .first_relocation = first_relocation,
                                              .operand_count = (u8)instruction->operand_count,
                                              .relocation_count = (u16)encoded.relocation_count,
                                              .effects = (u8)(effects | (general_goto ? MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR : 0)),
                                              .successor_count = general_goto ? (u16)(instruction->target_count + control_count) : 0,
                                              .declared_successor_count = general_goto ? (u16)instruction->target_count : 0,
                                              .preserved_vector_slot = preserved_vector_slot,
                                              .fallthrough_block = general_goto ? first_continuation : UINT32_MAX};
        machine_x64_select_row(selector, (MachineInstruction){.payload = descriptor_index, .opcode = MACHINE_X64_INLINE_ASSEMBLY});
        if (general_goto)
        {
            u32 source_block = selector->builder.open_block;
            u32 successor_count = instruction->target_count + control_count;
            u32 reserved_successor_count = instruction->target_count + reference_capacity;
            selected = first_continuation == source_block + 1u && successor_count <= UINT16_MAX &&
                       reserved_successor_count <= MACHINE_REF_PAYLOAD_LIMIT - first_continuation;
            for (u32 target = 0; selected && target < successor_count; target += 1)
            {
                machine_builder_edge(&selector->builder, (MachineEdge){.source_block = source_block,
                                                                       .destination_block = first_continuation + target});
            }
            for (u32 target = 0; selected && target < reserved_successor_count; target += 1)
            {
                machine_builder_block_end(&selector->builder, selector->open_block);
                machine_builder_block_begin(&selector->builder);
                selector->open_block = (MachineBlock){0};
                bool successor_used = target < successor_count;
                if (successor_used)
                {
                    selected = machine_x64_select_inline_assembly_outputs(selector, instruction, slots, sizes, operand_flags);
                    u32 target_index = target < instruction->target_count ? target : control_targets[target - instruction->target_count];
                    u32 destination = instruction->targets[target_index].value;
                    selected = selected && destination < function->block_count;
                    if (selected)
                    {
                        machine_x64_select_row(selector, (MachineInstruction){
                            .operands = {machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, destination))},
                            .opcode = MACHINE_X64_JMP,
                        });
                    }
                }
            }
        }
        else
        {
            selected = machine_x64_select_inline_assembly_outputs(selector, instruction, slots, sizes, operand_flags);
            if (selected && simple_goto)
            {
                selected = assembly_target < instruction->target_count && instruction->targets[assembly_target].value < function->block_count;
                if (selected)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_BLOCK,
                                                      machine_x64_select_block_entry(selector, instruction->targets[assembly_target].value))},
                        .opcode = MACHINE_X64_JMP,
                    });
                }
            }
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_select_block_entry(MachineX64Selector* selector, u32 canonical_block)
{
    return selector->block_entries ? selector->block_entries[canonical_block] : canonical_block;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_assembly_identity(MachineX64Selector* selector, IrInstruction* instruction)
{
    MachineAssemblyIdentityPlan plan;
    bool selected = machine_selection_assembly_identity_plan(selector->program, selector->function, instruction, S8("jmp %l"), &plan);
    u32 values[MACHINE_ASSEMBLY_IDENTITY_MAX_OPERANDS];
    // Capture every input before any output place changes. In particular a
    // tied-input permutation must not become sequential stores to locals.
    for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
    {
        if (((u32)plan.matching_inputs >> index) & 1u)
        {
            continue;
        }
        IrValueId source = instruction->operands[plan.source_operands[index]];
        u32 source_register;
        if (((u32)plan.read_write >> index) & 1u)
        {
            source_register = machine_x64_synthesize_register(selector);
            IrInstruction load = {.opcode = IR_OPCODE_LOAD, .canonical_type = selector->function->values[source.value].canonical_type,
                                  .operands = &source, .operand_count = 1, .result = source};
            selected = machine_x64_select_load(selector, &load, source_register);
        }
        else
        {
            selected = machine_x64_operand_register(selector, source, &source_register);
        }
        if (selected)
        {
            values[index] = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, values[index]),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                .opcode = MACHINE_X64_ASM_IDENTITY,
            });
        }
    }
    for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
    {
        if (((u32)plan.outputs >> index) & 1u)
        {
            IrValueId place = instruction->operands[index];
            selected = machine_x64_select_scalar_store(selector, place, selector->place_kinds[place.value], plan.sizes[index],
                                                       selector->value_stack_slots[place.value], values[index]);
        }
    }
    if (selected && plan.target_index != UINT32_MAX)
    {
        if (!instruction->operand_count)
        {
            IrInstructionExtra extra = ir_instruction_extra(selector->function, ir_instruction_self_id(selector->function, instruction));
            machine_x64_select_row(selector, (MachineInstruction){.opcode = machine_x64_inline_effect_opcode(extra)});
        }
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, instruction->targets[plan.target_index].value))},
            .opcode = MACHINE_X64_JMP,
        });
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_inline_hint(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrInstructionExtra extra = ir_instruction_extra(selector->function, ir_instruction_self_id(selector->function, instruction));
    bool nop = string_equal(extra.literal, S8("nop"));
    bool pause = string_equal(extra.literal, S8("pause"));
    bool selected = (nop || pause) && machine_selection_is_operand_free_assembly(selector->function, instruction);
    if (selected)
    {
        machine_x64_select_row(selector, (MachineInstruction){.payload = pause ? 2u : 1u, .opcode = machine_x64_inline_effect_opcode(extra)});
    }
    return selected;
}

// These fixed literal forms have more architectural results than the hot
// row has inline operand slots. One constrained row snapshots all results
// into a private frame object; ordinary stores then publish the C outputs.
// Keeping both CPUID inputs on that row lets placement resolve them in
// parallel, including RAX/RCX swaps, and preserves every live clobbered value.
BUSTER_GLOBAL_LOCAL bool machine_x64_select_cpu_query(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;
    IrInstructionExtra extra = ir_instruction_extra(function, ir_instruction_self_id(function, instruction));
    bool cpuid = string_equal(extra.literal, S8("cpuid"));
    bool xgetbv = string_equal(extra.literal, S8("xgetbv"));
    bool selected = (cpuid || xgetbv) && instruction->operand_count == (cpuid ? 6u : 3u) &&
                    instruction->immediate_count == instruction->operand_count && !instruction->target_count &&
                    (!xgetbv || target_cpu_feature_has(selector->target, TARGET_CPU_FEATURE_X86_XSAVE));
    u32 inputs[4] = {UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX};
    u32 input_mask = 0;
    u32 output_mask = 0;
    for (u32 index = 0; selected && index < extra.clobber_count; index += 1)
    {
        selected = string_equal(extra.clobbers[index], S8("memory")) || string_equal(extra.clobbers[index], S8("cc"));
    }
    for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
    {
        IrValueId operand = instruction->operands[index];
        u64 constraint = instruction->immediates[index];
        u32 role = (u32)(constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_CLASS_MASK);
        bool output = (constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT) != 0;
        bool matching = (constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_MATCH) != 0;
        selected = operand.value < function->value_count && role <= IR_INLINE_ASSEMBLY_CONSTRAINT_D &&
                    !(constraint & (IR_INLINE_ASSEMBLY_CONSTRAINT_READ_WRITE | ~IR_INLINE_ASSEMBLY_CONSTRAINT_KNOWN_MASK));
        if (selected)
        {
            IrType* type = ir_type_from_id(&selector->program->types, function->values[operand.value].canonical_type);
            // Partial-register and read/write forms retain their existing
            // fallback until their input and output semantics are selected.
            selected = type && type->kind == IR_TYPE_INTEGER && type->bit_width == 32 && type->layout.resolved && type->layout.size == 4;
        }
        if (selected && matching)
        {
            u32 match = IR_INLINE_ASSEMBLY_CONSTRAINT_MATCH_INDEX(constraint);
            selected = !output && match < instruction->operand_count &&
                        instruction->immediates[match] == (IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT | role);
        }
        if (selected && output)
        {
            selected = !(output_mask & (1u << role)) && selector->place_kinds[operand.value] != MACHINE_X64_PLACE_NONE;
            output_mask |= 1u << role;
        }
        else if (selected)
        {
            selected = !(input_mask & (1u << role)) && machine_x64_operand_register(selector, operand, inputs + role);
            input_mask |= 1u << role;
        }
    }
    selected = selected && output_mask == (cpuid ? 0xfu : (1u << IR_INLINE_ASSEMBLY_CONSTRAINT_A) | (1u << IR_INLINE_ASSEMBLY_CONSTRAINT_D)) &&
               input_mask == (cpuid ? (1u << IR_INLINE_ASSEMBLY_CONSTRAINT_A) | (1u << IR_INLINE_ASSEMBLY_CONSTRAINT_C)
                                   : (1u << IR_INLINE_ASSEMBLY_CONSTRAINT_C));
    if (selected)
    {
        u32 result_slot = machine_x64_append_slot(selector, cpuid ? 32u : 16u, 8);
        MachineInstruction row = {.opcode = (u16)(cpuid ? MACHINE_X64_CPUID : MACHINE_X64_XGETBV)};
        if (cpuid)
        {
            row.operands[0] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, inputs[IR_INLINE_ASSEMBLY_CONSTRAINT_A]);
            row.operands[1] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, inputs[IR_INLINE_ASSEMBLY_CONSTRAINT_C]);
            row.operands[2] = machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot);
        }
        else
        {
            row.operands[0] = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, inputs[IR_INLINE_ASSEMBLY_CONSTRAINT_C]);
            row.operands[1] = machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot);
        }
        machine_x64_select_row(selector, row);
        for (u32 index = 0; selected && index < instruction->operand_count; index += 1)
        {
            u64 constraint = instruction->immediates[index];
            if (constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_OUTPUT)
            {
                u32 role = (u32)(constraint & IR_INLINE_ASSEMBLY_CONSTRAINT_CLASS_MASK);
                u32 result_offset = cpuid ? role * 8u : (role == IR_INLINE_ASSEMBLY_CONSTRAINT_D ? 8u : 0u);
                u32 value = machine_x64_select_frame_load64(selector, result_slot, result_offset);
                IrValueId place = instruction->operands[index];
                selected = machine_x64_select_scalar_store(selector, place, selector->place_kinds[place.value], 4,
                                                           selector->value_stack_slots[place.value], value);
            }
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_store(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    bool selected = false;
    if (instruction->operands[0].value < function->value_count && instruction->operands[1].value < function->value_count)
    {
        u8 place_kind = selector->place_kinds[instruction->operands[0].value];
        if (place_kind != MACHINE_X64_PLACE_NONE)
        {
            IrTypeId stored_type_id = function->values[instruction->operands[1].value].canonical_type;
            MachineTypeClass stored_class = machine_x64_type_class(selector, stored_type_id);
            // The scalar and vector classes carry their size; an aggregate's
            // arbitrary byte count is the record's.
            u64 size;
            if (stored_class.size_log2 != MACHINE_TYPE_CLASS_NO_LOG2)
            {
                size = (u64)1 << stored_class.size_log2;
            }
            else
            {
                IrType* stored_type = ir_type_from_id(&program->types, stored_type_id);
                size = stored_type && stored_type->layout.resolved ? stored_type->layout.size : 0;
            }
            if (machine_x64_type_is_f80(selector, stored_type_id))
            {
                size = 10;
            }
            u32 slot = selector->value_stack_slots[instruction->operands[0].value];
            u32 value_slot = selector->value_stack_slots[instruction->operands[1].value];
            if (instruction->opcode == IR_OPCODE_ATOMIC_STORE && value_slot != UINT32_MAX &&
                selector->value_virtual_registers[instruction->operands[1].value] == UINT32_MAX)
            {
                // An atomic aggregate stores through one integer access at
                // the place's promoted width (#731): the image loads from
                // the value slot, keeps only the value's real bytes (the
                // slot's tail may be residue while the promoted padding
                // must store as zero), and one sized store — XCHG when
                // sequential — writes the whole width.
                IrType* place_type = ir_type_from_id(&program->types, function->values[instruction->operands[0].value].canonical_type);
                u64 atomic_width = place_type && place_type->layout.resolved ? place_type->layout.size : 0;
                u32 width_index = atomic_width == 1 ? 0 : atomic_width == 2 ? 1 : atomic_width == 4 ? 2 : atomic_width == 8 ? 3 : UINT32_MAX;
                bool aggregate_kind = stored_class.kind == IR_TYPE_STRUCT || stored_class.kind == IR_TYPE_UNION;
                bool integer128 = stored_class.kind == IR_TYPE_INTEGER && (stored_class.flags & MACHINE_TYPE_CLASS_INTEGER128) != 0;
                bool wide_atomic = (aggregate_kind || integer128) && atomic_width == 16 && size >= 9 && size <= 16 &&
                                   target_cpu_feature_has(selector->target, TARGET_CPU_FEATURE_X86_CX16);
                if (wide_atomic)
                {
                    // CMPXCHG16B is the only machine form for a sixteen-byte
                    // atomic store. The desired image remains in its frame
                    // slot; the constrained row carries the place address in
                    // slot 3 so SysV uses RSI and Win64 uses volatile R11.
                    u32 address_register = machine_x64_synthesize_register(selector);
                    selected = machine_x64_select_place_address(selector, instruction->operands[0], address_register);
                    if (selected)
                    {
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot),
                                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot),
                                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register)},
                                                             .payload = (u32)size,
                                                             .opcode = MACHINE_X64_ATOMIC_STORE16,
                                                         });
                    }
                }
                else if (aggregate_kind && size && size <= 8 && width_index != UINT32_MAX)
                {
                    u32 data_register = machine_x64_select_frame_load64(selector, value_slot, 0);
                    if (size < atomic_width)
                    {
                        u32 mask_register = machine_x64_select_immediate_register(selector, ((u64)1 << (size * 8)) - 1);
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, data_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, data_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask_register)},
                                                             .opcode = MACHINE_X64_AND64,
                                                         });
                    }
                    u32 address_register = machine_x64_synthesize_register(selector);
                    selected = machine_x64_select_place_address(selector, instruction->operands[0], address_register);
                    if (selected)
                    {
                        bool sequential = instruction->memory_order == IR_MEMORY_ORDER_SEQUENTIAL;
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, data_register)},
                                                             .payload = sequential ? (u32)atomic_width : 0,
                                                             .opcode = (u16)(sequential ? (u16)MACHINE_X64_ATOMIC_STORE_XCHG
                                                                                        : (u16)(MACHINE_X64_STORE_PTR8 + width_index)),
                                                         });
                    }
                }
            }
            else if (instruction->opcode == IR_OPCODE_ATOMIC_STORE && instruction->memory_order == IR_MEMORY_ORDER_SEQUENTIAL)
            {
                selected = machine_x64_select_sequential_atomic_store(selector, instruction, size);
            }
            else if (value_slot != UINT32_MAX && selector->value_virtual_registers[instruction->operands[1].value] == UINT32_MAX)
            {
                selected = machine_x64_select_aggregate_store(selector, instruction, place_kind, size, slot, value_slot);
            }
            else
            {
                u32 value_register;
                if (machine_x64_operand_register(selector, instruction->operands[1], &value_register))
                {
                    // Spelled as a branch rather than a conditional operand:
                    // both arms emit rows, and `ide` evaluates both arms of a
                    // conditional in some operand positions.
                    if (stored_class.flags & MACHINE_TYPE_CLASS_VECTOR_REGISTER)
                    {
                        selected = machine_x64_select_vector_store(selector, instruction, place_kind, slot, value_register);
                    }
                    else
                    {
                        selected = machine_x64_select_scalar_store(selector, instruction->operands[0], place_kind, size, slot, value_register);
                    }
                }
            }
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_function(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    // A function reference is an ordinary symbol address; direct calls carry
    // the symbol on the CALL row itself, so a value used only as that callee
    // needs no address row or relocation.
    bool selected = false;
    if (instruction->symbol.value != IR_ID_UNDERLYING_INVALID)
    {
        selected = true;
        if (result_register != UINT32_MAX)
        {
            // Under -fPIC an interposable address comes out of the GOT, so
            // every object in the image agrees on which definition `&f` names.
            u8 reference = machine_x64_symbol_reference(selector, instruction->symbol, false);
            u32 target_index = machine_x64_call_target(selector, instruction->symbol, reference);
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                           .payload = target_index,
                                                           .opcode = (u16)(reference == MACHINE_SYMBOL_REFERENCE_GOT ? MACHINE_X64_LOAD_SYMBOL_GOT
                                                                                                                     : MACHINE_X64_LEA_SYMBOL),
                                                       });
            machine_x64_define(selector, result_register, row);
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_simd(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    // The 512-bit vocabulary, one EVEX row per operation with values
    // register-resident — the canonical path's per-operand frame
    // round-trips are exactly what this subset removes. Masks arrive
    // and leave in general registers; rows that consume or produce one
    // stage through k1 inside the encoder.
    IrSimdOperation operation = (IrSimdOperation)instruction->simd_operation;
    IrSimdShape shape = ir_simd_operation_shape(operation);
    bool selected = ir_simd_operation_supported(selector->target, operation) && instruction->operand_count == shape.operand_count &&
                    instruction->immediate_count == shape.immediate_count && (!shape.immediate_count || instruction->immediates) &&
                    (!shape.has_result || result_register != UINT32_MAX);
    u32 operand_registers[4];
    for (u32 operand_index = 0; operand_index < instruction->operand_count && selected; operand_index += 1)
    {
        selected = machine_x64_operand_register(selector, instruction->operands[operand_index], operand_registers + operand_index);
    }
    if (selected)
    {
        // Read after the verdict: a shape that wants an immediate has already
        // been rejected here if the instruction carries no immediate array.
        u32 immediate = shape.immediate_count ? (u32)instruction->immediates[0] : 0;
        switch (operation)
        {
        case IR_SIMD_LOAD:
        case IR_SIMD_LOAD_MASKED:
        {
            bool masked = operation == IR_SIMD_LOAD_MASKED;
            // The mask ref is built before the row, not inside it: only the masked
            // shape has a second operand, so an unmasked load must not reach
            // operand_registers[1] at all.
            MachineRef mask_operand = masked ? machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[1]) : 0;
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0]), mask_operand},
                                                           .opcode = masked ? MACHINE_X64_VLOAD_PTR_MASKED : MACHINE_X64_VLOAD_PTR,
                                                       });
            machine_x64_define(selector, result_register, row);
            break;
        }
        case IR_SIMD_STORE:
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0]),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[1])},
                                                 .opcode = MACHINE_X64_VSTORE_PTR,
                                             });
            break;
        }
        case IR_SIMD_STORE_MASKED:
        case IR_SIMD_COMPRESS_STORE_BYTE:
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0]),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[1]),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[2])},
                                                 .opcode = operation == IR_SIMD_STORE_MASKED ? MACHINE_X64_VSTORE_PTR_MASKED : MACHINE_X64_VCOMPRESS_STORE_PTR,
                                             });
            break;
        }
        case IR_SIMD_SPLAT_BYTE:
        case IR_SIMD_SPLAT_WORD:
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0])},
                                                           .opcode = operation == IR_SIMD_SPLAT_BYTE ? MACHINE_X64_VSPLATB : MACHINE_X64_VSPLATD,
                                                       });
            machine_x64_define(selector, result_register, row);
            break;
        }
        case IR_SIMD_COMPARE_EQUAL_BYTE:
        case IR_SIMD_COMPARE_LESS_BYTE:
        case IR_SIMD_TEST_MASK_BYTE:
        case IR_SIMD_COMPARE_EQUAL_WORD:
        case IR_SIMD_COMPARE_LESS_WORD:
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0]),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[1])},
                                                           .payload = operation == IR_SIMD_COMPARE_EQUAL_BYTE  ? 0u
                                                                      : operation == IR_SIMD_COMPARE_LESS_BYTE  ? 1u
                                                                      : operation == IR_SIMD_TEST_MASK_BYTE     ? 2u
                                                                      : operation == IR_SIMD_COMPARE_EQUAL_WORD ? 3u
                                                                                                                : 4u,
                                                           .opcode = MACHINE_X64_VPCMP_MASK,
                                                       });
            machine_x64_define(selector, result_register, row);
            break;
        }
        case IR_SIMD_SIGN_MASK_BYTE:
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0])},
                                                           .opcode = MACHINE_X64_VPMOVB2M,
                                                       });
            machine_x64_define(selector, result_register, row);
            break;
        }
        case IR_SIMD_PERMUTE2_BYTE:
        {
            // vpermt2b reads the low table from its destination register
            // and overwrites it, so the low table copies into the result
            // first; the copy coalesces whenever the low value dies here.
            u32 copy_row = machine_x64_select_row(selector, (MachineInstruction){
                                                                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[1])},
                                                                .opcode = MACHINE_X64_VMOV_RR,
                                                            });
            machine_x64_define(selector, result_register, copy_row);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0]),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[2]),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[3])},
                                                 .opcode = MACHINE_X64_VPERMT2B,
                                             });
            break;
        }
        case IR_SIMD_COMPRESS_BYTE:
        case IR_SIMD_COMPRESS_WORD:
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0]),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[1])},
                                                           .payload = operation == IR_SIMD_COMPRESS_BYTE ? 0u : 1u,
                                                           .opcode = MACHINE_X64_VCOMPRESSB,
                                                       });
            machine_x64_define(selector, result_register, row);
            break;
        }
        case IR_SIMD_WIDEN_BYTE_TO_WORD:
        case IR_SIMD_SHIFT_LEFT_WORD:
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0])},
                                                           .payload = immediate,
                                                           .opcode = operation == IR_SIMD_WIDEN_BYTE_TO_WORD ? MACHINE_X64_VPMOVZXBD : MACHINE_X64_VPSLLD_RI,
                                                       });
            machine_x64_define(selector, result_register, row);
            break;
        }
        case IR_SIMD_TERNARY_WORD:
        {
            // vpternlogd reads its first source from the destination, the
            // same in-place shape as vpermt2b.
            u32 copy_row = machine_x64_select_row(selector, (MachineInstruction){
                                                                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[0])},
                                                                .opcode = MACHINE_X64_VMOV_RR,
                                                            });
            machine_x64_define(selector, result_register, copy_row);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[1]),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, operand_registers[2])},
                                                 .payload = immediate,
                                                 .opcode = MACHINE_X64_VPTERNLOGD,
                                             });
            break;
        }
        case IR_SIMD_COUNT:
            selected = false;
            break;
        }
    }
    return selected;
}

// The type-derived half of a call plan, computed once per callee function
// type: every call through the type stages the same shapes into the same
// registers and eightbytes, so the ABI classification and the placement of
// the fixed parameters are paid once per signature and a call pays for its
// operands alone. The pool is sized by the module's function types before
// any function selects, so a plan is never allocated during selection.
struct MachineX64SignaturePlan
{
    MachineX64ValueShape* argument_shapes;
    MachineX64ArgumentPlacement* argument_placements;
    MachineX64ValueShape return_shape;
    u32 parameter_count;
    // The register and stack cursors after the fixed parameters, where a
    // variadic call's tail continues.
    u32 integer_count;
    u32 float_count;
    u32 stack_part_count;
    bool built;
    bool returns_value;
    bool variadic;
    // The result took a subset shape, or there is none.
    bool return_supported;
    // Every fixed parameter took a subset shape, and a variadic signature
    // has no vector parameter:
    // the signature's share of the per-call verdict.
    bool arguments_supported;
    u8 reserved[3];
};

// Sizes and allocates the module's plan pool: one slot per function type,
// with shape and placement rows for the parameters a plan can carry.
BUSTER_GLOBAL_LOCAL void machine_x64_signature_plans_prepare(Arena* arena, IrProgram* program, MachineSelectionModule* module)
{
    u32 type_count = program->types.count;
    module->x64_signature_slots = arena_allocate(arena, u32, type_count ? type_count : 1);
    u32 plan_count = 0;
    u64 parameter_total = 0;
    for (u32 type_index = 0; type_index < type_count; type_index += 1)
    {
        u32 slot = UINT32_MAX;
        if (module->type_classes[type_index].kind == IR_TYPE_FUNCTION)
        {
            u32 parameter_count = program->types.types[type_index].parameter_count;
            slot = plan_count;
            plan_count += 1;
            parameter_total += parameter_count;
        }
        module->x64_signature_slots[type_index] = slot;
    }
    module->x64_signature_plan_count = plan_count;
    module->x64_signature_plans = arena_allocate(arena, MachineX64SignaturePlan, plan_count ? plan_count : 1);
    memset(module->x64_signature_plans, 0, sizeof(*module->x64_signature_plans) * (plan_count ? plan_count : 1));
    MachineX64ValueShape* shapes = arena_allocate(arena, MachineX64ValueShape, parameter_total ? parameter_total : 1);
    MachineX64ArgumentPlacement* placements = arena_allocate(arena, MachineX64ArgumentPlacement, parameter_total ? parameter_total : 1);
    u64 parameter_base = 0;
    for (u32 type_index = 0; type_index < type_count; type_index += 1)
    {
        u32 slot = module->x64_signature_slots[type_index];
        if (slot != UINT32_MAX)
        {
            u32 parameter_count = program->types.types[type_index].parameter_count;
            MachineX64SignaturePlan* plan = module->x64_signature_plans + slot;
            plan->argument_shapes = shapes + parameter_base;
            plan->argument_placements = placements + parameter_base;
            parameter_base += parameter_count;
        }
    }
}

// The plan of a callee function type, built on the first call through it.
BUSTER_GLOBAL_LOCAL MachineX64SignaturePlan const* machine_x64_signature_plan(MachineX64Selector* selector, IrTypeId callee_type_id, IrType* callee_type)
{
    MachineSelectionModule* module = selector->module;
    MachineX64SignaturePlan* plan = module->x64_signature_plans + module->x64_signature_slots[callee_type_id.value];
    if (!plan->built)
    {
        IrProgram* program = selector->program;
        Target target = selector->target;
        bool windows = machine_x64_target_is_windows(target);
        plan->parameter_count = callee_type->parameter_count;
        plan->variadic = callee_type->is_variadic;
        IrType* return_type = ir_type_from_id(&program->types, callee_type->return_type);
        plan->returns_value = return_type && return_type->kind != IR_TYPE_VOID;
        plan->return_supported =
            !plan->returns_value || machine_x64_value_shape(program, callee_type->return_type, IR_ABI_USE_RESULT, target, &plan->return_shape);
        plan->integer_count = plan->return_shape.indirect ? 1 : 0;
        plan->float_count = plan->return_shape.indirect && windows ? 1 : 0;
        plan->stack_part_count = 0;
        // System V variadic vector arguments need a separate AL/overflow
        // contract. Win64 vectors use the ordinary indirect pointer placement.
        bool arguments_supported = true;
        for (u32 parameter_index = 0; parameter_index < plan->parameter_count && arguments_supported; parameter_index += 1)
        {
            MachineX64ValueShape* shape = plan->argument_shapes + parameter_index;
            arguments_supported = machine_x64_value_shape(program, callee_type->parameter_types[parameter_index], IR_ABI_USE_ARGUMENT, target, shape) &&
                                  !(plan->variadic && !windows && shape->vector);
            arguments_supported = arguments_supported && machine_x64_argument_area_fits(shape, plan->stack_part_count);
            if (arguments_supported)
            {
                MachineX64ArgumentPlacement* placement = plan->argument_placements + parameter_index;
                machine_x64_place_argument(shape, windows, &plan->integer_count, &plan->float_count, &plan->stack_part_count, placement);
            }
        }
        plan->arguments_supported = arguments_supported;
        plan->built = true;
    }
    return plan;
}

// Everything CALL selection resolves before it emits a row: who is called,
// where each argument travels, and how the result comes back. The shapes
// and placements are the signature plan's rows; a variadic call's tail is
// classified per call into arena rows that start with a copy of the fixed
// part, so the staging below indexes one array either way.
typedef struct MachineX64CallPlan MachineX64CallPlan;
struct MachineX64CallPlan
{
    MachineX64ValueShape const* argument_shapes;
    MachineX64ArgumentPlacement const* argument_placements;
    u32* argument_registers;
    u32* argument_slots;
    MachineX64ValueShape return_shape;
    u32 argument_count;
    u32 callee_register;
    u32 indirect_result_slot;
    u32 indirect_result_backing_slot;
    u32 indirect_result_pointer;
    u32 integer_count;
    u32 float_count;
    u32 stack_part_count;
    u32 outgoing_bytes;
    u32 stack_alignment;
    u32 saved_stack_register;
    bool aligned_stack;
    bool stack_padding;
    bool windows_call;
    bool direct_call;
    bool variadic_call;
    bool returns_value;
};

// Resolves the call against the callee's signature and the ABI's argument
// placement. The only rows it emits are the backing store for an unused
// indirect result and the bounce slots the staging below reads.
BUSTER_GLOBAL_LOCAL bool machine_x64_plan_call(MachineX64Selector* selector, IrInstruction* instruction, MachineX64CallPlan* plan)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    *plan = (MachineX64CallPlan){.callee_register = UINT32_MAX, .indirect_result_slot = UINT32_MAX,
                               .indirect_result_backing_slot = UINT32_MAX, .indirect_result_pointer = UINT32_MAX,
                               .stack_alignment = 16, .saved_stack_register = UINT32_MAX};
    plan->argument_registers = selector->call_argument_registers;
    plan->argument_slots = selector->call_argument_slots;
    IrType* callee_type = 0;
    IrTypeId callee_type_id = {.value = IR_ID_UNDERLYING_INVALID};
    bool planned = instruction->operand_count != 0 && instruction->operands[0].value < function->value_count;
    if (planned)
    {
        IrValue* callee = function->values + instruction->operands[0].value;
        u8 callee_kind = selector->place_kinds[instruction->operands[0].value];
        planned = callee_kind != MACHINE_X64_PLACE_NONE;
        if (planned)
        {
            plan->direct_call = callee_kind == MACHINE_X64_PLACE_FUNCTION && instruction->symbol.value != IR_ID_UNDERLYING_INVALID;
            planned = plan->direct_call || machine_x64_operand_register(selector, instruction->operands[0], &plan->callee_register);
            callee_type_id = callee->canonical_type;
            callee_type = ir_type_from_id(&program->types, callee_type_id);
            if (callee_type && callee_type->kind == IR_TYPE_POINTER)
            {
                callee_type_id = callee_type->element_type;
                callee_type = ir_type_from_id(&program->types, callee_type_id);
            }
        }
    }
    if (planned)
    {
        plan->argument_count = instruction->operand_count - 1;
        plan->variadic_call = callee_type && callee_type->kind == IR_TYPE_FUNCTION && callee_type->is_variadic;
        plan->windows_call = machine_x64_target_is_windows(selector->target);
        planned = callee_type && callee_type->kind == IR_TYPE_FUNCTION &&
                  (plan->variadic_call ? plan->argument_count >= callee_type->parameter_count
                                       : callee_type->parameter_count == plan->argument_count) &&
                  plan->argument_count <= selector->call_argument_capacity;
    }
    MachineX64SignaturePlan const* signature = 0;
    if (planned)
    {
        signature = machine_x64_signature_plan(selector, callee_type_id, callee_type);
        plan->returns_value = signature->returns_value;
        plan->return_shape = signature->return_shape;
        planned = signature->return_supported;
    }
    if (planned)
    {
        plan->integer_count = plan->return_shape.indirect ? 1 : 0;
        plan->float_count = plan->return_shape.indirect && plan->windows_call ? 1 : 0;
        if (plan->return_shape.indirect)
        {
            if (instruction->result.value != IR_ID_UNDERLYING_INVALID)
            {
                plan->indirect_result_slot = selector->value_stack_slots[instruction->result.value];
                planned = plan->indirect_result_slot != UINT32_MAX;
            }
            else
            {
                // An unused indirect result still needs backing storage.
                plan->indirect_result_slot = machine_x64_append_slot(selector, plan->return_shape.byte_size, 8);
            }
            if (planned && plan->return_shape.stack_alignment > 16)
            {
                u64 backing_size = (u64)plan->return_shape.byte_size + plan->return_shape.stack_alignment - 1;
                planned = backing_size <= UINT32_MAX;
                if (planned)
                {
                    // Internal aggregate slots are only eight-aligned. Give
                    // an external callee enough slack for its naturally
                    // aligned vector store, then copy back after the call.
                    plan->indirect_result_backing_slot = machine_x64_append_slot(selector, (u32)backing_size, 8);
                }
            }
        }
    }
    // The fixed parameters are the signature's verdict and rows; the
    // variadic tail — every argument past them, shaped by its value's type
    // under the same rules — continues the signature's cursors per call.
    // Indirect aggregate tails use the same one-pointer Win64 placement.
    if (planned)
    {
        planned = signature->arguments_supported;
    }
    if (planned)
    {
        plan->integer_count = signature->integer_count;
        plan->float_count = signature->float_count;
        plan->stack_part_count = signature->stack_part_count;
        plan->argument_shapes = signature->argument_shapes;
        plan->argument_placements = signature->argument_placements;
        if (plan->argument_count > signature->parameter_count)
        {
            MachineX64ValueShape* tail_shapes = arena_allocate(selector->arena, MachineX64ValueShape, plan->argument_count);
            MachineX64ArgumentPlacement* tail_placements = arena_allocate(selector->arena, MachineX64ArgumentPlacement, plan->argument_count);
            for (u32 parameter_index = 0; parameter_index < signature->parameter_count; parameter_index += 1)
            {
                tail_shapes[parameter_index] = signature->argument_shapes[parameter_index];
                tail_placements[parameter_index] = signature->argument_placements[parameter_index];
            }
            for (u32 argument_index = signature->parameter_count; argument_index < plan->argument_count && planned; argument_index += 1)
            {
                IrTypeId argument_type_id = function->values[instruction->operands[argument_index + 1].value].canonical_type;
                // System V's AL protocol would have to count vector registers;
                // Win64's indirect vector tail consumes only pointer slots.
                planned = machine_x64_value_shape(program, argument_type_id, IR_ABI_USE_ARGUMENT, selector->target, tail_shapes + argument_index) &&
                          !(plan->variadic_call && !plan->windows_call && tail_shapes[argument_index].vector);
                if (planned && plan->variadic_call && !plan->windows_call && tail_shapes[argument_index].aggregate &&
                    machine_x64_type_class(selector, argument_type_id).kind == IR_TYPE_VECTOR && tail_shapes[argument_index].byte_size > 16)
                {
                    // Unnamed wide vectors always occupy the overflow area,
                    // even when a named parameter would fit one YMM register.
                    tail_shapes[argument_index].force_stack = true;
                    tail_shapes[argument_index].part_count = 0;
                    tail_shapes[argument_index].vector_part_bytes = 0;
                }
                planned = planned && machine_x64_argument_area_fits(tail_shapes + argument_index, plan->stack_part_count);
                if (planned)
                {
                    machine_x64_place_argument(tail_shapes + argument_index, plan->windows_call, &plan->integer_count, &plan->float_count,
                                               &plan->stack_part_count, tail_placements + argument_index);
                }
            }
            plan->argument_shapes = tail_shapes;
            plan->argument_placements = tail_placements;
        }
    }
    if (planned)
    {
        plan->stack_padding = (plan->stack_part_count & 1) != 0;
    }
    u64 outgoing_bytes = plan->windows_call ? (32ull + (u64)plan->stack_part_count * 8 + 15) & ~(u64)15 : 0;
    u32 stack_end = 0;
    for (u32 argument_index = 0; argument_index < plan->argument_count && planned; argument_index += 1)
    {
        plan->argument_registers[argument_index] = UINT32_MAX;
        plan->argument_slots[argument_index] = selector->value_stack_slots[instruction->operands[argument_index + 1].value];
        planned = plan->argument_shapes[argument_index].aggregate
                      ? plan->argument_slots[argument_index] != UINT32_MAX
                      : machine_x64_operand_register(selector, instruction->operands[argument_index + 1], plan->argument_registers + argument_index);
        if (plan->windows_call && plan->argument_shapes[argument_index].indirect)
        {
            outgoing_bytes += ((u64)plan->argument_shapes[argument_index].byte_size + 15) & ~(u64)15;
            outgoing_bytes += plan->argument_shapes[argument_index].stack_alignment - 16;
        }
        MachineX64ArgumentPlacement const* placement = plan->argument_placements + argument_index;
        if (!plan->windows_call && placement->on_stack)
        {
            plan->stack_alignment = BUSTER_MAX(plan->stack_alignment, plan->argument_shapes[argument_index].stack_alignment);
            plan->aligned_stack |= placement->first_stack_part != stack_end || plan->stack_alignment > 16;
            stack_end = (u32)placement->first_stack_part + placement->stack_part_count;
        }
    }
    if (plan->aligned_stack)
    {
        outgoing_bytes = (u64)plan->stack_part_count * 8;
    }
    // Frame displacements are signed 32-bit. Check the complete reservation
    // before narrowing or emitting any outgoing-area address.
    planned = planned && outgoing_bytes <= INT32_MAX;
    plan->outgoing_bytes = planned ? (u32)outgoing_bytes : 0;
    return planned;
}

// Moves one consecutive direct-result/argument vector part between a frame
// slot and its fixed ABI register. XMM/YMM have compact dedicated rows; a ZMM
// part uses the existing pointer transfer after materializing the subobject
// address, preserving the same unaligned frame contract.
BUSTER_GLOBAL_LOCAL void machine_x64_select_vector_frame_part(MachineX64Selector* selector, bool load, u32 physical_register,
                                                              u32 slot, u32 offset, u32 part_bytes)
{
    if (part_bytes == 64)
    {
        u32 address = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address), machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
            .payload = offset,
            .opcode = MACHINE_X64_LEA_FRAME,
        });
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {load ? machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, physical_register)
                              : machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address),
                         load ? machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address)
                              : machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, physical_register)},
            .opcode = load ? MACHINE_X64_VLOAD_PTR : MACHINE_X64_VSTORE_PTR,
        });
    }
    else
    {
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, physical_register),
                         machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
            .payload = offset,
            .opcode = part_bytes == 32 ? (load ? MACHINE_X64_LOAD_YMM_FRAME256 : MACHINE_X64_STORE_YMM_FRAME256)
                                       : (load ? MACHINE_X64_LOAD_XMM_FRAME128 : MACHINE_X64_STORE_XMM_FRAME128),
        });
    }
}

// The scalar lane forms use the same sized memory vocabulary as ordinary
// scalar selection. Loads materialize an address because the frame has one
// generic 64-bit load row, while stores already publish exact-width rows.
BUSTER_GLOBAL_LOCAL u16 machine_x64_frame_store_opcode(u32 byte_size)
{
    u16 result = byte_size == 1   ? MACHINE_X64_STORE_FRAME8
                 : byte_size == 2 ? MACHINE_X64_STORE_FRAME16
                 : byte_size == 4 ? MACHINE_X64_STORE_FRAME32
                                  : MACHINE_X64_STORE_FRAME64;
    return result;
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_select_frame_scalar_load(MachineX64Selector* selector, u32 slot, u32 offset, u32 byte_size)
{
    u32 address = machine_x64_synthesize_register(selector);
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address),
                                                      machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
                                         .payload = offset,
                                         .opcode = MACHINE_X64_LEA_FRAME,
                                     });
    u32 value = machine_x64_synthesize_register(selector);
    u16 opcode = byte_size == 1   ? MACHINE_X64_LOAD_PTR8
                 : byte_size == 2 ? MACHINE_X64_LOAD_PTR16
                 : byte_size == 4 ? MACHINE_X64_LOAD_PTR32
                                  : MACHINE_X64_LOAD_PTR64;
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value),
                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address)},
                                         .opcode = opcode,
                                     });
    return value;
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_return_integer_register(u32 index)
{
    static u32 const registers[] = {MACHINE_X64_RAX, MACHINE_X64_RDX, MACHINE_X64_RCX};
    u32 result = index < BUSTER_ARRAY_LENGTH(registers) ? registers[index] : MACHINE_X64_RAX;
    return result;
}

BUSTER_GLOBAL_LOCAL u32 machine_x64_shape_part_size(MachineX64ValueShape const* shape, u32 part_index)
{
    u32 result = part_index < BUSTER_ARRAY_LENGTH(shape->part_sizes) && shape->part_sizes[part_index]
                     ? shape->part_sizes[part_index]
                     : 8u;
    return result;
}

// Stages every argument into the register or stack slot its placement names,
// and reports the flags the call row carries: the variadic AL count, and
// whether a vector register is live across the call.
BUSTER_GLOBAL_LOCAL u16 machine_x64_stage_call_arguments(MachineX64Selector* selector, MachineX64CallPlan* plan)
{
    // Stack and indirect vector arguments bounce through a dedicated
    // 64-byte frame slot. Pushes and private-copy staging then have memory
    // to read, independent of the outgoing stack pointer.
    for (u32 argument_index = 0; argument_index < plan->argument_count; argument_index += 1)
    {
        if (!plan->argument_shapes[argument_index].vector ||
            (!plan->argument_placements[argument_index].on_stack && !plan->argument_shapes[argument_index].indirect))
        {
            continue;
        }
        plan->argument_slots[argument_index] = machine_x64_append_slot(selector, 64, 16);
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index]),
                                                          machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                                             .opcode = MACHINE_X64_VSTORE_FRAME,
                                         });
    }
    if (plan->aligned_stack)
    {
        // Save the exact caller RSP, including any live alloca, then allocate
        // the complete ABI area at its required base alignment. Writing each
        // argument at its classified offset also preserves padding gaps.
        plan->saved_stack_register = machine_x64_synthesize_register(selector);
        (void)machine_x64_select_stack_save(selector, plan->saved_stack_register);
        u32 size_register = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, size_register),
                         machine_ref_make(MACHINE_REF_IMMEDIATE, machine_x64_append_immediate(selector, plan->outgoing_bytes))},
            .opcode = MACHINE_X64_MOV_RI,
        });
        u32 area_register = machine_x64_synthesize_register(selector);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, area_register),
                         machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, size_register)},
            .payload = plan->stack_alignment,
            .opcode = MACHINE_X64_STACK_ALLOCATE,
        });
        for (u32 argument_index = 0; argument_index < plan->argument_count; argument_index += 1)
        {
            MachineX64ArgumentPlacement const* placement = plan->argument_placements + argument_index;
            if (!placement->on_stack) { continue; }
            MachineX64ValueShape const* shape = plan->argument_shapes + argument_index;
            u32 pointer = area_register;
            if (placement->first_stack_part)
            {
                pointer = machine_x64_synthesize_register(selector);
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer),
                                 machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, area_register)},
                    .payload = (u32)placement->first_stack_part * 8,
                    .opcode = MACHINE_X64_LEA_OFFSET,
                });
            }
            bool frame = shape->aggregate || shape->vector;
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer),
                             frame ? machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index])
                                   : machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                .payload = frame ? shape->byte_size : 0,
                .opcode = frame ? MACHINE_X64_COPY_PTR_FROM_FRAME : MACHINE_X64_STORE_PTR64,
            });
        }
    }
    // Win64 writes its outgoing stack arguments into the frame's own
    // area, above the four shadow eightbytes the callee owns, and leaves
    // the stack pointer alone: the area's base is where a call's stack
    // pointer already points. Every part travels through a register,
    // which the allocator is free to pick because nothing here is fixed.
    if (plan->windows_call)
    {
        u32 outgoing_register = UINT32_MAX;
        if (selector->dynamic_stack)
        {
            // Calls reserve their own area below the live VLA. Frame-relative
            // staging would otherwise leave arguments above the current RSP.
            u32 size = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, size),
                             machine_ref_make(MACHINE_REF_IMMEDIATE, machine_x64_append_immediate(selector, plan->outgoing_bytes))},
                .opcode = MACHINE_X64_MOV_RI,
            });
            outgoing_register = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, outgoing_register),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, size)},
                .payload = 16,
                .opcode = MACHINE_X64_STACK_ALLOCATE,
            });
        }
        else if (selector->outgoing_slot == UINT32_MAX)
        {
            selector->outgoing_slot = machine_x64_append_slot(selector, plan->outgoing_bytes, 16);
        }
        if (!selector->dynamic_stack)
        {
            selector->outgoing_bytes = BUSTER_MAX(selector->outgoing_bytes, plan->outgoing_bytes);
        }
        u32 copy_offset = (32u + plan->stack_part_count * 8u + 15u) & ~15u;
        for (u32 argument_index = 0; argument_index < plan->argument_count; argument_index += 1)
        {
            MachineX64ValueShape const* shape = plan->argument_shapes + argument_index;
            MachineX64ArgumentPlacement const* argument_placement = plan->argument_placements + argument_index;
            if (shape->indirect)
            {
                // The callee may modify its parameter. Copy exact bytes into
                // the shared outgoing area after shadow/stack arguments;
                // all call sites reuse this area at their maximum size. Its
                // base is sixteen-aligned, so alignment - 16 spare bytes are
                // enough to round a copy up to the type's stronger alignment.
                u32 copy_slack = shape->stack_alignment - 16;
                u32 pointer;
                if (selector->dynamic_stack)
                {
                    u32 offset = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, offset),
                                     machine_ref_make(MACHINE_REF_IMMEDIATE, machine_x64_append_immediate(selector, copy_offset + copy_slack))},
                        .opcode = MACHINE_X64_MOV_RI,
                    });
                    pointer = machine_x64_select_arithmetic_row(selector, MACHINE_X64_ADD64, outgoing_register, offset);
                }
                else
                {
                    pointer = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer),
                                     machine_ref_make(MACHINE_REF_STACK_SLOT, selector->outgoing_slot)},
                        .payload = copy_offset + copy_slack,
                        .opcode = MACHINE_X64_LEA_FRAME,
                    });
                }
                if (copy_slack)
                {
                    u32 mask = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask),
                                     machine_ref_make(MACHINE_REF_IMMEDIATE, machine_x64_append_immediate(selector, 0ull - shape->stack_alignment))},
                        .opcode = MACHINE_X64_MOV_RI,
                    });
                    pointer = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, pointer, mask);
                }
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer),
                                 machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index])},
                    .payload = shape->exact_byte_size,
                    .opcode = MACHINE_X64_COPY_PTR_FROM_FRAME,
                });
                plan->argument_registers[argument_index] = pointer;
                copy_offset += ((shape->byte_size + 15u) & ~15u) + copy_slack;
            }
            if (!argument_placement->on_stack)
            {
                continue;
            }
            for (u32 part_index = 0; part_index < argument_placement->stack_part_count; part_index += 1)
            {
                u32 outgoing_offset = 32u + ((u32)argument_placement->first_stack_part + part_index) * 8u;
                u32 part_register = plan->argument_registers[argument_index];
                if (shape->windows_scalar_lane_size)
                {
                    u32 lane = (u32)argument_placement->register_part_count + part_index;
                    part_register = machine_x64_select_frame_scalar_load(selector, plan->argument_slots[argument_index],
                                                                          lane * shape->windows_scalar_lane_size,
                                                                          shape->windows_scalar_lane_size);
                }
                else if (shape->indirect && shape->vector_part_bytes)
                {
                    u32 piece = (u32)argument_placement->register_part_count + part_index;
                    if (piece)
                    {
                        part_register = machine_x64_synthesize_register(selector);
                        machine_x64_select_row(selector, (MachineInstruction){
                            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, part_register),
                                         machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                            .payload = piece * shape->vector_part_bytes,
                            .opcode = MACHINE_X64_LEA_OFFSET,
                        });
                    }
                }
                else if (shape->aggregate && !shape->indirect)
                {
                    part_register = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, part_register),
                                                                      machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index])},
                                                         .payload = part_index * 8,
                                                         .opcode = MACHINE_X64_LOAD_FRAME,
                                                     });
                }
                u32 outgoing_address = outgoing_register;
                if (selector->dynamic_stack)
                {
                    u32 offset = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, offset),
                                     machine_ref_make(MACHINE_REF_IMMEDIATE, machine_x64_append_immediate(selector, outgoing_offset))},
                        .opcode = MACHINE_X64_MOV_RI,
                    });
                    outgoing_address = machine_x64_select_arithmetic_row(selector, MACHINE_X64_ADD64, outgoing_register, offset);
                }
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {selector->dynamic_stack
                                                                      ? machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, outgoing_address)
                                                                      : machine_ref_make(MACHINE_REF_STACK_SLOT, selector->outgoing_slot),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, part_register)},
                                                     .payload = selector->dynamic_stack ? 0 : outgoing_offset,
                                                     .opcode = selector->dynamic_stack ? MACHINE_X64_STORE_PTR64 : MACHINE_X64_STORE_FRAME64,
                                                 });
            }
        }
    }
    // Materialize scalar lanes and register-bound split references before
    // populating any fixed argument register. Each is ordinary virtual-register
    // work and may bind to RCX/RDX/R8/R9; emitting it after an earlier scalar
    // or pointer was placed there would silently clobber that argument before
    // the call. Keeping all bases and derived pointers live through this
    // preparation lets every allocator resolve the later fixed copies safely.
    u32 windows_argument_parts[BUSTER_ARRAY_LENGTH(machine_x64_windows_arguments)] = {0};
    if (plan->windows_call)
    {
        for (u32 argument_index = 0; argument_index < plan->argument_count; argument_index += 1)
        {
            MachineX64ValueShape const* shape = plan->argument_shapes + argument_index;
            MachineX64ArgumentPlacement const* placement = plan->argument_placements + argument_index;
            if (shape->windows_scalar_lane_size)
            {
                for (u32 lane = 0; lane < placement->register_part_count; lane += 1)
                {
                    windows_argument_parts[(u32)placement->first_integer + lane] = machine_x64_select_frame_scalar_load(
                        selector, plan->argument_slots[argument_index], lane * shape->windows_scalar_lane_size,
                        shape->windows_scalar_lane_size);
                }
            }
            if (!shape->indirect || !shape->vector_part_bytes)
            {
                continue;
            }
            for (u32 part = 0; part < placement->register_part_count; part += 1)
            {
                u32 pointer = plan->argument_registers[argument_index];
                if (part)
                {
                    pointer = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer),
                                     machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                        .payload = part * shape->vector_part_bytes,
                        .opcode = MACHINE_X64_LEA_OFFSET,
                    });
                }
                windows_argument_parts[(u32)placement->first_integer + part] = pointer;
            }
        }
    }
    // Outgoing stack parts push right to left before any register is
    // placed (the pushes scratch only RAX), with alignment padding for
    // an odd part count.
    if (!plan->windows_call && !plan->aligned_stack && plan->stack_padding)
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .payload = 8,
                                             .opcode = MACHINE_X64_SUB_RSP,
                                         });
    }
    for (u32 argument_reverse = plan->windows_call || plan->aligned_stack ? 0 : plan->argument_count; argument_reverse > 0; argument_reverse -= 1)
    {
        u32 argument_index = argument_reverse - 1;
        MachineX64ArgumentPlacement const* argument_placement = plan->argument_placements + argument_index;
        if (!argument_placement->on_stack)
        {
            continue;
        }
        if (plan->argument_shapes[argument_index].aggregate || plan->argument_shapes[argument_index].vector)
        {
            for (u32 part_reverse = argument_placement->stack_part_count; part_reverse > 0; part_reverse -= 1)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index])},
                                                     .payload = (part_reverse - 1) * 8,
                                                     .opcode = MACHINE_X64_PUSH_FRAME,
                                                 });
            }
            continue;
        }
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                                             .opcode = MACHINE_X64_PUSH_REGISTER,
                                         });
    }
    // Explicit fixed-register argument copies, floats-first in two passes
    // like machine_x64_select_return: a float part bounces through RAX into
    // its XMM register via a freshly synthesized load whose free register
    // pick knows nothing about argument staging — crossing every float
    // before any integer argument register is written is what keeps that
    // pick from landing on (and destroying) an already placed argument.
    // Integer targets then load directly, never through a scratch. The
    // hidden result pointer takes the first integer register.
    bool call_vector_registers = false;
    for (u32 populate_pass = 0; populate_pass < 2; populate_pass += 1)
    {
        bool float_pass = populate_pass == 0;
        if (!float_pass && plan->return_shape.indirect)
        {
            u32 result_pointer_register = machine_x64_synthesize_register(selector);
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_pointer_register),
                                                              machine_ref_make(MACHINE_REF_STACK_SLOT,
                                                                               plan->indirect_result_backing_slot != UINT32_MAX
                                                                                   ? plan->indirect_result_backing_slot
                                                                                   : plan->indirect_result_slot)},
                                                 .payload = plan->indirect_result_backing_slot != UINT32_MAX
                                                                ? plan->return_shape.stack_alignment - 1
                                                                : 0,
                                                 .opcode = MACHINE_X64_LEA_FRAME,
                                             });
            if (plan->indirect_result_backing_slot != UINT32_MAX)
            {
                u32 mask = machine_x64_synthesize_register(selector);
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, mask),
                                 machine_ref_make(MACHINE_REF_IMMEDIATE,
                                                  machine_x64_append_immediate(selector, 0ull - plan->return_shape.stack_alignment))},
                    .opcode = MACHINE_X64_MOV_RI,
                });
                result_pointer_register = machine_x64_select_arithmetic_row(selector, MACHINE_X64_AND64, result_pointer_register, mask);
            }
            plan->indirect_result_pointer = result_pointer_register;
            machine_x64_select_row(selector,
                                   (MachineInstruction){
                                       .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, machine_x64_argument_register(plan->windows_call, 0)),
                                                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_pointer_register)},
                                       .opcode = MACHINE_X64_MOV_RR,
                                   });
        }
        for (u32 argument_index = 0; argument_index < plan->argument_count; argument_index += 1)
        {
            MachineX64ValueShape const* shape = plan->argument_shapes + argument_index;
            MachineX64ArgumentPlacement const* placement = plan->argument_placements + argument_index;
            if (placement->on_stack && (!plan->windows_call || placement->register_part_count == 0))
            {
                continue;
            }
            u32 next_integer = placement->first_integer;
            u32 next_float = placement->first_float;
            if (shape->windows_scalar_lane_size)
            {
                bool lane_float = shape->windows_scalar_float;
                bool stage_registers = lane_float == float_pass;
                bool duplicate_variadic = lane_float && !float_pass && plan->variadic_call;
                if (stage_registers || duplicate_variadic)
                {
                    for (u32 lane = 0; lane < placement->register_part_count; lane += 1)
                    {
                        u32 slot = (u32)placement->first_integer + lane;
                        u32 lane_value = windows_argument_parts[slot];
                        if (lane_float && stage_registers)
                        {
                            machine_x64_select_row(selector, (MachineInstruction){
                                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, lane_value)},
                                .payload = slot,
                                .opcode = MACHINE_X64_MOVQ_TO_XMM,
                            });
                        }
                        else
                        {
                            machine_x64_select_row(selector, (MachineInstruction){
                                .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, machine_x64_argument_register(true, slot)),
                                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, lane_value)},
                                .opcode = MACHINE_X64_MOV_RR,
                            });
                        }
                    }
                }
                continue;
            }
            if (shape->indirect)
            {
                // Pointer arguments stage after every floating bridge, just
                // like scalar integer arguments.
                if (!float_pass)
                {
                    u32 register_parts = shape->vector_part_bytes ? placement->register_part_count : 1u;
                    for (u32 part = 0; part < register_parts; part += 1)
                    {
                        u32 pointer = shape->vector_part_bytes ? windows_argument_parts[next_integer + part]
                                                               : plan->argument_registers[argument_index];
                        machine_x64_select_row(selector, (MachineInstruction){
                            .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                         machine_x64_argument_register(plan->windows_call, next_integer + part)),
                                         machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer)},
                            .opcode = MACHINE_X64_MOV_RR,
                        });
                    }
                }
                continue;
            }
            if (shape->vector)
            {
                if (float_pass)
                {
                    // The whole 512-bit value takes its SSE-sequence register;
                    // the allocator relocates the source into that exact ZMM,
                    // so no later staging row can disturb an already placed one.
                    machine_x64_select_row(selector,
                                           (MachineInstruction){
                                               .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_ZMM0 + next_float),
                                                            machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                                               .opcode = MACHINE_X64_VMOV_RR,
                                           });
                    call_vector_registers = true;
                }
                continue;
            }
            if (shape->vector_part_bytes)
            {
                if (float_pass)
                {
                    for (u32 part = 0; part < shape->part_count; part += 1)
                    {
                        machine_x64_select_vector_frame_part(selector, true, MACHINE_X64_ZMM0 + next_float + part,
                                                             plan->argument_slots[argument_index], part * shape->vector_part_bytes,
                                                             shape->vector_part_bytes);
                    }
                    call_vector_registers |= shape->vector_part_bytes >= 32;
                }
                continue;
            }
            if (shape->xmm128)
            {
                if (float_pass)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_ZMM0 + next_float),
                                     machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index])},
                        .opcode = MACHINE_X64_LOAD_XMM_FRAME128,
                    });
                }
                continue;
            }
            if (shape->aggregate)
            {
                for (u32 part_index = 0; part_index < shape->part_count; part_index += 1)
                {
                    bool part_float = shape->part_is_float[part_index] != 0;
                    if (part_float != float_pass)
                    {
                        next_integer += !part_float;
                        next_float += part_float;
                        continue;
                    }
                    if (part_float)
                    {
                        u32 bounce_register = machine_x64_synthesize_register(selector);
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register),
                                                                          machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index])},
                                                             .payload = shape->part_offsets[part_index],
                                                             .opcode = MACHINE_X64_LOAD_FRAME,
                                                         });
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                             .payload = next_float,
                                                             .opcode = MACHINE_X64_MOVQ_TO_XMM,
                                                         });
                        next_float += 1;
                    }
                    else
                    {
                        machine_x64_select_row(selector,
                                               (MachineInstruction){
                                                   .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                                                 machine_x64_argument_register(plan->windows_call, next_integer)),
                                                                machine_ref_make(MACHINE_REF_STACK_SLOT, plan->argument_slots[argument_index])},
                                                   .payload = shape->part_offsets[part_index],
                                                   .opcode = MACHINE_X64_LOAD_FRAME,
                                               });
                        next_integer += 1;
                    }
                }
                continue;
            }
            if (shape->part_is_float[0])
            {
                if (float_pass)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                                                         .payload = next_float,
                                                         .opcode = MACHINE_X64_MOVQ_TO_XMM,
                                                     });
                }
                else if (plan->windows_call && plan->variadic_call)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, machine_x64_argument_register(true, next_integer)),
                                     machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                        .opcode = MACHINE_X64_MOV_RR,
                    });
                }
                continue;
            }
            if (!float_pass)
            {
                u32 target_register = machine_x64_argument_register(plan->windows_call, next_integer);
                // The copy must stay the copy opcode: the allocators stage a
                // copy-into-physical's source in that same register, which is
                // the invariant keeping argument staging clobber-free. The
                // widening then runs in place, physical to physical, where
                // the allocator has nothing left to decide.
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, target_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->argument_registers[argument_index])},
                                                     .opcode = MACHINE_X64_MOV_RR,
                                                 });
                if (shape->scalar_extend_opcode)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, target_register),
                                                                      machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, target_register)},
                                                         .opcode = shape->scalar_extend_opcode,
                                                     });
                }
            }
        }
    }
    return (u16)((plan->variadic_call && !plan->windows_call ? (1u | (plan->float_count << 1)) : 0) |
                 (call_vector_registers ? MACHINE_X64_INSTRUCTION_FLAG_VECTOR_LIVE : 0));
}

// Collects the returned value: an indirect result is already in its slot, an
// aggregate comes back in parts, and a scalar arrives in RAX or XMM0.
BUSTER_GLOBAL_LOCAL bool machine_x64_receive_call_result(MachineX64Selector* selector, IrInstruction* instruction, MachineX64CallPlan* plan,
                                                         u32 result_register)
{
    bool received = true;
    if (instruction->result.value != IR_ID_UNDERLYING_INVALID)
    {
        if (plan->return_shape.f80_result)
        {
            u32 result_slot = selector->value_stack_slots[instruction->result.value];
            received = result_slot != UINT32_MAX;
            if (received)
            {
                for (u32 part = 0; part < plan->return_shape.f80_result; part += 1)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot)}, .payload = part * 16u,
                        .opcode = MACHINE_X64_F80_RESULT_STORE});
                }
            }
        }
        else if (plan->return_shape.indirect)
        {
            // Strongly aligned wide returns use a private buffer because
            // ordinary SSA aggregate slots have only internal alignment.
            // Copy exact object bytes back to the canonical result slot.
            received = plan->indirect_result_slot != UINT32_MAX && plan->indirect_result_pointer != UINT32_MAX;
            if (received && plan->indirect_result_backing_slot != UINT32_MAX)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, plan->indirect_result_slot),
                                 machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan->indirect_result_pointer)},
                    .payload = plan->return_shape.exact_byte_size,
                    .opcode = MACHINE_X64_COPY_FRAME_FROM_PTR,
                });
            }
        }
        else if (plan->return_shape.vector_part_bytes)
        {
            u32 result_slot = selector->value_stack_slots[instruction->result.value];
            received = result_slot != UINT32_MAX;
            for (u32 part = 0; received && part < plan->return_shape.part_count; part += 1)
            {
                machine_x64_select_vector_frame_part(selector, false, MACHINE_X64_ZMM0 + part, result_slot,
                                                     part * plan->return_shape.vector_part_bytes, plan->return_shape.vector_part_bytes);
            }
        }
        else if (plan->return_shape.xmm128)
        {
            u32 result_slot = selector->value_stack_slots[instruction->result.value];
            received = result_slot != UINT32_MAX;
            if (received)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot)},
                    .opcode = MACHINE_X64_STORE_XMM0_FRAME128,
                });
            }
        }
        else if (plan->return_shape.aggregate)
        {
            u32 result_slot = selector->value_stack_slots[instruction->result.value];
            received = result_slot != UINT32_MAX;
            // Capture integer results before floating results: the
            // MOVQ_FROM_XMM bridge uses RAX as its fixed scratch, which
            // would otherwise destroy an integer-class return part that
            // still has to be copied from RAX.
            u32 return_integer_index = 0;
            u32 return_float_index = 0;
            if (received && plan->return_shape.x87_f64_result)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot)},
                    .payload = 24,
                    .opcode = MACHINE_X64_F80_RESULT_STORE,
                });
            }
            for (u32 capture_pass = 0; capture_pass < 2 && received; capture_pass += 1)
            {
                bool float_pass = capture_pass == 1;
                for (u32 part_index = 0; part_index < plan->return_shape.part_count; part_index += 1)
                {
                    if (plan->return_shape.x87_f64_result && part_index == 2)
                    {
                        continue;
                    }
                    bool part_float = plan->return_shape.part_is_float[part_index] != 0;
                    if (part_float != float_pass)
                    {
                        continue;
                    }
                    if (!part_float)
                    {
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                          machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                                                           machine_x64_return_integer_register(return_integer_index))},
                                                             .payload = plan->return_shape.part_offsets[part_index],
                                                             .opcode = machine_x64_frame_store_opcode(
                                                                 machine_x64_shape_part_size(&plan->return_shape, part_index)),
                                                         });
                        return_integer_index += 1;
                        continue;
                    }
                    u32 bounce_register = machine_x64_synthesize_register(selector);
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                         .payload = return_float_index,
                                                         .opcode = MACHINE_X64_MOVQ_FROM_XMM,
                                                     });
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                         .payload = plan->return_shape.part_offsets[part_index],
                                                         .opcode = machine_x64_frame_store_opcode(
                                                             machine_x64_shape_part_size(&plan->return_shape, part_index)),
                                                     });
                    return_float_index += 1;
                }
            }
        }
        else if (result_register == UINT32_MAX)
        {
            received = false;
        }
        else
        {
            u32 row;
            if (plan->return_shape.vector)
            {
                // The 512-bit result arrives in ZMM0 — the call's own
                // vzeroupper fires before the call, never after — and the
                // capture binds in place exactly like a scalar RAX capture.
                row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_ZMM0)},
                                                           .opcode = MACHINE_X64_VMOV_RR,
                                                       });
            }
            else if (plan->return_shape.part_is_float[0])
            {
                row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                           .opcode = MACHINE_X64_MOVQ_FROM_XMM,
                                                       });
            }
            else
            {
                row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX)},
                                                           .opcode = MACHINE_X64_MOV_RR,
                                                       });
            }
            machine_x64_define(selector, result_register, row);
        }
    }
    if (instruction->result.value == IR_ID_UNDERLYING_INVALID && plan->return_shape.f80_result)
    {
        // Ignoring a C result still consumes the callee's x87 stack value.
        u32 discard = machine_x64_append_slot(selector, 16, 16);
        for (u32 part = 0; part < plan->return_shape.f80_result; part += 1)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, discard)}, .opcode = MACHINE_X64_F80_RESULT_STORE});
        }
    }
    else if (instruction->result.value == IR_ID_UNDERLYING_INVALID && plan->return_shape.x87_f64_result)
    {
        u32 discard = machine_x64_append_slot(selector, 8, 8);
        machine_x64_select_row(selector, (MachineInstruction){
            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, discard)},
            .payload = 8,
            .opcode = MACHINE_X64_F80_RESULT_STORE,
        });
    }
    return received;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_call(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    MachineX64CallPlan plan;
    bool selected = machine_x64_plan_call(selector, instruction, &plan);
    if (selected)
    {
        u16 call_flags = machine_x64_stage_call_arguments(selector, &plan);
        if (plan.direct_call)
        {
            u32 target_index =
                machine_x64_call_target(selector, instruction->symbol, machine_x64_symbol_reference(selector, instruction->symbol, true));
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .payload = target_index,
                                                 .opcode = MACHINE_X64_CALL_DIRECT,
                                                 .flags = call_flags,
                                             });
        }
        else
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan.callee_register)},
                                                 .opcode = MACHINE_X64_CALL_INDIRECT,
                                                 .flags = call_flags,
                                             });
        }
        u32 call_stack_release = plan.windows_call ? (selector->dynamic_stack ? plan.outgoing_bytes : 0u)
                                                 : plan.aligned_stack ? 0u : plan.stack_part_count * 8 + (plan.stack_padding ? 8u : 0);
        if (call_stack_release)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .payload = call_stack_release,
                                                 .opcode = MACHINE_X64_ADD_RSP,
                                             });
        }
        selected = machine_x64_receive_call_result(selector, instruction, &plan, result_register);
        if (plan.aligned_stack)
        {
            // Capture RAX/RDX/XMM results before restoring RSP: reloading the
            // saved SSA value is allowed to use those caller-saved registers.
            machine_x64_select_row(selector, (MachineInstruction){
                .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RSP),
                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, plan.saved_stack_register)},
                .opcode = MACHINE_X64_MOV_RR,
            });
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_branch(MachineX64Selector* selector, IrInstruction* instruction)
{
    machine_x64_select_row(selector, (MachineInstruction){
                                         .operands = {machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, instruction->targets[0].value))},
                                         .opcode = MACHINE_X64_JMP,
                                     });
    return true;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_label_address(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    bool selected = result_register != UINT32_MAX && instruction->target_count == 1 && instruction->targets &&
                    instruction->targets[0].value < selector->function->block_count;
    if (selected)
    {
        u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                          .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register)},
                                                          .payload = machine_x64_select_block_entry(selector, instruction->targets[0].value),
                                                          .opcode = MACHINE_X64_LEA_BLOCK,
                                                      });
        machine_x64_define(selector, result_register, row);
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_indirect_branch(MachineX64Selector* selector, IrInstruction* instruction)
{
    bool selected = instruction->operand_count == 1 && instruction->target_count != 0 && instruction->targets;
    u32 target_register = UINT32_MAX;
    if (selected)
    {
        selected = machine_x64_operand_register(selector, instruction->operands[0], &target_register);
    }
    if (selected)
    {
        u32 first_target = selector->switch_cases.total_count;
        for (u32 target_index = 0; target_index < instruction->target_count; target_index += 1)
        {
            if (instruction->targets[target_index].value >= selector->function->block_count)
            {
                selected = false;
                break;
            }
            machine_x64_append_switch_case(selector, (MachineSwitchCase){.target_block = machine_x64_select_block_entry(selector, instruction->targets[target_index].value)});
        }
        if (selected)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, target_register)},
                                                         .payload = first_target,
                                                         .flags = instruction->target_count,
                                                         .opcode = MACHINE_X64_INDIRECT_BRANCH,
                                                     });
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_atomic_read_modify_write(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrProgram* program = selector->program;

    bool selected = false;
    IrType* atomic_type = ir_type_from_id(&program->types, instruction->canonical_type);
    u64 size = atomic_type && atomic_type->layout.resolved ? atomic_type->layout.size : 0;
    if (size == 16)
    {
        IrFunction* function = selector->function;
        u32 result_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
        u32 value_slot = instruction->operand_count >= 2 && instruction->operands[1].value < function->value_count
                             ? selector->value_stack_slots[instruction->operands[1].value]
                             : UINT32_MAX;
        u32 address_register = machine_x64_synthesize_register(selector);
        selected = atomic_type && atomic_type->kind == IR_TYPE_INTEGER && instruction->operand_count >= 2 && result_slot != UINT32_MAX &&
                   value_slot != UINT32_MAX && instruction->atomic_operation < IR_ATOMIC_OPERATION_COUNT &&
                   target_cpu_feature_has(selector->target, TARGET_CPU_FEATURE_X86_CX16) &&
                   machine_x64_select_place_address(selector, instruction->operands[0], address_register);
        if (selected)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                      machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot),
                                                                      machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register)},
                                                         .payload = 16u | ((u32)instruction->atomic_operation << 8),
                                                         .opcode = MACHINE_X64_ATOMIC_RMW16,
                                                     });
        }
    }
    else
    {
        u32 value_register;
        if (result_register != UINT32_MAX && instruction->operand_count >= 2 &&
            machine_x64_operand_register(selector, instruction->operands[1], &value_register) &&
            instruction->atomic_operation < IR_ATOMIC_OPERATION_COUNT)
        {
            if (size == 1 || size == 2 || size == 4 || size == 8)
            {
                u32 address_register = machine_x64_synthesize_register(selector);
                if (machine_x64_select_place_address(selector, instruction->operands[0], address_register))
                {
                    u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                                   .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                                                                                machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                                   .payload = (u32)size | ((u32)instruction->atomic_operation << 8),
                                                                   .opcode = MACHINE_X64_ATOMIC_RMW,
                                                               });
                    machine_x64_define(selector, result_register, row);
                    selected = true;
                }
            }
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_atomic_compare_exchange(MachineX64Selector* selector, IrInstruction* instruction, u32 result_register)
{
    IrProgram* program = selector->program;
    IrFunction* function = selector->function;

    bool selected = false;
    IrType* atomic_type = ir_type_from_id(&program->types, instruction->canonical_type);
    u64 size = atomic_type && atomic_type->layout.resolved ? atomic_type->layout.size : 0;
    u32 address_register = machine_x64_synthesize_register(selector);
    if (size == 16)
    {
        // CMPXCHG16B consumes and produces two eightbyte values. Keep
        // all three value images in frame slots; only the address is a
        // virtual register and is constrained to slot 3 (RSI), leaving
        // RAX/RDX/RBX/RCX wholly available to the instruction's implicit
        // protocol.
        u32 result_slot = instruction->result.value < function->value_count ? selector->value_stack_slots[instruction->result.value] : UINT32_MAX;
        u32 expected_slot = instruction->operand_count >= 2 && instruction->operands[1].value < function->value_count
                                ? selector->value_stack_slots[instruction->operands[1].value]
                                : UINT32_MAX;
        u32 desired_slot = instruction->operand_count >= 3 && instruction->operands[2].value < function->value_count
                               ? selector->value_stack_slots[instruction->operands[2].value]
                               : UINT32_MAX;
        selected = target_cpu_feature_has(selector->target, TARGET_CPU_FEATURE_X86_CX16) && instruction->operand_count >= 3 &&
                   result_slot != UINT32_MAX && expected_slot != UINT32_MAX && desired_slot != UINT32_MAX &&
                   machine_x64_select_place_address(selector, instruction->operands[0], address_register);
        if (selected)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                       .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, result_slot),
                                                                    machine_ref_make(MACHINE_REF_STACK_SLOT, expected_slot),
                                                                    machine_ref_make(MACHINE_REF_STACK_SLOT, desired_slot),
                                                                    machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register)},
                                                       .opcode = MACHINE_X64_ATOMIC_CMPXCHG16,
                                                   });
            u32 success_register = machine_x64_synthesize_register(selector);
            u32 success_row = machine_x64_select_row(selector, (MachineInstruction){
                                                                  .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, success_register)},
                                                                  .payload = MACHINE_X64_CONDITION_EQUAL,
                                                                  .opcode = MACHINE_X64_SETCC,
                                                              });
            machine_x64_define(selector, success_register, success_row);
            selector->atomic_success_registers[instruction->result.value] = success_register;
        }
    }
    else
    {
        // Both are read only where the lookups that fill them succeeded.
        u32 expected_register = UINT32_MAX;
        u32 desired_register = UINT32_MAX;
        selected = result_register != UINT32_MAX && instruction->operand_count >= 3 && (size == 1 || size == 2 || size == 4 || size == 8) &&
                   machine_x64_operand_register(selector, instruction->operands[1], &expected_register) &&
                   machine_x64_operand_register(selector, instruction->operands[2], &desired_register) &&
                   machine_x64_select_place_address(selector, instruction->operands[0], address_register);
        if (selected)
        {
            u32 row = machine_x64_select_row(selector, (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, result_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, expected_register),
                                                                        machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, desired_register)},
                                                           .payload = (u32)size,
                                                           .opcode = MACHINE_X64_ATOMIC_CMPXCHG,
                                                       });
            machine_x64_define(selector, result_register, row);
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_atomic_fence(MachineX64Selector* selector, IrInstruction* instruction)
{
    if (!instruction->atomic_signal_fence && instruction->memory_order == IR_MEMORY_ORDER_SEQUENTIAL)
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .opcode = MACHINE_X64_MFENCE,
                                         });
    }
    return true;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_unreachable(MachineX64Selector* selector)
{
    // Control never reaches this terminator; ud2 keeps the block
    // verifier-well-formed, faults loudly if control ever arrives, and
    // matches the canonical bytes.
    machine_x64_select_row(selector, (MachineInstruction){
                                         .opcode = MACHINE_X64_UD2,
                                     });
    return true;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_switch(MachineX64Selector* selector, IrInstruction* instruction)
{
    u32 condition_register;
    bool selected = false;
    if (machine_x64_operand_register(selector, instruction->operands[0], &condition_register) && instruction->target_count &&
        instruction->target_count == instruction->immediate_count + 1 && instruction->immediates)
    {
        u16 compare_width = 64;
        if (instruction->operands[0].value < selector->function->value_count)
        {
            MachineTypeClass condition_class =
                machine_x64_type_class(selector, selector->function->values[instruction->operands[0].value].canonical_type);
            // An integer at most 32 bits wide is one the class does not call
            // wide.
            if (condition_class.kind == IR_TYPE_BOOLEAN ||
                (condition_class.kind == IR_TYPE_INTEGER && !(condition_class.flags & MACHINE_TYPE_CLASS_WIDE)))
            {
                compare_width = 32;
            }
        }
        u32 first_case = selector->switch_cases.total_count;
        for (u32 case_index = 0; case_index < instruction->immediate_count; case_index += 1)
        {
            machine_x64_append_switch_case(selector, (MachineSwitchCase){
                                                         .value = instruction->immediates[case_index],
                                                         .target_block = machine_x64_select_block_entry(selector, instruction->targets[case_index].value),
                                                         .compare_width = compare_width,
                                                     });
        }
        machine_x64_select_row(selector, (MachineInstruction){
                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, condition_register),
                                                          machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, instruction->targets[instruction->target_count - 1].value))},
                                             .payload = first_case,
                                             .opcode = MACHINE_X64_SWITCH,
                                             .flags = (u16)instruction->immediate_count,
                                         });
        selected = true;
    }
    return selected;
}

// A fused condition re-selects the chain's innermost comparison here,
// immediately before JCC: only allocator edits can land between the flags
// define and its use, and every edit form is a flag-preserving mov (frame
// load/store, reg copy, movabs remat).
BUSTER_GLOBAL_LOCAL bool machine_x64_select_fused_branch(MachineX64Selector* selector, IrInstruction* instruction, MachineX64BranchFusion* fusion)
{
    bool selected = false;
    u32 left_register;
    u32 right_register;
    if (machine_x64_operand_register(selector, (IrValueId){.value = fusion->left}, &left_register))
    {
        selected = true;
        if (fusion->right != UINT32_MAX)
        {
            selected = machine_x64_operand_register(selector, (IrValueId){.value = fusion->right}, &right_register);
            if (selected)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, right_register)},
                                                     .opcode = (u16)(fusion->wide ? MACHINE_X64_CMP64 : MACHINE_X64_CMP32),
                                                 });
            }
        }
        else
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, left_register)},
                                                 .opcode = MACHINE_X64_TEST_RR,
                                             });
        }
        if (selected)
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, instruction->targets[0].value)),
                                                              machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, instruction->targets[1].value))},
                                                 .payload = fusion->condition,
                                                 .opcode = MACHINE_X64_JCC,
                                             });
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_branch_if(MachineX64Selector* selector, IrInstruction* instruction)
{
    bool selected = false;
    MachineX64BranchFusion* fusion = selector->branch_fusions + selector->current_block;
    if (fusion->condition && fusion->condition_value == instruction->operands[0].value)
    {
        selected = machine_x64_select_fused_branch(selector, instruction, fusion);
    }
    else
    {
        u32 condition_register;
        if (machine_x64_operand_register(selector, instruction->operands[0], &condition_register))
        {
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, condition_register),
                                                              machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, condition_register)},
                                                 .opcode = MACHINE_X64_TEST_RR,
                                             });
            machine_x64_select_row(selector, (MachineInstruction){
                                                 .operands = {machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, instruction->targets[0].value)),
                                                              machine_ref_make(MACHINE_REF_BLOCK, machine_x64_select_block_entry(selector, instruction->targets[1].value))},
                                                 .payload = MACHINE_X64_CONDITION_NOT_EQUAL,
                                                 .opcode = MACHINE_X64_JCC,
                                             });
            selected = true;
        }
    }
    return selected;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_select_return(MachineX64Selector* selector, IrInstruction* instruction)
{
    IrFunction* function = selector->function;

    bool selected = true;
    if (instruction->operand_count)
    {
        u32 value_slot = instruction->operands[0].value < function->value_count ? selector->value_stack_slots[instruction->operands[0].value] : UINT32_MAX;
        if (selector->return_shape.f80_result)
        {
            selected = value_slot != UINT32_MAX;
            if (selected)
            {
                for (u32 part = selector->return_shape.f80_result; part > 0; part -= 1)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot)}, .payload = (part - 1u) * 16u,
                        .opcode = MACHINE_X64_F80_RESULT_LOAD});
                }
            }
        }
        else if (selector->return_shape.indirect)
        {
            selected = value_slot != UINT32_MAX && selector->hidden_return_slot != UINT32_MAX;
            if (selected)
            {
                u32 pointer_register = machine_x64_synthesize_register(selector);
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer_register),
                                                                  machine_ref_make(MACHINE_REF_STACK_SLOT, selector->hidden_return_slot)},
                                                     .opcode = MACHINE_X64_LOAD_FRAME,
                                                 });
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer_register),
                                                                  machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot)},
                                                     .payload = selector->return_shape.exact_byte_size ? selector->return_shape.exact_byte_size
                                                                                                       : selector->return_shape.byte_size,
                                                     .opcode = MACHINE_X64_COPY_PTR_FROM_FRAME,
                                                 });
                // The System V contract returns the hidden pointer in RAX.
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer_register)},
                                                     .opcode = MACHINE_X64_MOV_RR,
                                                 });
            }
        }
        else if (selector->return_shape.vector_part_bytes)
        {
            selected = value_slot != UINT32_MAX;
            for (u32 part = 0; selected && part < selector->return_shape.part_count; part += 1)
            {
                machine_x64_select_vector_frame_part(selector, true, MACHINE_X64_ZMM0 + part, value_slot,
                                                     part * selector->return_shape.vector_part_bytes, selector->return_shape.vector_part_bytes);
            }
        }
        else if (selector->return_shape.xmm128)
        {
            selected = value_slot != UINT32_MAX;
            if (selected)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot)},
                    .opcode = MACHINE_X64_LOAD_XMM0_FRAME128,
                });
            }
        }
        else if (selector->return_shape.aggregate)
        {
            selected = value_slot != UINT32_MAX;
            if (selected)
            {
                // Populate floating return registers first: MOVQ_TO_XMM uses
                // RAX as its bridge. Materialize every integer part before
                // publishing the fixed return registers, then write RDX/RCX
                // before RAX. MIR_STACK reloads a virtual value through RAX;
                // writing RAX last keeps those reloads from destroying lane 0.
                u32 return_integer_values[4] = {0};
                u32 return_integer_count = 0;
                u32 return_float_index = 0;
                for (u32 populate_pass = 0; populate_pass < 2; populate_pass += 1)
                {
                    bool float_pass = populate_pass == 0;
                    for (u32 part_index = 0; part_index < selector->return_shape.part_count; part_index += 1)
                    {
                        if (selector->return_shape.x87_f64_result && part_index == 2)
                        {
                            continue;
                        }
                        bool part_float = selector->return_shape.part_is_float[part_index] != 0;
                        if (part_float != float_pass)
                        {
                            continue;
                        }
                        if (!part_float)
                        {
                            return_integer_values[return_integer_count] = machine_x64_select_frame_scalar_load(
                                selector, value_slot, selector->return_shape.part_offsets[part_index],
                                machine_x64_shape_part_size(&selector->return_shape, part_index));
                            return_integer_count += 1;
                            continue;
                        }
                        u32 bounce_register = machine_x64_select_frame_scalar_load(selector, value_slot,
                            selector->return_shape.part_offsets[part_index],
                            machine_x64_shape_part_size(&selector->return_shape, part_index));
                        machine_x64_select_row(selector, (MachineInstruction){
                                                             .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                             .payload = return_float_index,
                                                             .opcode = MACHINE_X64_MOVQ_TO_XMM,
                                                         });
                        return_float_index += 1;
                    }
                }
                for (u32 return_integer_index = return_integer_count; return_integer_index > 1; return_integer_index -= 1)
                {
                    u32 value_index = return_integer_index - 1;
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                                                       machine_x64_return_integer_register(value_index)),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER,
                                                                                       return_integer_values[value_index])},
                                                         .opcode = MACHINE_X64_MOV_RR,
                                                     });
                }
                if (return_integer_count)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                                                         .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX),
                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, return_integer_values[0])},
                                                         .opcode = MACHINE_X64_MOV_RR,
                                                     });
                }
                if (selector->return_shape.x87_f64_result)
                {
                    machine_x64_select_row(selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, value_slot)},
                        .payload = 24,
                        .opcode = MACHINE_X64_F80_RESULT_LOAD,
                    });
                }
            }
        }
        else
        {
            u32 value_register;
            selected = machine_x64_operand_register(selector, instruction->operands[0], &value_register);
            if (selected && selector->return_shape.vector)
            {
                // The 512-bit result leaves in ZMM0 and stays live through
                // the return row, whose vzeroupper the flag below suppresses.
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_ZMM0),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                     .opcode = MACHINE_X64_VMOV_RR,
                                                 });
            }
            else if (selected && selector->return_shape.part_is_float[0])
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                     .opcode = MACHINE_X64_MOVQ_TO_XMM,
                                                 });
            }
            else if (selected)
            {
                machine_x64_select_row(selector, (MachineInstruction){
                                                     .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX),
                                                                  machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value_register)},
                                                     .opcode = MACHINE_X64_MOV_RR,
                                                 });
            }
        }
    }
    if (selected)
    {
        machine_x64_select_row(selector, (MachineInstruction){
                                             .opcode = MACHINE_X64_RET,
                                             .flags = (u16)(instruction->operand_count && (selector->return_shape.vector || selector->return_shape.vector_part_bytes >= 32)
                                                                ? MACHINE_X64_INSTRUCTION_FLAG_VECTOR_LIVE
                                                                : 0),
                                         });
    }
    return selected;
}

// The rows the alias sweeps and the branch-fusion pass act on.  Everything
// else those passes visited only to fall through, so the prepass walk records
// where these sit and the two passes read that list instead of the rows.
#define MACHINE_X64_CANDIDATE_OPCODES                                                                                                  \
    (IR_OPCODE_BIT(IR_OPCODE_LOAD) | IR_OPCODE_BIT(IR_OPCODE_STORE) | IR_OPCODE_BIT(IR_OPCODE_DEREFERENCE) |                           \
     IR_OPCODE_BIT(IR_OPCODE_BRANCH_IF))

// A candidate's absolute row and the ordinal the walk gave it. Recording the
// block-relative offset instead made each of the 1,28 M candidate visits
// below rebuild both numbers: a `layout_rows ?` select, a load or a block-base
// add for the row, and a block-base add for the ordinal, all from state the
// walk was holding when it wrote the entry.
typedef struct MachineX64CandidateRow MachineX64CandidateRow;
struct MachineX64CandidateRow
{
    u32 row;
    u32 ordinal;
};

#include <buster/lib/compiler/codegen/machine_x86_64_predicate.c>

MachineSelectResult machine_select_canonical_function_x86_64(Arena* arena, IrProgram* program, IrFunction* function, Target target,
                                                              bool position_independent, bool assume_validated, bool predicate_residency,
                                                              bool preserve_debug_values, MachineSelectionModule* module)
{
    MachineSelectResult result = {
        .failed_opcode = IR_OPCODE_COUNT,
    };
    if (!arena || !program || !function || target.cpu_arch != CPU_ARCH_X86_64 || function->state != IR_FUNCTION_LOWERED || !function->block_count ||
        function->entry.value != 0)
    {
        return result;
    }
    IrType* function_type = ir_type_from_id(&program->types, function->canonical_type);
    if (!function_type || function_type->kind != IR_TYPE_FUNCTION)
    {
        return result;
    }
    result.signature_rejected = true;
    IrType* return_type = ir_type_from_id(&program->types, function_type->return_type);
    bool returns_value = return_type && return_type->kind != IR_TYPE_VOID;
    MachineX64ValueShape signature_return_shape = {0};
    if (returns_value && !machine_x64_value_shape(program, function_type->return_type, IR_ABI_USE_RESULT, target, &signature_return_shape))
    {
        return result;
    }
    MachineX64ValueShape* signature_parameter_shapes = arena_allocate(arena, MachineX64ValueShape, function_type->parameter_count);
    MachineX64ArgumentPlacement* signature_parameter_placements = arena_allocate(arena, MachineX64ArgumentPlacement, function_type->parameter_count);
    bool windows_abi = machine_x64_target_is_windows(target);
    u32 signature_integer_count = signature_return_shape.indirect ? 1 : 0;
    u32 signature_float_count = signature_return_shape.indirect && windows_abi ? 1 : 0;
    u32 signature_stack_count = 0;
    for (u32 parameter_index = 0; parameter_index < function_type->parameter_count; parameter_index += 1)
    {
        if (!machine_x64_value_shape(program, function_type->parameter_types[parameter_index], IR_ABI_USE_ARGUMENT, target,
                                     signature_parameter_shapes + parameter_index) ||
            !machine_x64_argument_area_fits(signature_parameter_shapes + parameter_index, signature_stack_count))
        {
            return result;
        }
        machine_x64_place_argument(signature_parameter_shapes + parameter_index, windows_abi, &signature_integer_count, &signature_float_count,
                                   &signature_stack_count, signature_parameter_placements + parameter_index);
    }
    result.signature_rejected = false;
    if (!module)
    {
        // The unvalidated entry point carries no module context; one
        // prepared here for this function alone answers the same questions.
        module = machine_select_module_prepare(arena, program, target);
    }
    MachineX64Selector selector = {
        .arena = arena,
        .program = program,
        .function = function,
        .builder = machine_function_builder_begin(arena),
        .target = target,
        .vector_registers_supported = ir_simd_operation_supported(target, IR_SIMD_SPLAT_BYTE),
        .module = module,
        .type_classes = module->type_classes,
        .type_class_count = module->type_count,
        .address_cache = {.type_classes = module->type_classes, .type_count = module->type_count},
        .position_independent = position_independent,
        .supported = true,
        .dynamic_stack = ir_function_may_contain_opcodes(function, IR_OPCODE_BIT(IR_OPCODE_STACK_ALLOCATE) | IR_OPCODE_BIT(IR_OPCODE_STACK_RESTORE)),
        .failed_opcode = IR_OPCODE_COUNT,
    };
    if (!assume_validated && machine_selection_validate_function(arena, program, function) != MACHINE_SELECTION_VALIDATION_NONE)
    {
        return result;
    }
    // Every per-value fact the prepasses and the row path read, in one arena
    // block with two regions: one that rests at zero and one that rests at
    // "none" (UINT32_MAX), so two memsets replace the per-array fills, and
    // the arrays a pass reads together sit together. The atomic-success map
    // exists only for a function whose opcode summary admits the exchange,
    // and the alias list is written before it is read.
    u32 value_capacity = function->value_count ? function->value_count : 1;
    u32 block_capacity = function->block_count ? function->block_count : 1;
    bool may_hold_atomic_exchange = ir_function_may_contain_opcodes(function, IR_OPCODE_BIT(IR_OPCODE_ATOMIC_COMPARE_EXCHANGE));
    u64 zero_region_bytes = (u64)value_capacity * (sizeof(MachineX64ValueUse) + sizeof(u32) + 2 * sizeof(u8)) +
                            (u64)block_capacity * sizeof(MachineX64BranchFusion);
    zero_region_bytes = (zero_region_bytes + 15) & ~(u64)15;
    u64 none_region_bytes = (u64)value_capacity * sizeof(u32) * (may_hold_atomic_exchange ? 6 : 5);
    u8* value_block = (u8*)arena_allocate_bytes(arena, zero_region_bytes + none_region_bytes + (u64)value_capacity * sizeof(u32), 16);
    memset(value_block, 0, zero_region_bytes);
    memset(value_block + zero_region_bytes, 0xff, none_region_bytes);
    MachineX64ValueUse* value_uses = (MachineX64ValueUse*)value_block;
    u32* value_def_ordinals = (u32*)(value_uses + value_capacity);
    selector.branch_fusions = (MachineX64BranchFusion*)(value_def_ordinals + value_capacity);
    selector.fused_dead = (u8*)(selector.branch_fusions + block_capacity);
    selector.place_kinds = selector.fused_dead + value_capacity;
    selector.value_virtual_registers = (u32*)(value_block + zero_region_bytes);
    selector.value_stack_slots = selector.value_virtual_registers + value_capacity;
    selector.value_indirect_slots = selector.value_stack_slots + value_capacity;
    u32* value_def_blocks = selector.value_indirect_slots + value_capacity;
    u32* load_aliases = value_def_blocks + value_capacity;
    selector.atomic_success_registers = may_hold_atomic_exchange ? load_aliases + value_capacity : 0;
    u32* alias_values = (u32*)(value_block + zero_region_bytes + none_region_bytes);
    machine_stream_initialize(&selector.immediates, sizeof(u64));
    machine_stream_initialize(&selector.stack_slots, sizeof(MachineX64StackSlot));
    machine_stream_initialize(&selector.call_targets, sizeof(MachineX64CallTarget));
    machine_stream_initialize(&selector.switch_cases, sizeof(MachineSwitchCase));
    machine_stream_initialize(&selector.va_args, sizeof(MachineVaArg));
    machine_stream_initialize(&selector.inline_assemblies, sizeof(MachineInlineAssembly));
    machine_stream_initialize(&selector.inline_assembly_operands, sizeof(MachineInlineAssemblyOperand));
    machine_stream_initialize(&selector.inline_assembly_relocations, sizeof(MachineInlineAssemblyRelocation));
    selector.return_shape = signature_return_shape;
    selector.hidden_return_slot = UINT32_MAX;
    selector.va_register_save_slot = UINT32_MAX;
    selector.outgoing_slot = UINT32_MAX;
    if (signature_return_shape.indirect)
    {
        selector.hidden_return_slot = machine_x64_append_slot(&selector, 8, 8);
    }
    if (function_type->is_variadic && !windows_abi)
    {
        // SysV's va_list points at a fixed 176-byte register save area.  A
        // dedicated frame slot keeps its displacement in ordinary placement
        // data while VA_SAVE owns the prologue snapshot itself.
        selector.va_register_save_slot = machine_x64_append_slot(&selector, 176, 16);
    }
    selector.parameter_shapes = signature_parameter_shapes;
    selector.parameter_placements = signature_parameter_placements;
    selector.parameter_count = function_type->parameter_count;
    selector.argument_values = arena_allocate(arena, u32, function_type->parameter_count);
    for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
    {
        u32 parameter_count = 0;
        IrCfgBlock const* published_block = function->published_cfg->blocks + block_index;
        for (u32 parameter_index = 0; parameter_index < published_block->parameter_count; parameter_index += 1)
        {
            IrCfgParameter const* parameter = function->published_cfg->parameters + published_block->parameter_offset + parameter_index;
            MachineTypeClass parameter_class = machine_x64_type_class(&selector, parameter->canonical_type);
            bool windows_va_list = machine_x64_type_is_windows_va_list(ir_type_from_id(&program->types, parameter->canonical_type), target);
            bool wide = (parameter_class.flags & MACHINE_TYPE_CLASS_INTEGER128) != 0 ||
                        machine_x64_type_is_f80(&selector, parameter->canonical_type) ||
                        (parameter_class.kind == IR_TYPE_VECTOR && (parameter_class.flags & MACHINE_TYPE_CLASS_RESOLVED) &&
                         parameter_class.size_log2 <= 4);
            bool vector = selector.vector_registers_supported && (parameter_class.flags & MACHINE_TYPE_CLASS_VECTOR_REGISTER);
            if (parameter->value.value >= function->value_count ||
                (!wide && !vector && !windows_va_list &&
                 !(parameter_class.flags & (MACHINE_TYPE_CLASS_SCALAR_REGISTER | MACHINE_TYPE_CLASS_FLOAT_SCALAR))))
            {
                return result;
            }
            parameter_count += wide ? 2u : 1u;
            if (parameter_count > UINT16_MAX)
            {
                return result;
            }
            if (wide)
            {
                if (!machine_builder_canonical_pair_parameter(&selector.builder, function, published_block, parameter_index, &selector.value_pairs))
                {
                    return result;
                }
                selector.value_stack_slots[parameter->value.value] = machine_x64_append_slot(&selector, 16, 16);
            }
            else
            {
                selector.value_virtual_registers[parameter->value.value] =
                    machine_builder_virtual_register(&selector.builder, (MachineVirtualRegister){
                                                                             .definition_point = MACHINE_POINT_INVALID,
                                                                             .register_class = vector ? MACHINE_REGISTER_CLASS_VECTOR : MACHINE_REGISTER_CLASS_GENERAL,
                                                                             .typed_origin = parameter->value.value,
                                                                         });
            }
            // Block parameters are values defined by incoming edges. They
            // have no instruction for the opcode classifier below to visit,
            // but pointer parameters still supply INDEX bases.
            selector.place_kinds[parameter->value.value] = MACHINE_X64_PLACE_OTHER;
            value_def_blocks[parameter->value.value] = function->blocks[block_index].id.value;
        }
    }
    for (u32 argument_index = 0; argument_index < selector.parameter_count; argument_index += 1)
    {
        selector.argument_values[argument_index] = IR_ID_UNDERLYING_INVALID;
    }
    // Local promotion, the mem2reg the machine path was built for: a
    // scalar local whose address never leaves a load or a store needs no
    // memory at all. Eligibility by type is derived from the stable
    // value-definition table while the target-order arrays below are
    // initialized; disqualification still happens on every use that is not
    // the place operand of a same-width scalar load or store: a field or
    // index selection, an address handed to a call, a mixed-width access,
    // and the atomic forms all keep the local in its slot. The byte size
    // is recorded so the width check needs no second type walk.
    //
    // The value-wide form rejected by the 2026-08-22T084855Z survey did a
    // random row fetch for every value. local_places is the producer-owned
    // sparse population instead: one entry per source local, then one
    // definition fetch for the small set that still owns a canonical place.
    // Hand-built IR without that projection keeps the row scan as a
    // compatibility fallback.
    bool sparse_local_projection = function->local_places ||
                                   ((function->opcode_summary & IR_OPCODE_SUMMARY_KNOWN) && function->local_count == 0);
    u32 local_capacity = sparse_local_projection ? function->local_count : function->value_count;
    MachineX64LocalUse* local_uses = arena_allocate(arena, MachineX64LocalUse, (u64)local_capacity + 1);
    local_uses[0] = (MachineX64LocalUse){0};
    u32 local_use_count = 1;
    if (!program->disable_target_local_promotion && sparse_local_projection)
    {
        for (u32 local_index = 0; local_index < function->local_count; local_index += 1)
        {
            IrValueId place = function->local_places[local_index];
            if (place.value >= function->value_count)
            {
                continue;
            }
            IrInstructionId definition = function->values[place.value].definition;
            if (definition.value >= function->instruction_count)
            {
                continue;
            }
            IrInstruction* instruction = function->instructions + definition.value;
            // Preserve the old row/value round trip: a popped row may retain
            // LOCAL in its storage, but only the value's live definition is
            // eligible.
            if (instruction->opcode != IR_OPCODE_LOCAL || instruction->result.value != place.value)
            {
                continue;
            }
            MachineTypeClass local_class = machine_x64_type_class(&selector, function->values[place.value].canonical_type);
            u32 width = 0;
            if ((local_class.flags & MACHINE_TYPE_CLASS_SCALAR_REGISTER) && (local_class.size_log2 == 2 || local_class.size_log2 == 3))
            {
                width = 1u << local_class.size_log2;
            }
            else if ((local_class.flags & MACHINE_TYPE_CLASS_VECTOR_REGISTER) && selector.vector_registers_supported)
            {
                width = 64;
            }
            if (width)
            {
                local_uses[local_use_count] = (MachineX64LocalUse){.value = place.value, .width = width};
                value_uses[place.value].local_use = local_use_count++;
            }
        }
    }
    else if (!program->disable_target_local_promotion)
    {
        for (u32 instruction_index = 0; instruction_index < function->instruction_count; instruction_index += 1)
        {
            IrInstruction* instruction = function->instructions + instruction_index;
            if (instruction->opcode != IR_OPCODE_LOCAL || instruction->result.value >= function->value_count ||
                function->values[instruction->result.value].definition.value != instruction_index)
            {
                continue;
            }
            u32 value_index = instruction->result.value;
            MachineTypeClass local_class = machine_x64_type_class(&selector, function->values[value_index].canonical_type);
            u32 width = 0;
            if ((local_class.flags & MACHINE_TYPE_CLASS_SCALAR_REGISTER) && (local_class.size_log2 == 2 || local_class.size_log2 == 3))
            {
                width = 1u << local_class.size_log2;
            }
            else if ((local_class.flags & MACHINE_TYPE_CLASS_VECTOR_REGISTER) && selector.vector_registers_supported)
            {
                width = 64;
            }
            if (width)
            {
                local_uses[local_use_count] = (MachineX64LocalUse){.value = value_index, .width = width};
                value_uses[value_index].local_use = local_use_count++;
            }
        }
    }
    // Canonical publication owns instruction spans. This pass gathers value
    // facts and candidate rows for aliasing/fusion without rebuilding row order.
    u32* block_candidate_counts = arena_allocate(arena, u32, function->block_count ? function->block_count : 1);
    MachineX64CandidateRow* candidate_rows =
        arena_allocate(arena, MachineX64CandidateRow, function->instruction_count ? function->instruction_count : 1);
    u32 candidate_count = 0;
    bool nonvolatile_memory = true;
    bool returns_twice_free = true;
    u32 walk_ordinal = 0;
    u32 expanded_blocks = 0;
    for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
    {
        IrBlock* block = function->blocks + block_index;
        u32 block_candidate_count = 0;
        u32 entry_block = expanded_blocks;
        if (expanded_blocks < MACHINE_REF_PAYLOAD_LIMIT)
        {
            expanded_blocks += 1;
        }
        else
        {
            machine_x64_reject(&selector, IR_OPCODE_BINARY);
        }
        for (IrInstructionId id = block->first_instruction; id.value <= block->last_instruction.value; id.value += 1)
        {
            IrInstruction* instruction = function->instructions + id.value;
            nonvolatile_memory &= !instruction->volatile_access;
            returns_twice_free &= !(instruction->opcode == IR_OPCODE_CALL && ir_call_returns_twice(program, instruction));
            if (machine_x64_instruction_is_i128_divide(program, instruction))
            {
                if (!selector.block_entries)
                {
                    selector.block_entries = arena_allocate(arena, u32, function->block_count);
                    selector.block_exits = arena_allocate(arena, u32, function->block_count);
                    for (u32 previous = 0; previous < block_index; previous += 1)
                    {
                        selector.block_entries[previous] = previous;
                        selector.block_exits[previous] = previous;
                    }
                }
                if (expanded_blocks > MACHINE_REF_PAYLOAD_LIMIT - 2)
                {
                    machine_x64_reject(&selector, IR_OPCODE_BINARY);
                }
                else
                {
                    expanded_blocks += 2;
                }
            }
            IrInstructionExtra asm_extra = instruction->opcode == IR_OPCODE_INLINE_ASSEMBLY && instruction->target_count
                                                ? ir_instruction_extra(function, id)
                                                : (IrInstructionExtra){0};
            u32 asm_target = 0;
            bool general_asm_goto = instruction->opcode == IR_OPCODE_INLINE_ASSEMBLY && instruction->target_count &&
                                    asm_extra.literal.length &&
                                    !ir_inline_assembly_jump_target(function, instruction, asm_extra.literal, S8("jmp %l"), &asm_target);
            if (general_asm_goto)
            {
                u32 reference_capacity = 0;
                bool references_valid = machine_selection_assembly_label_reference_capacity(asm_extra.literal, &reference_capacity);
                if (!selector.block_entries)
                {
                    selector.block_entries = arena_allocate(arena, u32, function->block_count);
                    selector.block_exits = arena_allocate(arena, u32, function->block_count);
                    for (u32 previous = 0; previous < block_index; previous += 1)
                    {
                        selector.block_entries[previous] = previous;
                        selector.block_exits[previous] = previous;
                    }
                }
                if (!selector.asm_goto_continuations)
                {
                    selector.asm_goto_continuations = arena_allocate(arena, u32, function->block_count);
                    memset(selector.asm_goto_continuations, 0xff, sizeof(u32) * function->block_count);
                }
                if (!references_valid || instruction->target_count > MACHINE_REF_PAYLOAD_LIMIT - expanded_blocks ||
                    reference_capacity > MACHINE_REF_PAYLOAD_LIMIT - expanded_blocks - instruction->target_count)
                {
                    machine_x64_reject(&selector, IR_OPCODE_INLINE_ASSEMBLY);
                }
                else
                {
                    selector.asm_goto_continuations[block_index] = expanded_blocks;
                    expanded_blocks += instruction->target_count + reference_capacity;
                }
            }
            if (instruction->opcode == IR_OPCODE_CALL && instruction->operand_count)
            {
                selector.call_argument_capacity = BUSTER_MAX(selector.call_argument_capacity, instruction->operand_count - 1u);
            }
            if ((MACHINE_X64_CANDIDATE_OPCODES >> instruction->opcode) & 1)
            {
                // `walk_ordinal` is still this row's predecessor count here,
                // so the row's own ordinal is one past it -- the same number
                // the offset form rebuilt as `block base + offset + 1`.
                candidate_rows[candidate_count] = (MachineX64CandidateRow){.row = id.value, .ordinal = walk_ordinal + 1};
                candidate_count += 1;
                block_candidate_count += 1;
            }
            walk_ordinal += 1;
            if (instruction->result.value != IR_ID_UNDERLYING_INVALID && instruction->result.value < function->value_count)
            {
                value_def_ordinals[instruction->result.value] = walk_ordinal;
                value_def_blocks[instruction->result.value] = block->id.value;
            }
            for (u32 operand_index = 0; operand_index < instruction->operand_count; operand_index += 1)
            {
                u32 used = instruction->operands[operand_index].value;
                if (used >= function->value_count)
                {
                    continue;
                }
                // A direct CALL names its function on the call row. Its
                // function-value operand is not an address use; counting it
                // would keep a dead LEA/GOT load and its relocation alive.
                bool direct_symbol_callee = operand_index == 0 && instruction->opcode == IR_OPCODE_CALL &&
                                            instruction->symbol.value != IR_ID_UNDERLYING_INVALID;
                if (direct_symbol_callee)
                {
                    IrInstructionId definition = function->values[used].definition;
                    direct_symbol_callee = definition.value < function->instruction_count &&
                                           function->instructions[definition.value].opcode == IR_OPCODE_FUNCTION &&
                                           function->instructions[definition.value].symbol.value == instruction->symbol.value;
                }
                if (direct_symbol_callee)
                {
                    continue;
                }
                MachineX64ValueUse* use = value_uses + used;
                use->use_count += 1;
                if (use->use_block == 0)
                {
                    use->use_block = block->id.value + 1;
                }
                else if (use->use_block != block->id.value + 1)
                {
                    use->use_block = MACHINE_SELECTION_MULTIPLE_BLOCKS;
                }
                use->last_use_ordinal = walk_ordinal;
                if (!use->local_use)
                {
                    continue;
                }
                // A same-width access: the promotable widths are powers of
                // two, so a register-class access of any other size cannot
                // match and reads as no size at all.
                bool place_use = false;
                if (operand_index == 0 && instruction->opcode == IR_OPCODE_LOAD)
                {
                    MachineTypeClass access_class = machine_x64_type_class(&selector, instruction->canonical_type);
                    place_use = !instruction->volatile_access &&
                                (access_class.flags & (MACHINE_TYPE_CLASS_SCALAR_REGISTER | MACHINE_TYPE_CLASS_VECTOR_REGISTER)) &&
                                access_class.size_log2 != MACHINE_TYPE_CLASS_NO_LOG2 && (1u << access_class.size_log2) == local_uses[use->local_use].width;
                }
                else if (operand_index == 0 && instruction->opcode == IR_OPCODE_STORE && instruction->operand_count >= 2 &&
                         instruction->operands[1].value < function->value_count)
                {
                    MachineTypeClass access_class = machine_x64_type_class(&selector, function->values[instruction->operands[1].value].canonical_type);
                    place_use = !instruction->volatile_access &&
                                (access_class.flags & (MACHINE_TYPE_CLASS_SCALAR_REGISTER | MACHINE_TYPE_CLASS_VECTOR_REGISTER)) &&
                                access_class.size_log2 != MACHINE_TYPE_CLASS_NO_LOG2 && (1u << access_class.size_log2) == local_uses[use->local_use].width;
                    local_uses[use->local_use].store_count += 1;
                }
                if (!place_use)
                {
                    use->local_use = 0;
                }
            }
        }
        if (selector.block_entries)
        {
            selector.block_entries[block_index] = entry_block;
            selector.block_exits[block_index] = expanded_blocks - 1;
        }
        block_candidate_counts[block_index] = block_candidate_count;
    }
    // Block-parameter incoming values are uses on CFG edges rather than row
    // operands. Keep them visible to aliasing and branch fusion: in
    // particular, a comparison that also supplies a promoted local is not a
    // dead condition merely because BRANCH_IF is its only instruction use.
    IrPublishedCfg const* cfg = function->published_cfg;
    for (u32 index = 0; index < cfg->argument_count; index += 1)
    {
        MachineX64ValueUse* use = value_uses + cfg->arguments[index].value;
        use->use_count += 1;
        use->use_block = MACHINE_SELECTION_MULTIPLE_BLOCKS;
        use->last_use_ordinal = walk_ordinal;
    }
    // One line mark per selected row, written by the main loop as it reaches
    // the row; the walk just counted the rows, so the array is exact.
    MachineLineMark* line_marks = arena_allocate(arena, MachineLineMark, walk_ordinal ? walk_ordinal : 1);
    MachineLineMark* line_mark_cursor = line_marks;
    // Load aliasing over the promoted locals. The measured cost of
    // promotion is the copy every load lowers to: its source is the local,
    // which lives on, so the copy never coalesces — one extra register
    // move per read, and a second instruction whenever the local was not
    // resident. A load result whose every use sits in the load's own block
    // before the local's next store *is* the local: it shares the local's
    // virtual register and the load selects into nothing. The block-local
    // requirement is what makes the layout reasoning sound — a jump can
    // only re-enter at a block head, above the load, never between the
    // load and a use.
    // The values the sweeps alias, in assignment order.  About an eighth of a
    // function's values end up aliased, so the pass that hands each one its
    // local's register reads this list — 128 K entries in a self-compile —
    // instead of asking all 1.01 M values whether they have an alias.
    u32 alias_count = 0;
    // Two identical reverse sweeps: the first aliases loads, the second
    // extends each alias through IR_OPCODE_DEREFERENCE, whose selection is
    // a plain pointer copy — an aliased pointer load feeding a dereference
    // used to coalesce because the load temporary died at the copy, and an
    // aliased value never dies, so the chain must collapse at selection or
    // the copy just moves from the load to the address staging. A field or
    // index base folds its offset into a real lea and stops the chain.
    for (u32 alias_sweep = 0; alias_sweep < 2; alias_sweep += 1)
    {
        u32 candidate_base = 0;
        for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
        {
            u32 epoch = alias_sweep * function->block_count + block_index + 1;
            u32 block_candidate_count = block_candidate_counts[block_index];
            // Only the candidate rows can move this sweep: every other opcode
            // leaves the root unrooted and falls straight through, and the
            // candidates are a subsequence, so reversing them is reversing
            // the block.
            for (u32 remaining = block_candidate_count; remaining > 0; remaining -= 1)
            {
                MachineX64CandidateRow candidate_row = candidate_rows[candidate_base + remaining - 1];
                IrInstruction* instruction = function->instructions + candidate_row.row;
                u32 instruction_ordinal = candidate_row.ordinal;
                if (instruction->opcode == IR_OPCODE_STORE && instruction->operand_count >= 1 && instruction->operands[0].value < function->value_count &&
                    value_uses[instruction->operands[0].value].local_use)
                {
                    MachineX64LocalUse* local = local_uses + value_uses[instruction->operands[0].value].local_use;
                    local->next_store_ordinal = instruction_ordinal;
                    local->next_store_epoch = epoch;
                }
                // The rooting local of a candidate: the load's own place,
                // or the alias the previous sweep gave a dereference's
                // pointer operand.
                u32 root = UINT32_MAX;
                if (instruction->opcode == IR_OPCODE_LOAD && instruction->operand_count >= 1 && instruction->operands[0].value < function->value_count &&
                    value_uses[instruction->operands[0].value].local_use)
                {
                    root = instruction->operands[0].value;
                }
                else if (instruction->opcode == IR_OPCODE_DEREFERENCE && instruction->operand_count >= 1 &&
                         instruction->operands[0].value < function->value_count)
                {
                    root = load_aliases[instruction->operands[0].value];
                }
                if (root == UINT32_MAX || instruction->result.value == IR_ID_UNDERLYING_INVALID || instruction->result.value >= function->value_count)
                {
                    continue;
                }
                u32 candidate = instruction->result.value;
                // A single-store local — a saved parameter, an init-once
                // configuration value — never changes after its one store,
                // so every read of it everywhere is the local, uses in
                // other blocks included. Otherwise the reverse walk means
                // next_store already names the nearest store strictly
                // below this row when its epoch stamp is current, and the
                // block-local containment is what keeps the layout
                // reasoning sound: a jump can only re-enter at a block
                // head, above the row, never between it and a use.
                MachineX64LocalUse* local = local_uses + value_uses[root].local_use;
                if (local->store_count == 1 ||
                    (value_uses[candidate].use_block == block_index + 1 &&
                     (local->next_store_epoch != epoch || local->next_store_ordinal > value_uses[candidate].last_use_ordinal)))
                {
                    // The second sweep recomputes the first's load aliases
                    // identically, so the transition is what keeps one value
                    // out of the list twice.
                    if (load_aliases[candidate] == UINT32_MAX)
                    {
                        alias_values[alias_count] = candidate;
                        alias_count += 1;
                    }
                    load_aliases[candidate] = root;
                }
            }
            candidate_base += block_candidate_count;
        }
    }
    // A local with no store has no defining value to seed a mutable virtual
    // register.  This is observable for automatic declarations materialized
    // solely so a later unreachable label can still refer to their storage:
    // the dead read is valid IR, but the object has indeterminate bytes. Keep
    // such a local in its frame slot rather than manufacturing an undefined
    // virtual-register definition.
    for (u32 index = 1; index < local_use_count; index += 1)
    {
        if (local_uses[index].store_count == 0)
        {
            value_uses[local_uses[index].value].local_use = 0;
        }
    }
    selector.call_argument_registers = arena_allocate(arena, u32, selector.call_argument_capacity);
    selector.call_argument_slots = arena_allocate(arena, u32, selector.call_argument_capacity);
    // Classification pass: direct locals become stack slots, every other
    // scalar result becomes a virtual register, in stable value-id order.
    for (u32 block_index = 0; block_index < function->block_count && selector.supported; block_index += 1)
    {
        IrBlock* block = function->blocks + block_index;
        u32 block_row_count = function->published_cfg->blocks[block_index].instruction_count;
        u32 block_first_row = block->first_instruction.value;
        for (u32 row_offset = 0; row_offset < block_row_count; row_offset += 1)
        {
            IrInstruction* instruction = function->instructions + (block_first_row + row_offset);
            if (instruction->result.value == IR_ID_UNDERLYING_INVALID || instruction->result.value >= function->value_count)
            {
                continue;
            }
            IrValue* value = function->values + instruction->result.value;
            selector.place_kinds[instruction->result.value] = (u8)machine_x64_place_kind_of_opcode(instruction->opcode);
            if (instruction->opcode == IR_OPCODE_FUNCTION && !value_uses[instruction->result.value].use_count)
            {
                continue;
            }
            if (instruction->opcode == IR_OPCODE_ARGUMENT && instruction->immediate_count && instruction->immediates &&
                instruction->immediates[0] < selector.parameter_count)
            {
                selector.argument_values[instruction->immediates[0]] = instruction->result.value;
            }
            if (instruction->opcode == IR_OPCODE_LOCAL)
            {
                IrType* local_type = ir_type_from_id(&program->types, value->canonical_type);
                u32 local_alignment = BUSTER_MAX(BUSTER_MAX(value->alignment, local_type ? local_type->layout.alignment : 0), 8u);
                // Vector locals clamp to the frame's sixteen-byte contract
                // exactly like the canonical frame layout: every access is
                // the unaligned vmovdqu8, so the declared 64-byte alignment
                // buys correctness nothing here.
                if (local_type && local_type->kind == IR_TYPE_VECTOR)
                {
                    local_alignment = BUSTER_MIN(local_alignment, 16u);
                }
                if (!local_type || !local_type->layout.resolved || local_type->layout.size > UINT32_MAX - 7)
                {
                    machine_x64_reject(&selector, instruction->opcode);
                    break;
                }
                if (value_uses[instruction->result.value].local_use)
                {
                    // Promoted: the local is a virtual register for its
                    // whole life and never owns a frame slot. Its loads
                    // and stores lower to copies, and its definition point
                    // is patched at the first store like any other
                    // classification vreg. Vector locals promote into the
                    // vector class. Promotion also covers over-aligned
                    // locals: the scan proved no use needs the address, so
                    // the declared alignment is unobservable.
                    selector.value_virtual_registers[instruction->result.value] =
                        machine_builder_virtual_register(&selector.builder, (MachineVirtualRegister){
                                                                                .definition_point = MACHINE_POINT_INVALID,
                                                                                .register_class = local_uses[value_uses[instruction->result.value].local_use].width == 64
                                                                                                      ? MACHINE_REGISTER_CLASS_VECTOR
                                                                                                      : MACHINE_REGISTER_CLASS_GENERAL,
                                                                                .flags = MACHINE_VIRTUAL_REGISTER_FLAG_MUTABLE,
                                                                                .typed_origin = instruction->result.value,
                                                                            });
                    continue;
                }
                if (local_alignment > 16)
                {
                    // Over-aligned local, the canonical frame layout's
                    // shape exactly: a padded raw slot and a pointer
                    // aligned into it at runtime by the LOCAL's own rows.
                    // The slot stays out of value_stack_slots so every
                    // consumer takes the pointer paths a GLOBAL takes.
                    if (local_type->layout.size > UINT32_MAX - 7 - local_alignment)
                    {
                        machine_x64_reject(&selector, instruction->opcode);
                        break;
                    }
                    selector.value_indirect_slots[instruction->result.value] =
                        machine_x64_append_slot(&selector, (u32)((local_type->layout.size + local_alignment - 1 + 7) & ~(u64)7), 8u);
                    selector.value_virtual_registers[instruction->result.value] =
                        machine_builder_virtual_register(&selector.builder, (MachineVirtualRegister){
                                                                                .definition_point = MACHINE_POINT_INVALID,
                                                                                .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                                .typed_origin = instruction->result.value,
                                                                            });
                    continue;
                }
                selector.value_stack_slots[instruction->result.value] =
                    machine_x64_append_slot(&selector, (u32)((local_type->layout.size + 7) & ~(u64)7), local_alignment);
                continue;
            }
            MachineTypeClass value_class = machine_x64_type_class(&selector, value->canonical_type);
            bool windows_va_list = machine_x64_type_is_windows_va_list(ir_type_from_id(&program->types, value->canonical_type), selector.target);
            if ((instruction->opcode == IR_OPCODE_VA_START || instruction->opcode == IR_OPCODE_VA_COPY) && value_class.kind == IR_TYPE_VA_LIST &&
                (value_class.flags & MACHINE_TYPE_CLASS_RESOLVED))
            {
                // va_list is a three-word aggregate on SysV. Keep the
                // temporary in a regular frame slot so STORE/LOAD and
                // VA_COPY can reuse the existing aggregate copy rows.
                IrType* value_type = ir_type_from_id(&program->types, value->canonical_type);
                if (value_type->layout.size <= UINT32_MAX - 7)
                {
                    selector.value_stack_slots[instruction->result.value] =
                        machine_x64_append_slot(&selector, (u32)((value_type->layout.size + 7) & ~(u64)7), 8);
                    continue;
                }
            }
            // Address producers hold an 8-byte address in their vreg no
            // matter what their declared canonical type is, exactly like
            // the canonical path stores an address in the value's slot.
            bool float_scalar = (value_class.flags & (MACHINE_TYPE_CLASS_RESOLVED | MACHINE_TYPE_CLASS_FLOAT_SCALAR)) ==
                                (MACHINE_TYPE_CLASS_RESOLVED | MACHINE_TYPE_CLASS_FLOAT_SCALAR);
            bool windows_va_list_register = windows_va_list &&
                                            (instruction->opcode == IR_OPCODE_ARGUMENT || instruction->opcode == IR_OPCODE_LOAD ||
                                             instruction->opcode == IR_OPCODE_ATOMIC_LOAD || instruction->opcode == IR_OPCODE_CALL);
            if ((value_class.flags & MACHINE_TYPE_CLASS_SCALAR_REGISTER) || float_scalar || windows_va_list_register ||
                machine_x64_opcode_produces_address(instruction->opcode))
            {
                u32 register_index = machine_builder_virtual_register(&selector.builder, (MachineVirtualRegister){
                                                                                             .definition_point = MACHINE_POINT_INVALID,
                                                                                             .register_class = MACHINE_REGISTER_CLASS_GENERAL,
                                                                                             .typed_origin = instruction->result.value,
                                                                                         });
                selector.value_virtual_registers[instruction->result.value] = register_index;
            }
            else if (machine_x64_type_is_f80(&selector, value->canonical_type))
            {
                selector.value_stack_slots[instruction->result.value] = machine_x64_append_slot(&selector, 16, 16);
            }
            else if ((value_class.flags & MACHINE_TYPE_CLASS_VECTOR_REGISTER) && selector.vector_registers_supported)
            {
                // 64-byte vector values live in ZMM-class virtual
                // registers; the rows that cannot keep one there reject at
                // selection and the function falls back whole.
                selector.value_virtual_registers[instruction->result.value] =
                    machine_builder_virtual_register(&selector.builder, (MachineVirtualRegister){
                                                                            .definition_point = MACHINE_POINT_INVALID,
                                                                            .register_class = MACHINE_REGISTER_CLASS_VECTOR,
                                                                            .typed_origin = instruction->result.value,
                                                                        });
            }
            else if ((instruction->opcode == IR_OPCODE_ARGUMENT || instruction->opcode == IR_OPCODE_LOAD ||
                      instruction->opcode == IR_OPCODE_ATOMIC_LOAD || instruction->opcode == IR_OPCODE_CALL ||
                      instruction->opcode == IR_OPCODE_VA_ARG ||
                      instruction->opcode == IR_OPCODE_CAST || instruction->opcode == IR_OPCODE_AGGREGATE || instruction->opcode == IR_OPCODE_ARRAY ||
                      instruction->opcode == IR_OPCODE_ATOMIC_READ_MODIFY_WRITE || instruction->opcode == IR_OPCODE_ATOMIC_COMPARE_EXCHANGE ||
                      instruction->opcode == IR_OPCODE_BINARY ||
                      (instruction->opcode == IR_OPCODE_UNARY && (instruction->unary_operation == IR_UNARY_INTEGER_BITWISE_NOT ||
                                                                instruction->unary_operation == IR_UNARY_INTEGER_NEGATE || value_class.kind == IR_TYPE_VECTOR)) ||
                      // An i128 constant is slot-backed like every other i128
                      // value; nothing else this opcode produces reaches the
                      // aggregate kinds below, so the widened list costs one
                      // compare on a row that already fails them all.
                      instruction->opcode == IR_OPCODE_CONSTANT_INTEGER) &&
                     (value_class.flags & MACHINE_TYPE_CLASS_RESOLVED) &&
                     ((value_class.flags & (MACHINE_TYPE_CLASS_AGGREGATE | MACHINE_TYPE_CLASS_INTEGER128)) || value_class.kind == IR_TYPE_VECTOR ||
                      ((instruction->opcode == IR_OPCODE_ARRAY || instruction->opcode == IR_OPCODE_LOAD) && value_class.kind == IR_TYPE_ARRAY)))
            {
                // Aggregate values own a frame slot like the canonical
                // path's per-value storage; copies and ABI part transfers
                // address it directly. The record is fetched for the slot's
                // byte count.
                IrType* value_type = ir_type_from_id(&program->types, value->canonical_type);
                if (value_type->layout.size <= UINT32_MAX - 7)
                {
                    selector.value_stack_slots[instruction->result.value] =
                        machine_x64_append_slot(&selector,
                            (u32)BUSTER_MAX((value_type->layout.size + 7) & ~(u64)7,
                                selector.value_pairs && selector.value_pairs[instruction->result.value].registers[0] != UINT32_MAX ? 16u : 8u), 8);
                }
            }
        }
    }
    // Aliased load results share their local's virtual register: every use
    // site then names the local directly and the load emits nothing. The
    // result's own classification vreg goes unused, which costs an id and
    // nothing else.
    for (u32 alias_index = 0; alias_index < alias_count; alias_index += 1)
    {
        u32 value_index = alias_values[alias_index];
        if (selector.value_virtual_registers[load_aliases[value_index]] != UINT32_MAX)
        {
            selector.value_virtual_registers[value_index] = selector.value_virtual_registers[load_aliases[value_index]];
        }
    }
    // Compare/branch fusion. A C loop head lowers its controlling
    // expression as compare → widen → (!= 0) → BRANCH_IF, and each link
    // materializes: SETCC/MOVZX makes a bool, a movabs makes the zero, a
    // second compare makes a second flag, and the branch tests it — ~10
    // instructions where clang emits cmp+jcc. When every member of that
    // chain has exactly one use and sits in the branch's own block, the
    // branch re-selects the innermost comparison as CMP (or the residual
    // truthiness test as TEST) at the terminator and the members select
    // into nothing. Walking the chain keeps an invariant — the branch
    // outcome equals truthy(chain value) xor negate — through (!= 0) and
    // (== 0) against a literal zero, truthiness-preserving extensions,
    // and BOOLEAN_NOT; a comparison that is none of those terminates the
    // walk as the CMP, and anything else terminates it as TEST. Both
    // read their operands at the branch row instead of the member's, so
    // a promoted local stored between the deepest absorbed member and
    // the branch forecloses the fusion — the walk stamps every promoted
    // local's latest store ordinal and the commit compares. Types stay
    // integer-class scalars throughout: float compares keep their
    // FCMP_SET materialization and only feed the chain as its bool.
    // The store counts the sweeps read are done with; the same sparse column now
    // carries the latest store ordinal per promoted local.
    for (u32 index = 1; index < local_use_count; index += 1)
    {
        local_uses[index].store_count = 0;
    }
    // The stores this stamps and the branches it fuses are both candidate
    // rows, so this pass reads the same compact list the sweeps did, and each
    // entry already carries the ordinal the full walk gave that row.
    u32 fusion_candidate_base = 0;
    for (u32 block_index = 0; block_index < function->block_count && selector.supported; block_index += 1)
    {
        u32 block_candidate_count = block_candidate_counts[block_index];
        for (u32 candidate_index = 0; candidate_index < block_candidate_count; candidate_index += 1)
        {
            MachineX64CandidateRow candidate_row = candidate_rows[fusion_candidate_base + candidate_index];
            IrInstruction* instruction = function->instructions + candidate_row.row;
            u32 fusion_ordinal = candidate_row.ordinal;
            if (instruction->opcode == IR_OPCODE_STORE && instruction->operand_count >= 1 && instruction->operands[0].value < function->value_count &&
                value_uses[instruction->operands[0].value].local_use)
            {
                local_uses[value_uses[instruction->operands[0].value].local_use].store_count = fusion_ordinal;
            }
            if (instruction->opcode != IR_OPCODE_BRANCH_IF || instruction->operand_count < 1 || instruction->operands[0].value >= function->value_count)
            {
                continue;
            }
            u32 chain_value = instruction->operands[0].value;
            u32 absorbed_members[16];
            u32 absorbed_count = 0;
            u32 dead_zeros[16];
            u32 dead_zero_count = 0;
            u32 negate = 0;
            u32 innermost_ordinal = 0;
            u32 read_left = UINT32_MAX;
            u32 read_right = UINT32_MAX;
            u32 condition = 0;
            bool wide = false;
            while (absorbed_count < BUSTER_ARRAY_LENGTH(absorbed_members))
            {
                if (chain_value >= function->value_count || value_uses[chain_value].use_count != 1 || value_def_blocks[chain_value] != block_index ||
                    function->values[chain_value].definition.value == UINT32_MAX)
                {
                    break;
                }
                IrInstruction* member = function->instructions + function->values[chain_value].definition.value;
                if (member->opcode == IR_OPCODE_BINARY && member->operand_count >= 2 && member->operands[0].value < function->value_count &&
                    member->operands[1].value < function->value_count)
                {
                    u32 member_condition = machine_x64_condition_from_comparison(member->binary_operation);
                    MachineTypeClass member_operand_class = machine_x64_type_class(&selector, function->values[member->operands[0].value].canonical_type);
                    if (!member_condition || !(member_operand_class.flags & MACHINE_TYPE_CLASS_SCALAR_REGISTER))
                    {
                        break;
                    }
                    if (member_condition == MACHINE_X64_CONDITION_EQUAL || member_condition == MACHINE_X64_CONDITION_NOT_EQUAL)
                    {
                        // A literal zero side may sit behind one widening
                        // cast (extending zero is zero). The cast dies only
                        // when this compare is its one use, and the
                        // constant only once nothing still reads it.
                        u32 zero_side = UINT32_MAX;
                        u32 zero_cast = UINT32_MAX;
                        u32 zero_constant = UINT32_MAX;
                        for (u32 side = 0; side < 2 && zero_side == UINT32_MAX; side += 1)
                        {
                            u32 constant_value = member->operands[side].value;
                            u32 through_cast = UINT32_MAX;
                            if (function->values[constant_value].definition.value == UINT32_MAX)
                            {
                                continue;
                            }
                            IrInstruction* side_definition = function->instructions + function->values[constant_value].definition.value;
                            if (side_definition->opcode == IR_OPCODE_CAST && side_definition->operand_count >= 1 &&
                                side_definition->operands[0].value < function->value_count &&
                                (side_definition->conversion_operation == IR_CONVERSION_INTEGER_ZERO_EXTEND ||
                                 side_definition->conversion_operation == IR_CONVERSION_INTEGER_SIGN_EXTEND ||
                                 side_definition->conversion_operation == IR_CONVERSION_IDENTITY))
                            {
                                through_cast = constant_value;
                                constant_value = side_definition->operands[0].value;
                                if (function->values[constant_value].definition.value == UINT32_MAX)
                                {
                                    continue;
                                }
                                side_definition = function->instructions + function->values[constant_value].definition.value;
                            }
                            if (side_definition->opcode == IR_OPCODE_CONSTANT_INTEGER && side_definition->immediate_count && side_definition->immediates &&
                                side_definition->immediates[0] == 0)
                            {
                                zero_side = side;
                                zero_cast = through_cast;
                                zero_constant = constant_value;
                            }
                        }
                        if (zero_side != UINT32_MAX)
                        {
                            absorbed_members[absorbed_count++] = chain_value;
                            innermost_ordinal = value_def_ordinals[chain_value];
                            bool cast_dies = zero_cast == UINT32_MAX ||
                                             (value_uses[zero_cast].use_count == 1 && dead_zero_count < BUSTER_ARRAY_LENGTH(dead_zeros));
                            if (zero_cast != UINT32_MAX && cast_dies)
                            {
                                dead_zeros[dead_zero_count++] = zero_cast;
                            }
                            if (cast_dies && value_uses[zero_constant].use_count == 1 && dead_zero_count < BUSTER_ARRAY_LENGTH(dead_zeros))
                            {
                                dead_zeros[dead_zero_count++] = zero_constant;
                            }
                            negate ^= member_condition == MACHINE_X64_CONDITION_EQUAL;
                            chain_value = member->operands[1 - zero_side].value;
                            continue;
                        }
                    }
                    absorbed_members[absorbed_count++] = chain_value;
                    innermost_ordinal = value_def_ordinals[chain_value];
                    read_left = member->operands[0].value;
                    read_right = member->operands[1].value;
                    condition = member_condition ^ negate;
                    wide = (member_operand_class.flags & MACHINE_TYPE_CLASS_WIDE) != 0;
                    break;
                }
                if (member->opcode == IR_OPCODE_CAST && member->operand_count >= 1 && member->operands[0].value < function->value_count &&
                    (member->conversion_operation == IR_CONVERSION_INTEGER_ZERO_EXTEND ||
                     member->conversion_operation == IR_CONVERSION_INTEGER_SIGN_EXTEND || member->conversion_operation == IR_CONVERSION_IDENTITY) &&
                    (machine_x64_type_class(&selector, function->values[member->operands[0].value].canonical_type).flags &
                     MACHINE_TYPE_CLASS_SCALAR_REGISTER))
                {
                    absorbed_members[absorbed_count++] = chain_value;
                    innermost_ordinal = value_def_ordinals[chain_value];
                    chain_value = member->operands[0].value;
                    continue;
                }
                if (member->opcode == IR_OPCODE_UNARY && member->unary_operation == IR_UNARY_BOOLEAN_NOT && member->operand_count >= 1 &&
                    member->operands[0].value < function->value_count &&
                    (machine_x64_type_class(&selector, function->values[member->operands[0].value].canonical_type).flags &
                     MACHINE_TYPE_CLASS_SCALAR_REGISTER))
                {
                    absorbed_members[absorbed_count++] = chain_value;
                    innermost_ordinal = value_def_ordinals[chain_value];
                    negate ^= 1;
                    chain_value = member->operands[0].value;
                    continue;
                }
                break;
            }
            if (!absorbed_count)
            {
                continue;
            }
            if (read_left == UINT32_MAX)
            {
                // Truthiness terminal: TEST64 of the register content is
                // exact because sub-64-bit values sit extended with clean
                // upper bits, matching the CMP-against-zero it replaces.
                if (chain_value >= function->value_count ||
                    !(machine_x64_type_class(&selector, function->values[chain_value].canonical_type).flags & MACHINE_TYPE_CLASS_SCALAR_REGISTER))
                {
                    continue;
                }
                read_left = chain_value;
                condition = MACHINE_X64_CONDITION_NOT_EQUAL ^ negate;
            }
            bool reads_safe = selector.value_virtual_registers[read_left] != UINT32_MAX &&
                              (read_right == UINT32_MAX || selector.value_virtual_registers[read_right] != UINT32_MAX);
            for (u32 read_side = 0; read_side < 2 && reads_safe; read_side += 1)
            {
                u32 read_value = read_side ? read_right : read_left;
                if (read_value == UINT32_MAX)
                {
                    continue;
                }
                u32 read_root = load_aliases[read_value];
                if (read_root != UINT32_MAX && local_uses[value_uses[read_root].local_use].store_count > innermost_ordinal)
                {
                    reads_safe = false;
                }
            }
            if (!reads_safe)
            {
                continue;
            }
            selector.branch_fusions[block_index] = (MachineX64BranchFusion){
                .left = read_left,
                .right = read_right,
                .condition_value = instruction->operands[0].value,
                .condition = (u8)condition,
                .wide = wide,
            };
            for (u32 member_index = 0; member_index < absorbed_count; member_index += 1)
            {
                selector.fused_dead[absorbed_members[member_index]] = 1;
            }
            for (u32 zero_index = 0; zero_index < dead_zero_count; zero_index += 1)
            {
                selector.fused_dead[dead_zeros[zero_index]] = 1;
            }
        }
        fusion_candidate_base += block_candidate_count;
    }
    selector.virtual_register_count = selector.builder.virtual_registers.total_count;
    selector.classification_registers =
        selector.virtual_register_count ? (MachineVirtualRegister*)(selector.builder.virtual_registers.first + 1) : 0;
    u32 typed_instruction_count = 0;
    u32 simd_operation_count = 0;
    for (u32 block_index = 0; block_index < function->block_count && selector.supported; block_index += 1)
    {
        IrBlock* block = function->blocks + block_index;
        selector.current_block = block_index;
        machine_builder_block_begin(&selector.builder);
        selector.open_block = (MachineBlock){.parameter_offset = selector.builder.block_parameters.total_count};
        IrCfgBlock const* published_block = function->published_cfg->blocks + block_index;
        for (u32 parameter_index = 0; parameter_index < published_block->parameter_count; parameter_index += 1)
        {
            IrCfgParameter const* parameter = function->published_cfg->parameters + published_block->parameter_offset + parameter_index;
            u32 value = parameter->value.value;
            bool wide = selector.value_pairs && selector.value_pairs[value].registers[0] != UINT32_MAX;
            u32 count = wide ? 2u : 1u;
            u32 const* registers = wide ? selector.value_pairs[value].registers : selector.value_virtual_registers + value;
            for (u32 part = 0; part < count; part += 1)
            {
                machine_builder_block_parameter(&selector.builder, (MachineBlockParameter){.virtual_register = registers[part]});
                if (wide)
                {
                    machine_x64_select_frame_store64(&selector, selector.value_stack_slots[value], part * 8u, registers[part]);
                }
            }
        }
        selector.open_block.parameter_count = (u16)(selector.builder.block_parameters.total_count - selector.open_block.parameter_offset);
        if (block_index == 0)
        {
            if (function_type->is_variadic && windows_abi)
            {
                // Home all four incoming GPRs before argument captures can
                // reuse them. The caller's homes adjoin the overflow tail.
                machine_x64_select_row(&selector, (MachineInstruction){
                    .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RCX),
                                 machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RDX),
                                 machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_R8),
                                 machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_R9)},
                    .opcode = MACHINE_X64_WIN_VA_SAVE,
                });
            }
            else if (selector.va_register_save_slot != UINT32_MAX)
            {
                machine_x64_select_row(&selector, (MachineInstruction){
                                                          .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, selector.va_register_save_slot)},
                                                          .opcode = MACHINE_X64_VA_SAVE,
                                                      });
            }
            // Win64 stack arguments start above the caller-owned shadow
            // area, so every incoming read shifts by its four eightbytes;
            // System V starts at the saved frame and return address alone.
            u32 incoming_stack_base = windows_abi ? 32u : 0u;
            // Capture every incoming argument register at entry, before any
            // body row can use an argument register as an operand scratch.
            // Integer parts capture first because float captures scratch
            // general registers; XMM state survives that pass untouched.
            if (selector.return_shape.indirect)
            {
                machine_x64_select_row(&selector,
                                       (MachineInstruction){
                                           .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, selector.hidden_return_slot),
                                                        machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, machine_x64_argument_register(windows_abi, 0))},
                                           .opcode = MACHINE_X64_STORE_FRAME64,
                                       });
            }
            u32* normalize_registers = arena_allocate(arena, u32, function_type->parameter_count);
            u32* normalize_values = arena_allocate(arena, u32, function_type->parameter_count);
            u16* normalize_opcodes = arena_allocate(arena, u16, function_type->parameter_count);
            u32 normalize_count = 0;
            u32* indirect_bases = arena_allocate(arena, u32, function_type->parameter_count);
            u32 indirect_part_count = 0;
            for (u32 argument_index = 0; argument_index < function_type->parameter_count; argument_index += 1)
            {
                indirect_bases[argument_index] = indirect_part_count;
                if (selector.parameter_shapes[argument_index].indirect)
                {
                    indirect_part_count += selector.parameter_shapes[argument_index].part_count;
                }
            }
            u32* indirect_registers = arena_allocate(arena, u32, indirect_part_count ? indirect_part_count : 1);
            for (u32 capture_pass = 0; capture_pass < 2 && selector.supported; capture_pass += 1)
            {
                bool float_pass = capture_pass == 1;
                for (u32 argument_index = 0; argument_index < function_type->parameter_count; argument_index += 1)
                {
                    u32 argument_value = selector.argument_values[argument_index];
                    if (argument_value == IR_ID_UNDERLYING_INVALID)
                    {
                        continue;
                    }
                    MachineX64ValueShape* shape = selector.parameter_shapes + argument_index;
                    MachineX64ArgumentPlacement* parameter_placement = selector.parameter_placements + argument_index;
                    u32 next_integer = parameter_placement->first_integer;
                    u32 next_float = parameter_placement->first_float;
                    if (shape->windows_scalar_lane_size)
                    {
                        u32 slot = selector.value_stack_slots[argument_value];
                        if (slot == UINT32_MAX)
                        {
                            machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                            break;
                        }
                        bool lane_float = shape->windows_scalar_float;
                        if (lane_float == float_pass)
                        {
                            for (u32 lane = 0; lane < parameter_placement->register_part_count; lane += 1)
                            {
                                MachineRef source;
                                if (lane_float)
                                {
                                    u32 lane_value = machine_x64_synthesize_register(&selector);
                                    machine_x64_select_row(&selector, (MachineInstruction){
                                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, lane_value)},
                                        .payload = (u32)parameter_placement->first_float + lane,
                                        .opcode = MACHINE_X64_MOVQ_FROM_XMM,
                                    });
                                    source = machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, lane_value);
                                }
                                else
                                {
                                    source = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                              machine_x64_argument_register(true,
                                                                  (u32)parameter_placement->first_integer + lane));
                                }
                                machine_x64_select_row(&selector, (MachineInstruction){
                                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot), source},
                                    .payload = lane * shape->windows_scalar_lane_size,
                                    .opcode = machine_x64_frame_store_opcode(shape->windows_scalar_lane_size),
                                });
                            }
                        }
                        if (float_pass)
                        {
                            for (u32 part = 0; part < parameter_placement->stack_part_count; part += 1)
                            {
                                u32 lane_value = machine_x64_synthesize_register(&selector);
                                machine_x64_select_row(&selector, (MachineInstruction){
                                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, lane_value)},
                                    .payload = incoming_stack_base + ((u32)parameter_placement->first_stack_part + part) * 8,
                                    .opcode = MACHINE_X64_LOAD_INCOMING,
                                });
                                u32 lane = (u32)parameter_placement->register_part_count + part;
                                machine_x64_select_row(&selector, (MachineInstruction){
                                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                 machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, lane_value)},
                                    .payload = lane * shape->windows_scalar_lane_size,
                                    .opcode = machine_x64_frame_store_opcode(shape->windows_scalar_lane_size),
                                });
                            }
                        }
                        continue;
                    }
                    if (shape->indirect)
                    {
                        // Capture incoming GPR pointers before float bridges;
                        // read stack pointers after the GPRs are free. Defer
                        // copying bytes until both capture passes finish.
                        u32 register_parts = shape->vector_part_bytes ? parameter_placement->register_part_count
                                                                     : parameter_placement->on_stack ? 0u : 1u;
                        u32 capture_count = float_pass ? parameter_placement->stack_part_count : register_parts;
                        for (u32 capture_index = 0; capture_index < capture_count; capture_index += 1)
                        {
                            u32 pointer = machine_x64_synthesize_register(&selector);
                            MachineInstruction capture = {
                                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, pointer)},
                                .payload = incoming_stack_base + ((u32)parameter_placement->first_stack_part + capture_index) * 8,
                                .opcode = MACHINE_X64_LOAD_INCOMING,
                            };
                            if (!float_pass)
                            {
                                capture.operands[1] = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                    machine_x64_argument_register(windows_abi, next_integer + capture_index));
                                capture.payload = 0;
                                capture.opcode = MACHINE_X64_MOV_RR;
                            }
                            machine_x64_select_row(&selector, capture);
                            indirect_registers[indirect_bases[argument_index] + (float_pass ? register_parts + capture_index : capture_index)] = pointer;
                        }
                        continue;
                    }
                    if (parameter_placement->on_stack)
                    {
                        // Stack parameters copy from the caller-pushed area
                        // in the float pass, where the general-register
                        // scratches are already free.
                        if (!float_pass)
                        {
                            continue;
                        }
                        if (shape->vector)
                        {
                            // A stack vector parameter reads its 64-aligned
                            // incoming eightbytes whole: the area address is
                            // rbp plus the saved-frame-and-return sixteen,
                            // and the load's free register pick is safe here
                            // because every register vector parameter was
                            // captured in the integer pass below.
                            u32 vector_parameter_register = selector.value_virtual_registers[argument_value];
                            if (vector_parameter_register == UINT32_MAX)
                            {
                                machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                                break;
                            }
                            u32 area_register = machine_x64_synthesize_register(&selector);
                            machine_x64_select_row(&selector, (MachineInstruction){
                                                                  .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, area_register),
                                                                               machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RBP)},
                                                                  .payload = 16 + incoming_stack_base + (u32)parameter_placement->first_stack_part * 8,
                                                                  .opcode = MACHINE_X64_LEA_OFFSET,
                                                              });
                            u32 vector_incoming_row =
                                machine_x64_select_row(&selector, (MachineInstruction){
                                                                      .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER,
                                                                                                    vector_parameter_register),
                                                                                   machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, area_register)},
                                                                      .opcode = MACHINE_X64_VLOAD_PTR,
                                                                  });
                            machine_x64_define(&selector, vector_parameter_register, vector_incoming_row);
                            continue;
                        }
                        if (shape->aggregate)
                        {
                            u32 slot = selector.value_stack_slots[argument_value];
                            if (slot == UINT32_MAX)
                            {
                                machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                                break;
                            }
                            for (u32 part_index = 0; part_index < parameter_placement->stack_part_count; part_index += 1)
                            {
                                u32 bounce_register = machine_x64_synthesize_register(&selector);
                                machine_x64_select_row(&selector,
                                                       (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                           .payload = incoming_stack_base + ((u32)parameter_placement->first_stack_part + part_index) * 8,
                                                           .opcode = MACHINE_X64_LOAD_INCOMING,
                                                       });
                                machine_x64_select_row(&selector, (MachineInstruction){
                                                                      .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                                                   machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                                      .payload = part_index * 8,
                                                                      .opcode = MACHINE_X64_STORE_FRAME64,
                                                                  });
                            }
                            continue;
                        }
                        u32 stack_argument_register = selector.value_virtual_registers[argument_value];
                        if (stack_argument_register == UINT32_MAX)
                        {
                            machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                            break;
                        }
                        u32 incoming_row = machine_x64_select_row(&selector, (MachineInstruction){
                                                                                 .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER,
                                                                                                               stack_argument_register)},
                                                                                 .payload = incoming_stack_base + (u32)parameter_placement->first_stack_part * 8,
                                                                                 .opcode = MACHINE_X64_LOAD_INCOMING,
                                                                             });
                        machine_x64_define(&selector, stack_argument_register, incoming_row);
                        continue;
                    }
                    if (shape->vector)
                    {
                        // Register vector parameters capture in the integer
                        // pass: the copy binds in place on its incoming ZMM,
                        // so no free pick exists before every argument
                        // register — either file — has been read.
                        if (float_pass)
                        {
                            continue;
                        }
                        u32 vector_argument_register = selector.value_virtual_registers[argument_value];
                        if (vector_argument_register == UINT32_MAX)
                        {
                            machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                            break;
                        }
                        u32 vector_capture_row =
                            machine_x64_select_row(&selector, (MachineInstruction){
                                                                  .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, vector_argument_register),
                                                                               machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                                                                MACHINE_X64_ZMM0 + next_float)},
                                                                  .opcode = MACHINE_X64_VMOV_RR,
                                                              });
                        machine_x64_define(&selector, vector_argument_register, vector_capture_row);
                        continue;
                    }
                    if (shape->vector_part_bytes)
                    {
                        if (float_pass)
                        {
                            u32 slot = selector.value_stack_slots[argument_value];
                            if (slot == UINT32_MAX)
                            {
                                machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                                break;
                            }
                            for (u32 part = 0; part < shape->part_count; part += 1)
                            {
                                machine_x64_select_vector_frame_part(&selector, false, MACHINE_X64_ZMM0 + next_float + part, slot,
                                                                     part * shape->vector_part_bytes, shape->vector_part_bytes);
                            }
                        }
                        continue;
                    }
                    if (shape->xmm128)
                    {
                        if (float_pass)
                        {
                            u32 slot = selector.value_stack_slots[argument_value];
                            if (slot == UINT32_MAX)
                            {
                                machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                                break;
                            }
                            machine_x64_select_row(&selector, (MachineInstruction){
                                .operands = {machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_ZMM0 + next_float),
                                             machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
                                .opcode = MACHINE_X64_STORE_XMM_FRAME128,
                            });
                        }
                        continue;
                    }
                    if (shape->aggregate)
                    {
                        u32 slot = selector.value_stack_slots[argument_value];
                        if (slot == UINT32_MAX)
                        {
                            machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                            break;
                        }
                        for (u32 part_index = 0; part_index < shape->part_count; part_index += 1)
                        {
                            bool part_float = shape->part_is_float[part_index] != 0;
                            u32 part_integer = next_integer;
                            u32 part_float_register = next_float;
                            next_integer += !part_float;
                            next_float += part_float;
                            if (part_float != float_pass)
                            {
                                continue;
                            }
                            if (part_float)
                            {
                                u32 bounce_register = machine_x64_synthesize_register(&selector);
                                machine_x64_select_row(&selector, (MachineInstruction){
                                                                      .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                                      .payload = part_float_register,
                                                                      .opcode = MACHINE_X64_MOVQ_FROM_XMM,
                                                                  });
                                machine_x64_select_row(&selector, (MachineInstruction){
                                                                      .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                                                   machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, bounce_register)},
                                                                      .payload = shape->part_offsets[part_index],
                                                                      .opcode = MACHINE_X64_STORE_FRAME64,
                                                                  });
                            }
                            else
                            {
                                machine_x64_select_row(&selector,
                                                       (MachineInstruction){
                                                           .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                                        machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                                                         machine_x64_argument_register(windows_abi, part_integer))},
                                                           .payload = shape->part_offsets[part_index],
                                                           .opcode = MACHINE_X64_STORE_FRAME64,
                                                       });
                            }
                        }
                        continue;
                    }
                    bool scalar_float = shape->part_is_float[0] != 0;
                    if (scalar_float != float_pass)
                    {
                        continue;
                    }
                    u32 argument_register = selector.value_virtual_registers[argument_value];
                    if (argument_register == UINT32_MAX)
                    {
                        machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                        break;
                    }
                    u32 row;
                    if (scalar_float)
                    {
                        row = machine_x64_select_row(&selector, (MachineInstruction){
                                                                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, argument_register)},
                                                                    .payload = next_float,
                                                                    .opcode = MACHINE_X64_MOVQ_FROM_XMM,
                                                                });
                    }
                    else
                    {
                        row = machine_x64_select_row(&selector, (MachineInstruction){
                                                                    .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, argument_register),
                                                                                 machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER,
                                                                                                  machine_x64_argument_register(windows_abi, next_integer))},
                                                                    .opcode = MACHINE_X64_MOV_RR,
                                                                });
                    }
                    machine_x64_define(&selector, argument_register, row);
                    // Both ABIs leave the bits above a narrow integer
                    // argument's declared width unspecified in the register
                    // it arrives in, so the captured value is normalized to
                    // that width here. Every later use reads the whole
                    // register, and a `uint32_t` parameter used as an index
                    // otherwise scales the caller's leftover high half.  The
                    // rows are recorded here and emitted after both capture
                    // passes: a row emitted between captures may take a
                    // scratch register the incoming arguments still occupy.
                    if (!scalar_float && normalize_count < function_type->parameter_count)
                    {
                        IrType* parameter_type = ir_type_from_id(&program->types, function_type->parameter_types[argument_index]);
                        if (parameter_type && (parameter_type->kind == IR_TYPE_INTEGER || parameter_type->kind == IR_TYPE_BOOLEAN) &&
                            parameter_type->layout.size < 8)
                        {
                            normalize_registers[normalize_count] = argument_register;
                            normalize_values[normalize_count] = argument_value;
                            normalize_opcodes[normalize_count] = parameter_type->layout.size == 1   ? MACHINE_X64_MOVZX8_RR
                                                                 : parameter_type->layout.size == 2 ? MACHINE_X64_MOVZX16_RR
                                                                                                    : MACHINE_X64_MOV32_RR;
                            normalize_count += 1;
                        }
                    }
                }
            }
            if (windows_abi)
            {
                for (u32 argument_index = 0; argument_index < function_type->parameter_count && selector.supported; argument_index += 1)
                {
                    u32 value = selector.argument_values[argument_index];
                    MachineX64ValueShape* shape = selector.parameter_shapes + argument_index;
                    if (value != IR_ID_UNDERLYING_INVALID && shape->indirect)
                    {
                        u32 slot = selector.value_stack_slots[value];
                        u32 vector_register = selector.value_virtual_registers[value];
                        if (shape->vector && vector_register != UINT32_MAX)
                        {
                            u32 row = machine_x64_select_row(&selector, (MachineInstruction){
                                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, vector_register),
                                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER,
                                                              indirect_registers[indirect_bases[argument_index]])},
                                .opcode = MACHINE_X64_VLOAD_PTR,
                            });
                            machine_x64_define(&selector, vector_register, row);
                        }
                        else if (slot == UINT32_MAX)
                        {
                            machine_x64_reject(&selector, IR_OPCODE_ARGUMENT);
                        }
                        else
                        {
                            if (shape->vector_part_bytes)
                            {
                                for (u32 part = 0; part < shape->part_count; part += 1)
                                {
                                    u32 source = indirect_registers[indirect_bases[argument_index] + part];
                                    for (u32 copied = 0; copied < shape->vector_part_bytes; copied += 8)
                                    {
                                        u32 address = source;
                                        if (copied)
                                        {
                                            address = machine_x64_synthesize_register(&selector);
                                            machine_x64_select_row(&selector, (MachineInstruction){
                                                .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address),
                                                             machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source)},
                                                .payload = copied,
                                                .opcode = MACHINE_X64_LEA_OFFSET,
                                            });
                                        }
                                        u32 chunk = machine_x64_synthesize_register(&selector);
                                        machine_x64_select_row(&selector, (MachineInstruction){
                                            .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, chunk),
                                                         machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, address)},
                                            .opcode = MACHINE_X64_LOAD_PTR64,
                                        });
                                        machine_x64_select_row(&selector, (MachineInstruction){
                                            .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                         machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, chunk)},
                                            .payload = part * shape->vector_part_bytes + copied,
                                            .opcode = MACHINE_X64_STORE_FRAME64,
                                        });
                                    }
                                }
                            }
                            else
                            {
                                machine_x64_select_row(&selector, (MachineInstruction){
                                    .operands = {machine_ref_make(MACHINE_REF_STACK_SLOT, slot),
                                                 machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER,
                                                                  indirect_registers[indirect_bases[argument_index]])},
                                    .payload = shape->exact_byte_size,
                                    .opcode = MACHINE_X64_COPY_FRAME_FROM_PTR,
                                });
                            }
                        }
                    }
                }
            }
            for (u32 normalize_index = 0; normalize_index < normalize_count && selector.supported; normalize_index += 1)
            {
                // The normalized value takes a register of its own: a virtual
                // register is defined exactly once, and the argument's is
                // already defined by its capture row.
                u32 source_register = normalize_registers[normalize_index];
                u32 normalize_register = machine_x64_synthesize_register(&selector);
                u32 normalize_row = machine_x64_select_row(&selector, (MachineInstruction){
                                                                         .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, normalize_register),
                                                                                      machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, source_register)},
                                                                         .opcode = normalize_opcodes[normalize_index],
                                                                     });
                machine_x64_define(&selector, normalize_register, normalize_row);
                selector.value_virtual_registers[normalize_values[normalize_index]] = normalize_register;
            }
        }
        u32 block_row_count = function->published_cfg->blocks[block_index].instruction_count;
        u32 block_first_row = block->first_instruction.value;
        for (u32 row_offset = 0; row_offset < block_row_count && selector.supported; row_offset += 1)
        {
            IrInstructionId id = {.value = block_first_row + row_offset};
            IrInstruction* instruction = function->instructions + id.value;
            typed_instruction_count += 1;
            simd_operation_count += instruction->opcode == IR_OPCODE_SIMD;
            *line_mark_cursor = (MachineLineMark){.row = selector.builder.instructions.total_count, .instruction = id.value};
            line_mark_cursor += 1;
            bool instruction_selected = false;
            bool fused_dead = false;
            u32 result_register = UINT32_MAX;
            if (instruction->result.value != IR_ID_UNDERLYING_INVALID && instruction->result.value < function->value_count)
            {
                // A branch-fusion chain member selects into nothing: the branch
                // re-selects the compare at its own row, and the member's only
                // consumer is the chain. Every marked member is pure.
                fused_dead = selector.fused_dead[instruction->result.value];
                result_register = selector.value_virtual_registers[instruction->result.value];
            }
            if (fused_dead)
            {
                instruction_selected = true;
            }
            else
            {
                switch (instruction->opcode)
                {
                case IR_OPCODE_VA_ARG:
                    instruction_selected = machine_x64_select_va_arg(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_VA_START:
                    instruction_selected = machine_x64_select_va_start(&selector, instruction);
                    break;
                case IR_OPCODE_VA_COPY:
                    instruction_selected = machine_x64_select_va_copy(&selector, instruction);
                    break;
                case IR_OPCODE_VA_END:
                    instruction_selected = machine_x64_select_va_end(&selector, instruction);
                    break;
                case IR_OPCODE_LOCAL:
                    instruction_selected = machine_x64_select_local(&selector, instruction);
                    break;
                case IR_OPCODE_STACK_SAVE:
                    instruction_selected = machine_x64_select_stack_save(&selector, result_register);
                    break;
                case IR_OPCODE_STACK_ALLOCATE:
                    instruction_selected = machine_x64_select_stack_allocate(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_STACK_RESTORE:
                    instruction_selected = machine_x64_select_stack_restore(&selector, instruction);
                    break;
                case IR_OPCODE_ARGUMENT:
                    instruction_selected = machine_x64_select_argument(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_CONSTANT_INTEGER:
                case IR_OPCODE_CONSTANT_FLOAT:
                    instruction_selected = machine_x64_select_constant(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_CAST:
                    instruction_selected = machine_x64_select_cast(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_UNARY:
                    if (machine_x64_type_class(&selector, instruction->canonical_type).kind == IR_TYPE_VECTOR)
                    {
                        instruction_selected = machine_x64_select_vector_lanes(&selector, instruction,
                            ir_type_from_id(&program->types, instruction->canonical_type));
                    }
                    else if (machine_x64_type_is_f80(&selector, instruction->canonical_type))
                    {
                        instruction_selected = machine_x64_select_f80_negate(&selector, instruction);
                    }
                    else if (machine_x64_type_class(&selector, instruction->canonical_type).flags & MACHINE_TYPE_CLASS_INTEGER128)
                    {
                        instruction_selected = machine_x64_select_i128_unary(&selector, instruction);
                    }
                    else
                    {
                        instruction_selected = machine_x64_select_unary(&selector, instruction, result_register);
                    }
                    break;
                case IR_OPCODE_BINARY:
                    instruction_selected = machine_x64_select_binary(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_DEREFERENCE:
                    instruction_selected = machine_x64_select_dereference(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_GLOBAL:
                    instruction_selected = machine_x64_select_global_address(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_ADDRESS_OF:
                    instruction_selected = machine_x64_select_address_of(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_FIELD:
                    instruction_selected = machine_x64_select_field(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_DEBUG_TRAP:
                    instruction_selected = machine_x64_select_debug_trap(&selector);
                    break;
                case IR_OPCODE_AGGREGATE:
                    instruction_selected = machine_x64_select_aggregate(&selector, instruction);
                    break;
                case IR_OPCODE_ARRAY:
                    instruction_selected = machine_x64_select_array(&selector, instruction);
                    break;
                case IR_OPCODE_INDEX:
                    instruction_selected = machine_x64_select_index(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_LOAD:
                case IR_OPCODE_ATOMIC_LOAD:
                    instruction_selected = machine_x64_select_load(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_STORE:
                case IR_OPCODE_ATOMIC_STORE:
                    instruction_selected = machine_x64_select_store(&selector, instruction);
                    break;
                case IR_OPCODE_FUNCTION:
                    instruction_selected = machine_x64_select_function(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_SIMD:
                    instruction_selected = machine_x64_select_simd(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_CALL:
                    instruction_selected = machine_x64_select_call(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_BRANCH:
                    instruction_selected = machine_x64_select_branch(&selector, instruction);
                    break;
                case IR_OPCODE_LABEL_ADDRESS:
                    instruction_selected = machine_x64_select_label_address(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_INDIRECT_BRANCH:
                    instruction_selected = machine_x64_select_indirect_branch(&selector, instruction);
                    break;
                case IR_OPCODE_ATOMIC_READ_MODIFY_WRITE:
                    instruction_selected = machine_x64_select_atomic_read_modify_write(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_ATOMIC_COMPARE_EXCHANGE:
                    instruction_selected = machine_x64_select_atomic_compare_exchange(&selector, instruction, result_register);
                    break;
                case IR_OPCODE_CLEAR_INSTRUCTION_CACHE:
                    // x86 cache maintenance emits no instructions. Argument
                    // side effects have already been lowered independently.
                    instruction_selected = true;
                    break;
                case IR_OPCODE_INLINE_ASSEMBLY:
                    instruction_selected = machine_x64_select_compiler_barrier(&selector, instruction) ||
                                           machine_x64_select_assembly_identity(&selector, instruction) ||
                                           machine_x64_select_inline_hint(&selector, instruction) ||
                                           machine_x64_select_cpu_query(&selector, instruction) ||
                                           machine_x64_select_inline_assembly(&selector, instruction);
                    break;
                case IR_OPCODE_ATOMIC_FENCE:
                    instruction_selected = machine_x64_select_atomic_fence(&selector, instruction);
                    break;
                case IR_OPCODE_UNREACHABLE:
                    instruction_selected = machine_x64_select_unreachable(&selector);
                    break;
                case IR_OPCODE_SWITCH:
                    instruction_selected = machine_x64_select_switch(&selector, instruction);
                    break;
                case IR_OPCODE_BRANCH_IF:
                    instruction_selected = machine_x64_select_branch_if(&selector, instruction);
                    break;
                case IR_OPCODE_RETURN:
                    instruction_selected = machine_x64_select_return(&selector, instruction);
                    break;
                default:
                    instruction_selected = false;
                    break;
                }
            }
            if (!instruction_selected)
            {
                machine_x64_reject(&selector, instruction->opcode);
                break;
            }
            u32 value = instruction->result.value;
            if (selector.value_pairs && value < function->value_count && selector.value_pairs[value].registers[0] != UINT32_MAX)
            {
                u32 slot = selector.value_stack_slots[value];
                if (slot == UINT32_MAX)
                {
                    machine_x64_reject(&selector, instruction->opcode);
                    break;
                }
                for (u32 part = 0; part < 2; part += 1)
                {
                    u32 reg = selector.value_pairs[value].registers[part];
                    u32 row = machine_x64_select_row(&selector, (MachineInstruction){
                        .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, reg), machine_ref_make(MACHINE_REF_STACK_SLOT, slot)},
                        .payload = part * 8u, .opcode = MACHINE_X64_LOAD_FRAME});
                    machine_x64_define(&selector, reg, row);
                }
            }
        }
        machine_builder_block_end(&selector.builder, selector.open_block);
    }
    if (!selector.supported)
    {
        result.failed_opcode = selector.failed_opcode;
        return result;
    }
    u32 canonical_edge_offset = selector.builder.edges.total_count;
    if (!machine_builder_canonical_edges(&selector.builder, function, selector.value_virtual_registers, selector.value_pairs))
    {
        return (MachineSelectResult){.failed_opcode = IR_OPCODE_COUNT};
    }
    result.function = machine_function_builder_finish(arena, &selector.builder);
    result.function.target = windows_abi ? &machine_x86_64_windows_description : &machine_x86_64_description;
    machine_stream_cursor_close(&selector.immediates, selector.immediate_cursor);
    result.function.immediates = (u64*)machine_stream_materialize(arena, arena, &selector.immediates, BUSTER_ALIGN_OF(u64));
    result.function.immediate_count = selector.immediates.total_count;
    // The slot and call-target rows are split into their parallel public
    // columns here; the outgoing-area patch below writes the sizes column.
    machine_stream_cursor_close(&selector.stack_slots, selector.stack_slot_cursor);
    result.function.stack_slot_sizes = arena_allocate(arena, u32, selector.stack_slots.total_count);
    result.function.stack_slot_alignments = arena_allocate(arena, u32, selector.stack_slots.total_count);
    result.function.stack_slot_count = selector.stack_slots.total_count;
    result.function.nonvolatile_memory_certified = nonvolatile_memory;
    result.function.returns_twice_absence_certified = returns_twice_free;
    u32 split_slot = 0;
    for (MachineBuilderChunk* chunk = selector.stack_slots.first; chunk; chunk = chunk->next)
    {
        MachineX64StackSlot const* slot_rows = (MachineX64StackSlot const*)(chunk + 1);
        for (u32 row_index = 0; row_index < chunk->count; row_index += 1)
        {
            result.function.stack_slot_sizes[split_slot] = slot_rows[row_index].size;
            result.function.stack_slot_alignments[split_slot] = slot_rows[row_index].alignment;
            split_slot += 1;
        }
    }
    // The outgoing area's final size is only known once every call has been
    // selected, so its slot is patched here rather than at creation.
    if (selector.outgoing_slot != UINT32_MAX)
    {
        result.function.outgoing_slot = selector.outgoing_slot;
        result.function.outgoing_bytes = selector.outgoing_bytes;
        result.function.stack_slot_sizes[selector.outgoing_slot] = selector.outgoing_bytes;
    }
    machine_stream_cursor_close(&selector.call_targets, selector.call_target_cursor);
    result.function.call_targets = arena_allocate(arena, IrSymbolId, selector.call_targets.total_count);
    result.function.call_target_references = arena_allocate(arena, u8, selector.call_targets.total_count);
    result.function.call_target_count = selector.call_targets.total_count;
    u32 split_target = 0;
    for (MachineBuilderChunk* chunk = selector.call_targets.first; chunk; chunk = chunk->next)
    {
        MachineX64CallTarget const* target_rows = (MachineX64CallTarget const*)(chunk + 1);
        for (u32 row_index = 0; row_index < chunk->count; row_index += 1)
        {
            result.function.call_targets[split_target] = target_rows[row_index].symbol;
            result.function.call_target_references[split_target] = target_rows[row_index].reference;
            split_target += 1;
        }
    }
    result.function.line_marks = line_marks;
    result.function.line_mark_count = (u32)(line_mark_cursor - line_marks);
    if (!nonvolatile_memory)
    {
        machine_selection_certify_stack_memory(arena, &result.function, function);
    }
    machine_stream_cursor_close(&selector.switch_cases, selector.switch_case_cursor);
    result.function.switch_cases =
        (MachineSwitchCase*)machine_stream_materialize(arena, arena, &selector.switch_cases, BUSTER_ALIGN_OF(MachineSwitchCase));
    result.function.switch_case_count = selector.switch_cases.total_count;
    result.function.va_args = arena_allocate(arena, MachineVaArg, selector.va_args.total_count);
    result.function.va_arg_count = selector.va_args.total_count;
    machine_stream_flatten(&selector.va_args, result.function.va_args);
    result.function.inline_assemblies = arena_allocate(arena, MachineInlineAssembly, selector.inline_assemblies.total_count);
    result.function.inline_assembly_count = selector.inline_assemblies.total_count;
    machine_stream_flatten(&selector.inline_assemblies, result.function.inline_assemblies);
    result.function.inline_assembly_operands =
        arena_allocate(arena, MachineInlineAssemblyOperand, selector.inline_assembly_operands.total_count);
    result.function.inline_assembly_operand_count = selector.inline_assembly_operands.total_count;
    machine_stream_flatten(&selector.inline_assembly_operands, result.function.inline_assembly_operands);
    result.function.inline_assembly_relocations =
        arena_allocate(arena, MachineInlineAssemblyRelocation, selector.inline_assembly_relocations.total_count);
    result.function.inline_assembly_relocation_count = selector.inline_assembly_relocations.total_count;
    machine_stream_flatten(&selector.inline_assembly_relocations, result.function.inline_assembly_relocations);
    if (!machine_selection_finish_canonical_edges(arena, &result.function, function, canonical_edge_offset,
                                                   selector.block_entries, selector.block_exits,
                                                   selector.asm_goto_continuations))
    {
        return (MachineSelectResult){.failed_opcode = IR_OPCODE_COUNT};
    }
    if (!machine_function_split_parameter_edges(arena, &result.function))
    {
        return (MachineSelectResult){.failed_opcode = IR_OPCODE_COUNT};
    }
    bool select_predicates = simd_operation_count != 0 && predicate_residency;
    if (select_predicates && ((u64)result.function.virtual_register_count + (u64)result.function.instruction_count * 2u >= MACHINE_REF_PAYLOAD_LIMIT ||
        (u64)result.function.instruction_count * 2u >= MACHINE_POINT_INSTRUCTION_LIMIT))
    {
        return (MachineSelectResult){.failed_opcode = IR_OPCODE_COUNT};
    }
    result.function.predicate_absence_certified = !select_predicates;
    if (select_predicates) machine_x64_select_predicates(arena, &result.function);
    result.mutable_virtual_register_count = machine_function_compact_virtual_registers(arena, &result.function);
    if (result.mutable_virtual_register_count == UINT32_MAX)
    {
        return (MachineSelectResult){.failed_opcode = IR_OPCODE_COUNT};
    }
    if (preserve_debug_values &&
        !machine_debug_values_build(arena, program, function, &result.function, selector.value_stack_slots, selector.value_indirect_slots))
    {
        return (MachineSelectResult){.failed_opcode = IR_OPCODE_COUNT};
    }
    result.supported = true;
    result.selector_certified = true;
    result.returns_value = returns_value;
    result.selected_typed_instructions = typed_instruction_count;
    result.machine_instructions = result.function.instruction_count;
    result.simd_operation_count = simd_operation_count;
    return result;
}

typedef struct MachineX64Encoder MachineX64Encoder;
struct MachineX64Encoder
{
    u8* bytes;
    u32 count;
    u32 capacity;
    // Logical frame offsets remain relative to the top of the fixed frame.
    // Dynamic Win64 frames put physical RBP at its bottom for PE unwinding.
    u32 frame_base_offset;
    bool overflow;
    u8 reserved[3];
};

// These exact-form keys are generated-snapshot identities, not architectural
// opcode numbers.  Keep the stable hash beside the row ID so a regenerated
// metadata snapshot cannot silently route a machine row through another form.
enum
{
    MACHINE_X64_MFENCE_EXACT_FORM_ID = 9610u,
    MACHINE_X64_INT3_EXACT_FORM_ID = 10027u,
    MACHINE_X64_MOV_IMMEDIATE_EXACT_FORM_ID = 10018u,
    MACHINE_X64_MOV_SIGNED_IMMEDIATE_EXACT_FORM_ID = 9533u,
    MACHINE_X64_LEA_EXACT_FORM_ID = 9849u,
    MACHINE_X64_ADD_IMMEDIATE8_EXACT_FORM_ID = 9316u,
    MACHINE_X64_ADD_IMMEDIATE32_EXACT_FORM_ID = 9270u,
    MACHINE_X64_IMUL_IMMEDIATE8_EXACT_FORM_ID = 9748u,
    MACHINE_X64_IMUL_IMMEDIATE32_EXACT_FORM_ID = 9745u,
    MACHINE_X64_MOV_MEMORY_EXACT_FORM_ID = 9845u,
    MACHINE_X64_MOV_MEMORY8_EXACT_FORM_ID = 9840u,
    MACHINE_X64_MOV_MEMORY_FULL_EXACT_FORM_ID = 9841u,
    MACHINE_X64_MOVZX_MEMORY8_EXACT_FORM_ID = 10289u,
    MACHINE_X64_MOVZX_MEMORY16_EXACT_FORM_ID = 10291u,
    MACHINE_X64_MOV_RR_EXACT_FORM_ID = 9842u,
    MACHINE_X64_MOVSX8_RR_EXACT_FORM_ID = 10686u,
    MACHINE_X64_MOVSX16_RR_EXACT_FORM_ID = 10687u,
    MACHINE_X64_MOVSX32_RR_EXACT_FORM_ID = 9742u,
    MACHINE_X64_MOVZX8_RR_EXACT_FORM_ID = 10294u,
    MACHINE_X64_MOVZX16_RR_EXACT_FORM_ID = 10295u,
    MACHINE_X64_ADD_RR_EXACT_FORM_ID = 9620u,
    MACHINE_X64_SUB_RR_EXACT_FORM_ID = 9688u,
    MACHINE_X64_AND_RR_EXACT_FORM_ID = 9675u,
    MACHINE_X64_OR_RR_EXACT_FORM_ID = 9634u,
    MACHINE_X64_XOR_RR_EXACT_FORM_ID = 9701u,
    MACHINE_X64_IMUL_RR_EXACT_FORM_ID = 10673u,
    MACHINE_X64_NEG_R_EXACT_FORM_ID = 9462u,
    MACHINE_X64_NOT_R_EXACT_FORM_ID = 9459u,
    MACHINE_X64_BSF_RR_EXACT_FORM_ID = 8688u,
    MACHINE_X64_BSR_RR_EXACT_FORM_ID = 8105u,
    MACHINE_X64_CMP_RR_EXACT_FORM_ID = 9712u,
    MACHINE_X64_TEST_RR_EXACT_FORM_ID = 9832u,
    MACHINE_X64_POPCNT_RR_EXACT_FORM_ID = 10846u,
    MACHINE_X64_SHIFT_LEFT_R_EXACT_FORM_ID = 9428u,
    MACHINE_X64_SHIFT_ARITHMETIC_R_EXACT_FORM_ID = 9434u,
    MACHINE_X64_SHIFT_RIGHT_R_EXACT_FORM_ID = 9430u,
    MACHINE_X64_JMP_EXACT_FORM_ID = 10060u,
    MACHINE_X64_LEA_SYMBOL_EXACT_FORM_ID = 9849u,
    MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID = 10574u,
    MACHINE_X64_MOVQ_FROM_XMM_EXACT_FORM_ID = 10575u,
    MACHINE_X64_LOAD_INCOMING_EXACT_FORM_ID = 9845u,
    MACHINE_X64_PUSH_REGISTER_EXACT_FORM_ID = 9722u,
    MACHINE_X64_ADD_RSP_EXACT_FORM_ID = 9270u,
    MACHINE_X64_PUSH_FRAME_EXACT_FORM_ID = 9490u,
    MACHINE_X64_VMOV_RR_EXACT_FORM_ID = 5635u,
    MACHINE_X64_VLOAD_EXACT_FORM_ID = 5636u,
    MACHINE_X64_VSTORE_EXACT_FORM_ID = 5638u,
    MACHINE_X64_VPSLLD_EXACT_FORM_ID = 7702u,
    MACHINE_X64_VPTERNLOGD_EXACT_FORM_ID = 7740u,
    MACHINE_X64_VSPLATB_EXACT_FORM_ID = 5841u,
    MACHINE_X64_VSPLATD_EXACT_FORM_ID = 7534u,
    MACHINE_X64_XCHG_EXACT_FORM_ID = 9837u,
    // `xchg r/m8, r8` is opcode 0x86, a different metadata form from the
    // 0x87 row above rather than an operand-size variant of it, so a width-1
    // atomic store had no encoding at all and fell back to the canonical
    // emitter after selecting (#806). Both rows are the nolock spelling: an
    // XCHG with a memory operand locks the bus whether or not LOCK is written.
    MACHINE_X64_XCHG8_EXACT_FORM_ID = 9834u,
    MACHINE_X64_CMPXCHG_EXACT_FORM_ID = 10280u,
    MACHINE_X64_CMPXCHG8_EXACT_FORM_ID = 10278u,
    MACHINE_X64_SUB_RSP_EXACT_FORM_ID = 9285u,
    MACHINE_X64_VPADDB_EXACT_FORM_ID = 5739u,
    MACHINE_X64_VPADDW_EXACT_FORM_ID = 5777u,
    MACHINE_X64_VPADDD_EXACT_FORM_ID = 7515u,
    MACHINE_X64_VPADDQ_EXACT_FORM_ID = 7517u,
    MACHINE_X64_VPSUBB_EXACT_FORM_ID = 6595u,
    MACHINE_X64_VPSUBW_EXACT_FORM_ID = 6633u,
    MACHINE_X64_VPSUBD_EXACT_FORM_ID = 7736u,
    MACHINE_X64_VPSUBQ_EXACT_FORM_ID = 7738u,
    MACHINE_X64_VPANDD_EXACT_FORM_ID = 7519u,
    MACHINE_X64_VPORD_EXACT_FORM_ID = 7674u,
    MACHINE_X64_VPXORD_EXACT_FORM_ID = 7760u,
};

// x86-64 requires SSE2, so the MFENCE exact row always receives the target's
// architectural baseline gate.  INT3 is BASE and deliberately carries no
// optional feature names.
BUSTER_GLOBAL_LOCAL String8 const machine_x64_sse2_features[] = {S8_INITIALIZER("sse2")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_xsave_features[] = {S8_INITIALIZER("xsave")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_pause_features[] = {S8_INITIALIZER("pause")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_sse_features[] = {S8_INITIALIZER("sse")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_avx_features[] = {S8_INITIALIZER("avx")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_popcnt_features[] = {S8_INITIALIZER("popcnt")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_avx512f_features[] = {S8_INITIALIZER("avx512f")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_avx512bw_features[] = {S8_INITIALIZER("avx512f"), S8_INITIALIZER("avx512bw")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_predicate_features[] = {S8_INITIALIZER("avx512f"), S8_INITIALIZER("avx512bw"), S8_INITIALIZER("avx512dq")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_avx512vbmi_features[] = {
    S8_INITIALIZER("avx512f"), S8_INITIALIZER("avx512bw"), S8_INITIALIZER("avx512vbmi")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_avx512vbmi2_features[] = {
    S8_INITIALIZER("avx512f"), S8_INITIALIZER("avx512bw"), S8_INITIALIZER("avx512vbmi2")};
/* Expansion rows use this name for the same architectural AVX-512 baseline. */
BUSTER_GLOBAL_LOCAL String8 const machine_x64_avx512_features[] = {S8_INITIALIZER("avx512f"), S8_INITIALIZER("avx512bw")};
BUSTER_GLOBAL_LOCAL String8 const machine_x64_cx16_features[] = {S8_INITIALIZER("cx16")};

// Expansion/prologue instructions use a small, closed set of physical
// shapes.  Resolve each shape through the metadata selector once during the
// serial prewarm lane and publish only the resulting opaque machine token to
// workers.  The signature deliberately describes physical shape/value
// classes, not register numbers or byte templates; dynamic registers,
// displacements, and immediates are still validated by the metadata transform
// on every emission.
#define MACHINE_X64_METADATA_SHAPE_CACHE_CAPACITY 288u
#define MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY 512u
typedef struct MachineX64MetadataShapeCacheEntry MachineX64MetadataShapeCacheEntry;
struct MachineX64MetadataShapeCacheEntry
{
    u64 signature;
    u64 guard;
    BusterX86MetadataMachineExactToken token;
};
BUSTER_GLOBAL_LOCAL MachineX64MetadataShapeCacheEntry machine_x64_metadata_shape_cache[MACHINE_X64_METADATA_SHAPE_CACHE_CAPACITY];
BUSTER_GLOBAL_LOCAL u16 machine_x64_metadata_shape_cache_slots[MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY];
BUSTER_GLOBAL_LOCAL u32 machine_x64_metadata_shape_cache_count;
BUSTER_GLOBAL_LOCAL u32 machine_x64_metadata_shape_cache_invalid_count;
BUSTER_GLOBAL_LOCAL bool machine_x64_metadata_shape_cache_ready;
BUSTER_CT_CHECK((MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY & (MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY - 1u)) == 0);

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prewarm(void);
BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_fixed_templates(void);

enum
{
    MACHINE_X64_EXACT_RECIPE_FLAG_SELF_COPY_NOOP = 1u << 0,
    MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP = 1u << 1,
    MACHINE_X64_EXACT_RECIPE_FLAG_CALL_SITE = 1u << 2,
    MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32 = 1u << 3,
    MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_LOCK = 1u << 4,
    MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_ONLY = 1u << 5,
    MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_OR = 1u << 6,
};

typedef enum MachineX64ExactOperandProjection
{
    MACHINE_X64_EXACT_OPERAND_GPR,
    MACHINE_X64_EXACT_OPERAND_XMM_PAYLOAD,
    MACHINE_X64_EXACT_OPERAND_XMM_FIXED0,
    MACHINE_X64_EXACT_OPERAND_XMM_FIXED1,
    MACHINE_X64_EXACT_OPERAND_XMM_SLOT,
    MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX,
    MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX,
    MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE,
    MACHINE_X64_EXACT_OPERAND_ZMM_SLOT,
    MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1,
    MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K0,
    MACHINE_X64_EXACT_OPERAND_FIXED_RSP,
    MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD,
    MACHINE_X64_EXACT_OPERAND_IMMEDIATE_CONSTANT,
    // The constant 1: the unsigned less-than predicate of the vpcmp*u* forms,
    // for rows whose payload is already spent on the variant index.
    MACHINE_X64_EXACT_OPERAND_IMMEDIATE_LESS,
    MACHINE_X64_EXACT_OPERAND_RELATIVE_ZERO,
    MACHINE_X64_EXACT_OPERAND_RIP_MEMORY_ZERO,
    MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO,
    MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE,
    MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD,
    MACHINE_X64_EXACT_OPERAND_RBP_MEMORY_PAYLOAD,
    MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD,
    MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_SLOT,
    MACHINE_X64_EXACT_OPERAND_PROJECTION_COUNT,
} MachineX64ExactOperandProjection;

typedef enum MachineX64ExactVariantSelector
{
    MACHINE_X64_EXACT_VARIANT_FIXED,
    MACHINE_X64_EXACT_VARIANT_MOV_IMMEDIATE,
    MACHINE_X64_EXACT_VARIANT_SIGNED_IMMEDIATE,
    MACHINE_X64_EXACT_VARIANT_VBINARY,
    // The payload carries the access width in bytes, and one is a different
    // metadata form rather than a narrower operand of the same one.
    MACHINE_X64_EXACT_VARIANT_PAYLOAD_BYTE_WIDTH,
    MACHINE_X64_EXACT_VARIANT_SELECTOR_COUNT,
} MachineX64ExactVariantSelector;

// The metadata plan cache is keyed by unique durable form keys rather than
// by DIRECT recipe rows: width variants and other projections share one
// immutable normalized form/pattern plan.  Keep the identity compact in the
// row-to-plan map below; no plan pointer or callback enters MachineInstruction.
typedef enum MachineX64ExactPlanId
{
    MACHINE_X64_EXACT_PLAN_MOV,
    MACHINE_X64_EXACT_PLAN_SX8,
    MACHINE_X64_EXACT_PLAN_SX16,
    MACHINE_X64_EXACT_PLAN_SX32,
    MACHINE_X64_EXACT_PLAN_ZX8,
    MACHINE_X64_EXACT_PLAN_ZX16,
    MACHINE_X64_EXACT_PLAN_ADD,
    MACHINE_X64_EXACT_PLAN_SUB,
    MACHINE_X64_EXACT_PLAN_AND,
    MACHINE_X64_EXACT_PLAN_OR,
    MACHINE_X64_EXACT_PLAN_XOR,
    MACHINE_X64_EXACT_PLAN_IMUL,
    MACHINE_X64_EXACT_PLAN_NEG,
    MACHINE_X64_EXACT_PLAN_NOT,
    MACHINE_X64_EXACT_PLAN_BSF,
    MACHINE_X64_EXACT_PLAN_BSR,
    MACHINE_X64_EXACT_PLAN_POPCNT,
    MACHINE_X64_EXACT_PLAN_JMP,
    MACHINE_X64_EXACT_PLAN_SHL,
    MACHINE_X64_EXACT_PLAN_SAR,
    MACHINE_X64_EXACT_PLAN_SHR,
    MACHINE_X64_EXACT_PLAN_LEA_SYMBOL,
    MACHINE_X64_EXACT_PLAN_MOVQ_TO_XMM,
    MACHINE_X64_EXACT_PLAN_MOVQ_FROM_XMM,
    MACHINE_X64_EXACT_PLAN_PUSH,
    MACHINE_X64_EXACT_PLAN_ADD_RSP,
    MACHINE_X64_EXACT_PLAN_CMP,
    MACHINE_X64_EXACT_PLAN_TEST,
    MACHINE_X64_EXACT_PLAN_MFENCE,
    MACHINE_X64_EXACT_PLAN_INT3,
    MACHINE_X64_EXACT_PLAN_LOAD_INCOMING,
    MACHINE_X64_EXACT_PLAN_MOV_IMMEDIATE,
    MACHINE_X64_EXACT_PLAN_MOV_SIGNED_IMMEDIATE,
    MACHINE_X64_EXACT_PLAN_ADD_IMMEDIATE8,
    MACHINE_X64_EXACT_PLAN_IMUL_IMMEDIATE8,
    MACHINE_X64_EXACT_PLAN_IMUL_IMMEDIATE32,
    MACHINE_X64_EXACT_PLAN_STORE8,
    MACHINE_X64_EXACT_PLAN_STORE_FULL,
    MACHINE_X64_EXACT_PLAN_MOVZX8,
    MACHINE_X64_EXACT_PLAN_MOVZX16,
    MACHINE_X64_EXACT_PLAN_PUSH_FRAME,
    MACHINE_X64_EXACT_PLAN_VMOV,
    MACHINE_X64_EXACT_PLAN_VLOAD,
    MACHINE_X64_EXACT_PLAN_VSTORE,
    MACHINE_X64_EXACT_PLAN_VPSLLD,
    MACHINE_X64_EXACT_PLAN_VPADDB,
    MACHINE_X64_EXACT_PLAN_VPADDW,
    MACHINE_X64_EXACT_PLAN_VPADDD,
    MACHINE_X64_EXACT_PLAN_VPADDQ,
    MACHINE_X64_EXACT_PLAN_VPSUBB,
    MACHINE_X64_EXACT_PLAN_VPSUBW,
    MACHINE_X64_EXACT_PLAN_VPSUBD,
    MACHINE_X64_EXACT_PLAN_VPSUBQ,
    MACHINE_X64_EXACT_PLAN_VPANDD,
    MACHINE_X64_EXACT_PLAN_VPORD,
    MACHINE_X64_EXACT_PLAN_VPXORD,
    MACHINE_X64_EXACT_PLAN_VSPLATB,
    MACHINE_X64_EXACT_PLAN_VSPLATD,
    MACHINE_X64_EXACT_PLAN_VPTERNLOGD,
    MACHINE_X64_EXACT_PLAN_XCHG,
    MACHINE_X64_EXACT_PLAN_XCHG8,
    MACHINE_X64_EXACT_PLAN_CMPXCHG,
    MACHINE_X64_EXACT_PLAN_SUB_RSP,
    MACHINE_X64_EXACT_PLAN_COUNT,
    MACHINE_X64_EXACT_PLAN_INVALID = UINT8_MAX,
} MachineX64ExactPlanId;

typedef struct MachineX64ExactRecipe MachineX64ExactRecipe;
typedef struct MachineX64ExactRecipeVariant MachineX64ExactRecipeVariant;
struct MachineX64ExactRecipeVariant
{
    X64ExactFormKey key;
    String8 const* features;
    u32 feature_count;
    u8 operand_count;
    u8 flags;
    u8 operand_slots[4];
    u8 operand_kinds[4];
    u16 operand_widths[4];
};

struct MachineX64ExactRecipe
{
    MachineEmitRecipeId recipe;
    X64ExactFormKey key;
    String8 const* features;
    u32 feature_count;
    u8 operand_count;
    u8 flags;
    u8 operand_slots[4];
    u8 operand_kinds[4];
    u16 operand_widths[4];
    // A family row may select one of a small number of durable forms (for
    // example MOV's zero-extending, sign-extending, and full-width immediate
    // encodings).  Variant zero is the row itself; the optional array holds
    // variants one and onward.  Direct rows keep variant_count at zero.
    u8 variant_count;
    u8 variant_selector;
    u8 reserved[2];
    MachineX64ExactRecipeVariant const* variants;
};

// Composite family rows are represented as a short, immutable sequence of
// metadata forms.  Steps carry the same projections as single-form recipes;
// staging (for example GPR -> k1) is therefore expressed by another exact
// token instead of a handwritten opcode helper.
#define MACHINE_X64_EXACT_SEQUENCE_MAX_VARIANTS 16u
#define MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS 8u
typedef struct MachineX64ExactSequenceStep MachineX64ExactSequenceStep;
typedef struct MachineX64ExactSequenceVariant MachineX64ExactSequenceVariant;
typedef struct MachineX64ExactSequence MachineX64ExactSequence;
struct MachineX64ExactSequenceStep
{
    X64ExactFormKey key;
    String8 const* features;
    u32 feature_count;
    u8 operand_count;
    u8 flags;
    u8 operand_slots[4];
    u8 operand_kinds[4];
    u16 operand_widths[4];
    u8 mask_register_plus_one;
    bool zeroing;
};
struct MachineX64ExactSequenceVariant
{
    u8 step_count;
    MachineX64ExactSequenceStep const* steps;
};
struct MachineX64ExactSequence
{
    MachineEmitRecipeId recipe;
    u8 variant_count;
    u8 variant_selector;
    u8 reserved[2];
    MachineX64ExactSequenceVariant const* variants;
};

BUSTER_GLOBAL_LOCAL MachineX64ExactRecipeVariant machine_x64_exact_recipe_variant(MachineX64ExactRecipe const* recipe, u32 variant_index)
{
    MachineX64ExactRecipeVariant result = {
        .key = recipe->key,
        .features = recipe->features,
        .feature_count = recipe->feature_count,
        .operand_count = recipe->operand_count,
        .flags = recipe->flags,
        .operand_slots = {recipe->operand_slots[0], recipe->operand_slots[1], recipe->operand_slots[2], recipe->operand_slots[3]},
        .operand_kinds = {recipe->operand_kinds[0], recipe->operand_kinds[1], recipe->operand_kinds[2], recipe->operand_kinds[3]},
        .operand_widths = {recipe->operand_widths[0], recipe->operand_widths[1], recipe->operand_widths[2], recipe->operand_widths[3]},
    };
    if (variant_index && variant_index <= recipe->variant_count && recipe->variants)
    {
        result = recipe->variants[variant_index - 1];
    }
    return result;
}

// Flat DIRECT recipe projections.  Each descriptor is keyed by the stable
// MachineEmitRecipeId assigned by machine.c; the operand slots are the
// post-placement machine row slots, in metadata form order (RM/B before
// REG/R for the two-address ALU forms).
// XCHG's byte row. Variant zero is the 0x87 form the recipe itself names,
// which covers widths two, four and eight; a width-1 payload selects this one.
// The operand projections are the same -- they resolve their width from the
// payload -- so only the durable form key differs.
BUSTER_GLOBAL_LOCAL MachineX64ExactRecipeVariant const machine_x64_xchg_variants[] = {
    {.key = {MACHINE_X64_XCHG8_EXACT_FORM_ID, UINT64_C(0x148a08bd76c221bc)}, .operand_count = 2, .operand_slots = {0, 1},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE, MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE}},
};

BUSTER_GLOBAL_LOCAL MachineX64ExactRecipe const machine_x64_exact_recipe_table[MACHINE_X86_64_EMIT_REGISTRY_DIRECT_COUNT] = {
    [0] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 0,
        .key = {MACHINE_X64_MOV_RR_EXACT_FORM_ID, UINT64_C(0x3ab69ab9d0d06329)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_SELF_COPY_NOOP,
        .operand_slots = {0, 1}, .operand_widths = {64, 64},
    },
    [1] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 1,
        .key = {MACHINE_X64_MOV_RR_EXACT_FORM_ID, UINT64_C(0x3ab69ab9d0d06329)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {32, 32},
    },
    [2] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 2,
        .key = {MACHINE_X64_MOVSX8_RR_EXACT_FORM_ID, UINT64_C(0x60113253679881a6)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 8},
    },
    [3] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 3,
        .key = {MACHINE_X64_MOVSX16_RR_EXACT_FORM_ID, UINT64_C(0x1ea1a0d40c380394)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 16},
    },
    [4] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 4,
        .key = {MACHINE_X64_MOVSX32_RR_EXACT_FORM_ID, UINT64_C(0xacab1d188d386b1e)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 32},
    },
    [5] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 5,
        .key = {MACHINE_X64_MOVZX8_RR_EXACT_FORM_ID, UINT64_C(0xa9d675ab86fb1641)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 8},
    },
    [6] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 6,
        .key = {MACHINE_X64_MOVZX16_RR_EXACT_FORM_ID, UINT64_C(0xb25b807d6d5747b3)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 16},
    },
    [7] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 7,
        .key = {MACHINE_X64_ADD_RR_EXACT_FORM_ID, UINT64_C(0xf0743d28f1fbad54)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {32, 32},
    },
    [8] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 8,
        .key = {MACHINE_X64_ADD_RR_EXACT_FORM_ID, UINT64_C(0xf0743d28f1fbad54)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {64, 64},
    },
    [9] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 9,
        .key = {MACHINE_X64_SUB_RR_EXACT_FORM_ID, UINT64_C(0x240ef104bd0b9756)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {32, 32},
    },
    [10] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 10,
        .key = {MACHINE_X64_SUB_RR_EXACT_FORM_ID, UINT64_C(0x240ef104bd0b9756)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {64, 64},
    },
    [11] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 11,
        .key = {MACHINE_X64_AND_RR_EXACT_FORM_ID, UINT64_C(0x65889d347cd743a9)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {32, 32},
    },
    [12] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 12,
        .key = {MACHINE_X64_AND_RR_EXACT_FORM_ID, UINT64_C(0x65889d347cd743a9)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {64, 64},
    },
    [13] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 13,
        .key = {MACHINE_X64_OR_RR_EXACT_FORM_ID, UINT64_C(0x7f76bb71727dbfaa)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {32, 32},
    },
    [14] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 14,
        .key = {MACHINE_X64_OR_RR_EXACT_FORM_ID, UINT64_C(0x7f76bb71727dbfaa)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {64, 64},
    },
    [15] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 15,
        .key = {MACHINE_X64_XOR_RR_EXACT_FORM_ID, UINT64_C(0x915fb23b51f8b7d1)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {32, 32},
    },
    [16] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 16,
        .key = {MACHINE_X64_XOR_RR_EXACT_FORM_ID, UINT64_C(0x915fb23b51f8b7d1)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {64, 64},
    },
    [17] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 17,
        .key = {MACHINE_X64_IMUL_RR_EXACT_FORM_ID, UINT64_C(0x8ad1b7f99185b8ea)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {32, 32},
    },
    [18] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 18,
        .key = {MACHINE_X64_IMUL_RR_EXACT_FORM_ID, UINT64_C(0x8ad1b7f99185b8ea)},
        .operand_count = 2, .operand_slots = {0, 2}, .operand_widths = {64, 64},
    },
    [19] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 19,
        .key = {MACHINE_X64_NEG_R_EXACT_FORM_ID, UINT64_C(0x10bbcf6d744b04f9)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {32},
    },
    [20] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 20,
        .key = {MACHINE_X64_NEG_R_EXACT_FORM_ID, UINT64_C(0x10bbcf6d744b04f9)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {64},
    },
    [21] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 21,
        .key = {MACHINE_X64_NOT_R_EXACT_FORM_ID, UINT64_C(0xbd007ad8742aadfc)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {32},
    },
    [22] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 22,
        .key = {MACHINE_X64_NOT_R_EXACT_FORM_ID, UINT64_C(0xbd007ad8742aadfc)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {64},
    },
    [23] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 23,
        .key = {MACHINE_X64_BSF_RR_EXACT_FORM_ID, UINT64_C(0x047fe78cb986f7d1)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {32, 32},
    },
    [24] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 24,
        .key = {MACHINE_X64_BSF_RR_EXACT_FORM_ID, UINT64_C(0x047fe78cb986f7d1)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 64},
    },
    [25] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 25,
        .key = {MACHINE_X64_BSR_RR_EXACT_FORM_ID, UINT64_C(0x7c13390dbcf0139e)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {32, 32},
    },
    [26] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 26,
        .key = {MACHINE_X64_BSR_RR_EXACT_FORM_ID, UINT64_C(0x7c13390dbcf0139e)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 64},
    },
    [27] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 27,
        .key = {MACHINE_X64_POPCNT_RR_EXACT_FORM_ID, UINT64_C(0xb971fc2e8a6cb1bc)},
        .features = machine_x64_popcnt_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_popcnt_features),
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {32, 32},
    },
    [28] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 28,
        .key = {MACHINE_X64_POPCNT_RR_EXACT_FORM_ID, UINT64_C(0xb971fc2e8a6cb1bc)},
        .features = machine_x64_popcnt_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_popcnt_features),
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 64},
    },
    [32] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 32,
        .key = {MACHINE_X64_JMP_EXACT_FORM_ID, UINT64_C(0xab9c4b53fce14f6e)},
        .operand_count = 1, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP,
        .operand_slots = {0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RELATIVE_ZERO}, .operand_widths = {32},
    },
    [33] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 33,
        .key = {MACHINE_X64_SHIFT_LEFT_R_EXACT_FORM_ID, UINT64_C(0xe73cf970ddf68ce2)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {32},
    },
    [34] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 34,
        .key = {MACHINE_X64_SHIFT_LEFT_R_EXACT_FORM_ID, UINT64_C(0xe73cf970ddf68ce2)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {64},
    },
    [35] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 35,
        .key = {MACHINE_X64_SHIFT_ARITHMETIC_R_EXACT_FORM_ID, UINT64_C(0xa64cc273e7d95e92)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {32},
    },
    [36] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 36,
        .key = {MACHINE_X64_SHIFT_ARITHMETIC_R_EXACT_FORM_ID, UINT64_C(0xa64cc273e7d95e92)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {64},
    },
    [37] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 37,
        .key = {MACHINE_X64_SHIFT_RIGHT_R_EXACT_FORM_ID, UINT64_C(0x1fb65789e301333f)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {32},
    },
    [38] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 38,
        .key = {MACHINE_X64_SHIFT_RIGHT_R_EXACT_FORM_ID, UINT64_C(0x1fb65789e301333f)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {64},
    },
    [39] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 39,
        .key = {MACHINE_X64_LEA_SYMBOL_EXACT_FORM_ID, UINT64_C(0x0b357f27b62f3409)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_CALL_SITE,
        .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_RIP_MEMORY_ZERO},
        .operand_widths = {64, 64},
    },
    [40] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 40,
        .key = {MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID, UINT64_C(0x7bd465046ab10c4f)},
        .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features),
        .operand_count = 2, .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_PAYLOAD, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64},
    },
    [41] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 41,
        .key = {MACHINE_X64_MOVQ_FROM_XMM_EXACT_FORM_ID, UINT64_C(0x3698d9bff62c4360)},
        .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features),
        .operand_count = 2, .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_PAYLOAD}, .operand_widths = {64, 128},
    },
    [42] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 42,
        .key = {MACHINE_X64_LOAD_INCOMING_EXACT_FORM_ID, UINT64_C(0xca30e68cfa1406bc)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_RBP_MEMORY_PAYLOAD},
        .operand_widths = {64, 64},
    },
    [43] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 43,
        .key = {MACHINE_X64_PUSH_REGISTER_EXACT_FORM_ID, UINT64_C(0x849cc7557c589605)},
        .operand_count = 1, .operand_slots = {0}, .operand_widths = {64},
    },
    [44] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 44,
        .key = {MACHINE_X64_ADD_RSP_EXACT_FORM_ID, UINT64_C(0xcebed63a599832c0)},
        .operand_count = 2, .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_FIXED_RSP, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD}, .operand_widths = {64, 32},
    },
    [29] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 29,
        .key = {MACHINE_X64_CMP_RR_EXACT_FORM_ID, UINT64_C(0xa381563e623950cd)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {32, 32},
    },
    [30] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 30,
        .key = {MACHINE_X64_CMP_RR_EXACT_FORM_ID, UINT64_C(0xa381563e623950cd)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 64},
    },
    [31] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 31,
        .key = {MACHINE_X64_TEST_RR_EXACT_FORM_ID, UINT64_C(0x29ceea139128c1a6)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_widths = {64, 64},
    },
    [45] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 45,
        .key = {MACHINE_X64_MFENCE_EXACT_FORM_ID, UINT64_C(0x8deb7f066b773767)},
        .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features),
    },
    [46] = {
        .recipe = MACHINE_EMIT_RECIPE_DIRECT_BASE + 46,
        .key = {MACHINE_X64_INT3_EXACT_FORM_ID, UINT64_C(0x11eeb10ba44771fd)},
    },
};

// FAMILY rows migrated to the metadata bridge.  The first cohort keeps the
// machine selector's original opcode identities while replacing each
// handwritten byte template with one or more durable form keys.  Immediate
// rows use variants to retain the old shortest-form choice; memory rows carry
// the exact operand width and frame-displacement policy in their descriptors.
BUSTER_GLOBAL_LOCAL MachineX64ExactRecipeVariant const machine_x64_mov_ri_variants[] = {
    {
        .key = {MACHINE_X64_MOV_SIGNED_IMMEDIATE_EXACT_FORM_ID, UINT64_C(0x2f91860fef63a638)},
        .operand_count = 2,
        .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD},
        .operand_widths = {64, 32},
    },
    {
        .key = {MACHINE_X64_MOV_IMMEDIATE_EXACT_FORM_ID, UINT64_C(0x2a2535c90ada7adc)},
        .operand_count = 2,
        .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD},
        .operand_widths = {64, 64},
    },
};

#define MACHINE_X64_VBINARY_VARIANT_COUNT 10u
BUSTER_GLOBAL_LOCAL MachineX64ExactRecipeVariant const machine_x64_vbinary_variants[MACHINE_X64_VBINARY_VARIANT_COUNT];

BUSTER_GLOBAL_LOCAL MachineX64ExactRecipeVariant const machine_x64_add_imm_variants[] = {
    {
        .key = {MACHINE_X64_ADD_IMMEDIATE32_EXACT_FORM_ID, UINT64_C(0xcebed63a599832c0)},
        .operand_count = 2,
        .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD},
        .operand_widths = {64, 32},
    },
};

BUSTER_GLOBAL_LOCAL MachineX64ExactRecipeVariant const machine_x64_imul_imm_variants[] = {
    {
        .key = {MACHINE_X64_IMUL_IMMEDIATE32_EXACT_FORM_ID, UINT64_C(0x0c283301d404723a)},
        .operand_count = 3,
        .operand_slots = {0, 1, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD},
        .operand_widths = {64, 64, 32},
    },
};

BUSTER_GLOBAL_LOCAL MachineX64ExactRecipeVariant const machine_x64_vbinary_variants[] = {
    {.key = {MACHINE_X64_VPADDW_EXACT_FORM_ID, UINT64_C(0xc226488b97c949be)}, .features = machine_x64_avx512bw_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPADDD_EXACT_FORM_ID, UINT64_C(0xa91a25d8b3eabcb3)}, .features = machine_x64_avx512f_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPADDQ_EXACT_FORM_ID, UINT64_C(0x0bd74fee16f80704)}, .features = machine_x64_avx512f_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPSUBB_EXACT_FORM_ID, UINT64_C(0x46bb97c7e362ab9c)}, .features = machine_x64_avx512bw_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPSUBW_EXACT_FORM_ID, UINT64_C(0xe58ae9721b6de3e6)}, .features = machine_x64_avx512bw_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPSUBD_EXACT_FORM_ID, UINT64_C(0x535e16651bc218c4)}, .features = machine_x64_avx512f_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPSUBQ_EXACT_FORM_ID, UINT64_C(0xd390b11ac7f6e1db)}, .features = machine_x64_avx512f_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPANDD_EXACT_FORM_ID, UINT64_C(0x4903e85df3a91181)}, .features = machine_x64_avx512f_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPORD_EXACT_FORM_ID, UINT64_C(0x72940a7ae71f5658)}, .features = machine_x64_avx512f_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
    {.key = {MACHINE_X64_VPXORD_EXACT_FORM_ID, UINT64_C(0x1b33e7cdaa3916be)}, .features = machine_x64_avx512f_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features), .operand_count = 3, .operand_slots = {0, 1, 2},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT},
     .operand_widths = {512, 512, 512}},
};

BUSTER_GLOBAL_LOCAL MachineX64ExactRecipe const machine_x64_family_exact_recipe_table[MACHINE_X86_64_EMIT_REGISTRY_FAMILY_COUNT] = {
    [0] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 0,
        .key = {MACHINE_X64_MOV_IMMEDIATE_EXACT_FORM_ID, UINT64_C(0x2a2535c90ada7adc)},
        .operand_count = 2,
        .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD},
        .operand_widths = {32, 32},
        .variant_count = BUSTER_ARRAY_LENGTH(machine_x64_mov_ri_variants),
        .variant_selector = MACHINE_X64_EXACT_VARIANT_MOV_IMMEDIATE,
        .variants = machine_x64_mov_ri_variants,
    },
    [1] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 1,
        .key = {MACHINE_X64_LEA_EXACT_FORM_ID, UINT64_C(0x0b357f27b62f3409)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD},
        .operand_widths = {64, 64},
    },
    [2] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 2,
        .key = {MACHINE_X64_ADD_IMMEDIATE8_EXACT_FORM_ID, UINT64_C(0xc4d75f09ceeb4f69)},
        .operand_count = 2,
        .operand_slots = {0, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD},
        .operand_widths = {64, 8},
        .variant_count = BUSTER_ARRAY_LENGTH(machine_x64_add_imm_variants),
        .variant_selector = MACHINE_X64_EXACT_VARIANT_SIGNED_IMMEDIATE,
        .variants = machine_x64_add_imm_variants,
    },
    [3] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 3,
        .key = {MACHINE_X64_IMUL_IMMEDIATE8_EXACT_FORM_ID, UINT64_C(0xcc57ef111fd55ec5)},
        .operand_count = 3,
        .operand_slots = {0, 1, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD},
        .operand_widths = {64, 64, 8},
        .variant_count = BUSTER_ARRAY_LENGTH(machine_x64_imul_imm_variants),
        .variant_selector = MACHINE_X64_EXACT_VARIANT_SIGNED_IMMEDIATE,
        .variants = machine_x64_imul_imm_variants,
    },
    [4] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 4,
        .key = {MACHINE_X64_MOV_MEMORY_EXACT_FORM_ID, UINT64_C(0xca30e68cfa1406bc)},
        .operand_count = 2,
        .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD},
        .operand_widths = {64, 64},
    },
    [5] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 5,
        .key = {MACHINE_X64_MOV_MEMORY8_EXACT_FORM_ID, UINT64_C(0xe7a77cae08617d2d)},
        .operand_count = 2,
        .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {8, 8},
    },
    [6] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 6,
        .key = {MACHINE_X64_MOV_MEMORY_FULL_EXACT_FORM_ID, UINT64_C(0xa4ef94df2e338694)},
        .operand_count = 2,
        .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {16, 16},
    },
    [7] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 7,
        .key = {MACHINE_X64_MOV_MEMORY_FULL_EXACT_FORM_ID, UINT64_C(0xa4ef94df2e338694)},
        .operand_count = 2,
        .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {32, 32},
    },
    [8] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 8,
        .key = {MACHINE_X64_MOV_MEMORY_FULL_EXACT_FORM_ID, UINT64_C(0xa4ef94df2e338694)},
        .operand_count = 2,
        .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {64, 64},
    },
    [9] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 9,
        .key = {MACHINE_X64_MOVZX_MEMORY8_EXACT_FORM_ID, UINT64_C(0x6d04093431c32330)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO},
        .operand_widths = {64, 8},
    },
    [10] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 10,
        .key = {MACHINE_X64_MOVZX_MEMORY16_EXACT_FORM_ID, UINT64_C(0xa910655fd16f6729)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO},
        .operand_widths = {64, 16},
    },
    [11] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 11,
        .key = {MACHINE_X64_MOV_MEMORY_EXACT_FORM_ID, UINT64_C(0xca30e68cfa1406bc)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO},
        .operand_widths = {32, 32},
    },
    [12] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 12,
        .key = {MACHINE_X64_MOV_MEMORY_EXACT_FORM_ID, UINT64_C(0xca30e68cfa1406bc)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO},
        .operand_widths = {64, 64},
    },
    [13] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 13,
        .key = {MACHINE_X64_MOV_MEMORY8_EXACT_FORM_ID, UINT64_C(0xe7a77cae08617d2d)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {8, 8},
    },
    [14] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 14,
        .key = {MACHINE_X64_MOV_MEMORY_FULL_EXACT_FORM_ID, UINT64_C(0xa4ef94df2e338694)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {16, 16},
    },
    [15] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 15,
        .key = {MACHINE_X64_MOV_MEMORY_FULL_EXACT_FORM_ID, UINT64_C(0xa4ef94df2e338694)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {32, 32},
    },
    [16] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 16,
        .key = {MACHINE_X64_MOV_MEMORY_FULL_EXACT_FORM_ID, UINT64_C(0xa4ef94df2e338694)},
        .operand_count = 2,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {64, 64},
    },
    [17] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 17,
        .key = {MACHINE_X64_LEA_EXACT_FORM_ID, UINT64_C(0x0b357f27b62f3409)},
        .operand_count = 2,
        .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD},
        .operand_widths = {64, 64},
    },
    [18] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 18,
        .key = {MACHINE_X64_PUSH_FRAME_EXACT_FORM_ID, UINT64_C(0x18f2cf99c5297c27)},
        .operand_count = 1, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32,
        .operand_slots = {0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD}, .operand_widths = {64},
    },
    [19] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 19,
        .key = {MACHINE_X64_VMOV_RR_EXACT_FORM_ID, UINT64_C(0xea537c4b94111b09)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_SELF_COPY_NOOP, .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {512, 512},
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [20] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 20,
        .key = {MACHINE_X64_VLOAD_EXACT_FORM_ID, UINT64_C(0x62bba0430900201e)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32, .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_SLOT}, .operand_widths = {512, 8},
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [21] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 21,
        .key = {MACHINE_X64_VSTORE_EXACT_FORM_ID, UINT64_C(0xa3f8bbb35dcafc20)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32, .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {8, 512},
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [22] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 22,
        .key = {MACHINE_X64_VLOAD_EXACT_FORM_ID, UINT64_C(0x62bba0430900201e)}, .operand_count = 2, .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO}, .operand_widths = {512, 8},
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [23] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 23,
        .key = {MACHINE_X64_VSTORE_EXACT_FORM_ID, UINT64_C(0xa3f8bbb35dcafc20)}, .operand_count = 2, .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {8, 512},
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [24] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 24,
        .key = {MACHINE_X64_VPSLLD_EXACT_FORM_ID, UINT64_C(0x47cd9f2fa72e4408)}, .operand_count = 3, .operand_slots = {0, 1, 0},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD}, .operand_widths = {512, 512, 8},
        .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
    },
    [25] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 25,
        .key = {MACHINE_X64_VPADDB_EXACT_FORM_ID, UINT64_C(0x9fc171a572e6eeae)}, .operand_count = 3, .operand_slots = {0, 1, 2},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {512, 512, 512},
        .variant_count = MACHINE_X64_VBINARY_VARIANT_COUNT, .variant_selector = MACHINE_X64_EXACT_VARIANT_VBINARY, .variants = machine_x64_vbinary_variants,
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [32] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 32, .key = {MACHINE_X64_VSPLATB_EXACT_FORM_ID, UINT64_C(0x5db141a5417ed3f6)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {512, 32},
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [49] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 49, .key = {MACHINE_X64_VSPLATD_EXACT_FORM_ID, UINT64_C(0xf65793e9357098c7)},
        .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {512, 32},
        .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
    },
    [33] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 33, .key = {MACHINE_X64_VPTERNLOGD_EXACT_FORM_ID, UINT64_C(0x61fc34c1d8f6da45)},
        .operand_count = 4, .operand_slots = {0, 1, 2, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD}, .operand_widths = {512, 512, 512, 8},
        .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
    },
    [34] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 34, .key = {MACHINE_X64_XCHG_EXACT_FORM_ID, UINT64_C(0x100612d3d9f27042)},
        .operand_count = 2, .operand_slots = {0, 1},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE, MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE},
        .variant_count = BUSTER_ARRAY_LENGTH(machine_x64_xchg_variants),
        .variant_selector = MACHINE_X64_EXACT_VARIANT_PAYLOAD_BYTE_WIDTH, .variants = machine_x64_xchg_variants,
    },
    [35] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 35, .key = {MACHINE_X64_CMPXCHG_EXACT_FORM_ID, UINT64_C(0x46a888e2c049f87a)},
        .operand_count = 2, .operand_slots = {1, 3}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE, MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE},
    },
    [46] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 46, .key = {MACHINE_X64_SUB_RSP_EXACT_FORM_ID, UINT64_C(0xb9527cc38accf111)},
        .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_FIXED_RSP, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD}, .operand_widths = {64, 32},
    },
};

// Composite descriptors are dense by family index.  Rows not yet carrying a
// validated metadata vocabulary remain zero and consequently fail closed in
// the worker lane rather than re-entering the handwritten switch.
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cmpxchg_sequence_steps[] = {
    {
        .key = {MACHINE_X64_MOV_RR_EXACT_FORM_ID, UINT64_C(0x3ab69ab9d0d06329)},
        .operand_count = 2, .operand_slots = {0, 2},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {64, 64},
    },
    {
        .key = {MACHINE_X64_CMPXCHG_EXACT_FORM_ID, UINT64_C(0x46a888e2c049f87a)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_LOCK,
        .operand_slots = {1, 3},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE, MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE},
        .operand_widths = {0, 0},
    },
};
// CMPXCHG's byte row, for the same reason XCHG needs one: `cmpxchg r/m8, r8`
// is 0x0F 0xB0, a different metadata form from the 0x0F 0xB1 row above rather
// than an operand-size variant of it, so a width-1 compare-exchange selected
// and then failed to encode. The staging MOV is unchanged -- it loads the
// expected value into RAX, and the byte compare reads AL out of it.
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cmpxchg8_sequence_steps[] = {
    {
        .key = {MACHINE_X64_MOV_RR_EXACT_FORM_ID, UINT64_C(0x3ab69ab9d0d06329)},
        .operand_count = 2, .operand_slots = {0, 2},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX, MACHINE_X64_EXACT_OPERAND_GPR},
        .operand_widths = {64, 64},
    },
    {
        .key = {MACHINE_X64_CMPXCHG8_EXACT_FORM_ID, UINT64_C(0xd8600a40453775c4)},
        .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_LOCK,
        .operand_slots = {1, 3},
        .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE, MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE},
        .operand_widths = {0, 0},
    },
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_cmpxchg_sequence_variants[] = {
    {.step_count = 2, .steps = machine_x64_cmpxchg_sequence_steps},
    {.step_count = 2, .steps = machine_x64_cmpxchg8_sequence_steps},
};

// Scalar floating-point rows retain the canonical two-address scratch
// convention (XMM0 receives the integer bit pattern, the conversion reads
// and writes XMM0, and the result is copied back to the allocated GPR).  Each
// byte-producing step is a durable metadata form; the sequence merely stages
// the fixed scratch register through the existing exact MOVQ forms.
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cvt_f32_f64_sequence_steps[] = {
    {.key = {MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID, UINT64_C(0x7bd465046ab10c4f)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 1},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}},
    {.key = {10509u, UINT64_C(0xd0ebceb2f65c639d)}, .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {128, 128}},
    {.key = {MACHINE_X64_MOVQ_FROM_XMM_EXACT_FORM_ID, UINT64_C(0x3698d9bff62c4360)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {64, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cvt_f64_f32_sequence_steps[] = {
    {.key = {MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID, UINT64_C(0x7bd465046ab10c4f)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 1},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}},
    {.key = {10541u, UINT64_C(0x1d8915237e1a0dca)}, .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {128, 128}},
    {.key = {MACHINE_X64_MOVQ_FROM_XMM_EXACT_FORM_ID, UINT64_C(0x3698d9bff62c4360)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {64, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cvt_i64_f32_sequence_steps[] = {
    {.key = {10436u, UINT64_C(0x8632f672b995b8ef)}, .features = machine_x64_sse_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse_features), .operand_count = 2, .operand_slots = {0, 1},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}},
    {.key = {MACHINE_X64_MOVQ_FROM_XMM_EXACT_FORM_ID, UINT64_C(0x3698d9bff62c4360)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {64, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cvt_i64_f64_sequence_steps[] = {
    {.key = {10463u, UINT64_C(0x6b1b449f0ed1e10e)}, .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 1},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}},
    {.key = {MACHINE_X64_MOVQ_FROM_XMM_EXACT_FORM_ID, UINT64_C(0x3698d9bff62c4360)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {64, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cvt_f32_i64_sequence_steps[] = {
    {.key = {MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID, UINT64_C(0x7bd465046ab10c4f)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 1},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}},
    {.key = {10440u, UINT64_C(0x443fee16922dd4d2)}, .features = machine_x64_sse_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {64, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_cvt_f64_i64_sequence_steps[] = {
    {.key = {MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID, UINT64_C(0x7bd465046ab10c4f)}, .features = machine_x64_sse2_features,
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 1},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}},
    {.key = {10467u, UINT64_C(0xdb7e2aa7c56853cf)}, .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0},
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {64, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_cvt_f32_f64_sequence_variants[] = {{.step_count = 3, .steps = machine_x64_cvt_f32_f64_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_cvt_f64_f32_sequence_variants[] = {{.step_count = 3, .steps = machine_x64_cvt_f64_f32_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_cvt_i64_f32_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_cvt_i64_f32_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_cvt_i64_f64_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_cvt_i64_f64_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_cvt_f32_i64_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_cvt_f32_i64_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_cvt_f64_i64_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_cvt_f64_i64_sequence_steps}};

// Scalar floating arithmetic uses the same two-address XMM scratch convention
// as the legacy selector.  The arithmetic forms themselves are canonical
// metadata tokens; all integer/XMM staging remains in the exact sequence.
#define MACHINE_X64_FP_MOVQ_TO_STEP(slot_value) \
    {.key = {MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID, UINT64_C(0x7bd465046ab10c4f)}, .features = machine_x64_sse2_features, \
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, slot_value}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}}
#define MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(slot_value) \
    {.key = {MACHINE_X64_MOVQ_TO_XMM_EXACT_FORM_ID, UINT64_C(0x7bd465046ab10c4f)}, .features = machine_x64_sse2_features, \
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, slot_value}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED1, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {128, 64}}
#define MACHINE_X64_FP_ARITH_STEP(form_id, form_hash) \
    {.key = {form_id, form_hash}, .features = machine_x64_sse_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse_features), .operand_count = 2, .operand_slots = {0, 0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_XMM_FIXED1}, .operand_widths = {128, 128}}
#define MACHINE_X64_FP_ARITH_SSE2_STEP(form_id, form_hash) \
    {.key = {form_id, form_hash}, .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_XMM_FIXED1}, .operand_widths = {128, 128}}
#define MACHINE_X64_FP_MOVQ_FROM_STEP \
    {.key = {MACHINE_X64_MOVQ_FROM_XMM_EXACT_FORM_ID, UINT64_C(0x3698d9bff62c4360)}, .features = machine_x64_sse2_features, \
     .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_XMM_FIXED0}, .operand_widths = {64, 128}}

BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_farith_sequence_steps[8][4] = {
    [0] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_STEP(10505u, 0xb7548ac43adc345e), MACHINE_X64_FP_MOVQ_FROM_STEP},
    [1] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_STEP(10513u, 0x9444e608b81120dc), MACHINE_X64_FP_MOVQ_FROM_STEP},
    [2] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_STEP(10507u, 0x5cc22ab1a19a6e33), MACHINE_X64_FP_MOVQ_FROM_STEP},
    [3] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_STEP(10517u, 0xa367cc47795a1141), MACHINE_X64_FP_MOVQ_FROM_STEP},
    [4] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_SSE2_STEP(10537u, 0x64c1f66df6f45674), MACHINE_X64_FP_MOVQ_FROM_STEP},
    [5] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_SSE2_STEP(10543u, 0x1b16db007692b16b), MACHINE_X64_FP_MOVQ_FROM_STEP},
    [6] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_SSE2_STEP(10539u, 0xa16076f1418ba607), MACHINE_X64_FP_MOVQ_FROM_STEP},
    [7] = {MACHINE_X64_FP_MOVQ_TO_STEP(1), MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FP_ARITH_SSE2_STEP(10547u, 0x96856051e8170cbf), MACHINE_X64_FP_MOVQ_FROM_STEP},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_farith_sequence_variants[] = {
    [0] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[0]},
    [1] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[1]},
    [2] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[2]},
    [3] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[3]},
    [4] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[4]},
    [5] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[5]},
    [6] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[6]},
    [7] = {.step_count = 4, .steps = machine_x64_farith_sequence_steps[7]},
};

// FCMP_SET's parity repair is encoded with the exact SETNP/AND pair as the
// primary token.  For the OR-parity variants the worker swaps those two
// metadata tokens for SETP/OR; no byte template enters the sequence path.
#define MACHINE_X64_FCMP_MOVQ_TO_STEP(slot_value) MACHINE_X64_FP_MOVQ_TO_STEP(slot_value)
#define MACHINE_X64_FCMP_MOVQ_TO_XMM1_STEP(slot_value) MACHINE_X64_FP_MOVQ_TO_XMM1_STEP(slot_value)
#define MACHINE_X64_FCMP_COMI_STEP(form_id, form_hash) \
    {.key = {form_id, form_hash}, .features = machine_x64_sse2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features), .operand_count = 2, .operand_slots = {0, 0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_FIXED0, MACHINE_X64_EXACT_OPERAND_XMM_FIXED1}, .operand_widths = {128, 128}}
#define MACHINE_X64_FCMP_SETCC_STEP(form_id, form_hash) \
    {.key = {form_id, form_hash}, .operand_count = 1, .operand_slots = {0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX}, \
     .operand_widths = {8}}
#define MACHINE_X64_FCMP_PARITY_SETNP_STEP \
    {.key = {10649u, UINT64_C(0xd15c6a2ed2b79fc2)}, .operand_count = 1, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_ONLY, .operand_slots = {0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX}, .operand_widths = {8}}
#define MACHINE_X64_FCMP_PARITY_AND_STEP \
    {.key = {9672u, UINT64_C(0xcbdfecbe7e216f54)}, .operand_count = 2, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_ONLY | MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_OR, .operand_slots = {0, 0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX, MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX}, .operand_widths = {8, 8}}
#define MACHINE_X64_FCMP_MOVZX_STEP \
    {.key = {MACHINE_X64_MOVZX8_RR_EXACT_FORM_ID, UINT64_C(0xa9d675ab86fb1641)}, .operand_count = 2, .operand_slots = {0, 0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX, MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX}, .operand_widths = {64, 8}}
#define MACHINE_X64_FCMP_STEPS(comi_id, comi_hash, set_id, set_hash) \
    {MACHINE_X64_FCMP_MOVQ_TO_STEP(1), MACHINE_X64_FCMP_MOVQ_TO_XMM1_STEP(2), MACHINE_X64_FCMP_COMI_STEP(comi_id, comi_hash), \
     MACHINE_X64_FCMP_SETCC_STEP(set_id, set_hash), MACHINE_X64_FCMP_PARITY_SETNP_STEP, MACHINE_X64_FCMP_PARITY_AND_STEP, MACHINE_X64_FCMP_MOVZX_STEP}

BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_fcmp_set_sequence_steps[12][7] = {
    [0] = MACHINE_X64_FCMP_STEPS(10432u, 0x513be0a63ce4f782, 10265u, 0x261b81212af08017),
    [1] = MACHINE_X64_FCMP_STEPS(10432u, 0x513be0a63ce4f782, 10267u, 0x99647caf50cf7fff),
    [2] = MACHINE_X64_FCMP_STEPS(10432u, 0x513be0a63ce4f782, 10261u, 0x0bc47fa18ee6a6de),
    [3] = MACHINE_X64_FCMP_STEPS(10432u, 0x513be0a63ce4f782, 10269u, 0x73419bd793371f04),
    [4] = MACHINE_X64_FCMP_STEPS(10432u, 0x513be0a63ce4f782, 10271u, 0x4c681fe5d1e14b1),
    [5] = MACHINE_X64_FCMP_STEPS(10432u, 0x513be0a63ce4f782, 10263u, 0x7022443cd4a81cf5),
    [6] = MACHINE_X64_FCMP_STEPS(10459u, 0x32db225c1a1533da, 10265u, 0x261b81212af08017),
    [7] = MACHINE_X64_FCMP_STEPS(10459u, 0x32db225c1a1533da, 10267u, 0x99647caf50cf7fff),
    [8] = MACHINE_X64_FCMP_STEPS(10459u, 0x32db225c1a1533da, 10261u, 0x0bc47fa18ee6a6de),
    [9] = MACHINE_X64_FCMP_STEPS(10459u, 0x32db225c1a1533da, 10269u, 0x73419bd793371f04),
    [10] = MACHINE_X64_FCMP_STEPS(10459u, 0x32db225c1a1533da, 10271u, 0x4c681fe5d1e14b1),
    [11] = MACHINE_X64_FCMP_STEPS(10459u, 0x32db225c1a1533da, 10263u, 0x7022443cd4a81cf5),
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_fcmp_set_sequence_variants[] = {
    [0] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[0]},
    [1] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[1]},
    [2] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[2]},
    [3] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[3]},
    [4] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[4]},
    [5] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[5]},
    [6] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[6]},
    [7] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[7]},
    [8] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[8]},
    [9] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[9]},
    [10] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[10]},
    [11] = {.step_count = 7, .steps = machine_x64_fcmp_set_sequence_steps[11]},
};

BUSTER_GLOBAL_LOCAL BusterX86MetadataMachineExactToken machine_x64_fcmp_setp_token;
BUSTER_GLOBAL_LOCAL BusterX86MetadataMachineExactToken machine_x64_fcmp_or_token;
BUSTER_GLOBAL_LOCAL bool machine_x64_fcmp_alternate_tokens_valid;

#define MACHINE_X64_SETCC_STEP(form_id, form_hash) \
    {.key = {form_id, form_hash}, .operand_count = 1, .operand_slots = {0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX}, .operand_widths = {8}}
#define MACHINE_X64_SETCC_MOVZX_STEP \
    {.key = {MACHINE_X64_MOVZX8_RR_EXACT_FORM_ID, UINT64_C(0xa9d675ab86fb1641)}, .operand_count = 2, .operand_slots = {0, 0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX, MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX}, .operand_widths = {64, 8}}
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_setcc_sequence_steps[16][2] = {
    [0] = {MACHINE_X64_SETCC_STEP(10257u, 0x31ddc1ed865a5575), MACHINE_X64_SETCC_MOVZX_STEP},
    [1] = {MACHINE_X64_SETCC_STEP(10259u, 0x81dd033fae75c1c6), MACHINE_X64_SETCC_MOVZX_STEP},
    [2] = {MACHINE_X64_SETCC_STEP(10261u, 0x0bc47fa18ee6a6de), MACHINE_X64_SETCC_MOVZX_STEP},
    [3] = {MACHINE_X64_SETCC_STEP(10263u, 0x7022443cd4a81cf5), MACHINE_X64_SETCC_MOVZX_STEP},
    [4] = {MACHINE_X64_SETCC_STEP(10265u, 0x261b81212af08017), MACHINE_X64_SETCC_MOVZX_STEP},
    [5] = {MACHINE_X64_SETCC_STEP(10267u, 0x99647caf50cf7fff), MACHINE_X64_SETCC_MOVZX_STEP},
    [6] = {MACHINE_X64_SETCC_STEP(10269u, 0x73419bd793371f04), MACHINE_X64_SETCC_MOVZX_STEP},
    [7] = {MACHINE_X64_SETCC_STEP(10271u, 0x4c681fe5d1e14b1), MACHINE_X64_SETCC_MOVZX_STEP},
    [8] = {MACHINE_X64_SETCC_STEP(10643u, 0x0f501b348d5ad3ab), MACHINE_X64_SETCC_MOVZX_STEP},
    [9] = {MACHINE_X64_SETCC_STEP(10645u, 0xe718192d18926b3f), MACHINE_X64_SETCC_MOVZX_STEP},
    [10] = {MACHINE_X64_SETCC_STEP(10647u, 0x65dc8e342334f3cb), MACHINE_X64_SETCC_MOVZX_STEP},
    [11] = {MACHINE_X64_SETCC_STEP(10649u, 0xd15c6a2ed2b79fc2), MACHINE_X64_SETCC_MOVZX_STEP},
    [12] = {MACHINE_X64_SETCC_STEP(10651u, 0xb45e8ae6fd038751), MACHINE_X64_SETCC_MOVZX_STEP},
    [13] = {MACHINE_X64_SETCC_STEP(10653u, 0x4efeb1d47cbd56a0), MACHINE_X64_SETCC_MOVZX_STEP},
    [14] = {MACHINE_X64_SETCC_STEP(10655u, 0x6e81bfd37e941496), MACHINE_X64_SETCC_MOVZX_STEP},
    [15] = {MACHINE_X64_SETCC_STEP(10657u, 0xa2843c8dd1c8c547), MACHINE_X64_SETCC_MOVZX_STEP},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_setcc_sequence_variants[] = {
    [0] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[0]},
    [1] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[1]},
    [2] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[2]},
    [3] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[3]},
    [4] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[4]},
    [5] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[5]},
    [6] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[6]},
    [7] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[7]},
    [8] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[8]},
    [9] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[9]},
    [10] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[10]},
    [11] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[11]},
    [12] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[12]},
    [13] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[13]},
    [14] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[14]},
    [15] = {.step_count = 2, .steps = machine_x64_setcc_sequence_steps[15]},
};

#define MACHINE_X64_JCC_STEP(form_id, form_hash) \
    {.key = {form_id, form_hash}, .operand_count = 1, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP, .operand_slots = {0}, \
     .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RELATIVE_ZERO}, .operand_widths = {32}}
#define MACHINE_X64_JMP_STEP \
    {.key = {MACHINE_X64_JMP_EXACT_FORM_ID, UINT64_C(0xab9c4b53fce14f6e)}, .operand_count = 1, .flags = MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP, \
     .operand_slots = {1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_RELATIVE_ZERO}, .operand_widths = {32}}
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_jcc_sequence_steps[16][2] = {
    [0] = {MACHINE_X64_JCC_STEP(10240u, 0x663680e7ff926f87), MACHINE_X64_JMP_STEP},
    [1] = {MACHINE_X64_JCC_STEP(10243u, 0x5b0b1a9540ee71fb), MACHINE_X64_JMP_STEP},
    [2] = {MACHINE_X64_JCC_STEP(10245u, 0x311d2176cc680771), MACHINE_X64_JMP_STEP},
    [3] = {MACHINE_X64_JCC_STEP(10247u, 0xb78eb0afc41232dd), MACHINE_X64_JMP_STEP},
    [4] = {MACHINE_X64_JCC_STEP(10249u, 0x5b6e3cd6eb63b76c), MACHINE_X64_JMP_STEP},
    [5] = {MACHINE_X64_JCC_STEP(10251u, 0x4d8e220c403f8696), MACHINE_X64_JMP_STEP},
    [6] = {MACHINE_X64_JCC_STEP(10253u, 0xd3e93216ca69f952), MACHINE_X64_JMP_STEP},
    [7] = {MACHINE_X64_JCC_STEP(10255u, 0x0da05f55f9ead40a), MACHINE_X64_JMP_STEP},
    [8] = {MACHINE_X64_JCC_STEP(10627u, 0x1b3720aa4829444c), MACHINE_X64_JMP_STEP},
    [9] = {MACHINE_X64_JCC_STEP(10629u, 0x744e31783e151c7b), MACHINE_X64_JMP_STEP},
    [10] = {MACHINE_X64_JCC_STEP(10631u, 0xf3d3864103433402), MACHINE_X64_JMP_STEP},
    [11] = {MACHINE_X64_JCC_STEP(10633u, 0xf6a6442e85dfa8e4), MACHINE_X64_JMP_STEP},
    [12] = {MACHINE_X64_JCC_STEP(10635u, 0xad1a1b6b4487b442), MACHINE_X64_JMP_STEP},
    [13] = {MACHINE_X64_JCC_STEP(10637u, 0xdc02d320fd463c30), MACHINE_X64_JMP_STEP},
    [14] = {MACHINE_X64_JCC_STEP(10639u, 0xbbb60554e5ce4380), MACHINE_X64_JMP_STEP},
    [15] = {MACHINE_X64_JCC_STEP(10641u, 0x6c77826ff61644d0), MACHINE_X64_JMP_STEP},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_jcc_sequence_variants[] = {
    [0] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[0]},
    [1] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[1]},
    [2] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[2]},
    [3] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[3]},
    [4] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[4]},
    [5] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[5]},
    [6] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[6]},
    [7] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[7]},
    [8] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[8]},
    [9] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[9]},
    [10] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[10]},
    [11] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[11]},
    [12] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[12]},
    [13] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[13]},
    [14] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[14]},
    [15] = {.step_count = 2, .steps = machine_x64_jcc_sequence_steps[15]},
};

#undef MACHINE_X64_JMP_STEP
#undef MACHINE_X64_JCC_STEP
#undef MACHINE_X64_SETCC_MOVZX_STEP
#undef MACHINE_X64_SETCC_STEP

#undef MACHINE_X64_FCMP_STEPS
#undef MACHINE_X64_FCMP_MOVZX_STEP
#undef MACHINE_X64_FCMP_PARITY_AND_STEP
#undef MACHINE_X64_FCMP_PARITY_SETNP_STEP
#undef MACHINE_X64_FCMP_SETCC_STEP
#undef MACHINE_X64_FCMP_COMI_STEP
#undef MACHINE_X64_FCMP_MOVQ_TO_STEP
#undef MACHINE_X64_FCMP_MOVQ_TO_XMM1_STEP
#undef MACHINE_X64_FP_MOVQ_FROM_STEP
#undef MACHINE_X64_FP_ARITH_STEP
#undef MACHINE_X64_FP_ARITH_SSE2_STEP
#undef MACHINE_X64_FP_MOVQ_TO_STEP
#undef MACHINE_X64_FP_MOVQ_TO_XMM1_STEP

// AVX-512 masked rows use k1 as the machine scratch mask.  KMOVQ is itself a
// metadata form, so staging the incoming general-register mask never falls
// back to a byte template.  The EVEX forms omit MASK1 from the physical list;
// the machine-only mask/zeroing attributes supply that decorator exactly.
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vload_ptr_masked_sequence_steps[] = {
    {.key = {6896u, UINT64_C(0x105806391b8c13c8)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {64, 64}},
    {.key = {MACHINE_X64_VLOAD_EXACT_FORM_ID, UINT64_C(0x62bba0430900201e)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO}, .operand_widths = {512, 8}, .mask_register_plus_one = 2, .zeroing = true},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vstore_ptr_masked_sequence_steps[] = {
    {.key = {6896u, UINT64_C(0x105806391b8c13c8)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {64, 64}},
    {.key = {MACHINE_X64_VSTORE_EXACT_FORM_ID, UINT64_C(0xa3f8bbb35dcafc20)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {8, 512}, .mask_register_plus_one = 2},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vcompress_store_ptr_sequence_steps[] = {
    {.key = {6896u, UINT64_C(0x105806391b8c13c8)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {64, 64}},
    {.key = {8910u, UINT64_C(0x68e38f515bab1a21)}, .features = machine_x64_avx512vbmi2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512vbmi2_features),
     .operand_count = 2, .operand_slots = {0, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {8, 512}, .mask_register_plus_one = 2},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpcmp_equal_sequence_steps[] = {
    {.key = {5883u, UINT64_C(0xb5f8bb7935287038)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 3, .operand_slots = {0, 1, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {64, 512, 512}},
    {.key = {6897u, UINT64_C(0x12ab4073f19fd9ef)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1}, .operand_widths = {64, 64}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpcmp_less_sequence_steps[] = {
    {.key = {5927u, UINT64_C(0x328655b53fe636a2)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 4, .operand_slots = {0, 1, 2, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_CONSTANT}, .operand_widths = {64, 512, 512, 8}},
    {.key = {6897u, UINT64_C(0x12ab4073f19fd9ef)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1}, .operand_widths = {64, 64}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpcmp_test_sequence_steps[] = {
    {.key = {6647u, UINT64_C(0x1c172153a615826b)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 3, .operand_slots = {0, 1, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {64, 512, 512}},
    {.key = {6897u, UINT64_C(0x12ab4073f19fd9ef)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1}, .operand_widths = {64, 64}},
};
// vpcmpeqd writes 16 mask bits and zeroes the rest of k1, so the shared
// 64-bit KMOVQ step delivers the exact Mask64 the dword compare defines.
// vpcmpud takes its predicate as an immediate, and the vpcmp family already
// spends the machine payload on the variant index, so the predicate cannot
// ride the payload the way vpcmpub's does (there payload 1 happens to be the
// unsigned-less predicate too). MACHINE_X64_EXACT_OPERAND_IMMEDIATE_LESS
// carries it instead.
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpcmp_less_word_sequence_steps[] = {
    {.key = {7550u, UINT64_C(0xbd651626b11cf5bf)}, .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
     .operand_count = 4, .operand_slots = {0, 1, 2, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_LESS}, .operand_widths = {64, 512, 512, 8}},
    {.key = {6897u, UINT64_C(0x12ab4073f19fd9ef)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1}, .operand_widths = {64, 64}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpcmp_equal_word_sequence_steps[] = {
    {.key = {7540u, UINT64_C(0x2c3485903430167f)}, .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
     .operand_count = 3, .operand_slots = {0, 1, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {64, 512, 512}},
    {.key = {6897u, UINT64_C(0x12ab4073f19fd9ef)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1}, .operand_widths = {64, 64}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vload_ptr_masked_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_vload_ptr_masked_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vstore_ptr_masked_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_vstore_ptr_masked_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vcompress_store_ptr_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_vcompress_store_ptr_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vpcmp_sequence_variants[] = {
    {.step_count = 2, .steps = machine_x64_vpcmp_equal_sequence_steps},
    {.step_count = 2, .steps = machine_x64_vpcmp_less_sequence_steps},
    {.step_count = 2, .steps = machine_x64_vpcmp_test_sequence_steps},
    {.step_count = 2, .steps = machine_x64_vpcmp_equal_word_sequence_steps},
    {.step_count = 2, .steps = machine_x64_vpcmp_less_word_sequence_steps},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpmovb2m_sequence_steps[] = {
    {.key = {6183u, UINT64_C(0x845181de5363cb8d)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {64, 512}},
    {.key = {6897u, UINT64_C(0x12ab4073f19fd9ef)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_GPR, MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1}, .operand_widths = {64, 64}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpermt2b_sequence_steps[] = {
    {.key = {6896u, UINT64_C(0x105806391b8c13c8)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {64, 64}},
    {.key = {7901u, UINT64_C(0xf776ce35d04b2826)}, .features = machine_x64_avx512vbmi_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512vbmi_features),
     .operand_count = 3, .operand_slots = {0, 2, 3}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {512, 512, 512}, .mask_register_plus_one = 2, .zeroing = true},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vcompressb_sequence_steps[] = {
    {.key = {6896u, UINT64_C(0x105806391b8c13c8)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {64, 64}},
    {.key = {8911u, UINT64_C(0xe4d1b4ecc7503fab)}, .features = machine_x64_avx512vbmi2_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512vbmi2_features),
     .operand_count = 2, .operand_slots = {0, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {512, 512}, .mask_register_plus_one = 2, .zeroing = true},
};
// The dword compress shares the family: payload 1 selects it, and only the
// vector instruction differs — vpcompressd is plain AVX-512F where the byte
// form needs VBMI2, and it consumes 16 mask bits from the same 64-bit KMOVQ.
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vcompressd_sequence_steps[] = {
    {.key = {6896u, UINT64_C(0x105806391b8c13c8)}, .features = machine_x64_avx512bw_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512bw_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1, MACHINE_X64_EXACT_OPERAND_GPR}, .operand_widths = {64, 64}},
    {.key = {7555u, UINT64_C(0xf39881ff9abad52e)}, .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
     .operand_count = 2, .operand_slots = {0, 2}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT}, .operand_widths = {512, 512}, .mask_register_plus_one = 2, .zeroing = true},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vpmovb2m_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_vpmovb2m_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vpermt2b_sequence_variants[] = {{.step_count = 2, .steps = machine_x64_vpermt2b_sequence_steps}};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vcompressb_sequence_variants[] = {
    {.step_count = 2, .steps = machine_x64_vcompressb_sequence_steps},
    {.step_count = 2, .steps = machine_x64_vcompressd_sequence_steps},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpmovzxbd_q0_steps[] = {
    {.key = {7658u, UINT64_C(0x1646d75ce384e74a)}, .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
     .operand_count = 2, .operand_slots = {0, 1}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_XMM_SLOT}, .operand_widths = {512, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceStep const machine_x64_vpmovzxbd_q_steps[] = {
    {.key = {7163u, UINT64_C(0x6d8890c0fa6f8622)}, .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
     .operand_count = 3, .operand_slots = {0, 1, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_XMM_SLOT, MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_IMMEDIATE_CONSTANT}, .operand_widths = {128, 512, 8}},
    {.key = {7658u, UINT64_C(0x1646d75ce384e74a)}, .features = machine_x64_avx512f_features, .feature_count = BUSTER_ARRAY_LENGTH(machine_x64_avx512f_features),
     .operand_count = 2, .operand_slots = {0, 0}, .operand_kinds = {MACHINE_X64_EXACT_OPERAND_ZMM_SLOT, MACHINE_X64_EXACT_OPERAND_XMM_SLOT}, .operand_widths = {512, 128}},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequenceVariant const machine_x64_vpmovzxbd_sequence_variants[] = {
    {.step_count = 1, .steps = machine_x64_vpmovzxbd_q0_steps},
    {.step_count = 2, .steps = machine_x64_vpmovzxbd_q_steps},
    {.step_count = 2, .steps = machine_x64_vpmovzxbd_q_steps},
    {.step_count = 2, .steps = machine_x64_vpmovzxbd_q_steps},
};
BUSTER_GLOBAL_LOCAL MachineX64ExactSequence const machine_x64_exact_sequence_table[MACHINE_X86_64_EMIT_REGISTRY_FAMILY_COUNT] = {
    [26] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 26, .variant_count = 1, .variants = machine_x64_cvt_f32_f64_sequence_variants},
    [27] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 27, .variant_count = 1, .variants = machine_x64_cvt_f64_f32_sequence_variants},
    [28] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 28, .variant_count = 1, .variants = machine_x64_cvt_i64_f32_sequence_variants},
    [29] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 29, .variant_count = 1, .variants = machine_x64_cvt_i64_f64_sequence_variants},
    [30] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 30, .variant_count = 1, .variants = machine_x64_cvt_f32_i64_sequence_variants},
    [31] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 31, .variant_count = 1, .variants = machine_x64_cvt_f64_i64_sequence_variants},
    [36] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 36, .variant_count = 1, .variants = machine_x64_vload_ptr_masked_sequence_variants},
    [37] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 37, .variant_count = 1, .variants = machine_x64_vstore_ptr_masked_sequence_variants},
    [38] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 38, .variant_count = 1, .variants = machine_x64_vcompress_store_ptr_sequence_variants},
    [39] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 39, .variant_count = 5, .variant_selector = MACHINE_X64_EXACT_VARIANT_FIXED, .variants = machine_x64_vpcmp_sequence_variants},
    [40] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 40, .variant_count = 1, .variants = machine_x64_vpmovb2m_sequence_variants},
    [41] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 41, .variant_count = 1, .variants = machine_x64_vpermt2b_sequence_variants},
    [42] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 42, .variant_count = 2, .variant_selector = MACHINE_X64_EXACT_VARIANT_FIXED, .variants = machine_x64_vcompressb_sequence_variants},
    [43] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 43, .variant_count = 4, .variants = machine_x64_vpmovzxbd_sequence_variants},
    [35] = {
        .recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 35,
        .variant_count = BUSTER_ARRAY_LENGTH(machine_x64_cmpxchg_sequence_variants),
        .variant_selector = MACHINE_X64_EXACT_VARIANT_PAYLOAD_BYTE_WIDTH, .variants = machine_x64_cmpxchg_sequence_variants,
    },
    [44] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 44, .variant_count = 8, .variants = machine_x64_farith_sequence_variants},
    [45] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 45, .variant_count = 12, .variants = machine_x64_fcmp_set_sequence_variants},
    [47] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 47, .variant_count = 16, .variants = machine_x64_setcc_sequence_variants},
    [48] = {.recipe = MACHINE_EMIT_RECIPE_FAMILY_BASE + 48, .variant_count = 16, .variants = machine_x64_jcc_sequence_variants},
};

// DIRECT recipe index -> compact unique exact-plan identity.  Width variants
// and projection variants share a plan; LOAD_INCOMING has its own plan because
// its memory operand is a distinct metadata form.  The table is immutable;
// the plan values themselves are published only by
// machine_x86_64_exact_prewarm() after every selected key has prepared.
BUSTER_GLOBAL_LOCAL u8 const machine_x64_exact_plan_id_by_recipe[MACHINE_X86_64_EMIT_REGISTRY_DIRECT_COUNT] = {
    [0] = MACHINE_X64_EXACT_PLAN_MOV,
    [1] = MACHINE_X64_EXACT_PLAN_MOV,
    [2] = MACHINE_X64_EXACT_PLAN_SX8,
    [3] = MACHINE_X64_EXACT_PLAN_SX16,
    [4] = MACHINE_X64_EXACT_PLAN_SX32,
    [5] = MACHINE_X64_EXACT_PLAN_ZX8,
    [6] = MACHINE_X64_EXACT_PLAN_ZX16,
    [7] = MACHINE_X64_EXACT_PLAN_ADD,
    [8] = MACHINE_X64_EXACT_PLAN_ADD,
    [9] = MACHINE_X64_EXACT_PLAN_SUB,
    [10] = MACHINE_X64_EXACT_PLAN_SUB,
    [11] = MACHINE_X64_EXACT_PLAN_AND,
    [12] = MACHINE_X64_EXACT_PLAN_AND,
    [13] = MACHINE_X64_EXACT_PLAN_OR,
    [14] = MACHINE_X64_EXACT_PLAN_OR,
    [15] = MACHINE_X64_EXACT_PLAN_XOR,
    [16] = MACHINE_X64_EXACT_PLAN_XOR,
    [17] = MACHINE_X64_EXACT_PLAN_IMUL,
    [18] = MACHINE_X64_EXACT_PLAN_IMUL,
    [19] = MACHINE_X64_EXACT_PLAN_NEG,
    [20] = MACHINE_X64_EXACT_PLAN_NEG,
    [21] = MACHINE_X64_EXACT_PLAN_NOT,
    [22] = MACHINE_X64_EXACT_PLAN_NOT,
    [23] = MACHINE_X64_EXACT_PLAN_BSF,
    [24] = MACHINE_X64_EXACT_PLAN_BSF,
    [25] = MACHINE_X64_EXACT_PLAN_BSR,
    [26] = MACHINE_X64_EXACT_PLAN_BSR,
    [27] = MACHINE_X64_EXACT_PLAN_POPCNT,
    [28] = MACHINE_X64_EXACT_PLAN_POPCNT,
    [29] = MACHINE_X64_EXACT_PLAN_CMP,
    [30] = MACHINE_X64_EXACT_PLAN_CMP,
    [31] = MACHINE_X64_EXACT_PLAN_TEST,
    [32] = MACHINE_X64_EXACT_PLAN_JMP,
    [33] = MACHINE_X64_EXACT_PLAN_SHL,
    [34] = MACHINE_X64_EXACT_PLAN_SHL,
    [35] = MACHINE_X64_EXACT_PLAN_SAR,
    [36] = MACHINE_X64_EXACT_PLAN_SAR,
    [37] = MACHINE_X64_EXACT_PLAN_SHR,
    [38] = MACHINE_X64_EXACT_PLAN_SHR,
    [39] = MACHINE_X64_EXACT_PLAN_LEA_SYMBOL,
    [40] = MACHINE_X64_EXACT_PLAN_MOVQ_TO_XMM,
    [41] = MACHINE_X64_EXACT_PLAN_MOVQ_FROM_XMM,
    [42] = MACHINE_X64_EXACT_PLAN_LOAD_INCOMING,
    [43] = MACHINE_X64_EXACT_PLAN_PUSH,
    [44] = MACHINE_X64_EXACT_PLAN_ADD_RSP,
    [45] = MACHINE_X64_EXACT_PLAN_MFENCE,
    [46] = MACHINE_X64_EXACT_PLAN_INT3,
};

BUSTER_GLOBAL_LOCAL u8 const machine_x64_family_exact_plan_id_by_recipe[MACHINE_X86_64_EMIT_REGISTRY_FAMILY_COUNT] = {
    [0] = MACHINE_X64_EXACT_PLAN_MOV_IMMEDIATE,
    [1] = MACHINE_X64_EXACT_PLAN_LEA_SYMBOL,
    [2] = MACHINE_X64_EXACT_PLAN_ADD_IMMEDIATE8,
    [3] = MACHINE_X64_EXACT_PLAN_IMUL_IMMEDIATE8,
    [4] = MACHINE_X64_EXACT_PLAN_LOAD_INCOMING,
    [5] = MACHINE_X64_EXACT_PLAN_STORE8,
    [6] = MACHINE_X64_EXACT_PLAN_STORE_FULL,
    [7] = MACHINE_X64_EXACT_PLAN_STORE_FULL,
    [8] = MACHINE_X64_EXACT_PLAN_STORE_FULL,
    [9] = MACHINE_X64_EXACT_PLAN_MOVZX8,
    [10] = MACHINE_X64_EXACT_PLAN_MOVZX16,
    [11] = MACHINE_X64_EXACT_PLAN_LOAD_INCOMING,
    [12] = MACHINE_X64_EXACT_PLAN_LOAD_INCOMING,
    [13] = MACHINE_X64_EXACT_PLAN_STORE8,
    [14] = MACHINE_X64_EXACT_PLAN_STORE_FULL,
    [15] = MACHINE_X64_EXACT_PLAN_STORE_FULL,
    [16] = MACHINE_X64_EXACT_PLAN_STORE_FULL,
    [17] = MACHINE_X64_EXACT_PLAN_LEA_SYMBOL,
    [18] = MACHINE_X64_EXACT_PLAN_PUSH_FRAME,
    [19] = MACHINE_X64_EXACT_PLAN_VMOV,
    [20] = MACHINE_X64_EXACT_PLAN_VLOAD,
    [21] = MACHINE_X64_EXACT_PLAN_VSTORE,
    [22] = MACHINE_X64_EXACT_PLAN_VLOAD,
    [23] = MACHINE_X64_EXACT_PLAN_VSTORE,
    [24] = MACHINE_X64_EXACT_PLAN_VPSLLD,
    [25] = MACHINE_X64_EXACT_PLAN_VPADDB,
    [32] = MACHINE_X64_EXACT_PLAN_VSPLATB,
    [33] = MACHINE_X64_EXACT_PLAN_VPTERNLOGD,
    [34] = MACHINE_X64_EXACT_PLAN_XCHG,
    [35] = MACHINE_X64_EXACT_PLAN_CMPXCHG,
    [46] = MACHINE_X64_EXACT_PLAN_SUB_RSP,
    [49] = MACHINE_X64_EXACT_PLAN_VSPLATD,
};

BUSTER_GLOBAL_LOCAL u8 machine_x64_exact_plan_id_for_recipe_variant(MachineEmitRecipeCategory category, u16 recipe_index, u32 variant_index)
{
    if (category == MACHINE_EMIT_RECIPE_CATEGORY_DIRECT)
    {
        return recipe_index < BUSTER_ARRAY_LENGTH(machine_x64_exact_plan_id_by_recipe) ? machine_x64_exact_plan_id_by_recipe[recipe_index]
                                                                                       : MACHINE_X64_EXACT_PLAN_INVALID;
    }
    if (category == MACHINE_EMIT_RECIPE_CATEGORY_FAMILY)
    {
        if (recipe_index < BUSTER_ARRAY_LENGTH(machine_x64_family_exact_plan_id_by_recipe))
        {
            if (recipe_index == 0 && variant_index == 1) return MACHINE_X64_EXACT_PLAN_MOV_SIGNED_IMMEDIATE;
            if (recipe_index == 2 && variant_index == 1) return MACHINE_X64_EXACT_PLAN_ADD_RSP;
            if (recipe_index == 3 && variant_index == 1) return MACHINE_X64_EXACT_PLAN_IMUL_IMMEDIATE32;
            if (recipe_index == 25 && variant_index <= 10) return (u8)(MACHINE_X64_EXACT_PLAN_VPADDB + variant_index);
            if (recipe_index == 34 && variant_index == 1) return MACHINE_X64_EXACT_PLAN_XCHG8;
            return machine_x64_family_exact_plan_id_by_recipe[recipe_index];
        }
    }
    return MACHINE_X64_EXACT_PLAN_INVALID;
}

// The encoder's hot row loop sees x86 opcodes as one contiguous ordinal span
// (MACHINE_X64_MOV_RI .. MACHINE_X64_VBINARY).  Keep the exact projection in
// that same dense namespace so workers do not re-enter the registry, decode a
// recipe category/index, or re-check a durable form key for every row.  The
// descriptor/status portion is a static projection of the source registry;
// the token and validity fields are filled and published by serial prewarm.
typedef struct MachineX64PreparedExactOpcode MachineX64PreparedExactOpcode;

// Register-indexed exact forms have a closed 16x16 physical population.
// Serial prewarm asks the metadata authority for every member once and
// publishes the result as a dense 16-byte record: fifteen architectural bytes
// plus its count.  Zero-displacement base-register memory joins the same closed
// population.  Forms with one trailing immediate or forced RBP displacement
// are encoded twice per member so publication also proves that only that patch
// field changes.  The worker then consumes the dense table and writes the
// dynamic field without reinterpreting the metadata form.  Tables whose
// complete population fits three bytes also place the count in byte three.
// Their first dword is a fixed scalar store and the compact encoding unit
// consumed by future homogeneous SIMD batches; longer tables keep the same
// uniform stride.
#define MACHINE_X64_GPR_ENCODING_TABLE_CAPACITY 64u
BUSTER_CT_CHECK(MACHINE_X64_GPR_ENCODING_TABLE_CAPACITY <= UINT8_MAX);
typedef struct MachineX64GprEncoding MachineX64GprEncoding;
typedef struct MachineX64GprEncodingTable MachineX64GprEncodingTable;
typedef struct MachineX64VariableMemoryEncodingTable MachineX64VariableMemoryEncodingTable;
struct MachineX64GprEncoding
{
    u8 bytes[15];
    u8 byte_count;
};
BUSTER_CT_CHECK(sizeof(MachineX64GprEncoding) == 16);

// Copy one published encoding into the code buffer. Every record is exactly
// one sixteen-byte line and every emitted row was budgeted at least
// MACHINE_OPCODE_ROW_FLAT_BUDGET bytes, so the ordinary case is a whole-line
// load and store the compiler emits inline -- 15 Ir a call went to libc for a
// length it could not see, over 2,0 M calls a compile. The exact copy stays
// for the last row of a buffer, the only place where sixteen bytes of slack
// is not already reserved.
BUSTER_GLOBAL_LOCAL BUSTER_INLINE void machine_x64_encoder_copy_encoding(MachineX64Encoder* encoder, MachineX64GprEncoding const* encoding, u32 byte_count)
{
    if (BUSTER_LIKELY(encoder->capacity - encoder->count >= sizeof(*encoding)))
    {
        memcpy(encoder->bytes + encoder->count, encoding, sizeof(*encoding));
    }
    else
    {
        memcpy(encoder->bytes + encoder->count, encoding->bytes, byte_count);
    }
}

// Write one little-endian field of 1, 2, 4 or 8 bytes into the code buffer.
// Every width the encoding tables publish is one store; the loop stays for a
// width none of them uses. It was a byte loop over a field whose width the
// caller cannot fold, on every patched immediate and displacement of the
// compile.
BUSTER_GLOBAL_LOCAL BUSTER_INLINE void machine_x64_encoder_store_field(u8* destination, u64 value, u32 width)
{
    switch (width)
    {
    case 1:
        destination[0] = (u8)value;
        break;
    case 2:
    {
        u16 narrow = (u16)value;
        memcpy(destination, &narrow, sizeof(narrow));
        break;
    }
    case 4:
    {
        u32 narrow = (u32)value;
        memcpy(destination, &narrow, sizeof(narrow));
        break;
    }
    case 8:
        memcpy(destination, &value, sizeof(value));
        break;
    default:
        for (u32 byte_index = 0; byte_index < width; byte_index += 1)
        {
            destination[byte_index] = (u8)(value >> (byte_index * 8u));
        }
        break;
    }
}

struct MachineX64GprEncodingTable
{
    MachineX64GprEncoding encodings[256];
    u8 operand_slots[2];
    u8 operand_count;
    u8 flags;
    u8 immediate_width;
    u8 memory_operand_slot;
};
#define MACHINE_X64_GPR_ENCODING_TABLE_COMPACT 0x1u
#define MACHINE_X64_GPR_ENCODING_TABLE_SELF_COPY_NOOP 0x2u
#define MACHINE_X64_GPR_ENCODING_TABLE_PATCH_IMMEDIATE 0x4u
#define MACHINE_X64_GPR_ENCODING_TABLE_MEMORY_BASE 0x8u
#define MACHINE_X64_GPR_ENCODING_TABLE_PATCH_DISPLACEMENT 0x10u
#define MACHINE_X64_GPR_ENCODING_TABLE_INCOMING_DISPLACEMENT 0x20u
#define MACHINE_X64_GPR_ENCODING_TABLE_IMMEDIATE_FROM_PAYLOAD 0x40u
BUSTER_CT_CHECK(sizeof(MachineX64GprEncoding) == 16);
BUSTER_GLOBAL_LOCAL MachineX64GprEncodingTable
    machine_x64_gpr_encoding_tables[MACHINE_X64_GPR_ENCODING_TABLE_CAPACITY];
BUSTER_GLOBAL_LOCAL u32 machine_x64_gpr_encoding_table_count;

// Variable base-register memory forms are another closed population.  Keep
// their zero, disp8, and disp32 encodings in separate homogeneous lanes so the
// worker classifies the displacement once and consumes a fixed-stride record.
#define MACHINE_X64_VARIABLE_MEMORY_TABLE_CAPACITY 16u
#define MACHINE_X64_MEMORY_DISPLACEMENT_CLASS_COUNT 3u
BUSTER_CT_CHECK(MACHINE_X64_VARIABLE_MEMORY_TABLE_CAPACITY <= UINT8_MAX);
struct MachineX64VariableMemoryEncodingTable
{
    MachineX64GprEncoding encodings[MACHINE_X64_MEMORY_DISPLACEMENT_CLASS_COUNT][256];
    u8 gpr_operand_slot;
    u8 memory_operand_slot;
};
BUSTER_GLOBAL_LOCAL MachineX64VariableMemoryEncodingTable
    machine_x64_variable_memory_encoding_tables[MACHINE_X64_VARIABLE_MEMORY_TABLE_CAPACITY];
BUSTER_GLOBAL_LOCAL u32 machine_x64_variable_memory_encoding_table_count;

// Fixed-shape rows.  Every prologue, epilogue, call, divide, and switch
// chain, and every JCC/SETCC sequence step, spells the same instruction for
// the same inputs: PUSH/POP of one of sixteen registers, MOV between RBP and
// RSP, the page-probe SUB/TEST pair, RET, a Jcc/JMP/CALL rel32 whose zero
// displacement the fixup stream patches later, SETcc AL, and so on.  Serial
// prewarm asks the metadata authority for each member once -- through the
// mnemonic bridge for expansion rows, through the row's own exact token for
// recipe variants and sequence steps -- and publishes the answer as a dense
// 16-byte record; the worker copies the record and stores at most one
// dynamic field, the way the GPR encoding tables serve their rows.  A shape
// prewarm could not publish keeps the lane it had, which fails closed
// exactly as before.  Rows below MACHINE_X64_FIXED_TEMPLATE_STATIC_COUNT are
// the bridge shapes the encoder names directly; register-indexed families
// among them are sixteen contiguous rows so a site adds the register to the
// family's first row, and width pairs are two rows, 32-bit then 64-bit.  The
// rows after them are allotted at prewarm to recipe variants and sequence
// steps.
enum
{
    MACHINE_X64_FIXED_TEMPLATE_PUSH = 0,
    MACHINE_X64_FIXED_TEMPLATE_POP = MACHINE_X64_FIXED_TEMPLATE_PUSH + 16,
    MACHINE_X64_FIXED_TEMPLATE_CALL_REGISTER = MACHINE_X64_FIXED_TEMPLATE_POP + 16,
    MACHINE_X64_FIXED_TEMPLATE_JMP_REGISTER = MACHINE_X64_FIXED_TEMPLATE_CALL_REGISTER + 16,
    // lea r64, [rip + 0]: the block-address load whose displacement the
    // fixup stream owns.
    MACHINE_X64_FIXED_TEMPLATE_LEA_RIP = MACHINE_X64_FIXED_TEMPLATE_JMP_REGISTER + 16,
    // mov r32, imm32 with the immediate patched: the switch chain's case
    // value, proven for the 0..INT32_MAX classes; a site keeps the bridge
    // for any other value.
    MACHINE_X64_FIXED_TEMPLATE_MOV_R32_IMM32 = MACHINE_X64_FIXED_TEMPLATE_LEA_RIP + 16,
    // cmp ecx/rcx, r: the switch chain compares its case value, carried in
    // RCX, against the condition register -- or in RAX against RCX when the
    // allocator put the condition there.
    MACHINE_X64_FIXED_TEMPLATE_CMP32_RCX = MACHINE_X64_FIXED_TEMPLATE_MOV_R32_IMM32 + 16,
    MACHINE_X64_FIXED_TEMPLATE_CMP64_RCX = MACHINE_X64_FIXED_TEMPLATE_CMP32_RCX + 16,
    MACHINE_X64_FIXED_TEMPLATE_CMP32_RAX_RCX = MACHINE_X64_FIXED_TEMPLATE_CMP64_RCX + 16,
    MACHINE_X64_FIXED_TEMPLATE_CMP64_RAX_RCX,
    MACHINE_X64_FIXED_TEMPLATE_MOV_RBP_RSP,
    MACHINE_X64_FIXED_TEMPLATE_MOV_RSP_RBP,
    // sub rsp, imm8 / imm32 with the immediate patched.  The prologue passes
    // 1..127 to the byte form and 128..4096 to the wide one, which are the
    // value classes the two rows were proven with.
    MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM8,
    MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM32,
    // test byte [rsp], 0: the page probe.
    MACHINE_X64_FIXED_TEMPLATE_PROBE,
    // lea rsp, [rbp + disp8] with the displacement patched; the epilogue's
    // displacement is minus eight per pushed register, at most sixteen.
    MACHINE_X64_FIXED_TEMPLATE_LEA_RSP_RBP_DISP8,
    // mov eax, imm32 with the immediate patched: the variadic call's XMM
    // count, proven for the 0..127 class the row carries.
    MACHINE_X64_FIXED_TEMPLATE_MOV_EAX_IMM32,
    MACHINE_X64_FIXED_TEMPLATE_RET,
    MACHINE_X64_FIXED_TEMPLATE_CALL_REL32,
    MACHINE_X64_FIXED_TEMPLATE_JMP_REL32,
    MACHINE_X64_FIXED_TEMPLATE_JZ_REL32,
    MACHINE_X64_FIXED_TEMPLATE_VZEROUPPER,
    MACHINE_X64_FIXED_TEMPLATE_UD2,
    // The divide rows: xor edx/rdx, div/idiv ecx/rcx, cdq/cqo, and the
    // remainder's mov eax/rax, edx/rdx.
    MACHINE_X64_FIXED_TEMPLATE_XOR_RDX_RDX,
    MACHINE_X64_FIXED_TEMPLATE_DIV_RCX = MACHINE_X64_FIXED_TEMPLATE_XOR_RDX_RDX + 2,
    MACHINE_X64_FIXED_TEMPLATE_IDIV_RCX = MACHINE_X64_FIXED_TEMPLATE_DIV_RCX + 2,
    MACHINE_X64_FIXED_TEMPLATE_CDQ_CQO = MACHINE_X64_FIXED_TEMPLATE_IDIV_RCX + 2,
    MACHINE_X64_FIXED_TEMPLATE_MOV_RAX_RDX = MACHINE_X64_FIXED_TEMPLATE_CDQ_CQO + 2,
    MACHINE_X64_FIXED_TEMPLATE_STATIC_COUNT = MACHINE_X64_FIXED_TEMPLATE_MOV_RAX_RDX + 2,
};
// Recipe variants and sequence steps whose operands are all fixed -- a zero
// relative, a rip-relative zero, RAX/RDX/RSP, XMM0/XMM1, k0/k1 -- plus at
// most one general register, which spans sixteen rows.  The scalar float
// sequences account for most of these rows.
#define MACHINE_X64_FIXED_TEMPLATE_DYNAMIC_CAPACITY 1536u
#define MACHINE_X64_FIXED_TEMPLATE_CAPACITY (MACHINE_X64_FIXED_TEMPLATE_STATIC_COUNT + MACHINE_X64_FIXED_TEMPLATE_DYNAMIC_CAPACITY)
// A family's rows are indexed by a GPR operand slot; a single template has
// no slot.
#define MACHINE_X64_FIXED_TEMPLATE_NO_SLOT UINT8_MAX
// A row index that names no template, so a site can index a family with a
// register it could not validate and still keep its bridge.
#define MACHINE_X64_FIXED_TEMPLATE_NONE UINT32_MAX
BUSTER_CT_CHECK(MACHINE_X64_FIXED_TEMPLATE_CAPACITY < UINT16_MAX);

// The longest published member is seven bytes (a REX.W LEA or SUB with a
// 32-bit field); twelve keeps the record at one 16-byte stride, and a longer
// encoding simply stays unpublished.
typedef struct MachineX64FixedTemplate MachineX64FixedTemplate;
struct MachineX64FixedTemplate
{
    u8 bytes[12];
    u8 byte_count;
    u8 patch_offset;
    u8 patch_width;
    u8 valid;
};
BUSTER_CT_CHECK(sizeof(MachineX64FixedTemplate) == 16);
BUSTER_GLOBAL_LOCAL MachineX64FixedTemplate machine_x64_fixed_templates[MACHINE_X64_FIXED_TEMPLATE_CAPACITY];
// Rows allotted so far, the static rows included, and how many of them the
// authority refused.
BUSTER_GLOBAL_LOCAL u32 machine_x64_fixed_template_count;
BUSTER_GLOBAL_LOCAL u32 machine_x64_fixed_template_invalid_count;

typedef enum MachineX64FixedTemplateResult
{
    // Prewarm did not publish the row; the caller keeps its metadata lane.
    MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED,
    MACHINE_X64_FIXED_TEMPLATE_EMITTED,
    // The encoder had no room: it is flagged overflowed and nothing was
    // written, which is the metadata lanes' contract too.
    MACHINE_X64_FIXED_TEMPLATE_EXHAUSTED,
} MachineX64FixedTemplateResult;

// Copies template `template_id` and stores its dynamic field little-endian.
BUSTER_GLOBAL_LOCAL MachineX64FixedTemplateResult machine_x64_emit_fixed_template(MachineX64Encoder* encoder, u32 template_id, u64 patch_value)
{
    MachineX64FixedTemplateResult result;
    if (template_id >= MACHINE_X64_FIXED_TEMPLATE_CAPACITY || !machine_x64_fixed_templates[template_id].valid)
    {
        result = MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED;
    }
    else
    {
        MachineX64FixedTemplate const* record = machine_x64_fixed_templates + template_id;
        u32 byte_count = record->byte_count;
        if (encoder->count > encoder->capacity || byte_count > encoder->capacity - encoder->count)
        {
            encoder->overflow = true;
            result = MACHINE_X64_FIXED_TEMPLATE_EXHAUSTED;
        }
        else
        {
            u8* output = encoder->bytes + encoder->count;
            // The whole record when it fits: one fixed-size store instead
            // of a variable-length copy.
            if (encoder->capacity - encoder->count >= sizeof(record->bytes))
            {
                memcpy(output, record->bytes, sizeof(record->bytes));
            }
            else
            {
                memcpy(output, record->bytes, byte_count);
            }
            for (u32 byte_index = 0; byte_index < record->patch_width; byte_index += 1)
            {
                output[record->patch_offset + byte_index] = (u8)(patch_value >> (byte_index * 8u));
            }
            encoder->count += byte_count;
            result = MACHINE_X64_FIXED_TEMPLATE_EMITTED;
        }
    }
    return result;
}

// The row of a register-indexed family for `reg`, or none when the register
// is not one of the sixteen the family was published for.
BUSTER_GLOBAL_LOCAL u32 machine_x64_fixed_template_family_row(u32 family, u32 reg)
{
    return reg < 16 ? family + reg : MACHINE_X64_FIXED_TEMPLATE_NONE;
}

// Publishes one encoding -- the bytes a scratch encoder received from the
// bridge or from a token -- as template `template_id`.  A patched template
// is published holding its representative value in the trailing
// `patch_width` bytes; machine_x64_fixed_template_prove then has to accept
// a second encoding of the shape before a worker may rely on the store.
BUSTER_GLOBAL_LOCAL void machine_x64_fixed_template_publish(u32 template_id, MachineX64Encoder const* encoder, u8 patch_width)
{
    MachineX64FixedTemplate* record = machine_x64_fixed_templates + template_id;
    *record = (MachineX64FixedTemplate){0};
    if (!encoder->overflow && encoder->count != 0 && encoder->count <= sizeof(record->bytes) && encoder->count >= patch_width)
    {
        memcpy(record->bytes, encoder->bytes, encoder->count);
        record->byte_count = (u8)encoder->count;
        record->patch_offset = (u8)(encoder->count - patch_width);
        record->patch_width = patch_width;
        record->valid = 1;
    }
    else
    {
        machine_x64_fixed_template_invalid_count += 1;
    }
}

// Proves that `probe_encoder` -- the same shape encoded with `probe_value`
// in its dynamic field -- matches the published template outside the patch
// field and spells `probe_value` little-endian inside it.  Any difference
// retires the template: the worker's store would not reproduce what the
// authority encodes for that value class.
BUSTER_GLOBAL_LOCAL void machine_x64_fixed_template_prove(u32 template_id, MachineX64Encoder const* probe_encoder, u64 probe_value)
{
    MachineX64FixedTemplate* record = machine_x64_fixed_templates + template_id;
    bool valid = record->valid && record->patch_width && !probe_encoder->overflow &&
                 probe_encoder->count == record->byte_count;
    for (u32 byte_index = 0; valid && byte_index < record->byte_count; byte_index += 1)
    {
        u8 expected = (u8)(byte_index >= record->patch_offset ? probe_value >> ((byte_index - record->patch_offset) * 8u) : record->bytes[byte_index]);
        valid = probe_encoder->bytes[byte_index] == expected;
    }
    if (record->valid && !valid) machine_x64_fixed_template_invalid_count += 1;
    record->valid = valid ? 1 : 0;
}

struct MachineX64PreparedExactOpcode
{
    MachineX64ExactRecipe const* descriptor;
    MachineX64ExactSequence const* sequence;
    // Tokens are resolved beside each descriptor variant's feature policy
    // during serial prewarm and remain opaque to the machine layer.
    BusterX86MetadataMachineExactToken metadata_tokens[16];
    // One-based index into machine_x64_gpr_encoding_tables per form variant;
    // zero keeps the ordinary exact metadata transform.
    u8 gpr_encoding_tables[16];
    // One-based index into the displacement-class tables above.
    u8 variable_memory_encoding_tables[16];
    BusterX86MetadataMachineExactToken sequence_tokens[MACHINE_X64_EXACT_SEQUENCE_MAX_VARIANTS * MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS];
    // One-based first row in machine_x64_fixed_templates per form variant
    // without a dense table, and per sequence step, with the operand slot
    // whose register spans the family (MACHINE_X64_FIXED_TEMPLATE_NO_SLOT
    // for a single row); zero keeps the token lane.
    u16 fixed_templates[16];
    u8 fixed_template_slots[16];
    u16 sequence_templates[MACHINE_X64_EXACT_SEQUENCE_MAX_VARIANTS * MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS];
    u8 sequence_template_slots[MACHINE_X64_EXACT_SEQUENCE_MAX_VARIANTS * MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS];
    u8 exact_required;
    u8 sequence_required;
    u8 variant_count;
    // Direct single-variant GPR rows bypass the generic variant selector and
    // validity projection; zero retains the ordinary exact lane.
    u8 single_gpr_encoding_table;
    u16 variant_valid_mask;
    u8 plan_valid;
};

#define MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_FORM(category, index) MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_FORM_##category(index)
#define MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_FORM_DIRECT(index) (&machine_x64_exact_recipe_table[(index)])
#define MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_FORM_FAMILY(index) (&machine_x64_family_exact_recipe_table[(index)])
#define MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_SEQUENCE(category, index) 0
#define MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_LEGACY_RAW(category, index) 0
#define MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXPANSION_POLICY(category, index) 0
#define MACHINE_X64_EXACT_OPCODE_REQUIRED_EXACT_FORM 1u
#define MACHINE_X64_EXACT_OPCODE_REQUIRED_EXACT_SEQUENCE 1u
#define MACHINE_X64_EXACT_OPCODE_REQUIRED_LEGACY_RAW 0u
#define MACHINE_X64_EXACT_OPCODE_REQUIRED_EXPANSION_POLICY 0u
#define MACHINE_X64_EXACT_OPCODE_SEQUENCE_EXACT_FORM 0u
#define MACHINE_X64_EXACT_OPCODE_SEQUENCE_EXACT_SEQUENCE 1u
#define MACHINE_X64_EXACT_OPCODE_SEQUENCE_LEGACY_RAW 0u
#define MACHINE_X64_EXACT_OPCODE_SEQUENCE_EXPANSION_POLICY 0u
#define MACHINE_X64_EXACT_OPCODE_MAP_ROW(opcode_value, category_value, index_value, status_value) \
    [opcode_value - MACHINE_X64_MOV_RI] = { \
        .descriptor = MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_##status_value(category_value, index_value), \
        .sequence_required = MACHINE_X64_EXACT_OPCODE_SEQUENCE_##status_value, \
        .exact_required = MACHINE_X64_EXACT_OPCODE_REQUIRED_##status_value, \
    },
BUSTER_GLOBAL_LOCAL MachineX64PreparedExactOpcode machine_x64_exact_opcode_map[MACHINE_X86_64_EMIT_REGISTRY_COUNT] = {
    MACHINE_X86_64_EMIT_REGISTRY(MACHINE_X64_EXACT_OPCODE_MAP_ROW)
};
#undef MACHINE_X64_EXACT_OPCODE_MAP_ROW
#undef MACHINE_X64_EXACT_OPCODE_REQUIRED_EXPANSION_POLICY
#undef MACHINE_X64_EXACT_OPCODE_REQUIRED_LEGACY_RAW
#undef MACHINE_X64_EXACT_OPCODE_REQUIRED_EXACT_FORM
#undef MACHINE_X64_EXACT_OPCODE_REQUIRED_EXACT_SEQUENCE
#undef MACHINE_X64_EXACT_OPCODE_SEQUENCE_EXPANSION_POLICY
#undef MACHINE_X64_EXACT_OPCODE_SEQUENCE_LEGACY_RAW
#undef MACHINE_X64_EXACT_OPCODE_SEQUENCE_EXACT_SEQUENCE
#undef MACHINE_X64_EXACT_OPCODE_SEQUENCE_EXACT_FORM
#undef MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXPANSION_POLICY
#undef MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_LEGACY_RAW
#undef MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_FORM_FAMILY
#undef MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_FORM_DIRECT
#undef MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_FORM
#undef MACHINE_X64_EXACT_OPCODE_DESCRIPTOR_EXACT_SEQUENCE

BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(machine_x64_exact_opcode_map) == MACHINE_X86_64_EMIT_REGISTRY_COUNT);
BUSTER_GLOBAL_LOCAL bool machine_x64_exact_opcode_map_ready;

// Keep the prewarm stages in separate functions.  The self-hosted C compiler
// accounts MIR capacity per function, and putting key collection, metadata
// preparation, and row publication in one body makes this otherwise bounded
// serial operation exceed that limit.  The key/plan helpers write caller-owned
// scratch storage, while the row helper stages the global map before the
// ready bit is published by the entry point.
BUSTER_GLOBAL_LOCAL void machine_x64_exact_collect_plan_keys(BusterX86MetadataFormKey* keys, bool* key_found)
{
    for (u32 recipe_index = 0; recipe_index < BUSTER_ARRAY_LENGTH(machine_x64_exact_recipe_table); recipe_index += 1)
    {
        MachineX64ExactRecipe const* recipe = machine_x64_exact_recipe_table + recipe_index;
        u32 variant_total = recipe->variant_count + 1u;
        for (u32 variant_index = 0; variant_index < variant_total; variant_index += 1)
        {
            MachineX64ExactRecipeVariant variant = machine_x64_exact_recipe_variant(recipe, variant_index);
            u8 plan_id = machine_x64_exact_plan_id_for_recipe_variant(MACHINE_EMIT_RECIPE_CATEGORY_DIRECT, (u16)recipe_index, variant_index);
            if (plan_id >= MACHINE_X64_EXACT_PLAN_COUNT || key_found[plan_id]) continue;
            keys[plan_id] = variant.key;
            key_found[plan_id] = true;
        }
    }
    for (u32 recipe_index = 0; recipe_index < BUSTER_ARRAY_LENGTH(machine_x64_family_exact_recipe_table); recipe_index += 1)
    {
        MachineX64ExactRecipe const* recipe = machine_x64_family_exact_recipe_table + recipe_index;
        if (!recipe->recipe || !recipe->key.stable_hash) continue;
        u32 variant_total = recipe->variant_count + 1u;
        for (u32 variant_index = 0; variant_index < variant_total; variant_index += 1)
        {
            MachineX64ExactRecipeVariant variant = machine_x64_exact_recipe_variant(recipe, variant_index);
            u8 plan_id = machine_x64_exact_plan_id_for_recipe_variant(MACHINE_EMIT_RECIPE_CATEGORY_FAMILY, (u16)recipe_index, variant_index);
            if (plan_id >= MACHINE_X64_EXACT_PLAN_COUNT || key_found[plan_id]) continue;
            keys[plan_id] = variant.key;
            key_found[plan_id] = true;
        }
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_plans(BusterX86MetadataFormKey const* keys, bool const* key_found,
                                                          BusterX86MetadataExactPlan* prepared, bool* plan_valid)
{
    for (u32 plan_id = 0; plan_id < MACHINE_X64_EXACT_PLAN_COUNT; plan_id += 1)
    {
        plan_valid[plan_id] = key_found[plan_id] &&
                              buster_x86_metadata_exact_plan_prepare(keys[plan_id], &prepared[plan_id]) &&
                              prepared[plan_id].form_id == keys[plan_id].form_id &&
                              prepared[plan_id].stable_hash == keys[plan_id].stable_hash;
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_fcmp_alternate_tokens(void)
{
    // FCMP_SET's OR-parity repair uses two alternate BASE forms.  Prepare
    // their opaque metadata tokens on the serial prewarm lane; workers only
    // select among these already validated tokens and never call metadata.
    machine_x64_fcmp_alternate_tokens_valid = false;
    BusterX86MetadataExactPlan setp_plan = {0};
    BusterX86MetadataExactPlan or_plan = {0};
    bool setp_prepared = buster_x86_metadata_exact_plan_prepare((BusterX86MetadataFormKey){10647u, UINT64_C(0x65dc8e342334f3cb)}, &setp_plan);
    bool or_prepared = buster_x86_metadata_exact_plan_prepare((BusterX86MetadataFormKey){9631u, UINT64_C(0x89a3abb502bbc55a)}, &or_plan);
    machine_x64_fcmp_alternate_tokens_valid = setp_prepared && or_prepared &&
                                               buster_x86_metadata_machine_exact_token_for_plan(setp_plan, (BusterX86MetadataFeatureInput){0}, &machine_x64_fcmp_setp_token) &&
                                               buster_x86_metadata_machine_exact_token_for_plan(or_plan, (BusterX86MetadataFeatureInput){0}, &machine_x64_fcmp_or_token);
}

BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_sequence_entry(MachineX64PreparedExactOpcode* entry,
                                                                    MachineX64EmitRegistryEntry const* registry_entry)
{
    MachineEmitRecipeId sequence_recipe = registry_entry ? registry_entry->recipe : 0;
    u16 sequence_index = machine_emit_recipe_index(sequence_recipe);
    MachineX64ExactSequence const* sequence = sequence_index < BUSTER_ARRAY_LENGTH(machine_x64_exact_sequence_table)
                                                   ? machine_x64_exact_sequence_table[sequence_index].variants ? machine_x64_exact_sequence_table + sequence_index : 0
                                                   : 0;
    entry->sequence = sequence;
    bool sequence_valid = registry_entry && registry_entry->producer_status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_SEQUENCE &&
                          sequence && sequence->recipe == sequence_recipe && sequence->variant_count > 0 &&
                          sequence->variant_count <= MACHINE_X64_EXACT_SEQUENCE_MAX_VARIANTS;
    entry->variant_count = (u8)(sequence_valid ? sequence->variant_count : 0);
    entry->variant_valid_mask = 0;
    for (u32 variant_index = 0; sequence_valid && variant_index < sequence->variant_count; variant_index += 1)
    {
        MachineX64ExactSequenceVariant const* variant = sequence->variants + variant_index;
        if (!variant->steps || variant->step_count == 0 || variant->step_count > MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS)
        {
            sequence_valid = false;
            break;
        }
        for (u32 step_index = 0; step_index < variant->step_count; step_index += 1)
        {
        MachineX64ExactSequenceStep const* step = variant->steps + step_index;
            BusterX86MetadataExactPlan step_plan = {0};
            BusterX86MetadataMachineExactToken* token = entry->sequence_tokens +
                variant_index * MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS + step_index;
            bool prepared_step = buster_x86_metadata_exact_plan_prepare(step->key, &step_plan);
            bool identity_step = prepared_step && step_plan.form_id == step->key.form_id && step_plan.stable_hash == step->key.stable_hash;
            bool token_step = identity_step && buster_x86_metadata_machine_exact_token_for_plan(
                                                        step_plan,
                                                        (BusterX86MetadataFeatureInput){.names = step->features, .count = step->feature_count}, token);
            if (!token_step)
            {
                sequence_valid = false;
                break;
            }
        }
        if (sequence_valid) entry->variant_valid_mask |= (u16)(1u << variant_index);
    }
    entry->plan_valid = sequence_valid && entry->variant_valid_mask == (u16)((1u << entry->variant_count) - 1u);
    if (!entry->plan_valid)
    {
        entry->sequence = 0;
        entry->variant_count = 0;
        entry->variant_valid_mask = 0;
        for (u32 token_index = 0; token_index < BUSTER_ARRAY_LENGTH(entry->sequence_tokens); token_index += 1)
        {
            entry->sequence_tokens[token_index] = (BusterX86MetadataMachineExactToken){0};
        }
    }
}

BUSTER_GLOBAL_LOCAL bool machine_x64_exact_gpr_variant_slots(MachineX64ExactRecipeVariant const* variant,
                                                              u8 operand_slots[2], u8* operand_count,
                                                              u8* immediate_operand_index, u8* displacement_operand_index,
                                                              bool* has_memory_base)
{
    if (!variant || variant->operand_count == 0 ||
        (variant->flags & ~(MACHINE_X64_EXACT_RECIPE_FLAG_SELF_COPY_NOOP |
                            MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32)))
        return false;
    u8 count = 0;
    *immediate_operand_index = UINT8_MAX;
    *displacement_operand_index = UINT8_MAX;
    *has_memory_base = false;
    for (u32 operand_index = 0; operand_index < variant->operand_count; operand_index += 1)
    {
        MachineX64ExactOperandProjection kind = (MachineX64ExactOperandProjection)variant->operand_kinds[operand_index];
        if (kind == MACHINE_X64_EXACT_OPERAND_GPR)
        {
            if (count >= 2 || variant->operand_slots[operand_index] >= 4) return false;
            operand_slots[count++] = variant->operand_slots[operand_index];
        }
        else if (kind == MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO)
        {
            if (count >= 2 || variant->operand_slots[operand_index] >= 4) return false;
            operand_slots[count++] = variant->operand_slots[operand_index];
            *has_memory_base = true;
        }
        else if (kind == MACHINE_X64_EXACT_OPERAND_RBP_MEMORY_PAYLOAD ||
                 kind == MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD)
        {
            if (*displacement_operand_index != UINT8_MAX ||
                !(variant->flags & MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32) ||
                variant->operand_slots[operand_index] >= 4)
                return false;
            *displacement_operand_index = (u8)operand_index;
        }
        else if (kind == MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD)
        {
            if (*immediate_operand_index != UINT8_MAX) return false;
            *immediate_operand_index = (u8)operand_index;
        }
        else if (kind != MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX &&
                 kind != MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX && kind != MACHINE_X64_EXACT_OPERAND_FIXED_RSP)
        {
            return false;
        }
        u16 width = variant->operand_widths[operand_index];
        if (width != 8 && width != 16 && width != 32 && width != 64) return false;
    }
    if (!count && *immediate_operand_index == UINT8_MAX && *displacement_operand_index == UINT8_MAX) return false;
    *operand_count = count;
    return true;
}

BUSTER_GLOBAL_LOCAL u8 machine_x64_exact_prepare_gpr_encoding_table(
    MachineX64ExactRecipeVariant const* variant, BusterX86MetadataMachineExactToken token)
{
    if (machine_x64_gpr_encoding_table_count >= MACHINE_X64_GPR_ENCODING_TABLE_CAPACITY) return 0;
    u8 operand_slots[2] = {0};
    u8 register_operand_count = 0;
    u8 immediate_operand_index = UINT8_MAX;
    u8 displacement_operand_index = UINT8_MAX;
    bool has_memory_base = false;
    if (!machine_x64_exact_gpr_variant_slots(variant, operand_slots, &register_operand_count,
                                              &immediate_operand_index, &displacement_operand_index,
                                              &has_memory_base))
        return 0;
    if (immediate_operand_index != UINT8_MAX && displacement_operand_index != UINT8_MAX) return 0;
    u8 immediate_width = immediate_operand_index == UINT8_MAX ? 0 : (u8)(variant->operand_widths[immediate_operand_index] / 8u);
    if (immediate_operand_index != UINT8_MAX &&
        (immediate_width == 0 || immediate_width > sizeof(u64) || variant->operand_widths[immediate_operand_index] % 8u))
        return 0;

    MachineX64GprEncodingTable* table = machine_x64_gpr_encoding_tables + machine_x64_gpr_encoding_table_count;
    bool compact = true;
    for (u32 register_key = 0; register_key < BUSTER_ARRAY_LENGTH(table->encodings); register_key += 1)
    {
        u8 register_values[2] = {(u8)(register_key & 15u), (u8)(register_key >> 4)};
        u32 register_value_index = 0;
        BusterX86MetadataPhysicalOperand operands[4];
        for (u32 operand_index = 0; operand_index < variant->operand_count; operand_index += 1)
        {
            u32 reg = 0;
            switch ((MachineX64ExactOperandProjection)variant->operand_kinds[operand_index])
            {
            case MACHINE_X64_EXACT_OPERAND_GPR: reg = register_values[register_value_index++]; break;
            case MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO:
            {
                reg = register_values[register_value_index++];
                u16 width = variant->operand_widths[operand_index];
                operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                    .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
                    .width = width,
                    .memory = {
                        .base = {.index = (u16)reg, .width = 64,
                                 .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
                        .address_size = 64,
                        .scale = 1,
                        .has_base = true,
                    },
                };
                continue;
            }
            case MACHINE_X64_EXACT_OPERAND_RBP_MEMORY_PAYLOAD:
            case MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD:
            {
                u16 width = variant->operand_widths[operand_index];
                operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                    .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
                    .width = width,
                    .memory = {
                        .base = {.index = MACHINE_X64_RBP, .width = 64,
                                 .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
                        .address_size = 64,
                        .scale = 1,
                        .has_base = true,
                        .has_displacement = true,
                    },
                };
                continue;
            }
            case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX: reg = MACHINE_X64_RAX; break;
            case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX: reg = MACHINE_X64_RDX; break;
            case MACHINE_X64_EXACT_OPERAND_FIXED_RSP: reg = MACHINE_X64_RSP; break;
            case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD:
            {
                u16 width = variant->operand_widths[operand_index];
                bool unsigned_immediate = variant->key.form_id == MACHINE_X64_MOV_IMMEDIATE_EXACT_FORM_ID;
                operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                    .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE,
                    .width = width,
                    .has_value = !unsigned_immediate,
                    .has_unsigned_value = unsigned_immediate,
                    .unsigned_value = 0,
                };
                continue;
            }
            default: return 0;
            }
            u16 width = variant->operand_widths[operand_index];
            operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
                .width = width,
                .reg = {.index = (u16)reg, .width = width, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR},
            };
        }
        MachineX64GprEncoding* encoding = table->encodings + register_key;
        BusterX86MetadataEmitResult emitted = buster_x86_metadata_emit_exact_machine(token, (BusterX86MetadataMachineExactQuery){
            .operands = operands,
            .operand_count = variant->operand_count,
            .output = encoding->bytes,
            .output_capacity = BUSTER_ARRAY_LENGTH(encoding->bytes),
            .force_disp32 = displacement_operand_index != UINT8_MAX,
        });
        if (emitted.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || emitted.relocation_count != 0 ||
            emitted.byte_count > BUSTER_ARRAY_LENGTH(encoding->bytes))
            return 0;
        encoding->byte_count = (u8)emitted.byte_count;
        if (immediate_operand_index != UINT8_MAX)
        {
            if (emitted.byte_count < immediate_width) return 0;
            u64 probe_value = immediate_width == 1 ? UINT64_C(0x5a) :
                              immediate_width == 2 ? UINT64_C(0x5aa5) :
                              immediate_width == 4 ? UINT64_C(0x5aa55aa5) : UINT64_C(0x5aa55aa55aa55aa5);
            BusterX86MetadataPhysicalOperand* immediate = operands + immediate_operand_index;
            if (immediate->has_unsigned_value) immediate->unsigned_value = probe_value;
            else immediate->value = (s64)probe_value;
            u8 probe_bytes[15];
            BusterX86MetadataEmitResult probe = buster_x86_metadata_emit_exact_machine(token, (BusterX86MetadataMachineExactQuery){
                .operands = operands,
                .operand_count = variant->operand_count,
                .output = probe_bytes,
                .output_capacity = BUSTER_ARRAY_LENGTH(probe_bytes),
            });
            if (probe.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || probe.relocation_count != 0 ||
                probe.byte_count != emitted.byte_count)
                return 0;
            u32 immediate_offset = emitted.byte_count - immediate_width;
            for (u32 byte_index = 0; byte_index < emitted.byte_count; byte_index += 1)
            {
                u8 expected = (u8)(byte_index >= immediate_offset ? probe_value >> ((byte_index - immediate_offset) * 8u) : encoding->bytes[byte_index]);
                if (probe_bytes[byte_index] != expected) return 0;
            }
        }
        if (displacement_operand_index != UINT8_MAX)
        {
            if (emitted.byte_count < sizeof(u32)) return 0;
            u32 probe_value = UINT32_C(0x5aa55aa5);
            operands[displacement_operand_index].memory.displacement = (s32)probe_value;
            u8 probe_bytes[15];
            BusterX86MetadataEmitResult probe = buster_x86_metadata_emit_exact_machine(token, (BusterX86MetadataMachineExactQuery){
                .operands = operands,
                .operand_count = variant->operand_count,
                .output = probe_bytes,
                .output_capacity = BUSTER_ARRAY_LENGTH(probe_bytes),
                .force_disp32 = true,
            });
            if (probe.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || probe.relocation_count != 0 ||
                probe.byte_count != emitted.byte_count)
                return 0;
            u32 displacement_offset = emitted.byte_count - (u32)sizeof(u32);
            for (u32 byte_index = 0; byte_index < emitted.byte_count; byte_index += 1)
            {
                u8 expected = (u8)(byte_index >= displacement_offset ? probe_value >> ((byte_index - displacement_offset) * 8u) : encoding->bytes[byte_index]);
                if (probe_bytes[byte_index] != expected) return 0;
            }
        }
        compact &= emitted.byte_count <= 3;
    }
    if (compact)
    {
        for (u32 register_key = 0; register_key < BUSTER_ARRAY_LENGTH(table->encodings); register_key += 1)
        {
            table->encodings[register_key].bytes[3] = table->encodings[register_key].byte_count;
        }
    }
    table->operand_slots[0] = operand_slots[0];
    table->operand_slots[1] = operand_slots[1];
    table->operand_count = register_operand_count;
    table->immediate_width = immediate_width;
    table->memory_operand_slot = displacement_operand_index == UINT8_MAX ? 0 : variant->operand_slots[displacement_operand_index];
    table->flags = (compact ? MACHINE_X64_GPR_ENCODING_TABLE_COMPACT : 0u) |
                   ((register_operand_count == 2 && (variant->flags & MACHINE_X64_EXACT_RECIPE_FLAG_SELF_COPY_NOOP))
                        ? MACHINE_X64_GPR_ENCODING_TABLE_SELF_COPY_NOOP
                        : 0u) |
                   (immediate_operand_index != UINT8_MAX ? MACHINE_X64_GPR_ENCODING_TABLE_PATCH_IMMEDIATE : 0u) |
                   (has_memory_base ? MACHINE_X64_GPR_ENCODING_TABLE_MEMORY_BASE : 0u) |
                   (displacement_operand_index != UINT8_MAX ? MACHINE_X64_GPR_ENCODING_TABLE_PATCH_DISPLACEMENT : 0u) |
                   ((displacement_operand_index != UINT8_MAX &&
                     variant->operand_kinds[displacement_operand_index] == MACHINE_X64_EXACT_OPERAND_RBP_MEMORY_PAYLOAD)
                        ? MACHINE_X64_GPR_ENCODING_TABLE_INCOMING_DISPLACEMENT
                        : 0u) |
                   ((immediate_operand_index != UINT8_MAX && variant->key.form_id == MACHINE_X64_SUB_RSP_EXACT_FORM_ID)
                        ? MACHINE_X64_GPR_ENCODING_TABLE_IMMEDIATE_FROM_PAYLOAD
                        : 0u);
    machine_x64_gpr_encoding_table_count += 1;
    return (u8)machine_x64_gpr_encoding_table_count;
}

BUSTER_GLOBAL_LOCAL u8 machine_x64_exact_prepare_variable_memory_encoding_table(
    MachineX64ExactRecipeVariant const* variant, BusterX86MetadataMachineExactToken token)
{
    if (!variant || variant->operand_count != 2 || variant->flags ||
        machine_x64_variable_memory_encoding_table_count >= MACHINE_X64_VARIABLE_MEMORY_TABLE_CAPACITY)
        return 0;

    u32 gpr_operand_index = UINT32_MAX;
    u32 memory_operand_index = UINT32_MAX;
    for (u32 operand_index = 0; operand_index < variant->operand_count; operand_index += 1)
    {
        MachineX64ExactOperandProjection kind = (MachineX64ExactOperandProjection)variant->operand_kinds[operand_index];
        if (kind == MACHINE_X64_EXACT_OPERAND_GPR && gpr_operand_index == UINT32_MAX)
        {
            gpr_operand_index = operand_index;
        }
        else if ((kind == MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO ||
                  kind == MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD) &&
                 memory_operand_index == UINT32_MAX)
        {
            memory_operand_index = operand_index;
        }
        else
        {
            return 0;
        }
        u16 width = variant->operand_widths[operand_index];
        if ((width != 8 && width != 16 && width != 32 && width != 64) ||
            variant->operand_slots[operand_index] >= 4)
            return 0;
    }
    if (gpr_operand_index == UINT32_MAX || memory_operand_index == UINT32_MAX) return 0;

    MachineX64VariableMemoryEncodingTable* table =
        machine_x64_variable_memory_encoding_tables + machine_x64_variable_memory_encoding_table_count;
    s32 const class_displacements[MACHINE_X64_MEMORY_DISPLACEMENT_CLASS_COUNT] = {
        0,
        INT32_C(0x5a),
        INT32_C(0x12345678),
    };
    s32 const probe_displacements[MACHINE_X64_MEMORY_DISPLACEMENT_CLASS_COUNT] = {
        0,
        -INT32_C(0x5b),
        INT32_C(0x5aa55aa5),
    };
    u8 const patch_widths[MACHINE_X64_MEMORY_DISPLACEMENT_CLASS_COUNT] = {0, 1, 4};

    for (u32 displacement_class = 0; displacement_class < MACHINE_X64_MEMORY_DISPLACEMENT_CLASS_COUNT; displacement_class += 1)
    {
        for (u32 register_key = 0; register_key < 256; register_key += 1)
        {
            u32 data_register = register_key & 15u;
            u32 base_register = register_key >> 4;
            BusterX86MetadataPhysicalOperand operands[2];
            operands[gpr_operand_index] = (BusterX86MetadataPhysicalOperand){
                .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
                .width = variant->operand_widths[gpr_operand_index],
                .reg = {
                    .index = (u16)data_register,
                    .width = variant->operand_widths[gpr_operand_index],
                    .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR,
                },
            };
            operands[memory_operand_index] = (BusterX86MetadataPhysicalOperand){
                .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
                .width = variant->operand_widths[memory_operand_index],
                .memory = {
                    .base = {
                        .index = (u16)base_register,
                        .width = 64,
                        .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR,
                    },
                    .displacement = class_displacements[displacement_class],
                    .address_size = 64,
                    .scale = 1,
                    .has_base = true,
                    .has_displacement = displacement_class != 0,
                },
            };

            MachineX64GprEncoding* encoding = table->encodings[displacement_class] + register_key;
            BusterX86MetadataEmitResult emitted = buster_x86_metadata_emit_exact_machine(token, (BusterX86MetadataMachineExactQuery){
                .operands = operands,
                .operand_count = variant->operand_count,
                .output = encoding->bytes,
                .output_capacity = BUSTER_ARRAY_LENGTH(encoding->bytes),
            });
            if (emitted.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || emitted.relocation_count != 0 ||
                emitted.byte_count > BUSTER_ARRAY_LENGTH(encoding->bytes))
                return 0;
            encoding->byte_count = (u8)emitted.byte_count;

            u32 patch_width = patch_widths[displacement_class];
            if (patch_width)
            {
                if (emitted.byte_count < patch_width) return 0;
                operands[memory_operand_index].memory.displacement = probe_displacements[displacement_class];
                u8 probe_bytes[15];
                BusterX86MetadataEmitResult probe = buster_x86_metadata_emit_exact_machine(token, (BusterX86MetadataMachineExactQuery){
                    .operands = operands,
                    .operand_count = variant->operand_count,
                    .output = probe_bytes,
                    .output_capacity = BUSTER_ARRAY_LENGTH(probe_bytes),
                });
                if (probe.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || probe.relocation_count != 0 ||
                    probe.byte_count != emitted.byte_count)
                    return 0;
                u32 patch_offset = emitted.byte_count - patch_width;
                u32 probe_value = (u32)probe_displacements[displacement_class];
                for (u32 byte_index = 0; byte_index < emitted.byte_count; byte_index += 1)
                {
                    u8 expected = (u8)(byte_index >= patch_offset ? probe_value >> ((byte_index - patch_offset) * 8u) : encoding->bytes[byte_index]);
                    if (probe_bytes[byte_index] != expected) return 0;
                }
            }
        }
    }

    table->gpr_operand_slot = variant->operand_slots[gpr_operand_index];
    table->memory_operand_slot = variant->operand_slots[memory_operand_index];
    machine_x64_variable_memory_encoding_table_count += 1;
    return (u8)machine_x64_variable_memory_encoding_table_count;
}

BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_form_entry(MachineX64PreparedExactOpcode* entry,
                                                               MachineX64EmitRegistryEntry const* registry_entry,
                                                               BusterX86MetadataExactPlan const* prepared, bool const* plan_valid)
{
    MachineX64ExactRecipe const* descriptor = entry->descriptor;
    MachineEmitRecipeCategory category = descriptor ? machine_emit_recipe_category(descriptor->recipe) : MACHINE_EMIT_RECIPE_CATEGORY_COUNT;
    bool descriptor_valid = registry_entry && registry_entry->producer_status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_FORM &&
                            descriptor && descriptor->key.stable_hash != 0 && descriptor->recipe == registry_entry->recipe &&
                            (category == MACHINE_EMIT_RECIPE_CATEGORY_DIRECT || category == MACHINE_EMIT_RECIPE_CATEGORY_FAMILY);
    u16 recipe_index = descriptor_valid ? machine_emit_recipe_index(descriptor->recipe) : 0;
    u32 variant_total = descriptor_valid ? descriptor->variant_count + 1u : 0;
    descriptor_valid &= variant_total > 0 && variant_total <= BUSTER_ARRAY_LENGTH(entry->metadata_tokens);
    entry->variant_count = (u8)(descriptor_valid ? variant_total : 0);
    entry->variant_valid_mask = 0;
    for (u32 variant_index = 0; descriptor_valid && variant_index < variant_total; variant_index += 1)
    {
        MachineX64ExactRecipeVariant variant = machine_x64_exact_recipe_variant(descriptor, variant_index);
        u8 plan_id = machine_x64_exact_plan_id_for_recipe_variant(category, recipe_index, variant_index);
        bool variant_valid = plan_id < MACHINE_X64_EXACT_PLAN_COUNT && plan_valid[plan_id] &&
                             prepared[plan_id].form_id == variant.key.form_id && prepared[plan_id].stable_hash == variant.key.stable_hash;
        if (variant_valid)
        {
            variant_valid = buster_x86_metadata_machine_exact_token_for_plan(
                prepared[plan_id],
                (BusterX86MetadataFeatureInput){.names = variant.features, .count = variant.feature_count},
                &entry->metadata_tokens[variant_index]);
        }
        entry->gpr_encoding_tables[variant_index] = variant_valid
            ? machine_x64_exact_prepare_gpr_encoding_table(&variant, entry->metadata_tokens[variant_index])
            : 0;
        entry->variable_memory_encoding_tables[variant_index] = variant_valid
            ? machine_x64_exact_prepare_variable_memory_encoding_table(&variant, entry->metadata_tokens[variant_index])
            : 0;
        if (variant_valid) entry->variant_valid_mask |= (u16)(1u << variant_index);
        else descriptor_valid = false;
    }
    if (descriptor_valid && entry->variant_valid_mask == (u16)((1u << variant_total) - 1u))
    {
        entry->descriptor = descriptor;
        entry->single_gpr_encoding_table = variant_total == 1 ? entry->gpr_encoding_tables[0] : 0;
        entry->plan_valid = true;
    }
    else
    {
        // Retain exact_required so an invalid exact row is counted and
        // rejected by the worker lane instead of using the old switch as an
        // accidental fallback.
        entry->descriptor = 0;
        for (u32 token_index = 0; token_index < BUSTER_ARRAY_LENGTH(entry->metadata_tokens); token_index += 1)
        {
            entry->metadata_tokens[token_index] = (BusterX86MetadataMachineExactToken){0};
        }
        entry->variant_count = 0;
        entry->single_gpr_encoding_table = 0;
        for (u32 table_index = 0; table_index < BUSTER_ARRAY_LENGTH(entry->variable_memory_encoding_tables); table_index += 1)
        {
            entry->variable_memory_encoding_tables[table_index] = 0;
        }
        entry->variant_valid_mask = 0;
        entry->plan_valid = false;
    }
}

// The dense variable-memory table a chunk emits through, by direction and by
// chunk width. Both chunk emitters used to name their pointer opcode with a
// ternary ladder, index the 1.064-byte prepared row with it, and read
// `plan_valid`, `variant_count` and `variable_memory_encoding_tables[0]` from
// three different lines of that row -- for a closed population of eight
// opcodes whose answer stops changing at prewarm. Eight bytes published there
// answer it instead, and zero at rest is the same refusal an unprepared row
// gave, because machine_x64_emit_variable_memory_encoding refuses table zero
// before it touches the encoder.
#define MACHINE_X64_CHUNK_WIDTH_COUNT 4u
#define MACHINE_X64_CHUNK_DIRECTION_LOAD 0u
#define MACHINE_X64_CHUNK_DIRECTION_STORE 1u
BUSTER_GLOBAL_LOCAL u8 machine_x64_chunk_memory_tables[2][MACHINE_X64_CHUNK_WIDTH_COUNT];
// Frame chunks are the closed RBP, forced-disp32 row of those same tables:
// the record depends only on direction, width and data register, so prewarm
// copies the sixteen RBP records of each table here and a spill or reload
// reads one record instead of re-validating the table index and re-deriving
// the displacement class and row stride per call. The frame base offset is
// still added at emission time; it is a per-function fact. A zero byte count
// is the same refusal an unprepared table gave.
BUSTER_GLOBAL_LOCAL MachineX64GprEncoding machine_x64_frame_chunk_encodings[2][MACHINE_X64_CHUNK_WIDTH_COUNT][16];
// Chunk byte counts are 1, 2, 4 and 8 (machine_x64_copy_chunk); every other
// value took the ladder's 64-bit arm, so it maps to the last width here.
BUSTER_GLOBAL_LOCAL u8 const machine_x64_chunk_width_index[9] = {3, 0, 1, 3, 2, 3, 3, 3, 3};

BUSTER_GLOBAL_LOCAL u32 machine_x64_chunk_width_slot(u32 chunk)
{
    u32 result = chunk < BUSTER_ARRAY_LENGTH(machine_x64_chunk_width_index)
                     ? machine_x64_chunk_width_index[chunk]
                     : MACHINE_X64_CHUNK_WIDTH_COUNT - 1u;

    return result;
}

// The chunk emitters' dense-table projection, published from the prepared
// rows the map preparation has just resolved.
BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_chunk_memory_tables(void)
{
    static u16 const load_opcodes[MACHINE_X64_CHUNK_WIDTH_COUNT] = {MACHINE_X64_LOAD_PTR8, MACHINE_X64_LOAD_PTR16,
                                                                    MACHINE_X64_LOAD_PTR32, MACHINE_X64_LOAD_PTR64};
    static u16 const store_opcodes[MACHINE_X64_CHUNK_WIDTH_COUNT] = {MACHINE_X64_STORE_PTR8, MACHINE_X64_STORE_PTR16,
                                                                     MACHINE_X64_STORE_PTR32, MACHINE_X64_STORE_PTR64};
    for (u32 width_slot = 0; width_slot < MACHINE_X64_CHUNK_WIDTH_COUNT; width_slot += 1)
    {
        // Indexed rather than looked up: the eight opcodes above are registry
        // rows by construction, and the accessor that proves that for an
        // arbitrary opcode is defined further down the file.
        u32 load_ordinal = (u32)(load_opcodes[width_slot] - MACHINE_X64_MOV_RI);
        u32 store_ordinal = (u32)(store_opcodes[width_slot] - MACHINE_X64_MOV_RI);
        MachineX64PreparedExactOpcode const* load_entry =
            load_ordinal < MACHINE_X86_64_EMIT_REGISTRY_COUNT ? machine_x64_exact_opcode_map + load_ordinal : 0;
        MachineX64PreparedExactOpcode const* store_entry =
            store_ordinal < MACHINE_X86_64_EMIT_REGISTRY_COUNT ? machine_x64_exact_opcode_map + store_ordinal : 0;
        machine_x64_chunk_memory_tables[MACHINE_X64_CHUNK_DIRECTION_LOAD][width_slot] =
            load_entry && load_entry->plan_valid && load_entry->variant_count ? load_entry->variable_memory_encoding_tables[0] : 0;
        machine_x64_chunk_memory_tables[MACHINE_X64_CHUNK_DIRECTION_STORE][width_slot] =
            store_entry && store_entry->plan_valid && store_entry->variant_count ? store_entry->variable_memory_encoding_tables[0] : 0;
        for (u32 direction = 0; direction < 2; direction += 1)
        {
            u8 table_plus_one = machine_x64_chunk_memory_tables[direction][width_slot];
            for (u32 reg = 0; reg < 16; reg += 1)
            {
                machine_x64_frame_chunk_encodings[direction][width_slot][reg] =
                    table_plus_one && table_plus_one <= machine_x64_variable_memory_encoding_table_count
                        ? machine_x64_variable_memory_encoding_tables[table_plus_one - 1u].encodings[2][reg + (MACHINE_X64_RBP << 4)]
                        : (MachineX64GprEncoding){0};
            }
        }
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_opcode_map(BusterX86MetadataExactPlan const* prepared, bool const* plan_valid)
{
    for (u32 ordinal = 0; ordinal < MACHINE_X86_64_EMIT_REGISTRY_COUNT; ordinal += 1)
    {
        // The dense map is only observed after the ready bit is published, so
        // its static rows are safe serial staging storage.  Mutating each row
        // in place avoids a large aggregate scratch array (and its generated
        // zeroing/copying MIR) in the self-hosted prewarm function.
        MachineX64PreparedExactOpcode* entry = machine_x64_exact_opcode_map + ordinal;
        if (entry->exact_required)
        {
            MachineX64EmitRegistryEntry const* registry_entry = machine_x86_64_emit_registry_entry(ordinal);
            if (entry->sequence_required)
            {
                machine_x64_exact_prepare_sequence_entry(entry, registry_entry);
            }
            else
            {
                machine_x64_exact_prepare_form_entry(entry, registry_entry, prepared, plan_valid);
            }
        }
    }
}

// Prepare the immutable metadata plans once on the serial prewarm thread.
// Width variants and projection variants deliberately share a plan identity;
// workers only read the published value table after the ready bit is set.  The
// opcode map is published even when one key is stale: its exact-required bits
// remain set, while the affected descriptor/plan entries stay invalid so the
// worker lane fails closed rather than falling through to handwritten bytes.
void machine_x86_64_exact_prewarm(void)
{
    if (machine_x64_exact_opcode_map_ready) return;
    BUSTER_CHECK_SERIAL_INITIALIZATION();

    BusterX86MetadataFormKey keys[MACHINE_X64_EXACT_PLAN_COUNT] = {0};
    bool key_found[MACHINE_X64_EXACT_PLAN_COUNT] = {0};
    BusterX86MetadataExactPlan prepared[MACHINE_X64_EXACT_PLAN_COUNT] = {0};
    bool plan_valid[MACHINE_X64_EXACT_PLAN_COUNT] = {0};
    machine_x64_gpr_encoding_table_count = 0;
    machine_x64_variable_memory_encoding_table_count = 0;
    machine_x64_exact_collect_plan_keys(keys, key_found);
    machine_x64_exact_prepare_plans(keys, key_found, prepared, plan_valid);
    machine_x64_exact_prepare_fcmp_alternate_tokens();
    machine_x64_exact_prepare_opcode_map(prepared, plan_valid);
    machine_x64_exact_prepare_chunk_memory_tables();
    machine_x64_metadata_shape_cache_prewarm();
    // Templates are encoded through the shape cache and the staged tokens,
    // so they are published last.
    machine_x64_exact_prepare_fixed_templates();

    // Every row was staged serially above.  The ready bit is written last;
    // codegen_prewarm() completes before any worker lane can observe globals.
    machine_x64_exact_opcode_map_ready = true;
}

#if BUSTER_INCLUDE_TESTS
MachineX64ExactMapAudit machine_x86_64_exact_map_audit(void)
{
    machine_x86_64_exact_prewarm();
    MachineX64ExactMapAudit result = {.valid = machine_x64_exact_opcode_map_ready};
    result.registry_rows = MACHINE_X86_64_EMIT_REGISTRY_COUNT;
    for (u32 ordinal = 0; ordinal < result.registry_rows; ordinal += 1)
    {
        MachineX64PreparedExactOpcode const* entry = machine_x64_exact_opcode_map + ordinal;
        MachineX64EmitRegistryEntry const* registry_entry = machine_x86_64_emit_registry_entry(ordinal);
        bool row_valid = registry_entry != 0;
        if (!row_valid)
        {
            result.valid = false;
            continue;
        }
        MachineX64EmitProducerStatus status = (MachineX64EmitProducerStatus)registry_entry->producer_status;
        bool is_exact_form = status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_FORM;
        bool is_exact_sequence = status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXACT_SEQUENCE;
        bool is_expansion = status == MACHINE_X64_EMIT_PRODUCER_STATUS_EXPANSION_POLICY;
        if (is_exact_form || is_exact_sequence)
        {
            result.exact_rows += 1;
            bool variants_in_range = entry->variant_count > 0 && entry->variant_count <= 16;
            u16 expected_mask = (u16)(variants_in_range ? (1u << entry->variant_count) - 1u : 0u);
            bool variants_valid = variants_in_range && entry->variant_valid_mask == expected_mask;
            bool exact_row_valid = entry->exact_required && entry->plan_valid && variants_valid;
            if (is_exact_sequence)
            {
                result.sequence_rows += 1;
                bool sequence_valid = exact_row_valid && entry->sequence_required && entry->sequence && !entry->descriptor &&
                                       entry->sequence->variant_count == entry->variant_count;
                if (sequence_valid) result.sequence_variant_valid_rows += 1;
                exact_row_valid = sequence_valid;
            }
            else
            {
                exact_row_valid = exact_row_valid && !entry->sequence_required && entry->descriptor && !entry->sequence;
            }
            if (exact_row_valid) result.exact_plan_valid_rows += 1;
            result.valid &= exact_row_valid;
        }
        else if (is_expansion)
        {
            result.expansion_rows += 1;
            bool nonexact = !entry->exact_required && !entry->sequence_required && !entry->plan_valid && !entry->descriptor &&
                            !entry->sequence && entry->variant_count == 0 && entry->variant_valid_mask == 0;
            if (nonexact) result.expansion_nonexact_rows += 1;
            result.valid &= nonexact;
        }
        else
        {
            result.valid = false;
        }
    }
    result.valid &= result.exact_rows == MACHINE_X86_64_EMIT_REGISTRY_EXACT_COUNT;
    result.valid &= result.exact_plan_valid_rows == result.exact_rows;
    result.valid &= result.sequence_variant_valid_rows == result.sequence_rows;
    result.valid &= result.expansion_rows == MACHINE_X86_64_EMIT_REGISTRY_EXPANSION_COUNT;
    result.valid &= result.expansion_nonexact_rows == result.expansion_rows;
    result.dense_encoding_tables = machine_x64_gpr_encoding_table_count;
    result.variable_memory_encoding_tables = machine_x64_variable_memory_encoding_table_count;
    result.fixed_template_rows = machine_x64_fixed_template_count;
    result.fixed_template_invalid_rows = machine_x64_fixed_template_invalid_count;
    for (u32 table_index = 0; table_index < machine_x64_gpr_encoding_table_count; table_index += 1)
    {
        result.immediate_patch_tables +=
            (machine_x64_gpr_encoding_tables[table_index].flags & MACHINE_X64_GPR_ENCODING_TABLE_PATCH_IMMEDIATE) != 0;
        result.memory_base_tables +=
            (machine_x64_gpr_encoding_tables[table_index].flags & MACHINE_X64_GPR_ENCODING_TABLE_MEMORY_BASE) != 0;
        result.displacement_patch_tables +=
            (machine_x64_gpr_encoding_tables[table_index].flags & MACHINE_X64_GPR_ENCODING_TABLE_PATCH_DISPLACEMENT) != 0;
    }
    return result;
}
#endif


typedef struct MachineX64ExactEmitCounters MachineX64ExactEmitCounters;
struct MachineX64ExactEmitCounters
{
    u32 attempts;
    u32 successes;
    u32 fallbacks;
};

BUSTER_GLOBAL_LOCAL void machine_x64_exact_counters_assign(MachineEncodeResult* result,
                                                            MachineX64ExactEmitCounters counters)
{
    result->exact_attempts = counters.attempts;
    result->exact_successes = counters.successes;
    result->exact_failures = counters.fallbacks;
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_gpr_operand(u32 reg, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
        .width = width,
        .reg = {
            .index = (u16)reg,
            .width = width,
            .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR,
        },
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_xmm_operand(u32 reg, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
        .width = width,
        .reg = {
            .index = (u16)reg,
            .width = width,
            .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_XMM,
        },
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_ymm_operand(u32 reg)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = 256,
        .reg = {.index = (u16)reg, .width = 256, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_YMM},
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_immediate_operand(s64 value, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE,
        .width = width,
        .value = value,
        .has_value = true,
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_unsigned_immediate_operand(u64 value, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE,
        .width = width,
        .unsigned_value = value,
        .has_unsigned_value = true,
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_relative_operand(s64 value, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_RELATIVE,
        .width = width,
        .value = value,
        .has_value = true,
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_rip_memory_operand(void)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
        .width = 64,
        .memory = {
            .displacement = 0,
            .address_size = 64,
            .scale = 1,
            .has_displacement = true,
            .rip_relative = true,
        },
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_memory_operand(u32 base, u16 width, s64 displacement, bool force_displacement)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
        .width = width,
        .memory = {
            .base = {
                .index = (u16)base,
                .width = 64,
                .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_GPR,
            },
            .displacement = displacement,
            .address_size = 64,
            .scale = 1,
            .has_base = true,
            .has_displacement = force_displacement || displacement != 0,
        },
    };
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_rbp_memory_operand(s64 displacement, u16 width, bool force_displacement)
{
    return machine_x64_exact_memory_operand(MACHINE_X64_RBP, width, displacement, force_displacement);
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_zmm_operand(u32 reg, u16 width);

BUSTER_GLOBAL_LOCAL u8 machine_x64_metadata_shape_immediate_class(BusterX86MetadataPhysicalOperand operand)
{
    u8 result;
    if (operand.has_unsigned_value)
    {
        result = 5;
    }
    else if (!operand.has_value)
    {
        result = 0;
    }
    else if (operand.value >= INT8_MIN && operand.value <= INT8_MAX)
    {
        result = operand.value < 0 ? 2 : 1;
    }
    else if (operand.value >= INT32_MIN && operand.value <= INT32_MAX)
    {
        result = operand.value < 0 ? 4 : 3;
    }
    else
    {
        result = operand.value < 0 ? 6 : 7;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL u8 machine_x64_metadata_shape_displacement_class(BusterX86MetadataPhysicalOperand operand)
{
    u8 result;
    if (operand.kind != BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY || !operand.memory.has_displacement)
    {
        result = 0;
    }
    else if (operand.memory.displacement >= INT8_MIN && operand.memory.displacement <= INT8_MAX)
    {
        result = 1;
    }
    else if (operand.memory.displacement >= INT32_MIN && operand.memory.displacement <= INT32_MAX)
    {
        result = 2;
    }
    else
    {
        result = 3;
    }

    return result;
}

// The mnemonics the shape signature distinguishes, and the small dense id each
// one folds to. Every producer must have a distinct nonzero identity so
// operand-free instructions cannot alias when their feature counts agree.
typedef struct MachineX64ShapeMnemonic MachineX64ShapeMnemonic;
struct MachineX64ShapeMnemonic
{
    String8 name;
    u8 id;
};

// Rows are grouped by length, ascending, and the span table below indexes
// straight into each group -- this stands in for the length test that opened
// every arm of the per-character compare ladder this replaced. Keep both in
// step when editing: adding a row means bumping every later span bound.
BUSTER_GLOBAL_LOCAL MachineX64ShapeMnemonic const machine_x64_shape_mnemonics[] = {
    {S8_INITIALIZER("JB"), 7},
    {S8_INITIALIZER("JZ"), 11},
    {S8_INITIALIZER("OR"), 14},
    {S8_INITIALIZER("ADC"), 79},
    {S8_INITIALIZER("SBB"), 80},
    {S8_INITIALIZER("ADD"), 1},
    {S8_INITIALIZER("AND"), 2},
    {S8_INITIALIZER("CDQ"), 3},
    {S8_INITIALIZER("CMP"), 4},
    {S8_INITIALIZER("CQO"), 5},
    {S8_INITIALIZER("DIV"), 6},
    {S8_INITIALIZER("JMP"), 8},
    {S8_INITIALIZER("JNS"), 9},
    {S8_INITIALIZER("JNZ"), 10},
    {S8_INITIALIZER("LEA"), 12},
    {S8_INITIALIZER("MOV"), 13},
    {S8_INITIALIZER("POP"), 15},
    {S8_INITIALIZER("RET"), 16},
    {S8_INITIALIZER("SHL"), 78},
    {S8_INITIALIZER("SHR"), 17},
    {S8_INITIALIZER("SUB"), 18},
    {S8_INITIALIZER("UD2"), 19},
    {S8_INITIALIZER("XOR"), 20},
    {S8_INITIALIZER("NOP"), 52},
    {S8_INITIALIZER("MUL"), 22},
    {S8_INITIALIZER("FLD"), 56},
    {S8_INITIALIZER("NOT"), 81},
    {S8_INITIALIZER("CALL"), 21},
    {S8_INITIALIZER("IDIV"), 23},
    {S8_INITIALIZER("JNBE"), 24},
    {S8_INITIALIZER("MOVQ"), 25},
    {S8_INITIALIZER("PUSH"), 26},
    {S8_INITIALIZER("TEST"), 33},
    {S8_INITIALIZER("KORQ"), 44},
    {S8_INITIALIZER("FSTP"), 57},
    {S8_INITIALIZER("FILD"), 58},
    {S8_INITIALIZER("FCHS"), 65},
    {S8_INITIALIZER("SETZ"), 68},
    {S8_INITIALIZER("SETB"), 70},
    {S8_INITIALIZER("SETP"), 74},
    {S8_INITIALIZER("ADDSD"), 27},
    {S8_INITIALIZER("ADDSS"), 28},
    {S8_INITIALIZER("MOVSD"), 29},
    {S8_INITIALIZER("MOVZX"), 30},
    {S8_INITIALIZER("SUBSD"), 31},
    {S8_INITIALIZER("SUBSS"), 32},
    {S8_INITIALIZER("KMOVB"), 45},
    {S8_INITIALIZER("KMOVW"), 46},
    {S8_INITIALIZER("KMOVD"), 47},
    {S8_INITIALIZER("KMOVQ"), 48},
    {S8_INITIALIZER("KANDQ"), 49},
    {S8_INITIALIZER("KXORQ"), 50},
    {S8_INITIALIZER("PAUSE"), 53},
    {S8_INITIALIZER("CPUID"), 54},
    {S8_INITIALIZER("FISTP"), 59},
    {S8_INITIALIZER("FADDP"), 60},
    {S8_INITIALIZER("FSUBP"), 61},
    {S8_INITIALIZER("FMULP"), 62},
    {S8_INITIALIZER("FDIVP"), 63},
    {S8_INITIALIZER("FLDCW"), 67},
    {S8_INITIALIZER("SETNZ"), 69},
    {S8_INITIALIZER("SETBE"), 71},
    {S8_INITIALIZER("SETNB"), 73},
    {S8_INITIALIZER("SETNP"), 75},
    {S8_INITIALIZER("KXNORQ"), 51},
    {S8_INITIALIZER("XGETBV"), 55},
    {S8_INITIALIZER("MOVDQU"), 76},
    {S8_INITIALIZER("FNSTCW"), 66},
    {S8_INITIALIZER("SETNBE"), 72},
    {S8_INITIALIZER("CMPXCHG"), 34},
    {S8_INITIALIZER("UCOMISD"), 35},
    {S8_INITIALIZER("UCOMISS"), 36},
    {S8_INITIALIZER("FUCOMIP"), 64},
    {S8_INITIALIZER("VMOVDQU"), 77},
    {S8_INITIALIZER("CVTSI2SD"), 37},
    {S8_INITIALIZER("CVTSI2SS"), 38},
    {S8_INITIALIZER("VMOVDQU8"), 39},
    {S8_INITIALIZER("CVTTSD2SI"), 40},
    {S8_INITIALIZER("CVTTSS2SI"), 41},
    {S8_INITIALIZER("CMPXCHG16B"), 42},
    {S8_INITIALIZER("VZEROUPPER"), 43},
};

#define MACHINE_X64_SHAPE_MNEMONIC_MIN_LENGTH 2u
#define MACHINE_X64_SHAPE_MNEMONIC_MAX_LENGTH 10u

// First row of each length, indexed by length - 2, with a closing bound. There
// Closing bound for each mnemonic length group.
BUSTER_GLOBAL_LOCAL u8 const machine_x64_shape_mnemonic_spans[] = {0, 3, 27, 40, 64, 69, 74, 77, 79, 81};

BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(machine_x64_shape_mnemonics) == 81);
BUSTER_CT_CHECK(BUSTER_ARRAY_LENGTH(machine_x64_shape_mnemonic_spans) ==
                MACHINE_X64_SHAPE_MNEMONIC_MAX_LENGTH - MACHINE_X64_SHAPE_MNEMONIC_MIN_LENGTH + 2u);

BUSTER_GLOBAL_LOCAL u8 machine_x64_metadata_shape_mnemonic_id(String8 mnemonic)
{
    if (mnemonic.length >= MACHINE_X64_SHAPE_MNEMONIC_MIN_LENGTH && mnemonic.length <= MACHINE_X64_SHAPE_MNEMONIC_MAX_LENGTH)
    {
        u32 span = (u32)mnemonic.length - MACHINE_X64_SHAPE_MNEMONIC_MIN_LENGTH;
        // The first byte rejects all but a couple of rows in the widest span, so
        // the full compare runs about once per lookup rather than once per row.
        for (u32 row = machine_x64_shape_mnemonic_spans[span]; row < machine_x64_shape_mnemonic_spans[span + 1]; row += 1)
        {
            if (machine_x64_shape_mnemonics[row].name.pointer[0] == mnemonic.pointer[0] &&
                string_equal(machine_x64_shape_mnemonics[row].name, mnemonic))
            {
                return machine_x64_shape_mnemonics[row].id;
            }
        }
    }

    return 0;
}

BUSTER_GLOBAL_LOCAL u8 machine_x64_metadata_shape_feature_id(BusterX86MetadataFeatureInput features)
{
    u8 result;
    if (!features.count)
    {
        result = 0;
    }
    else if (features.names == machine_x64_sse_features)
    {
        result = 1;
    }
    else if (features.names == machine_x64_sse2_features)
    {
        result = 2;
    }
    else if (features.names == machine_x64_avx_features)
    {
        result = 3;
    }
    else if (features.names == machine_x64_avx512_features)
    {
        result = 4;
    }
    else if (features.names == machine_x64_cx16_features)
    {
        result = 5;
    }
    else if (features.names == machine_x64_avx512f_features)
    {
        result = 6;
    }
    else if (features.names == machine_x64_predicate_features)
    {
        result = 7;
    }
    else
    {
        result = (u8)(0x80u | BUSTER_MIN(features.count, 0x7fu));
    }

    return result;
}

typedef struct MachineX64MetadataShapeHashes MachineX64MetadataShapeHashes;
struct MachineX64MetadataShapeHashes
{
    u64 signature;
    u64 guard;
};

BUSTER_GLOBAL_LOCAL MachineX64MetadataShapeHashes machine_x64_metadata_shape_hashes(
    String8 mnemonic, BusterX86MetadataPhysicalOperand const* operands, u32 operand_count,
    BusterX86MetadataFeatureInput features, BusterX86MetadataPhysicalAttributes attributes)
{
    u64 common = machine_x64_metadata_shape_mnemonic_id(mnemonic) ^ ((u64)operand_count << 8) ^
                 ((u64)machine_x64_metadata_shape_feature_id(features) << 16);
    MachineX64MetadataShapeHashes hashes = {
        .signature = UINT64_C(1469598103934665603) ^ common,
        .guard = UINT64_C(0x6a09e667f3bcc909) ^ common,
    };
    u64 attribute_bits = attributes.decorator_flags | ((u64)attributes.apx_flags << 8) | ((u64)attributes.amx_flags << 16) |
                         ((u64)attributes.mask_register << 24) | ((u64)attributes.broadcast_elements << 32) |
                         ((u64)attributes.rounding_mode << 40) | ((u64)attributes.has_mask_register << 44) |
                         ((u64)attributes.zeroing << 45) | ((u64)attributes.sae << 46) | ((u64)attributes.no_flags << 47) |
                         ((u64)attributes.lock << 48) | ((u64)attributes.rep << 49) | ((u64)attributes.repne << 50) |
                         ((u64)attributes.implicit_segment << 51) | ((u64)attributes.branch_hint << 55) |
                         ((u64)attributes.notrack << 58) | ((u64)attributes.dfv << 59) | ((u64)attributes.has_dfv << 60);
    hashes.signature ^= attribute_bits;
    hashes.guard ^= attribute_bits;
    for (u32 operand_index = 0; operand_index < operand_count; operand_index += 1)
    {
        BusterX86MetadataPhysicalOperand operand = operands[operand_index];
        u64 descriptor = (u64)operand.kind | ((u64)operand.width << 4);
        if (operand.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER)
        {
            descriptor |= (u64)operand.reg.physical_class << 14;
            descriptor |= (u64)operand.reg.width << 18;
        }
        else if (operand.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY)
        {
            descriptor |= (u64)operand.memory.base.physical_class << 14;
            descriptor |= (u64)operand.memory.index.physical_class << 18;
            descriptor |= (u64)operand.memory.address_size << 22;
            descriptor |= (u64)operand.memory.scale << 30;
            descriptor |= (u64)operand.memory.segment << 34;
            descriptor |= (u64)operand.memory.has_base << 38;
            descriptor |= (u64)operand.memory.has_index << 39;
            descriptor |= (u64)operand.memory.rip_relative << 40;
            descriptor |= (u64)operand.memory.has_segment << 41;
            descriptor |= (u64)operand.memory.vsib << 42;
            descriptor |= (u64)machine_x64_metadata_shape_displacement_class(operand) << 43;
        }
        else if (operand.kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_IMMEDIATE)
        {
            descriptor |= (u64)machine_x64_metadata_shape_immediate_class(operand) << 14;
        }
        hashes.signature ^= descriptor + UINT64_C(0x9e3779b97f4a7c15) + (hashes.signature << 6) + (hashes.signature >> 2);
        hashes.signature *= UINT64_C(0x9e3779b97f4a7c15);
        hashes.guard ^= descriptor + UINT64_C(0x9e3779b97f4a7c15) + (hashes.guard << 6) + (hashes.guard >> 2);
        hashes.guard *= UINT64_C(0x9e3779b97f4a7c15);
    }
    return hashes;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_metadata_shape_cache_add(String8 mnemonic,
                                                               BusterX86MetadataPhysicalOperand const* operands, u32 operand_count,
                                                               BusterX86MetadataFeatureInput features,
                                                               BusterX86MetadataPhysicalAttributes attributes)
{
    BusterX86MetadataPhysicalQuery query = {
        .mnemonic = mnemonic,
        .operands = operands,
        .operand_count = operand_count,
        .features = features,
        .attributes = attributes,
        .address_size = 64,
        .execution_mode = BUSTER_X86_METADATA_EXECUTION_MODE_64,
        .include_privileged = false,
        .include_not64 = false,
        .include_implicit = false,
        .source_semantics = false,
    };
    BusterX86MetadataSelectResult selected = buster_x86_metadata_select_form(query);
    if (!machine_x64_metadata_shape_mnemonic_id(mnemonic) || selected.status != BUSTER_X86_METADATA_ENCODE_SUCCESS ||
        selected.form_id == UINT32_MAX || !selected.stable_hash)
    {
        machine_x64_metadata_shape_cache_invalid_count += 1;
        return false;
    }
    BusterX86MetadataFormKey key = {.form_id = selected.form_id, .stable_hash = selected.stable_hash};
    BusterX86MetadataExactPlan plan = {0};
    BusterX86MetadataMachineExactToken token = {0};
    if (!buster_x86_metadata_exact_plan_prepare(key, &plan) ||
        !buster_x86_metadata_machine_exact_token_for_plan(plan, features, &token))
    {
        machine_x64_metadata_shape_cache_invalid_count += 1;
        return false;
    }
    MachineX64MetadataShapeHashes hashes = machine_x64_metadata_shape_hashes(mnemonic, operands, operand_count, features, attributes);
    for (u32 entry_index = 0; entry_index < machine_x64_metadata_shape_cache_count; entry_index += 1)
    {
        MachineX64MetadataShapeCacheEntry* entry = machine_x64_metadata_shape_cache + entry_index;
        if (entry->signature != hashes.signature) continue;
        if (entry->guard != hashes.guard || entry->token.slot_plus_one != token.slot_plus_one ||
            entry->token.policy_flags != token.policy_flags ||
            entry->token.integrity != token.integrity)
        {
        machine_x64_metadata_shape_cache_invalid_count += 1;
            return false;
        }
        return true;
    }
    if (machine_x64_metadata_shape_cache_count >= MACHINE_X64_METADATA_SHAPE_CACHE_CAPACITY)
    {
        machine_x64_metadata_shape_cache_invalid_count += 1;
        return false;
    }
    machine_x64_metadata_shape_cache[machine_x64_metadata_shape_cache_count++] = (MachineX64MetadataShapeCacheEntry){
        .signature = hashes.signature,
        .guard = hashes.guard,
        .token = token,
    };
    return true;
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataMachineExactToken const* machine_x64_metadata_shape_cache_find(
    String8 mnemonic, BusterX86MetadataPhysicalOperand const* operands, u32 operand_count,
    BusterX86MetadataFeatureInput features, BusterX86MetadataPhysicalAttributes attributes)
{
    MachineX64MetadataShapeHashes hashes = machine_x64_metadata_shape_hashes(mnemonic, operands, operand_count, features, attributes);
    u32 slot = (u32)hashes.signature & (MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY - 1u);
    for (u32 probe = 0; probe < MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY; probe += 1)
    {
        u16 entry_plus_one = machine_x64_metadata_shape_cache_slots[slot];
        if (!entry_plus_one) return 0;
        MachineX64MetadataShapeCacheEntry const* entry = machine_x64_metadata_shape_cache + (entry_plus_one - 1u);
        if (entry->signature == hashes.signature)
        {
            return entry->guard == hashes.guard ? &entry->token : 0;
        }
        slot = (slot + 1u) & (MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY - 1u);
    }
    return 0;
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_publish_slots(void)
{
    for (u32 slot = 0; slot < MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY; slot += 1)
    {
        machine_x64_metadata_shape_cache_slots[slot] = 0;
    }
    for (u32 entry_index = 0; entry_index < machine_x64_metadata_shape_cache_count; entry_index += 1)
    {
        u32 slot = (u32)machine_x64_metadata_shape_cache[entry_index].signature &
                   (MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY - 1u);
        bool placed = false;
        for (u32 probe = 0; probe < MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY; probe += 1)
        {
            if (!machine_x64_metadata_shape_cache_slots[slot])
            {
                machine_x64_metadata_shape_cache_slots[slot] = (u16)(entry_index + 1u);
                placed = true;
                break;
            }
            slot = (slot + 1u) & (MACHINE_X64_METADATA_SHAPE_CACHE_SLOT_CAPACITY - 1u);
        }
        if (!placed) machine_x64_metadata_shape_cache_invalid_count += 1;
    }
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_predicate_operand(u32 reg)
{
    return (BusterX86MetadataPhysicalOperand){.kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = 64,
        .reg = {.index = (u16)reg, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_MASK}};
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_predicates(void)
{
    String8 const moves[] = {S8("KMOVB"), S8("KMOVW"), S8("KMOVD"), S8("KMOVQ")};
    String8 const logic[] = {S8("KANDQ"), S8("KORQ"), S8("KXORQ"), S8("KXNORQ")};
    BusterX86MetadataFeatureInput features = {.names = machine_x64_predicate_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_predicate_features)};
    for (u32 width = 0; width < 4; width += 1)
    {
        BusterX86MetadataPhysicalOperand operands[] = {machine_x64_predicate_operand(1), machine_x64_exact_gpr_operand(0, width == 3 ? 64 : 32)};
        (void)machine_x64_metadata_shape_cache_add(moves[width], operands, 2, features, (BusterX86MetadataPhysicalAttributes){0});
        BusterX86MetadataPhysicalOperand swap = operands[0]; operands[0] = operands[1]; operands[1] = swap;
        (void)machine_x64_metadata_shape_cache_add(moves[width], operands, 2, features, (BusterX86MetadataPhysicalAttributes){0});
        operands[0] = machine_x64_predicate_operand(1);
        (void)machine_x64_metadata_shape_cache_add(moves[width], operands, 2, features, (BusterX86MetadataPhysicalAttributes){0});
    }
    BusterX86MetadataPhysicalOperand operands[] = {machine_x64_predicate_operand(1), machine_x64_predicate_operand(2), machine_x64_predicate_operand(3)};
    for (u32 index = 0; index < BUSTER_ARRAY_LENGTH(logic); index += 1)
        (void)machine_x64_metadata_shape_cache_add(logic[index], operands, 3, features, (BusterX86MetadataPhysicalAttributes){0});
    for (u32 displacement = 0; displacement < 2; displacement += 1)
    {
        operands[0] = machine_x64_predicate_operand(1);
        operands[1] = machine_x64_exact_memory_operand(MACHINE_X64_RBP, 64, displacement ? -256 : -8, true);
        (void)machine_x64_metadata_shape_cache_add(S8("KMOVQ"), operands, 2, features, (BusterX86MetadataPhysicalAttributes){0});
        operands[0] = operands[1]; operands[1] = machine_x64_predicate_operand(1);
        (void)machine_x64_metadata_shape_cache_add(S8("KMOVQ"), operands, 2, features, (BusterX86MetadataPhysicalAttributes){0});
    }
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_x87_operand(u32 index)
{
    return (BusterX86MetadataPhysicalOperand){.kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = 80,
        .reg = {.index = (u16)index, .width = 80, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_SPECIAL}};
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_x87(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    BusterX86MetadataFeatureInput features = {.names = machine_x64_sse2_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features)};
    String8 memory_names[] = {S8("FLD"), S8("FSTP"), S8("FILD"), S8("FISTP"), S8("FNSTCW"), S8("FLDCW")};
    for (u32 displacement = 0; displacement < 2; displacement += 1)
    {
        s64 offset = displacement ? -256 : -16;
        for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(memory_names); name += 1)
        {
            u32 count = name < 2 ? 3u : 1u;
            for (u32 width = 0; width < count; width += 1)
            {
                u16 bits = name < 2 ? (width == 0 ? 32u : width == 1 ? 64u : 80u) : name < 4 ? 64u : 16u;
                BusterX86MetadataPhysicalOperand operand = machine_x64_exact_rbp_memory_operand(offset, bits, true);
                (void)machine_x64_metadata_shape_cache_add(memory_names[name], &operand, 1, features, attributes);
            }
        }
        for (u32 width = 16; width <= 32; width += 16)
        {
            BusterX86MetadataPhysicalOperand operands[] = {machine_x64_exact_rbp_memory_operand(offset, (u16)width, true),
                machine_x64_exact_immediate_operand(0, (u16)width)};
            (void)machine_x64_metadata_shape_cache_add(S8("MOV"), operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
        }
    }
    BusterX86MetadataPhysicalOperand pair[] = {machine_x64_x87_operand(1), machine_x64_x87_operand(0)};
    String8 binary_names[] = {S8("FADDP"), S8("FSUBP"), S8("FMULP"), S8("FDIVP")};
    for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(binary_names); name += 1)
    {
        (void)machine_x64_metadata_shape_cache_add(binary_names[name], pair, 1, features, attributes);
    }
    pair[0] = machine_x64_x87_operand(0); pair[1] = machine_x64_x87_operand(1);
    (void)machine_x64_metadata_shape_cache_add(S8("FUCOMIP"), pair + 1, 1, features, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("FSTP"), pair, 1, features, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("FCHS"), 0, 0, features, attributes);
    String8 comparisons[] = {S8("SETZ"), S8("SETNZ"), S8("SETB"), S8("SETBE"), S8("SETNBE"), S8("SETNB"), S8("SETP"), S8("SETNP")};
    BusterX86MetadataPhysicalOperand byte = machine_x64_exact_gpr_operand(0, 8);
    for (u32 name = 0; name < BUSTER_ARRAY_LENGTH(comparisons); name += 1)
    {
        (void)machine_x64_metadata_shape_cache_add(comparisons[name], &byte, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    }
    BusterX86MetadataPhysicalOperand truncate[] = {machine_x64_exact_gpr_operand(0, 32), machine_x64_exact_immediate_operand(0x0c00, 32)};
    (void)machine_x64_metadata_shape_cache_add(S8("OR"), truncate, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    BusterX86MetadataPhysicalOperand extend[] = {machine_x64_exact_gpr_operand(0, 64), byte};
    (void)machine_x64_metadata_shape_cache_add(S8("MOVZX"), extend, 2, (BusterX86MetadataFeatureInput){0}, attributes);
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_zero(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    (void)machine_x64_metadata_shape_cache_add(S8("CDQ"), 0, 0, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("CQO"), 0, 0, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("RET"), 0, 0, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("UD2"), 0, 0, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("CPUID"), 0, 0, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("NOP"), 0, 0, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("PAUSE"), 0, 0,
                                               (BusterX86MetadataFeatureInput){.names = machine_x64_pause_features,
                                                                                .count = BUSTER_ARRAY_LENGTH(machine_x64_pause_features)},
                                               attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("XGETBV"), 0, 0,
                                               (BusterX86MetadataFeatureInput){.names = machine_x64_xsave_features,
                                                                                .count = BUSTER_ARRAY_LENGTH(machine_x64_xsave_features)},
                                               attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("VZEROUPPER"), 0, 0,
                                               (BusterX86MetadataFeatureInput){.names = machine_x64_avx_features,
                                                                                .count = BUSTER_ARRAY_LENGTH(machine_x64_avx_features)},
                                               attributes);
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_unary(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    BusterX86MetadataPhysicalOperand operand = machine_x64_exact_gpr_operand(0, 64);
    (void)machine_x64_metadata_shape_cache_add(S8("PUSH"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("POP"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("CALL"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    operand.width = operand.reg.width = 32;
    (void)machine_x64_metadata_shape_cache_add(S8("DIV"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("IDIV"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    operand.width = operand.reg.width = 64;
    (void)machine_x64_metadata_shape_cache_add(S8("DIV"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("IDIV"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    // The one-operand MUL is the divides' sibling in every respect that
    // matters here -- same encoding group, same implicit RDX:RAX pair -- and
    // MACHINE_X64_MULH64 emits it for the high half of an i128 product. A
    // shape absent from this cache fails closed at encode rather than falling
    // back to handwritten bytes, so registering it is what makes the row
    // reachable at all.
    (void)machine_x64_metadata_shape_cache_add(S8("MUL"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    // Atomic NAND expansions complement the proposed value at its actual
    // width; prepare these shapes before the encoding workers start.
    for (u32 width_index = 0; width_index < 4; width_index += 1)
    {
        operand = machine_x64_exact_gpr_operand(0, (u16)(8u << width_index));
        (void)machine_x64_metadata_shape_cache_add(S8("NOT"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    }
    for (u32 register_index = 0; register_index < 16; register_index += 1)
    {
        operand = machine_x64_exact_gpr_operand(register_index, 64);
        (void)machine_x64_metadata_shape_cache_add(S8("JMP"), &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_registers(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    String8 binary_names[] = {S8("MOV"), S8("XOR"), S8("ADD"), S8("ADC"), S8("SUB"), S8("SBB"), S8("AND"), S8("OR")};
    u16 binary_widths[] = {8, 16, 32, 64};
    for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(binary_names); name_index += 1)
    {
        for (u32 width_index = 0; width_index < BUSTER_ARRAY_LENGTH(binary_widths); width_index += 1)
        {
            u16 width = binary_widths[width_index];
            BusterX86MetadataPhysicalOperand operands[2] = {
                machine_x64_exact_gpr_operand(0, width), machine_x64_exact_gpr_operand(1, width),
            };
            (void)machine_x64_metadata_shape_cache_add(binary_names[name_index], operands, 2,
                                                        (BusterX86MetadataFeatureInput){0}, attributes);
        }
    }
    u16 compare_widths[] = {32, 64};
    for (u32 width_index = 0; width_index < BUSTER_ARRAY_LENGTH(compare_widths); width_index += 1)
    {
        u16 width = compare_widths[width_index];
        BusterX86MetadataPhysicalOperand operands[2] = {
            machine_x64_exact_gpr_operand(0, width), machine_x64_exact_gpr_operand(1, width),
        };
        (void)machine_x64_metadata_shape_cache_add(S8("CMP"), operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
        (void)machine_x64_metadata_shape_cache_add(S8("TEST"), operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_immediates(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    BusterX86MetadataPhysicalOperand operands[2] = {0};
    String8 names[] = {S8("MOV"), S8("SUB"), S8("SHL"), S8("SHR"), S8("AND"), S8("CMP"), S8("ADD")};
    u16 register_widths[] = {32, 64};
    for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(names); name_index += 1)
    {
        for (u32 width_index = 0; width_index < BUSTER_ARRAY_LENGTH(register_widths); width_index += 1)
        {
            u16 register_width = register_widths[width_index];
            if (string_equal(names[name_index], S8("MOV")) && register_width != 32) continue;
            if ((string_equal(names[name_index], S8("SHL")) || string_equal(names[name_index], S8("SHR"))) && register_width != 64) continue;
            u16 immediate_widths[] = {8, 32};
            for (u32 immediate_width_index = 0; immediate_width_index < BUSTER_ARRAY_LENGTH(immediate_widths); immediate_width_index += 1)
            {
                u16 immediate_width = immediate_widths[immediate_width_index];
                if ((string_equal(names[name_index], S8("SHL")) || string_equal(names[name_index], S8("SHR"))) && immediate_width != 8) continue;
                operands[0] = machine_x64_exact_gpr_operand(0, register_width);
                // Keep the explicit-immediate SHR form in the prepared
                // cache.  A representative value of one selects XED's
                // shorter implicit `shr reg, 1` row, whose exact token has
                // no visible immediate operand and therefore cannot be
                // replayed through the two-operand machine bridge.  Values
                // one and two share the same signed-int8 shape class, so
                // workers still find this token for the runtime shift-by-one
                // expansion while retaining its explicit immediate field.
                s64 representative_immediate = (string_equal(names[name_index], S8("SHL")) || string_equal(names[name_index], S8("SHR"))) && immediate_width == 8
                                                   ? 2
                                                   : (immediate_width == 8 ? 1 : 128);
                operands[1] = machine_x64_exact_immediate_operand(representative_immediate, immediate_width);
                (void)machine_x64_metadata_shape_cache_add(names[name_index], operands, 2,
                                                            (BusterX86MetadataFeatureInput){0}, attributes);
                // A width-32 immediate that fits the signed eight-bit form
                // and one that does not are distinct metadata rows.
                if (immediate_width == 32)
                {
                    operands[1] = machine_x64_exact_immediate_operand(1, immediate_width);
                    (void)machine_x64_metadata_shape_cache_add(names[name_index], operands, 2,
                                                                (BusterX86MetadataFeatureInput){0}, attributes);
                    operands[1] = machine_x64_exact_immediate_operand(-1, immediate_width);
                    (void)machine_x64_metadata_shape_cache_add(names[name_index], operands, 2,
                                                                (BusterX86MetadataFeatureInput){0}, attributes);
                    operands[1] = machine_x64_exact_immediate_operand(-129, immediate_width);
                    (void)machine_x64_metadata_shape_cache_add(names[name_index], operands, 2,
                                                                (BusterX86MetadataFeatureInput){0}, attributes);
                }
            }
        }
    }
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_metadata_shape_memory(u32 base, u16 width, s64 displacement,
                                                                                         bool force_displacement)
{
    return machine_x64_exact_memory_operand(base, width, displacement, force_displacement);
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_memory(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    u16 widths[] = {8, 16, 32, 64};
    u32 bases[] = {MACHINE_X64_RAX, MACHINE_X64_RBP};
    s64 displacements[] = {0, 8, 256};
    for (u32 base_index = 0; base_index < BUSTER_ARRAY_LENGTH(bases); base_index += 1)
    {
        for (u32 width_index = 0; width_index < BUSTER_ARRAY_LENGTH(widths); width_index += 1)
        {
            u16 width = widths[width_index];
            for (u32 displacement_index = 0; displacement_index < BUSTER_ARRAY_LENGTH(displacements); displacement_index += 1)
            {
                s64 displacement = displacements[displacement_index];
                BusterX86MetadataPhysicalOperand operands[2] = {
                    machine_x64_exact_gpr_operand(0, 64), machine_x64_metadata_shape_memory(bases[base_index], width, displacement, displacement != 0),
                };
                if (width >= 32)
                {
                    (void)machine_x64_metadata_shape_cache_add(S8("MOV"), operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
                }
                (void)machine_x64_metadata_shape_cache_add(S8("LEA"), operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
                if (width == 32)
                {
                    operands[0] = machine_x64_exact_gpr_operand(0, 32);
                    (void)machine_x64_metadata_shape_cache_add(S8("MOV"), operands, 2,
                                                                (BusterX86MetadataFeatureInput){0}, attributes);
                    operands[0] = machine_x64_exact_gpr_operand(0, 64);
                }
                if (width == 8 || width == 16)
                {
                    (void)machine_x64_metadata_shape_cache_add(S8("MOVZX"), operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
                }
                operands[0] = operands[1];
                operands[1] = machine_x64_exact_gpr_operand(0, width);
                (void)machine_x64_metadata_shape_cache_add(S8("MOV"), operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
            }
        }
    }
    BusterX86MetadataPhysicalOperand test_operands[2] = {
        machine_x64_exact_memory_operand(MACHINE_X64_RSP, 8, 0, false), machine_x64_exact_immediate_operand(0, 8),
    };
    (void)machine_x64_metadata_shape_cache_add(S8("TEST"), test_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    BusterX86MetadataPhysicalOperand fs_operands[2] = {
        machine_x64_exact_gpr_operand(0, 64),
        {
            .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
            .width = 64,
            .memory = {.displacement = 0, .address_size = 64, .scale = 1, .has_displacement = true,
                       .segment = BUSTER_X86_METADATA_SEGMENT_FS, .has_segment = true},
        },
    };
    (void)machine_x64_metadata_shape_cache_add(S8("MOV"), fs_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    BusterX86MetadataPhysicalOperand rip_operands[2] = {
        machine_x64_exact_gpr_operand(0, 64), machine_x64_exact_rip_memory_operand(),
    };
    for (u32 register_index = 0; register_index < 16; register_index += 1)
    {
        rip_operands[0] = machine_x64_exact_gpr_operand(register_index, 64);
        (void)machine_x64_metadata_shape_cache_add(S8("LEA"), rip_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    }
    // Initial-exec TLS adds the GOT offset; PIC symbols load a GOT pointer.
    (void)machine_x64_metadata_shape_cache_add(S8("MOV"), rip_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("ADD"), rip_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    // Windows uses the module's 32-bit index and GS-relative TLS array;
    // Darwin calls the resolver pointer loaded from its descriptor.
    rip_operands[0] = machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 32);
    rip_operands[1].width = 32;
    (void)machine_x64_metadata_shape_cache_add(S8("MOV"), rip_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    fs_operands[1].memory.segment = BUSTER_X86_METADATA_SEGMENT_GS;
    fs_operands[1].memory.displacement = 0x58;
    (void)machine_x64_metadata_shape_cache_add(S8("MOV"), fs_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    BusterX86MetadataPhysicalOperand indexed_memory = machine_x64_exact_memory_operand(MACHINE_X64_RDX, 64, 0, false);
    indexed_memory.memory.has_index = true;
    indexed_memory.memory.index = machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 64).reg;
    indexed_memory.memory.scale = 8;
    BusterX86MetadataPhysicalOperand indexed_operands[] = {machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 64), indexed_memory};
    (void)machine_x64_metadata_shape_cache_add(S8("MOV"), indexed_operands, 2, (BusterX86MetadataFeatureInput){0}, attributes);
    BusterX86MetadataPhysicalOperand call_memory = machine_x64_exact_memory_operand(MACHINE_X64_RDI, 64, 0, false);
    (void)machine_x64_metadata_shape_cache_add(S8("CALL"), &call_memory, 1, (BusterX86MetadataFeatureInput){0}, attributes);
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_relative(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    String8 names[] = {S8("CALL"), S8("JMP"), S8("JNS"), S8("JB"), S8("JNBE"), S8("JNZ"), S8("JZ")};
    u16 widths[] = {8, 32};
    for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(names); name_index += 1)
    {
        for (u32 width_index = 0; width_index < BUSTER_ARRAY_LENGTH(widths); width_index += 1)
        {
            if (string_equal(names[name_index], S8("CALL")) && widths[width_index] != 32) continue;
            if (string_equal(names[name_index], S8("JNS")) && widths[width_index] != 8) continue;
            if (string_equal(names[name_index], S8("JB")) && widths[width_index] != 8) continue;
            if (string_equal(names[name_index], S8("JNBE")) && widths[width_index] != 32) continue;
            if (string_equal(names[name_index], S8("JNZ")) && widths[width_index] != 32) continue;
            if (string_equal(names[name_index], S8("JZ")) && widths[width_index] != 32) continue;
            BusterX86MetadataPhysicalOperand operand = machine_x64_exact_relative_operand(0, widths[width_index]);
            (void)machine_x64_metadata_shape_cache_add(names[name_index], &operand, 1, (BusterX86MetadataFeatureInput){0}, attributes);
        }
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prepare_float_vector_atomic(void)
{
    BusterX86MetadataPhysicalAttributes attributes = {0};
    BusterX86MetadataFeatureInput sse = {.names = machine_x64_sse_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_sse_features)};
    BusterX86MetadataFeatureInput sse2 = {.names = machine_x64_sse2_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features)};
    BusterX86MetadataFeatureInput avx512 = {.names = machine_x64_avx512_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_avx512_features)};
    BusterX86MetadataFeatureInput cx16 = {.names = machine_x64_cx16_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_cx16_features)};
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_xmm_operand(0, 128), machine_x64_exact_gpr_operand(0, 64),
    };
    (void)machine_x64_metadata_shape_cache_add(S8("MOVQ"), operands, 2, sse2, attributes);
    operands[0] = machine_x64_exact_xmm_operand(0, 64);
    (void)machine_x64_metadata_shape_cache_add(S8("MOVQ"), operands, 2, sse2, attributes);
    operands[0] = machine_x64_exact_xmm_operand(0, 32);
    (void)machine_x64_metadata_shape_cache_add(S8("CVTSI2SS"), operands, 2, sse, attributes);
    operands[0] = machine_x64_exact_xmm_operand(0, 64);
    (void)machine_x64_metadata_shape_cache_add(S8("CVTSI2SD"), operands, 2, sse2, attributes);

    operands[0] = machine_x64_exact_gpr_operand(0, 64);
    operands[1] = machine_x64_exact_xmm_operand(0, 128);
    (void)machine_x64_metadata_shape_cache_add(S8("MOVQ"), operands, 2, sse2, attributes);
    operands[1] = machine_x64_exact_xmm_operand(0, 32);
    (void)machine_x64_metadata_shape_cache_add(S8("CVTTSS2SI"), operands, 2, sse, attributes);
    operands[1] = machine_x64_exact_xmm_operand(0, 64);
    (void)machine_x64_metadata_shape_cache_add(S8("CVTTSD2SI"), operands, 2, sse2, attributes);
    operands[1] = machine_x64_exact_xmm_operand(0, 128);
    (void)machine_x64_metadata_shape_cache_add(S8("CVTTSS2SI"), operands, 2, sse, attributes);
    (void)machine_x64_metadata_shape_cache_add(S8("CVTTSD2SI"), operands, 2, sse2, attributes);

    String8 scalar_names[] = {S8("ADDSS"), S8("ADDSD"), S8("SUBSS"), S8("SUBSD"), S8("UCOMISS"), S8("UCOMISD")};
    for (u32 name_index = 0; name_index < BUSTER_ARRAY_LENGTH(scalar_names); name_index += 1)
    {
        bool double_width = string_ends_with_sequence(scalar_names[name_index], S8("SD"));
        BusterX86MetadataFeatureInput feature = double_width ? sse2 : sse;
        BusterX86MetadataPhysicalOperand scalar_operands[2] = {
            machine_x64_exact_xmm_operand(0, double_width ? 64 : 32), machine_x64_exact_xmm_operand(1, double_width ? 64 : 32),
        };
        (void)machine_x64_metadata_shape_cache_add(scalar_names[name_index], scalar_operands, 2, feature, attributes);
    }
    for (u32 displacement_index = 0; displacement_index < 3; displacement_index += 1)
    {
        s64 displacement = displacement_index == 0 ? 0 : displacement_index == 1 ? 8 : 256;
        BusterX86MetadataPhysicalOperand memory_operand = machine_x64_exact_memory_operand(MACHINE_X64_RBP, 64, displacement, displacement != 0);
        BusterX86MetadataPhysicalOperand xmm_operand = machine_x64_exact_xmm_operand(0, 64);
        BusterX86MetadataPhysicalOperand memory_operands[2] = {xmm_operand, memory_operand};
        (void)machine_x64_metadata_shape_cache_add(S8("MOVSD"), memory_operands, 2, sse2, attributes);
        memory_operands[0] = memory_operand;
        memory_operands[1] = xmm_operand;
        (void)machine_x64_metadata_shape_cache_add(S8("MOVSD"), memory_operands, 2, sse2, attributes);
        memory_operand.width = 128;
        xmm_operand = machine_x64_exact_xmm_operand(0, 128);
        memory_operands[0] = xmm_operand;
        memory_operands[1] = memory_operand;
        (void)machine_x64_metadata_shape_cache_add(S8("MOVDQU"), memory_operands, 2, sse2, attributes);
        memory_operands[0] = memory_operand;
        memory_operands[1] = xmm_operand;
        (void)machine_x64_metadata_shape_cache_add(S8("MOVDQU"), memory_operands, 2, sse2, attributes);
        memory_operand.width = 256;
        BusterX86MetadataPhysicalOperand ymm_operand = machine_x64_exact_ymm_operand(0);
        BusterX86MetadataFeatureInput avx = {.names = machine_x64_avx_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_avx_features)};
        memory_operands[0] = ymm_operand;
        memory_operands[1] = memory_operand;
        (void)machine_x64_metadata_shape_cache_add(S8("VMOVDQU"), memory_operands, 2, avx, attributes);
        memory_operands[0] = memory_operand;
        memory_operands[1] = ymm_operand;
        (void)machine_x64_metadata_shape_cache_add(S8("VMOVDQU"), memory_operands, 2, avx, attributes);
        BusterX86MetadataPhysicalOperand zmm_operand = machine_x64_exact_zmm_operand(0, 512);
        memory_operand.width = 8;
        BusterX86MetadataPhysicalOperand vector_operands[2] = {zmm_operand, memory_operand};
        (void)machine_x64_metadata_shape_cache_add(S8("VMOVDQU8"), vector_operands, 2, avx512, attributes);
        vector_operands[0] = memory_operand;
        vector_operands[1] = zmm_operand;
        (void)machine_x64_metadata_shape_cache_add(S8("VMOVDQU8"), vector_operands, 2, avx512, attributes);
    }
    BusterX86MetadataPhysicalOperand vector_registers[2] = {
        machine_x64_exact_zmm_operand(0, 512), machine_x64_exact_zmm_operand(1, 512),
    };
    (void)machine_x64_metadata_shape_cache_add(S8("VMOVDQU8"), vector_registers, 2, avx512, attributes);

    attributes.lock = true;
    for (u32 width_index = 0; width_index < 4; width_index += 1)
    {
        u16 width = (u16)(8u << width_index);
        BusterX86MetadataPhysicalOperand atomic_operands[2] = {
            machine_x64_exact_memory_operand(MACHINE_X64_RCX, width, 0, false), machine_x64_exact_gpr_operand(0, width),
        };
        (void)machine_x64_metadata_shape_cache_add(S8("CMPXCHG"), atomic_operands, 2,
                                                    (BusterX86MetadataFeatureInput){0}, attributes);
    }
    BusterX86MetadataPhysicalOperand cmpxchg16_operand = machine_x64_exact_memory_operand(MACHINE_X64_RCX, 128, 0, false);
    (void)machine_x64_metadata_shape_cache_add(S8("CMPXCHG16B"), &cmpxchg16_operand, 1, cx16, attributes);
}

BUSTER_GLOBAL_LOCAL void machine_x64_metadata_shape_cache_prewarm(void)
{
    if (machine_x64_metadata_shape_cache_ready) return;
    machine_x64_metadata_shape_cache_count = 0;
    machine_x64_metadata_shape_cache_invalid_count = 0;
    machine_x64_metadata_shape_cache_prepare_zero();
    machine_x64_metadata_shape_cache_prepare_predicates();
    machine_x64_metadata_shape_cache_prepare_unary();
    machine_x64_metadata_shape_cache_prepare_registers();
    machine_x64_metadata_shape_cache_prepare_immediates();
    machine_x64_metadata_shape_cache_prepare_memory();
    machine_x64_metadata_shape_cache_prepare_relative();
    machine_x64_metadata_shape_cache_prepare_float_vector_atomic();
    machine_x64_metadata_shape_cache_prepare_x87();
    machine_x64_metadata_shape_cache_publish_slots();
    machine_x64_metadata_shape_cache_ready = machine_x64_metadata_shape_cache_invalid_count == 0;
}

#if BUSTER_INCLUDE_TESTS
MachineX64MetadataShapeCacheAudit machine_x86_64_metadata_shape_cache_audit(void)
{
    machine_x86_64_exact_prewarm();
    return (MachineX64MetadataShapeCacheAudit){
        .prepared_rows = machine_x64_metadata_shape_cache_count,
        .invalid_rows = machine_x64_metadata_shape_cache_invalid_count,
        .valid = machine_x64_metadata_shape_cache_ready && machine_x64_metadata_shape_cache_count != 0 &&
                 machine_x64_metadata_shape_cache_invalid_count == 0,
    };
}
#endif

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_exact_form(MachineX64Encoder* encoder,
                                                     BusterX86MetadataMachineExactToken metadata_token,
                                                     BusterX86MetadataPhysicalOperand const* operands, u32 operand_count,
                                                     bool force_disp32,
                                                     bool force_lock, u8 mask_register_plus_one, bool zeroing,
                                                     MachineX64ExactEmitCounters* counters)
{
    if (counters) counters->attempts += 1;
    // The metadata bridge writes only after all dynamic validation and
    // capacity checks succeed.  Point it at the final encoder storage so the
    // machine path does not copy through a second 16-byte staging buffer.
    // Guard the subtraction and pointer formation first: an already-overflowed
    // encoder must fail closed without forming an out-of-range destination.
    if (encoder->count > encoder->capacity)
    {
        encoder->overflow = true;
        if (counters) counters->fallbacks += 1;
        return false;
    }
    u32 output_capacity = encoder->capacity - encoder->count;
    if (output_capacity > 16u) output_capacity = 16u;
    u8* output = encoder->bytes + encoder->count;
    BusterX86MetadataPhysicalOperand rebased_operands[4];
    if (encoder->frame_base_offset)
    {
        BUSTER_CHECK(operand_count <= BUSTER_ARRAY_LENGTH(rebased_operands));
        for (u32 index = 0; index < operand_count; index += 1)
        {
            rebased_operands[index] = operands[index];
            if (operands[index].kind == BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY && operands[index].memory.has_base &&
                operands[index].memory.base.index == MACHINE_X64_RBP)
            {
                rebased_operands[index].memory.displacement += encoder->frame_base_offset;
                rebased_operands[index].memory.has_displacement = true;
            }
        }
        operands = rebased_operands;
    }
    BusterX86MetadataEmitResult emitted = buster_x86_metadata_emit_exact_machine(metadata_token, (BusterX86MetadataMachineExactQuery){
        .operands = operands,
        .operand_count = operand_count,
        .force_disp32 = force_disp32,
        .force_lock = force_lock,
        .mask_register_plus_one = mask_register_plus_one,
        .zeroing = zeroing,
        .output = output,
        .output_capacity = output_capacity,
        .relocations = 0,
        .relocation_capacity = 0,
    });
    if (emitted.status != BUSTER_X86_METADATA_ENCODE_SUCCESS || emitted.relocation_count != 0 ||
        emitted.byte_count > 16u || emitted.byte_count > output_capacity)
    {
        encoder->overflow = true;
        if (counters) counters->fallbacks += 1;
        return false;
    }
    encoder->count += emitted.byte_count;
    if (counters) counters->successes += 1;
    return true;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_exact_reject(MachineX64Encoder* encoder, MachineX64ExactEmitCounters* counters);

// Expansion rows are architectural sequences rather than one MIR opcode.
// Keep their individual instructions in the same metadata path as ordinary
// exact rows: select one durable form from the physical shape, then immediately
// re-emit that selected form through the exact-form transform.  The selection
// is deliberately local to the sequence helper (there is no callback or raw
// byte template hidden behind it); callers only provide the mnemonic and the
// already-typed physical operands.  Relative/TLS fields are passed as their
// neutral zero values and remain owned by the fixup/call-site stream.
BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_instruction(MachineX64Encoder* encoder, String8 mnemonic,
                                                              BusterX86MetadataPhysicalOperand const* operands, u32 operand_count,
                                                              BusterX86MetadataFeatureInput features,
                                                              BusterX86MetadataPhysicalAttributes attributes,
                                                              MachineX64ExactEmitCounters* counters)
{
    // Scalar SSE/SSE2 forms are real feature-gated metadata rows.  Callers
    // that use the generic mnemonic bridge intentionally omit a feature list;
    // derive the architectural requirement here so selection cannot silently
    // reject an otherwise valid exact instruction as a feature-mode miss.
    if (!features.count)
    {
        if (string_equal(mnemonic, S8("CVTSI2SS")) || string_equal(mnemonic, S8("ADDSS")) || string_equal(mnemonic, S8("UCOMISS")) ||
            string_equal(mnemonic, S8("SUBSS")) || string_equal(mnemonic, S8("CVTTSS2SI")) || string_equal(mnemonic, S8("MOVSS")))
        {
            features.names = machine_x64_sse_features;
            features.count = BUSTER_ARRAY_LENGTH(machine_x64_sse_features);
        }
        else if (string_equal(mnemonic, S8("CVTSI2SD")) || string_equal(mnemonic, S8("ADDSD")) || string_equal(mnemonic, S8("UCOMISD")) ||
                 string_equal(mnemonic, S8("SUBSD")) || string_equal(mnemonic, S8("CVTTSD2SI")) || string_equal(mnemonic, S8("MOVQ")) ||
                 string_equal(mnemonic, S8("MOVSD")) || string_equal(mnemonic, S8("MOVDQU")))
        {
            features.names = machine_x64_sse2_features;
            features.count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features);
        }
    }
    // Workers never re-enter the generic selector.  The serial prewarm lane
    // populated one immutable token per finite physical shape; a stale or
    // unclassified shape fails closed instead of falling back to handwritten
    // bytes or a checked query lookup.
    if (!machine_x64_metadata_shape_cache_ready)
    {
        return machine_x64_exact_reject(encoder, counters);
    }
    BusterX86MetadataMachineExactToken const* token = machine_x64_metadata_shape_cache_find(mnemonic, operands, operand_count, features, attributes);
    bool result;
    if (!token)
    {
        result = machine_x64_exact_reject(encoder, counters);
    }
    else
    {
        result = machine_x64_emit_exact_form(encoder, *token, operands, operand_count, false, attributes.lock, 0, false, counters);
    }

    return result;
}

BUSTER_GLOBAL_LOCAL MachineX64PreparedExactOpcode const* machine_x64_exact_opcode_for_opcode(u16 opcode);

BUSTER_GLOBAL_LOCAL bool machine_x64_exact_reject(MachineX64Encoder* encoder, MachineX64ExactEmitCounters* counters)
{
    // These exact wrappers are used by spill/reload and expansion paths whose
    // callers intentionally ignore the bool result.  Keep a stale or missing
    // prepared row from silently deleting an instruction.
    encoder->overflow = true;
    if (counters)
    {
        counters->attempts += 1;
        counters->fallbacks += 1;
    }
    return false;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_registers(MachineX64Encoder* encoder, String8 mnemonic, u32 destination, u32 source,
                                                             u16 width, MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_gpr_operand(destination, width),
        machine_x64_exact_gpr_operand(source, width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_register(MachineX64Encoder* encoder, String8 mnemonic, u32 reg, u16 width,
                                                            MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operand = machine_x64_exact_gpr_operand(reg, width);
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, &operand, 1, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_register_immediate(MachineX64Encoder* encoder, String8 mnemonic, u32 destination,
                                                                      u64 immediate, u16 register_width, u16 immediate_width,
                                                                      MachineX64ExactEmitCounters* counters)
{
    // A full-width 32-bit immediate is a bit pattern. The exact bridge's
    // signed operand must retain its high bit without widening its value.
    // Keep narrower immediates and 64-bit destinations sign-extension aware.
    s64 value = register_width == 32 && immediate_width == 32 ? (s64)(s32)(u32)immediate : (s64)immediate;
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_gpr_operand(destination, register_width),
        machine_x64_exact_immediate_operand(value, immediate_width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_register_memory(MachineX64Encoder* encoder, String8 mnemonic, u32 destination, u32 base,
                                                                   s64 displacement, u16 register_width, u16 memory_width,
                                                                   MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_gpr_operand(destination, register_width),
        machine_x64_exact_memory_operand(base, memory_width, displacement, displacement != 0),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_memory_register(MachineX64Encoder* encoder, String8 mnemonic, u32 base, s64 displacement,
                                                                   u32 source, u16 memory_width, u16 register_width,
                                                                   MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_memory_operand(base, memory_width, displacement, displacement != 0),
        machine_x64_exact_gpr_operand(source, register_width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_atomic_memory_register(MachineX64Encoder* encoder, String8 mnemonic, u32 base, u32 source,
                                                                         u16 width, MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_memory_operand(base, width, 0, false),
        machine_x64_exact_gpr_operand(source, width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){.lock = true}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_atomic_memory(MachineX64Encoder* encoder, String8 mnemonic, u32 base, u16 width,
                                                                 MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operand = machine_x64_exact_memory_operand(base, width, 0, false);
    BusterX86MetadataFeatureInput features = {0};
    if (string_equal(mnemonic, S8("CMPXCHG16B")))
    {
        features.names = machine_x64_cx16_features;
        features.count = BUSTER_ARRAY_LENGTH(machine_x64_cx16_features);
    }
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, &operand, 1, features,
                                                 (BusterX86MetadataPhysicalAttributes){.lock = true}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_relative(MachineX64Encoder* encoder, String8 mnemonic, s64 displacement, u16 width,
                                                            MachineX64ExactEmitCounters* counters)
{
    // The metadata snapshot uses one canonical spelling per condition-code
    // opcode.  JA/JNE are architectural aliases of JNBE/JNZ, respectively;
    // route those spellings through the canonical metadata rows while the
    // caller continues to express the branch semantics naturally.
    String8 metadata_mnemonic = mnemonic;
    if (string_equal(mnemonic, S8("JA"))) metadata_mnemonic = S8("JNBE");
    else if (string_equal(mnemonic, S8("JNE"))) metadata_mnemonic = S8("JNZ");
    BusterX86MetadataPhysicalOperand operand = machine_x64_exact_relative_operand(displacement, width);
    return machine_x64_emit_metadata_instruction(encoder, metadata_mnemonic, &operand, 1, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_memory_immediate(MachineX64Encoder* encoder, String8 mnemonic, u32 base, s64 displacement,
                                                                    u64 immediate, u16 memory_width, u16 immediate_width,
                                                                    MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_memory_operand(base, memory_width, displacement, displacement != 0),
        machine_x64_exact_immediate_operand((s64)immediate, immediate_width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL BusterX86MetadataPhysicalOperand machine_x64_exact_zmm_operand(u32 reg, u16 width)
{
    return (BusterX86MetadataPhysicalOperand){
        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
        .width = width,
        .reg = {
            .index = (u16)reg,
            .width = width,
            .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM,
        },
    };
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_zmm_registers(MachineX64Encoder* encoder, String8 mnemonic, u32 destination, u32 source,
                                                                 u16 width, BusterX86MetadataFeatureInput features,
                                                                 MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_zmm_operand(destination, width),
        machine_x64_exact_zmm_operand(source, width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, features,
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_zmm_memory(MachineX64Encoder* encoder, String8 mnemonic, u32 zmm, u32 base, s64 displacement,
                                                              bool store, u16 vector_width, u16 memory_width, BusterX86MetadataFeatureInput features,
                                                              MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {0};
    BusterX86MetadataPhysicalOperand memory = machine_x64_exact_memory_operand(base, memory_width, displacement, displacement != 0);
    BusterX86MetadataPhysicalOperand vector = machine_x64_exact_zmm_operand(zmm, vector_width);
    operands[0] = store ? memory : vector;
    operands[1] = store ? vector : memory;
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, features,
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_xmm_gpr(MachineX64Encoder* encoder, String8 mnemonic, u32 xmm, u32 gpr, u16 xmm_width,
                                                           u16 gpr_width, MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_xmm_operand(xmm, xmm_width),
        machine_x64_exact_gpr_operand(gpr, gpr_width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_gpr_xmm(MachineX64Encoder* encoder, String8 mnemonic, u32 gpr, u32 xmm, u16 gpr_width,
                                                           u16 xmm_width, MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_gpr_operand(gpr, gpr_width),
        machine_x64_exact_xmm_operand(xmm, xmm_width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_xmm_registers(MachineX64Encoder* encoder, String8 mnemonic, u32 destination, u32 source,
                                                                 u16 width, MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {
        machine_x64_exact_xmm_operand(destination, width),
        machine_x64_exact_xmm_operand(source, width),
    };
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_xmm_memory(MachineX64Encoder* encoder, String8 mnemonic, u32 xmm, u32 base, s64 displacement,
                                                              bool store, u16 width, MachineX64ExactEmitCounters* counters)
{
    BusterX86MetadataPhysicalOperand operands[2] = {0};
    BusterX86MetadataPhysicalOperand memory = machine_x64_exact_memory_operand(base, width, displacement, displacement != 0);
    BusterX86MetadataPhysicalOperand vector = machine_x64_exact_xmm_operand(xmm, width);
    operands[0] = store ? memory : vector;
    operands[1] = store ? vector : memory;
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                 (BusterX86MetadataPhysicalAttributes){0}, counters);
}

// Fixed-template publication.  Everything below runs on the serial prewarm
// lane after the shape cache and the opcode map are staged; the bridge
// shapes are encoded through the same wrappers the encoder sites use, and
// recipe/sequence rows through the same exact-form call, so a template is
// byte-for-byte what the lane it replaces would have written.

BUSTER_GLOBAL_LOCAL MachineX64Encoder machine_x64_fixed_template_scratch(u8* bytes)
{
    return (MachineX64Encoder){.bytes = bytes, .capacity = 16};
}

BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_static_fixed_templates(void)
{
    u8 scratch_bytes[16];
    u8 probe_bytes[16];
    MachineX64Encoder scratch;
    MachineX64Encoder probe;
    BusterX86MetadataFeatureInput no_features = {0};
    BusterX86MetadataFeatureInput avx = {.names = machine_x64_avx_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_avx_features)};
    BusterX86MetadataPhysicalAttributes attributes = {0};
    for (u32 reg = 0; reg < 16; reg += 1)
    {
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_register(&scratch, S8("PUSH"), reg, 64, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_PUSH + reg, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_register(&scratch, S8("POP"), reg, 64, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_POP + reg, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_register(&scratch, S8("CALL"), reg, 64, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_CALL_REGISTER + reg, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_register(&scratch, S8("JMP"), reg, 64, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_JMP_REGISTER + reg, &scratch, 0);
        BusterX86MetadataPhysicalOperand rip_operands[2] = {
            machine_x64_exact_gpr_operand(reg, 64), machine_x64_exact_rip_memory_operand(),
        };
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_instruction(&scratch, S8("LEA"), rip_operands, 2, no_features, attributes, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_LEA_RIP + reg, &scratch, 0);
        // The case-value move is proven for both non-negative classes the
        // chain passes: a byte and a full 32-bit value.
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_register_immediate(&scratch, S8("MOV"), reg, 0, 32, 32, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_MOV_R32_IMM32 + reg, &scratch, 4);
        probe = machine_x64_fixed_template_scratch(probe_bytes);
        (void)machine_x64_emit_metadata_register_immediate(&probe, S8("MOV"), reg, 0x5a, 32, 32, 0);
        machine_x64_fixed_template_prove(MACHINE_X64_FIXED_TEMPLATE_MOV_R32_IMM32 + reg, &probe, 0x5a);
        probe = machine_x64_fixed_template_scratch(probe_bytes);
        (void)machine_x64_emit_metadata_register_immediate(&probe, S8("MOV"), reg, UINT64_C(0x5aa55aa5), 32, 32, 0);
        machine_x64_fixed_template_prove(MACHINE_X64_FIXED_TEMPLATE_MOV_R32_IMM32 + reg, &probe, UINT64_C(0x5aa55aa5));
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_registers(&scratch, S8("CMP"), MACHINE_X64_RCX, reg, 32, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_CMP32_RCX + reg, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_registers(&scratch, S8("CMP"), MACHINE_X64_RCX, reg, 64, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_CMP64_RCX + reg, &scratch, 0);
    }
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_registers(&scratch, S8("CMP"), MACHINE_X64_RAX, MACHINE_X64_RCX, 32, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_CMP32_RAX_RCX, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_registers(&scratch, S8("CMP"), MACHINE_X64_RAX, MACHINE_X64_RCX, 64, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_CMP64_RAX_RCX, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_registers(&scratch, S8("MOV"), MACHINE_X64_RBP, MACHINE_X64_RSP, 64, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_MOV_RBP_RSP, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_registers(&scratch, S8("MOV"), MACHINE_X64_RSP, MACHINE_X64_RBP, 64, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_MOV_RSP_RBP, &scratch, 0);

    // The patched rows: publish a representative of the value class the
    // site passes, then prove a second value of the same class moves only
    // the trailing field.
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_register_immediate(&scratch, S8("SUB"), MACHINE_X64_RSP, 16, 64, 8, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM8, &scratch, 1);
    probe = machine_x64_fixed_template_scratch(probe_bytes);
    (void)machine_x64_emit_metadata_register_immediate(&probe, S8("SUB"), MACHINE_X64_RSP, 0x5a, 64, 8, 0);
    machine_x64_fixed_template_prove(MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM8, &probe, 0x5a);

    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_register_immediate(&scratch, S8("SUB"), MACHINE_X64_RSP, 4096, 64, 32, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM32, &scratch, 4);
    probe = machine_x64_fixed_template_scratch(probe_bytes);
    (void)machine_x64_emit_metadata_register_immediate(&probe, S8("SUB"), MACHINE_X64_RSP, UINT64_C(0x5aa55aa5), 64, 32, 0);
    machine_x64_fixed_template_prove(MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM32, &probe, UINT64_C(0x5aa55aa5));

    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_memory_immediate(&scratch, S8("TEST"), MACHINE_X64_RSP, 0, 0, 8, 8, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_PROBE, &scratch, 0);

    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_register_memory(&scratch, S8("LEA"), MACHINE_X64_RSP, MACHINE_X64_RBP, -8, 64, 64, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_LEA_RSP_RBP_DISP8, &scratch, 1);
    probe = machine_x64_fixed_template_scratch(probe_bytes);
    (void)machine_x64_emit_metadata_register_memory(&probe, S8("LEA"), MACHINE_X64_RSP, MACHINE_X64_RBP, -0x5b, 64, 64, 0);
    machine_x64_fixed_template_prove(MACHINE_X64_FIXED_TEMPLATE_LEA_RSP_RBP_DISP8, &probe, (u8)(-0x5b));

    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_register_immediate(&scratch, S8("MOV"), MACHINE_X64_RAX, 0, 32, 32, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_MOV_EAX_IMM32, &scratch, 4);
    probe = machine_x64_fixed_template_scratch(probe_bytes);
    (void)machine_x64_emit_metadata_register_immediate(&probe, S8("MOV"), MACHINE_X64_RAX, 0x5a, 32, 32, 0);
    machine_x64_fixed_template_prove(MACHINE_X64_FIXED_TEMPLATE_MOV_EAX_IMM32, &probe, 0x5a);

    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_instruction(&scratch, S8("RET"), 0, 0, no_features, attributes, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_RET, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_relative(&scratch, S8("CALL"), 0, 32, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_CALL_REL32, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_relative(&scratch, S8("JMP"), 0, 32, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_JMP_REL32, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_relative(&scratch, S8("JZ"), 0, 32, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_JZ_REL32, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_instruction(&scratch, S8("VZEROUPPER"), 0, 0, avx, attributes, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_VZEROUPPER, &scratch, 0);
    scratch = machine_x64_fixed_template_scratch(scratch_bytes);
    (void)machine_x64_emit_metadata_instruction(&scratch, S8("UD2"), 0, 0, no_features, attributes, 0);
    machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_UD2, &scratch, 0);

    for (u32 width_row = 0; width_row < 2; width_row += 1)
    {
        u16 width = width_row ? 64 : 32;
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_registers(&scratch, S8("XOR"), MACHINE_X64_RDX, MACHINE_X64_RDX, width, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_XOR_RDX_RDX + width_row, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_register(&scratch, S8("DIV"), MACHINE_X64_RCX, width, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_DIV_RCX + width_row, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_register(&scratch, S8("IDIV"), MACHINE_X64_RCX, width, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_IDIV_RCX + width_row, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_instruction(&scratch, width_row ? S8("CQO") : S8("CDQ"), 0, 0, no_features, attributes, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_CDQ_CQO + width_row, &scratch, 0);
        scratch = machine_x64_fixed_template_scratch(scratch_bytes);
        (void)machine_x64_emit_metadata_registers(&scratch, S8("MOV"), MACHINE_X64_RAX, MACHINE_X64_RDX, width, 0);
        machine_x64_fixed_template_publish(MACHINE_X64_FIXED_TEMPLATE_MOV_RAX_RDX + width_row, &scratch, 0);
    }
}

// Projects one fixed operand kind the way the recipe tail (or, with
// `sequence`, the sequence step loop) projects it, so a template row is the
// encoding that lane would have requested.  A kind the lane does not accept
// is not fixed here either, whatever its name suggests.
BUSTER_GLOBAL_LOCAL bool machine_x64_fixed_template_operand(u8 kind, u16 width, u32 reg, bool sequence,
                                                            BusterX86MetadataPhysicalOperand* operand)
{
    bool result = true;
    switch ((MachineX64ExactOperandProjection)kind)
    {
    case MACHINE_X64_EXACT_OPERAND_GPR:
        *operand = machine_x64_exact_gpr_operand(reg, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX:
        *operand = machine_x64_exact_gpr_operand(MACHINE_X64_RAX, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX:
        *operand = machine_x64_exact_gpr_operand(MACHINE_X64_RDX, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_FIXED_RSP:
        *operand = machine_x64_exact_gpr_operand(MACHINE_X64_RSP, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_XMM_FIXED0:
        result = sequence;
        *operand = machine_x64_exact_xmm_operand(0, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_XMM_FIXED1:
        result = sequence;
        *operand = machine_x64_exact_xmm_operand(1, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K0:
        result = sequence;
        *operand = (BusterX86MetadataPhysicalOperand){
            .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = 64,
            .reg = {.index = 0, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_MASK}};
        break;
    case MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1:
        *operand = (BusterX86MetadataPhysicalOperand){
            .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = 64,
            .reg = {.index = 1, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_MASK}};
        break;
    case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_LESS:
        *operand = machine_x64_exact_unsigned_immediate_operand(1, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_RELATIVE_ZERO:
        *operand = machine_x64_exact_relative_operand(0, width);
        break;
    case MACHINE_X64_EXACT_OPERAND_RIP_MEMORY_ZERO:
        result = !sequence;
        *operand = machine_x64_exact_rip_memory_operand();
        break;
    default:
        result = false;
        break;
    }
    return result;
}

// Allots and publishes the template rows of one recipe variant or sequence
// step whose operands are all fixed: one row, or sixteen when one operand is
// a general register, whose slot is returned through `family_slot`.  Returns
// the one-based first row, or zero when the shape has a dynamic operand or
// no room is left.  Rows the token refuses stay unpublished individually.
BUSTER_GLOBAL_LOCAL u16 machine_x64_exact_prepare_fixed_template_family(
    u8 const* operand_kinds, u8 const* operand_slots, u16 const* operand_widths, u32 operand_count,
    bool sequence, bool force_disp32, bool force_lock, u8 mask_register_plus_one, bool zeroing,
    BusterX86MetadataMachineExactToken token, u8* family_slot)
{
    u16 result = 0;
    u8 gpr_slot = MACHINE_X64_FIXED_TEMPLATE_NO_SLOT;
    bool fixed = operand_count <= 4;
    for (u32 operand_index = 0; fixed && operand_index < operand_count; operand_index += 1)
    {
        u8 kind = operand_kinds[operand_index];
        if (kind == MACHINE_X64_EXACT_OPERAND_GPR)
        {
            fixed = gpr_slot == MACHINE_X64_FIXED_TEMPLATE_NO_SLOT && operand_slots[operand_index] < 4;
            gpr_slot = operand_slots[operand_index];
        }
        else
        {
            BusterX86MetadataPhysicalOperand projected;
            fixed = machine_x64_fixed_template_operand(kind, operand_widths[operand_index], 0, sequence, &projected);
        }
    }
    u32 row_count = gpr_slot == MACHINE_X64_FIXED_TEMPLATE_NO_SLOT ? 1u : 16u;
    if (fixed && machine_x64_fixed_template_count + row_count <= MACHINE_X64_FIXED_TEMPLATE_CAPACITY)
    {
        u32 first_row = machine_x64_fixed_template_count;
        for (u32 row = 0; row < row_count; row += 1)
        {
            BusterX86MetadataPhysicalOperand operands[4];
            for (u32 operand_index = 0; operand_index < operand_count; operand_index += 1)
            {
                (void)machine_x64_fixed_template_operand(operand_kinds[operand_index], operand_widths[operand_index], row, sequence,
                                                         operands + operand_index);
            }
            u8 scratch_bytes[16];
            MachineX64Encoder scratch = machine_x64_fixed_template_scratch(scratch_bytes);
            (void)machine_x64_emit_exact_form(&scratch, token, operands, operand_count, force_disp32, force_lock,
                                              mask_register_plus_one, zeroing, 0);
            machine_x64_fixed_template_publish(first_row + row, &scratch, 0);
        }
        machine_x64_fixed_template_count += row_count;
        *family_slot = gpr_slot;
        result = (u16)(first_row + 1u);
    }
    return result;
}

BUSTER_GLOBAL_LOCAL void machine_x64_exact_prepare_fixed_templates(void)
{
    machine_x64_fixed_template_count = MACHINE_X64_FIXED_TEMPLATE_STATIC_COUNT;
    machine_x64_fixed_template_invalid_count = 0;
    machine_x64_exact_prepare_static_fixed_templates();
    for (u32 ordinal = 0; ordinal < MACHINE_X86_64_EMIT_REGISTRY_COUNT; ordinal += 1)
    {
        MachineX64PreparedExactOpcode* entry = machine_x64_exact_opcode_map + ordinal;
        for (u32 variant_index = 0; variant_index < BUSTER_ARRAY_LENGTH(entry->fixed_templates); variant_index += 1)
        {
            entry->fixed_templates[variant_index] = 0;
            entry->fixed_template_slots[variant_index] = MACHINE_X64_FIXED_TEMPLATE_NO_SLOT;
        }
        for (u32 step_slot = 0; step_slot < BUSTER_ARRAY_LENGTH(entry->sequence_templates); step_slot += 1)
        {
            entry->sequence_templates[step_slot] = 0;
            entry->sequence_template_slots[step_slot] = MACHINE_X64_FIXED_TEMPLATE_NO_SLOT;
        }
        if (entry->exact_required && entry->plan_valid && entry->sequence_required && entry->sequence)
        {
            MachineX64ExactSequence const* sequence = entry->sequence;
            for (u32 variant_index = 0; variant_index < sequence->variant_count; variant_index += 1)
            {
                MachineX64ExactSequenceVariant const* variant = sequence->variants + variant_index;
                for (u32 step_index = 0; step_index < variant->step_count; step_index += 1)
                {
                    MachineX64ExactSequenceStep const* step = variant->steps + step_index;
                    u32 step_slot = variant_index * MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS + step_index;
                    // A parity step swaps tokens at emission time and stays
                    // on its token lane.
                    if (!(step->flags & ~(MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP | MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32 |
                                          MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_LOCK)))
                    {
                        entry->sequence_templates[step_slot] = machine_x64_exact_prepare_fixed_template_family(
                            step->operand_kinds, step->operand_slots, step->operand_widths, step->operand_count, true,
                            (step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32) != 0,
                            (step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_LOCK) != 0,
                            step->mask_register_plus_one, step->zeroing, entry->sequence_tokens[step_slot],
                            entry->sequence_template_slots + step_slot);
                    }
                }
            }
        }
        else if (entry->exact_required && entry->plan_valid && entry->descriptor)
        {
            for (u32 variant_index = 0; variant_index < entry->variant_count; variant_index += 1)
            {
                MachineX64ExactRecipeVariant variant = machine_x64_exact_recipe_variant(entry->descriptor, variant_index);
                // A variant with a dense table never reaches the tail, and
                // the tail passes no lock, mask, or zeroing of its own.
                if (!entry->gpr_encoding_tables[variant_index] && !entry->variable_memory_encoding_tables[variant_index] &&
                    !(variant.flags & ~(MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP | MACHINE_X64_EXACT_RECIPE_FLAG_CALL_SITE |
                                        MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32)))
                {
                    entry->fixed_templates[variant_index] = machine_x64_exact_prepare_fixed_template_family(
                        variant.operand_kinds, variant.operand_slots, variant.operand_widths, variant.operand_count, false,
                        (variant.flags & MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32) != 0, false, 0, false,
                        entry->metadata_tokens[variant_index], entry->fixed_template_slots + variant_index);
                }
            }
        }
    }
}

// The expansion sites in machine_encode_x86_64 emit closed shapes.  Each
// helper copies the shape's published template and otherwise keeps the
// mnemonic bridge the site had, so an unpublished row fails closed exactly
// as before.  None of these sites keeps exact counters.
BUSTER_GLOBAL_LOCAL void machine_x64_emit_fixed_instruction(MachineX64Encoder* encoder, u32 template_id, String8 mnemonic,
                                                            BusterX86MetadataFeatureInput features)
{
    if (machine_x64_emit_fixed_template(encoder, template_id, 0) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
    {
        (void)machine_x64_emit_metadata_instruction(encoder, mnemonic, 0, 0, features, (BusterX86MetadataPhysicalAttributes){0}, 0);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_emit_fixed_register(MachineX64Encoder* encoder, u32 template_id, String8 mnemonic, u32 reg, u16 width)
{
    if (machine_x64_emit_fixed_template(encoder, template_id, 0) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
    {
        (void)machine_x64_emit_metadata_register(encoder, mnemonic, reg, width, 0);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_emit_fixed_registers(MachineX64Encoder* encoder, u32 template_id, String8 mnemonic,
                                                          u32 destination, u32 source, u16 width)
{
    if (machine_x64_emit_fixed_template(encoder, template_id, 0) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
    {
        (void)machine_x64_emit_metadata_registers(encoder, mnemonic, destination, source, width, 0);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_emit_fixed_relative(MachineX64Encoder* encoder, u32 template_id, String8 mnemonic)
{
    if (machine_x64_emit_fixed_template(encoder, template_id, 0) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
    {
        (void)machine_x64_emit_metadata_relative(encoder, mnemonic, 0, 32, 0);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_emit_fixed_rip_register(MachineX64Encoder* encoder, u32 template_id, String8 mnemonic, u32 reg)
{
    if (machine_x64_emit_fixed_template(encoder, template_id, 0) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
    {
        BusterX86MetadataPhysicalOperand operands[2] = {
            machine_x64_exact_gpr_operand(reg, 64), machine_x64_exact_rip_memory_operand(),
        };
        (void)machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, 2, (BusterX86MetadataFeatureInput){0},
                                                    (BusterX86MetadataPhysicalAttributes){0}, 0);
    }
}

BUSTER_GLOBAL_LOCAL void machine_x64_emit_fixed_vzeroupper(MachineX64Encoder* encoder)
{
    machine_x64_emit_fixed_instruction(encoder, MACHINE_X64_FIXED_TEMPLATE_VZEROUPPER, S8("VZEROUPPER"),
                                       (BusterX86MetadataFeatureInput){.names = machine_x64_avx_features,
                                                                       .count = BUSTER_ARRAY_LENGTH(machine_x64_avx_features)});
}

// mov eax, imm32 carrying a variadic call's XMM register count.  The
// template was proven for the 0..127 class; a larger count keeps the bridge.
BUSTER_GLOBAL_LOCAL void machine_x64_emit_fixed_xmm_count(MachineX64Encoder* encoder, u32 xmm_count)
{
    if (xmm_count > INT8_MAX ||
        machine_x64_emit_fixed_template(encoder, MACHINE_X64_FIXED_TEMPLATE_MOV_EAX_IMM32, xmm_count) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
    {
        (void)machine_x64_emit_metadata_register_immediate(encoder, S8("MOV"), MACHINE_X64_RAX, xmm_count, 32, 32, 0);
    }
}

// The row a family serves for these operand registers, or none when the
// family is unallotted or the indexing register is not a GPR.
BUSTER_GLOBAL_LOCAL u32 machine_x64_fixed_template_row(u16 family_plus_one, u8 family_slot, u8 const* operand_registers)
{
    u32 result = MACHINE_X64_FIXED_TEMPLATE_NONE;
    if (family_plus_one)
    {
        if (family_slot == MACHINE_X64_FIXED_TEMPLATE_NO_SLOT)
        {
            result = family_plus_one - 1u;
        }
        else if (operand_registers[family_slot] < 16)
        {
            result = family_plus_one - 1u + operand_registers[family_slot];
        }
    }
    return result;
}

// Emits a fixed template row for an exact lane with the lane's accounting:
// one attempt, then a success or a fallback.  UNPUBLISHED counts nothing so
// the caller can keep its metadata lane.
BUSTER_GLOBAL_LOCAL MachineX64FixedTemplateResult machine_x64_emit_fixed_template_counted(MachineX64Encoder* encoder, u32 row,
                                                                                         MachineX64ExactEmitCounters* counters)
{
    MachineX64FixedTemplateResult result = machine_x64_emit_fixed_template(encoder, row, 0);
    if (counters && result != MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
    {
        counters->attempts += 1;
        if (result == MACHINE_X64_FIXED_TEMPLATE_EMITTED) counters->successes += 1;
        else counters->fallbacks += 1;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_variable_memory_encoding(
    MachineX64Encoder* encoder, u8 table_plus_one, u32 reg, u32 base, s32 displacement,
    bool force_disp32, MachineX64ExactEmitCounters* counters);

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_exact_frame_chunk_metadata(MachineX64Encoder* encoder, bool load, u32 reg, u32 offset, u32 chunk,
                                                                      MachineX64ExactEmitCounters* counters)
{
    u16 opcode = load ? (chunk == 1 ? MACHINE_X64_LOAD_PTR8 : chunk == 2 ? MACHINE_X64_LOAD_PTR16 : chunk == 4 ? MACHINE_X64_LOAD_PTR32
                                                                           : MACHINE_X64_LOAD_FRAME)
                      : (chunk == 1 ? MACHINE_X64_STORE_FRAME8 : chunk == 2 ? MACHINE_X64_STORE_FRAME16 : chunk == 4 ? MACHINE_X64_STORE_FRAME32
                                                                                                                         : MACHINE_X64_STORE_FRAME64);
    u16 width = (u16)(chunk * 8u);
    MachineX64PreparedExactOpcode const* entry = machine_x64_exact_opcode_for_opcode(opcode);
    if (!entry || !entry->descriptor || !entry->plan_valid || !entry->variant_count)
    {
        return machine_x64_exact_reject(encoder, counters);
    }
    BusterX86MetadataPhysicalOperand operands[2];
    if (load)
    {
        operands[0] = machine_x64_exact_gpr_operand(reg, chunk <= 2 ? 64 : width);
        operands[1] = machine_x64_exact_rbp_memory_operand(-(s64)(s32)offset, width, true);
    }
    else
    {
        operands[0] = machine_x64_exact_rbp_memory_operand(-(s64)(s32)offset, width, true);
        operands[1] = machine_x64_exact_gpr_operand(reg, width);
    }
    MachineX64ExactRecipeVariant variant = machine_x64_exact_recipe_variant(entry->descriptor, 0);
    return machine_x64_emit_exact_form(encoder, entry->metadata_tokens[0], operands, variant.operand_count, true, false, 0, false, counters);
}

BUSTER_GLOBAL_LOCAL BUSTER_INLINE bool machine_x64_emit_exact_frame_chunk(MachineX64Encoder* encoder, bool load, u32 reg, u32 offset, u32 chunk,
                                                                           MachineX64ExactEmitCounters* counters)
{
    bool result = false;
    MachineX64GprEncoding const* encoding =
        machine_x64_frame_chunk_encodings[load ? MACHINE_X64_CHUNK_DIRECTION_LOAD : MACHINE_X64_CHUNK_DIRECTION_STORE]
                                         [machine_x64_chunk_width_slot(chunk)] + (reg & 15u);
    u32 byte_count = encoding->byte_count;
    if (reg < 16 && byte_count)
    {
        if (encoder->count > encoder->capacity || byte_count > encoder->capacity - encoder->count)
        {
            encoder->overflow = true;
            if (counters)
            {
                counters->attempts += 1;
                counters->fallbacks += 1;
            }
        }
        else
        {
            machine_x64_encoder_copy_encoding(encoder, encoding, byte_count);
            u32 value = (0u - offset) + encoder->frame_base_offset;
            memcpy(encoder->bytes + encoder->count + byte_count - (u32)sizeof(u32), &value, sizeof(value));
            encoder->count += byte_count;
            if (counters)
            {
                counters->attempts += 1;
                counters->successes += 1;
            }
            result = true;
        }
    }
    else
    {
        result = machine_x64_emit_exact_frame_chunk_metadata(encoder, load, reg, offset, chunk, counters);
    }
    return result;
}

#if BUSTER_INCLUDE_TESTS
bool machine_x64_test_frame_chunk_prepared(void)
{
    bool result = machine_x64_exact_opcode_map_ready;
    for (u32 direction = 0; direction < 2; direction += 1)
    {
        for (u32 width_slot = 0; width_slot < MACHINE_X64_CHUNK_WIDTH_COUNT; width_slot += 1)
        {
            for (u32 reg = 0; reg < 16; reg += 1)
            {
                u32 byte_count = machine_x64_frame_chunk_encodings[direction][width_slot][reg].byte_count;
                result &= byte_count > sizeof(u32) && byte_count <= 15;
            }
        }
    }
    return result;
}

MachineEncodeResult machine_x64_test_emit_frame_chunk(u8* bytes, u32 capacity, u32 start, u32 frame_base_offset, bool load, u32 reg,
                                                      u32 offset, u32 chunk, bool reference)
{
    MachineX64Encoder encoder = {.bytes = bytes, .capacity = capacity, .count = start, .frame_base_offset = frame_base_offset};
    MachineX64ExactEmitCounters counters = {0};
    MachineEncodeResult result = {.bytes = bytes};
    result.valid = reference ? machine_x64_emit_exact_frame_chunk_metadata(&encoder, load, reg, offset, chunk, &counters)
                             : machine_x64_emit_exact_frame_chunk(&encoder, load, reg, offset, chunk, &counters);
    result.byte_count = encoder.count;
    machine_x64_exact_counters_assign(&result, counters);
    return result;
}
#endif

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_x87(MachineX64Encoder* encoder, String8 mnemonic,
                                               BusterX86MetadataPhysicalOperand const* operands, u32 operand_count);
BUSTER_GLOBAL_LOCAL void machine_x64_emit_x87_memory(MachineX64Encoder* encoder, String8 mnemonic, s32 displacement, u16 width);
BUSTER_GLOBAL_LOCAL void machine_x64_emit_f80_padding(MachineX64Encoder* encoder, s32 displacement);

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_inline_assembly_outputs(MachineX64Encoder* encoder, MachineFunction* function,
                                                                 MachineStackPlacement* placement,
                                                                 MachineInlineAssembly const* assembly,
                                                                 u32 x87_top, u32 x87_below, u32 input_x87_depth)
{
    bool valid = true;
    u32 x87_depth = input_x87_depth;
    for (u32 operand_index = 0; operand_index < assembly->operand_count && valid && !encoder->overflow; operand_index += 1)
    {
        MachineInlineAssemblyOperand const* operand = function->inline_assembly_operands + assembly->first_operand + operand_index;
        if ((operand->flags & (MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_VECTOR)) ==
            (MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_VECTOR))
        {
            u32 frame_offset = placement->stack_slot_offsets[operand->stack_slot];
            u32 xmm = operand->physical_register - MACHINE_X64_ZMM0;
            (void)machine_x64_emit_metadata_xmm_memory(encoder, S8("MOVSD"), xmm, MACHINE_X64_RBP,
                                                       -(s64)(s32)frame_offset, true, 64, 0);
        }
        else if ((operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT) &&
                 !(operand->flags & (MACHINE_INLINE_ASSEMBLY_OPERAND_MEMORY | MACHINE_INLINE_ASSEMBLY_OPERAND_X87_TOP |
                                     MACHINE_INLINE_ASSEMBLY_OPERAND_X87_BELOW)))
        {
            valid = machine_x64_emit_exact_frame_chunk(encoder, false, operand->physical_register,
                                                       placement->stack_slot_offsets[operand->stack_slot], 8, 0);
        }
    }
    MachineInlineAssemblyOperand const* top_operand =
        x87_top != UINT32_MAX ? function->inline_assembly_operands + x87_top : 0;
    MachineInlineAssemblyOperand const* below_operand =
        x87_below != UINT32_MAX ? function->inline_assembly_operands + x87_below : 0;
    if (top_operand && (top_operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT) &&
        !(top_operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT))
    {
        x87_depth += 1;
    }
    if (below_operand && (below_operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT) &&
        !(below_operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT))
    {
        x87_depth += 1;
    }
    if ((assembly->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_X87_POP) && x87_depth)
    {
        x87_depth -= 1;
    }
    if (top_operand && x87_depth)
    {
        if (top_operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT)
        {
            s32 displacement = -(s32)placement->stack_slot_offsets[top_operand->stack_slot];
            machine_x64_emit_x87_memory(encoder, S8("FSTP"), displacement, 80);
            machine_x64_emit_f80_padding(encoder, displacement);
            x87_depth -= 1;
        }
        else if (!(assembly->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_X87_POP))
        {
            BusterX86MetadataPhysicalOperand st0 = machine_x64_x87_operand(0);
            (void)machine_x64_emit_x87(encoder, S8("FSTP"), &st0, 1);
            x87_depth -= 1;
        }
    }
    if (below_operand && x87_depth)
    {
        if (below_operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_OUTPUT)
        {
            s32 displacement = -(s32)placement->stack_slot_offsets[below_operand->stack_slot];
            machine_x64_emit_x87_memory(encoder, S8("FSTP"), displacement, 80);
            machine_x64_emit_f80_padding(encoder, displacement);
        }
        else
        {
            BusterX86MetadataPhysicalOperand st0 = machine_x64_x87_operand(0);
            (void)machine_x64_emit_x87(encoder, S8("FSTP"), &st0, 1);
        }
        x87_depth -= 1;
    }
    u16 preserved_vector_mask = function->target == machine_target_x86_64_windows()
                                    ? (u16)((assembly->clobber_mask >> MACHINE_X64_ZMM0) &
                                            MACHINE_INLINE_ASSEMBLY_WIN64_PRESERVED_VECTOR_MASK)
                                    : 0;
    if (preserved_vector_mask)
    {
        u32 preserve_offset = placement->stack_slot_offsets[assembly->preserved_vector_slot];
        u32 preserve_index = 0;
        for (u32 xmm = 6; xmm < 16; xmm += 1)
        {
            if (preserved_vector_mask & (1u << xmm))
            {
                s64 displacement = -(s64)(s32)(preserve_offset - preserve_index * 16u);
                (void)machine_x64_emit_metadata_xmm_memory(encoder, S8("MOVDQU"), xmm, MACHINE_X64_RBP,
                                                           displacement, false, 128, 0);
                preserve_index += 1;
            }
        }
    }
    valid = valid && !x87_depth && !encoder->overflow;
    return valid;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_exact_movabs(MachineX64Encoder* encoder, u32 reg, u64 value,
                                                       MachineX64ExactEmitCounters* counters)
{
    bool result = false;
    MachineX64PreparedExactOpcode const* entry = machine_x64_exact_opcode_for_opcode(MACHINE_X64_MOV_RI);
    if (!entry || !entry->descriptor || !entry->plan_valid || entry->variant_count < 3 || reg >= 16 || !encoder->bytes)
    {
        result = machine_x64_exact_reject(encoder, counters);
    }
    else if (entry->gpr_encoding_tables[2])
    {
        // Switch constants deliberately retain MOV r64, imm64 even when a
        // shorter MOV would carry the value. Variant 2 already proves the
        // complete register population and its trailing eight-byte field.
        u32 table_index = entry->gpr_encoding_tables[2] - 1u;
        if (table_index >= machine_x64_gpr_encoding_table_count)
        {
            result = machine_x64_exact_reject(encoder, counters);
        }
        else
        {
            MachineX64GprEncodingTable const* table = machine_x64_gpr_encoding_tables + table_index;
            MachineX64GprEncoding const* encoding = table->encodings + reg;
            if (table->operand_count != 1 || table->operand_slots[0] != 0 ||
                table->flags != MACHINE_X64_GPR_ENCODING_TABLE_PATCH_IMMEDIATE ||
                table->immediate_width != sizeof(value) || encoding->byte_count != 10 ||
                encoder->count > encoder->capacity || encoding->byte_count > encoder->capacity - encoder->count)
            {
                result = machine_x64_exact_reject(encoder, counters);
            }
            else
            {
                // Copy only the authoritative prefix, then patch the field:
                // no whole-record overstore and no write before validation.
                memcpy(encoder->bytes + encoder->count, encoding->bytes, 2);
                memcpy(encoder->bytes + encoder->count + 2, &value, sizeof(value));
                encoder->count += encoding->byte_count;
                if (counters)
                {
                    counters->attempts += 1;
                    counters->successes += 1;
                }
                result = true;
            }
        }
    }
    else
    {
        // An unavailable prepared table retains the same checked authority,
        // not a handwritten encoding or a value-dependent shorter form.
        MachineX64ExactRecipeVariant variant = machine_x64_exact_recipe_variant(entry->descriptor, 2);
        BusterX86MetadataPhysicalOperand operands[2] = {
            machine_x64_exact_gpr_operand(reg, 64),
            machine_x64_exact_unsigned_immediate_operand(value, 64),
        };
        result = machine_x64_emit_exact_form(encoder, entry->metadata_tokens[2], operands, variant.operand_count,
                                             false, false, 0, false, counters);
    }
    return result;
}

#if BUSTER_INCLUDE_TESTS
bool machine_x64_test_movabs_prepared(void)
{
    MachineX64PreparedExactOpcode const* entry = machine_x64_exact_opcode_for_opcode(MACHINE_X64_MOV_RI);
    bool result = entry && entry->plan_valid && entry->variant_count >= 3 && entry->gpr_encoding_tables[2] != 0;
    return result;
}

MachineEncodeResult machine_x64_test_emit_movabs(u8* bytes, u32 capacity, u32 start, u32 reg, u64 value, bool reference)
{
    MachineX64Encoder encoder = {.bytes = bytes, .capacity = capacity, .count = start};
    MachineX64ExactEmitCounters counters = {0};
    MachineEncodeResult result = {.bytes = bytes};
    if (reference)
    {
        MachineX64PreparedExactOpcode const* entry = machine_x64_exact_opcode_for_opcode(MACHINE_X64_MOV_RI);
        BusterX86MetadataPhysicalOperand operands[2] = {
            machine_x64_exact_gpr_operand(reg, 64),
            machine_x64_exact_unsigned_immediate_operand(value, 64),
        };
        result.valid = machine_x64_emit_exact_form(&encoder, entry->metadata_tokens[2], operands, 2,
                                                   false, false, 0, false, &counters);
    }
    else
    {
        result.valid = machine_x64_emit_exact_movabs(&encoder, reg, value, &counters);
    }
    result.valid = result.valid && !encoder.overflow;
    result.byte_count = encoder.count;
    machine_x64_exact_counters_assign(&result, counters);
    return result;
}
#endif

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_variable_memory_encoding(
    MachineX64Encoder* encoder, u8 table_plus_one, u32 reg, u32 base, s32 displacement,
    bool force_disp32, MachineX64ExactEmitCounters* counters)
{
    if (!table_plus_one || table_plus_one > machine_x64_variable_memory_encoding_table_count || reg >= 16 || base >= 16)
        return false;

    if (base == MACHINE_X64_RBP)
    {
        displacement = (s32)((u32)displacement + encoder->frame_base_offset);
    }

    u32 displacement_class = force_disp32 ? 2 : displacement == 0 ? 0 : displacement >= INT8_MIN && displacement <= INT8_MAX ? 1 : 2;
    MachineX64VariableMemoryEncodingTable const* table =
        machine_x64_variable_memory_encoding_tables + (table_plus_one - 1u);
    MachineX64GprEncoding const* encoding =
        table->encodings[displacement_class] + reg + (base << 4);
    u32 byte_count = encoding->byte_count;
    if (encoder->count > encoder->capacity || byte_count > encoder->capacity - encoder->count)
    {
        encoder->overflow = true;
        if (counters)
        {
            counters->attempts += 1;
            counters->fallbacks += 1;
        }
        return false;
    }

    // The published encoding record is exactly one sixteen-byte line, so a
    // 1-15 byte copy is one load and one store whose width the caller can
    // fold, not a call into libc with a length it cannot see. The spare bytes
    // land inside the row budget every emitter already reserved and the next
    // emit overwrites them; only a row that would end within sixteen bytes of
    // capacity takes the exact copy.
    machine_x64_encoder_copy_encoding(encoder, encoding, byte_count);
    if (displacement_class == 1)
    {
        encoder->bytes[encoder->count + byte_count - 1u] = (u8)displacement;
    }
    else if (displacement_class == 2)
    {
        u32 patch_offset = encoder->count + byte_count - (u32)sizeof(u32);
        u32 value = (u32)displacement;
        // One 32-bit store: the byte loop spelled the same little-endian
        // field four times over, and the fixup path below has always written
        // it as one store.
        memcpy(encoder->bytes + patch_offset, &value, sizeof(value));
    }
    encoder->count += byte_count;
    if (counters)
    {
        counters->attempts += 1;
        counters->successes += 1;
    }
    return true;
}

// TLS is an ABI recipe in the metadata authority, not a literal-byte escape.
BUSTER_GLOBAL_LOCAL bool machine_x64_emit_tls_general_dynamic(MachineX64Encoder* encoder)
{
    bool result = false;
    if (encoder->count <= encoder->capacity && BUSTER_X86_METADATA_TLS_GD_SIZE <= encoder->capacity - encoder->count)
    {
        result = buster_x86_metadata_emit_tls_general_dynamic(encoder->bytes + encoder->count, BUSTER_X86_METADATA_TLS_GD_SIZE);
    }
    if (result)
    {
        encoder->count += BUSTER_X86_METADATA_TLS_GD_SIZE;
    }
    else
    {
        encoder->overflow = true;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_metadata_pointer_chunk(MachineX64Encoder* encoder, bool load, u32 reg, u32 base, u32 offset, u32 chunk,
                                                                  MachineX64ExactEmitCounters* counters)
{
    if (offset <= INT32_MAX &&
        machine_x64_emit_variable_memory_encoding(
            encoder,
            machine_x64_chunk_memory_tables[load ? MACHINE_X64_CHUNK_DIRECTION_LOAD : MACHINE_X64_CHUNK_DIRECTION_STORE]
                                           [machine_x64_chunk_width_slot(chunk)],
            reg, base, (s32)offset, false, counters))
        return true;
    if (encoder->overflow) return false;

    u16 width = (u16)(chunk * 8u);
    if (load)
    {
        if (chunk == 1 || chunk == 2)
        {
            BusterX86MetadataPhysicalOperand operands[2] = {
                machine_x64_exact_gpr_operand(reg, 64),
                machine_x64_exact_memory_operand(base, width, offset, offset != 0),
            };
            bool result = machine_x64_emit_metadata_instruction(encoder, S8("MOVZX"), operands, 2, (BusterX86MetadataFeatureInput){0},
                                                                (BusterX86MetadataPhysicalAttributes){0}, counters);
            return result;
        }
        bool result = machine_x64_emit_metadata_register_memory(encoder, S8("MOV"), reg, base, offset, width, width, counters);
        return result;
    }
    bool result = machine_x64_emit_metadata_memory_register(encoder, S8("MOV"), base, offset, reg, width, width, counters);
    return result;
}

BUSTER_GLOBAL_LOCAL MachineX64PreparedExactOpcode const* machine_x64_exact_opcode_for_opcode(u16 opcode)
{
    MachineX64PreparedExactOpcode const* result;
    if (opcode < MACHINE_X64_MOV_RI || opcode > MACHINE_X64_VBINARY)
    {
        result = 0;
    }
    else
    {
        u32 ordinal = opcode - MACHINE_X64_MOV_RI;
        result = ordinal < BUSTER_ARRAY_LENGTH(machine_x64_exact_opcode_map) ? machine_x64_exact_opcode_map + ordinal : 0;
    }

    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_exact_recipe(MachineX64Encoder* encoder, MachineX64PreparedExactOpcode const* entry,
                                                       MachineInstruction const* instruction, MachineStackPlacement const* placement,
                                                       u8 const* operand_registers, u32 payload, u64 immediate_value,
                                                       bool emit_self_copy, MachineX64ExactEmitCounters* counters)
{
    MachineX64ExactRecipe const* descriptor = entry ? entry->descriptor : 0;
    u32 variant_index = 0;
    u8 gpr_table_plus_one = entry ? entry->single_gpr_encoding_table : 0;
    if (!gpr_table_plus_one)
    {
        if (!descriptor || !entry->plan_valid)
        {
            if (counters) counters->attempts += 1;
            if (counters) counters->fallbacks += 1;
            return false;
        }
        if (descriptor->variant_selector == MACHINE_X64_EXACT_VARIANT_MOV_IMMEDIATE)
        {
            variant_index = immediate_value <= UINT32_MAX ? 0 : immediate_value >= UINT64_C(0xffffffff80000000) ? 1 : 2;
        }
        else if (descriptor->variant_selector == MACHINE_X64_EXACT_VARIANT_SIGNED_IMMEDIATE)
        {
            s64 signed_immediate = (s64)immediate_value;
            variant_index = signed_immediate >= INT8_MIN && signed_immediate <= INT8_MAX ? 0 : 1;
        }
        else if (descriptor->variant_selector == MACHINE_X64_EXACT_VARIANT_PAYLOAD_BYTE_WIDTH)
        {
            variant_index = (payload & 0xffu) == 1u ? 1u : 0u;
        }
        else if (descriptor->variant_selector == MACHINE_X64_EXACT_VARIANT_VBINARY)
        {
            switch (payload)
            {
            case 0xfcu: variant_index = 0; break;
            case 0xfdu: variant_index = 1; break;
            case 0xfeu: variant_index = 2; break;
            case 0x1d4u: variant_index = 3; break;
            case 0xf8u: variant_index = 4; break;
            case 0xf9u: variant_index = 5; break;
            case 0xfau: variant_index = 6; break;
            case 0x1fbu: variant_index = 7; break;
            case 0xdbu: variant_index = 8; break;
            case 0xebu: variant_index = 9; break;
            case 0xefu: variant_index = 10; break;
            default: variant_index = UINT32_MAX; break;
            }
        }
        if (variant_index >= entry->variant_count || !(entry->variant_valid_mask & (u16)(1u << variant_index)))
        {
            if (counters) counters->attempts += 1;
            if (counters) counters->fallbacks += 1;
            return false;
        }
        gpr_table_plus_one = entry->gpr_encoding_tables[variant_index];
    }
    if (gpr_table_plus_one && gpr_table_plus_one <= machine_x64_gpr_encoding_table_count)
    {
        MachineX64GprEncodingTable const* table = machine_x64_gpr_encoding_tables + (gpr_table_plus_one - 1u);
        u8 low_register = table->operand_count ? operand_registers[table->operand_slots[0]] : 0;
        u8 high_register = table->operand_count > 1 ? operand_registers[table->operand_slots[1]] : 0;
        if (low_register < 16 && high_register < 16)
        {
            if (!emit_self_copy && (table->flags & MACHINE_X64_GPR_ENCODING_TABLE_SELF_COPY_NOOP) && low_register == high_register)
            {
                if (counters)
                {
                    counters->attempts += 1;
                    counters->successes += 1;
                }
                return true;
            }
            MachineX64GprEncoding const* encoding = table->encodings + low_register + ((u32)high_register << 4);
            u32 byte_count = encoding->byte_count;
            s32 displacement = 0;
            if (table->flags & MACHINE_X64_GPR_ENCODING_TABLE_PATCH_DISPLACEMENT)
            {
                if (table->flags & MACHINE_X64_GPR_ENCODING_TABLE_INCOMING_DISPLACEMENT)
                {
                    displacement = (s32)(16u + (placement ? placement->incoming_base : 0u) + payload);
                }
                else
                {
                    u8 operand_slot = table->memory_operand_slot;
                    if (!instruction || !placement || operand_slot >= 4 ||
                        machine_ref_kind(instruction->operands[operand_slot]) != MACHINE_REF_STACK_SLOT)
                    {
                        if (counters)
                        {
                            counters->attempts += 1;
                            counters->fallbacks += 1;
                        }
                        return false;
                    }
                    u32 offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[operand_slot])] - payload;
                    displacement = -(s32)offset;
                }
                displacement = (s32)((u32)displacement + encoder->frame_base_offset);
            }
            if (counters) counters->attempts += 1;
            if (encoder->count > encoder->capacity || byte_count > encoder->capacity - encoder->count)
            {
                encoder->overflow = true;
                if (counters) counters->fallbacks += 1;
                return false;
            }
            if ((table->flags & MACHINE_X64_GPR_ENCODING_TABLE_COMPACT) &&
                encoder->capacity - encoder->count >= sizeof(u32))
            {
                memcpy(encoder->bytes + encoder->count, encoding->bytes, sizeof(u32));
            }
            else
            {
                machine_x64_encoder_copy_encoding(encoder, encoding, byte_count);
            }
            if (table->flags & MACHINE_X64_GPR_ENCODING_TABLE_PATCH_IMMEDIATE)
            {
                u32 immediate_width = table->immediate_width;
                if (!immediate_width || immediate_width > byte_count)
                {
                    if (counters) counters->fallbacks += 1;
                    return false;
                }
                u64 patch_value = table->flags & MACHINE_X64_GPR_ENCODING_TABLE_IMMEDIATE_FROM_PAYLOAD
                                      ? payload
                                      : immediate_value;
                u32 immediate_offset = encoder->count + byte_count - immediate_width;
                machine_x64_encoder_store_field(encoder->bytes + immediate_offset, patch_value, immediate_width);
            }
            if (table->flags & MACHINE_X64_GPR_ENCODING_TABLE_PATCH_DISPLACEMENT)
            {
                u32 displacement_offset = encoder->count + byte_count - (u32)sizeof(u32);
                u32 value = (u32)displacement;
                memcpy(encoder->bytes + displacement_offset, &value, sizeof(value));
            }
            encoder->count += byte_count;
            if (counters) counters->successes += 1;
            return true;
        }
    }
    u8 variable_memory_table_plus_one = entry->variable_memory_encoding_tables[variant_index];
    if (variable_memory_table_plus_one &&
        variable_memory_table_plus_one <= machine_x64_variable_memory_encoding_table_count)
    {
        MachineX64VariableMemoryEncodingTable const* table =
            machine_x64_variable_memory_encoding_tables + (variable_memory_table_plus_one - 1u);
        if (machine_x64_emit_variable_memory_encoding(
                encoder, variable_memory_table_plus_one,
                operand_registers[table->gpr_operand_slot], operand_registers[table->memory_operand_slot],
                (s32)payload, false, counters))
            return true;
        if (encoder->overflow) return false;
    }
    // A variant with only fixed operands (JMP, LEA_SYMBOL, INT3, ...) was
    // published as a template at prewarm; its operands are not projected.
    MachineX64FixedTemplateResult fixed_result = machine_x64_emit_fixed_template_counted(
        encoder,
        machine_x64_fixed_template_row(entry->fixed_templates[variant_index], entry->fixed_template_slots[variant_index], operand_registers),
        counters);
    if (fixed_result != MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED) return fixed_result == MACHINE_X64_FIXED_TEMPLATE_EMITTED;
    MachineX64ExactRecipeVariant variant = machine_x64_exact_recipe_variant(descriptor, variant_index);
    if (!emit_self_copy && (variant.flags & MACHINE_X64_EXACT_RECIPE_FLAG_SELF_COPY_NOOP) &&
        operand_registers[variant.operand_slots[0]] == operand_registers[variant.operand_slots[1]])
    {
        if (counters)
        {
            counters->attempts += 1;
            counters->successes += 1;
        }
        return true;
    }
    // Every active descriptor slot is populated by the projection loop before
    // the metadata query; no inactive slot is consumed by the exact API.
    BusterX86MetadataPhysicalOperand operands[4];
    bool force_disp32 = (variant.flags & MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32) != 0;
    for (u32 operand_index = 0; operand_index < variant.operand_count; operand_index += 1)
    {
        u8 operand_slot = variant.operand_slots[operand_index];
        u16 width = variant.operand_widths[operand_index];
        switch ((MachineX64ExactOperandProjection)variant.operand_kinds[operand_index])
        {
        case MACHINE_X64_EXACT_OPERAND_GPR:
            operands[operand_index] = machine_x64_exact_gpr_operand(operand_registers[operand_slot], width);
            break;
        case MACHINE_X64_EXACT_OPERAND_XMM_PAYLOAD:
            operands[operand_index] = machine_x64_exact_xmm_operand(payload, width);
            break;
        case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX:
            operands[operand_index] = machine_x64_exact_gpr_operand(MACHINE_X64_RAX, width);
            break;
        case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX:
            operands[operand_index] = machine_x64_exact_gpr_operand(MACHINE_X64_RDX, width);
            break;
        case MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE:
        {
            u32 size = payload & 0xffu;
            if (size != 1 && size != 2 && size != 4 && size != 8)
            {
                if (counters) counters->fallbacks += 1;
                return false;
            }
            operands[operand_index] = machine_x64_exact_gpr_operand(operand_registers[operand_slot], (u16)(size * 8u));
        }
        break;
        case MACHINE_X64_EXACT_OPERAND_ZMM_SLOT:
            if (operand_registers[operand_slot] < MACHINE_X64_ZMM0 || operand_registers[operand_slot] >= MACHINE_X64_ZMM0 + 32)
            {
                if (counters) counters->fallbacks += 1;
                return false;
            }
            operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
                .width = width,
                .reg = {.index = (u16)(operand_registers[operand_slot] - MACHINE_X64_ZMM0), .width = width,
                        .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM},
            };
            break;
        case MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1:
            operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER,
                .width = 64,
                .reg = {.index = 1, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_MASK},
            };
            break;
        case MACHINE_X64_EXACT_OPERAND_FIXED_RSP:
            operands[operand_index] = machine_x64_exact_gpr_operand(MACHINE_X64_RSP, width);
            break;
        case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD:
            // MOV's B8 forms are unsigned (UIMMv), while its C7 form and the
            // arithmetic immediate forms are signed.  Preserve the complete
            // u64 payload for the unsigned variants; truncating through s32
            // would reject values such as 0xffffffff and all movabs bits.
            if (variant.key.form_id == MACHINE_X64_MOV_IMMEDIATE_EXACT_FORM_ID)
            {
                operands[operand_index] = machine_x64_exact_unsigned_immediate_operand(immediate_value, width);
            }
            else if (variant.key.form_id == MACHINE_X64_VPSLLD_EXACT_FORM_ID || variant.key.form_id == MACHINE_X64_VPTERNLOGD_EXACT_FORM_ID ||
                     variant.key.form_id == MACHINE_X64_SUB_RSP_EXACT_FORM_ID)
            {
                // These rows carry their immediate directly in the machine
                // payload rather than through a MACHINE_REF_IMMEDIATE slot.
                operands[operand_index] = machine_x64_exact_immediate_operand((s64)(s32)payload, width);
            }
            else
            {
                operands[operand_index] = machine_x64_exact_immediate_operand((s64)(s32)immediate_value, width);
            }
            break;
        case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_CONSTANT:
            operands[operand_index] = machine_x64_exact_unsigned_immediate_operand(payload, width);
            break;
        case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_LESS:
            operands[operand_index] = machine_x64_exact_unsigned_immediate_operand(1, width);
            break;
        case MACHINE_X64_EXACT_OPERAND_RELATIVE_ZERO:
            operands[operand_index] = machine_x64_exact_relative_operand(0, width);
            break;
        case MACHINE_X64_EXACT_OPERAND_RIP_MEMORY_ZERO:
            operands[operand_index] = machine_x64_exact_rip_memory_operand();
            break;
        case MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO:
            operands[operand_index] = machine_x64_exact_memory_operand(operand_registers[operand_slot], width, 0, false);
            break;
        case MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE:
        {
            u32 size = payload & 0xffu;
            if (size != 1 && size != 2 && size != 4 && size != 8)
            {
                if (counters) counters->fallbacks += 1;
                return false;
            }
            operands[operand_index] = machine_x64_exact_memory_operand(operand_registers[operand_slot], (u16)(size * 8u), 0, false);
        }
        break;
        case MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD:
            operands[operand_index] = machine_x64_exact_memory_operand(operand_registers[operand_slot], width, (s64)(s32)payload, false);
            break;
        case MACHINE_X64_EXACT_OPERAND_RBP_MEMORY_PAYLOAD:
            // Incoming arguments: past the saved frame pointer and return
            // address, plus whatever the prologue pushed below the frame
            // pointer before establishing it.
            operands[operand_index] =
                machine_x64_exact_rbp_memory_operand(16u + (placement ? placement->incoming_base : 0u) + payload, width, force_disp32);
            break;
        case MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_PAYLOAD:
            if (!instruction || !placement || operand_slot >= 4 || machine_ref_kind(instruction->operands[operand_slot]) != MACHINE_REF_STACK_SLOT)
            {
                if (counters) counters->attempts += 1;
                if (counters) counters->fallbacks += 1;
                return false;
            }
            {
                u32 offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[operand_slot])] - payload;
                operands[operand_index] = machine_x64_exact_rbp_memory_operand(-(s64)(s32)offset, width, force_disp32);
            }
            break;
        case MACHINE_X64_EXACT_OPERAND_RBP_FRAME_MEMORY_SLOT:
            if (!instruction || !placement || operand_slot >= 4 || machine_ref_kind(instruction->operands[operand_slot]) != MACHINE_REF_STACK_SLOT)
            {
                if (counters) counters->attempts += 1;
                if (counters) counters->fallbacks += 1;
                return false;
            }
            {
                u32 offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[operand_slot])];
                operands[operand_index] = machine_x64_exact_rbp_memory_operand(-(s64)(s32)offset, width, true);
            }
            break;
        default:
            if (counters) counters->attempts += 1;
            if (counters) counters->fallbacks += 1;
            return false;
        }
    }
    return machine_x64_emit_exact_form(encoder, entry->metadata_tokens[variant_index], operands, variant.operand_count, force_disp32, false, 0, false, counters);
}

// Allocator copies and rematerializations are not a separate encoding
// population.  Feed them through the same prepared recipe lane as ordinary
// machine rows so they consume its dense register tables and patch kernels.
BUSTER_GLOBAL_LOCAL bool machine_x64_emit_exact_register_copy(MachineX64Encoder* encoder, u32 destination, u32 source,
                                                              MachineX64ExactEmitCounters* counters)
{
    if (destination >= 16 || source >= 16) return machine_x64_exact_reject(encoder, counters);
    u8 operand_registers[4] = {(u8)destination, (u8)source};
    return machine_x64_emit_exact_recipe(
        encoder, machine_x64_exact_opcode_for_opcode(MACHINE_X64_MOV_RR), 0, 0,
        operand_registers, 0, 0, true, counters);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_exact_immediate_value(MachineX64Encoder* encoder, u32 reg, u64 value,
                                                                MachineX64ExactEmitCounters* counters)
{
    if (reg >= 16) return machine_x64_exact_reject(encoder, counters);
    u8 operand_registers[4] = {(u8)reg};
    return machine_x64_emit_exact_recipe(
        encoder, machine_x64_exact_opcode_for_opcode(MACHINE_X64_MOV_RI), 0, 0,
        operand_registers, 0, value, false, counters);
}

typedef struct MachineX64BranchFixup MachineX64BranchFixup;
struct MachineX64BranchFixup
{
    s64 addend;
    u32 patch_offset;
    u32 block;
    bool label_address;
    u8 reserved[3];
};

BUSTER_GLOBAL_LOCAL bool machine_x64_block_displacement(u32 target_offset, s64 addend, u32 place_offset, s64* displacement_out)
{
    bool valid = displacement_out && addend >= INT64_MIN + (s64)target_offset &&
                 addend <= INT64_MAX - (s64)target_offset;
    s64 target = valid ? (s64)target_offset + addend : 0;
    valid = valid && target >= INT64_MIN + (s64)place_offset;
    if (valid)
    {
        *displacement_out = target - (s64)place_offset;
    }
    return valid;
}

#if BUSTER_INCLUDE_TESTS
bool machine_x64_test_block_displacement(u32 target_offset, s64 addend, u32 place_offset, s64* displacement_out)
{
    return machine_x64_block_displacement(target_offset, addend, place_offset, displacement_out);
}
#endif

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_exact_sequence(MachineX64Encoder* encoder, MachineX64PreparedExactOpcode const* entry,
                                                         MachineInstruction const* instruction, MachineStackPlacement const* placement,
                                                         u8 const* operand_registers, u32 payload, u64 immediate_value,
                                                         MachineX64ExactEmitCounters* counters, Arena* arena, MachineBuilderStream* fixups)
{
    MachineX64ExactSequence const* sequence = entry ? entry->sequence : 0;
    if (!sequence || !entry->plan_valid || sequence->variant_count == 0 || entry->variant_count != sequence->variant_count ||
        !entry->variant_valid_mask)
    {
        if (counters) { counters->attempts += 1; counters->fallbacks += 1; }
        return false;
    }
    // Sequence variants are selected by the family payload where a row has
    // multiple canonical forms.  The first variant is the fixed/default path;
    // callers can extend this switch without changing MachineInstruction.
    u32 variant_index = 0;
    if (sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 39 ||
        sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 42)
    {
        variant_index = payload < sequence->variant_count ? payload : UINT32_MAX;
    }
    else if (sequence->variant_selector == MACHINE_X64_EXACT_VARIANT_PAYLOAD_BYTE_WIDTH)
    {
        variant_index = (payload & 0xffu) == 1u ? 1u : 0u;
    }
    else if (sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 44)
    {
        u32 operation = payload & 0xffu;
        u32 operation_index = operation == 0x58u ? 0 : operation == 0x5cu ? 1 : operation == 0x59u ? 2 : operation == 0x5eu ? 3 : UINT32_MAX;
        variant_index = operation_index == UINT32_MAX ? UINT32_MAX : operation_index + ((payload & 0x100u) ? 4u : 0u);
    }
    else if (sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 45)
    {
        u32 condition = payload & 0xfu;
        u32 condition_index = condition == 4 ? 0 : condition == 5 ? 1 : condition == 2 ? 2 : condition == 6 ? 3 : condition == 7 ? 4 : condition == 3 ? 5 : UINT32_MAX;
        variant_index = condition_index == UINT32_MAX ? UINT32_MAX : condition_index + ((payload & 0x100u) ? 6u : 0u);
    }
    else if (sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 43)
    {
        u32 quarter = payload & 0xffu;
        variant_index = quarter < sequence->variant_count ? quarter : UINT32_MAX;
    }
    else if (sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 47 ||
             sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 48)
    {
        variant_index = (payload & 0xfu) < sequence->variant_count ? payload & 0xfu : UINT32_MAX;
    }
    if (variant_index >= sequence->variant_count || !(entry->variant_valid_mask & (u16)(1u << variant_index)))
    {
        if (counters) { counters->attempts += 1; counters->fallbacks += 1; }
        return false;
    }
    MachineX64ExactSequenceVariant const* variant = sequence->variants + variant_index;
    bool allocated_predicate = instruction && instruction->opcode >= MACHINE_X64_VPCMP_K && instruction->opcode <= MACHINE_X64_VCOMPRESSB_K;
    bool predicate_result = allocated_predicate && (instruction->opcode == MACHINE_X64_VPCMP_K || instruction->opcode == MACHINE_X64_VPMOVB2K);
    u32 predicate_slot = predicate_result ? 0 : instruction && instruction->opcode == MACHINE_X64_VLOAD_PTR_K ? 2 : 1;
    u32 predicate_register = allocated_predicate ? operand_registers[predicate_slot] - MACHINE_PREDICATE_REGISTER_BASE : 1;
    if (allocated_predicate && (predicate_register == 0 || predicate_register >= MACHINE_PREDICATE_REGISTER_COUNT))
    {
        return machine_x64_exact_reject(encoder, counters);
    }
    u32 sequence_start = encoder->count;
    u32 parity_mode = (payload >> 9) & 0x3u;
    for (u32 step_index = 0; step_index < variant->step_count; step_index += 1)
    {
        if (allocated_predicate && step_index == (predicate_result ? 1u : 0u)) continue;
        MachineX64ExactSequenceStep const* step = variant->steps + step_index;
        if ((step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_ONLY) && parity_mode == 0)
        {
            continue;
        }
        u32 step_slot = variant_index * MACHINE_X64_EXACT_SEQUENCE_MAX_STEPS + step_index;
        u32 step_start = encoder->count;
        // A step with only fixed operands (every JCC and SETCC step) was
        // published as a template at prewarm; its operands are not
        // projected and its token is not consulted.
        MachineX64FixedTemplateResult step_template = allocated_predicate ? MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED : machine_x64_emit_fixed_template_counted(
            encoder,
            machine_x64_fixed_template_row(entry->sequence_templates[step_slot], entry->sequence_template_slots[step_slot], operand_registers),
            counters);
        bool step_templated = step_template != MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED;
        BusterX86MetadataPhysicalOperand operands[4];
        bool force_disp32 = (step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_DISP32) != 0;
        bool step_valid = true;
        for (u32 operand_index = 0; !step_templated && operand_index < step->operand_count; operand_index += 1)
        {
            u8 operand_slot = step->operand_slots[operand_index];
            u16 width = step->operand_widths[operand_index];
            switch ((MachineX64ExactOperandProjection)step->operand_kinds[operand_index])
            {
            case MACHINE_X64_EXACT_OPERAND_GPR:
                operands[operand_index] = machine_x64_exact_gpr_operand(operand_registers[operand_slot], width);
                break;
            case MACHINE_X64_EXACT_OPERAND_XMM_PAYLOAD:
                operands[operand_index] = machine_x64_exact_xmm_operand(payload, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_XMM_FIXED0:
                operands[operand_index] = machine_x64_exact_xmm_operand(0, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_XMM_FIXED1:
                operands[operand_index] = machine_x64_exact_xmm_operand(1, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_XMM_SLOT:
                step_valid = operand_registers[operand_slot] >= MACHINE_X64_ZMM0 && operand_registers[operand_slot] < MACHINE_X64_ZMM0 + 32;
                if (step_valid) operands[operand_index] = machine_x64_exact_xmm_operand(operand_registers[operand_slot] - MACHINE_X64_ZMM0, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RAX:
                operands[operand_index] = machine_x64_exact_gpr_operand(MACHINE_X64_RAX, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_GPR_FIXED_RDX:
                operands[operand_index] = machine_x64_exact_gpr_operand(MACHINE_X64_RDX, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_GPR_PAYLOAD_SIZE:
            {
                u32 size = payload & 0xffu;
                step_valid = size == 1 || size == 2 || size == 4 || size == 8;
                if (step_valid) operands[operand_index] = machine_x64_exact_gpr_operand(operand_registers[operand_slot], (u16)(size * 8u));
            }
            break;
            case MACHINE_X64_EXACT_OPERAND_ZMM_SLOT:
                step_valid = operand_registers[operand_slot] >= MACHINE_X64_ZMM0 && operand_registers[operand_slot] < MACHINE_X64_ZMM0 + 32;
                if (step_valid)
                {
                    operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                        .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = width,
                        .reg = {.index = (u16)(operand_registers[operand_slot] - MACHINE_X64_ZMM0), .width = width,
                                .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_ZMM}};
                }
                break;
            case MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K1:
                operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                    .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = 64,
                    .reg = {.index = (u16)predicate_register, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_MASK}};
                break;
            case MACHINE_X64_EXACT_OPERAND_MASK_FIXED_K0:
                operands[operand_index] = (BusterX86MetadataPhysicalOperand){
                    .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_REGISTER, .width = 64,
                    .reg = {.index = 0, .width = 64, .physical_class = BUSTER_X86_METADATA_PHYSICAL_CLASS_MASK}};
                break;
            case MACHINE_X64_EXACT_OPERAND_FIXED_RSP:
                operands[operand_index] = machine_x64_exact_gpr_operand(MACHINE_X64_RSP, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_PAYLOAD:
                operands[operand_index] = machine_x64_exact_immediate_operand((s64)(s32)payload, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_CONSTANT:
                operands[operand_index] = machine_x64_exact_unsigned_immediate_operand(payload, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_IMMEDIATE_LESS:
                operands[operand_index] = machine_x64_exact_unsigned_immediate_operand(1, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_RELATIVE_ZERO:
                operands[operand_index] = machine_x64_exact_relative_operand(0, width);
                break;
            case MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_ZERO:
                operands[operand_index] = machine_x64_exact_memory_operand(operand_registers[operand_slot], width, 0, false);
                break;
            case MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD_SIZE:
            {
                u32 size = payload & 0xffu;
                step_valid = size == 1 || size == 2 || size == 4 || size == 8;
                if (step_valid) operands[operand_index] = machine_x64_exact_memory_operand(operand_registers[operand_slot], (u16)(size * 8u), 0, false);
            }
            break;
            case MACHINE_X64_EXACT_OPERAND_MEMORY_BASE_PAYLOAD:
                operands[operand_index] = machine_x64_exact_memory_operand(operand_registers[operand_slot], width, (s64)(s32)payload, false);
                break;
            default:
                step_valid = false;
                break;
            }
            if (!step_valid) break;
        }
        BusterX86MetadataMachineExactToken step_token = entry->sequence_tokens[step_slot];
        if (!step_templated && sequence->recipe == MACHINE_EMIT_RECIPE_FAMILY_BASE + 45 &&
            (step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_ONLY) && parity_mode != 1)
        {
            step_valid = step_valid && machine_x64_fcmp_alternate_tokens_valid;
            if (step_valid)
            {
                step_token = (step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_PARITY_OR) ? machine_x64_fcmp_or_token : machine_x64_fcmp_setp_token;
            }
        }
        bool step_emitted = step_templated
                                ? step_template == MACHINE_X64_FIXED_TEMPLATE_EMITTED
                                : step_valid && machine_x64_emit_exact_form(
                                                    encoder,
                                                    step_token,
                                                    operands, step->operand_count, force_disp32,
                                                    (step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_FORCE_LOCK) != 0,
                                                    allocated_predicate && step->mask_register_plus_one ? (u8)(predicate_register + 1) : step->mask_register_plus_one, step->zeroing, counters);
        if (!step_emitted)
        {
            encoder->count = sequence_start;
            if (counters && step_valid == false) counters->fallbacks += 1;
            return false;
        }
        if (step->flags & MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP)
        {
            u8 branch_slot = step->operand_slots[0];
            if (!instruction || branch_slot >= 4 || machine_ref_kind(instruction->operands[branch_slot]) != MACHINE_REF_BLOCK)
            {
                encoder->count = sequence_start;
                if (counters) counters->fallbacks += 1;
                return false;
            }
            MachineX64BranchFixup* fixup = (MachineX64BranchFixup*)machine_stream_append(arena, fixups);
            *fixup = (MachineX64BranchFixup){
                .patch_offset = step_start + (step->key.form_id == MACHINE_X64_JMP_EXACT_FORM_ID ? 1u : 2u),
                .block = machine_ref_payload(instruction->operands[branch_slot]),
            };
        }
    }
    (void)placement;
    (void)immediate_value;
    return true;
}

// Sized chunk moves shared by the aggregate copy loops, chunked 8/4/2/1
// exactly like the canonical copy code: narrow loads zero-extend through
// movzx, narrow stores write their exact width.
BUSTER_GLOBAL_LOCAL u32 machine_x64_copy_chunk(u64 remaining)
{
    return remaining >= 8 ? 8 : remaining >= 4 ? 4 : remaining >= 2 ? 2 : 1;
}

BUSTER_GLOBAL_LOCAL u16 machine_x64_predicate_legacy_opcode(u16 opcode)
{
    u16 result = opcode;
    switch (opcode)
    {
        case MACHINE_X64_VPCMP_K: result = MACHINE_X64_VPCMP_MASK; break;
        case MACHINE_X64_VPMOVB2K: result = MACHINE_X64_VPMOVB2M; break;
        case MACHINE_X64_VLOAD_PTR_K: result = MACHINE_X64_VLOAD_PTR_MASKED; break;
        case MACHINE_X64_VSTORE_PTR_K: result = MACHINE_X64_VSTORE_PTR_MASKED; break;
        case MACHINE_X64_VCOMPRESS_STORE_PTR_K: result = MACHINE_X64_VCOMPRESS_STORE_PTR; break;
        case MACHINE_X64_VPERMT2B_K: result = MACHINE_X64_VPERMT2B; break;
        case MACHINE_X64_VCOMPRESSB_K: result = MACHINE_X64_VCOMPRESSB; break;
        default: break;
    }
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_predicate_row(MachineX64Encoder* encoder, MachineInstruction const* instruction, u8 const* regs)
{
    u32 width = instruction->payload ? instruction->payload : 64;
    String8 name = width <= 8 ? S8("KMOVB") : width <= 16 ? S8("KMOVW") : width <= 32 ? S8("KMOVD") : S8("KMOVQ");
    u32 count = 2;
    BusterX86MetadataPhysicalOperand operands[3];
    for (u32 slot = 0; slot < 3; slot += 1)
        operands[slot] = regs[slot] >= MACHINE_PREDICATE_REGISTER_BASE ? machine_x64_predicate_operand(regs[slot] - MACHINE_PREDICATE_REGISTER_BASE)
            : machine_x64_exact_gpr_operand(regs[slot], width > 32 ? 64 : 32);
    switch (instruction->opcode)
    {
        case MACHINE_X64_KAND: name = S8("KANDQ"); count = 3; break;
        case MACHINE_X64_KOR: name = S8("KORQ"); count = 3; break;
        case MACHINE_X64_KXOR: name = S8("KXORQ"); count = 3; break;
        default: break;
    }
    return machine_x64_emit_metadata_instruction(encoder, name, operands, count,
        (BusterX86MetadataFeatureInput){.names = machine_x64_predicate_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_predicate_features)},
        (BusterX86MetadataPhysicalAttributes){0}, 0);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_predicate_constant(MachineX64Encoder* encoder, u32 reg, u64 value)
{
    BusterX86MetadataPhysicalOperand operand = machine_x64_predicate_operand(reg - MACHINE_PREDICATE_REGISTER_BASE);
    BusterX86MetadataPhysicalOperand operands[] = {operand, operand, operand};
    return machine_x64_emit_metadata_instruction(encoder, value ? S8("KXNORQ") : S8("KXORQ"), operands, 3,
        (BusterX86MetadataFeatureInput){.names = machine_x64_predicate_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_predicate_features)},
        (BusterX86MetadataPhysicalAttributes){0}, 0);
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_predicate_frame(MachineX64Encoder* encoder, u32 reg, u32 frame, bool store)
{
    BusterX86MetadataPhysicalOperand operands[2];
    operands[store ? 1 : 0] = machine_x64_predicate_operand(reg - MACHINE_PREDICATE_REGISTER_BASE);
    operands[store ? 0 : 1] = machine_x64_exact_memory_operand(MACHINE_X64_RBP, 64, -(s64)frame, true);
    return machine_x64_emit_metadata_instruction(encoder, S8("KMOVQ"), operands, 2,
        (BusterX86MetadataFeatureInput){.names = machine_x64_predicate_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_predicate_features)},
        (BusterX86MetadataPhysicalAttributes){0}, 0);
}

// Allocation edits are already a compact point-sorted command stream. Keep
// their interpretation outside the machine-row dispatcher so the common row
// path does not duplicate spill/reload/copy/rematerialization policy around
// every instruction.
BUSTER_GLOBAL_LOCAL BUSTER_INLINE u32 machine_x64_emit_edit_run(MachineX64Encoder* encoder, MachineFunction* function,
                                                                MachineStackPlacement* placement, u32 edit_cursor,
                                                                MachinePoint point, bool default_store)
{
    while (edit_cursor < placement->edit_count && placement->edits[edit_cursor].point == point)
    {
        MachineEdit* edit = placement->edits + edit_cursor;
        bool predicate_location = edit->location >= MACHINE_PREDICATE_REGISTER_BASE;
        bool vector_location = edit->location >= MACHINE_X64_ZMM0 && !predicate_location;
        if (edit->kind == MACHINE_EDIT_COPY)
        {
            if (predicate_location)
            {
                u8 regs[4] = {(u8)edit->location, (u8)edit->subject, 0, 0};
                (void)machine_x64_emit_predicate_row(encoder, &(MachineInstruction){.opcode = MACHINE_X64_KMOV, .payload = 64}, regs);
            }
            else if (vector_location)
            {
                (void)machine_x64_emit_metadata_zmm_registers(
                    encoder, S8("VMOVDQU8"), edit->location - MACHINE_X64_ZMM0, edit->subject - MACHINE_X64_ZMM0, 512,
                    (BusterX86MetadataFeatureInput){.names = machine_x64_avx512_features,
                                                   .count = BUSTER_ARRAY_LENGTH(machine_x64_avx512_features)},
                    0);
            }
            else
            {
                (void)machine_x64_emit_exact_register_copy(encoder, edit->location, edit->subject, 0);
            }
        }
        else if (edit->kind == MACHINE_EDIT_REMATERIALIZE)
        {
            if (predicate_location) (void)machine_x64_emit_predicate_constant(encoder, edit->location, function->immediates[edit->subject]);
            else (void)machine_x64_emit_exact_immediate_value(encoder, edit->location, function->immediates[edit->subject], 0);
        }
        else
        {
            bool temporary = edit->kind == MACHINE_EDIT_TEMP_SPILL || edit->kind == MACHINE_EDIT_TEMP_RELOAD;
            bool store = edit->kind == MACHINE_EDIT_FRAME_SPILL || edit->kind == MACHINE_EDIT_SPILL || edit->kind == MACHINE_EDIT_TEMP_SPILL ||
                         (edit->kind != MACHINE_EDIT_FRAME_RELOAD && edit->kind != MACHINE_EDIT_RELOAD && edit->kind != MACHINE_EDIT_TEMP_RELOAD && default_store);
            bool direct_frame = edit->kind == MACHINE_EDIT_FRAME_SPILL || edit->kind == MACHINE_EDIT_FRAME_RELOAD;
            u32 frame_offset = direct_frame ? edit->subject : temporary ? placement->edge_copy_temporary_offset + edit->subject
                                         : placement->virtual_register_offsets[edit->subject];
            if (predicate_location)
            {
                (void)machine_x64_emit_predicate_frame(encoder, edit->location, frame_offset, store);
            }
            else if (vector_location)
            {
                (void)machine_x64_emit_metadata_zmm_memory(
                    encoder, S8("VMOVDQU8"), edit->location - MACHINE_X64_ZMM0, MACHINE_X64_RBP,
                    -(s64)(s32)frame_offset, store, 512, 8,
                    (BusterX86MetadataFeatureInput){.names = machine_x64_avx512_features,
                                                   .count = BUSTER_ARRAY_LENGTH(machine_x64_avx512_features)},
                    0);
            }
            else
            {
                (void)machine_x64_emit_exact_frame_chunk(
                    encoder, !store, edit->location, frame_offset, 8, 0);
            }
        }
        edit_cursor += 1;
    }
    return edit_cursor;
}

BUSTER_GLOBAL_LOCAL bool machine_x64_emit_x87(MachineX64Encoder* encoder, String8 mnemonic,
                                                BusterX86MetadataPhysicalOperand const* operands, u32 count)
{
    return machine_x64_emit_metadata_instruction(encoder, mnemonic, operands, count,
        (BusterX86MetadataFeatureInput){.names = machine_x64_sse2_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_sse2_features)},
        (BusterX86MetadataPhysicalAttributes){0}, 0);
}

BUSTER_GLOBAL_LOCAL void machine_x64_emit_x87_memory(MachineX64Encoder* encoder, String8 mnemonic, s32 displacement, u16 width)
{
    BusterX86MetadataPhysicalOperand operand = machine_x64_exact_rbp_memory_operand(displacement, width, true);
    (void)machine_x64_emit_x87(encoder, mnemonic, &operand, 1);
}

BUSTER_GLOBAL_LOCAL void machine_x64_emit_f80_padding(MachineX64Encoder* encoder, s32 displacement)
{
    (void)machine_x64_emit_metadata_memory_immediate(encoder, S8("MOV"), MACHINE_X64_RBP, displacement + 10, 0, 16, 16, 0);
    (void)machine_x64_emit_metadata_memory_immediate(encoder, S8("MOV"), MACHINE_X64_RBP, displacement + 12, 0, 32, 32, 0);
}

// Every arithmetic/conversion sequence balances its own x87 stack and keeps
// the caller's precision/rounding control. C integer casts temporarily select
// truncation using baseline FISTP; SSE3 FISTTP is not assumed available.
BUSTER_GLOBAL_LOCAL void machine_x64_emit_f80(MachineX64Encoder* encoder, MachineInstruction* instruction, MachineStackPlacement* placement)
{
    s32 offsets[3] = {0};
    bool compare = instruction->opcode == MACHINE_X64_F80_COMPARE;
    u32 count = instruction->opcode == MACHINE_X64_F80_BINARY || compare || instruction->opcode == MACHINE_X64_F80_CONVERT ? 3u :
                instruction->opcode == MACHINE_X64_F80_NEGATE ? 2u : 1u;
    for (u32 operand = compare ? 1u : 0u; operand < count; operand += 1)
    {
        offsets[operand] = -(s32)placement->stack_slot_offsets[machine_ref_payload(instruction->operands[operand])];
    }
    if (instruction->opcode == MACHINE_X64_F80_BINARY)
    {
        String8 names[] = {S8("FADDP"), S8("FSUBP"), S8("FMULP"), S8("FDIVP")};
        u32 mode = instruction->payload;
        bool controlled = mode >= MACHINE_X64_F80_ADD_P24;
        u32 operation = mode == MACHINE_X64_F80_MULTIPLY_P64 ? MACHINE_X64_F80_MULTIPLY :
                        mode == MACHINE_X64_F80_SUBTRACT_P64 ? MACHINE_X64_F80_SUBTRACT : controlled ? MACHINE_X64_F80_ADD : mode;
        u32 precision = mode == MACHINE_X64_F80_ADD_P24 ? 0u : mode == MACHINE_X64_F80_ADD_P53 ? 0x200u : 0x300u;
        if (controlled)
        {
            // The six padding bytes in the destination frame hold the saved
            // and temporary control words until this closed transaction ends.
            machine_x64_emit_x87_memory(encoder, S8("FNSTCW"), offsets[0] + 10, 16);
            (void)machine_x64_emit_metadata_register_memory(encoder, S8("MOVZX"), MACHINE_X64_RAX, MACHINE_X64_RBP,
                                                           offsets[0] + 10, 64, 16, 0);
            (void)machine_x64_emit_metadata_register_immediate(encoder, S8("AND"), MACHINE_X64_RAX, ~UINT32_C(0x300), 32, 32, 0);
            if (precision)
            {
                (void)machine_x64_emit_metadata_register_immediate(encoder, S8("OR"), MACHINE_X64_RAX, precision, 32, 32, 0);
            }
            (void)machine_x64_emit_metadata_memory_register(encoder, S8("MOV"), MACHINE_X64_RBP, offsets[0] + 12,
                                                           MACHINE_X64_RAX, 16, 16, 0);
            machine_x64_emit_x87_memory(encoder, S8("FLDCW"), offsets[0] + 12, 16);
        }
        machine_x64_emit_x87_memory(encoder, S8("FLD"), offsets[1], 80);
        machine_x64_emit_x87_memory(encoder, S8("FLD"), offsets[2], 80);
        BusterX86MetadataPhysicalOperand operands[] = {machine_x64_x87_operand(1), machine_x64_x87_operand(0)};
        (void)machine_x64_emit_x87(encoder, names[operation], operands, 1);
        machine_x64_emit_x87_memory(encoder, S8("FSTP"), offsets[0], 80);
        if (controlled)
        {
            machine_x64_emit_x87_memory(encoder, S8("FLDCW"), offsets[0] + 10, 16);
        }
        machine_x64_emit_f80_padding(encoder, offsets[0]);
    }
    else if (instruction->opcode == MACHINE_X64_F80_NEGATE)
    {
        machine_x64_emit_x87_memory(encoder, S8("FLD"), offsets[1], 80);
        (void)machine_x64_emit_x87(encoder, S8("FCHS"), 0, 0);
        machine_x64_emit_x87_memory(encoder, S8("FSTP"), offsets[0], 80);
        machine_x64_emit_f80_padding(encoder, offsets[0]);
    }
    else if (compare)
    {
        machine_x64_emit_x87_memory(encoder, S8("FLD"), offsets[2], 80);
        machine_x64_emit_x87_memory(encoder, S8("FLD"), offsets[1], 80);
        BusterX86MetadataPhysicalOperand operands[] = {machine_x64_x87_operand(0), machine_x64_x87_operand(1)};
        (void)machine_x64_emit_x87(encoder, S8("FUCOMIP"), operands + 1, 1);
        (void)machine_x64_emit_x87(encoder, S8("FSTP"), operands, 1);
        String8 names[] = {S8("SETZ"), S8("SETNZ"), S8("SETB"), S8("SETBE"), S8("SETNBE"), S8("SETNB")};
        (void)machine_x64_emit_metadata_register(encoder, names[instruction->payload], MACHINE_X64_RAX, 8, 0);
        if (instruction->payload < 4)
        {
            bool unequal = instruction->payload == 1;
            (void)machine_x64_emit_metadata_register(encoder, unequal ? S8("SETP") : S8("SETNP"), MACHINE_X64_RCX, 8, 0);
            (void)machine_x64_emit_metadata_registers(encoder, unequal ? S8("OR") : S8("AND"), MACHINE_X64_RAX, MACHINE_X64_RCX, 8, 0);
        }
        BusterX86MetadataPhysicalOperand extend[] = {machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 64), machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 8)};
        (void)machine_x64_emit_metadata_instruction(encoder, S8("MOVZX"), extend, 2, (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
    }
    else if (instruction->opcode == MACHINE_X64_F80_CONVERT)
    {
        u32 mode = instruction->payload;
        bool to_f80 = mode == 0 || mode == 1 || mode == 4;
        u16 source_width = (u16)(mode == 0 ? 32 : mode == 1 || mode == 4 ? 64 : 80);
        u16 result_width = (u16)(to_f80 ? 80 : mode == 2 ? 32 : 64);
        if (mode == 5)
        {
            machine_x64_emit_x87_memory(encoder, S8("FNSTCW"), offsets[2], 16);
            (void)machine_x64_emit_metadata_register_memory(encoder, S8("MOVZX"), MACHINE_X64_RAX, MACHINE_X64_RBP, offsets[2], 64, 16, 0);
            (void)machine_x64_emit_metadata_register_immediate(encoder, S8("OR"), MACHINE_X64_RAX, 0x0c00, 32, 32, 0);
            (void)machine_x64_emit_metadata_memory_register(encoder, S8("MOV"), MACHINE_X64_RBP, offsets[2] + 2, MACHINE_X64_RAX, 16, 16, 0);
            machine_x64_emit_x87_memory(encoder, S8("FLDCW"), offsets[2] + 2, 16);
        }
        machine_x64_emit_x87_memory(encoder, mode == 4 ? S8("FILD") : S8("FLD"), offsets[1], source_width);
        machine_x64_emit_x87_memory(encoder, mode == 5 ? S8("FISTP") : S8("FSTP"), offsets[0], result_width);
        if (mode == 5)
        {
            machine_x64_emit_x87_memory(encoder, S8("FLDCW"), offsets[2], 16);
        }
        if (to_f80)
        {
            machine_x64_emit_f80_padding(encoder, offsets[0]);
        }
        else if (mode == 2)
        {
            (void)machine_x64_emit_metadata_memory_immediate(encoder, S8("MOV"), MACHINE_X64_RBP, offsets[0] + 4, 0, 32, 32, 0);
        }
    }
    else
    {
        bool load = instruction->opcode == MACHINE_X64_F80_RESULT_LOAD;
        bool is_f64_result = instruction->payload == 8 || instruction->payload == 24;
        offsets[0] += (s32)(instruction->payload & ~8u);
        machine_x64_emit_x87_memory(encoder, load ? S8("FLD") : S8("FSTP"), offsets[0], (u16)(is_f64_result ? 64 : 80));
        if (!load && !is_f64_result)
        {
            machine_x64_emit_f80_padding(encoder, offsets[0]);
        }
    }
}

MachineEncodeResult machine_encode_x86_64(Arena* arena, MachineFunction* function, MachineStackPlacement* placement)
{
    MachineEncodeResult result = {0};
    if (!placement->valid)
    {
        return result;
    }
    // Per-row worst-case byte budget, read from the published opcode row
    // rather than re-derived by a switch: the budget is a function of the
    // opcode, so it is table content. Switches and aggregate copies are the
    // only rows whose budget also depends on their own side data, and they
    // are 2% of the stream, so their arm is a predicted-not-taken branch
    // instead of a nine-way dispatch on every one of 1,7 M rows.
    MachineOpcodeRow const* opcode_rows = machine_opcode_row_table();
    u64 capacity64 = 64;
    bool dynamic_stack = false;
    for (u32 capacity_index = 0; capacity_index < function->instruction_count; capacity_index += 1)
    {
        MachineInstruction* capacity_row = function->instructions + capacity_index;
        MachineOpcodeRow row = opcode_rows[capacity_row->opcode];
        dynamic_stack |= capacity_row->opcode == MACHINE_X64_STACK_ALLOCATE;
        capacity64 += row.encode_budget;
        if (capacity_row->opcode == MACHINE_X64_INLINE_ASSEMBLY && capacity_row->payload < function->inline_assembly_count)
        {
            MachineInlineAssembly const* assembly = function->inline_assemblies + capacity_row->payload;
            u64 paths = (assembly->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR) ? (u64)assembly->relocation_count + 1u : 1u;
            u16 preserved_vector_mask = function->target == machine_target_x86_64_windows()
                                            ? (u16)((assembly->clobber_mask >> MACHINE_X64_ZMM0) &
                                                    MACHINE_INLINE_ASSEMBLY_WIN64_PRESERVED_VECTOR_MASK)
                                            : 0;
            u32 preserved_vector_count = 0;
            for (u32 vector_register = 6; vector_register < 16; vector_register += 1)
            {
                preserved_vector_count += ((u32)preserved_vector_mask >> vector_register) & 1u;
            }
            capacity64 += assembly->bytes.length +
                          paths * ((u64)assembly->operand_count * 24u + (u64)preserved_vector_count * 24u + 16u);
        }
        if (BUSTER_UNLIKELY((row.flags & MACHINE_OPCODE_ROW_VARIABLE_BUDGET) != 0))
        {
            capacity64 += capacity_row->opcode == MACHINE_X64_SWITCH ? (u64)capacity_row->flags * 24u : ((u64)capacity_row->payload / 8u) * 24u;
        }
    }
    // The fixed frame is reserved in the prologue, independently of any
    // MIR STACK_ALLOCATE row.  Each touched page emits a SUB plus a probe, so
    // account for that bounded prefix even for small functions with a large
    // spill frame; otherwise a valid placement can truncate before its first
    // machine row.
    bool windows_frame_probe = function->target && function->target->saves_precede_frame_pointer &&
                               placement->frame_size > CODEGEN_X64_STACK_PROBE_PAGE;
    u64 frame_probe_chunks = ((u64)placement->frame_size + CODEGEN_X64_STACK_PROBE_PAGE - 1u) / CODEGEN_X64_STACK_PROBE_PAGE;
    capacity64 += windows_frame_probe ? 64u : frame_probe_chunks * 24u;
    // Vector spill and reload edits are ten bytes (EVEX plus disp32).
    capacity64 += (u64)placement->edit_count * 12;
    if (capacity64 > UINT32_MAX)
    {
        return result;
    }
    MachineX64Encoder encoder = {
        .bytes = arena_allocate(arena, u8, capacity64),
        .capacity = (u32)capacity64,
    };
    MachineX64ExactEmitCounters exact_counters = {0};
    // Functions that touch the vector file end their AVX-512 regions with
    // vzeroupper at every call and return, matching the transition hygiene
    // the canonical vector paths keep; all vector values are dead at those
    // points — the scan flushed them — and the low XMM halves the float ABI
    // uses survive vzeroupper untouched. ZMM16-31 sit outside vzeroupper's
    // reach entirely (it clears bits 128+ of the VEX-visible ymm0-15 only,
    // and the high file has no legacy or VEX encodings to transition
    // against), so the policy is unchanged by the widened file — the high
    // registers still flush at calls through the caller-saved contract.
    bool function_has_vector = false;
    for (u32 vector_scan = 0; vector_scan < function->virtual_register_count; vector_scan += 1)
    {
        function_has_vector |= function->virtual_registers[vector_scan].register_class == MACHINE_REGISTER_CLASS_VECTOR;
    }
    MachineBuilderStream fixups;
    machine_stream_initialize(&fixups, sizeof(MachineX64BranchFixup));
    MachineBuilderStream call_sites;
    machine_stream_initialize(&call_sites, sizeof(MachineCallSite));
    MachineBuilderStream inline_assembly_relocations;
    machine_stream_initialize(&inline_assembly_relocations, sizeof(MachineInlineAssemblyRelocation));
    u32 control_relocation_count = 0;
    for (u32 relocation_index = 0; relocation_index < function->inline_assembly_relocation_count; relocation_index += 1)
    {
        control_relocation_count += function->inline_assembly_relocations[relocation_index].is_control != 0;
    }
    s64* block_addends = control_relocation_count ? arena_allocate(arena, s64, function->block_count) : 0;
    u32* block_addend_targets = control_relocation_count ? arena_allocate(arena, u32, function->block_count) : 0;
    if (control_relocation_count)
    {
        memset(block_addends, 0, sizeof(*block_addends) * function->block_count);
        memset(block_addend_targets, 0xff, sizeof(*block_addend_targets) * function->block_count);
    }
    for (u32 relocation_index = 0; relocation_index < function->inline_assembly_relocation_count; relocation_index += 1)
    {
        MachineInlineAssemblyRelocation* relocation = function->inline_assembly_relocations + relocation_index;
        if (!relocation->is_control)
        {
            continue;
        }
        if (relocation->continuation_block >= function->block_count || block_addend_targets[relocation->continuation_block] != UINT32_MAX)
        {
            encoder.overflow = true;
            continue;
        }
        block_addends[relocation->continuation_block] = relocation->addend;
        block_addend_targets[relocation->continuation_block] = relocation->block;
    }
    result.block_offsets = arena_allocate(arena, u32, function->block_count);
    result.row_offsets = arena_allocate(arena, u32, function->instruction_count ? function->instruction_count : 1);
    // Prologue: the frame base is RBP, matching the canonical path, and
    // the placement's callee-saved registers push right after it in fixed
    // RBX, R14, R15 order so the unwind actions can name exact offsets.
    bool saves_first = function->target && function->target->saves_precede_frame_pointer;
    bool windows_dynamic_stack = saves_first && dynamic_stack;
    if (windows_dynamic_stack && placement->frame_size > INT32_MAX)
    {
        return result;
    }
    machine_x64_emit_fixed_register(&encoder, MACHINE_X64_FIXED_TEMPLATE_PUSH + MACHINE_X64_RBP, S8("PUSH"), MACHINE_X64_RBP, 64);
    if (!saves_first)
    {
        machine_x64_emit_fixed_registers(&encoder, MACHINE_X64_FIXED_TEMPLATE_MOV_RBP_RSP, S8("MOV"), MACHINE_X64_RBP, MACHINE_X64_RSP, 64);
    }
    // Ascending register order, which is RBX, R12-R15 under System V and
    // gains RSI and RDI under Win64; the unwind actions walk the same mask
    // the same way, so their offsets stay exact under either file.
    for (u32 push_register = 0; push_register < MACHINE_X64_ZMM0; push_register += 1)
    {
        if (placement->callee_saved_mask & (1ull << push_register))
        {
            machine_x64_emit_fixed_register(&encoder, MACHINE_X64_FIXED_TEMPLATE_PUSH + push_register, S8("PUSH"), push_register, 64);
        }
    }
    if (saves_first && !windows_dynamic_stack)
    {
        // The frame pointer lands below the saves, so they sit at its
        // positive offsets. Its fixed epilogue adds back the allocation.
        machine_x64_emit_fixed_registers(&encoder, MACHINE_X64_FIXED_TEMPLATE_MOV_RBP_RSP, S8("MOV"), MACHINE_X64_RBP, MACHINE_X64_RSP, 64);
    }
    // The stack allocation mirrors the canonical chunked form: at most a
    // page per subtract with a probe touch after each, so a frame larger
    // than the guard page cannot skip it.
    u32 frame_remaining = placement->frame_size;
    if (windows_frame_probe)
    {
        // Reuse the direct emitter's bounded Win64 probe. Its R10/R11
        // scratch does not disturb incoming integer, float or hidden-result
        // arguments, and RSP changes only at the final allocation instruction.
        CodegenBuffer probe = {.bytes = encoder.bytes, .count = encoder.count, .capacity = encoder.capacity};
        (void)codegen_x64_emit_windows_stack_allocate(&probe, frame_remaining, 0, 0, 0);
        encoder.count = (u32)probe.count;
        encoder.overflow |= probe.error != CODEGEN_ERROR_NONE;
        result.frame_allocation_offset = encoder.count;
        frame_remaining = 0;
    }
    while (frame_remaining)
    {
        u32 frame_chunk = BUSTER_MIN(frame_remaining, CODEGEN_X64_STACK_PROBE_PAGE);
        bool frame_chunk_byte = frame_chunk <= INT8_MAX;
        if (machine_x64_emit_fixed_template(&encoder,
                                            frame_chunk_byte ? MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM8 : MACHINE_X64_FIXED_TEMPLATE_SUB_RSP_IMM32,
                                            frame_chunk) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
        {
            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("SUB"), MACHINE_X64_RSP, frame_chunk, 64,
                                                               frame_chunk_byte ? 8 : 32, 0);
        }
        if (machine_x64_emit_fixed_template(&encoder, MACHINE_X64_FIXED_TEMPLATE_PROBE, 0) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
        {
            (void)machine_x64_emit_metadata_memory_immediate(&encoder, S8("TEST"), MACHINE_X64_RSP, 0, 0, 8, 8, 0);
        }
        frame_remaining -= frame_chunk;
    }
    if (windows_dynamic_stack)
    {
        machine_x64_emit_fixed_registers(&encoder, MACHINE_X64_FIXED_TEMPLATE_MOV_RBP_RSP, S8("MOV"), MACHINE_X64_RBP, MACHINE_X64_RSP, 64);
        BUSTER_CHECK(encoder.count <= UINT8_MAX);
        result.frame_pointer_offset = (u8)encoder.count;
        encoder.frame_base_offset = placement->frame_size;
    }
    u32 edit_cursor = 0;
    for (u32 block_index = 0; block_index < function->block_count; block_index += 1)
    {
        MachineBlock* block = function->blocks + block_index;
        result.block_offsets[block_index] = encoder.count;
        for (u32 offset = 0; offset < block->instruction_count; offset += 1)
        {
            u32 instruction_index = block->first_instruction + offset;
            MachineInstruction* instruction = function->instructions + instruction_index;
            u8 const* operand_registers = placement->operand_registers + (u64)instruction_index * 4;
            result.row_offsets[instruction_index] = encoder.count;
            MachinePoint before = machine_point_make(instruction_index, MACHINE_POINT_BEFORE);
            if (edit_cursor < placement->edit_count && placement->edits[edit_cursor].point == before)
            {
                edit_cursor = machine_x64_emit_edit_run(&encoder, function, placement, edit_cursor, before, false);
            }
            MachineX64PreparedExactOpcode const* exact_entry = machine_x64_exact_opcode_for_opcode(machine_x64_predicate_legacy_opcode(instruction->opcode));
            bool exact_required = exact_entry && exact_entry->exact_required;
            if (exact_required)
            {
                u32 exact_start = encoder.count;
                u64 exact_immediate = 0;
                bool exact_immediate_valid = true;
                if (instruction->opcode == MACHINE_X64_MOV_RI || instruction->opcode == MACHINE_X64_ADD64_IMM || instruction->opcode == MACHINE_X64_IMUL64_RRI)
                {
                    u32 immediate_operand = instruction->opcode == MACHINE_X64_IMUL64_RRI ? 2u : 1u;
                    if (machine_ref_kind(instruction->operands[immediate_operand]) == MACHINE_REF_IMMEDIATE &&
                        machine_ref_payload(instruction->operands[immediate_operand]) < function->immediate_count)
                    {
                        exact_immediate = function->immediates[machine_ref_payload(instruction->operands[immediate_operand])];
                    }
                    else
                    {
                        exact_immediate_valid = false;
                    }
                }
                else if (instruction->opcode == MACHINE_X64_ADD_RSP)
                {
                    // ADD_RSP carries its immediate directly in the row
                    // payload (there is no MACHINE_REF_IMMEDIATE operand).
                    exact_immediate = instruction->payload;
                }
                bool exact_emitted = false;
                if (!exact_immediate_valid)
                {
                    exact_counters.attempts += 1;
                    exact_counters.fallbacks += 1;
                }
                else
                {
                    exact_emitted = exact_entry->sequence_required
                                         ? machine_x64_emit_exact_sequence(&encoder, exact_entry, instruction, placement, operand_registers,
                                                                           instruction->payload, exact_immediate, &exact_counters, arena, &fixups)
                                         : machine_x64_emit_exact_recipe(&encoder, exact_entry, instruction, placement, operand_registers,
                                                                         instruction->payload, exact_immediate, false, &exact_counters);
                }
                if (!exact_entry)
                {
                    // A registry row marked EXACT_FORM is itself an exact
                    // attempt even when its descriptor projection is absent
                    // or stale. Count that fail-closed event so the
                    // per-function invariant remains attempts = successes +
                    // failures while refusing to re-enter the legacy switch.
                    exact_counters.attempts += 1;
                    exact_counters.fallbacks += 1;
                }
                if (!exact_emitted)
                {
                    // Migrated DIRECT rows have no handwritten byte fallback:
                    // an exact-form failure invalidates this result so the
                    // caller's existing codegen fallback accounting remains
                    // authoritative.
                    encoder.overflow = true;
                }
                else if (exact_entry->descriptor)
                {
                    // Relative and symbolic forms deliberately query the
                    // metadata encoder with a neutral zero displacement. The
                    // existing machine fixup/call-site streams remain the
                    // owner of target resolution, preserving their canonical
                    // offsets and relocation semantics.
                    if (exact_entry->descriptor->flags & MACHINE_X64_EXACT_RECIPE_FLAG_BRANCH_FIXUP)
                    {
                        MachineX64BranchFixup* fixup = (MachineX64BranchFixup*)machine_stream_append(arena, &fixups);
                        *fixup = (MachineX64BranchFixup){
                            .addend = block_addend_targets &&
                                              block_addend_targets[block_index] == machine_ref_payload(instruction->operands[0])
                                          ? block_addends[block_index]
                                          : 0,
                            .patch_offset = exact_start + 1,
                            .block = machine_ref_payload(instruction->operands[0]),
                        };
                    }
                    if (exact_entry->descriptor->flags & MACHINE_X64_EXACT_RECIPE_FLAG_CALL_SITE)
                    {
                        MachineCallSite* site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *site = (MachineCallSite){
                            .code_offset = exact_start + 3,
                            .target = instruction->payload,
                        };
                    }
                }
            }
            else
            {
                switch (instruction->opcode)
                {
                    case MACHINE_X64_F80_BINARY:
                    case MACHINE_X64_F80_NEGATE:
                    case MACHINE_X64_F80_COMPARE:
                    case MACHINE_X64_F80_CONVERT:
                    case MACHINE_X64_F80_RESULT_LOAD:
                    case MACHINE_X64_F80_RESULT_STORE:
                        machine_x64_emit_f80(&encoder, instruction, placement);
                        break;
                    case MACHINE_X64_KMOV_FROM_GENERAL:
                    case MACHINE_X64_KMOV_TO_GENERAL:
                    case MACHINE_X64_KMOV:
                    case MACHINE_X64_KAND:
                    case MACHINE_X64_KOR:
                    case MACHINE_X64_KXOR:
                        (void)machine_x64_emit_predicate_row(&encoder, instruction, operand_registers);
                    break;
                    case MACHINE_X64_SDIV32:
                    case MACHINE_X64_SDIV64:
                    case MACHINE_X64_SREM32:
                    case MACHINE_X64_SREM64:
                    case MACHINE_X64_UDIV32:
                    case MACHINE_X64_UDIV64:
                    case MACHINE_X64_UREM32:
                    case MACHINE_X64_UREM64:
                    {
                        // Dividend and result live in RAX (operand slot 0); the
                        // divisor is in RCX (slot 1); RDX is clobbered, exactly like
                        // the canonical divide sequences.
                        bool wide = instruction->opcode == MACHINE_X64_SDIV64 || instruction->opcode == MACHINE_X64_SREM64 ||
                            instruction->opcode == MACHINE_X64_UDIV64 || instruction->opcode == MACHINE_X64_UREM64;
                        bool is_signed = instruction->opcode == MACHINE_X64_SDIV32 || instruction->opcode == MACHINE_X64_SDIV64 ||
                            instruction->opcode == MACHINE_X64_SREM32 || instruction->opcode == MACHINE_X64_SREM64;
                        bool remainder = instruction->opcode == MACHINE_X64_SREM32 || instruction->opcode == MACHINE_X64_SREM64 ||
                            instruction->opcode == MACHINE_X64_UREM32 || instruction->opcode == MACHINE_X64_UREM64;
                        u32 width_row = wide ? 1u : 0u;
                        u16 width = wide ? 64 : 32;
                        if (is_signed)
                        {
                            machine_x64_emit_fixed_instruction(&encoder, MACHINE_X64_FIXED_TEMPLATE_CDQ_CQO + width_row, wide ? S8("CQO") : S8("CDQ"),
                                                               (BusterX86MetadataFeatureInput){0});
                        }
                        else
                        {
                            machine_x64_emit_fixed_registers(&encoder, MACHINE_X64_FIXED_TEMPLATE_XOR_RDX_RDX + width_row, S8("XOR"),
                                                             MACHINE_X64_RDX, MACHINE_X64_RDX, width);
                        }
                        machine_x64_emit_fixed_register(&encoder,
                                                        (is_signed ? MACHINE_X64_FIXED_TEMPLATE_IDIV_RCX : MACHINE_X64_FIXED_TEMPLATE_DIV_RCX) + width_row,
                                                        is_signed ? S8("IDIV") : S8("DIV"), MACHINE_X64_RCX, width);
                        if (remainder)
                        {
                            machine_x64_emit_fixed_registers(&encoder, MACHINE_X64_FIXED_TEMPLATE_MOV_RAX_RDX + width_row, S8("MOV"),
                                                             MACHINE_X64_RAX, MACHINE_X64_RDX, width);
                        }
                    }
                    break; case MACHINE_X64_MULH64:
                    {
                        // `mul r/m64` writes RDX:RAX, and only the high half is
                        // wanted; the move back into RAX is the same one the
                        // remainder rows above make, and for the same reason --
                        // slot 0 says the answer is in RAX.
                        (void)machine_x64_emit_metadata_register(&encoder, S8("MUL"), MACHINE_X64_RCX, 64, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RAX, MACHINE_X64_RDX, 64, 0);
                    }
                    break; case MACHINE_X64_RET:
                    {
                        // No vzeroupper over a live 512-bit return: it would zero
                        // bits 128+ of the ZMM0 the caller is about to read.
                        if (function_has_vector && !(instruction->flags & MACHINE_X64_INSTRUCTION_FLAG_VECTOR_LIVE))
                        {
                            machine_x64_emit_fixed_vzeroupper(&encoder);
                        }
                        // Windows fixed-stack unwind records use RSP alone.
                        // Its epilogue grammar requires ADD RSP, constant (not
                        // MOV RSP, RBP), followed only by the saved-register pops.
                        if (windows_dynamic_stack)
                        {
                            // LEA restores from the bottom frame register plus
                            // the fixed allocation, a legal Windows epilogue.
                            (void)machine_x64_emit_metadata_register_memory(&encoder, S8("LEA"), MACHINE_X64_RSP, MACHINE_X64_RBP, 0, 64, 64, 0);
                        }
                        else if (saves_first && placement->frame_size)
                        {
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("ADD"), MACHINE_X64_RSP,
                                                                               placement->frame_size, 64,
                                                                               placement->frame_size <= INT8_MAX ? 8 : 32, 0);
                        }
                        if (placement->callee_saved_mask)
                        {
                            if (!saves_first)
                            {
                                u32 push_count = 0;
                                for (u32 push_register = 0; push_register < MACHINE_X64_REGISTER_COUNT; push_register += 1)
                                {
                                    push_count += (u32)((placement->callee_saved_mask >> push_register) & 1u);
                                }
                                // System V retains its frame-relative restore.
                                s64 frame_displacement = -(s64)(8u * push_count);
                                if (frame_displacement < INT8_MIN ||
                                    machine_x64_emit_fixed_template(&encoder, MACHINE_X64_FIXED_TEMPLATE_LEA_RSP_RBP_DISP8,
                                                                    (u8)frame_displacement) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
                                {
                                    (void)machine_x64_emit_metadata_register_memory(&encoder, S8("LEA"), MACHINE_X64_RSP, MACHINE_X64_RBP,
                                                                                    frame_displacement, 64, 64, 0);
                                }
                            }
                            for (u32 pop_reverse = MACHINE_X64_ZMM0; pop_reverse > 0; pop_reverse -= 1)
                            {
                                u32 pop_register = pop_reverse - 1;
                                if (placement->callee_saved_mask & (1ull << pop_register))
                                {
                                    machine_x64_emit_fixed_register(&encoder, MACHINE_X64_FIXED_TEMPLATE_POP + pop_register, S8("POP"), pop_register, 64);
                                }
                            }
                        }
                        else if (!saves_first)
                        {
                            machine_x64_emit_fixed_registers(&encoder, MACHINE_X64_FIXED_TEMPLATE_MOV_RSP_RBP, S8("MOV"),
                                                             MACHINE_X64_RSP, MACHINE_X64_RBP, 64);
                        }
                        machine_x64_emit_fixed_register(&encoder, MACHINE_X64_FIXED_TEMPLATE_POP + MACHINE_X64_RBP, S8("POP"), MACHINE_X64_RBP, 64);
                        machine_x64_emit_fixed_instruction(&encoder, MACHINE_X64_FIXED_TEMPLATE_RET, S8("RET"), (BusterX86MetadataFeatureInput){0});
                    }
                    break; case MACHINE_X64_CALL_DIRECT:
                    {
                        // No vzeroupper over staged ZMM arguments: the callee reads
                        // them whole, exactly like the canonical path, whose lazy
                        // vzeroupper fires before its call staging rather than after.
                        if (function_has_vector && !(instruction->flags & MACHINE_X64_INSTRUCTION_FLAG_VECTOR_LIVE))
                        {
                            machine_x64_emit_fixed_vzeroupper(&encoder);
                        }
                        if (instruction->flags & 1)
                        {
                            // Variadic System V call: AL carries the count of XMM
                            // registers holding arguments.
                            machine_x64_emit_fixed_xmm_count(&encoder, instruction->flags >> 1);
                        }
                        u32 call_start = encoder.count;
                        machine_x64_emit_fixed_relative(&encoder, MACHINE_X64_FIXED_TEMPLATE_CALL_REL32, S8("CALL"));
                        MachineCallSite* site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *site = (MachineCallSite){
                            .code_offset = call_start + 1,
                            .target = instruction->payload,
                        };
                    }
                    break; case MACHINE_X64_CALL_INDIRECT:
                    {
                        if (function_has_vector && !(instruction->flags & MACHINE_X64_INSTRUCTION_FLAG_VECTOR_LIVE))
                        {
                            machine_x64_emit_fixed_vzeroupper(&encoder);
                        }
                        if (instruction->flags & 1)
                        {
                            machine_x64_emit_fixed_xmm_count(&encoder, instruction->flags >> 1);
                        }
                        u32 target_register = operand_registers[0];
                        machine_x64_emit_fixed_register(&encoder,
                                                        machine_x64_fixed_template_family_row(MACHINE_X64_FIXED_TEMPLATE_CALL_REGISTER, target_register),
                                                        S8("CALL"), target_register, 64);
                    }
                    break; case MACHINE_X64_LEA_BLOCK:
                    {
                        u32 branch_start = encoder.count;
                        u32 destination = operand_registers[0];
                        machine_x64_emit_fixed_rip_register(&encoder,
                                                            machine_x64_fixed_template_family_row(MACHINE_X64_FIXED_TEMPLATE_LEA_RIP, destination),
                                                            S8("LEA"), destination);
                        MachineX64BranchFixup* fixup = (MachineX64BranchFixup*)machine_stream_append(arena, &fixups);
                        *fixup = (MachineX64BranchFixup){
                            .patch_offset = branch_start + 3,
                            .block = instruction->payload,
                            .label_address = true,
                        };
                    }
                    break; case MACHINE_X64_INDIRECT_BRANCH:
                    {
                        u32 target_register = operand_registers[0];
                        machine_x64_emit_fixed_register(&encoder,
                                                        machine_x64_fixed_template_family_row(MACHINE_X64_FIXED_TEMPLATE_JMP_REGISTER, target_register),
                                                        S8("JMP"), target_register, 64);
                    }
                    break; case MACHINE_X64_COMPILER_BARRIER:
                    case MACHINE_X64_ASM_IDENTITY:
                    break; case MACHINE_X64_NOP:
                    case MACHINE_X64_PAUSE:
                    {
                        // PAUSE is accepted at the baseline by the direct
                        // backend; its imported row still requires this name.
                        bool pause = instruction->opcode == MACHINE_X64_PAUSE;
                        (void)machine_x64_emit_metadata_instruction(&encoder, pause ? S8("PAUSE") : S8("NOP"), 0, 0,
                            (BusterX86MetadataFeatureInput){.names = machine_x64_pause_features, .count = pause ? 1u : 0u},
                            (BusterX86MetadataPhysicalAttributes){0}, 0);
                    }
                    break; case MACHINE_X64_INLINE_EFFECTS_NONE:
                    case MACHINE_X64_INLINE_EFFECTS_MEMORY:
                    case MACHINE_X64_INLINE_EFFECTS_FLAGS:
                    case MACHINE_X64_INLINE_EFFECTS_MEMORY_FLAGS:
                    {
                        if (instruction->payload)
                        {
                            bool pause = instruction->payload == 2;
                            bool valid_payload = instruction->payload == 1 || pause;
                            encoder.overflow = !valid_payload || encoder.overflow;
                            if (valid_payload)
                            {
                                (void)machine_x64_emit_metadata_instruction(&encoder, pause ? S8("PAUSE") : S8("NOP"), 0, 0,
                                    (BusterX86MetadataFeatureInput){.names = machine_x64_pause_features, .count = pause ? 1u : 0u},
                                    (BusterX86MetadataPhysicalAttributes){0}, 0);
                            }
                        }
                    }
                    break; case MACHINE_X64_INLINE_ASSEMBLY:
                    {
                        if (instruction->payload >= function->inline_assembly_count)
                        {
                            encoder.overflow = true;
                            break;
                        }
                        MachineInlineAssembly const* assembly = function->inline_assemblies + instruction->payload;
                        u32 x87_top = UINT32_MAX;
                        u32 x87_below = UINT32_MAX;
                        u16 preserved_vector_mask = function->target == machine_target_x86_64_windows()
                                                        ? (u16)((assembly->clobber_mask >> MACHINE_X64_ZMM0) &
                                                                MACHINE_INLINE_ASSEMBLY_WIN64_PRESERVED_VECTOR_MASK)
                                                        : 0;
                        if (preserved_vector_mask)
                        {
                            u32 preserve_offset = placement->stack_slot_offsets[assembly->preserved_vector_slot];
                            u32 preserve_index = 0;
                            for (u32 xmm = 6; xmm < 16; xmm += 1)
                            {
                                if (preserved_vector_mask & (1u << xmm))
                                {
                                    s64 displacement = -(s64)(s32)(preserve_offset - preserve_index * 16u);
                                    (void)machine_x64_emit_metadata_xmm_memory(&encoder, S8("MOVDQU"), xmm, MACHINE_X64_RBP,
                                                                                displacement, true, 128, 0);
                                    preserve_index += 1;
                                }
                            }
                        }
                        for (u32 operand_index = 0; operand_index < assembly->operand_count && !encoder.overflow; operand_index += 1)
                        {
                            u32 side_index = assembly->first_operand + operand_index;
                            if (side_index >= function->inline_assembly_operand_count)
                            {
                                encoder.overflow = true;
                                break;
                            }
                            MachineInlineAssemblyOperand const* operand = function->inline_assembly_operands + side_index;
                            if (operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_X87_TOP)
                            {
                                x87_top = side_index;
                            }
                            else if (operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_X87_BELOW)
                            {
                                x87_below = side_index;
                            }
                            else if ((operand->flags & (MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_VECTOR)) ==
                                     (MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT | MACHINE_INLINE_ASSEMBLY_OPERAND_VECTOR))
                            {
                                u32 frame_offset = placement->stack_slot_offsets[operand->stack_slot];
                                u32 xmm = operand->physical_register - MACHINE_X64_ZMM0;
                                (void)machine_x64_emit_metadata_xmm_memory(&encoder, S8("MOVSD"), xmm,
                                                                          MACHINE_X64_RBP, -(s64)(s32)frame_offset, false,
                                                                          64, 0);
                            }
                            else if (operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT)
                            {
                                machine_x64_emit_exact_frame_chunk(&encoder, true, operand->physical_register,
                                                                   placement->stack_slot_offsets[operand->stack_slot], 8, 0);
                            }
                        }
                        u32 x87_depth = 0;
                        if (x87_below != UINT32_MAX)
                        {
                            MachineInlineAssemblyOperand const* operand = function->inline_assembly_operands + x87_below;
                            if (operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT)
                            {
                                machine_x64_emit_x87_memory(&encoder, S8("FLD"), -(s32)placement->stack_slot_offsets[operand->stack_slot], 80);
                                x87_depth += 1;
                            }
                        }
                        if (x87_top != UINT32_MAX)
                        {
                            MachineInlineAssemblyOperand const* operand = function->inline_assembly_operands + x87_top;
                            if (operand->flags & MACHINE_INLINE_ASSEMBLY_OPERAND_INPUT)
                            {
                                machine_x64_emit_x87_memory(&encoder, S8("FLD"), -(s32)placement->stack_slot_offsets[operand->stack_slot], 80);
                                x87_depth += 1;
                            }
                        }
                        u32 assembly_start = encoder.count;
                        if (assembly->bytes.length > encoder.capacity - encoder.count)
                        {
                            encoder.overflow = true;
                        }
                        else if (assembly->bytes.length)
                        {
                            memcpy(encoder.bytes + encoder.count, assembly->bytes.pointer, assembly->bytes.length);
                            encoder.count += (u32)assembly->bytes.length;
                        }
                        for (u32 relocation_index = 0; relocation_index < assembly->relocation_count && !encoder.overflow; relocation_index += 1)
                        {
                            u32 side_index = assembly->first_relocation + relocation_index;
                            if (side_index >= function->inline_assembly_relocation_count)
                            {
                                encoder.overflow = true;
                                break;
                            }
                            MachineInlineAssemblyRelocation row = function->inline_assembly_relocations[side_index];
                            row.offset += assembly_start;
                            if (!row.is_block)
                            {
                                MachineInlineAssemblyRelocation* output =
                                    (MachineInlineAssemblyRelocation*)machine_stream_append(arena, &inline_assembly_relocations);
                                *output = row;
                            }
                            else if (!row.is_control)
                            {
                                MachineX64BranchFixup* fixup = (MachineX64BranchFixup*)machine_stream_append(arena, &fixups);
                                *fixup = (MachineX64BranchFixup){.addend = row.addend, .patch_offset = row.offset,
                                                                 .block = row.block, .label_address = true};
                            }
                        }
                        bool captured = machine_x64_emit_inline_assembly_outputs(&encoder, function, placement, assembly,
                                                                                 x87_top, x87_below, x87_depth);
                        bool terminator = (assembly->effects & MACHINE_INLINE_ASSEMBLY_EFFECT_TERMINATOR) != 0;
                        if (captured && terminator)
                        {
                            u32 branch_start = encoder.count;
                            machine_x64_emit_fixed_relative(&encoder, MACHINE_X64_FIXED_TEMPLATE_JMP_REL32, S8("JMP"));
                            MachineX64BranchFixup* fixup = (MachineX64BranchFixup*)machine_stream_append(arena, &fixups);
                            *fixup = (MachineX64BranchFixup){.patch_offset = branch_start + 1u, .block = assembly->fallthrough_block};
                        }
                        for (u32 relocation_index = 0;
                             captured && terminator && relocation_index < assembly->relocation_count; relocation_index += 1)
                        {
                            MachineInlineAssemblyRelocation const* relocation =
                                function->inline_assembly_relocations + assembly->first_relocation + relocation_index;
                            if (!relocation->is_control)
                            {
                                continue;
                            }
                            u32 template_patch = assembly_start + relocation->offset;
                            u32 stub_offset = encoder.count;
                            captured = relocation->kind == ASSEMBLY_RELOCATION_X86_PC32 &&
                                       relocation->offset <= assembly->bytes.length &&
                                       assembly->bytes.length - relocation->offset >= sizeof(s32) &&
                                       machine_x64_emit_inline_assembly_outputs(&encoder, function, placement, assembly,
                                                                                x87_top, x87_below, x87_depth);
                            if (captured)
                            {
                                u32 branch_start = encoder.count;
                                machine_x64_emit_fixed_relative(&encoder, MACHINE_X64_FIXED_TEMPLATE_JMP_REL32, S8("JMP"));
                                MachineX64BranchFixup* fixup = (MachineX64BranchFixup*)machine_stream_append(arena, &fixups);
                                *fixup = (MachineX64BranchFixup){.patch_offset = branch_start + 1u,
                                                                 .block = relocation->continuation_block};
                                s64 displacement = (s64)(u64)stub_offset - (s64)(u64)(template_patch + 4u);
                                captured = displacement >= INT32_MIN && displacement <= INT32_MAX;
                                if (captured)
                                {
                                    s32 encoded_displacement = (s32)displacement;
                                    memcpy(encoder.bytes + template_patch, &encoded_displacement, sizeof(encoded_displacement));
                                }
                            }
                        }
                        encoder.overflow = encoder.overflow || !captured;
                    }
                    break; case MACHINE_X64_CPUID:
                    case MACHINE_X64_XGETBV:
                    {
                        bool cpuid = instruction->opcode == MACHINE_X64_CPUID;
                        u32 result_slot = machine_ref_payload(instruction->operands[cpuid ? 2u : 1u]);
                        u32 result_count = cpuid ? 4u : 2u;
                        if (result_slot >= function->stack_slot_count || function->stack_slot_sizes[result_slot] < result_count * 8u)
                        {
                            (void)machine_x64_exact_reject(&encoder, 0);
                        }
                        else
                        {
                            BusterX86MetadataFeatureInput features = {0};
                            if (!cpuid)
                            {
                                features.names = machine_x64_xsave_features;
                                features.count = BUSTER_ARRAY_LENGTH(machine_x64_xsave_features);
                            }
                            (void)machine_x64_emit_metadata_instruction(&encoder, cpuid ? S8("CPUID") : S8("XGETBV"), 0, 0, features,
                                                                         (BusterX86MetadataPhysicalAttributes){0}, 0);
                            u32 registers[] = {MACHINE_X64_RAX, cpuid ? MACHINE_X64_RBX : MACHINE_X64_RDX, MACHINE_X64_RCX, MACHINE_X64_RDX};
                            for (u32 index = 0; index < result_count; index += 1)
                            {
                                s64 displacement = -(s64)placement->stack_slot_offsets[result_slot] + (s64)(index * 8u);
                                (void)machine_x64_emit_metadata_memory_register(&encoder, S8("MOV"), MACHINE_X64_RBP, displacement,
                                                                                registers[index], 64, 64, 0);
                            }
                        }
                    }
                    break; case MACHINE_X64_LOAD_SYMBOL_GOT:
                    {
                        // mov dest, [rip + 0], with the displacement patched
                        // to the symbol's GOT slot. The rip-relative operand
                        // is LEA_SYMBOL's; only the mnemonic differs, so the
                        // patched field sits at the same three bytes in.
                        u32 load_start = encoder.count;
                        BusterX86MetadataPhysicalOperand load_operands[2] = {
                            machine_x64_exact_gpr_operand(operand_registers[0], 64), machine_x64_exact_rip_memory_operand(),
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("MOV"), load_operands, 2,
                                                                     (BusterX86MetadataFeatureInput){0},
                                                                     (BusterX86MetadataPhysicalAttributes){0}, 0);
                        MachineCallSite* site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *site = (MachineCallSite){
                            .code_offset = load_start + 3,
                            .target = instruction->payload,
                        };
                    }
                    break; case MACHINE_X64_LEA_TLS:
                    {
                        // mov dest, fs:[0] — the thread pointer — then
                        // lea dest, [dest + tpoff] with the displacement patched
                        // thread-locally, byte-for-byte the canonical sequence.
                        u32 destination = operand_registers[0];
                        BusterX86MetadataPhysicalOperand fs_operands[2] = {
                            machine_x64_exact_gpr_operand(destination, 64),
                            {
                                .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
                                .width = 64,
                                .memory = {
                                    .displacement = 0,
                                    .address_size = 64,
                                    .scale = 1,
                                    .segment = BUSTER_X86_METADATA_SEGMENT_FS,
                                    .has_displacement = true,
                                    .has_segment = true,
                                },
                            },
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("MOV"), fs_operands, 2,
                                (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                        MachineX64PreparedExactOpcode const* lea_entry = machine_x64_exact_opcode_for_opcode(MACHINE_X64_LEA_FRAME);
                        BusterX86MetadataPhysicalOperand lea_operands[2] = {
                            machine_x64_exact_gpr_operand(destination, 64),
                            machine_x64_exact_memory_operand(destination, 64, 0, true),
                        };
                        if (!lea_entry || !lea_entry->descriptor || !lea_entry->plan_valid ||
                                !machine_x64_emit_exact_form(&encoder, lea_entry->metadata_tokens[0], lea_operands, 2, true, false, 0, false, 0))
                        {
                            encoder.overflow = true;
                        }
                        MachineCallSite* site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *site = (MachineCallSite){
                            .code_offset = encoder.count - 4,
                            .target = instruction->payload,
                            .is_thread_local = 1,
                            .thread_local_site = MACHINE_THREAD_LOCAL_SITE_LOCAL_EXEC,
                        };
                    }
                    break; case MACHINE_X64_LEA_TLS_INITIAL_EXEC:
                    {
                        // mov dest, fs:[0] — the thread pointer — then
                        // add dest, [rip + sym@GOTTPOFF], the word the loader
                        // wrote with this symbol's offset from it.
                        u32 destination = operand_registers[0];
                        BusterX86MetadataPhysicalOperand fs_operands[2] = {
                            machine_x64_exact_gpr_operand(destination, 64),
                            {
                                .kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY,
                                .width = 64,
                                .memory = {
                                    .displacement = 0,
                                    .address_size = 64,
                                    .scale = 1,
                                    .segment = BUSTER_X86_METADATA_SEGMENT_FS,
                                    .has_displacement = true,
                                    .has_segment = true,
                                },
                            },
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("MOV"), fs_operands, 2,
                                (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                        BusterX86MetadataPhysicalOperand add_operands[2] = {
                            machine_x64_exact_gpr_operand(destination, 64),
                            machine_x64_exact_rip_memory_operand(),
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("ADD"), add_operands, 2,
                                (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                        MachineCallSite* site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *site = (MachineCallSite){
                            .code_offset = encoder.count - 4,
                            .target = instruction->payload,
                            .is_thread_local = 1,
                            .thread_local_site = MACHINE_THREAD_LOCAL_SITE_INITIAL_EXEC,
                        };
                    }
                    break; case MACHINE_X64_TLS_WINDOWS:
                    {
                        BusterX86MetadataPhysicalOperand index_memory = machine_x64_exact_rip_memory_operand();
                        index_memory.width = 32;
                        BusterX86MetadataPhysicalOperand index_operands[] = {
                            machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 32), index_memory,
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("MOV"), index_operands, 2,
                            (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                        MachineCallSite* index_site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *index_site = (MachineCallSite){.code_offset = encoder.count - 4, .target = instruction->payload,
                            .is_thread_local = 1, .thread_local_site = MACHINE_THREAD_LOCAL_SITE_WINDOWS_INDEX};
                        BusterX86MetadataPhysicalOperand thread_operands[] = {
                            machine_x64_exact_gpr_operand(MACHINE_X64_RDX, 64),
                            {.kind = BUSTER_X86_METADATA_PHYSICAL_OPERAND_MEMORY, .width = 64,
                             .memory = {.displacement = 0x58, .address_size = 64, .scale = 1,
                                .segment = BUSTER_X86_METADATA_SEGMENT_GS, .has_displacement = true, .has_segment = true}},
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("MOV"), thread_operands, 2,
                            (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                        BusterX86MetadataPhysicalOperand slot_memory = machine_x64_exact_memory_operand(MACHINE_X64_RDX, 64, 0, false);
                        slot_memory.memory.has_index = true;
                        slot_memory.memory.index = machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 64).reg;
                        slot_memory.memory.scale = 8;
                        BusterX86MetadataPhysicalOperand slot_operands[] = {
                            machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 64), slot_memory,
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("MOV"), slot_operands, 2,
                            (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                        MachineX64PreparedExactOpcode const* lea_entry = machine_x64_exact_opcode_for_opcode(MACHINE_X64_LEA_FRAME);
                        BusterX86MetadataPhysicalOperand lea_operands[] = {
                            machine_x64_exact_gpr_operand(MACHINE_X64_RAX, 64),
                            machine_x64_exact_memory_operand(MACHINE_X64_RAX, 64, 0, true),
                        };
                        if (!lea_entry || !lea_entry->descriptor || !lea_entry->plan_valid ||
                            !machine_x64_emit_exact_form(&encoder, lea_entry->metadata_tokens[0], lea_operands, 2, true, false, 0, false, 0))
                        {
                            encoder.overflow = true;
                        }
                        MachineCallSite* offset_site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *offset_site = (MachineCallSite){.code_offset = encoder.count - 4, .target = instruction->payload,
                            .is_thread_local = 1, .thread_local_site = MACHINE_THREAD_LOCAL_SITE_WINDOWS_OFFSET};
                    }
                    break; case MACHINE_X64_TLS_DARWIN:
                    {
                        BusterX86MetadataPhysicalOperand descriptor_operands[] = {
                            machine_x64_exact_gpr_operand(MACHINE_X64_RDI, 64), machine_x64_exact_rip_memory_operand(),
                        };
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("MOV"), descriptor_operands, 2,
                            (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                        MachineCallSite* descriptor_site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *descriptor_site = (MachineCallSite){.code_offset = encoder.count - 4, .target = instruction->payload,
                            .is_thread_local = 1, .thread_local_site = MACHINE_THREAD_LOCAL_SITE_DARWIN_DESCRIPTOR};
                        BusterX86MetadataPhysicalOperand call_operand = machine_x64_exact_memory_operand(MACHINE_X64_RDI, 64, 0, false);
                        (void)machine_x64_emit_metadata_instruction(&encoder, S8("CALL"), &call_operand, 1,
                            (BusterX86MetadataFeatureInput){0}, (BusterX86MetadataPhysicalAttributes){0}, 0);
                    }
                    break; case MACHINE_X64_TLS_GENERAL_DYNAMIC:
                    {
                        u32 sequence_offset = encoder.count;
                        (void)machine_x64_emit_tls_general_dynamic(&encoder);
                        MachineCallSite* address_site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *address_site = (MachineCallSite){
                            .code_offset = sequence_offset + BUSTER_X86_METADATA_TLS_GD_ADDRESS_OFFSET,
                            .target = instruction->payload,
                            .is_thread_local = 1,
                            .thread_local_site = MACHINE_THREAD_LOCAL_SITE_GENERAL_DYNAMIC,
                        };
                        MachineCallSite* helper_site = (MachineCallSite*)machine_stream_append(arena, &call_sites);
                        *helper_site = (MachineCallSite){
                            .code_offset = sequence_offset + BUSTER_X86_METADATA_TLS_GD_HELPER_OFFSET,
                            .target = instruction->payload,
                            .thread_local_site = MACHINE_THREAD_LOCAL_SITE_TLS_GET_ADDR,
                        };
                    }
                    break; case MACHINE_X64_COPY_FRAME_FROM_FRAME:
                    {
                        u32 destination_offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[0])];
                        u32 source_offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[1])];
                        u32 copied = 0;
                        while (copied < instruction->payload)
                        {
                            u32 chunk = machine_x64_copy_chunk(instruction->payload - copied);
                            (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RAX, source_offset - copied, chunk, 0);
                            (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RAX, destination_offset - copied, chunk, 0);
                            copied += chunk;
                        }
                    }
                    break; case MACHINE_X64_COPY_FRAME_FROM_PTR:
                    {
                        u32 destination_offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[0])];
                        u32 source_register = operand_registers[1];
                        u32 copied = 0;
                        while (copied < instruction->payload)
                        {
                            u32 chunk = machine_x64_copy_chunk(instruction->payload - copied);
                            (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_RAX, source_register, copied, chunk, 0);
                            (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RAX, destination_offset - copied, chunk, 0);
                            copied += chunk;
                        }
                    }
                    break; case MACHINE_X64_COPY_PTR_FROM_FRAME:
                    {
                        u32 destination_register = operand_registers[0];
                        u32 source_offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[1])];
                        u32 copied = 0;
                        while (copied < instruction->payload)
                        {
                            u32 chunk = machine_x64_copy_chunk(instruction->payload - copied);
                            (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RDX, source_offset - copied, chunk, 0);
                            (void)machine_x64_emit_metadata_pointer_chunk(&encoder, false, MACHINE_X64_RDX, destination_register, copied, chunk, 0);
                            copied += chunk;
                        }
                    }
                    break; case MACHINE_X64_CVT_U64_TO_F32: case MACHINE_X64_CVT_U64_TO_F64:
                    {
                        // Canonical branchy form: non-negative converts directly;
                        // a set sign bit halves with a sticky rounding bit, then
                        // doubles the float.  The selector leaves the two operands
                        // unconstrained; RCX is the row's declared integer scratch,
                        // while the destination carries the resulting float bits.
                        bool to_f64 = instruction->opcode == MACHINE_X64_CVT_U64_TO_F64;
                        u32 source = operand_registers[1];
                        u32 destination = operand_registers[0];
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RCX, source, 64, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("TEST"), source, source, 64, 0);
                        u32 non_negative_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JNS"), 0, 8, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), destination, source, 64, 0);
                        (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("SHR"), destination, 1, 64, 8, 0);
                        (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("AND"), MACHINE_X64_RCX, 1, 32, 8, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("OR"), destination, MACHINE_X64_RCX, 64, 0);
                        (void)machine_x64_emit_metadata_xmm_gpr(&encoder, to_f64 ? S8("CVTSI2SD") : S8("CVTSI2SS"), 0, destination,
                                to_f64 ? 64 : 32, 64, 0);
                        (void)machine_x64_emit_metadata_xmm_registers(&encoder, to_f64 ? S8("ADDSD") : S8("ADDSS"), 0, 0,
                                to_f64 ? 64 : 32, 0);
                        (void)machine_x64_emit_metadata_gpr_xmm(&encoder, S8("MOVQ"), destination, 0, 64, 128, 0);
                        u32 end_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JMP"), 0, 8, 0);
                        u32 direct_conversion = encoder.count;
                        (void)machine_x64_emit_metadata_xmm_gpr(&encoder, to_f64 ? S8("CVTSI2SD") : S8("CVTSI2SS"), 0, source,
                                to_f64 ? 64 : 32, 64, 0);
                        (void)machine_x64_emit_metadata_gpr_xmm(&encoder, S8("MOVQ"), destination, 0, 64, 128, 0);
                        u32 conversion_end = encoder.count;
                        encoder.bytes[non_negative_branch + 1] = (u8)(direct_conversion - (non_negative_branch + 2));
                        encoder.bytes[end_branch + 1] = (u8)(conversion_end - (end_branch + 2));
                    }
                    break; case MACHINE_X64_CVT_F32_TO_U64: case MACHINE_X64_CVT_F64_TO_U64:
                    {
                        // Canonical threshold form: values below 2^63 convert
                        // directly, larger ones subtract the threshold first and
                        // set the top bit after.  The row's operands are free to use
                        // any allocatable GPR; RCX is reserved as the final scratch.
                        bool from_f64 = instruction->opcode == MACHINE_X64_CVT_F64_TO_U64;
                        u32 source = operand_registers[1];
                        u32 destination = operand_registers[0];
                        (void)machine_x64_emit_metadata_xmm_gpr(&encoder, S8("MOVQ"), 0, source, 128, 64, 0);
                        // IEEE encodings of 2^63 in binary64 and binary32.
                        (void)machine_x64_emit_exact_immediate_value(&encoder, destination,
                                from_f64 ? CODEGEN_F64_SIGNED64_LIMIT_BITS : CODEGEN_F32_SIGNED64_LIMIT_BITS, 0);
                        (void)machine_x64_emit_metadata_xmm_gpr(&encoder, S8("MOVQ"), 1, destination, 128, 64, 0);
                        (void)machine_x64_emit_metadata_xmm_registers(&encoder, from_f64 ? S8("UCOMISD") : S8("UCOMISS"), 0, 1,
                                from_f64 ? 64 : 32, 0);
                        u32 direct_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JB"), 0, 8, 0);
                        (void)machine_x64_emit_metadata_xmm_registers(&encoder, from_f64 ? S8("SUBSD") : S8("SUBSS"), 0, 1,
                                from_f64 ? 64 : 32, 0);
                        (void)machine_x64_emit_metadata_gpr_xmm(&encoder, from_f64 ? S8("CVTTSD2SI") : S8("CVTTSS2SI"), destination, 0, 64,
                                from_f64 ? 64 : 32, 0);
                        // The threshold path already converted x-2^63 to a signed
                        // 64-bit result; restore the unsigned high bit, not merely
                        // bit 31 (the latter is only the f32 result width).
                        (void)machine_x64_emit_exact_immediate_value(&encoder, MACHINE_X64_RCX, UINT64_C(0x8000000000000000), 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("OR"), destination, MACHINE_X64_RCX, 64, 0);
                        u32 end_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JMP"), 0, 8, 0);
                        u32 direct_conversion = encoder.count;
                        (void)machine_x64_emit_metadata_gpr_xmm(&encoder, from_f64 ? S8("CVTTSD2SI") : S8("CVTTSS2SI"), destination, 0, 64,
                                from_f64 ? 64 : 32, 0);
                        u32 conversion_end = encoder.count;
                        encoder.bytes[direct_branch + 1] = (u8)(direct_conversion - (direct_branch + 2));
                        encoder.bytes[end_branch + 1] = (u8)(conversion_end - (end_branch + 2));
                    }
                    break; case MACHINE_X64_CVT_F32_TO_I64: case MACHINE_X64_CVT_F64_TO_I64:
                    {
                        bool from_f64 = instruction->opcode == MACHINE_X64_CVT_F64_TO_I64;
                        (void)machine_x64_emit_metadata_xmm_gpr(&encoder, S8("MOVQ"), 0, operand_registers[1], 64, 64, 0);
                        (void)machine_x64_emit_metadata_gpr_xmm(&encoder, from_f64 ? S8("CVTTSD2SI") : S8("CVTTSS2SI"), operand_registers[0], 0, 64, 128, 0);
                    }
                    break; case MACHINE_X64_LOAD_XMM_FRAME128:
                    case MACHINE_X64_STORE_XMM_FRAME128:
                    case MACHINE_X64_LOAD_YMM_FRAME256:
                    case MACHINE_X64_STORE_YMM_FRAME256:
                    {
                        u32 slot = machine_ref_payload(instruction->operands[1]);
                        s64 displacement = -(s64)(s32)placement->stack_slot_offsets[slot] + instruction->payload;
                        bool ymm = instruction->opcode == MACHINE_X64_LOAD_YMM_FRAME256 || instruction->opcode == MACHINE_X64_STORE_YMM_FRAME256;
                        bool store = instruction->opcode == MACHINE_X64_STORE_XMM_FRAME128 || instruction->opcode == MACHINE_X64_STORE_YMM_FRAME256;
                        u16 width = ymm ? 256 : 128;
                        BusterX86MetadataPhysicalOperand memory = machine_x64_exact_memory_operand(MACHINE_X64_RBP, width, displacement, displacement != 0);
                        BusterX86MetadataPhysicalOperand vector = ymm ? machine_x64_exact_ymm_operand(operand_registers[0] - MACHINE_X64_ZMM0)
                            : machine_x64_exact_xmm_operand(operand_registers[0] - MACHINE_X64_ZMM0, width);
                        BusterX86MetadataPhysicalOperand operands[] = {store ? memory : vector, store ? vector : memory};
                        BusterX86MetadataFeatureInput features = ymm
                            ? (BusterX86MetadataFeatureInput){.names = machine_x64_avx_features, .count = BUSTER_ARRAY_LENGTH(machine_x64_avx_features)}
                            : (BusterX86MetadataFeatureInput){0};
                        (void)machine_x64_emit_metadata_instruction(&encoder, ymm ? S8("VMOVDQU") : S8("MOVDQU"), operands, 2,
                            features, (BusterX86MetadataPhysicalAttributes){0}, 0);
                    }
                    break; case MACHINE_X64_LOAD_XMM0_FRAME128:
                    case MACHINE_X64_STORE_XMM0_FRAME128:
                    {
                        u32 slot = machine_ref_payload(instruction->operands[0]);
                        s64 displacement = -(s64)(s32)placement->stack_slot_offsets[slot];
                        (void)machine_x64_emit_metadata_xmm_memory(&encoder, S8("MOVDQU"), 0, MACHINE_X64_RBP, displacement,
                            instruction->opcode == MACHINE_X64_STORE_XMM0_FRAME128, 128, 0);
                    }
                    break; case MACHINE_X64_WIN_VA_SAVE:
                    {
                        for (u32 index = 0; index < 4; index += 1)
                        {
                            s64 displacement = 16 + (s64)placement->incoming_base + (s64)index * 8;
                            (void)machine_x64_emit_metadata_memory_register(&encoder, S8("MOV"), MACHINE_X64_RBP, displacement,
                                                                            operand_registers[index], 64, 64, 0);
                        }
                    }
                    break; case MACHINE_X64_LEA_INCOMING:
                    {
                        s64 displacement = 16 + (s64)placement->incoming_base + (s64)instruction->payload;
                        (void)machine_x64_emit_metadata_register_memory(&encoder, S8("LEA"), operand_registers[0], MACHINE_X64_RBP,
                                                                        displacement, 64, 64, 0);
                    }
                    break; case MACHINE_X64_VA_SAVE:
                    {
                        u32 save_offset = placement->stack_slot_offsets[machine_ref_payload(instruction->operands[0])];
                        static u8 const gp_registers[6] = {
                            MACHINE_X64_RDI, MACHINE_X64_RSI, MACHINE_X64_RDX, MACHINE_X64_RCX, MACHINE_X64_R8, MACHINE_X64_R9,
                        };
                        for (u32 gp_index = 0; gp_index < BUSTER_ARRAY_LENGTH(gp_registers); gp_index += 1)
                        {
                            u32 save_displacement = save_offset - gp_index * 8u;
                            (void)machine_x64_emit_exact_frame_chunk(&encoder, false, gp_registers[gp_index], save_displacement, 8, 0);
                        }
                        for (u32 float_index = 0; float_index < 8; float_index += 1)
                        {
                            u32 xmm = float_index;
                            u32 save_displacement = save_offset - 48u - float_index * 16u;
                            (void)machine_x64_emit_metadata_xmm_memory(&encoder, S8("MOVDQU"), xmm, MACHINE_X64_RBP,
                                    -(s64)(s32)save_displacement, true, 128, 0);
                        }
                    }
                    break; case MACHINE_X64_VA_ARG:
                    {
                        MachineVaArg* metadata = function->va_args + instruction->payload;
                        u32 list = operand_registers[0];
                        u32 result_register = operand_registers[1];
                        u32 result_offset = metadata->result_is_frame ? placement->stack_slot_offsets[metadata->result_slot] : 0;
                        // A mixed aggregate can exhaust either class independently.
                        // Both class checks branch to the same overflow sequence, so
                        // retain every displacement field rather than silently
                        // leaving the second Jcc's zero displacement unpatched.
                        u32 overflow_patches[2] = {UINT32_MAX, UINT32_MAX};
                        u32 overflow_patch_count = 0;
                        u32 end_patch = UINT32_MAX;
                        bool register_path = metadata->part_count && !metadata->parts[0].is_memory;
                        u32 integer_parts = 0;
                        u32 float_parts = 0;
                        for (u32 part_index = 0; part_index < metadata->part_count; part_index += 1)
                        {
                            integer_parts += !metadata->parts[part_index].is_float && !metadata->parts[part_index].is_memory;
                            float_parts += metadata->parts[part_index].is_float && !metadata->parts[part_index].is_memory;
                            register_path &= !metadata->parts[part_index].is_memory;
                        }
                        if (register_path)
                        {
                            if (integer_parts)
                            {
                                (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_RDX, list, 0, 4, 0);
                                (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("CMP"), MACHINE_X64_RDX,
                                        48u - integer_parts * 8u, 32, 32, 0);
                                u32 branch_start = encoder.count;
                                (void)machine_x64_emit_metadata_relative(&encoder, S8("JA"), 0, 32, 0);
                                if (overflow_patch_count < BUSTER_ARRAY_LENGTH(overflow_patches))
                                {
                                    overflow_patches[overflow_patch_count++] = branch_start + 2;
                                }
                            }
                            if (float_parts)
                            {
                                (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_R9, list, 4, 4, 0);
                                (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("CMP"), MACHINE_X64_R9,
                                        176u - float_parts * 16u, 32, 32, 0);
                                u32 branch_start = encoder.count;
                                (void)machine_x64_emit_metadata_relative(&encoder, S8("JA"), 0, 32, 0);
                                if (overflow_patch_count < BUSTER_ARRAY_LENGTH(overflow_patches))
                                {
                                    overflow_patches[overflow_patch_count++] = branch_start + 2;
                                }
                            }
                            (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_R8, list, 16, 8, 0);
                            for (u32 part_index = 0; part_index < metadata->part_count; part_index += 1)
                            {
                                MachineVaArgPart* part = metadata->parts + part_index;
                                u32 offset_register = part->is_float ? MACHINE_X64_R9 : MACHINE_X64_RDX;
                                // Keep R8 as the immutable reg_save_area base.  Build
                                // each part address in the scratch R11 register so
                                // mixed GP/FP values do not accumulate one class's
                                // cursor into the save-area base.
                                (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_R11, MACHINE_X64_R8, 64, 0);
                                (void)machine_x64_emit_metadata_registers(&encoder, S8("ADD"), MACHINE_X64_R11, offset_register, 64, 0);
                                for (u32 copied = 0; copied < part->size; copied += 8u)
                                {
                                    u32 chunk = BUSTER_MIN((u32)part->size - copied, 8u);
                                    (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_R10, MACHINE_X64_R11,
                                        part->save_offset + copied, chunk, 0);
                                    if (metadata->result_is_frame)
                                    {
                                        (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_R10,
                                            result_offset - part->value_offset - copied, chunk, 0);
                                    }
                                    else
                                    {
                                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), result_register, MACHINE_X64_R10, 64, 0);
                                    }
                                }
                            }
                            if (integer_parts)
                            {
                                u32 amount = integer_parts * 8u;
                                (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("ADD"), MACHINE_X64_RDX, amount, 32,
                                        amount <= INT8_MAX ? 8 : 32, 0);
                                (void)machine_x64_emit_metadata_pointer_chunk(&encoder, false, MACHINE_X64_RDX, list, 0, 4, 0);
                            }
                            if (float_parts)
                            {
                                u32 amount = float_parts * 16u;
                                (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("ADD"), MACHINE_X64_R9, amount, 32,
                                        amount <= INT8_MAX ? 8 : 32, 0);
                                (void)machine_x64_emit_metadata_pointer_chunk(&encoder, false, MACHINE_X64_R9, list, 4, 4, 0);
                            }
                            u32 end_branch_start = encoder.count;
                            (void)machine_x64_emit_metadata_relative(&encoder, S8("JMP"), 0, 32, 0);
                            end_patch = end_branch_start + 1;
                        }
                        u32 overflow_start = encoder.count;
                        (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_RDX, list, 8, 8, 0);
                        if (metadata->alignment > 8)
                        {
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("ADD"), MACHINE_X64_RDX, metadata->alignment - 1,
                                    64, (metadata->alignment - 1) <= INT8_MAX ? 8 : 32, 0);
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("AND"), MACHINE_X64_RDX,
                                    (u64)(-(s64)metadata->alignment),
                                    64, 32, 0);
                        }
                        if (metadata->result_is_frame)
                        {
                            u32 copied = 0;
                            while (copied < metadata->size)
                            {
                                u32 chunk = machine_x64_copy_chunk(metadata->size - copied);
                                (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_R10, MACHINE_X64_RDX, copied, chunk, 0);
                                (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_R10, result_offset - copied, chunk, 0);
                                copied += chunk;
                            }
                        }
                        else
                        {
                            (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, result_register, MACHINE_X64_RDX, 0,
                                    metadata->scalar_size >= 8 ? 8 : metadata->scalar_size, 0);
                        }
                        (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("ADD"), MACHINE_X64_RDX, metadata->stack_size,
                                64, metadata->stack_size <= INT8_MAX ? 8 : 32, 0);
                        (void)machine_x64_emit_metadata_pointer_chunk(&encoder, false, MACHINE_X64_RDX, list, 8, 8, 0);
                        u32 end = encoder.count;
                        for (u32 patch_index = 0; patch_index < overflow_patch_count; patch_index += 1)
                        {
                            u32 overflow_patch = overflow_patches[patch_index];
                            u32 displacement = overflow_start - (overflow_patch + 4);
                            for (u32 byte_index = 0; byte_index < 4; byte_index += 1)
                            {
                                encoder.bytes[overflow_patch + byte_index] = (u8)(displacement >> (byte_index * 8));
                            }
                        }
                        if (end_patch != UINT32_MAX)
                        {
                            u32 displacement = end - (end_patch + 4);
                            for (u32 byte_index = 0; byte_index < 4; byte_index += 1)
                            {
                                encoder.bytes[end_patch + byte_index] = (u8)(displacement >> (byte_index * 8));
                            }
                        }
                    }
                    break; case MACHINE_X64_STACK_ALLOCATE:
                    {
                        // The constrained row places the runtime byte count in RCX
                        // and receives the resulting RSP in RAX. An over-aligned
                        // allocation probes the full distance to align_down(RSP-size),
                        // including the padding the incoming RSP needs.
                        u32 stack_alignment = instruction->payload;
                        if (stack_alignment > 16)
                        {
                            (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RAX, MACHINE_X64_RSP, 64, 0);
                            (void)machine_x64_emit_metadata_registers(&encoder, S8("SUB"), MACHINE_X64_RAX, MACHINE_X64_RCX, 64, 0);
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("AND"), MACHINE_X64_RAX,
                                    (u64)(-(s64)stack_alignment), 64, 32, 0);
                            (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RCX, MACHINE_X64_RSP, 64, 0);
                            (void)machine_x64_emit_metadata_registers(&encoder, S8("SUB"), MACHINE_X64_RCX, MACHINE_X64_RAX, 64, 0);
                        }
                        else
                        {
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("ADD"), MACHINE_X64_RCX, stack_alignment - 1, 64, 32, 0);
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("AND"), MACHINE_X64_RCX,
                                    (u64)(-(s64)stack_alignment), 64, 32, 0);
                        }

                        u32 compare_offset = encoder.count;
                        (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("CMP"), MACHINE_X64_RCX, 4096, 64, 32, 0);
                        u32 short_exit = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JB"), 0, 8, 0);
                        (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("SUB"), MACHINE_X64_RSP, 4096, 64, 32, 0);
                        (void)machine_x64_emit_metadata_memory_immediate(&encoder, S8("TEST"), MACHINE_X64_RSP, 0, 0, 8, 8, 0);
                        (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("SUB"), MACHINE_X64_RCX, 4096, 64, 32, 0);
                        u32 loop_back = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JMP"), 0, 8, 0);
                        u32 residual = encoder.count;
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("SUB"), MACHINE_X64_RSP, MACHINE_X64_RCX, 64, 0);
                        (void)machine_x64_emit_metadata_memory_immediate(&encoder, S8("TEST"), MACHINE_X64_RSP, 0, 0, 8, 8, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RAX, MACHINE_X64_RSP, 64, 0);
                        encoder.bytes[short_exit + 1] = (u8)(residual - (short_exit + 2));
                        encoder.bytes[loop_back + 1] = (u8)(compare_offset - (loop_back + 2));
                    }
                    break; case MACHINE_X64_ATOMIC_RMW:
                    {
                        // Sized load, then a lock cmpxchg retry loop with R8 holding
                        // the proposed value, mirroring the canonical sequence.
                        u32 size = instruction->payload & 0xff;
                        u32 atomic_operation = instruction->payload >> 8;
                        (void)machine_x64_emit_metadata_pointer_chunk(&encoder, true, MACHINE_X64_RAX, MACHINE_X64_RCX, 0, size, 0);
                        u32 retry_offset = encoder.count;
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_R8, MACHINE_X64_RAX, (u16)(size * 8u), 0);
                        if (atomic_operation == IR_ATOMIC_EXCHANGE)
                        {
                            (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_R8, MACHINE_X64_RDX, (u16)(size * 8u), 0);
                        }
                        else
                        {
                            String8 operation = atomic_operation == IR_ATOMIC_ADD           ? S8("ADD")
                                : atomic_operation == IR_ATOMIC_SUBTRACT    ? S8("SUB")
                                : atomic_operation == IR_ATOMIC_BITWISE_AND || atomic_operation == IR_ATOMIC_BITWISE_NAND ? S8("AND")
                                : atomic_operation == IR_ATOMIC_BITWISE_OR  ? S8("OR")
                                : S8("XOR");
                            (void)machine_x64_emit_metadata_registers(&encoder, operation, MACHINE_X64_R8, MACHINE_X64_RDX, (u16)(size * 8u), 0);
                            if (atomic_operation == IR_ATOMIC_BITWISE_NAND)
                            {
                                (void)machine_x64_emit_metadata_register(&encoder, S8("NOT"), MACHINE_X64_R8, (u16)(size * 8u), 0);
                            }
                        }
                        (void)machine_x64_emit_metadata_atomic_memory_register(&encoder, S8("CMPXCHG"), MACHINE_X64_RCX, MACHINE_X64_R8,
                                (u16)(size * 8u), 0);
                        u32 retry_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JNE"), 0, 32, 0);
                        u32 displacement = retry_offset - (retry_branch + 6);
                        for (u32 byte_index = 0; byte_index < 4; byte_index += 1)
                        {
                            encoder.bytes[retry_branch + 2 + byte_index] = (u8)(displacement >> (byte_index * 8));
                        }
                    }
                    break; case MACHINE_X64_ATOMIC_CMPXCHG:
                    {
                        u32 size = instruction->payload & 0xff;
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RAX, MACHINE_X64_RDX, 64, 0);
                        (void)machine_x64_emit_metadata_atomic_memory_register(&encoder, S8("CMPXCHG"), MACHINE_X64_RCX, MACHINE_X64_RSI,
                                (u16)(size * 8u), 0);
                    }
                    break; case MACHINE_X64_ATOMIC_CMPXCHG16:
                    {
                        u32 result_slot = machine_ref_payload(instruction->operands[0]);
                        u32 expected_slot = machine_ref_payload(instruction->operands[1]);
                        u32 desired_slot = machine_ref_payload(instruction->operands[2]);
                        u32 address = operand_registers[3];
                        u32 result_offset = placement->stack_slot_offsets[result_slot];
                        u32 expected_offset = placement->stack_slot_offsets[expected_slot];
                        u32 desired_offset = placement->stack_slot_offsets[desired_slot];
                        // CMPXCHG16B's implicit pairs are RAX:RDX (expected/result)
                        // and RBX:RCX (desired). The result stores happen after the
                        // instruction, preserving the old memory image on both the
                        // success and failure paths.
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RAX, expected_offset, 8, 0);
                        // Frame slots grow toward lower addresses: aggregate byte
                        // offset 8 is represented by the slot offset minus eight.
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RDX, expected_offset - 8, 8, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RBX, desired_offset, 8, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RCX, desired_offset - 8, 8, 0);
                        (void)machine_x64_emit_metadata_atomic_memory(&encoder, S8("CMPXCHG16B"), address, 128, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RAX, result_offset, 8, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RDX, result_offset - 8, 8, 0);
                    }
                    break; case MACHINE_X64_ATOMIC_STORE16:
                    {
                        u32 desired_slot = machine_ref_payload(instruction->operands[0]);
                        u32 address = operand_registers[3];
                        u32 desired_offset = placement->stack_slot_offsets[desired_slot];
                        u32 stored_size = instruction->payload;
                        // CMPXCHG16B takes the desired image in RBX:RCX and
                        // the expected image in RAX:RDX.  The desired pair is
                        // loaded once and remains unchanged across retries;
                        // only RAX:RDX are replaced by a failed comparison.
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RBX, desired_offset, 8, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_RCX, desired_offset - 8, 8, 0);
                        if (stored_size > 8 && stored_size < 16)
                        {
                            u32 shift = 64u - (stored_size - 8u) * 8u;
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("SHL"), MACHINE_X64_RCX, shift, 64, 8, 0);
                            (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("SHR"), MACHINE_X64_RCX, shift, 64, 8, 0);
                        }
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("XOR"), MACHINE_X64_RAX, MACHINE_X64_RAX, 32, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("XOR"), MACHINE_X64_RDX, MACHINE_X64_RDX, 32, 0);
                        u32 retry_offset = encoder.count;
                        (void)machine_x64_emit_metadata_atomic_memory(&encoder, S8("CMPXCHG16B"), address, 128, 0);
                        u32 retry_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JNE"), 0, 32, 0);
                        u32 displacement = retry_offset - (retry_branch + 6);
                        for (u32 byte_index = 0; byte_index < 4; byte_index += 1)
                        {
                            encoder.bytes[retry_branch + 2 + byte_index] = (u8)(displacement >> (byte_index * 8));
                        }
                    }
                    break; case MACHINE_X64_ATOMIC_LOAD16:
                    {
                        u32 result_slot = machine_ref_payload(instruction->operands[0]);
                        u32 address = operand_registers[3];
                        u32 result_offset = placement->stack_slot_offsets[result_slot];
                        // The desired pair mirrors the current expected pair
                        // on every attempt.  CMPXCHG16B therefore leaves the
                        // observed image in RAX:RDX after either the initial
                        // zero comparison succeeds or a nonzero comparison
                        // fails and the retry imports the actual memory pair.
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("XOR"), MACHINE_X64_RAX, MACHINE_X64_RAX, 32, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("XOR"), MACHINE_X64_RDX, MACHINE_X64_RDX, 32, 0);
                        u32 retry_offset = encoder.count;
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RBX, MACHINE_X64_RAX, 64, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RCX, MACHINE_X64_RDX, 64, 0);
                        (void)machine_x64_emit_metadata_atomic_memory(&encoder, S8("CMPXCHG16B"), address, 128, 0);
                        u32 retry_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JNE"), 0, 32, 0);
                        u32 displacement = retry_offset - (retry_branch + 6);
                        for (u32 byte_index = 0; byte_index < 4; byte_index += 1)
                        {
                            encoder.bytes[retry_branch + 2 + byte_index] = (u8)(displacement >> (byte_index * 8));
                        }
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RAX, result_offset, 8, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RDX, result_offset - 8, 8, 0);
                    }
                    break; case MACHINE_X64_ATOMIC_RMW16:
                    {
                        u32 result_slot = machine_ref_payload(instruction->operands[0]);
                        u32 value_slot = machine_ref_payload(instruction->operands[1]);
                        u32 address = operand_registers[3];
                        u32 result_offset = placement->stack_slot_offsets[result_slot];
                        u32 value_offset = placement->stack_slot_offsets[value_slot];
                        u32 atomic_operation = instruction->payload >> 8;
                        String8 low_operation = atomic_operation == IR_ATOMIC_ADD           ? S8("ADD")
                            : atomic_operation == IR_ATOMIC_SUBTRACT    ? S8("SUB")
                            : atomic_operation == IR_ATOMIC_BITWISE_AND || atomic_operation == IR_ATOMIC_BITWISE_NAND ? S8("AND")
                            : atomic_operation == IR_ATOMIC_BITWISE_OR  ? S8("OR")
                            : atomic_operation == IR_ATOMIC_BITWISE_XOR ? S8("XOR")
                            : atomic_operation == IR_ATOMIC_EXCHANGE    ? S8("MOV")
                                                                         : (String8){0};
                        String8 high_operation = atomic_operation == IR_ATOMIC_ADD        ? S8("ADC")
                            : atomic_operation == IR_ATOMIC_SUBTRACT ? S8("SBB")
                            : low_operation;
                        // R8:R9 retain the requested value across retries;
                        // RBX:RCX are rebuilt from the current expected pair
                        // before applying the operation on every attempt.
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_R8, value_offset, 8, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, true, MACHINE_X64_R9, value_offset - 8, 8, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("XOR"), MACHINE_X64_RAX, MACHINE_X64_RAX, 32, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("XOR"), MACHINE_X64_RDX, MACHINE_X64_RDX, 32, 0);
                        u32 retry_offset = encoder.count;
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RBX, MACHINE_X64_RAX, 64, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, S8("MOV"), MACHINE_X64_RCX, MACHINE_X64_RDX, 64, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, low_operation, MACHINE_X64_RBX, MACHINE_X64_R8, 64, 0);
                        (void)machine_x64_emit_metadata_registers(&encoder, high_operation, MACHINE_X64_RCX, MACHINE_X64_R9, 64, 0);
                        if (atomic_operation == IR_ATOMIC_BITWISE_NAND)
                        {
                            (void)machine_x64_emit_metadata_register(&encoder, S8("NOT"), MACHINE_X64_RBX, 64, 0);
                            (void)machine_x64_emit_metadata_register(&encoder, S8("NOT"), MACHINE_X64_RCX, 64, 0);
                        }
                        (void)machine_x64_emit_metadata_atomic_memory(&encoder, S8("CMPXCHG16B"), address, 128, 0);
                        u32 retry_branch = encoder.count;
                        (void)machine_x64_emit_metadata_relative(&encoder, S8("JNE"), 0, 32, 0);
                        u32 displacement = retry_offset - (retry_branch + 6);
                        for (u32 byte_index = 0; byte_index < 4; byte_index += 1)
                        {
                            encoder.bytes[retry_branch + 2 + byte_index] = (u8)(displacement >> (byte_index * 8));
                        }
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RAX, result_offset, 8, 0);
                        (void)machine_x64_emit_exact_frame_chunk(&encoder, false, MACHINE_X64_RDX, result_offset - 8, 8, 0);
                    }
                    break; case MACHINE_X64_UD2: machine_x64_emit_fixed_instruction(&encoder, MACHINE_X64_FIXED_TEMPLATE_UD2, S8("UD2"), (BusterX86MetadataFeatureInput){0});
                    break; case MACHINE_X64_SWITCH:
                    {
                        // The canonical compare chain: the condition sits in the
                        // operand scratch, each case constant is materialized in
                        // RCX, equality jumps to the case block, and the tail jump
                        // takes the default edge.
                        u32 condition = operand_registers[0];
                        // A switch row has no explicit scratch operand.  RCX is the
                        // normal constant carrier, but the allocator may place the
                        // condition there; use RAX in that case so materializing a
                        // case value never destroys the value being compared.
                        u32 compare_register = condition == MACHINE_X64_RCX ? MACHINE_X64_RAX : MACHINE_X64_RCX;
                        // The compare's template: RCX against the condition, or
                        // RAX against the RCX the condition sits in.
                        u32 compare32_template = compare_register == MACHINE_X64_RCX
                            ? machine_x64_fixed_template_family_row(MACHINE_X64_FIXED_TEMPLATE_CMP32_RCX, condition)
                            : MACHINE_X64_FIXED_TEMPLATE_CMP32_RAX_RCX;
                        u32 compare64_template = compare_register == MACHINE_X64_RCX
                            ? machine_x64_fixed_template_family_row(MACHINE_X64_FIXED_TEMPLATE_CMP64_RCX, condition)
                            : MACHINE_X64_FIXED_TEMPLATE_CMP64_RAX_RCX;
                        for (u32 case_index = 0; case_index < instruction->flags; case_index += 1)
                        {
                            MachineSwitchCase* case_row = function->switch_cases + instruction->payload + case_index;
                            u16 compare_width = case_row->compare_width ? case_row->compare_width : 64;
                            if (compare_width == 32)
                            {
                                // The template was proven for the 0..INT32_MAX
                                // value classes; any other value keeps the bridge.
                                if (case_row->value > INT32_MAX ||
                                    machine_x64_emit_fixed_template(&encoder, MACHINE_X64_FIXED_TEMPLATE_MOV_R32_IMM32 + compare_register,
                                                                    case_row->value) == MACHINE_X64_FIXED_TEMPLATE_UNPUBLISHED)
                                {
                                    (void)machine_x64_emit_metadata_register_immediate(&encoder, S8("MOV"), compare_register,
                                                                                       case_row->value, 32, 32, 0);
                                }
                                machine_x64_emit_fixed_registers(&encoder, compare32_template, S8("CMP"), compare_register, condition, 32);
                            }
                            else
                            {
                                (void)machine_x64_emit_exact_movabs(&encoder, compare_register, case_row->value, 0);
                                machine_x64_emit_fixed_registers(&encoder, compare64_template, S8("CMP"), compare_register, condition, 64);
                            }
                            u32 branch_start = encoder.count;
                            machine_x64_emit_fixed_relative(&encoder, MACHINE_X64_FIXED_TEMPLATE_JZ_REL32, S8("JZ"));
                            MachineX64BranchFixup* case_fixup = (MachineX64BranchFixup*)machine_stream_append(arena, &fixups);
                            *case_fixup = (MachineX64BranchFixup){
                                .patch_offset = branch_start + 2,
                                .block = case_row->target_block,
                            };
                        }
                        u32 default_branch_start = encoder.count;
                        machine_x64_emit_fixed_relative(&encoder, MACHINE_X64_FIXED_TEMPLATE_JMP_REL32, S8("JMP"));
                        MachineX64BranchFixup* default_fixup = (MachineX64BranchFixup*)machine_stream_append(arena, &fixups);
                        *default_fixup = (MachineX64BranchFixup){
                            .patch_offset = default_branch_start + 1,
                            .block = machine_ref_payload(instruction->operands[1]),
                        };
                    }
                    break; default: machine_x64_exact_counters_assign(&result, exact_counters); return result;
                }
            }
            MachinePoint after = machine_point_make(instruction_index, MACHINE_POINT_AFTER);
            if (edit_cursor < placement->edit_count && placement->edits[edit_cursor].point == after)
            {
                edit_cursor = machine_x64_emit_edit_run(&encoder, function, placement, edit_cursor, after, true);
            }
        }
    }
    if (encoder.overflow)
    {
        machine_x64_exact_counters_assign(&result, exact_counters);
        return result;
    }
    bool fixups_valid = true;
    for (MachineBuilderChunk* chunk = fixups.first; chunk; chunk = chunk->next)
    {
        MachineX64BranchFixup* rows = (MachineX64BranchFixup*)(chunk + 1);
        for (u32 row_index = 0; row_index < chunk->count; row_index += 1)
        {
            MachineX64BranchFixup* fixup = rows + row_index;
            s64 displacement = 0;
            bool displacement_valid = machine_x64_block_displacement(result.block_offsets[fixup->block], fixup->addend,
                                                                      fixup->patch_offset + 4u, &displacement);
            if (fixup->label_address)
            {
                if (!displacement_valid || displacement < INT32_MIN || displacement > INT32_MAX)
                {
                    fixups_valid = false;
                    continue;
                }
                s32 encoded_displacement = (s32)displacement;
                memcpy(encoder.bytes + fixup->patch_offset, &encoded_displacement, sizeof(encoded_displacement));
            }
            else
            {
                if (!displacement_valid || displacement < INT32_MIN || displacement > INT32_MAX)
                {
                    fixups_valid = false;
                    continue;
                }
                s32 encoded_displacement = (s32)displacement;
                memcpy(encoder.bytes + fixup->patch_offset, &encoded_displacement, sizeof(encoded_displacement));
            }
        }
    }
    if (!fixups_valid)
    {
        machine_x64_exact_counters_assign(&result, exact_counters);
        return result;
    }
    result.call_sites = arena_allocate(arena, MachineCallSite, call_sites.total_count);
    result.call_site_count = call_sites.total_count;
    machine_stream_flatten(&call_sites, result.call_sites);
    result.inline_assembly_relocations =
        arena_allocate(arena, MachineInlineAssemblyRelocation, inline_assembly_relocations.total_count);
    result.inline_assembly_relocation_count = inline_assembly_relocations.total_count;
    machine_stream_flatten(&inline_assembly_relocations, result.inline_assembly_relocations);
    result.bytes = encoder.bytes;
    result.byte_count = encoder.count;
    result.valid = true;
    machine_x64_exact_counters_assign(&result, exact_counters);
    return result;
}
