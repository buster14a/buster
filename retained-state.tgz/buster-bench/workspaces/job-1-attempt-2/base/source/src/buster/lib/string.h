#pragma once
#include <buster/lib/base.h>

typedef struct OsArgumentBuilder OsArgumentBuilder;
struct OsArgumentBuilder
{
    Arena* arena;
    u64 position;
};

typedef struct StringOsListIterator StringOsListIterator;
struct StringOsListIterator
{
    StringOsList list;
    u64 position;
};


BUSTER_F_DECL String8 string_from_pointer(const char8* pointer);
BUSTER_F_DECL bool string_equal(String8 s1, String8 s2);
BUSTER_F_DECL void string_print(String8 format, ...);
BUSTER_F_DECL String8 string_format(Arena* arena, String8 format, ...);
BUSTER_F_DECL bool string_ends_with_sequence(String8 string, String8 ending);
BUSTER_F_DECL u64 string_first_code_unit(String8 string, char8 code_unit);
BUSTER_F_DECL u64 string_first_sequence(String8 string, String8 sequence);
BUSTER_F_DECL String8 string_slice(String8 slice, u64 start, u64 end);
// Windows ARM64 has eight general-purpose argument registers. Variadic
// wrappers pass the number left after their named arguments so the
// formatter can honor aggregate placement and stack alignment.
// Other targets keep their native va_arg implementation and ignore it.
#define STRING_FORMAT_VA_GP_REGISTER_COUNT 8u
#define STRING_FORMAT_VA_GP_SLOTS(named_gp_slots) ((u32)(STRING_FORMAT_VA_GP_REGISTER_COUNT - (named_gp_slots)))
BUSTER_F_DECL String8 string_format_va(Arena* arena, String8 format, va_list variable_arguments, u32 gp_register_slots_remaining);
BUSTER_F_DECL void string_write_to_file_va(OsFileDescriptor* file_handle, String8 format, va_list variable_arguments,
                                                   u32 gp_register_slots_remaining);
// Duplicate and join accept null-empty slices and fail the process on invalid
// nonempty slices or size overflow, before allocation or copying.
BUSTER_F_DECL String8 string_duplicate_arena(Arena* arena, String8 string, bool zero_terminate);
BUSTER_F_DECL bool string_starts_with_sequence(String8 string, String8 sequence);
BUSTER_F_DECL String8 string_from_pointer_length(const char8* pointer, u64 length);
BUSTER_F_DECL String8 string_join_arena(Arena* arena, SliceString8 strings, bool zero_terminate);
// Recoverable validation: false clears output and leaves the arena untouched.
// Reserved-capacity exhaustion also returns false; OS commitment failures
// follow the arena's ordinary fatal allocation policy.
BUSTER_F_DECL bool string_join_arena_attempt(Arena* arena, SliceString8 strings, bool zero_terminate, String8* output);
BUSTER_F_DECL String8 string_format_z(Arena* arena, String8 format, ...);
BUSTER_F_DECL u64 string_array_match(SliceString8 names, String8 name);
BUSTER_F_DECL bool code_unit_is_decimal(char8 code_unit);

BUSTER_F_DECL bool string16_equal(String16 s1, String16 s2);
BUSTER_F_DECL u64 string16_length(const char16* s);
BUSTER_F_DECL u64 string16_first_code_unit(String16 string, char16 code_unit);
BUSTER_F_DECL SliceString8 string16_environment_block_to_slice_string(Arena* arena, const char16* environment_block);

// BUSTER_F_DECL bool string_os_equal(StringOs s1, StringOs s2);
// BUSTER_F_DECL String8 string_os_from_pointer_length(CharOs* pointer, u64 length);
// BUSTER_F_DECL bool string_os_starts_with_sequence(StringOs string, StringOs sequence);
// BUSTER_F_DECL bool string_os_ends_with_sequence(StringOs string, StringOs ending);
// BUSTER_F_DECL u64 string_os_first_sequence(StringOs string, StringOs sequence);
// BUSTER_F_DECL StringOs string_os_slice(StringOs slice, u64 start, u64 end);
// BUSTER_F_DECL StringOs string_os_format_va(Arena* arena, StringOs format, va_list variable_arguments);
// BUSTER_F_DECL StringOs string_os_duplicate_arena(Arena* arena, StringOs string, bool zero_terminate);

// BUSTER_F_DECL StringOsListIterator string_os_list_iterator_initialize(StringOsList list);
// BUSTER_F_DECL StringOs string_os_list_iterator_next(StringOsListIterator* iterator);
BUSTER_F_DECL char** slice_string8_to_null_terminated_array_char(Arena* arena, SliceString8 strings);

BUSTER_F_DECL SliceString8 slice_string_from_posix_string_list(Arena* arena, PosixStringList string_os_list);
BUSTER_F_DECL SliceString8 slice_string_from_windows_string_list(Arena* arena, WindowsStringList string_os_list);
BUSTER_F_DECL WindowsStringList windows_string_list_from_slice_string(Arena* arena, SliceString8 parts);
BUSTER_F_DECL WindowsStringList windows_environment_block_from_slice_string(Arena* arena, SliceString8 environment);
BUSTER_F_DECL PosixStringList posix_string_list_from_slice_string(Arena* arena, SliceString8 parts);
PosixStringList posix_environment_from_keys_and_values(Arena* arena, SliceString8 keys, SliceString8 values);
WindowsStringList windows_environment_from_keys_and_values(Arena* arena, SliceString8 keys, SliceString8 values);

// Parse an unsigned digit prefix, without signs or base prefixes, within the
// slice bounds. length is the complete valid-digit prefix even on overflow;
// value saturates at UINT64_MAX on overflow and is zero for invalid/empty input.
// A nonempty null slice is invalid. No terminator or readable padding is needed.
BUSTER_F_DECL IntegerParsingU64 string8_parse_u64_hexadecimal(String8 string);
BUSTER_F_DECL IntegerParsingU64 string8_parse_u64_decimal(String8 string);
BUSTER_F_DECL IntegerParsingU64 string8_parse_u64_octal(String8 string);
BUSTER_F_DECL IntegerParsingU64 string8_parse_u64_binary(String8 string);
// The Windows OS text boundary. Paths, arguments, environment values and
// every other string crossing into or out of a wide Win32 call convert here.
// Both directions replace input they cannot represent with U+FFFD instead of
// reinterpreting it, and valid text is never altered (#106):
//   - string16_from_string8 emits one U+FFFD per byte that neither begins nor
//     completes a well-formed UTF-8 sequence, consuming exactly that one byte.
//     Invalid leaders, overlong forms, sequences truncated by the end of the
//     input, bad continuations, encoded UTF-16 surrogates and scalars above
//     U+10FFFF are all ill-formed and replaced this way.
//   - string8_from_string16 emits one U+FFFD per isolated surrogate, meaning a
//     high surrogate not directly followed by a low surrogate, including one
//     standing at the end of the input, and any low surrogate without a high
//     surrogate in front of it.
// Replacement is lossy and is not reversible byte preservation: converted text
// cannot be restored to the original bytes or code units, and converting back
// yields the replacement characters rather than the input. Callers that need
// arbitrary bytes to survive must carry them outside these conversions.
// null_terminate writes a terminator past the returned length; the result is
// allocated contiguously from arena and the unused tail of the conservative
// bound is returned to it.
BUSTER_F_DECL String16 string16_from_string8(Arena* arena, String8 string, bool null_terminate);
BUSTER_F_DECL String8 string8_from_string16(Arena* arena, String16 s, bool null_terminate);

BUSTER_F_DECL OsArgumentBuilder os_argument_builder_start(Arena* arena);
BUSTER_F_DECL void os_argument_builder_append(OsArgumentBuilder* builder, String8 string);
BUSTER_F_DECL SliceString8 os_argument_builder_flush(OsArgumentBuilder* const builder);
