from pathlib import Path
root=Path.cwd()
def edit(path, old, new, count=1):
 p=root/path;s=p.read_text();assert s.count(old)==count,(path,s.count(old),old[:90]);p.write_text(s.replace(old,new))
p=root/'src/buster/lib/compiler/object/object.c';s=p.read_text()
a=s.index('ObjectFile object_from_canonical_codegen_module(');b=s.index('\nBUSTER_GLOBAL_LOCAL u32 object_elf_relocation_type',a)
f=s[a:b]
f=f.replace('ObjectFile object_from_canonical_codegen_module(Arena* arena, IrProgram* program, CodegenModule* module, Target target)',
 'BUSTER_GLOBAL_LOCAL ObjectFile object_build_canonical_codegen_module(Arena* arena, IrProgram* program, CodegenModule* module, Target target, bool borrow_text)')
f=f.replace('    u8* text = arena_allocate(arena, u8, module->code.length);\n    if (module->code.length)\n    {\n        memcpy(text, module->code.pointer, module->code.length);\n    }',
 '''    u8* text = module->code.pointer;
    if (!borrow_text)
    {
        text = arena_allocate(arena, u8, module->code.length);
        if (module->code.length)
        {
            memcpy(text, module->code.pointer, module->code.length);
        }
    }''')
# Keep late symbol errors fail-closed when converging the existing builder to
# one return. An error exits its current loop, then the enclosing build block.
start=f.index('    if (!arena')
end=f.rindex('    return result;')
body=f[start:end].rstrip()
assert body.count('return result;')==7
body=body.replace('return result;', 'break;')
for anchor in [
 '    for (u32 global_index = 0; global_index < module->global_count; global_index += 1)\n    {\n        CodegenModuleGlobal global = module->globals[global_index];\n        IrSymbol* symbol',
 '    // An alias owns no storage:',
 '    if (apple_thread_local)\n    {\n        result.symbols[result.symbol_count++]',
]:
 assert body.count(anchor)==1,anchor
 body=body.replace(anchor,'    if (result.error != OBJECT_ERROR_NONE)\n    {\n        break;\n    }\n'+anchor)
f=f[:start]+'    do\n    {\n'+''.join('    '+line+'\n' if line else '\n' for line in body.splitlines())+'    } while (false);\n\n'+f[end:]
f+='''
ObjectFile object_from_canonical_codegen_module(Arena* arena, IrProgram* program, CodegenModule* module, Target target)
{
    return object_build_canonical_codegen_module(arena, program, module, target, false);
}

ObjectFile object_from_canonical_codegen_module_borrowed_text(Arena* arena, IrProgram* program, CodegenModule* module, Target target)
{
    return object_build_canonical_codegen_module(arena, program, module, target, true);
}
'''
s=s[:a]+f+s[b:]
s=s.replace('// (object_from_canonical_codegen_module), textual disassembly is printed',
 '''// (object_from_canonical_codegen_module; the driver-private borrowed-text
// entry shares object_build_canonical_codegen_module), textual disassembly is printed''')
p.write_text(s)
edit('src/buster/lib/compiler/object/object_internal.h', '#if BUSTER_INCLUDE_TESTS',
'''// Driver-private ownership opt-in. The completed module's code bytes must
// remain immutable and live until every object, linker and writer consumer
// finishes. Other borrowed payload/name lifetimes are unchanged. This is not
// incremental publication: the same complete builder and validation run.
BUSTER_F_DECL ObjectFile object_from_canonical_codegen_module_borrowed_text(Arena* arena, IrProgram* program, CodegenModule* module, Target target);

#if BUSTER_INCLUDE_TESTS''')
edit('src/buster/lib/compiler/driver/driver.c', '#include <buster/lib/compiler/object/object.h>',
'#include <buster/lib/compiler/object/object.h>\n#include <buster/lib/compiler/object/object_internal.h>')
edit('src/buster/lib/compiler/driver/driver.c',
'    ObjectFile object = object_from_canonical_codegen_module(arena, lowered.program, &code, invocation.target);',
'''    // Codegen completed all fixups in this arena. Single-TU results retain
    // it; the multi-TU collector evacuates the object before releasing it.
    // No writer may mutate the borrowed bytes or outlive that ownership.
    ObjectFile object = object_from_canonical_codegen_module_borrowed_text(arena, lowered.program, &code, invocation.target);''')
edit('src/buster/tests/compiler/object/object_test.c', '#include <buster/lib/compiler/object/object_internal.h>',
'#include <buster/lib/compiler/object/object_internal.h>\n#include <buster/lib/compiler/link/link.h>')
test='// Only the code buffer lives in the producer arena below. Program names and\n// every non-text payload outlive both objects, so destroying that arena tests\n// the public text snapshot, not a nonexistent whole-object ownership promise.\nBUSTER_GLOBAL_LOCAL UnitTestResult object_test_borrowed_codegen_text(UnitTestArguments* arguments)\n{\n    UnitTestResult result = {0};\n    Target targets[] = {\n        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_LINUX},\n        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_WINDOWS},\n        {.cpu_arch = CPU_ARCH_X86_64, .os = OPERATING_SYSTEM_MACOS},\n        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_LINUX},\n        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_WINDOWS},\n        {.cpu_arch = CPU_ARCH_AARCH64, .os = OPERATING_SYSTEM_MACOS},\n    };\n    for (u32 target_index = 0; target_index < BUSTER_ARRAY_LENGTH(targets); target_index += 1)\n    {\n        TemporalArena temporary = arena_begin_temporal(arguments->arena);\n        Target target = targets[target_index];\n        ObjectFormat format = object_format_for_target(target);\n        IrProgram program = ir_program_initialize(arguments->arena, 0, 0, 256, 0);\n        IrSymbolId defined = ir_program_add_symbol(&program, (IrSymbol){\n            .name = S8("borrowed_text"), .kind = IR_SYMBOL_FUNCTION, .linkage = IR_LINKAGE_EXTERNAL, .is_definition = true,\n        });\n        IrSymbolId external = ir_program_add_symbol(&program, (IrSymbol){\n            .name = S8("borrowed_external"), .kind = IR_SYMBOL_FUNCTION, .linkage = IR_LINKAGE_EXTERNAL,\n        });\n        IrSymbolId data_symbol = ir_program_add_symbol(&program, (IrSymbol){\n            .name = S8("borrowed_data"), .kind = IR_SYMBOL_DATA, .linkage = IR_LINKAGE_EXTERNAL, .is_definition = true,\n        });\n        u8 x64[] = {0xe8, 0, 0, 0, 0, 0xc3};\n        u8 arm64[] = {0, 0, 0, 0x94, 0xc0, 0x03, 0x5f, 0xd6};\n        bool aarch64 = target.cpu_arch == CPU_ARCH_AARCH64;\n        ByteSlice expected = aarch64 ? (ByteSlice)BUSTER_ARRAY_TO_SLICE(arm64) : (ByteSlice)BUSTER_ARRAY_TO_SLICE(x64);\n        u8 pristine[sizeof(arm64)];\n        memcpy(pristine, expected.pointer, expected.length);\n        Arena* producer = arena_create((ArenaCreation){.reserved_size = BUSTER_MB(1), .flags = {.no_pool = 1}});\n        if (BUSTER_REQUIRE(arguments, producer != 0))\n        {\n            u8* text = arena_allocate(producer, u8, expected.length);\n            if (BUSTER_REQUIRE(arguments, text != 0))\n            {\n                memcpy(text, expected.pointer, expected.length);\n                CodegenModuleEntry entry = {.symbol = defined};\n                CodegenFunctionDescriptor function = {.symbol = defined, .code_size = (u32)expected.length};\n                CodegenModuleRelocation relocation = {\n                    .symbol = external, .offset = aarch64 ? 0u : 1u,\n                    .kind = aarch64 ? CODEGEN_MODULE_RELOCATION_AARCH64_CALL26 : CODEGEN_MODULE_RELOCATION_X86_64_PC32,\n                };\n                CodegenModule module = {\n                    .code = {.pointer = text, .length = expected.length}, .entries = &entry, .functions = &function,\n                    .relocations = &relocation, .abi = codegen_abi_for_target(target),\n                    .entry_count = 1, .function_count = 1, .relocation_count = 1,\n                };\n                ObjectFile owned = object_from_canonical_codegen_module(arguments->arena, &program, &module, target);\n                ObjectFile borrowed = object_from_canonical_codegen_module_borrowed_text(arguments->arena, &program, &module, target);\n                if (BUSTER_REQUIRE(arguments, owned.error == OBJECT_ERROR_NONE && borrowed.error == OBJECT_ERROR_NONE &&\n                                               owned.sections && borrowed.sections &&\n                                               owned.section_count > OBJECT_SECTION_TEXT && borrowed.section_count > OBJECT_SECTION_TEXT))\n                {\n                    BUSTER_TEST(arguments, owned.sections[OBJECT_SECTION_TEXT].data.pointer != text);\n                    BUSTER_TEST(arguments, borrowed.sections[OBJECT_SECTION_TEXT].data.pointer == text);\n                    BUSTER_TEST(arguments, owned.sections[OBJECT_SECTION_TEXT].data.length == expected.length);\n                    BUSTER_TEST(arguments, borrowed.sections[OBJECT_SECTION_TEXT].data.length == expected.length);\n                    BUSTER_TEST(arguments, owned.symbol_count == borrowed.symbol_count && owned.relocation_count == borrowed.relocation_count);\n                    // Alternate consumers and repeat writers. COFF and Mach-O\n                    // inline addends must patch the artifact, never the module.\n                    for (u32 repeat = 0; repeat < 2; repeat += 1)\n                    {\n                        ObjectArtifact left = object_write(arguments->arena, &owned, format);\n                        ObjectArtifact right = object_write(arguments->arena, &borrowed, format);\n                        if (BUSTER_REQUIRE(arguments, left.error == OBJECT_ERROR_NONE && right.error == OBJECT_ERROR_NONE &&\n                                                       left.bytes.pointer && right.bytes.pointer && left.bytes.length == right.bytes.length))\n                        {\n                            BUSTER_TEST(arguments, memory_compare(left.bytes.pointer, right.bytes.pointer, left.bytes.length));\n                            ObjectFile decoded = object_read(arguments->arena, right.bytes, target);\n                            BUSTER_TEST(arguments, decoded.error == OBJECT_ERROR_NONE);\n                        }\n                        String8 left_assembly = object_print_assembly(arguments->arena, &owned);\n                        String8 right_assembly = object_print_assembly(arguments->arena, &borrowed);\n                        BUSTER_TEST(arguments, left_assembly.length && string_equal(left_assembly, right_assembly));\n                        BUSTER_TEST(arguments, memory_compare(text, expected.pointer, expected.length));\n                    }\n                    // Both linker policies consume the same immutable input.\n                    // The normal copy is the evacuation operation needed before\n                    // a producer dies; the one-input opt-in retains its lifetime.\n                    LinkObjectResult evacuated = link_objects(arguments->arena, &borrowed, 1, (LinkOptions){.allow_undefined_symbols = true});\n                    LinkObjectResult aliased = link_objects(arguments->arena, &borrowed, 1,\n                        (LinkOptions){.allow_undefined_symbols = true, .alias_single_input_sections = true});\n                    if (BUSTER_REQUIRE(arguments, evacuated.error == LINK_ERROR_NONE && aliased.error == LINK_ERROR_NONE &&\n                                                   evacuated.object.sections && aliased.object.sections &&\n                                                   evacuated.object.section_count > OBJECT_SECTION_TEXT && aliased.object.section_count > OBJECT_SECTION_TEXT))\n                    {\n                        BUSTER_TEST(arguments, evacuated.object.sections[OBJECT_SECTION_TEXT].data.pointer != text);\n                        BUSTER_TEST(arguments, aliased.object.sections[OBJECT_SECTION_TEXT].data.pointer == text);\n                        BUSTER_TEST(arguments, memory_compare(text, expected.pointer, expected.length));\n                        // All borrowed consumers finish before teardown. Do not\n                        // access borrowed or aliased after destroying producer.\n                        memset(text, 0xa5, expected.length);\n                        BUSTER_TEST(arguments, arena_destroy(producer, 1));\n                        producer = 0;\n                        ObjectArtifact retained = object_write(arguments->arena, &owned, format);\n                        ObjectArtifact copied = object_write(arguments->arena, &evacuated.object, format);\n                        BUSTER_TEST(arguments, retained.error == OBJECT_ERROR_NONE && copied.error == OBJECT_ERROR_NONE);\n                        BUSTER_TEST(arguments, memory_compare(owned.sections[OBJECT_SECTION_TEXT].data.pointer, expected.pointer, expected.length));\n                        BUSTER_TEST(arguments, memory_compare(evacuated.object.sections[OBJECT_SECTION_TEXT].data.pointer, expected.pointer, expected.length));\n                    }\n                }\n                // Reuse independent valid bytes for every diagnostic control;\n                // the former producer may already be unmapped.\n                module.code = expected;\n                for (u32 failure = 0; failure < 8; failure += 1)\n                {\n                    CodegenModule bad = module;\n                    CodegenModuleEntry bad_entry = entry;\n                    CodegenFunctionDescriptor bad_function = function;\n                    CodegenModuleRelocation bad_relocation = relocation;\n                    CodegenModuleGlobal bad_global = {.symbol = data_symbol, .size = 1};\n                    IrSymbolAlias bad_alias = {.symbol = defined, .target = {.value = UINT32_MAX}};\n                    IrModule bad_ir = {.aliases = &bad_alias, .alias_count = 1};\n                    bad.entries = &bad_entry;\n                    bad.functions = &bad_function;\n                    bad.relocations = &bad_relocation;\n                    switch (failure)\n                    {\n                        case 0: bad.error = CODEGEN_ERROR_INVALID_IR; break;\n                        case 1: bad.entry_count = 0; break;\n                        case 2: bad_function.code_size += 1; break;\n                        case 3: bad_relocation.offset = (u32)expected.length; break;\n                        case 4: bad_entry.symbol.value = UINT32_MAX; bad_function.symbol = bad_entry.symbol; break;\n                        case 5: bad_global.symbol = external; bad.globals = &bad_global; bad.global_count = 1; break;\n                        case 6: bad.globals = &bad_global; bad.global_count = 1; break;\n                        case 7: bad.ir_module = &bad_ir; break;\n                        default: BUSTER_TODO();\n                    }\n                    ObjectFile left = object_from_canonical_codegen_module(arguments->arena, &program, &bad, target);\n                    ObjectFile right = object_from_canonical_codegen_module_borrowed_text(arguments->arena, &program, &bad, target);\n                    BUSTER_TEST(arguments, left.error == OBJECT_ERROR_INVALID_INPUT && right.error == left.error);\n                    ObjectArtifact refused = object_write(arguments->arena, &right, format);\n                    BUSTER_TEST(arguments, refused.error != OBJECT_ERROR_NONE && !refused.bytes.length);\n                    BUSTER_TEST(arguments, memory_compare(expected.pointer, pristine, expected.length));\n                }\n            }\n            if (producer) BUSTER_TEST(arguments, arena_destroy(producer, 1));\n        }\n        CodegenModule empty = {0};\n        ObjectFile empty_owned = object_from_canonical_codegen_module(arguments->arena, &program, &empty, target);\n        ObjectFile empty_borrowed = object_from_canonical_codegen_module_borrowed_text(arguments->arena, &program, &empty, target);\n        if (BUSTER_REQUIRE(arguments, empty_owned.error == OBJECT_ERROR_NONE && empty_borrowed.error == OBJECT_ERROR_NONE &&\n                                       empty_owned.sections && empty_borrowed.sections &&\n                                       empty_owned.section_count > OBJECT_SECTION_TEXT && empty_borrowed.section_count > OBJECT_SECTION_TEXT))\n        {\n            BUSTER_TEST(arguments, !empty_owned.sections[OBJECT_SECTION_TEXT].data.length && !empty_borrowed.sections[OBJECT_SECTION_TEXT].data.length);\n            ObjectArtifact left = object_write(arguments->arena, &empty_owned, format);\n            ObjectArtifact right = object_write(arguments->arena, &empty_borrowed, format);\n            if (BUSTER_REQUIRE(arguments, left.error == OBJECT_ERROR_NONE && right.error == OBJECT_ERROR_NONE &&\n                                           left.bytes.pointer && right.bytes.pointer && left.bytes.length == right.bytes.length))\n            {\n                BUSTER_TEST(arguments, memory_compare(left.bytes.pointer, right.bytes.pointer, left.bytes.length));\n            }\n        }\n        scratch_end(temporary);\n    }\n    return result;\n}\n\n'
edit('src/buster/tests/compiler/object/object_test.c', 'UnitTestResult object_tests(UnitTestArguments* arguments)\n{\n    UnitTestResult result = object_test_assembly_index_order(arguments);',
 test+'''UnitTestResult object_tests(UnitTestArguments* arguments)
{
    UnitTestResult result = object_test_assembly_index_order(arguments);
    UnitTestResult borrowed_text = object_test_borrowed_codegen_text(arguments);
    result.test_count += borrowed_text.test_count;
    result.succeeded_test_count += borrowed_text.succeeded_test_count;''')
# Serial result must remain usable after later invocations recycle worker/TU
# arenas. Compare serialized objects as well as already-written executables.
edit('src/buster/tests/compiler/driver/driver_test.c',
'''                // Grow/reuse a gang, take an odd final batch, then shrink it.
                // The final serial repetition also catches recycled arenas.''',
'''                ObjectArtifact retained = {0};
                bool retained_object = BUSTER_REQUIRE(arguments, serial.error == COMPILER_DRIVER_ERROR_NONE && serial.has_object);
                if (retained_object)
                {
                    retained = object_write(arena, &serial.object, object_format_for_target(serial.object.target));
                    retained_object = BUSTER_REQUIRE(arguments, retained.error == OBJECT_ERROR_NONE && retained.bytes.pointer && retained.bytes.length);
                }
                // Grow/reuse a gang, take an odd final batch, then shrink it.
                // Re-serialize the previous returned object after each run:
                // comparing only output files would miss dangling TU payloads.''')
edit('src/buster/tests/compiler/driver/driver_test.c',
'''                    ByteSlice candidate = file_read(arena, output, (FileReadOptions){0});
                    BUSTER_TEST(arguments, candidate.length == original.length && candidate.length &&
                                          memory_compare(candidate.pointer, original.pointer, candidate.length));''',
'''                    ByteSlice candidate = file_read(arena, output, (FileReadOptions){0});
                    BUSTER_TEST(arguments, candidate.length == original.length && candidate.length &&
                                          memory_compare(candidate.pointer, original.pointer, candidate.length));
                    if (retained_object)
                    {
                        ObjectArtifact again = object_write(arena, &serial.object, object_format_for_target(serial.object.target));
                        if (BUSTER_REQUIRE(arguments, again.error == OBJECT_ERROR_NONE && again.bytes.pointer && again.bytes.length == retained.bytes.length))
                        {
                            BUSTER_TEST(arguments, memory_compare(again.bytes.pointer, retained.bytes.pointer, retained.bytes.length));
                        }
                    }''')
edit('docs/agents/driver.md', '## Opt-in native translation-unit lanes',
'''## Native object text lifetime

After successful canonical code generation, the native C driver calls the
private `object_from_canonical_codegen_module_borrowed_text` entry. Object
construction still performs all descriptor, relocation and metadata checks;
only the generated `.text` allocation and copy are omitted. The completed
code buffer stays immutable in the TU/result arena through object, assembly
and link consumers. A single TU retains its arena; the ordered multi-TU
collector still deep-copies the complete compact object before destroying
its source arena. Writer relocation patches belong to the writer's output,
never the shared input. No partial codegen result becomes publishable.

The public `object_from_canonical_codegen_module` remains a supported text
snapshot operation, not a migration shim. Its other borrowed data and name
lifetimes are unchanged; an independent text snapshot does not make the whole
object independent of its program/module. Do not move arena teardown earlier
or opt another caller into borrowing without proving its final consumer.

## Opt-in native translation-unit lanes''')
print('applied bounded borrowed-text prototype')
