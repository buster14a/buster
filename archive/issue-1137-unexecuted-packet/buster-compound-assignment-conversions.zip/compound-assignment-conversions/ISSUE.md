# c: preserve RHS arithmetic type through non-atomic compound assignment

## Evidence state: source-confirmed mechanism; runtime reproduction pending

Validate and repair a distinct conversion-placement defect in
`src/buster/lib/compiler/frontend/c/c_gen.c::c_ir_emit_compound_assignment`.
Do not label this report as a fresh runtime reproduction: no Clang, GCC or
Buster test was executed by the originating read-only session. An uncompiled
three-file candidate and an 84-case deterministic family accompany this body.

Pinned main: `fdebfb8810ed4db8c69d3b176f89f835fb77259c`.
Tree: `66c1f549efacaa54c3c4e94738407d5e1b312919`.
Full `c_gen.c` blob: `60bf69ed970fc43d84fa3f7198aac5d1410b0eb9`.
The large source was recovered from correctness artifact 10815042424 and its
full blob matched against pinned main. No result from that older run is
transferred to this investigation.

## Minimal discriminator and rule

```c
int main(void)
{
    int value = 3;
    value *= 1.5;
    return value != 4;
}
```

Expected exit is zero: C compound assignment performs the corresponding binary
arithmetic before assignment conversion, with one evaluation of the designator
(N1570 6.5.16.2p3). The double product 4.5 converts to int 4. This program has no
order-sensitive side effects, overflow or implementation-defined result.

The current helper casts `right` to `value_type` and assigns that cast to
`operation_right` before calling `c_ir_apply_operation`. For an int destination
this discards 1.5's fractional part before multiplication. The predicted result
is 3, but that prediction still needs execution. The binary emitter chooses
its operation from the operand types it receives, and the store helper already
performs the final assignment conversion. A type-valid canonical module can
therefore encode the wrong source semantics.

## Bounded validation

First falsify the explanation with the minimal source, independent Clang/GCC
GNU17 x86-64 Linux references and the exact baseline. Inspect raw frontend IR
before shared preparation. Do not blame a backend merely because all allocators
agree, and do not claim parser/semantic acceptance without running those paths.

The attached family has 84 isolated inputs: four distinguishing arithmetic
rows plus two controls, each with plain/volatile places across initializers,
arguments, returns, conditions, expression statements and GNU statement
expressions, plus bit-field and saved-place expansion controls. All require
exit zero. Separate counters test one designator/RHS evaluation without imposing
an order between them. Right helpers do not access the destination or left
counter. Ordinary saved-place expansion is equivalent only under that
noninterference condition.

Use `-std=gnu17 -fwrapv -fno-strict-aliasing -funsigned-char` with matched target
and O0/O2. Capture compiler versions/binary hashes, exact source revisions,
compile diagnostics, every executed status and timeouts. Retain sanitizer
results as corroboration, not proof of defined behavior. Run on standard
GitHub-hosted runners only; this is correctness work, not benchmark-service work.

## Candidate and coordination

The candidate adds an atomic guard to the existing pre-conversion arm, retaining
the original RHS for ordinary arithmetic and leaving final assignment/result
conversion in place. It adds raw canonical tests and a registered native runtime
matrix in `c_test.c` and clarifies the calls guide. It has not been compiled.

Recheck current main and overlapping PRs before applying. #1040/#1102 own comma
call preparation; #1101 owns choose-expression preparation; #1131/#1132 own
sizeof/VLA evaluation. Those are not discoveries to file again. #361/#370's
qualified-value repair is an architectural clue, but its narrow-RHS addition
control does not test premature arithmetic conversion. The current candidate
does not edit the preparation helpers or another contributor branch.

Retain C-only, one-return, arena, explicit-work-stack, canonical-IR, SIMD and
persistent-lane contracts. No new framework/dependency/IR, no weakened verifier,
no generated binding edit, no #36 work, no new retirement prerequisite, and no
merge or protection change. Atomic mixed-type arithmetic is deliberately not
repaired by this narrow patch; preserve existing atomic tests and report that
scope explicitly.

## Completion criteria

Confirm correct Clang/GCC results; preserve actual baseline failures and passing
controls; require the candidate to pass all 84 inputs, the 96 raw-IR lowerings,
and all 16 registered runtime configurations. Run the normal full Release,
sanitizer/configuration/platform gates and before/after self-host fixed point.
Keep useful negative controls and inspect any new discrepancy rather than
changing its oracle. Publish a narrowly scoped draft PR with exact submitted
revision and actual CI evidence. Do not claim completion based on patch
application, source hashing, historical CI or unavailable execution.
