# Standard-runner replay (NOT EXECUTED)

Use a standard GitHub-hosted Linux x86-64 correctness job and complete repository
worktrees, not the partial artifact snapshot used for source inspection.
Do not use a desktop, the 9700X performance route, an improvised SSH route, or
change a runner policy. Nothing in this packet dispatches a workflow.

## Source and build identity

Pin baseline commit `fdebfb8810ed4db8c69d3b176f89f835fb77259c`, tree
`66c1f549efacaa54c3c4e94738407d5e1b312919`. Build its trusted Clang-produced
compiler through the existing documented hosted build path. Preserve the normal
before-change self-host result. Create an independently owned candidate worktree
at that same base, check/apply `candidate.patch`, record its actual source commit
and tree, then build through the same path. Do not build or publish from the
partial recovered source archive. Do not pretend the candidate has a published
commit: none was created in the originating session.

```sh
git rev-parse HEAD HEAD^{tree}
git hash-object src/buster/lib/compiler/frontend/c/c_gen.c
# Must match the recorded baseline identities before applying in the candidate.
git apply --check --whitespace=error-all /absolute/packet/candidate.patch
git apply /absolute/packet/candidate.patch
```

Keep exact build commands, source commit/tree, compiler versions and resulting
binary SHA-256s with the logs. Do not infer a compiler's source identity merely
from its path/name. `BASE_IDE` and `CANDIDATE_IDE` below must name those separately
built compiler binaries, not self-built benchmark artifacts.

## Cheapest discriminator first

With `PACKET` set to the extracted packet's absolute directory, run:

```sh
scratch="$(mktemp -d)"
if clang --target=x86_64-unknown-linux-gnu -m64 -std=gnu17 -fwrapv \
  -fno-strict-aliasing -funsigned-char -O0 "$PACKET/minimal.c" -o "$scratch/clang"
then
  if "$scratch/clang"; then status=0; else status="$?"; fi
  printf 'clang exit=%s\n' "$status"
  test "$status" = 0 || exit 1
else
  printf 'clang compilation failed; program NOT RUN\n' >&2
  exit 1
fi

if gcc -m64 -std=gnu17 -fwrapv -fno-strict-aliasing -funsigned-char -O0 \
  "$PACKET/minimal.c" -o "$scratch/gcc"
then
  if "$scratch/gcc"; then status=0; else status="$?"; fi
  printf 'gcc exit=%s\n' "$status"
  test "$status" = 0 || exit 1
else
  printf 'gcc compilation failed; program NOT RUN\n' >&2
  exit 1
fi

if "$BASE_IDE" cc --target=x86_64-unknown-linux-gnu -std=gnu17 -fwrapv \
  -fno-strict-aliasing -funsigned-char -O0 -ffrontend-ssa \
  -fregister-allocator=none -fverify-codegen "$PACKET/minimal.c" -o "$scratch/base"
then
  if "$scratch/base"; then status=0; else status="$?"; fi
  printf 'buster baseline exit=%s\n' "$status"
else
  printf 'Buster baseline compilation failed; program NOT RUN\n' >&2
  exit 1
fi
```

Both references must compile and exit zero. The predicted baseline exit is one,
not an established observation. A compile failure is a different result; do not
execute a stale output after one. Remove output files before retries, or use
unique output paths. If baseline exits zero, inspect its raw lowering and explain
why the source-derived prediction did not apply before expanding the run.

## Bounded reference/baseline/candidate family

The following Bash block is diagnostic transport, not a repository build system.
It assumes the prior build-identity steps are complete. It records compile
failures separately from unexecuted programs and never silently suppresses a
case because another case failed. Run it only after the initial discriminator
justifies the wider experiment.

```bash
set -u
: "${PACKET:?absolute extracted packet path}"
: "${BASE_IDE:?absolute trusted baseline compiler path}"
: "${CANDIDATE_IDE:?absolute trusted candidate compiler path}"
test "${GITHUB_ACTIONS:-}" = true || exit 2
test "${RUNNER_ENVIRONMENT:-}" = github-hosted || exit 2
case "$(gcc -dumpmachine)" in x86_64-*linux-gnu*) ;; *) exit 2 ;; esac

mkdir -p "$PACKET/results"
results="$PACKET/results"
clang --version > "$results/clang-version.txt"
gcc --version > "$results/gcc-version.txt"
gcc -dumpmachine > "$results/gcc-target.txt"
uname -a > "$results/host.txt"
sha256sum "$BASE_IDE" "$CANDIDATE_IDE" > "$results/compiler-binaries.sha256"
sha256sum "$PACKET"/cases/*.c > "$results/inputs.sha256"
printf 'configuration\tcase\tcompile_exit\trun_exit\n' > "$results/status.tsv"

run_case()
{
    local configuration="$1" input="$2"
    shift 2
    local name stem output compile_exit run_exit
    name="$(basename "$input" .c)"
    stem="$results/$configuration-$name"
    output="$stem.exe"
    rm -f "$output"
    printf '%q ' "$@" -std=gnu17 -nostdinc -fwrapv -fno-strict-aliasing \
        -funsigned-char "$input" -o "$output" > "$stem.command"
    printf '\n' >> "$stem.command"
    if timeout 120 "$@" -std=gnu17 -nostdinc -fwrapv -fno-strict-aliasing \
        -funsigned-char "$input" -o "$output" > "$stem.compile.log" 2>&1
    then
        compile_exit=0
        if timeout 30 "$output" > "$stem.run.log" 2>&1
        then run_exit=0
        else run_exit="$?"
        fi
    else
        compile_exit="$?"
        run_exit=NOT_RUN
    fi
    printf '%s\t%s\t%s\t%s\n' "$configuration" "$name" "$compile_exit" "$run_exit" \
        >> "$results/status.tsv"
}

for source in "$PACKET"/cases/*.c
 do
    for opt in O0 O2
     do
        run_case "clang-$opt" "$source" clang --target=x86_64-unknown-linux-gnu -m64 "-$opt"
        run_case "gcc-$opt" "$source" gcc -m64 "-$opt"
     done
    run_case clang-sanitize "$source" clang --target=x86_64-unknown-linux-gnu -m64 \
        -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all
    run_case gcc-sanitize "$source" gcc -m64 -O1 -g \
        -fsanitize=address,undefined -fno-sanitize-recover=all
    for revision in base candidate
     do
        if test "$revision" = base; then compiler="$BASE_IDE"; else compiler="$CANDIDATE_IDE"; fi
        for allocator in none mir-stack fast quality
         do
            for frontend in -ffrontend-ssa -fno-frontend-ssa
             do
                for opt in O0 O2
                 do
                    run_case "buster-$revision-$allocator-$frontend-$opt" "$source" \
                        "$compiler" cc --target=x86_64-unknown-linux-gnu \
                        "-$opt" "$frontend" "-fregister-allocator=$allocator" -fverify-codegen
                 done
             done
         done
     done
 done

# Report every nonzero/unexecuted observation; baseline failures remain visible.
awk -F '\t' 'NR == 1 || $3 != "0" || $4 != "0"' "$results/status.tsv" \
    > "$results/nonzero-or-unexecuted.tsv"
# Fail the transport on any reference/candidate failure. This does not certify
# the predicted baseline pattern; inspect it and the raw-IR evidence separately.
awk -F '\t' 'NR > 1 && $1 !~ /^buster-base-/ && ($3 != "0" || $4 != "0") { bad=1 } END { exit bad }' \
    "$results/status.tsv"
```

Expected inventory: 84 sources × (6 reference + 32 Buster configurations) =
3192 compile observations, with executions recorded only after successful builds.
A timeout, crash, sanitizer report or NOT_RUN is not success. Preserve compiler
stdout/stderr and exact commands even when a later phase fails. The unexecuted
packet itself contains no such result table.

Individual program status is a bitmask: bit 0 expression-value mismatch, bit 1
stored-value mismatch, bit 2 place-helper count mismatch, bit 3 RHS-helper count
mismatch. The statement context intentionally checks only state and counts.
The aggregate `runtime-family.c` instead returns the first failed probe ordinal
(1–84) and still calls every probe. `manifest.json` maps ordinal to isolated case.

## Raw canonical evidence and normal gates

`c_test_compound_conversion_ir` observes the raw module before
`ir_prepare_canonical_module`. Its multiply row requires one float64 multiply;
its byte division row requires one unsigned32 divide; both keep volatile
access flags separate from value types. A baseline diagnostic build needs the
**test-only** hunk applied while keeping all baseline production bytes unchanged.
Record that actual diagnostic tree; do not label it the unmodified main tree.
The candidate build uses the complete patch. Keep any baseline failure and the
corresponding candidate result with its source and configuration.

The runtime fixture is registered in the existing frontend test module. The
normal full suite therefore runs it; no new test module, generated binding,
workflow prerequisite or runner recipe is needed. Use existing hosted build
orchestration for the configured gates, including:

```sh
./build.sh build --config Release -t test_all
./build.sh test_self_host --config Release
./build.sh test_mode_matrix --config Release
```

Retain the ordinary sanitizer/configuration/platform gates and before/after
self-host fixed point. Do not run `generate` over a live build tree. A completed
84-case replay does not replace these gates, and an all-allocator agreement
does not by itself prove a correct frontend. Do not promote or merge the
candidate without actual current-head evidence; the originating mission does
not authorize a merge at all.
