/* same_volatile_initializer: expected exit 0. Source-derived oracle; not yet executed.
   Same-type integral multiplication: 3 * 2 = 6.
   The two helpers modify different counters. Their relative order is not tested. */
_Static_assert(sizeof(int) == 4 && (unsigned char)256u == 0, "target widths");
static volatile int object;
static unsigned left_calls;
static unsigned right_calls;
static volatile int* slot(void)
{
    left_calls += 1;
    return &object;
}
static int right(void)
{
    right_calls += 1;
    return 2;
}
int main(void)
{
    object = 3;
    left_calls = 0;
    right_calls = 0;
    int observed = (*slot() *= right());
    int value_ok = observed == 6;
    return !value_ok | ((object != 6) << 1) |
           ((left_calls != 1) << 2) | ((right_calls != 1) << 3);
}
