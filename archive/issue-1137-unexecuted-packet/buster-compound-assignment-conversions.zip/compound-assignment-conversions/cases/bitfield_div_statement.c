/* bitfield_div_statement: expected exit 0. Source-derived oracle; not yet executed.
   Unsigned 8-bit bit-field promotes to int; usual conversions with 257u produce unsigned division yielding zero.
   The two helpers modify different counters. Their relative order is not tested. */
_Static_assert(sizeof(int) == 4 && (unsigned char)256u == 0, "target widths");
struct Bits { unsigned value : 8; };
static struct Bits object;
static unsigned left_calls;
static unsigned right_calls;
static struct Bits* slot(void)
{
    left_calls += 1;
    return &object;
}
static unsigned right(void)
{
    right_calls += 1;
    return 257u;
}
int main(void)
{
    object.value = 200;
    left_calls = 0;
    right_calls = 0;
    (slot()->value /= right());
    int value_ok = 1;
    return !value_ok | ((object.value != 0) << 1) |
           ((left_calls != 1) << 2) | ((right_calls != 1) << 3);
}
