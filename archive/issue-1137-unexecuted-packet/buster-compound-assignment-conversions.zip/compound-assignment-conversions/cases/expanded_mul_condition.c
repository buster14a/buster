/* expanded_mul_condition: expected exit 0. Source-derived oracle; not yet executed.
   Save the designator once; evaluate ordinary int-times-double arithmetic; assign the converted result.
   The two helpers modify different counters. Their relative order is not tested. */
_Static_assert(sizeof(int) == 4 && (unsigned char)256u == 0, "target widths");
static int object;
static unsigned left_calls;
static unsigned right_calls;
static int* slot(void)
{
    left_calls += 1;
    return &object;
}
static double right(void)
{
    right_calls += 1;
    return 1.5;
}
int main(void)
{
    object = 3;
    left_calls = 0;
    right_calls = 0;
    int value_ok;
    if ((({ int* saved_place = slot(); *saved_place = *saved_place * right(); })) == 4)
    {
        value_ok = 1;
    }
    else
    {
        value_ok = 0;
    }
    return !value_ok | ((object != 4) << 1) |
           ((left_calls != 1) << 2) | ((right_calls != 1) << 3);
}
