/* byte_add_plain_argument: expected exit 0. Source-derived oracle; not yet executed.
   200 + 257 = 457; unsigned-char assignment reduces modulo 256 to 201.
   The two helpers modify different counters. Their relative order is not tested. */
_Static_assert(sizeof(int) == 4 && (unsigned char)256u == 0, "target widths");
static unsigned char object;
static unsigned left_calls;
static unsigned right_calls;
static unsigned char* slot(void)
{
    left_calls += 1;
    return &object;
}
static unsigned right(void)
{
    right_calls += 1;
    return 257u;
}
static int identity(int value)
{
    return value;
}
int main(void)
{
    object = 200;
    left_calls = 0;
    right_calls = 0;
    int observed = identity(*slot() += right());
    int value_ok = observed == 201;
    return !value_ok | ((object != 201) << 1) |
           ((left_calls != 1) << 2) | ((right_calls != 1) << 3);
}
