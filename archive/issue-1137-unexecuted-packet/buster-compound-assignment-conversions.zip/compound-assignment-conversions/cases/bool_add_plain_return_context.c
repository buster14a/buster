/* bool_add_plain_return_context: expected exit 0. Source-derived oracle; not yet executed.
   Integer promotions give 1 + (-1) = 0, then conversion to _Bool gives zero.
   The two helpers modify different counters. Their relative order is not tested. */
_Static_assert(sizeof(int) == 4 && (unsigned char)256u == 0, "target widths");
static _Bool object;
static unsigned left_calls;
static unsigned right_calls;
static _Bool* slot(void)
{
    left_calls += 1;
    return &object;
}
static int right(void)
{
    right_calls += 1;
    return -1;
}
static int return_value(void)
{
    return (*slot() += right());
}
int main(void)
{
    object = 1;
    left_calls = 0;
    right_calls = 0;
    int observed = return_value();
    int value_ok = observed == 0;
    return !value_ok | ((object != 0) << 1) |
           ((left_calls != 1) << 2) | ((right_calls != 1) << 3);
}
