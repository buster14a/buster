/* mul_plain_argument: expected exit 0. Source-derived oracle; not yet executed.
   3 * 1.5 = 4.5; conversion to int produces 4.
   The two helpers modify different counters. Their relative order is not tested. */
_Static_assert(sizeof(int) == 4 && (unsigned char)256u == 0, "target widths");
static int object;
static unsigned left_calls;
static unsigned right_calls;
static int* slot(void)
{
    left_calls += 1;
    return &object;
}
static double right(void)
{
    right_calls += 1;
    return 1.5;
}
static int identity(int value)
{
    return value;
}
int main(void)
{
    object = 3;
    left_calls = 0;
    right_calls = 0;
    int observed = identity(*slot() *= right());
    int value_ok = observed == 4;
    return !value_ok | ((object != 4) << 1) |
           ((left_calls != 1) << 2) | ((right_calls != 1) << 3);
}
