/* GNU17, x86-64 Linux: conversion-placement family; no order oracle. */
_Static_assert(sizeof(int) == 4 && (unsigned char)256u == 0,
               "This bounded oracle requires the recorded target widths");

#define CONTEXTS(N, EXPR, EXPECTED) \
static int N##_identity(int value) { return value; } \
static int N##_return_value(void) { return (EXPR); } \
static int N##_initializer(void) \
{ N##_reset(); int observed = (EXPR); return N##_check(observed == (EXPECTED)); } \
static int N##_argument(void) \
{ N##_reset(); int observed = N##_identity((EXPR)); return N##_check(observed == (EXPECTED)); } \
static int N##_return_context(void) \
{ N##_reset(); int observed = N##_return_value(); return N##_check(observed == (EXPECTED)); } \
static int N##_condition(void) \
{ N##_reset(); int matched; if ((EXPR) == (EXPECTED)) matched = 1; else matched = 0; return N##_check(matched); } \
static int N##_statement(void) \
{ N##_reset(); (EXPR); return N##_check(1); } \
static int N##_extension(void) \
{ N##_reset(); int observed = ({ int captured = (EXPR); captured; }); return N##_check(observed == (EXPECTED)); }

#define SCALAR(N, TYPE, QUALIFIER, INITIAL, RHS_TYPE, RHS, OP, EXPECTED) \
static QUALIFIER TYPE N##_object; \
static unsigned N##_left_calls; \
static unsigned N##_right_calls; \
static QUALIFIER TYPE* N##_slot(void) \
{ N##_left_calls += 1; return &N##_object; } \
static RHS_TYPE N##_rhs(void) \
{ N##_right_calls += 1; return (RHS); } \
static void N##_reset(void) \
{ N##_object = (INITIAL); N##_left_calls = 0; N##_right_calls = 0; return; } \
static int N##_check(int value_ok) \
{ return !value_ok | ((N##_object != (EXPECTED)) << 1) | ((N##_left_calls != 1) << 2) | ((N##_right_calls != 1) << 3); } \
CONTEXTS(N, (*N##_slot() OP N##_rhs()), EXPECTED)

SCALAR(mul_plain, int, , 3, double, 1.5, *=, 4)
SCALAR(mul_volatile, int, volatile, 3, double, 1.5, *=, 4)
SCALAR(div_plain, int, , 3, double, 1.5, /=, 2)
SCALAR(div_volatile, int, volatile, 3, double, 1.5, /=, 2)
SCALAR(byte_div_plain, unsigned char, , 200, unsigned, 257u, /=, 0)
SCALAR(byte_div_volatile, unsigned char, volatile, 200, unsigned, 257u, /=, 0)
SCALAR(bool_add_plain, _Bool, , 1, int, -1, +=, 0)
SCALAR(bool_add_volatile, _Bool, volatile, 1, int, -1, +=, 0)
SCALAR(same_plain, int, , 3, int, 2, *=, 6)
SCALAR(same_volatile, int, volatile, 3, int, 2, *=, 6)
SCALAR(byte_add_plain, unsigned char, , 200, unsigned, 257u, +=, 201)
SCALAR(byte_add_volatile, unsigned char, volatile, 200, unsigned, 257u, +=, 201)

/* A narrow unsigned bit-field is an important control: the old helper
   already exempts this representation from its premature RHS conversion. */
static struct Bits { unsigned value : 8; } bitfield_object;
static unsigned bitfield_left_calls;
static unsigned bitfield_right_calls;
static struct Bits* bitfield_div_slot(void)
{ bitfield_left_calls += 1; return &bitfield_object; }
static unsigned bitfield_div_rhs(void)
{ bitfield_right_calls += 1; return 257u; }
static void bitfield_div_reset(void)
{ bitfield_object.value = 200; bitfield_left_calls = 0; bitfield_right_calls = 0; return; }
static int bitfield_div_check(int value_ok)
{ return !value_ok | ((bitfield_object.value != 0) << 1) | ((bitfield_left_calls != 1) << 2) | ((bitfield_right_calls != 1) << 3); }
CONTEXTS(bitfield_div, (bitfield_div_slot()->value /= bitfield_div_rhs()), 0)

/* The saved-place expansion is equivalent here: rhs modifies only its own
   counter, not the pointer, destination, or left counter. No order is tested. */
static int expanded_object;
static unsigned expanded_left_calls;
static unsigned expanded_right_calls;
static int* expanded_mul_slot(void)
{ expanded_left_calls += 1; return &expanded_object; }
static double expanded_mul_rhs(void)
{ expanded_right_calls += 1; return 1.5; }
static void expanded_mul_reset(void)
{ expanded_object = 3; expanded_left_calls = 0; expanded_right_calls = 0; return; }
static int expanded_mul_check(int value_ok)
{ return !value_ok | ((expanded_object != 4) << 1) | ((expanded_left_calls != 1) << 2) | ((expanded_right_calls != 1) << 3); }
CONTEXTS(expanded_mul, ({ int* saved_place = expanded_mul_slot(); *saved_place = *saved_place * expanded_mul_rhs(); }), 4)

int main(void)
{
    int failure = 0;
    { int observed = mul_plain_initializer(); if (!failure && observed) failure = 1; }
    { int observed = mul_plain_argument(); if (!failure && observed) failure = 2; }
    { int observed = mul_plain_return_context(); if (!failure && observed) failure = 3; }
    { int observed = mul_plain_condition(); if (!failure && observed) failure = 4; }
    { int observed = mul_plain_statement(); if (!failure && observed) failure = 5; }
    { int observed = mul_plain_extension(); if (!failure && observed) failure = 6; }
    { int observed = mul_volatile_initializer(); if (!failure && observed) failure = 7; }
    { int observed = mul_volatile_argument(); if (!failure && observed) failure = 8; }
    { int observed = mul_volatile_return_context(); if (!failure && observed) failure = 9; }
    { int observed = mul_volatile_condition(); if (!failure && observed) failure = 10; }
    { int observed = mul_volatile_statement(); if (!failure && observed) failure = 11; }
    { int observed = mul_volatile_extension(); if (!failure && observed) failure = 12; }
    { int observed = div_plain_initializer(); if (!failure && observed) failure = 13; }
    { int observed = div_plain_argument(); if (!failure && observed) failure = 14; }
    { int observed = div_plain_return_context(); if (!failure && observed) failure = 15; }
    { int observed = div_plain_condition(); if (!failure && observed) failure = 16; }
    { int observed = div_plain_statement(); if (!failure && observed) failure = 17; }
    { int observed = div_plain_extension(); if (!failure && observed) failure = 18; }
    { int observed = div_volatile_initializer(); if (!failure && observed) failure = 19; }
    { int observed = div_volatile_argument(); if (!failure && observed) failure = 20; }
    { int observed = div_volatile_return_context(); if (!failure && observed) failure = 21; }
    { int observed = div_volatile_condition(); if (!failure && observed) failure = 22; }
    { int observed = div_volatile_statement(); if (!failure && observed) failure = 23; }
    { int observed = div_volatile_extension(); if (!failure && observed) failure = 24; }
    { int observed = byte_div_plain_initializer(); if (!failure && observed) failure = 25; }
    { int observed = byte_div_plain_argument(); if (!failure && observed) failure = 26; }
    { int observed = byte_div_plain_return_context(); if (!failure && observed) failure = 27; }
    { int observed = byte_div_plain_condition(); if (!failure && observed) failure = 28; }
    { int observed = byte_div_plain_statement(); if (!failure && observed) failure = 29; }
    { int observed = byte_div_plain_extension(); if (!failure && observed) failure = 30; }
    { int observed = byte_div_volatile_initializer(); if (!failure && observed) failure = 31; }
    { int observed = byte_div_volatile_argument(); if (!failure && observed) failure = 32; }
    { int observed = byte_div_volatile_return_context(); if (!failure && observed) failure = 33; }
    { int observed = byte_div_volatile_condition(); if (!failure && observed) failure = 34; }
    { int observed = byte_div_volatile_statement(); if (!failure && observed) failure = 35; }
    { int observed = byte_div_volatile_extension(); if (!failure && observed) failure = 36; }
    { int observed = bool_add_plain_initializer(); if (!failure && observed) failure = 37; }
    { int observed = bool_add_plain_argument(); if (!failure && observed) failure = 38; }
    { int observed = bool_add_plain_return_context(); if (!failure && observed) failure = 39; }
    { int observed = bool_add_plain_condition(); if (!failure && observed) failure = 40; }
    { int observed = bool_add_plain_statement(); if (!failure && observed) failure = 41; }
    { int observed = bool_add_plain_extension(); if (!failure && observed) failure = 42; }
    { int observed = bool_add_volatile_initializer(); if (!failure && observed) failure = 43; }
    { int observed = bool_add_volatile_argument(); if (!failure && observed) failure = 44; }
    { int observed = bool_add_volatile_return_context(); if (!failure && observed) failure = 45; }
    { int observed = bool_add_volatile_condition(); if (!failure && observed) failure = 46; }
    { int observed = bool_add_volatile_statement(); if (!failure && observed) failure = 47; }
    { int observed = bool_add_volatile_extension(); if (!failure && observed) failure = 48; }
    { int observed = same_plain_initializer(); if (!failure && observed) failure = 49; }
    { int observed = same_plain_argument(); if (!failure && observed) failure = 50; }
    { int observed = same_plain_return_context(); if (!failure && observed) failure = 51; }
    { int observed = same_plain_condition(); if (!failure && observed) failure = 52; }
    { int observed = same_plain_statement(); if (!failure && observed) failure = 53; }
    { int observed = same_plain_extension(); if (!failure && observed) failure = 54; }
    { int observed = same_volatile_initializer(); if (!failure && observed) failure = 55; }
    { int observed = same_volatile_argument(); if (!failure && observed) failure = 56; }
    { int observed = same_volatile_return_context(); if (!failure && observed) failure = 57; }
    { int observed = same_volatile_condition(); if (!failure && observed) failure = 58; }
    { int observed = same_volatile_statement(); if (!failure && observed) failure = 59; }
    { int observed = same_volatile_extension(); if (!failure && observed) failure = 60; }
    { int observed = byte_add_plain_initializer(); if (!failure && observed) failure = 61; }
    { int observed = byte_add_plain_argument(); if (!failure && observed) failure = 62; }
    { int observed = byte_add_plain_return_context(); if (!failure && observed) failure = 63; }
    { int observed = byte_add_plain_condition(); if (!failure && observed) failure = 64; }
    { int observed = byte_add_plain_statement(); if (!failure && observed) failure = 65; }
    { int observed = byte_add_plain_extension(); if (!failure && observed) failure = 66; }
    { int observed = byte_add_volatile_initializer(); if (!failure && observed) failure = 67; }
    { int observed = byte_add_volatile_argument(); if (!failure && observed) failure = 68; }
    { int observed = byte_add_volatile_return_context(); if (!failure && observed) failure = 69; }
    { int observed = byte_add_volatile_condition(); if (!failure && observed) failure = 70; }
    { int observed = byte_add_volatile_statement(); if (!failure && observed) failure = 71; }
    { int observed = byte_add_volatile_extension(); if (!failure && observed) failure = 72; }
    { int observed = bitfield_div_initializer(); if (!failure && observed) failure = 73; }
    { int observed = bitfield_div_argument(); if (!failure && observed) failure = 74; }
    { int observed = bitfield_div_return_context(); if (!failure && observed) failure = 75; }
    { int observed = bitfield_div_condition(); if (!failure && observed) failure = 76; }
    { int observed = bitfield_div_statement(); if (!failure && observed) failure = 77; }
    { int observed = bitfield_div_extension(); if (!failure && observed) failure = 78; }
    { int observed = expanded_mul_initializer(); if (!failure && observed) failure = 79; }
    { int observed = expanded_mul_argument(); if (!failure && observed) failure = 80; }
    { int observed = expanded_mul_return_context(); if (!failure && observed) failure = 81; }
    { int observed = expanded_mul_condition(); if (!failure && observed) failure = 82; }
    { int observed = expanded_mul_statement(); if (!failure && observed) failure = 83; }
    { int observed = expanded_mul_extension(); if (!failure && observed) failure = 84; }
    return failure;
}
