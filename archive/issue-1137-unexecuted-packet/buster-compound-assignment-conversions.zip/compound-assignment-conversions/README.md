# Compound-assignment conversion placement — source-confirmed mechanism, unexecuted candidate

## Status

Date: 2026-09-24. This packet is **not runtime evidence and not a published PR**.
The available GitHub actions exposed repository reads, but no commit, issue/PR
creation, or workflow-dispatch action. Plugin discovery did not expose a
write-capable route. No C compiler or generated program was executed in this
session; the requested standard-runner correctness restriction was retained.

The source-confirmed mechanism is that `c_ir_emit_compound_assignment` converts
an ordinary RHS to the destination's value type **before** applying its binary
operation. The predicted miscompilations below have not been observed in a
fresh Buster execution. The attached patch is an uncompiled candidate.

## Exact source identities

Main, including the final connected-GitHub recheck:

- Commit: `fdebfb8810ed4db8c69d3b176f89f835fb77259c`
- Tree: `66c1f549efacaa54c3c4e94738407d5e1b312919`
- `c_gen.c`: `60bf69ed970fc43d84fa3f7198aac5d1410b0eb9`
- `c_test.c`: `0e4e9e4c63207bc60907d2cceb028731f3da1ec9`
- `docs/agents/frontend/calls.md`: `7f5f18a58fd98b4d7198a4defa0283b3711b7ab1`

The large-file GitHub reader returned empty bodies for the two C files. Their
bytes were recovered from an existing correctness artifact, then their full
Git blob identities were independently matched against the connected reader
at pinned main. Artifact 10815042424, run 36016595845, archive SHA-256
`635368ebb4fbed653ae70e92001ac8f88323bac46484296866c1c872c2b9a9f2`.
Its source snapshot was commit `055b7f71df518de1cdd7fcb9af7e0a47f81d173a`,
tree `f1fe21947bcfbecd55bd99c5b60616527756d33a`. The connected comparison from
that snapshot to main also shows none of these three files changed.
**No old artifact test result is counted as a test of this investigation.**

There is no candidate Git commit or complete candidate tree. `manifest.json`
records the exact before/after blob identities and patch digest instead.

## Decision and mechanism

The compact dimension is the placement of assignment conversion relative to
arithmetic conversion in **non-atomic compound assignment**, with exactly-once
place evaluation retained while composing the expression through six contexts.

`minimal.c` is already small enough to distinguish the proposed mechanism:

```c
int main(void)
{
    int value = 3;
    value *= 1.5;
    return value != 4;
}
```

C requires the equivalent arithmetic of `value = value * 1.5`, while evaluating
the compound-assignment designator only once. The product is exactly 4.5 and
conversion to int gives 4. No overflow, non-finite value, invalid lifetime,
aliasing assumption, or evaluation-order choice affects that answer.

At pinned `c_gen.c:23086`, the ordinary path sets `value_type` to int, casts
`right` to that type, and replaces `operation_right` with the cast result.
`c_ir_apply_operation` subsequently chooses arithmetic from the types of its
actual operands. Its `cast_type` argument is not an instruction to restore the
RHS's original double type. Thus the premature cast cannot be undone there.
`c_ir_emit_store_place` already performs the correct final assignment conversion.

Derived IR shape for a parameterized `int probe(int *p, double right)`:

```
Required:  load_i32(p), convert_lhs_to_f64, multiply_f64(right), convert_to_i32, store
Existing:  convert_right_f64_to_i32, load_i32(p), multiply_i32, store
```

This is a source-derived shape, **not a captured IR dump**. The earliest
source-confirmed mistake is in lowering, before canonical validation or the
backend. Fresh parser/semantic acceptance and actual emitted IR remain to be
checked. Type-consistent canonical IR can still encode the wrong C operation;
allocator agreement would not establish correctness.

## Bounded family and independent oracle

There are 84 isolated translation units, not random seeds. Each contains only
its selected context and relevant helpers. The permanent regression embeds a
compact macro-generated version of the same 84 semantic cases.

| Arithmetic row | Required stored/observed value | Classification |
|---|---:|---|
| `int 3 *= double 1.5` | 4 | Distinguishes premature floating conversion |
| `int 3 /= double 1.5` | 2 | Distinguishes premature floating conversion |
| `unsigned char 200 /= unsigned 257` | 0 | Distinguishes narrowing/rank loss without introducing a zero divisor |
| `_Bool 1 += int -1` | 0 | Distinguishes premature boolean conversion |
| `int 3 *= int 2` | 6 | Same-type control |
| `unsigned char 200 += unsigned 257` | 201 | Control: early reduction happens to preserve this modular result |

Each row has plain and volatile places and six contexts: initializer, function
argument, return, condition, expression statement, and a GNU statement
expression. This is 72 cases: 48 distinguishing candidates and 24 controls.
Six unsigned 8-bit bit-field division controls and six saved-place ordinary
assignment controls complete the family: **48 distinguishing candidates and
36 controls total**. Their expected success is not an observed negative result.

The bit-field control targets a real exception in the old helper: narrow
unsigned bit-fields already avoid the premature RHS cast. The saved-place
control computes ordinary multiplication after retaining the address once.
It is equivalent for these fixtures because the RHS modifies only a disjoint
counter and does not change the destination or saved pointer. The extra
statement-expression wrapper yields a captured int; all tested assignment
values fit that int. Its local never escapes.

The tests assert one call to the place helper and one call to the RHS helper,
but not their relative order. A useful dependency/sequence partial order is:

```
place evaluation -> read old object ----\
                                        arithmetic -> assignment conversion -> store
RHS value evaluation ------------------/
all effects of tested full expression -> subsequent state/counter checks
```

There is deliberately no place-before-RHS or RHS-before-place edge. The two
helpers modify different counters. GNU block-expression cases introduce no
jump, escaping local address, or temporary-lifetime dependency.

Only the recorded 8-bit-char/32-bit-int targets are admitted by this oracle.
Inputs avoid signed overflow, out-of-range floating conversion, negative shifts,
zero divisors, indeterminate padding, and unsequenced accesses to one modified
object. The floating examples use exactly representable halves. Sanitizers,
when run, can corroborate but cannot prove these defined-behavior arguments.

## Reconciliation and falsification

Current AGENTS and frontend foundations/calls/semantic-validation, build,
testing and style/workflow guidance were inspected. No performance work was
performed, and no retirement work or generated binding was changed.

#1040 and its fixing PR #1102 (head
`7c14466804253f371d9f14b31fb7de2dd5688b8a`) concern comma sequencing in call
preparation. That patch and its discussion were inspected; this candidate does
not touch its preparation helper. #1101 owns choose-expression preparation;
its discussion also identifies the separate #1131/#1132 sizeof families.
Those are controls/exclusions, not new findings here. #1127's semantic
promotion/type-query reports and #1098's fixed-signature bit-count conversions
were excluded as well.

Searches for `c_ir_emit_compound_assignment`, `compound assignment`, and
`compound` with `conversion` found the prior #361/#370 qualifier/callable-value
repair, not this premature arithmetic conversion. #361's discussion and the
current documented qualified-compound regression were inspected. That test
adds a narrow integer to a wider volatile integer; it does not distinguish
premature fraction loss or wide-to-narrow RHS conversion. This is a bounded
novelty search, not a proof that no historical report exists anywhere.

The preferred explanation can be falsified cheaply: first run the minimal
case with Clang/GCC and pinned Buster; then run the raw-IR fixture before shared
preparation. Correct raw floating multiplication on the unpatched tree would
contradict the asserted path for that context. An unchanged failed result after
restoring the operand type requires further diagnosis, not an automatic claim
that the backend is wrong. Same-type, modular, bit-field and saved-place
controls are retained with correct expectations; no unexpected failure is
silently reclassified as an expected failure.

## Candidate scope

`candidate.patch` changes exactly three files. Its production change adds an
`atomic` guard to the existing pre-conversion arm. Non-atomic arithmetic keeps
the RHS type; existing final store/result conversions remain. Pointer arithmetic
and the old atomic path are unchanged. The tests add 96 raw canonical lowerings
(two arithmetic rows, six contexts, two qualifiers, two frontend modes, two
targets) and 16 native runtime configurations (four allocators, two frontend
modes, O0/O2), each running the 84-probe aggregate. The guide is updated locally
within the candidate patch. No new production IR, callback, recursive walk,
module, dependency, workflow, benchmark requirement, or policy is introduced.

Atomic mixed-type arithmetic remains outside this narrow candidate. The old
helper's atomic path still contains a similar conversion; this packet does
not claim a universal atomic compound-assignment repair. Existing vector,
complex, qualifier, bit-field, pointer and atomic suites must be retained when
validating the changed common helper.

## What actually ran

Only source/packet checks: full blob hashing, archive hashing, diff application
and whitespace checks, fixture inventory/hash checks, and structural checks
that each isolated input has one place-helper and one RHS-helper call site.
See `checks.txt`. These are not compiler correctness tests.

NOT RUN: Clang/GCC reference compilation/execution, Buster baseline/candidate
compilation/execution, the 96 canonical lowerings, the 16 runtime configurations,
ASan/UBSan, full Release/configuration/platform suites, or self-host fixed points.
No PR/issue/branch was published, no workflow dispatched, no merge performed,
and no protection or runner setting changed.

`REPLAY.md` contains the precise probe commands and acceptance gates for the
next standard GitHub-hosted correctness run. `ISSUE.md` is a ready-to-post draft
that explicitly preserves these evidence limits.

## Primary language references

- WG14 N1570, 6.5.16.2p3; 6.5.16p3; 6.3.1.1–1.4 and 6.3.1.8:
  https://open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
- GCC, Statements and Declarations in Expressions:
  https://gcc.gnu.org/onlinedocs/gcc/Statement-Exprs.html
