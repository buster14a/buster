int main(void)
{
    int value = 3;
    value *= 1.5;
    return value != 4;
}
