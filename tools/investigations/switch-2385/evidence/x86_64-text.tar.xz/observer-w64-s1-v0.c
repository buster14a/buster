#include <stdio.h>
extern int choose(long long);
int main(void) { printf("%d\n", choose((long long)(7ULL))); return 0; }
