#include <stdio.h>
extern int choose(short);
int main(void) { printf("%d\n", choose((short)(-1LL))); return 0; }
