#include <stdio.h>
extern int choose(unsigned long long);
int main(void) { printf("%d\n", choose((unsigned long long)(7ULL))); return 0; }
