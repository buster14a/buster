#include <stdio.h>
extern int choose(unsigned int);
int main(void) { printf("%d\n", choose((unsigned int)(4294967295ULL))); return 0; }
