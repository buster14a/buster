#include <stdio.h>
extern int choose(unsigned int);
int main(void) { printf("%d\n", choose((unsigned int)(7ULL))); return 0; }
