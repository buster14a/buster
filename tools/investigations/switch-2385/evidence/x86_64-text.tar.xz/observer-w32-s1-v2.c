#include <stdio.h>
extern int choose(int);
int main(void) { printf("%d\n", choose((int)(-1LL))); return 0; }
