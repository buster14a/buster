#include <stdio.h>
extern int choose(long long);
int main(void) { printf("%d\n", choose((long long)(-1LL))); return 0; }
