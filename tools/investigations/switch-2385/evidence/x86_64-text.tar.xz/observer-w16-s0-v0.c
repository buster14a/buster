#include <stdio.h>
extern int choose(unsigned short);
int main(void) { printf("%d\n", choose((unsigned short)(7ULL))); return 0; }
