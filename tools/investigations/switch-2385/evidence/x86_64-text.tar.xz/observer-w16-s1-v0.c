#include <stdio.h>
extern int choose(short);
int main(void) { printf("%d\n", choose((short)(7ULL))); return 0; }
