#include <stdio.h>
extern int choose(int);
int main(void) { printf("%d\n", choose((int)(7ULL))); return 0; }
