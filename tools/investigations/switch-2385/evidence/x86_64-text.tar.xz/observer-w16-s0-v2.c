#include <stdio.h>
extern int choose(unsigned short);
int main(void) { printf("%d\n", choose((unsigned short)(65535ULL))); return 0; }
