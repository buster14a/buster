#include <stdio.h>
extern int choose(signed char);
int main(void) { printf("%d\n", choose((signed char)(-1LL))); return 0; }
