#include <stdio.h>
extern int choose(unsigned char);
int main(void) { printf("%d\n", choose((unsigned char)(255ULL))); return 0; }
