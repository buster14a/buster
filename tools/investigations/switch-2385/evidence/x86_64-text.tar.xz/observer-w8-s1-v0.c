#include <stdio.h>
extern int choose(signed char);
int main(void) { printf("%d\n", choose((signed char)(7ULL))); return 0; }
