#!/usr/bin/env python3
"""Frozen-input native artifact checks and paired compiler measurements."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "native"
BIN = ROOT / "bin"
FROZEN = ROOT / "frozen-input"
INPUTS = ROOT / "native-inputs"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command, log, timeout=240):
    with log.open("wb") as output:
        completed = subprocess.run(command, cwd=REPO, stdout=output,
                                   stderr=subprocess.STDOUT, timeout=timeout)
    if completed.returncode:
        raise RuntimeError(f"exit {completed.returncode}: {command}; see {log}")


def arguments(source, allocator, debug, output):
    args = ["cc", "-target", "x86_64-unknown-linux-gnu", debug,
            f"-fregister-allocator={allocator}"]
    if source.name == "ide.c":
        args += ["-I" + str(FROZEN / "src"), "-I" + str(FROZEN / "build/generated"),
                 "-DBUSTER_UNITY_BUILD=1", "-DBUSTER_INCLUDE_TESTS=0"]
    args += [str(source)]
    if source.name == "ide.c":
        args += ["-lm"]
    return args + ["-o", str(output)]


def cases():
    for source in sorted(INPUTS.glob("*.c")):
        for allocator in ("fast", "quality"):
            for debug in ("-g0", "-g"):
                yield source.stem + "-" + allocator + debug, source, allocator, debug
    source = FROZEN / "src/buster/apps/ide/ide.c"
    for allocator in ("fast", "quality"):
        for debug in ("-g0", "-g"):
            yield "unity-" + allocator + debug, source, allocator, debug


def identity(destination):
    destination.mkdir()
    receipt = {"binaries": {}, "inputs": {}, "cases": []}
    for name in ("baseline", "candidate"):
        path = BIN / ("ide-native-" + ("compaction" if name == "candidate" else name))
        receipt["binaries"][name] = {"path": str(path), "sha256": digest(path)}
    for source in sorted(INPUTS.glob("*.c")):
        receipt["inputs"][str(source)] = digest(source)
        oracle = destination / (source.stem + ".clang")
        run(["clang", "-O0", "-g0", str(source), "-o", str(oracle)],
            destination / (source.stem + ".clang-compile.log"))
        run([str(oracle)], destination / (source.stem + ".clang-run.log"))
    for label, source, allocator, debug in cases():
        directory = destination / label
        directory.mkdir()
        artifact = directory / "result"
        sizes = []
        hashes = []
        for arm in ("baseline", "candidate"):
            run([str(BIN / ("ide-native-" + ("compaction" if arm == "candidate" else arm)))] +
                arguments(source, allocator, debug, artifact), directory / (arm + "-compile.log"))
            sizes.append(artifact.stat().st_size)
            hashes.append(digest(artifact))
            if source.name == "ide.c":
                oracle = directory / "oracle"
                run([str(artifact), "cc", "-g0", "-target", "x86_64-unknown-linux-gnu",
                     str(INPUTS / "pressure-64.c"), "-o", str(oracle)],
                    directory / (arm + "-oracle-compile.log"))
                run([str(oracle)], directory / (arm + "-oracle-run.log"))
            else:
                run([str(artifact)], directory / (arm + "-run.log"))
        row = {"case": label, "source": str(source), "source_sha256": digest(source),
               "bytes": sizes, "sha256": hashes, "identical": hashes[0] == hashes[1],
               "both_executed": True}
        receipt["cases"].append(row)
        print(json.dumps(row), flush=True)
        (destination / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        if hashes[0] != hashes[1]:
            raise RuntimeError(f"artifact differs in {label}")


def measure(destination, claim, baseline_revision, candidate_revision, control):
    destination.mkdir()
    tool = "perf-stat" if claim == "work-reduction" else "time"
    runs = 6 if claim == "work-reduction" else 20
    selected = [("unity-fast-g0", FROZEN / "src/buster/apps/ide/ide.c", "fast", "-g0")]
    if not control:
        selected += [("unity-fast-g", FROZEN / "src/buster/apps/ide/ide.c", "fast", "-g"),
                     ("unity-quality-g0", FROZEN / "src/buster/apps/ide/ide.c", "quality", "-g0")]
        selected += [(source.stem + "-fast-g0", source, "fast", "-g0")
                     for source in sorted(INPUTS.glob("*.c"))]
    for label, source, allocator, debug in selected:
        directory = destination / label
        candidate = "baseline" if control else "candidate"
        command = [str(BIN / "performance-evidence"), "compare", "--claim", claim,
                   "--tool", tool, "--baseline", str(BIN / "ide-native-baseline"),
                   "--candidate", str(BIN / ("ide-native-" + ("compaction" if candidate == "candidate" else candidate))), "--out", str(directory),
                   "--runs", str(runs), "--warmup", "1", "--min-effect-percent", "0.1" if claim == "work-reduction" else "0.5",
                   "--baseline-revision", baseline_revision, "--candidate-revision",
                   baseline_revision if control else candidate_revision]
        if claim == "work-reduction":
            command += ["--events", "instructions:u"]
        command += ["--"] + arguments(source, allocator, debug, "/dev/null")
        run(command, destination / (label + ".log"), timeout=2400)
        print(label + " complete", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("identity", "work-reduction", "native-runtime"))
    parser.add_argument("destination", type=Path)
    parser.add_argument("--baseline-revision", default="c14841ae8e286447cf126de59119a887c13c9e36")
    parser.add_argument("--candidate-revision", default="")
    parser.add_argument("--control", action="store_true")
    args = parser.parse_args()
    if args.phase == "identity":
        identity(args.destination.resolve())
    else:
        measure(args.destination.resolve(), args.phase, args.baseline_revision,
                args.candidate_revision, args.control)


if __name__ == "__main__":
    main()
