from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent
probe=w.parent/'probe-build'/'bin'
results=[]
for shape,n,repeats in [('single',131072,32),('loops',256,256),('loops',4096,256),('loops',16384,256),('dense',4096,32),('dense',16384,32),('dense',16385,32)]:
    name=f'query-work-{shape}-{n}'
    cmd=['taskset','-c','4',str(w/'performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--baseline',str(probe/'baseline'),'--candidate',str(probe/'query-candidate'),'--out',str(w/'evidence'/name),'--runs','6','--warmup','1','--min-effect-percent','0.5','--events','instructions:u','--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--candidate-revision','0a1e15e6de985987ee19537686a85dba743fbe13','--',shape,str(n),str(repeats)]
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (w/'evidence'/f'{name}.log').write_text(p.stdout)
    print(name,p.returncode,p.stdout,flush=True)
    results.append({'case':name,'command':cmd,'exit':p.returncode})
    if p.returncode: break
(w/'query-probe-campaign.json').write_text(json.dumps(results,indent=2)+'\n')
