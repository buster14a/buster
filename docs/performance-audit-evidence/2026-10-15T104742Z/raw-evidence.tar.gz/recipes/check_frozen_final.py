from pathlib import Path
import subprocess,hashlib,json
w=Path(__file__).resolve().parent
manifest=[]
for mode,debug in [('fast','-g'),('quality','-g0')]:
    files=[]
    for arm in ['baseline','final']:
        out=w/'performance'/arm/f'unity-final-{mode}.o'
        cmd=[str(w/'performance'/arm/'ide'),'cc','-Isrc','-Igenerated','-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0',debug,'-march=native',f'-fregister-allocator={mode}','-c','src/buster/apps/ide/ide.c','-o',str(out)]
        p=subprocess.run(cmd,cwd=w/'frozen',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        (w/'performance'/arm/f'unity-final-{mode}.log').write_text(p.stdout)
        if p.returncode: raise SystemExit(f'{arm} {mode}: {p.stdout}')
        files.append({'arm':arm,'command':cmd,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
    equal=files[0]['sha256']==files[1]['sha256']
    manifest.append({'mode':mode,'debug':debug,'identical':equal,'files':files})
    print(json.dumps(manifest[-1]),flush=True)
    if not equal: raise SystemExit('frozen object mismatch')
(w/'frozen-final-checks.json').write_text(json.dumps(manifest,indent=2)+'\n')
