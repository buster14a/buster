#include <stdio.h>
#include <buster/lib/compiler/codegen/machine.c>
ProgramState* program_state;
int main(void)
{
    ThreadContext* context = thread_context_allocate();
    thread_context_select(context);
    Arena* arena = arena_create((ArenaCreation){.reserved_size = 1024ull * 1024ull * 1024ull});
    machine_opcode_rows_prewarm();
    bool solver = machine_fast_solve_liveness_test(arena);
    bool summary = machine_fast_prepass_summary_test(arena);
    printf("solver=%u summary=%u\n", (unsigned)solver, (unsigned)summary);
    arena_destroy(arena, 1);
    thread_context_release(context);
    return !(solver && summary);
}
