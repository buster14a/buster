from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent;results=[]
for depth in [64,1000,4000,4720,4730,8000,16000]:
    records=[]
    for arm in ['baseline','query']:
        out=w/'performance'/arm/f'query-nested-{depth}'
        cmd=[str(w/'performance'/arm/'ide'),'cc','-g0','-w',str(w/f'nested-{depth}.c'),'-o',str(out),f'-fmetrics-out={out}.metrics']
        p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        if p.returncode: raise SystemExit(p.stdout)
        q=subprocess.run([str(out)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=10)
        if q.returncode: raise SystemExit(q.stdout)
        line=Path(str(out)+'.metrics').read_text().splitlines()[1];f=dict(z.split('=',1) for z in line.split()[1:] if '=' in z)
        records.append({'arm':arm,'command':cmd,'run_exit':q.returncode,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'code_bytes':int(f['code_bytes']),'frame_bytes':int(f['stack_frame_bytes'])})
    same=records[0]['sha256']==records[1]['sha256'];results.append({'depth':depth,'identical':same,'records':records});print(depth,same,flush=True)
    if not same: raise SystemExit('changed output')
(w/'query-nested-checks.json').write_text(json.dumps(results,indent=2)+'\n')
