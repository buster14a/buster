from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent
repo=Path('/home/david/Documents/Codex/2026-10-15/iden-2/work/buster')
sources=['src/buster/lib/compiler/codegen/machine.c','src/buster/lib/compiler/codegen/codegen.c','src/buster/lib/arena.c','src/buster/lib/os.c','src/buster/lib/integer.c','src/buster/lib/string.c','src/buster/lib/float.c','src/buster/lib/time.c']
commands=[]
for arm,rev in [('baseline','84f051c13044938bcb8cbe1ac48ea3ee79defcff'),('candidate','7f968fa99f9c7d1921059efd688e24570637a4b6')]:
    if arm == 'baseline' and (w/'bin'/'baseline').exists():
        commands.append(json.loads((w/'builds.json').read_text())[0])
        continue
    archive=subprocess.run(['git','-C',str(repo),'archive',rev,'src'],capture_output=True,check=True).stdout
    subprocess.run(['tar','-x','-C',str(w/'source')],input=archive,check=True)
    cmd=['clang','-O2','-g','-ffunction-sections','-fdata-sections','-DBUSTER_INCLUDE_TESTS=0','-DBUSTER_LINK_LIBC=1','-DBUSTER_OPTIMIZE=1','-DBUSTER_SINGLE_THREADED=1','-Isource/src','-fwrapv','-fno-strict-aliasing','-funsigned-char','probe.c']+['source/'+s for s in sources]+['-Wl,--gc-sections','-lm','-lpthread','-ldl','-o',str(w/'bin'/arm)]
    p=subprocess.run(cmd,cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (w/f'{arm}-build.log').write_text(p.stdout)
    if p.returncode: raise SystemExit(p.stdout)
    commands.append({'arm':arm,'revision':rev,'command':cmd,'binary_sha256':hashlib.sha256((w/'bin'/arm).read_bytes()).hexdigest()})
    print(arm,commands[-1]['binary_sha256'],flush=True)
(w/'builds.json').write_text(json.dumps(commands,indent=2)+'\n')
