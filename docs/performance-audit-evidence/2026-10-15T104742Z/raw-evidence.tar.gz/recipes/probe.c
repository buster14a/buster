#define _POSIX_C_SOURCE 200809L
#include <buster/lib/compiler/codegen/machine.h>
#include <buster/lib/arena.h>
#include <buster/lib/os.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
ProgramState* program_state;
int main(int argc, char** argv)
{
    int status = argc != 4;
    unsigned n = argc > 2 ? (unsigned)strtoul(argv[2], 0, 10) : 0;
    unsigned repeats = argc > 3 ? (unsigned)strtoul(argv[3], 0, 10) : 0;
    int loops = argc > 1 && strcmp(argv[1], "loops") == 0;
    int single = argc > 1 && strcmp(argv[1], "single") == 0;
    status |= n < 2 || n > 1000000 || !repeats || (!loops && !single && strcmp(argv[1], "dense") != 0);
    if (!status)
    {
        ThreadContext* context = thread_context_allocate();
        thread_context_select(context);
        Arena* arena = arena_create((ArenaCreation){.reserved_size = 1024ull * 1024ull * 1024ull});
        MachineFunction f = {.target = machine_target_x86_64()};
        f.block_count = single ? 1 : n;
        f.virtual_register_count = loops ? 0 : n;
        f.instruction_count = loops ? n : single ? 2 * n + 1 : 3 * n;
        f.blocks = arena_allocate(arena, MachineBlock, f.block_count);
        f.instructions = arena_allocate(arena, MachineInstruction, f.instruction_count);
        f.virtual_registers = arena_allocate(arena, MachineVirtualRegister, n);
        memset(f.blocks, 0, (u64)f.block_count * sizeof(*f.blocks));
        memset(f.virtual_registers, 0, (u64)n * sizeof(*f.virtual_registers));
        MachineRef physical = machine_ref_make(MACHINE_REF_PHYSICAL_REGISTER, MACHINE_X64_RAX);
        unsigned row = 0;
        for (unsigned block = 0; block < f.block_count; ++block)
        {
            unsigned first = row;
            if (!loops && block == 0)
                for (unsigned value = 0; value < n; ++value)
                {
                    f.virtual_registers[value] = (MachineVirtualRegister){.definition_point = machine_point_make(row, MACHINE_POINT_NORMAL), .register_class = MACHINE_REGISTER_CLASS_GENERAL};
                    f.instructions[row++] = (MachineInstruction){.opcode = MACHINE_X64_MOV_RR, .operands = {machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value), physical}};
                    if (single) f.instructions[row++] = (MachineInstruction){.opcode = MACHINE_X64_MOV_RR, .operands = {physical, machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value)}};
                }
            if (!loops && !single && block + 1 == f.block_count)
                for (unsigned value = 0; value < n; ++value)
                    f.instructions[row++] = (MachineInstruction){.opcode = MACHINE_X64_MOV_RR, .operands = {physical, machine_ref_make(MACHINE_REF_VIRTUAL_REGISTER, value)}};
            if (loops)
                f.instructions[row++] = block + 1 == f.block_count ? (MachineInstruction){.opcode = MACHINE_X64_JMP, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 0)}}
                    : (MachineInstruction){.opcode = MACHINE_X64_JCC, .operands = {machine_ref_make(MACHINE_REF_BLOCK, 0), machine_ref_make(MACHINE_REF_BLOCK, block + 1)}};
            else
                f.instructions[row++] = block + 1 == f.block_count ? (MachineInstruction){.opcode = MACHINE_X64_RET}
                    : (MachineInstruction){.opcode = MACHINE_X64_JMP, .operands = {machine_ref_make(MACHINE_REF_BLOCK, block + 1)}};
            f.blocks[block] = (MachineBlock){.first_instruction = first, .instruction_count = row - first};
        }
        status |= row != f.instruction_count;
        machine_opcode_rows_prewarm();
        u64 input_end = arena->position, bytes = 0, checksum = 0;
        unsigned live_words = 0;
        for (unsigned repeat = 0; repeat < repeats; ++repeat)
        {
            arena_set_position(arena, input_end);
            MachineFastPrepass p = machine_fast_prepass_build(arena, &f, loops);
            status |= !p.valid;
            if (loops) status |= p.loop_span_count != 1 || p.loop_spans[0] != (u64)n - 1;
            if (n && !loops) status |= p.last_use[n - 1] != (single ? 2 * n - 1 : 3 * n - 2);
            checksum += loops ? p.loop_spans[0] : p.last_use[n - 1];
            bytes = arena->position - input_end;
            live_words = p.live_words;
        }
        printf("shape=%s n=%u repeats=%u rows=%u prepass_bytes=%llu live_words=%u checksum=%llu status=%d\n", argv[1], n, repeats, f.instruction_count, (unsigned long long)bytes, live_words, (unsigned long long)checksum, status);
        arena_destroy(arena, 1);
        thread_context_release(context);
    }
    return status;
}
