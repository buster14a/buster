from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent
base=w/'performance/baseline/ide';candidate=w/'performance/final/ide'
cases=[]
for mode,debug in [('fast','-g'),('quality','-g0')]:
    args=['cc','-Isrc','-Igenerated','-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0',debug,'-march=native',f'-fregister-allocator={mode}','-c','src/buster/apps/ide/ide.c','-o',str(w/'frozen-control-out.o')]
    if mode=='fast': cases.append(('aa-unity-fast','work-reduction','perf-stat',base,base,args,w/'frozen',6))
    cases.append((f'work-unity-{mode}','work-reduction','perf-stat',base,candidate,args,w/'frozen',6))
for depth in [4720,4000,4720,4730,8000,16000]:
    aa=not any(c[0]=='aa-native-4720' for c in cases)
    name='aa-native-4720' if aa else f'native-nested-{depth}'
    args=['cc','-g0','-w','-c',str(w/f'nested-{depth}.c'),'-o',str(w/'nested-control-out.o')]
    cases.append((name,'native-runtime','time',base,base if aa else candidate,args,w,10))
records=[]
for name,claim,tool,b,c,args,cwd,runs in cases:
    cmd=['taskset','-c','4',str(w/'performance-evidence'),'compare','--claim',claim,'--tool',tool,'--baseline',str(b),'--candidate',str(c),'--out',str(w/'evidence'/('final-'+name)),'--runs',str(runs),'--warmup','1','--min-effect-percent','0.5','--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--candidate-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff' if b==c else '7f968fa99f9c7d1921059efd688e24570637a4b6']
    if tool=='perf-stat': cmd+=['--events','instructions:u']
    cmd+=['--']+args
    p=subprocess.run(cmd,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (w/'evidence'/f'final-{name}.log').write_text(p.stdout)
    print(name,p.returncode,p.stdout,flush=True)
    records.append({'name':name,'command':cmd,'cwd':str(cwd),'exit':p.returncode})
    if p.returncode: break
(w/'final-native-campaign.json').write_text(json.dumps(records,indent=2)+'\n')
