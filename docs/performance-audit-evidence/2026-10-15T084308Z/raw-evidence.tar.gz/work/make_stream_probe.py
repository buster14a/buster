from pathlib import Path
p=Path('work/buster/tools/machine_edge_split_scaling.c');s=p.read_text().replace('#include <buster/lib/compiler/codegen/machine.h>','#include <buster/lib/compiler/codegen/machine.c>')
s=s.replace('        u64 input_end = arena->position;','''        MachineFunctionBuilder builder = machine_function_builder_begin(arena);
        for (u32 row = 0; row < input.instruction_count; row += 1)
        {
            *(MachineInstruction*)machine_stream_append(arena, &builder.instructions) = input.instructions[row];
        }
        u64 input_end = arena->position;''')
s=s.replace('            u64 start = edge_split_now();','''            if (output.instruction_count) { output.instructions = 0; }
            u64 start = edge_split_now();''')
s=s.replace('valid = machine_function_split_parameter_edges(arena, &output);','valid = machine_function_publish_parameter_edges(arena, &output, &builder, 0, 0);')
s=s.replace('            valid = valid && (splits ? retained', '''            MachineFunction stable = output;
            stable.instructions = input.instructions;
            u64 no_split_bytes = builder.instructions.first != builder.instructions.last ? (u64)count * sizeof(MachineInstruction) : 0;
            valid = valid && (splits ? retained''')
s=s.replace('retained == 0 && peak == 0 && !memcmp(&input, &output, sizeof(input))','retained >= no_split_bytes && retained <= no_split_bytes + 8u && peak == retained && !memcmp(&input, &stable, sizeof(input))')
Path('work/stream_probe.c').write_text(s)
p=Path('work/buster/tools/machine_edge_split_scaling_coverage.py');s=p.read_text()
s=s.replace('root = pathlib.Path(__file__).resolve().parents[1]',"root = pathlib.Path('work/buster').resolve()")
s=s.replace('"bool machine_function_split_parameter_edges_with_canonical_map("','"BUSTER_GLOBAL_LOCAL bool machine_function_split_parameter_edges_from_rows("')
s=s.replace('"MachineInstruction instruction = function->instructions[old_instruction];"','"MachineInstruction instruction = source_rows[offset];"')
s=s.replace('f["name"] ==\n                                "machine_function_split_parameter_edges_with_canonical_map"','f["name"].split(":")[-1] ==\n                                "machine_function_split_parameter_edges_from_rows"')
s=s.replace('"probe_sha256": digest(root / "tools/machine_edge_split_scaling.c")','"probe_sha256": digest(pathlib.Path("work/stream_probe.c"))')
Path('work/stream_coverage.py').write_text(s)
