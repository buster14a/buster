from pathlib import Path
import subprocess,json
root=Path.cwd(); source=root/'work/buster/src/buster/lib/compiler/codegen/machine.c'
lines=subprocess.check_output(['git','-C','work/buster','show','e359c46612ed6d0e9c8e4553252eb10968a870e8:src/buster/lib/compiler/codegen/machine.c'],text=True).splitlines()
points={
 'directory_chunks':('machine_function_publish_parameter_edges','chunks[chunk_index++] ='),
 'publication_spans':('machine_function_split_parameter_edges_from_rows','MachineInstruction const* source_rows ='),
 'publication_rows':('machine_function_split_parameter_edges_from_rows','MachineInstruction instruction = source_rows[offset];'),
 'fallback_flatten_chunks':('machine_stream_flatten','u64 chunk_bytes ='),
}
points={k:(fn,next((i+1,line.index(needle)+1) for i,line in enumerate(lines) if needle in line)) for k,(fn,needle) in points.items()}
rows=[]
base=json.load(open('work/stream-coverage-2/counts.json'))
for row in base['rows']:
 stem=f"{row['target']}-{row['shape']}-{row['blocks']}"
 export=json.loads(subprocess.check_output(['llvm-cov','export','work/stream-probe',f'-instr-profile=work/stream-coverage-2/{stem}.profdata',str(source)]))['data'][0]
 counts={};regions={}
 for k,(name,point) in points.items():
  f=next(f for f in export['functions'] if f['name'].split(':')[-1]==name)
  rr=[r for r in f['regions'] if r[7]==0 and r[5]==0 and (r[0],r[1])<=point<(r[2],r[3])]
  r=min(rr,key=lambda r:(r[2]-r[0],r[3]-r[1]));counts[k]=r[4];regions[k]=r
 n=row['blocks']; splits=row['shape']!='no-split' and n>1
 chunks=(n+681)//682
 expected=dict(directory_chunks=chunks,publication_spans=n if splits else 0,publication_rows=n if splits else 0,fallback_flatten_chunks=chunks if not splits and n>682 else 0)
 if counts!=expected:raise ValueError((stem,counts,expected))
 rows.append({'cell':stem,'observed':counts,'regions':regions})
Path('work/extra-coverage.json').write_text(json.dumps({'source_revision':'e359c46612ed6d0e9c8e4553252eb10968a870e8','points':points,'rows':rows},indent=2)+'\n')
print('PASS',len(rows),'cells: actual chunk-directory, row-publication and no-split fallback visits')
