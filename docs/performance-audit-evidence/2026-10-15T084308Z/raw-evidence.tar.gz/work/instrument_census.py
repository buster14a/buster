from pathlib import Path
p=Path('work/census/src/buster/lib/compiler/codegen/machine_x86_64.c')
s=p.read_text()
s='#include <buster/lib/time.h>\n#include <stdio.h>\n'+s
s=s.replace('    result.function = machine_function_builder_finish(arena, &selector.builder);','    TimeDataType census_start = timestamp_take();\n    result.function = machine_function_builder_finish(arena, &selector.builder);\n    u64 census_materialize_ns = timestamp_ns_between(census_start, timestamp_take());',1)
s=s.replace('    if (!machine_selection_finish_canonical_edges(arena, &result.function, function, canonical_edge_offset,','    census_start = timestamp_take();\n    if (!machine_selection_finish_canonical_edges(arena, &result.function, function, canonical_edge_offset,',1)
s=s.replace('    if (!machine_function_split_parameter_edges_with_canonical_map(arena, &result.function,','    u64 census_remap_ns = timestamp_ns_between(census_start, timestamp_take());\n    u32 census_old_i = result.function.instruction_count;\n    u32 census_old_b = result.function.block_count;\n    u32 census_old_e = result.function.edge_count;\n    u64 census_split_start = arena->position;\n    census_start = timestamp_take();\n    if (!machine_function_split_parameter_edges_with_canonical_map(arena, &result.function,',1)
s=s.replace('    bool select_predicates = simd_operation_count != 0;', '''    u64 census_split_ns = timestamp_ns_between(census_start, timestamp_take());
    fprintf(stderr, "MIR_CENSUS,%u,%u,%u,%u,%u,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%u,%u,%u\\n",
            census_old_i, census_old_b, census_old_e, result.function.block_count - census_old_b, function->block_count,
            (unsigned long long)(selector.builder.instructions.first != selector.builder.instructions.last ?
                (u64)selector.builder.instructions.total_count * sizeof(MachineInstruction) : 0),
            (unsigned long long)(selector.builder.blocks.first != selector.builder.blocks.last ?
                (u64)selector.builder.blocks.total_count * sizeof(MachineBlock) : 0),
            (unsigned long long)(selector.builder.edges.first != selector.builder.edges.last ?
                (u64)selector.builder.edges.total_count * sizeof(MachineEdge) : 0),
            (unsigned long long)census_materialize_ns, (unsigned long long)census_remap_ns, (unsigned long long)census_split_ns,
            (unsigned long long)(arena->position - census_split_start),
            (unsigned long long)((u64)result.function.switch_case_count * sizeof(MachineSwitchCase)),
            (unsigned long long)((u64)result.function.inline_assembly_count * sizeof(MachineInlineAssembly) +
                (u64)result.function.inline_assembly_relocation_count * sizeof(MachineInlineAssemblyRelocation)),
            nonvolatile_memory, result.function.inline_assembly_count, canonical_edge_offset);
    bool select_predicates = simd_operation_count != 0;''',1)
p.write_text(s)
