from pathlib import Path
root=Path('work/buster/src/buster/lib/compiler/codegen')
p=root/'machine.c';s=p.read_text()
s=s.replace('MachineFunction machine_function_builder_finish(Arena* arena, MachineFunctionBuilder* builder)\n{','BUSTER_GLOBAL_LOCAL MachineFunction machine_function_builder_finish_arrays(Arena* arena, MachineFunctionBuilder* builder, bool defer_instructions)\n{',1)
s=s.replace('.instructions = (MachineInstruction*)machine_stream_materialize(arena, builder->arena, &builder->instructions, BUSTER_ALIGN_OF(MachineInstruction)),','.instructions = defer_instructions ? 0 : (MachineInstruction*)machine_stream_materialize(arena, builder->arena, &builder->instructions, BUSTER_ALIGN_OF(MachineInstruction)),',1)
pos=s.index('// A block-parameter assignment belongs to one CFG edge.')
s=s[:pos]+'''MachineFunction machine_function_builder_finish(Arena* arena, MachineFunctionBuilder* builder)
{
    MachineFunction result = machine_function_builder_finish_arrays(arena, builder, false);
    return result;
}

// Multi-chunk instructions can go straight to their final split layout when
// no pre-split consumer needs contiguous rows. Single chunks already borrow.
BUSTER_GLOBAL_LOCAL MachineFunction machine_function_builder_finish_selection(Arena* arena, MachineFunctionBuilder* builder,
                                                                                bool instruction_consumers)
{
    bool defer = !instruction_consumers && builder->instructions.first != builder->instructions.last &&
                 builder->edge_copy_sources.total_count != 0;
    MachineFunction result = machine_function_builder_finish_arrays(arena, builder, defer);
    return result;
}

BUSTER_GLOBAL_LOCAL MachineInstruction const* machine_parameter_edge_instruction(MachineFunction const* function,
                                                                                  MachineInstruction const* const* chunks,
                                                                                  u32 chunk_capacity, u32 index)
{
    MachineInstruction const* result = chunks ? chunks[index / chunk_capacity] + index % chunk_capacity : function->instructions + index;
    return result;
}

'''+s[pos:]
s=s.replace('machine_function_parameter_edge_needs_split(MachineFunction const* function, MachineEdge const* edge)','machine_function_parameter_edge_needs_split(MachineFunction const* function, MachineEdge const* edge,\n                                                                                    MachineInstruction const* const* chunks, u32 chunk_capacity)',1)
s=s.replace('MachineInstruction const* terminator = function->instructions + source->first_instruction + source->instruction_count - 1u;', 'MachineInstruction const* terminator = machine_parameter_edge_instruction(\n                function, chunks, chunk_capacity, source->first_instruction + source->instruction_count - 1u);',1)
s=s.replace('bool machine_function_split_parameter_edges_with_canonical_map(Arena* arena, MachineFunction* function,\n                                                                u32** canonical_entries, u32 canonical_count)', 'BUSTER_GLOBAL_LOCAL bool machine_function_split_parameter_edges_from_rows(Arena* arena, MachineFunction* function,\n                                                                            u32** canonical_entries, u32 canonical_count,\n                                                                            MachineInstruction const* const* chunks, u32 chunk_capacity)',1)
s=s.replace('machine_function_parameter_edge_needs_split(function, function->edges + edge_index)', 'machine_function_parameter_edge_needs_split(function, function->edges + edge_index, chunks, chunk_capacity)')
start=s.index('                for (u32 offset = 0; offset < old->instruction_count; offset += 1)',s.index('machine_function_split_parameter_edges_from_rows'))
end=s.index('                for (u32 cursor = first_edge; result && cursor < limit_edge;',start)
old=s[start:end]
old=old.replace('                for (u32 offset = 0; offset < old->instruction_count; offset += 1)\n                {\n', '')
assert old.endswith('                }\n')
old=old[:-len('                }\n')]
old=old.replace('u32 old_instruction = old->first_instruction + offset;', 'u32 old_instruction = old_first + offset;').replace('MachineInstruction instruction = function->instructions[old_instruction];','MachineInstruction instruction = source_rows[offset];')
old=''.join('    '+line if line.strip() else line for line in old.splitlines(True))
s=s[:start]+'''                u32 first_offset = 0;
                while (result && first_offset < old->instruction_count)
                {
                    u32 old_first = old->first_instruction + first_offset;
                    u32 span_count = old->instruction_count - first_offset;
                    if (chunks)
                    {
                        span_count = BUSTER_MIN(span_count, chunk_capacity - old_first % chunk_capacity);
                    }
                    MachineInstruction const* source_rows = machine_parameter_edge_instruction(function, chunks, chunk_capacity, old_first);
                    for (u32 offset = 0; offset < span_count; offset += 1)
                    {
'''+old+'''                    }
                    first_offset += span_count;
                }
'''+s[end:]
pos=s.index('bool machine_function_split_parameter_edges(Arena* arena, MachineFunction* function)')
s=s[:pos]+'''bool machine_function_split_parameter_edges_with_canonical_map(Arena* arena, MachineFunction* function,
                                                                u32** canonical_entries, u32 canonical_count)
{
    bool result = machine_function_split_parameter_edges_from_rows(arena, function, canonical_entries, canonical_count, 0, 0);
    return result;
}

BUSTER_GLOBAL_LOCAL bool machine_function_publish_parameter_edges(Arena* arena, MachineFunction* function,
                                                                   MachineFunctionBuilder* builder, u32** canonical_entries, u32 canonical_count)
{
    bool result;
    if (!function->instructions && function->instruction_count)
    {
        // Only a chunk directory is new work: O(I / chunk_capacity), rather
        // than another I-row payload allocation/copy. Keep it out of the
        // publication arena so both split and no-split paths reclaim it.
        TemporalArena scratch = scratch_begin(&arena, 1);
        u32 capacity = builder->instructions.chunk_capacity;
        u32 count = (function->instruction_count - 1u) / capacity + 1u;
        MachineInstruction const** chunks = arena_allocate(scratch.arena, MachineInstruction const*, count);
        u32 chunk_index = 0;
        for (MachineBuilderChunk* chunk = builder->instructions.first; chunk; chunk = chunk->next)
        {
            chunks[chunk_index++] = (MachineInstruction const*)(chunk + 1);
        }
        BUSTER_CHECK(chunk_index == count);
        result = machine_function_split_parameter_edges_from_rows(arena, function, canonical_entries, canonical_count, chunks, capacity);
        if (result && !function->instructions)
        {
            function->instructions = (MachineInstruction*)machine_stream_materialize(
                arena, builder->arena, &builder->instructions, BUSTER_ALIGN_OF(MachineInstruction));
        }
        scratch_end(scratch);
    }
    else
    {
        result = machine_function_split_parameter_edges_with_canonical_map(arena, function, canonical_entries, canonical_count);
    }
    return result;
}

'''+s[pos:]
p.write_text(s)
for name in ['machine_x86_64.c','machine_aarch64.c']:
 p=root/name;s=p.read_text();s=s.replace('machine_function_builder_finish(arena, &selector.builder)', 'machine_function_builder_finish_selection(arena, &selector.builder,\n            !nonvolatile_memory || ir_function_may_contain_opcodes(function, IR_OPCODE_BIT(IR_OPCODE_INLINE_ASSEMBLY)))',1)
 s=s.replace('machine_function_split_parameter_edges_with_canonical_map(arena, &result.function,','machine_function_publish_parameter_edges(arena, &result.function, &selector.builder,',1)
 p.write_text(s)
