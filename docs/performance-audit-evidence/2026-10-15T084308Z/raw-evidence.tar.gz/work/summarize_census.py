import csv,json,sys
from pathlib import Path
keys='i b e splits canonical_b materialize_i materialize_b materialize_e finish_ns remap_ns split_ns retained switch_bytes asm_bytes nonvolatile asm_count internal_edges'.split()
rows=[dict(zip(keys,map(int,line.strip().split(',')[1:]))) for line in Path(sys.argv[1]).read_text().splitlines() if line.startswith('MIR_CENSUS,')]
groups={}
for name,pred in {
 'all':lambda r:True,'no_split':lambda r:r['splits']==0,'split':lambda r:r['splits']>0,
 'tiny_split':lambda r:r['splits']>0 and r['i']<=64,
 'single_chunk_split':lambda r:r['splits']>0 and r['materialize_i']==0,
 'multi_chunk_split':lambda r:r['splits']>0 and r['materialize_i']>0,
 'expanded_split':lambda r:r['splits']>0 and r['b']>r['canonical_b'],
 'defer_eligible_split':lambda r:r['splits']>0 and r['materialize_i']>0 and r['nonvolatile'] and not r['asm_count'],
}.items():
 rr=[r for r in rows if pred(r)]
 g={'functions':len(rr)}
 for k in keys:g[k]=sum(r[k] for r in rr)
 g['rebuilt_original_array_bytes']=sum(24*r['i']+32*r['b']+16*r['e'] for r in rr if r['splits'])
 g['inserted_array_bytes']=sum(72*r['splits'] for r in rr)
 groups[name]=g
Path(sys.argv[2]).write_text(json.dumps({'groups':groups,'rows':rows},indent=2)+'\n')
print(json.dumps(groups,indent=2))
