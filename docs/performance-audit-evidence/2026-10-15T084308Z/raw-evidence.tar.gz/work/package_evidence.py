from pathlib import Path
import hashlib,json,subprocess,tarfile,zipfile,platform
root=Path.cwd(); work=root/'work';repo=work/'buster';aid='2026-10-15T084308Z'
dest=repo/'docs/performance-audit-evidence'/aid;dest.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
names=['claim-4244.md','census-gate.md','instrument_census.py','summarize_census.py','census.patch','census.stderr','census-repeat.stderr','census.stdout','census-repeat.stdout','census-summary.json','census-repeat-summary.json','census-summary.txt','census-repeat-summary.txt','candidate.patch','candidate.format-patch','prototype.py','stream_probe.c','make_stream_probe.py','stream_coverage.py','extra_coverage.py','extra-coverage.json','extra-coverage.log','stream-probe-build-command.txt','stream-probe-build.log','stream-probe-build-2.log','stream-coverage.log','stream-coverage-2.log','check_artifacts.py','artifacts.json','artifacts.log','reproduce.txt','base.CMakeCache.txt','base.compile_commands.json','candidate.CMakeCache.txt','candidate.compile_commands.json','baseline-generate.log','baseline-build.log','baseline-selfhost.log','profile-generate.log','profile-build.log','candidate-build.log','census-build.log','aa-fast-g0.log','ab-fast-g0.log','time-fast-g0.log','time-aa-fast-g0.log','unity-base.stderr','unity-base.stdout','package_evidence.py']
for n in names:
 p=work/n
 if p.exists():files.append(p)
for n in ['stream-coverage','stream-coverage-2','aa-fast-g0','ab-fast-g0','time-fast-g0','time-aa-fast-g0']:
 files.extend(p for p in (work/n).rglob('*') if p.is_file())
files.extend(work.glob('artifact-*.log'))
files=sorted(set(files))
identity={
 'schema':'buster-mir-copy-experiment-v1','issue':'https://github.com/buster14a/buster/issues/4244','baseline_revision':'35fee905e39941acafb26db6d6ff3f41eb7d8dc7','trial_revision':'e359c46612ed6d0e9c8e4553252eb10968a870e8','disposition':'measured-neutral; reject trial; no production change',
 'declared_claim':'https://github.com/buster14a/buster/issues/4244#issuecomment-6187866442','effect_floors_percent':{'work':0.1,'time_resource':0.5},
 'native_build_root':str(work/'census'),'platform':platform.platform(),'compiler':subprocess.check_output(['clang','--version'],text=True).strip(),'cpu_affinity':2,
 'binaries':{n:{'path':str(work/n),'sha256':digest(work/n)} for n in ['ide-base','ide-candidate','ide-census','stream-probe','performance-evidence']},
 'unity':{'path':str(work/'unity.i'),'bytes':(work/'unity.i').stat().st_size,'sha256':digest(work/'unity.i'),'prepare_arguments':['work/ide-base','cc','-E','-Iwork/census/src','-Iwork/census/build/generated','-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0','-march=native','work/census/src/buster/apps/ide/ide.c','-o','work/unity.i']},
 'trial_source_sha256':{n:hashlib.sha256(subprocess.check_output(['git','-C',str(repo),'show','e359c46612ed6d0e9c8e4553252eb10968a870e8:src/buster/lib/compiler/codegen/'+n])).hexdigest() for n in ['machine.c','machine_x86_64.c','machine_aarch64.c']},
 'census_repeat_non_timing_identical':True,'baseline_self_host':{'fixed_point_bytes':42059776,'sha256':digest(repo/'build/self-host/Release/ide-stage1'),'stage2_sha256':digest(repo/'build/self-host/Release/ide-stage2')},
 'license':{'buster':'NOASSERTION; unselected per LICENSES/README.md at baseline','clang_llvm':'Apache-2.0 WITH LLVM-exception; component terms apply'},
 'raw_files':{str(p.relative_to(root)):digest(p) for p in files}}
(work/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
files.append(work/'identity.json')
(work/'SHA256SUMS').write_text(''.join(digest(p)+'  '+str(p.relative_to(root))+'\n' for p in files))
files.append(work/'SHA256SUMS')
archive=dest/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest=dict(identity,archive={'path':'raw-evidence.tar.gz','bytes':archive.stat().st_size,'sha256':digest(archive)})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
local=root/'outputs/issue-4244-evidence.zip'
with zipfile.ZipFile(local,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(archive,'raw-evidence.tar.gz');z.write(dest/'manifest.json','manifest.json');z.write(repo/f'docs/performance-audits/{aid}.md','audit.md')
 for n in ['ide-base','ide-candidate','ide-census','stream-probe','performance-evidence','unity.i']:
  z.write(work/n,'work/'+n)
 for fixture in ['basic_c_aarch64_i128_divide.c','basic_c_i128_divide_oracle_edges.c','basic_c_asm_goto_division.c','basic_c_asm_goto_identity.c','basic_c_switch_case_blocks.c']:
  z.write(repo/'tests'/fixture,'fixtures/'+fixture)
print(json.dumps({'archive':str(archive),'archive_sha256':digest(archive),'archive_bytes':archive.stat().st_size,'local_output':str(local),'local_bytes':local.stat().st_size,'raw_files':len(files)},indent=2))
