from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();work=root/'work';bins=[work/'ide-base-v2',work/'ide-candidate-final'];out=work/'artifact-output'
fixtures=['basic_c_aarch64_i128_divide.c','basic_c_i128_divide_oracle_edges.c','basic_c_asm_goto_division.c','basic_c_asm_goto_identity.c','basic_c_switch_case_blocks.c']
records=[]
for src in [work/'unity-v2.i']+[work/'buster/tests'/f for f in fixtures]:
 for mode in ['fast','quality']:
  for debug in ['-g0','-g']:
   args=['cc','-march=native',debug,'-fregister-allocator='+mode,str(src),'-lm','-o',str(out)]
   hashes=[];runs=[]
   for arm,b in enumerate(bins):
    p=subprocess.run([str(b)]+args,capture_output=True)
    (work/f'artifact-final-{src.stem}-{mode}-{debug[1:]}-{arm}.log').write_bytes(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError((src,mode,debug,arm,p.returncode))
    hashes.append(hashlib.sha256(out.read_bytes()).hexdigest())
    if src.name!='unity-v2.i':
     run=subprocess.run([str(out)],capture_output=True)
     if run.returncode: raise RuntimeError(('execute',src,mode,debug,arm,run.returncode))
     runs.append(run.returncode)
   if len(set(hashes))!=1: raise RuntimeError(('unequal',src,mode,debug,hashes))
   records.append({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'mode':mode,'debug':debug,'arguments':args,'hashes':hashes,'executions':runs})
   print('PASS',src.name,mode,debug,flush=True)
(work/'artifacts-final.json').write_text(json.dumps(records,indent=2)+'\n')
