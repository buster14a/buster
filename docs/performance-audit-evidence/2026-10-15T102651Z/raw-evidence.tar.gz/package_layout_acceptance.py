from pathlib import Path
import hashlib,json,tarfile,subprocess,sys
root=Path.cwd();w=root/'work';repo=w/'buster';audit=sys.argv[1];out=repo/'docs/performance-audit-evidence'/audit
out.mkdir(parents=True,exist_ok=False)
patterns=['ab-layout-v2-fast-g0/**/*','profile-generate.log','baseline-v2-native-build.log','qualify_composed_work.py','qualify_layout_runtime.py','layout_copy_accounting.py','precomposition-validation.json','layout-sanitizer-supersession.txt','*composed*.log','*composed*.json','*composed*.txt','*composed*/**/*','*final*.log','*final*.json','*final*.txt','*final*/**/*','layout-*.log','layout-*.patch','layout_coverage.py','layout_probe.c','layout-probe-build-command.txt','layout-coverage/**/*','layout-source-size.log','layout-production-final.patch','layout-draft-pr-body.md','layout-production-progress.md','qualify_layout_work.py','check_artifacts_final.py','package_layout_acceptance.py','baseline-v2-selfhost.log','base-v2.CMakeCache.txt','base-v2.compile_commands.json','candidate-final.CMakeCache.txt','candidate-final.compile_commands.json','layout-final-selfhost.log','layout-final-mode-matrix.log','layout-final-release-tests.log','layout-sanitize-tests-2.log','layout-final-differential-2.log']
files={p for pattern in patterns for p in w.glob(pattern) if p.is_file() and p.suffix not in ('.o','.zip') and p.name not in ('image','output')}
# No compiler executables, test-produced images, or unbounded build trees in Git.
files={p for p in files if not p.name.startswith('ide-') and 'build' not in p.relative_to(w).parts and p.stat().st_size<16_000_000}
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
files=sorted(files)
records=[{'path':str(p.relative_to(w)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
meta={'schema':'buster-4244-final-layout-evidence-v1','head':head,'claim':'work-reduction','work_screen_percent':0.1,'native_time_resource_screen_percent':0.5,'zen5':False,'files':records}
for name in ['ide-base-v2','ide-candidate-v2','ide-candidate-final','ide-base-composed','ide-candidate-composed','unity-v2.i']:
 p=w/name
 if p.exists():meta.setdefault('frozen_artifacts',[]).append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(w)),recursive=False)
meta['archive_sha256']=hashlib.sha256((out/'raw-evidence.tar.gz').read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
with tarfile.open(out/'raw-evidence.tar.gz') as t:
 members={m.name:m for m in t.getmembers()}
 assert set(members)=={r['path'] for r in records}
 for r in records:assert hashlib.sha256(t.extractfile(members[r['path']]).read()).hexdigest()==r['sha256']
print('VERIFIED',len(records),'raw identities',meta['archive_sha256'])
