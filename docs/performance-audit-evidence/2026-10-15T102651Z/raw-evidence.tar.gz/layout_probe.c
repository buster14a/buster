// Diagnostic only: exact planned publication and counted geometric traversals.
#include <buster/lib/compiler/codegen/machine.c>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
ProgramState* program_state;
int main(int argc, char** argv)
{
    bool valid = argc == 4;
    u32 count = valid ? (u32)strtoul(argv[1], 0, 10) : 0;
    bool fanout = valid && !strcmp(argv[2], "fanout");
    bool duplicates = valid && !strcmp(argv[2], "duplicates");
    bool no_split = valid && !strcmp(argv[2], "no-split");
    bool a64 = valid && !strcmp(argv[3], "a64");
    valid = valid && count <= 16384;
    if (valid)
    {
        ThreadContext* context = thread_context_allocate();
        thread_context_select(context);
        Arena* arena = arena_create((ArenaCreation){.reserved_size = 256ull * 1024ull * 1024ull});
        u32 multiplicity = duplicates ? 3u : 1u;
        u32 edges = (count ? count - 1u : 0) * multiplicity;
        IrBlock* blocks = arena_allocate(arena, IrBlock, count);
        IrInstruction* rows = arena_allocate(arena, IrInstruction, count);
        IrCfgBlock* cfg_blocks = arena_allocate(arena, IrCfgBlock, count);
        IrCfgEdge* cfg_edges = arena_allocate(arena, IrCfgEdge, edges);
        IrValueId* arguments = arena_allocate(arena, IrValueId, edges);
        IrCfgParameter* parameters = arena_allocate(arena, IrCfgParameter, count);
        memset(blocks, 0, (u64)count * sizeof(*blocks));
        memset(rows, 0, (u64)count * sizeof(*rows));
        memset(cfg_blocks, 0, (u64)count * sizeof(*cfg_blocks));
        memset(arguments, 0, (u64)edges * sizeof(*arguments));
        memset(parameters, 0, (u64)count * sizeof(*parameters));
        for (u32 b = 0; b < count; b += 1)
        {
            blocks[b].last_instruction.value = b;
            rows[b].opcode = fanout ? (b == 0 ? IR_OPCODE_SWITCH : IR_OPCODE_RETURN) : (b + 1 < count ? IR_OPCODE_BRANCH_IF : IR_OPCODE_RETURN);
            cfg_blocks[b].parameter_offset = b;
            cfg_blocks[b].parameter_count = !no_split && b != 0;
            cfg_blocks[b].successor_offset = fanout ? 0 : b * multiplicity;
            cfg_blocks[b].successor_count = fanout ? (b == 0 ? edges : 0) : (b + 1 < count ? multiplicity : 0);
        }
        for (u32 e = 0; e < edges; e += 1)
        {
            cfg_edges[e] = (IrCfgEdge){.source = {.value = fanout ? 0 : e / multiplicity},
                .destination = {.value = fanout ? count - 1u - e : e / multiplicity + 1u}, .argument_offset = e};
        }
        IrPublishedCfg cfg = {.blocks = cfg_blocks, .edges = cfg_edges, .arguments = arguments, .parameters = parameters,
            .block_count = count, .edge_count = edges, .argument_count = no_split ? 0 : edges};
        IrFunction function = {.blocks = blocks, .instructions = rows, .block_count = count, .instruction_count = count,
            .published_cfg = &cfg, .opcode_summary = IR_OPCODE_SUMMARY_KNOWN};
        u32* entries = 0;
        u32* exits = 0;
        MachineParameterEdgeLayout plan = machine_parameter_edge_layout_plan(arena, &function, 0, count, &entries, &exits);
        MachineTargetDescription const* target = a64 ? machine_target_aarch64() : machine_target_x86_64();
        machine_opcode_rows_prewarm();
        MachineFunctionBuilder builder = machine_function_builder_begin(arena);
        for (u32 b = 0; b < count; b += 1)
        {
            machine_parameter_edge_layout_begin(&plan, &function, b);
            u32 mapped = entries ? entries[b] : b;
            valid &= machine_builder_block_begin(&builder) == mapped;
            MachineInstruction row = {.opcode = (u16)(a64 ? MACHINE_A64_RET : MACHINE_X64_RET)};
            if (cfg_blocks[b].successor_count)
            {
                u32 d = cfg_edges[cfg_blocks[b].successor_offset].destination.value;
                u32 destination = plan.targets ? plan.targets[d] : d;
                row = (MachineInstruction){.opcode = (u16)(a64 ? MACHINE_A64_BCC : MACHINE_X64_JCC),
                    .operands = {machine_ref_make(MACHINE_REF_BLOCK, destination), machine_ref_make(MACHINE_REF_BLOCK, destination)}};
                valid &= destination == (no_split ? d : mapped + 1u);
            }
            machine_builder_instruction(&builder, row);
            machine_builder_block_end(&builder, (MachineBlock){0});
            machine_parameter_edge_layout_end(&builder, &plan, &function, b, entries, target);
        }
        u32 registers[] = {0};
        valid &= machine_builder_canonical_edges(&builder, &function, registers, 0, &plan, entries);
        MachineFunction output = machine_function_builder_finish(arena, &builder);
        u32 splits = no_split ? 0 : edges;
        valid &= plan.planned && plan.split_count == splits && output.instruction_count == count + splits &&
                 output.block_count == count + splits && output.edge_count == edges + splits;
        u32 cursor = 0;
        for (u32 e = 0; e < edges; e += 1)
        {
            u32 source = cfg_edges[e].source.value;
            u32 destination = cfg_edges[e].destination.value;
            u32 mapped_source = entries ? entries[source] : source;
            u32 mapped_dest = entries ? entries[destination] : destination;
            MachineEdge expected = {.source_block = mapped_source, .destination_block = mapped_dest, .copy_offset = no_split ? 0 : e,
                .copy_count = (u16)!no_split};
            if (splits)
            {
                u32 split = fanout ? e + 1u : mapped_source + 1u + e % multiplicity;
                expected.destination_block = split;
                expected.copy_count = 0;
                valid &= !memcmp(output.edges + cursor++, &expected, sizeof(expected));
                expected = (MachineEdge){.source_block = split, .destination_block = mapped_dest, .copy_offset = e, .copy_count = 1};
                MachineInstruction branch = {.opcode = target->unconditional_branch_opcode,
                    .operands = {machine_ref_make(MACHINE_REF_BLOCK, mapped_dest)}};
                MachineBlock block = {.first_instruction = split, .instruction_count = 1};
                valid &= !memcmp(output.instructions + split, &branch, sizeof(branch)) && !memcmp(output.blocks + split, &block, sizeof(block));
            }
            valid &= !memcmp(output.edges + cursor++, &expected, sizeof(expected));
        }
        printf("blocks=%u edges=%u splits=%u output_rows=%u valid=%u\n", count, edges, splits, output.instruction_count, valid);
        arena_destroy(arena, 1);
        thread_context_release(context);
    }
    return valid ? 0 : 1;
}
