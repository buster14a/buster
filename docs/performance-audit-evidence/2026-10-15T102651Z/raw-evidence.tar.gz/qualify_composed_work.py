from pathlib import Path
import subprocess,json
root=Path.cwd();w=root/'work';base='0f98c215dc265962abd46b7a5f315312e98a6426';candidate='b09ad3fd656e8eccd58e272a249b5caf61de5968'
commands=[]
for name,mode,debug,control in [('aa-composed-fast-g0','fast','-g0',True),('ab-composed-fast-g0','fast','-g0',False),('ab-composed-quality-g0','quality','-g0',False),('ab-composed-fast-g','fast','-g',False)]:
 args=['taskset','-c','2',str(w/'performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--baseline',str(w/'ide-base-composed'),'--candidate',str(w/('ide-base-composed' if control else 'ide-candidate-composed')),'--baseline-revision',base,'--candidate-revision',base if control else candidate,'--events','instructions:u','--runs','6','--min-effect-percent','0.1','--out',str(w/name),'--','cc','-march=native',debug,'-fregister-allocator='+mode,str(w/'unity-v2.i'),'-lm','-o',str(w/'ab-composed-output')]
 commands.append(args);(w/'composed-work-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (w/(name+'.log')).open('w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError((name,p.returncode))
 summary=json.load(open(w/name/'summary.json'));print(name,summary['result'],flush=True)
 if not summary['complete']:raise RuntimeError((name,'incomplete'))
