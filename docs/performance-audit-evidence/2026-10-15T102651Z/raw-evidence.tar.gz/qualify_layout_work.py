from pathlib import Path
import subprocess,json
root=Path.cwd();w=root/'work';base='88a9f1bb3adafa6d1512c2136c5b2235081ee159';candidate='d9a881e8ca233e0ab7b7e648bec312f5e310b831'
commands=[]
for name,mode,debug,control in [('aa-final-fast-g0','fast','-g0',True),('ab-final-fast-g0','fast','-g0',False),('ab-final-quality-g0','quality','-g0',False),('ab-final-fast-g','fast','-g',False)]:
 args=['taskset','-c','2',str(w/'performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--baseline',str(w/'ide-base-v2'),'--candidate',str(w/('ide-base-v2' if control else 'ide-candidate-final')),'--baseline-revision',base,'--candidate-revision',base if control else candidate,'--events','instructions:u','--runs','6','--min-effect-percent','0.1','--out',str(w/name),'--','cc','-march=native',debug,'-fregister-allocator='+mode,str(w/'unity-v2.i'),'-lm','-o',str(w/'ab-final-output')]
 commands.append(args);(w/'final-work-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (w/(name+'.log')).open('w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError((name,p.returncode))
 summary=json.load(open(w/name/'summary.json'));print(name,summary['result'],flush=True)
 if not summary['complete']:raise RuntimeError((name,'incomplete'))
