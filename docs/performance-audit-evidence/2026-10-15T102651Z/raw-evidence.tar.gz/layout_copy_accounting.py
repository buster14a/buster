from pathlib import Path
import json
w=Path('work');rows=json.loads((w/'layout-coverage/counts.json').read_text())['rows'];records=[]
for row in rows:
 target,rest=row['cell'].split('-',1);shape,n=rest.rsplit('-',1);n=int(n);e=max(n-1,0)*(3 if shape=='duplicates' else 1);s=e if shape!='no-split' else 0
 before=(n,n,e);after=(n+s,n+s,e+s);sizes=(24,32,16)
 old_flat=sum(c*z for c,z in zip(before,sizes) if c>(4096-16)//z)
 rebuilt=sum(c*z for c,z in zip(after,sizes)) if s else 0
 new_flat=sum(c*z for c,z in zip(after,sizes) if c>(4096-16)//z)
 saved=old_flat+rebuilt-new_flat
 assert saved>=0
 records.append({'cell':row['cell'],'old_initial_materialize_payload':old_flat,'old_split_rebuild_payload':rebuilt,'new_final_materialize_payload':new_flat,'net_payload_copy_bytes_removed':saved,'new_plan_map_payload_bytes':4*(e+2*n) if s else 0,'old_split_scratch_payload_bytes':4*(n+3*n+2*e+1) if s else 0})
(w/'composed-copy-accounting.json').write_text(json.dumps({'method':'Source-derived logical payload-copy accounting, not observed runtime bytes or RSS. Fixed 4 KiB chunks, 16-byte x86_64 builder header; CT-checked 24/32/16-byte instruction/block/edge records. One-chunk streams borrow in the same arena. Includes new final materialization and planning maps; excludes alignment/header reservations, switch tables and unchanged register/parameter/copy-source streams. Actual traversal regions and closed-form records are checked separately in layout-coverage/counts.json.','rows':records},indent=2)+'\n')
for r in records:
 if r['cell'] in ['x64-chain-17','x64-chain-16384','x64-duplicates-16384']: print(r)
