from pathlib import Path
import os,subprocess,json,hashlib
root=Path.cwd();w=root/'work';source=w/'buster/src/buster/lib/compiler/codegen/machine.c';binary=w/'layout-probe';out=w/'layout-coverage';out.mkdir(exist_ok=False)
lines=source.read_text().splitlines();points={}
for key,fn,needle in [
 ('plan_count','machine_parameter_edge_layout_plan','result.split_count += machine_parameter_edge_layout_splits'),
 ('plan_number','machine_parameter_edge_layout_plan','result.split_blocks[edge_index] = next_block++'),
 ('begin_edges','machine_parameter_edge_layout_begin','u32 edge_index = block->successor_offset + successor;'),
 ('end_edges','machine_parameter_edge_layout_end','u32 edge_index = block->successor_offset + successor;'),
 ('publish_edges','machine_builder_canonical_edges','IrCfgEdge const* edge = cfg->edges + index;'),
 ('publish_copies','machine_builder_canonical_edges','IR_CONSTRUCTION_RECORD(CFG_COPY_SOURCES, 1);')]:
 start=next(i for i,l in enumerate(lines) if fn+'(' in l and l.startswith('BUSTER_GLOBAL_LOCAL'))
 index=next(i for i in range(start,len(lines)) if needle in lines[i]);points[key]=(fn,(index+1,lines[index].index(needle)+1))
records=[]
for target in ['x64','a64']:
 for shape in ['chain','fanout','duplicates','no-split']:
  for n in [0,1,2,17,257,4097,16384]:
   stem=f'{target}-{shape}-{n}';raw=out/(stem+'.profraw');prof=out/(stem+'.profdata')
   p=subprocess.run([str(binary),str(n),shape,target],env=dict(os.environ,LLVM_PROFILE_FILE=str(raw)),capture_output=True,text=True,check=True)
   (out/(stem+'.stdout')).write_text(p.stdout+p.stderr)
   subprocess.run(['llvm-profdata','merge','-sparse',str(raw),'-o',str(prof)],check=True)
   export=json.loads(subprocess.check_output(['llvm-cov','export',str(binary),'-instr-profile='+str(prof),str(source)]))['data'][0]
   counts={};regions={}
   for key,(name,point) in points.items():
    f=next(f for f in export['functions'] if f['name'].split(':')[-1]==name)
    rr=[r for r in f['regions'] if r[7]==0 and r[5]==0 and (r[0],r[1])<=point<(r[2],r[3])]
    r=min(rr,key=lambda r:(r[2]-r[0],r[3]-r[1]));counts[key]=r[4];regions[key]=r
   e=max(n-1,0)*(3 if shape=='duplicates' else 1);splits=e if shape!='no-split' else 0
   expected={k:splits for k in counts};expected['publish_edges']=e
   if counts!=expected:raise ValueError((stem,counts,expected))
   records.append({'cell':stem,'counts':counts,'regions':regions,'expected':expected,'stdout':p.stdout.strip()})
(out/'counts.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'probe_sha256':hashlib.sha256((w/'layout_probe.c').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'points':points,'rows':records},indent=2)+'\n')
print('PASS',len(records),'both-target geometric publication and LLVM-counted linear traversal cells')
