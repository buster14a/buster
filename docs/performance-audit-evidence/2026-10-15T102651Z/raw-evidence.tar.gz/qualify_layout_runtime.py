from pathlib import Path
import subprocess,json
w=Path.cwd()/'work';base=(w/'composed-baseline-revision.txt').read_text().strip();candidate=(w/'composed-candidate-revision.txt').read_text().strip();commands=[]
for name,control in [('aa-composed-native-time',True),('ab-composed-native-time',False)]:
 args=['taskset','-c','2',str(w/'performance-evidence'),'compare','--claim','native-runtime','--tool','time','--baseline',str(w/'ide-base-composed'),'--candidate',str(w/('ide-base-composed' if control else 'ide-candidate-composed')),'--baseline-revision',base,'--candidate-revision',base if control else candidate,'--runs','10','--min-effect-percent','0.5','--out',str(w/name),'--','cc','-march=native','-g0','-fregister-allocator=fast',str(w/'unity-v2.i'),'-lm','-o',str(w/'runtime-composed-output')]
 commands.append(args);(w/'composed-runtime-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (w/(name+'.log')).open('w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError((name,p.returncode))
 s=json.load(open(w/name/'summary.json'));print(name,s['result'],flush=True)
 if not s['complete']:raise RuntimeError((name,'incomplete'))
