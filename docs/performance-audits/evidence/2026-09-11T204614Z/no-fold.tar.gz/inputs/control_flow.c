/* buster-throughput schema=1 seed=20260907 profile=ci scale=1 case=control_flow */
unsigned control_0000(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1721155669u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1830542459u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3288486161u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1244067361u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 145823312u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1696296653u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 278634284u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 213646579u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 395381057u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3785322941u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 4205976393u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2193068836u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1790329581u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4288528536u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3058862271u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 266762429u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0001(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3737559141u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1401595136u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3799938101u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3017837417u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 4080189391u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1034598634u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1011776401u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2495112175u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2155626029u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 4035584977u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 721120393u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2854717628u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1026851236u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 218805156u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 884858235u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1833804978u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0002(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3802825663u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3917111537u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 166091299u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2531865906u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3114962869u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3822528763u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3753982079u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3776587544u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 450349412u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2627480505u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 613150412u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1931087557u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1788101412u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3169253852u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 410275442u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2800915279u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0003(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1744447810u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2023587147u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 834317553u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3769852547u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 277600946u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 275268828u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 109763589u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 4232053376u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2116021640u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 4135266239u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3273478617u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1307503626u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2643682205u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3455571661u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3538142746u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3996824138u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0004(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3053871123u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 981704497u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1708583907u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2918195574u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2449999545u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3375535382u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3918725918u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3084942118u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2820148196u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2248095126u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 183845424u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4107370057u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3088993125u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1596500060u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 239248621u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 20584898u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0005(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 38625443u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1702078063u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 645372080u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2036314624u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1826702447u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3388755321u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1245374288u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3436014392u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1424041549u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1967093113u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3918728849u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2154577041u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 4164809390u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2338988762u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 689024258u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2324531226u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0006(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1247047293u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 888019888u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 76836860u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2753479273u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 4129838144u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1755670544u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1900434083u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3646917226u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 709431811u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 153597671u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 10357338u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4218453168u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1747377827u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3450735642u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2307132300u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 373584182u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0007(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2487049703u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3484804807u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 516608337u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3640309505u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1296093580u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3109960884u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2816014800u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2763395457u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3058064002u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3755124009u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3851408082u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3848682040u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1711558184u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 400949448u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 672271831u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1555298659u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0008(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1349426476u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 4204840425u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2712602631u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1431749200u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 780934942u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 10402953u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 921769678u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2436056986u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3251573818u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1245771358u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3320356731u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 385162104u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 114456341u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1311675053u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 320138896u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1444124563u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0009(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3101514115u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1850425045u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1000528317u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1916565271u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1728300664u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3864394334u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2061290737u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2333161296u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 311907341u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 4207380678u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1882646537u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 197414098u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3382178397u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3428155347u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 374009476u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 953361001u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0010(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3478890726u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 4070673765u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2728710275u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 773928953u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 320627030u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2045458285u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 4292183342u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2709270614u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3383402061u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3591183612u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3351666837u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1900833439u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2145478288u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 895135273u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1936224934u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3668773688u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0011(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 42790269u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2068012908u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 91500635u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3969723748u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1862317692u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1076779515u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3913216531u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3639458829u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2196331739u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2269078562u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 483995167u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 440434898u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1090681375u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3329374943u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2753221419u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 830885524u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0012(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 4072859006u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1673739080u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2448235197u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1710153696u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2084740553u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3499027636u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2920623416u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2113352897u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 4135876534u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1982069359u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 615368152u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 516420019u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 4274903211u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4274770599u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 393309672u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1665294670u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0013(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3256707483u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2330591116u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 370967808u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1361317278u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3261276021u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2419071443u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 4065082006u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3603350329u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3667749193u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2168070387u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1637903937u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3781654229u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 4161269867u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3344498350u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3374780392u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 865692453u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0014(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3242544955u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2095150634u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 380106808u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3719369192u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 234990574u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1425194064u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1819213932u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3804669u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1899244255u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2040114664u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3367367866u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2993912523u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2019884958u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 360630005u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2040530053u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1596169149u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0015(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2798755703u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 853117160u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2069211210u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 97346532u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2676445372u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3347948788u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 292598493u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3796449352u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1833633768u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3145082707u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2350082877u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3487812455u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1734439968u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1968130706u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 532010780u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 261534551u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0016(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3866872457u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2055079580u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 4011238026u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1404574217u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1339776213u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2893819989u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1688610990u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2546251415u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 601658780u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2626086987u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1887090956u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3426647681u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2116399542u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3396444767u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 964531458u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 4033842540u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0017(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 964934701u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2395037422u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 109396064u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2141975460u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 976296491u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 939173041u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 251270631u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3298601796u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1869902974u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3733148899u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 938652524u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1384085443u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 745437568u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2292125135u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1308488412u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2271701743u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0018(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 762134962u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 775102719u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 263215305u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2441488701u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3231043277u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1355161355u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 4156679576u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2770502657u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1106838736u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1292220481u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3148959143u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3535368197u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1804363129u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 54914024u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2033068660u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 813595844u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0019(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 53929431u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 771827761u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1810283506u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 797708926u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 364058495u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2630178545u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 4118205052u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3356621280u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 312331446u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3395321683u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1959120726u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1757565409u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2100458334u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1483535538u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 429927983u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2430452669u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0020(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1038387944u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 998394420u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 710580630u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1415889250u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1163136902u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1345394516u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 699296025u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1965707455u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3632810753u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3974659413u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2333553268u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3328778200u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1474285361u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1762573709u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1767315602u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3269897136u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0021(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3850678136u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2098822893u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 173672047u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 409970596u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2146528457u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 526703197u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 29896970u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 4207357246u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 4085035854u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3351083332u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2049731790u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 17773972u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 268766986u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2372331768u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1598150724u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3982763616u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0022(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1554662452u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2444560994u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 802361822u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 4042658410u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1708273111u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 762536323u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1764164962u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3102422343u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 372569766u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2498635798u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1819598048u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 184305044u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3416134355u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 826978321u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2388448533u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2335281706u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0023(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2548391056u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2996770763u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1554882808u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 4276633729u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 704341085u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3949738565u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3903923895u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1083420676u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3841344237u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3117769656u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2716812361u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1705926586u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1701861974u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2842625067u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1956797214u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3354467134u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0024(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1984137173u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3516773801u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2184995229u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3489076698u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2227449084u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 707667569u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 854479137u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3784025540u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 861832445u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2615932605u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1119395907u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2158856315u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 100460010u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2977742858u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 114229812u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 934797168u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0025(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1198428892u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 866013318u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3360908385u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1061017550u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1028583596u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2285576481u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1878102766u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3894672184u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2144510938u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1586968526u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3048985817u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 724761193u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 4219726486u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1560041022u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 289691971u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3621976789u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0026(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2679885737u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 798821710u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1218822356u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3881314795u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2931958777u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3172180551u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3795844010u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3021739247u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3871087183u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3679247893u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1363514386u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2603817937u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 4049713493u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 254030960u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3169084421u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1023367895u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0027(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 589296037u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2018302256u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2386540581u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1583330232u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2905870892u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3242276628u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 333143141u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1924123022u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 4166501473u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 463955340u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 365256423u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2099633291u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 271525361u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1723762841u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1108581039u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 428483468u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0028(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3800703825u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2062177281u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1026026164u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3461372684u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1661373204u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 4277016294u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3127629599u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3515006011u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1186363417u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3205924003u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2681782050u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2410405052u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1941500642u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3514041872u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1735653291u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 693499496u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0029(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1687095588u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 819115473u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2877061701u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2729296831u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1101001874u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1588627860u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3217548533u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 678809209u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2800644644u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2113013841u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2751394701u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3429024778u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 144310555u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1603399079u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 646097429u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 197545301u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0030(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2415722499u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3495135325u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2320983761u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3072575351u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 912609969u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 441756072u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1666985240u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 957649543u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3284190085u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2914108925u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 885768250u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3579342300u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3298014221u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4032556420u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 814630225u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 4238815523u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0031(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1256771618u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1299952340u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1594148804u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 947430266u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2934528849u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 904137616u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 643590843u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3395336446u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1922948705u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3814900713u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3639112358u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 19392248u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1122736260u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 245043033u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2171798721u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3699495604u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0032(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1009982015u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2985190693u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3558181760u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3386023794u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3719225324u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3426272357u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1110821343u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2596593496u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 617883183u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2720223943u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3338734010u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 552693377u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2835892785u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2844358870u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1424787583u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2038586190u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0033(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1872479579u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 4045764259u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2715161147u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 297352595u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 4150498390u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 952877794u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1382283145u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3200973248u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3752046105u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3866869257u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2799701076u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1244734401u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2809112645u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 511905718u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2446061964u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 280676433u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0034(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2141805993u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3616973639u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2083919288u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1856509432u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 4008926611u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 762222931u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 919881809u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1142472830u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3740459221u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3756537217u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 4065811597u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 555285934u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3943267832u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1383459779u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 246576357u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1173383858u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0035(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1550308033u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1640733214u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1132607514u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2494443802u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 52843484u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3807074610u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2959533908u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 4245058386u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1592358500u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1956380854u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1709040787u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4038258356u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 31668422u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3112352987u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 757911863u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1447509234u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0036(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2331879390u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 4274611069u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2255745006u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2319718153u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 469981243u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2542040217u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1006393938u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2793276201u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2776175780u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2052537618u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 592662248u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 457383503u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1775403850u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 247475575u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1723322560u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 157043831u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0037(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2593091550u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2581993700u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 95159993u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 706208900u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 107411239u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3368884134u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 755348986u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3975003335u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 903569117u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2652564093u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2851098935u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3641375580u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1246115308u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 327516593u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3587046760u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 645514072u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0038(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3695920753u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 606255699u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 510959367u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1058209901u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3167712162u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 98059551u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2718947298u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1183107323u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 753082870u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1399158424u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1266090019u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3306522330u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3423697821u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2402807724u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 713592685u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1472424255u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0039(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1719016941u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 481693192u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1939568339u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3043104275u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 60929443u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2544642569u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1330474143u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3103867888u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3198050991u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 733790858u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3461788924u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 32385944u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1463055126u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4086114333u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2270873626u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 358941174u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0040(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 505999419u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 98407852u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1516342552u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 328574937u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1253333422u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 4055815342u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1313547867u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2055876731u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2888599833u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2633581662u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 975770247u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 390474203u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2648259653u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4033473741u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1945463957u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 311678822u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0041(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1738229881u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3692661075u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1262511754u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3048320258u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2183400522u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1980038684u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3508950303u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1798480765u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3573450419u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2167697479u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3903745273u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2199556673u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 4211705832u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3043532882u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2369039491u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 205314801u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0042(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2067044672u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3951117454u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2701936070u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 522629788u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3890189030u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2783468743u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1617794079u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2402136168u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 490025976u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3523716605u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 4055548545u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2495379700u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1878806917u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1549594371u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 4129363069u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1098193770u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0043(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2703058598u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3036522498u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1044445052u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 893616715u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3830634766u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1360760919u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1094539839u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2770546498u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3651857351u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 513506414u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1405491269u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2299589730u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1677920812u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2912393583u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2314244210u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3828165677u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0044(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1958556633u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2315857402u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1500610049u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2694696569u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 856602832u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1720553882u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1131004773u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 464421383u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3056531952u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1258906232u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2408344251u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1505390870u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3834634650u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 254350660u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2645684996u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3656744812u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0045(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3036694624u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1032772262u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1033326763u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 667498026u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 545432364u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3892589247u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2754565974u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2524165812u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 4094532134u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2925939138u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2358867917u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4000340317u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1311438320u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 34294522u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 30659920u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 340063596u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0046(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3620680472u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 69816846u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3816301178u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 30748097u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 700883223u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1097057093u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 409241536u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2600776270u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2766399976u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3792578023u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 4041736574u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3895499453u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2542773966u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 161266629u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1114554967u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3735652325u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0047(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 620710191u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1988310914u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 505186523u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1878148184u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3360926564u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 449956507u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1406521370u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3540679377u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 374508505u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2719515117u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 4136265503u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4149387083u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 869142486u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3030544204u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3493457609u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1375190809u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0048(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1686982259u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1697272466u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3229130990u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1489260892u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2400763211u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2390995827u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3847770021u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2034214803u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 880652245u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2976820694u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 4267681852u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1616748432u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2790342311u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2973127365u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 381100338u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2696025914u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0049(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2834424848u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 436628233u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 998455290u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 4076302788u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2234518467u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 223155463u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1381629137u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3586042928u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 120400300u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3775392928u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2398076873u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1539492610u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1458815027u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4030946921u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3930605166u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2990215852u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0050(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3719408123u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 4183362108u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3686932563u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1724512599u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1703248230u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1619811826u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2373936395u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1511557476u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 766620478u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 1629070453u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3883071870u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3018968912u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3379216893u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3153068983u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3411112180u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1287637043u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0051(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 42446607u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 463512380u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 4146315071u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2554852605u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 3184825777u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3275153920u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 4054538971u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 3305014211u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2220611968u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 304046229u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1069174259u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3062286545u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2617720063u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 142919507u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2645754852u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1144020323u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0052(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3156168461u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3928390578u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2404715098u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3990222837u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 910471776u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2702487268u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2916000896u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1385012687u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3350570997u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 439153744u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 275805795u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3376365213u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 4085101707u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4168235485u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1450248537u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2618838132u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0053(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 658919775u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1087716041u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 369182959u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3700054849u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1805919920u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 20475945u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3902251351u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2333388329u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3303123297u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3363029351u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3148894280u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2258115092u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1048692697u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3374741604u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3279263057u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1244543614u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0054(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 559293710u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1527081301u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 869923330u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2678994318u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2061826337u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 1574294497u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 312051349u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1798160816u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2960043933u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3594164019u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 524951293u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3458696791u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3812777217u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3030845296u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3714877396u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 4283564799u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0055(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1589252697u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2195109889u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 4009815978u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2890861776u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 4151340410u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2704626357u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1729959812u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2018728754u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 1972848552u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 824388153u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3638567275u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1164496557u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3407175315u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2015809776u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3844652140u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2785927934u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0056(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1343739191u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 4238175631u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1958217273u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 4221344966u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1753837636u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2528883588u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 4188225473u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1429294444u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 4009924450u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 4176693u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 477459385u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4064501176u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2809542914u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1788832777u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 1692401478u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 4258867581u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0057(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3324659142u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1556779887u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3662279612u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1677604291u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 226945888u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3451576757u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2685216531u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2567432676u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3813680345u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 514166972u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 989502021u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1609817372u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 2925111732u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 4135838819u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3422023140u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 4280659681u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0058(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 365746237u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1470944344u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1775365035u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3224411865u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2928751276u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2421829390u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1657487283u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2727803021u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3446386574u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2883341219u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2007983127u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4271176097u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 1438500689u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1202040506u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3156240355u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2874650157u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0059(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2362838500u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3762274673u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 439108185u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 3733079594u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1588522025u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3864672828u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2191572210u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 854096845u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 2410243493u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 3232698699u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 1917477128u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 4077173149u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3805436742u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2665692411u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 3606587621u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2943927287u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0060(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 1472820980u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1542358431u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3774424593u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1129833868u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 1126266271u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 3754346902u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3631568748u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 562375200u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 485253184u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2355179122u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2621992453u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2694340321u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3284222755u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2668595409u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2896585915u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1712824515u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0061(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 3556684100u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 3205514831u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 1290160579u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 1041436332u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 2803009711u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 921003564u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 3728067772u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 2481820365u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 389046519u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2130649440u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 3233738025u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 3194205988u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3631038343u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 2351032681u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2426317839u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 3874668160u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0062(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 2508071985u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 1862120813u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 3529462245u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 874403668u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 543272430u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 2924513024u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 1756091224u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 1255906616u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 384610630u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2554467748u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2217337663u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 2978331672u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 3335609467u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 1184305236u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 925204826u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 1725880701u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
unsigned control_0063(unsigned x, unsigned y)
{
    if ((x ^ y) & 1u) { x += y; } else { y ^= x + 64345893u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2u) { x += y; } else { y ^= x + 2668911645u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4u) { x += y; } else { y ^= x + 2255043734u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8u) { x += y; } else { y ^= x + 2660114699u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16u) { x += y; } else { y ^= x + 256042972u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32u) { x += y; } else { y ^= x + 613453312u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 64u) { x += y; } else { y ^= x + 2671903144u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 128u) { x += y; } else { y ^= x + 832220275u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 256u) { x += y; } else { y ^= x + 3867881817u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 512u) { x += y; } else { y ^= x + 2494197801u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 1024u) { x += y; } else { y ^= x + 2403898046u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 2048u) { x += y; } else { y ^= x + 1056741905u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 4096u) { x += y; } else { y ^= x + 442725646u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 8192u) { x += y; } else { y ^= x + 3969081999u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 16384u) { x += y; } else { y ^= x + 2560270126u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    if ((x ^ y) & 32768u) { x += y; } else { y ^= x + 2761451697u; }
    for (unsigned k = 0; k < (y & 3u); ++k) { x = x * 33u + k; }
    switch (x & 3u) { case 0: y += x; break; case 1: y ^= x; break; default: x += y; break; }
    return x ^ y;
}
