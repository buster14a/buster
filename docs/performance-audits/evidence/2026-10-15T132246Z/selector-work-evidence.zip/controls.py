from pathlib import Path
import argparse
import subprocess

w = Path('/home/david/Documents/Codex/2026-10-15/fin/work')
parser = argparse.ArgumentParser()
parser.add_argument('baseline')
parser.add_argument('candidate')
parser.add_argument('label')
parser.add_argument('--indexed-primary', action='store_true')
args = parser.parse_args()
cases = [(name, ['cc', '-c', '-march=native', '-g0', '-fregister-allocator=fast', str(w / 'inputs' / (name + '.c')),
                 '-o', str(w / 'control-output.o')])
         for name in ['arithmetic', 'indexed', 'many-small', 'one-large', 'abi-and-memory']]
if args.indexed_primary:
    cases.insert(0, ('indexed-selection', ['bench-select', str(w / 'inputs/indexed.c')]))
for name, tail in cases:
    output = w / (args.label + '-' + name)
    command = ['taskset', '-c', '2', str(w / 'performance-evidence'), 'compare', '--claim', 'work-reduction',
               '--tool', 'perf-stat', '--baseline', str(w / args.baseline), '--candidate', str(w / args.candidate),
               '--out', str(output), '--runs', '6', '--events', 'instructions:u', '--min-effect-percent', '0.1', '--', *tail]
    with (w / (args.label + '-' + name + '.log')).open('w') as stream:
        result = subprocess.run(command, cwd=w / 'buster', stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, output
    print(name, 'complete', flush=True)
