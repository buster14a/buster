import argparse
import hashlib
import json
from pathlib import Path
import subprocess

w = Path('/home/david/Documents/Codex/2026-10-15/fin/work')
parser = argparse.ArgumentParser()
parser.add_argument('baseline')
parser.add_argument('candidate')
parser.add_argument('label')
parser.add_argument('--unity', action='store_true')
args = parser.parse_args()
directory = w / (args.label + '-identity')
directory.mkdir(exist_ok=True)
records = []
sources = sorted((w / 'inputs').glob('*.c'))
if args.unity:
    sources.append(w / 'unity.i')
for src in sources:
    for mode in ('fast', 'quality'):
        for debug in ('-g0', '-g'):
            products = []
            for arm, binary in [('baseline', args.baseline), ('candidate', args.candidate)]:
                name = f'{src.stem}-{mode}-{debug[1:]}-{arm}'
                product = directory / (name + ('.exe' if src.suffix == '.i' else '.o'))
                command = ['taskset', '-c', '2', str(w / binary), 'cc', '-march=native', debug, '-fregister-allocator=' + mode]
                if src.suffix != '.i':
                    command.append('-c')
                command.extend([str(src)])
                if src.suffix == '.i':
                    command.append('-lm')
                command.extend(['-o', str(product)])
                with (directory / (name + '.log')).open('w') as stream:
                    result = subprocess.run(command, cwd=w / 'buster', stdout=stream, stderr=subprocess.STDOUT)
                assert result.returncode == 0, command
                products.append(product)
            assert products[0].read_bytes() == products[1].read_bytes(), products
            records.append({'source': src.name, 'mode': mode, 'debug': debug, 'identical': True,
                            'sha256': hashlib.sha256(products[0].read_bytes()).hexdigest()})
            print(src.name, mode, debug, 'identical', flush=True)
(directory / 'identity.json').write_text(json.dumps(records, indent=2) + '\n')
