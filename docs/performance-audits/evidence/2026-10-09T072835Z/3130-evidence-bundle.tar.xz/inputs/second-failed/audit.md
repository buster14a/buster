# #3130 second 9700X analyzer attempt: failed evidence audit

Disposition: **failed and comparison-invalid; this is not a performance acceptance result.** The receipt is `failed`, the retained analyzer summary is `failed` with `comparison_invalid=true`, and the helper exited 1. All four matched analysis arms failed at the same translation unit. No baseline-to-candidate ratio, speedup, gain, or qualification conclusion is supported.

## Bound request, source, and host

The copied ZIP is byte-identical to the materialized attempt: 6,985,721 bytes, SHA-256 `95086bb50bc6465b2fafd37345d5c443a5d764679043165876cf1069f8a73d23`. The archive has 802 unique members; CRC verification passed and the inventory found no duplicate, unsafe, or symlink entries. [`archive-members.json`](archive-members.json) lists every member’s full SHA-256, size, and CRC. Its own SHA-256 is `f76d6f9865a6994df66130da67251156b3d7a585c5b6b0e0a4c12ba48d9fd401`.

The external expected identity has 13 keys and matches all 13 artifact receipt keys exactly. This is the identity record, not a synthesized local checkout:

| Identity key | Value |
| --- | --- |
| `repository` | `buster14a/buster` |
| `mode` | `pull` |
| `pull` | `3167` |
| `ref` | `refs/pull/3167/head` |
| `request_run_id` | `37894323184` |
| `run_id` | `37894338138` |
| `run_attempt` | `1` |
| `base` | `521b791421a962a085a0a9685357b6ea5ca790ef` |
| `base_tree` | `c1c0fbe0448824c69698e3b54294781543f196d7` |
| `head` | `7c75f6277c723125c09152a21cffc217c14db5c5` |
| `head_tree` | `6f711a0b96409a3c97b343d2614eadf4488d1a5d` |
| `pull_head` | `7c75f6277c723125c09152a21cffc217c14db5c5` |
| `trusted_revision` | `521b791421a962a085a0a9685357b6ea5ca790ef` |

The bound request is 8,472 bytes, SHA-256 `b58621ff49de247bc426489ef9e374bed47af3e50c72b5b3632d1e3feee29354`, and selects `profile: clang-analyze-full-v1` (two occurrences in the request). The workload uses Release, one candidate `compile_commands.json` (1,057,099 bytes; SHA-256 `6fdb5dc392e947c0f14e341a2880caf329a9bc0b1f433c3d6d36762604dd86c0`) shared byte-for-byte by both drivers, 182 rows, 8 shards, 2 jobs, 600-second per-TU timeout, two repetitions per driver in baseline/candidate/candidate/baseline order, and separate baseline/candidate preparation phases. The host identifies as AMD Ryzen 7 9700X 8-Core Processor (`benchpress`) with Clang 23.1.1; both analysis plans resolve `/usr/bin/clang-23`. The baseline driver checkout is trusted revision `521b791…`; the candidate driver checkout is `7c75f627…`. The exact identities and driver/toolchain provenance are retained in the ZIP and independent facts file.

Preflight authorization/request/TCC captures are in the sibling [`pre-campaign`](../pre-campaign/) directory and are referenced there rather than duplicated. Its canonical TCC source-size report is for merge commit `646d7e6a5daba7ae056cec1647b39a3080086ad2`, with the same tree as candidate H and parents base/H; it is not represented as a report literally run at H.

## Observed analyzer failure

Arm order was baseline-0, candidate-0, candidate-1, baseline-1. Each arm retains 182 of 182 rows and 182 bound diagnostic logs with no unbound logs; all have 181 passing rows and one failed row. Each also retains all eight terminal shard results: seven pass and shard 2 fails. Baseline PLAN_V1 records 182 executions and 0 aliases. Each candidate PLAN_V2 records 135 executions and 47 aliases.

The failed row is index 97, `ir`, `src/buster/lib/compiler/ir/ir.c:270:31`, compiler status 1 in every arm. The same 24,137-byte log is present in all four arms (SHA-256 `a851af2db8048a5d557053fc3053e75c4ae03d71fd4cd5d85f31bf6f429a8523`). It reports `Addition of a null pointer (via field 'types') and a probably nonzero integer value (via field 'value') may result in undefined behavior [core.NullPointerArithm]`. The trace selects `IR_OPCODE_VA_COPY` in the grouped `VA_START/VA_COPY/VA_END/VA_ARG` branch at `ir.c:6588` and calls `ir_type_from_id` at lines 6591, 6592, and 6604. This records the analyzer path, not a proven source root cause. The source-writer follow-up is assigned under #3168 comment `6076206079`; this package contains no fix or successful rerun.

| Arm | Role | Plan | Rows | Executions | Aliases | Row outcomes | Run elapsed (µs) | Result |
| --- | --- | --- | ---: | ---: | ---: | --- | ---: | --- |
| baseline-0 | baseline | PLAN_V1 | 182 | 182 | 0 | 181 pass, 1 fail | 307,883,532 | failed |
| candidate-0 | candidate | PLAN_V2 | 182 | 135 | 47 | 181 pass, 1 fail | 329,060,789 | failed |
| candidate-1 | candidate | PLAN_V2 | 182 | 135 | 47 | 181 pass, 1 fail | 328,384,247 | failed |
| baseline-1 | baseline | PLAN_V1 | 182 | 182 | 0 | 181 pass, 1 fail | 307,534,961 | failed |

All four analysis phases and all four aggregate phases exited with status 256 after the TU failure. The independent and in-run aggregate records agree in each arm. They report `checked=182`, `eligible=182`, `excluded_config_or_language=182`, `failures=1`, `shards=8`, and `status=fail`; candidate aggregates additionally report `selected_rows=182`, `unique_executions=135`, and `aliased_rows=47`. The aggregate `peak_child_rss_bytes` values are retained per arm. Their count/plan identities match, but the nonzero failure count violates the successful-result contract, so the aggregate and each arm remain invalid.

## Native phase observations

The ten phase records below were checked exactly against the ZIP’s `analyzer/summary.json` and the independent raw-replay facts. Times are microseconds. `largest individual RSS` is the per-phase `wait4` individual high-water, not a simultaneous sum of child RSS or process-tree memory. `exit=256` is a failed command; it is not a signal number.

| Phase | State / exit | Wall µs | User CPU µs | System CPU µs | Largest individual RSS bytes |
| --- | --- | ---: | ---: | ---: | ---: |
| prepare-baseline | complete / 0 | 64,630 | 59,601 | 3,311 | 23,568,384 |
| prepare-candidate | complete / 0 | 5,450,932 | 4,829,173 | 251,031 | 70,492,160 |
| analysis-baseline-0 | failed / 256 | 307,886,125 | 602,229,251 | 6,360,115 | 447,451,136 |
| aggregate-baseline-0 | failed / 256 | 64,776 | 63,388 | 0 | 23,490,560 |
| analysis-candidate-0 | failed / 256 | 329,063,331 | 640,307,119 | 6,739,129 | 451,751,936 |
| aggregate-candidate-0 | failed / 256 | 5,592,715 | 4,841,286 | 236,167 | 70,266,880 |
| analysis-candidate-1 | failed / 256 | 328,386,690 | 640,205,062 | 6,746,643 | 447,381,504 |
| aggregate-candidate-1 | failed / 256 | 5,425,078 | 4,874,419 | 205,888 | 70,250,496 |
| analysis-baseline-1 | failed / 256 | 307,537,365 | 601,901,886 | 6,516,940 | 447,483,904 |
| aggregate-baseline-1 | failed / 256 | 64,954 | 63,537 | 0 | 23,425,024 |

The phase totals are 1,289,536,596 µs native phase wall, comprising 5,515,562 µs preparation, 1,272,873,511 µs matched analysis, and 11,147,523 µs independent aggregate. The native helper reports 1,289,537,361 µs overall elapsed. The largest individual `wait4` RSS across phases is 451,751,936 bytes. These failed-run timings are observations only; they are not compared into a performance claim.

## Retained partial planning and shard costs

All available candidate PLAN_V2 and SHARD raw records were independently matched to the analysis stdout logs. Costs remain marked partial/failed validation, not qualification evidence. PLAN fields are `mode`, `selected_rows`, `unique_executions`, `aliases`, `planning_us`, and `context_proof_us`; worker plans add `shard`. The two run-plan and aggregate-plan observations are:

| Arm | PLAN mode | Planning µs | Context proof µs |
| --- | --- | ---: | ---: |
| candidate-0 | run | 5,549,813 | 5,465,855 |
| candidate-0 | aggregate | 5,587,063 | 5,502,460 |
| candidate-1 | run | 5,372,424 | 5,287,812 |
| candidate-1 | aggregate | 5,419,338 | 5,335,759 |

Each candidate arm also retains eight worker PLAN records and eight SHARD records. SHARD fields are `shard`, `selected_rows`, `unique_executions`, `aliased_rows`, `elapsed_us`, `context_preflight_us`, `context_postflight_us`, `peak_child_rss_bytes`, and `status`; all 16 raw records, including shard 2 failure, are in the independent facts JSON and original ZIP. PLAN_V1 baselines do not emit internal planning/context cost records: those values are unavailable, not zero. Aggregate process wall remains separately recorded in the native phase table.

## Sampler observations and limit

Sampler data is an independently sampled process-tree RSS lower bound, not continuous high-water RSS. Every arm’s `ANALYZE_RUN` record says `process_tree_status=complete` and `process_tree_reason=none`, and the summary says `status=complete`; however, the same summary’s top-level reason says “no complete full-run sample evidence was verified.” The summary’s status/completeness and reason are preserved verbatim; the reason is not reconciled into stronger sampler or qualification evidence.

| Arm | Status / reason | Jobs | Peak live processes | Peak pending workers | Samples | Sampled peak tree RSS bytes | Elapsed µs |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| baseline-0 | complete / none | 2 | 5 | 2 | 12,242 | 875,667,456 | 307,883,532 |
| candidate-0 | complete / none | 2 | 8 | 2 | 12,869 | 900,042,752 | 329,060,789 |
| candidate-1 | complete / none | 2 | 8 | 2 | 12,849 | 901,545,984 | 328,384,247 |
| baseline-1 | complete / none | 2 | 5 | 2 | 12,228 | 884,977,664 | 307,534,961 |

The full independent JSON preserves the exact top-level sampler status, completeness, contradictory reason, and per-run raw fields. This sampled measure must not be conflated with phase `wait4` individual RSS or aggregate `peak_child_rss_bytes`.

## Qualification limits and repository license note

The strict validator reports 42 problems; the outer receipt reports 43 reasons. All 182 per-TU baseline medians and all 182 candidate medians are null. The publisher decision is failure / “Not benchmarked.” Raw durations, sampler records, plans, aggregates, terminal shard outcomes, and partial per-TU facts are preserved, but no baseline/candidate timing ratio or gain is valid.

A bounded license-status check at candidate H found no root `LICENSE` or `COPYING`. `THIRD_PARTY_NOTICES.md`, `README.md`, and `LICENSES/README.md` state that upstream notices do not grant a first-party Buster license and no project-wide license is selected; the decision and unresolved questions are tracked in #621. This audit does not assert a project-wide license or redistribution permission. The files inspected are from the identity-bound H tree; their hashes and Git blob IDs are recorded in `provenance.json`.

## Files in this evidence package

- `issue3130-9700x-second-attempt.zip`: byte-identical original ZIP.
- `archive-members.json`: per-member size, CRC32, and SHA-256 inventory for all 802 members.
- `3130-second-physical-job.log` and `3130-second-publisher-job.log`: raw completed hosted job logs.
- `3130-second-expected-identity.json`: byte-preserved external 13-key identity record.
- `issue3160-second-campaign-independent-facts.json`: byte-exact independent raw replay facts, including all phase, arm, cost, sampler, and row observations.
- `provenance.json`: capture provenance, replay cross-checks, license-file source hashes, and scope limits.
- `SHA256SUMS`: hashes for each file in this directory other than the checksum file itself.
