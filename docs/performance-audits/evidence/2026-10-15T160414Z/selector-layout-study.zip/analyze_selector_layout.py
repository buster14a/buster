import csv
import json
import statistics
from pathlib import Path

out = Path(__file__).resolve().parent / 'evidence/layout-study'
# These adjacent orchestration runs overlapped on CPU 2. Preserve the raw
# records but exclude them, replacing each with one isolated diagnostic run.
excluded = {'selector-fills-2', 'stage1-overview-0'}
groups = {}
for path in out.glob('*.csv'):
    if path.stem in excluded or not path.stem.startswith(('selector-', 'stage1-')):
        continue
    scope = path.stem.split('-')[0]
    for row in csv.reader(path.read_text().splitlines(), delimiter=';'):
        if len(row) < 5 or row[0].startswith('#'):
            continue
        value, unit, event, enabled, percent = row[:5]
        assert float(percent) == 100, (path, row)
        groups.setdefault(scope, {}).setdefault(event, []).append((float(value), float(enabled)))

summary = {}
for scope, counters in groups.items():
    data = {k: {'median': statistics.median(v[0] for v in vals),
                'minimum': min(v[0] for v in vals), 'maximum': max(v[0] for v in vals),
                'samples': len(vals), 'counter_seconds': statistics.median(v[1] for v in vals) / 1e9}
            for k, vals in counters.items()}
    get = lambda event: data[event + ':u']['median']
    derived = {
        'ipc': get('instructions') / get('cycles'),
        'branch_miss_percent': 100 * get('branch-misses') / get('branches'),
        'indirect_share_of_branch_misses_percent': 100 * get('ex_ret_brn_ind_misp') / get('branch-misses'),
        'branch_mpki': 1000 * get('branch-misses') / get('instructions'),
        'l2_demand_miss_percent': 100 * get('l2_cache_req_stat.ls_rd_blk_c') / get('l2_cache_req_stat.dc_access_in_l2'),
        'dtlb_page_walk_mpki': 1000 * get('ls_l1_d_tlb_miss.all_l2_miss') / get('instructions'),
        'dram_io_any_fill_payload_gb_per_second': get('ls_any_fills_from_sys.dram_io_near') * 64 / 1e9 / data['ls_any_fills_from_sys.dram_io_near:u']['counter_seconds'],
    }
    refill_events = ['ls_dmnd_fills_from_sys.' + s for s in ['local_l2', 'local_ccx', 'dram_io_near']]
    counted_refills = sum(get(event) for event in refill_events)
    for event in refill_events:
        derived[event + '_share_of_three_sources_percent'] = 100 * get(event) / counted_refills
    summary[scope] = {'counters': data, 'derived': derived}
summary['exclusions'] = sorted(excluded)
(out / 'hardware-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v['derived'] for k, v in summary.items() if k != 'exclusions'}, indent=2))
