import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

root = Path(__file__).resolve().parent
repo = root / 'buster'
evidence = root / 'evidence/layout-study'
subjects = root / 'subjects'
runner = subjects / 'performance-evidence'
baseline = subjects / 'ide-roles'
candidate = subjects / 'ide-selector-batch'
source = root / 'evidence/frozen-unity.i'
for mode in ['fast', 'quality']:
    identities = []
    for name, compiler in [('roles', baseline), ('batch', candidate)]:
        output = evidence / ('identity-' + mode + '-' + name)
        argv = [str(compiler), 'cc', '-march=native', '-g', '-fregister-allocator=' + mode,
                str(source), '-lm', '-o', str(output)]
        with (evidence / ('identity-' + mode + '-' + name + '.log')).open('w') as log:
            subprocess.run(['taskset', '-c', '2', *argv], cwd=repo, stdout=log, stderr=subprocess.STDOUT, check=True)
        identities.append({'arm': name, 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                           'bytes': output.stat().st_size, 'argv': argv})
    (evidence / ('batch-identity-' + mode + '.json')).write_text(json.dumps(identities, indent=2))
    assert identities[0]['sha256'] == identities[1]['sha256'], identities
    print(mode + ' output identical', flush=True)

for tool, claim, count in [('perf-stat', 'work-reduction', 6), ('time', 'native-runtime', 10)]:
    if tool == 'time':
        # Do not overlap this task's native timing with the owner's compiler
        # build. Work counts and artifact identity do not claim elapsed speed.
        for attempt in range(60):
            busy = []
            for path in Path('/proc').glob('[0-9]*/cmdline'):
                try:
                    arguments = path.read_bytes().split(b'\0')
                except (OSError, ProcessLookupError):
                    continue
                if arguments and b'clang' in arguments[0] and any(b'/home/david/dev/buster/src/' in arg for arg in arguments):
                    busy.append(path.parent.name)
            if not busy:
                break
            print('Waiting for external compiler build: ' + ', '.join(busy), flush=True)
            time.sleep(5)
        else:
            raise SystemExit('Native timing not run: external build remains active')
    destination = evidence / ('batch-' + tool)
    argv = ['taskset', '-c', '2', str(runner), 'compare', '--claim', claim, '--tool', tool,
            '--baseline', str(baseline), '--candidate', str(candidate), '--out', str(destination),
            '--runs', str(count), '--min-effect-percent', '2']
    if tool == 'perf-stat':
        argv += ['--events', 'instructions:u']
    argv += ['--', 'bench-select', str(source)]
    with (evidence / ('batch-' + tool + '.log')).open('w') as log:
        run = subprocess.run(argv, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    print(json.dumps({'tool': tool, 'exit': run.returncode,
                      'summary': json.loads((destination / 'summary.json').read_text())}), flush=True)
    if run.returncode:
        raise SystemExit(run.returncode)
