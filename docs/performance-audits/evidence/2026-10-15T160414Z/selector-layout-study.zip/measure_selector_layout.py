import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'evidence/layout-study'
GROUPS = {
    'overview': ['cycles', 'instructions', 'branches', 'branch-misses', 'ex_ret_brn_ind_misp'],
    'memory': ['instructions', 'ls_dispatch.ld_dispatch', 'ls_dispatch.store_dispatch',
               'ls_dmnd_fills_from_sys.local_l2', 'ls_dmnd_fills_from_sys.local_ccx', 'ls_dmnd_fills_from_sys.dram_io_near'],
    'cache-tlb': ['instructions', 'l2_cache_req_stat.dc_access_in_l2', 'l2_cache_req_stat.ls_rd_blk_c',
                  'ls_l1_d_tlb_miss.all', 'ls_l1_d_tlb_miss.all_l2_miss', 'ic_tag_hit_miss.instruction_cache_miss'],
    'fills': ['instructions', 'ls_any_fills_from_sys.local_l2', 'ls_any_fills_from_sys.local_ccx',
              'ls_any_fills_from_sys.dram_io_near', 'ls_dmnd_fills_from_sys.all', 'ls_hw_pf_dc_fills.all'],
}
subject = ROOT / 'subjects/ide-selector-probe'
input_path = ROOT / 'evidence/frozen-unity.i'
scope = sys.argv[1] if len(sys.argv) > 1 else 'selector'
samples = range(3)
if len(sys.argv) > 2:
    GROUPS = {sys.argv[2]: GROUPS[sys.argv[2]]}
    samples = [3]
for sample in samples:
    for group, events in GROUPS.items():
        prefix = OUT / f'{scope}-{group}-{sample}'
        env = dict(os.environ)
        perf = ['perf', 'stat', '-x', ';', '-o', str(prefix.with_suffix('.csv')),
                '-e', '{' + ','.join(e + ':u' for e in events) + '}']
        fifos = []
        if scope == 'selector':
            for suffix in ['ctl', 'ack']:
                path = prefix.with_suffix('.' + suffix)
                os.mkfifo(path)
                fifos.append(path)
            env['BUSTER_SELECTOR_PERF_CTL'] = str(fifos[0])
            env['BUSTER_SELECTOR_PERF_ACK'] = str(fifos[1])
            perf += ['--delay=-1', '--control=fifo:' + ','.join(map(str, fifos))]
            command = [str(subject), 'bench-select', str(input_path)]
        else:
            command = [str(ROOT / 'subjects/ide-roles'), 'cc', '-march=native', '-g',
                       '-fregister-allocator=fast', str(input_path), '-lm', '-o', str(OUT / 'stage1-output')]
        argv = perf + ['--', 'taskset', '-c', '2'] + command
        prefix.with_suffix('.command.json').write_text(json.dumps({'argv': argv, 'scope': scope}, indent=2))
        with prefix.with_suffix('.stdout').open('w') as stdout, prefix.with_suffix('.stderr').open('w') as stderr:
            run = subprocess.run(argv, stdout=stdout, stderr=stderr, env=env, timeout=60)
        for path in fifos:
            path.unlink()
        print(json.dumps({'scope': scope, 'sample': sample, 'group': group, 'exit': run.returncode,
                          'counters': prefix.with_suffix('.csv').read_text()}), flush=True)
        if run.returncode:
            raise SystemExit(run.returncode)
