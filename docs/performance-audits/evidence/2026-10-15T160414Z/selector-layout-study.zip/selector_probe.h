#include <fcntl.h>
#include <unistd.h>

// Diagnostic-only gate: perf counts the same warm selector interval as the
// benchmark timer, excluding frontend, module preparation and verification.
static void selector_probe_gate(bool enable)
{
    static int control = -2;
    static int acknowledgement = -1;
    if (control == -2)
    {
        char const* control_path = getenv("BUSTER_SELECTOR_PERF_CTL");
        char const* acknowledgement_path = getenv("BUSTER_SELECTOR_PERF_ACK");
        control = control_path ? open(control_path, O_WRONLY) : -1;
        acknowledgement = acknowledgement_path ? open(acknowledgement_path, O_RDONLY) : -1;
        if (control_path && (control < 0 || acknowledgement < 0))
        {
            abort();
        }
    }
    if (control >= 0)
    {
        char const* command = enable ? "enable\n" : "disable\n";
        size_t size = enable ? 7 : 8;
        char response = 0;
        if (write(control, command, size) != (ssize_t)size)
        {
            abort();
        }
        do
        {
            if (read(acknowledgement, &response, 1) != 1)
            {
                abort();
            }
        } while (response != '\n');
    }
}

static void selector_probe_census(IrProgram* program)
{
    u64 rows = 0, values = 0, results = 0, operands = 0, functions = 0, blocks = 0;
    u64 opcodes[IR_OPCODE_COUNT] = {0};
    u64 arities[10] = {0};
    u64 widths[10] = {0};
    u64 max_values = 0, max_rows = 0, no_local_rows = 0, local_rows = 0;
    for (u32 mi = 0; mi < program->module_count; mi += 1)
    {
        IrModule* module = program->modules + mi;
        for (u32 fi = 0; fi < module->function_count; fi += 1)
        {
            IrFunction* function = module->functions + fi;
            if (function->state != IR_FUNCTION_LOWERED)
            {
                continue;
            }
            functions += 1;
            values += function->value_count;
            blocks += function->block_count;
            max_values = BUSTER_MAX(max_values, function->value_count);
            max_rows = BUSTER_MAX(max_rows, function->instruction_count);
            for (u32 bi = 0; bi < function->block_count; bi += 1)
            {
                IrBlock* block = function->blocks + bi;
                u32 count = function->published_cfg->blocks[bi].instruction_count;
                widths[BUSTER_MIN(count / 16, 9u)] += 1;
                for (u32 ri = 0; ri < count; ri += 1)
                {
                    IrInstruction* row = function->instructions + block->first_instruction.value + ri;
                    rows += 1;
                    results += row->result.value < function->value_count;
                    operands += row->operand_count;
                    opcodes[row->opcode] += 1;
                    arities[BUSTER_MIN(row->operand_count, 9u)] += 1;
                    if (function->local_count) local_rows += 1; else no_local_rows += 1;
                }
            }
        }
    }
    fprintf(stderr, "CENSUS functions=%llu blocks=%llu rows=%llu values=%llu results=%llu operands=%llu max_values=%llu max_rows=%llu no_local_rows=%llu local_rows=%llu\n",
            (unsigned long long)functions, (unsigned long long)blocks, (unsigned long long)rows, (unsigned long long)values,
            (unsigned long long)results, (unsigned long long)operands, (unsigned long long)max_values,
            (unsigned long long)max_rows, (unsigned long long)no_local_rows, (unsigned long long)local_rows);
    for (u32 i = 0; i < IR_OPCODE_COUNT; i += 1)
    {
        fprintf(stderr, "OPCODE %u %llu\n", i, (unsigned long long)opcodes[i]);
    }
    for (u32 i = 0; i < 10; i += 1)
    {
        fprintf(stderr, "ARITY %u %llu BLOCK_WIDTH_BUCKET %llu\n", i, (unsigned long long)arities[i], (unsigned long long)widths[i]);
    }
}
