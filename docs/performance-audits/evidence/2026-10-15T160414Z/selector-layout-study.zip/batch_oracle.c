#include <buster/lib/compiler/codegen/machine.h>
#include <buster/lib/simd.h>
#include <stdio.h>
#include <string.h>
BUSTER_GLOBAL_LOCAL bool machine_function_mark_reference_batch(MachineInstruction const* instructions,
                                                               MachineOpcodeRow const* opcode_rows,
                                                               u8* referenced, u32 register_count)
{
    bool valid = true;
    Mask64 active = 0;
    for (u32 index = 0; index < 4; index += 1)
    {
        u32 opcode = instructions[index].opcode;
        if (opcode >= MACHINE_OPCODE_COUNT)
        {
            valid = false;
        }
        else
        {
            active |= ((1ull << opcode_rows[opcode].operand_count) - 1) << (4 * index);
        }
    }
    if (valid)
    {
        static u32 const reference_lanes[16] = {0, 1, 2, 3, 6, 7, 8, 9, 12, 13, 14, 15, 18, 19, 20, 21};
        Simd512 low = simd512_load(instructions);
        Simd512 high = simd512_load_masked((u8 const*)instructions + 64, mask64_prefix(32));
        Simd512 indices = simd512_load(reference_lanes);
        Simd512 refs = simd512_permute2_u32(0xffff, low, indices, high);
        Simd512 kind_mask = simd512_splat_u32(~(MACHINE_REF_PAYLOAD_LIMIT - 1u));
        Simd512 virtual_tag = simd512_splat_u32(MACHINE_REF_VIRTUAL_REGISTER << MACHINE_REF_PAYLOAD_BITS);
        Simd512 kinds = simd512_and(refs, kind_mask);
        Mask64 virtual_lanes = simd512_equal_u32(kinds, virtual_tag) & active;
        Simd512 payload_mask = simd512_splat_u32(MACHINE_REF_PAYLOAD_LIMIT - 1u);
        Simd512 payloads = simd512_and(refs, payload_mask);
        Simd512 limit = simd512_splat_u32(register_count);
        Mask64 in_range = simd512_less_u32(payloads, limit);
        valid = (virtual_lanes & ~in_range) == 0;
        if (valid)
        {
            u32 registers[16];
            Simd512 packed = simd512_compress_u32(virtual_lanes, payloads);
            simd512_store(registers, packed);
            u32 count = mask64_count(virtual_lanes);
            for (u32 index = 0; index < count; index += 1)
            {
                referenced[registers[index]] = 1;
            }
        }
    }
    return valid;
}
int main(void)
{
    MachineOpcodeRow rows[MACHINE_OPCODE_COUNT] = {0};
    for (u32 i = 0; i < MACHINE_OPCODE_COUNT; ++i) rows[i].operand_count = (u8)(i % 5);
    u32 state = 0x4310u;
    for (u32 trial = 0; trial < 200000; ++trial)
    {
        MachineInstruction instructions[4] = {0};
        u8 expected[64] = {0}, observed[64] = {0};
        u32 count = 1 + trial % 64;
        bool valid = true;
        for (u32 ri = 0; ri < 4; ++ri)
        {
            state = state * 1664525u + 1013904223u;
            instructions[ri].opcode = (u16)(state % (MACHINE_OPCODE_COUNT + 1));
            for (u32 slot = 0; slot < 4; ++slot)
            {
                state = state * 1664525u + 1013904223u;
                u32 tag = (state >> 27) % MACHINE_REF_KIND_COUNT;
                u32 payload = (state >> 5) % 70;
                instructions[ri].operands[slot] = (tag << MACHINE_REF_PAYLOAD_BITS) | payload;
            }
            u32 opcode = instructions[ri].opcode;
            if (opcode >= MACHINE_OPCODE_COUNT) valid = false;
            else for (u32 slot = 0; slot < rows[opcode].operand_count; ++slot)
            {
                u32 ref = instructions[ri].operands[slot];
                if ((ref >> MACHINE_REF_PAYLOAD_BITS) == MACHINE_REF_VIRTUAL_REGISTER)
                {
                    u32 index = ref & (MACHINE_REF_PAYLOAD_LIMIT - 1u);
                    if (index >= count) valid = false;
                    else expected[index] = 1;
                }
            }
        }
        bool actual = machine_function_mark_reference_batch(instructions, rows, observed, count);
        if (actual != valid || (valid && memcmp(expected, observed, sizeof expected)))
        {
            printf("FAIL %u\n", trial);
            return 1;
        }
    }
    puts("200000 differential batches passed");
    return 0;
}
