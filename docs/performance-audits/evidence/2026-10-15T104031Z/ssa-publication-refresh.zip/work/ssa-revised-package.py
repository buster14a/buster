from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('/home/david/Documents/Codex/2026-10-15/ide/work');repo=root/'buster';stamp='2026-10-15T104031Z';destination=repo/'docs/performance-audits/evidence'/stamp;destination.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
payload={}
for p in sorted(root.glob('ssa-revised*')):
 if p.is_file() and p.suffix in ['.log','.json','.py','.metrics','.txt']:
  payload['work/'+p.name]=p
 elif p.is_dir():
  for x in sorted(p.rglob('*')):
   if x.is_file() and x.suffix in ['.json','.stderr','.stdout','.perf']:
    payload['work/'+str(x.relative_to(root))]=x
for name in ['ssa-analyzer-first-hosted.log','ssa-baseline-compile-commands.json','ssa-baseline-CMakeCache.txt','ssa-candidate-compile-commands.json','ssa-candidate-CMakeCache.txt']:
 p=root/name
 if p.exists():payload['work/'+name]=p
for p in sorted((root/'ssa-publish').glob('*.c')):payload['inputs/'+p.name]=p
for name in ['CMakeCache.txt','compile_commands.json']:
 payload['revised-profile/'+name]=repo/'build/profile'/name
manifest={'revision':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD:src'),'source_unchanged_required_after_freeze':True,'baseline_revision':'84f051c13044938bcb8cbe1ac48ea3ee79defcff','original_evidence':{'audit':'2026-10-15T095552Z.md','archive_sha256':'ffad3507b666d5453fbb872c31f7198013d5b474d2f01f6a5564b39cc79060c3'},'binaries':{n:{'path':str(root/n),'sha256':sha(root/n)} for n in ['ide-ssa-baseline','ide-ssa-candidate','ide-ssa-revised','ide-ssa-revised-census']},'frozen_unity':{'path':str(root/'ssa-frozen-unity.i'),'bytes':(root/'ssa-frozen-unity.i').stat().st_size,'sha256':sha(root/'ssa-frozen-unity.i'),'payload_in_original_evidence':True},'files':{n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in payload.items()}}
archive=destination/'ssa-publication-refresh.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
 for name,p in payload.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
result={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payload)+1,'manifest_revision':manifest['revision'],'source_tree':manifest['source_tree']}
(root/'ssa-revised-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
