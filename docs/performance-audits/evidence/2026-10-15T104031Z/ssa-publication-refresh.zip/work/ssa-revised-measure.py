from pathlib import Path
import subprocess,json
root=Path('/home/david/Documents/Codex/2026-10-15/ide/work')
cells=['unity-fast','unity-quality','fanout-512','fanout-1024','fanout-2048','straight-4096','identity-256','zero-hit']
rows=[]
for name in cells:
 old=json.loads((root/('ssa-counts-'+name)/'summary.json').read_text());args=old['arguments'];args[-1]=str(root/('ssa-revised-measured-'+name+'.out'))
 cmd=['taskset','-c','2',str(root/'ssa-performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--baseline',str(root/'ide-ssa-baseline'),'--candidate',str(root/'ide-ssa-revised'),'--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--candidate-revision','06f5c95527eb75a684693af9d4204a711072c8e7','--out',str(root/('ssa-revised-counts-'+name)),'--runs','6','--events','instructions:u','--min-effect-percent','0.1','--']+args
 with (root/('ssa-revised-counts-'+name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=root/'buster',stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(p.returncode)
 d=json.loads((root/('ssa-revised-counts-'+name)/'summary.json').read_text());assert d['complete'];rows.append({'cell':name,'summary':d});print(name,d['result'],flush=True)
(root/'ssa-revised-work-comparisons.json').write_text(json.dumps(rows,indent=2)+'\n')
