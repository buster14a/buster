from pathlib import Path
import subprocess,json,hashlib
root=Path('/home/david/Documents/Codex/2026-10-15/ide/work');repo=root/'buster';rows=[];parity=[]
for cell in ['fanout-'+str(n) for n in [32,64,128,256,512,1024,2048]]+['straight-4096','identity-256','zero-hit','unity-g0']:
 source=root/'ssa-frozen-unity.i' if cell=='unity-g0' else root/'ssa-publish'/(cell+'.c')
 results={};census={}
 for arm,binary in [('baseline','ide-ssa-baseline'),('revised','ide-ssa-revised'),('census','ide-ssa-revised-census')]:
  obj=root/('ssa-revised-focused-'+cell+'-'+arm+'.o');metrics=root/('ssa-revised-census-'+cell+'.metrics')
  cmd=[str(root/binary),'cc','-g0','-w','-c',str(source),'-o',str(obj)]+(['-fsource-metrics='+str(metrics)] if arm=='census' else [])+(['-march=native'] if cell=='unity-g0' else [])
  with (root/('ssa-revised-focused-'+cell+'-'+arm+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  assert p.returncode==0,(cell,arm,p.returncode)
  results[arm]={'exit':p.returncode,'sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'command':cmd}
  if arm=='census':
   census={k:int(v) for k,v in (line.split('=',1) for line in metrics.read_text().splitlines()) if k.startswith('ir_construction.')}
 assert len({v['sha256'] for v in results.values()})==1,cell
 parity.append({'cell':cell,'arms':results,'identical':True});rows.append({'cell':cell,'exit':0,'counts':census});print(cell,'identical',census.get('ir_construction.ssa_witness_moves'),flush=True)
(root/'ssa-revised-census-focused.json').write_text(json.dumps(rows,indent=2)+'\n')
(root/'ssa-revised-focused-output-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
