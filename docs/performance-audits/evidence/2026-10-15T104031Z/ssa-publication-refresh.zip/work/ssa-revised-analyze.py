import json,shlex,subprocess
from pathlib import Path
root=Path('/home/david/Documents/Codex/2026-10-15/ide/work/buster')
x=next(x for x in json.loads((root/'build/asan/compile_commands.json').read_text()) if x['file'].endswith('/c_gen.c'))
a=shlex.split(x['command']); args=[a[0],'--analyze','-Xanalyzer','-analyzer-output=text','-fno-color-diagnostics','-Wno-error=unused-command-line-argument']; i=1
while i<len(a):
 t=a[i]
 if t in ['-o','-MF','-MJ','-MQ','-MT','--output','-dependency-file']:i+=2;continue
 if t in ['-c','-fcolor-diagnostics','-MD','-MMD','-MP'] or t.startswith('-fsanitize=') or t=='-fno-sanitize-recover=all':i+=1;continue
 t=t.replace('-DBUSTER_SANITIZE=1','-DBUSTER_SANITIZE=0').replace('-DBUSTER_OPTIMIZE=0','-DBUSTER_OPTIMIZE=1');args.append(t);i+=1
args+=['-O3','-DNDEBUG']
(root.parent/'ssa-revised-analyzer-command.json').write_text(json.dumps(args,indent=2)+'\n')
p=subprocess.run(args,cwd=x['directory']);raise SystemExit(p.returncode)
