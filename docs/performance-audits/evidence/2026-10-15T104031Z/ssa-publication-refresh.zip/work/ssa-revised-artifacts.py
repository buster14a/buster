from pathlib import Path
import subprocess,json,hashlib
root=Path('/home/david/Documents/Codex/2026-10-15/ide/work');repo=root/'buster';rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for debug in ['g0','g']:
 for allocator in ['fast','quality']:
  for kind in ['object','executable']:
   arms={}
   for arm,binary in [('baseline','ide-ssa-baseline'),('revised','ide-ssa-revised')]:
    target=root/f'ssa-revised-unity-{debug}-{allocator}-{kind}-{arm}'
    cmd=[str(root/binary),'cc','-'+debug,'-w','-march=native','-fregister-allocator='+allocator]+(['-c'] if kind=='object' else [])+[str(root/'ssa-frozen-unity.i')]+(['-lm'] if kind=='executable' else [])+['-o',str(target)]
    with Path(str(target)+'.log').open('w') as log:p=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
    assert p.returncode==0,(arm,debug,allocator,kind,p.returncode)
    arms[arm]={'command':cmd,'exit':p.returncode,'sha256':sha(target),'bytes':target.stat().st_size}
   same=arms['baseline']['sha256']==arms['revised']['sha256'];rows.append({'debug':debug,'allocator':allocator,'kind':kind,'arms':arms,'identical':same});print(debug,allocator,kind,same,flush=True)
   assert same
(root/'ssa-revised-unity-output-parity.json').write_text(json.dumps(rows,indent=2)+'\n')
