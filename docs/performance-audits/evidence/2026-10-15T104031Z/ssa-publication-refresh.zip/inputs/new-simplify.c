// Two distinct non-self roots witness that a parameter cannot simplify.
// Watch their union groups, not each intermediate canonical representative.
// Union by rank moves each live witness only through logarithmically many
// groups; requeue only when the witnesses meet or one becomes the reader.
BUSTER_C_INTERNAL void c_ir_ssa_unwatch(u32* first, CIrSsaUser* users, u32 reader)
{
    for (u32 index = reader * 2; index < reader * 2 + 2; index += 1)
    {
        CIrSsaUser* user = users + index;
        if (user->root != UINT32_MAX)
        {
            if (user->previous == UINT32_MAX)
            {
                first[user->root] = user->next;
            }
            else
            {
                users[user->previous].next = user->next;
            }
            if (user->next != UINT32_MAX)
            {
                users[user->next].previous = user->previous;
            }
            user->root = UINT32_MAX;
        }
    }
}

BUSTER_C_INTERNAL void c_ir_ssa_retry_witness(u32* first, CIrSsaUser* users, u64* heap, u32* heap_count,
                                             u32 reader, u32 here, u64 sweep)
{
    c_ir_ssa_unwatch(first, users, reader);
    u64 due = reader > here ? sweep : sweep + 1;
    c_ir_ssa_retry_push(heap, heap_count, due << 32 | reader);
}

BUSTER_C_INTERNAL void c_ir_ssa_simplify_parameters_new(CIntegerIrBuilder* builder, u8* memory, u32* replacements,
                                                    CIrSsaParameter** pending_by_value, IrBlockParameter** parameter_by_value,
                                                    u32* cursor, u32 active_block_count)
{
    CIrDirectSsa* ssa = builder->direct_ssa;
    IrFunction* function = builder->function;
    u32 count = function->value_count;
    u32 parameter_count = 0;
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
        {
            CIrSsaParameter* pending = pending_by_value[parameter->value.value];
            parameter_count += (!pending || !memory[pending->local]) && replacements[parameter->value.value] == parameter->value.value;
        }
    }
    if (parameter_count)
    {
        u32* first = arena_allocate(builder->scratch_arena, u32, count);
        u32* groups = arena_allocate(builder->scratch_arena, u32, count);
        u32* position = arena_allocate(builder->scratch_arena, u32, count);
        u8* rank = arena_allocate(builder->scratch_arena, u8, count);
        u32* order = arena_allocate(builder->scratch_arena, u32, parameter_count);
        u64* heap = arena_allocate(builder->scratch_arena, u64, parameter_count);
        CIrSsaUser* users = arena_allocate(builder->scratch_arena, CIrSsaUser, (u64)parameter_count * 2);
        memset(first, 0xff, sizeof(*first) * count);
        memset(rank, 0, count);
        memset(parameter_by_value, 0, sizeof(*parameter_by_value) * count);
        for (u32 value = 0; value < count; value += 1)
        {
            groups[value] = value;
        }
        for (u32 index = 0; index < parameter_count * 2; index += 1)
        {
            users[index].root = UINT32_MAX;
        }
        u32 heap_count = 0;
        for (u32 active = 0; active < active_block_count; active += 1)
        {
            for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
            {
                u32 value = parameter->value.value;
                CIrSsaParameter* pending = pending_by_value[value];
                if ((!pending || !memory[pending->local]) && replacements[value] == value)
                {
                    parameter_by_value[value] = parameter;
                    position[value] = heap_count;
                    order[heap_count] = value;
                    heap[heap_count] = heap_count;
                    heap_count += 1;
                }
            }
        }
        while (heap_count)
        {
            u64 key = c_ir_ssa_retry_pop(heap, &heap_count);
            u64 sweep = key >> 32;
            u32 here = (u32)key;
            u32 value = order[here];
            IrBlockParameter* parameter = parameter_by_value[value];
            u32 same = UINT32_MAX;
            u32 other = UINT32_MAX;
            bool trivial = true;
            u32 dead_same = UINT32_MAX;
            u32 dead_other = UINT32_MAX;
            bool dead_trivial = true;
            for (IrIncoming* incoming = parameter->first_incoming; incoming && trivial; incoming = incoming->next)
            {
                u32 root = c_ir_ssa_root(replacements, incoming->value.value);
                bool runs = ssa->reachable[incoming->predecessor.value] != 0;
                if (root != value && runs)
                {
                    if (same == UINT32_MAX)
                    {
                        same = root;
                    }
                    else if (same != root)
                    {
                        trivial = false;
                        other = root;
                    }
                }
                else if (root != value)
                {
                    if (dead_same == UINT32_MAX)
                    {
                        dead_same = root;
                    }
                    else if (dead_same != root)
                    {
                        dead_trivial = false;
                        dead_other = root;
                    }
                }
            }
            if (trivial && same == UINT32_MAX)
            {
                trivial = dead_trivial;
                same = dead_same;
                other = dead_other;
            }
            if (trivial && same != UINT32_MAX)
            {
                replacements[value] = same;
                u32 kept = c_ir_ssa_root(groups, value);
                u32 moved = c_ir_ssa_root(groups, same);
                if (rank[kept] < rank[moved])
                {
                    u32 swap = kept;
                    kept = moved;
                    moved = swap;
                }
                if (rank[kept] == rank[moved])
                {
                    rank[kept] += 1;
                }
                groups[moved] = kept;
                while (first[moved] != UINT32_MAX)
                {
                    replay_user_visits += 1;
                    u32 user = first[moved];
                    u32 reader = user / 2;
                    u32 next = users[user].next;
                    first[moved] = next;
                    if (next != UINT32_MAX)
                    {
                        users[next].previous = UINT32_MAX;
                    }
                    users[user].root = kept;
                    users[user].previous = UINT32_MAX;
                    users[user].next = first[kept];
                    if (first[kept] != UINT32_MAX)
                    {
                        users[first[kept]].previous = user;
                    }
                    first[kept] = user;
                    if (c_ir_ssa_root(groups, users[user ^ 1].root) == kept)
                    {
                        c_ir_ssa_retry_witness(first, users, heap, &heap_count, reader, here, sweep);
                    }
                }
                // `same` now reads itself if one of its witnesses joined its
                // own group. It can sit in the kept list, which did not move.
                if (parameter_by_value[same])
                {
                    u32 reader = position[same];
                    if (users[reader * 2].root != UINT32_MAX &&
                        (users[reader * 2].root == kept || users[reader * 2 + 1].root == kept))
                    {
                        c_ir_ssa_retry_witness(first, users, heap, &heap_count, reader, here, sweep);
                    }
                }
            }
            else if (!trivial)
            {
                u32 roots[2] = {same, other};
                for (u32 witness = 0; witness < 2; witness += 1)
                {
                    u32 root = c_ir_ssa_root(groups, roots[witness]);
                    u32 user = here * 2 + witness;
                    users[user] = (CIrSsaUser){.root = root, .previous = UINT32_MAX, .next = first[root]};
                    if (first[root] != UINT32_MAX)
                    {
                        users[first[root]].previous = user;
                    }
                    first[root] = user;
                }
            }
        }
    }
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        IrBlock* destination = function->blocks + cursor[active];
        IrBlockParameter** link = &destination->first_parameter;
        destination->last_parameter = 0;
        while (*link)
        {
            IrBlockParameter* parameter = *link;
            CIrSsaParameter* pending = pending_by_value[parameter->value.value];
            if ((pending && memory[pending->local]) || replacements[parameter->value.value] != parameter->value.value)
            {
                *link = parameter->next;
                destination->parameter_count -= 1;
                ssa->statistics.parameters_removed += 1;
            }
            else
            {
                destination->last_parameter = parameter;
                link = &parameter->next;
            }
        }
    }
}
