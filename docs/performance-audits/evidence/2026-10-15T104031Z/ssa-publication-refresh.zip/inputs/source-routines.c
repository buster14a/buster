BUSTER_C_INTERNAL u32 c_ir_ssa_root(u32* replacements, u32 value)
{
    u32 root = value;
    while (replacements[root] != root)
    {
        root = replacements[root];
    }
    while (replacements[value] != value)
    {
        u32 next = replacements[value];
        replacements[value] = root;
        value = next;
    }
    return root;
}

BUSTER_C_INTERNAL void c_ir_ssa_retry_push(u64* heap, u32* heap_count, u64 key)
{
    u32 index = (*heap_count)++;
    while (index && heap[(index - 1) / 2] > key)
    {
        heap[index] = heap[(index - 1) / 2];
        index = (index - 1) / 2;
    }
    heap[index] = key;
}

BUSTER_C_INTERNAL u64 c_ir_ssa_retry_pop(u64* heap, u32* heap_count)
{
    u64 result = heap[0];
    u32 count = --(*heap_count);
    u64 key = heap[count];
    u32 index = 0;
    bool sifting = count != 0;
    while (sifting)
    {
        u32 child = index * 2 + 1;
        if (child + 1 < count && heap[child + 1] < heap[child])
        {
            child += 1;
        }
        sifting = child < count && heap[child] < key;
        if (sifting)
        {
            heap[index] = heap[child];
            index = child;
        }
    }
    if (count)
    {
        heap[index] = key;
    }
    return result;
}

BUSTER_C_INTERNAL void c_ir_ssa_simplify_parameters(CIntegerIrBuilder* builder, u8* memory, u32* replacements,
                                                    CIrSsaParameter** pending_by_value, IrBlockParameter** parameter_by_value,
                                                    u32* cursor, u32 active_block_count)
{
    CIrDirectSsa* ssa = builder->direct_ssa;
    IrFunction* function = builder->function;
    u32 count = function->value_count;
    u32* user_first = arena_allocate(builder->scratch_arena, u32, count);
    u32* user_last = arena_allocate(builder->scratch_arena, u32, count);
    u32* order = arena_allocate(builder->scratch_arena, u32, count);
    u32* position = arena_allocate(builder->scratch_arena, u32, count);
    u64* heap = arena_allocate(builder->scratch_arena, u64, count);
    u8* queued = arena_allocate(builder->scratch_arena, u8, count);
    u64 user_capacity = 0;
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
        {
            user_capacity += parameter->incoming_count;
        }
    }
    CIrSsaUser* users = arena_allocate(builder->scratch_arena, CIrSsaUser, user_capacity ? user_capacity : 1);
    memset(user_first, 0xff, sizeof(*user_first) * count);
    memset(queued, 0, count);
    memset(parameter_by_value, 0, sizeof(*parameter_by_value) * count);
    IR_CONSTRUCTION_RECORD(SSA_VALUE_SCRATCH_BYTES, (sizeof(*user_first) * 4 + sizeof(*heap) + sizeof(*queued)) * (u64)count +
                                                    sizeof(*users) * user_capacity);
    IR_CONSTRUCTION_RECORD(SSA_VALUE_CLEAR_BYTES, (sizeof(*user_first) + sizeof(*queued) + sizeof(*parameter_by_value)) * (u64)count);
    // Number every retained parameter in sweep order, due in sweep zero, and
    // file each incoming row under the root it currently reads. Ascending
    // keys already form a valid heap.
    u32 user_count = 0;
    u32 heap_count = 0;
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
        {
            u32 value = parameter->value.value;
            CIrSsaParameter* pending = pending_by_value[value];
            if ((!pending || !memory[pending->local]) && replacements[value] == value)
            {
                parameter_by_value[value] = parameter;
                position[value] = heap_count;
                order[heap_count] = value;
                heap[heap_count] = heap_count;
                heap_count += 1;
                queued[value] = 1;
                for (IrIncoming* incoming = parameter->first_incoming; incoming; incoming = incoming->next)
                {
                    u32 root = c_ir_ssa_root(replacements, incoming->value.value);
                    if (root != value)
                    {
                        users[user_count] = (CIrSsaUser){.parameter = value, .next = UINT32_MAX};
                        if (user_first[root] == UINT32_MAX)
                        {
                            user_first[root] = user_count;
                        }
                        else
                        {
                            users[user_last[root]].next = user_count;
                        }
                        user_last[root] = user_count;
                        user_count += 1;
                    }
                }
            }
        }
    }
#if BUSTER_BENCH_ALLOCATIONS
    // The census counts the sweeps the full block-order sweep would take.
    u64 sweeps = heap_count != 0;
#endif
    while (heap_count)
    {
        u64 key = c_ir_ssa_retry_pop(heap, &heap_count);
        u64 sweep = key >> 32;
        u32 here = (u32)key;
        u32 value = order[here];
        queued[value] = 0;
#if BUSTER_BENCH_ALLOCATIONS
        sweeps = BUSTER_MAX(sweeps, sweep + 1);
#endif
        IrBlockParameter* parameter = parameter_by_value[value];
        IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_PARAMETER_VISITS, 1);
        // An edge out of an unreachable block never runs, so the
        // value it carries cannot reach the parameter: when every
        // edge that can run carries one value, the parameter is
        // that value. A compound statement that ends in `break`,
        // `goto` or `return` leaves its continuation block without
        // predecessors, and the next `case` or label still gets an
        // edge from it, whose value is an unfilled parameter of the
        // dead block. Counting it would keep a merge of every
        // variable read after that label -- and of everything
        // downstream -- alive. With no runnable edge carrying a
        // value, only the dead ones decide, as they always did:
        // every dead root must agree, so the first mismatch is
        // final and a later repeat cannot restore triviality.
        u32 same = UINT32_MAX;
        bool trivial = true;
        u32 dead_same = UINT32_MAX;
        bool dead_trivial = true;
        for (IrIncoming* incoming = parameter->first_incoming; incoming && trivial; incoming = incoming->next)
        {
            IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_INCOMING_VISITS, 1);
            u32 root = c_ir_ssa_root(replacements, incoming->value.value);
            bool runs = ssa->reachable[incoming->predecessor.value] != 0;
            if (root != value && runs)
            {
                trivial = same == UINT32_MAX || root == same;
                same = root;
            }
            else if (root != value)
            {
                dead_trivial = dead_trivial && (dead_same == UINT32_MAX || root == dead_same);
                dead_same = root;
            }
        }
        if (trivial && same == UINT32_MAX)
        {
            trivial = dead_trivial;
            same = dead_same;
        }
        if (trivial && same != UINT32_MAX)
        {
            replacements[value] = same;
            // Every parameter reading this one now reads `same`. The full
            // sweep reaches a later position in this sweep, an earlier one
            // in the next. Move the rows to `same` for its own replacement,
            // minus those that can never requeue again: a replaced reader
            // stays replaced, and `same` now reads itself. Carrying them
            // would grow each list along a chain of trivial loop-header
            // parameters, making N nested loops cost N^3 (#3723).
            u32 kept_first = UINT32_MAX;
            u32 kept_last = UINT32_MAX;
            u32 user = user_first[value];
            while (user != UINT32_MAX)
            {
                u32 next = users[user].next;
                u32 reader = users[user].parameter;
                if (replacements[reader] == reader)
                {
                    if (!queued[reader])
                    {
                        queued[reader] = 1;
                        u64 due = position[reader] > here ? sweep : sweep + 1;
                        c_ir_ssa_retry_push(heap, &heap_count, due << 32 | position[reader]);
                    }
                    if (reader != same)
                    {
                        users[user].next = UINT32_MAX;
                        if (kept_first == UINT32_MAX)
                        {
                            kept_first = user;
                        }
                        else
                        {
                            users[kept_last].next = user;
                        }
                        kept_last = user;
                    }
                }
                user = next;
            }
            user_first[value] = UINT32_MAX;
            if (kept_first != UINT32_MAX)
            {
                if (user_first[same] == UINT32_MAX)
                {
                    user_first[same] = kept_first;
                }
                else
                {
                    users[user_last[same]].next = kept_first;
                }
                user_last[same] = kept_last;
            }
        }
    }
#if BUSTER_BENCH_ALLOCATIONS
    IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_PASSES, sweeps);
#endif
    // Unlink every replaced or memory-owned parameter in one final sweep, the
    // one block visit simplification makes; numbering above reads the same rows.
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_BLOCK_VISITS, 1);
        IrBlock* destination = function->blocks + cursor[active];
        IrBlockParameter** link = &destination->first_parameter;
        destination->last_parameter = 0;
        while (*link)
        {
            IrBlockParameter* parameter = *link;
            CIrSsaParameter* pending = pending_by_value[parameter->value.value];
            if ((pending && memory[pending->local]) || replacements[parameter->value.value] != parameter->value.value)
            {
                *link = parameter->next;
                destination->parameter_count -= 1;
                ssa->statistics.parameters_removed += 1;
            }
            else
            {
                destination->last_parameter = parameter;
                link = &parameter->next;
            }
        }
    }
}
