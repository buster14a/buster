#if BUSTER_INCLUDE_TESTS
// The repeated ordered sweep is an independent oracle for witness scheduling.
// It has no user lists, union groups or retry heap.
BUSTER_C_INTERNAL void c_test_ir_ssa_sweep(CIntegerIrBuilder* builder, u8* memory, u32* replacements,
                                         CIrSsaParameter** pending)
{
    bool changed = true;
    while (changed)
    {
        changed = false;
        for (IrBlockParameter* parameter = builder->function->blocks[0].first_parameter; parameter; parameter = parameter->next)
        {
            u32 value = parameter->value.value;
            if ((!pending[value] || !memory[pending[value]->local]) && replacements[value] == value)
            {
                u32 same = UINT32_MAX;
                u32 dead_same = UINT32_MAX;
                bool trivial = true;
                bool dead_trivial = true;
                for (IrIncoming* incoming = parameter->first_incoming; incoming && trivial; incoming = incoming->next)
                {
                    u32 root = c_ir_ssa_root(replacements, incoming->value.value);
                    if (root != value && builder->direct_ssa->reachable[incoming->predecessor.value])
                    {
                        trivial = same == UINT32_MAX || same == root;
                        same = root;
                    }
                    else if (root != value)
                    {
                        dead_trivial = dead_trivial && (dead_same == UINT32_MAX || dead_same == root);
                        dead_same = root;
                    }
                }
                if (trivial && same == UINT32_MAX)
                {
                    trivial = dead_trivial;
                    same = dead_same;
                }
                if (trivial && same != UINT32_MAX)
                {
                    replacements[value] = same;
                    changed = true;
                }
            }
        }
    }
}

BUSTER_C_INTERNAL u32 c_test_ir_ssa_random(u32* state)
{
    *state ^= *state << 13;
    *state ^= *state >> 17;
    *state ^= *state << 5;
    return *state;
}

bool c_test_ir_ssa_witness_graph(u32 seed)
{
    u32 state = seed;
    u32 parameter_count = 1 + c_test_ir_ssa_random(&state) % 24;
    u32 count = parameter_count + 3;
    u8 reachable[2] = {(u8)(c_test_ir_ssa_random(&state) & 1), (u8)(c_test_ir_ssa_random(&state) & 1)};
    u8 memory[24];
    CIrSsaParameter pending_rows[24];
    CIrSsaParameter* pending[27] = {0};
    u32 initial[27];
    u32 incoming_count[24];
    u32 incoming_values[24][5];
    u32 incoming_blocks[24][5];
    for (u32 value = 0; value < count; value += 1)
    {
        initial[value] = value;
    }
    for (u32 value = 0; value < parameter_count; value += 1)
    {
        memory[value] = (u8)(c_test_ir_ssa_random(&state) % 8 == 0);
        pending_rows[value] = (CIrSsaParameter){.local = value};
        pending[value] = c_test_ir_ssa_random(&state) & 1 ? pending_rows + value : 0;
        if (c_test_ir_ssa_random(&state) % 12 == 0)
        {
            initial[value] = parameter_count + c_test_ir_ssa_random(&state) % 3;
        }
        incoming_count[value] = c_test_ir_ssa_random(&state) % 6;
        for (u32 index = 0; index < incoming_count[value]; index += 1)
        {
            incoming_values[value][index] = c_test_ir_ssa_random(&state) % count;
            incoming_blocks[value][index] = c_test_ir_ssa_random(&state) & 1;
        }
    }
    u32 roots[2][27];
    u32 survivors[2][24];
    u32 retained[2] = {0};
    Arena* scratch = arena_create((ArenaCreation){0});
    for (u32 arm = 0; arm < 2; arm += 1)
    {
        arena_set_position(scratch, arena_minimum_position);
        IrBlockParameter parameters[24] = {0};
        IrIncoming incoming[24][5] = {0};
        IrBlockParameter* by_value[27] = {0};
        u32 replacements[27];
        memcpy(replacements, initial, sizeof(u32) * count);
        IrBlock block = {.first_parameter = parameters, .last_parameter = parameters + parameter_count - 1, .parameter_count = parameter_count};
        IrFunction function = {.blocks = &block, .value_count = count};
        CIrDirectSsa ssa = {.reachable = reachable};
        CIntegerIrBuilder builder = {.function = &function, .direct_ssa = &ssa, .scratch_arena = scratch};
        for (u32 value = 0; value < parameter_count; value += 1)
        {
            parameters[value] = (IrBlockParameter){.value = {.value = value}, .incoming_count = incoming_count[value],
                .next = value + 1 < parameter_count ? parameters + value + 1 : 0,
                .first_incoming = incoming_count[value] ? incoming[value] : 0,
                .last_incoming = incoming_count[value] ? incoming[value] + incoming_count[value] - 1 : 0};
            for (u32 index = 0; index < incoming_count[value]; index += 1)
            {
                incoming[value][index] = (IrIncoming){.value = {.value = incoming_values[value][index]},
                    .predecessor = {.value = incoming_blocks[value][index]},
                    .next = index + 1 < incoming_count[value] ? incoming[value] + index + 1 : 0};
            }
        }
        if (arm)
        {
            c_ir_ssa_simplify_parameters(&builder, memory, replacements, pending, by_value, (u32[]){0}, 1);
        }
        else
        {
            c_test_ir_ssa_sweep(&builder, memory, replacements, pending);
        }
        for (u32 value = 0; value < count; value += 1)
        {
            roots[arm][value] = c_ir_ssa_root(replacements, value);
        }
        for (IrBlockParameter* parameter = block.first_parameter; parameter; parameter = parameter->next)
        {
            u32 value = parameter->value.value;
            if ((!pending[value] || !memory[pending[value]->local]) && replacements[value] == value)
            {
                survivors[arm][retained[arm]++] = value;
            }
        }
    }
    bool valid = !memcmp(roots[0], roots[1], sizeof(u32) * count) && retained[0] == retained[1] &&
                 !memcmp(survivors[0], survivors[1], sizeof(u32) * retained[0]);
    arena_destroy(scratch, 1);
    return valid;
}

// Exercise the complete publication boundary with shared old operands, both
// identity and shifted IDs, parameter-free CFG edges, dirty reuse and refusal.
bool c_test_ir_ssa_publication(void)
{
    Arena* output = arena_create((ArenaCreation){0});
    Arena* scratch = arena_create((ArenaCreation){0});
    bool valid = true;
    for (u32 shape = 0; shape < 4; shape += 1)
    {
        arena_set_position(output, arena_minimum_position);
        arena_set_position(scratch, arena_minimum_position);
        bool shifted = shape == 1;
        bool refuse = shape == 3;
        u32 first = shifted ? 1 : 0;
        IrValue values[4] = {0};
        IrValueId shared[2] = {{.value = first}, {.value = first}};
        IrInstruction instructions[3] = {
            {.result = {.value = first}},
            {.result = {.value = first + 1}, .operand_count = 2, .operands = shared},
            {.result = {.value = first + 2}, .operand_count = 2, .operands = shared},
        };
        IrBlock blocks[3] = {0};
        IrFunction function = {.values = values, .value_count = first + 3, .instructions = instructions,
            .instruction_count = 3, .blocks = blocks, .block_count = 3};
        u32 offsets[4] = {0, 0, 1, 2};
        u32 predecessors[2] = {0, 1};
        u32 cursor[3];
        u8 reachable[3] = {1, 1, 1};
        CIrDirectSsa ssa = {.predecessor_offsets = offsets, .predecessors = predecessors,
            .read_blocks = cursor, .reachable = reachable};
        CIntegerIrBuilder builder = {.function = &function, .direct_ssa = &ssa, .arena = output, .scratch_arena = scratch};
        CIRDirectSsaStatistics statistics = {0};
        u64 reservation = output->reserved_size;
        if (refuse)
        {
            output->reserved_size = output->position + sizeof(IrPredecessor) * 2 - 1;
        }
        bool published = c_ir_ssa_finish_publish(&builder, 0, &statistics);
        output->reserved_size = reservation;
        valid = valid && published != refuse && function.value_count == 3 && function.operand_total == 4;
        if (!refuse)
        {
            valid = valid && blocks[0].sealed && blocks[1].sealed && blocks[2].sealed &&
                    blocks[1].predecessor_count == 1 && blocks[2].predecessor_count == 1 &&
                    blocks[1].first_predecessor->block.value == 0 && blocks[2].first_predecessor->block.value == 1 &&
                    !blocks[1].last_predecessor->next && !blocks[2].last_predecessor->next;
            valid = valid && instructions[1].operands[0].value == 0 && instructions[2].operands[1].value == 0 && shared[0].value == first;
            valid = valid && (shifted ? instructions[1].operands != instructions[2].operands
                                     : instructions[1].operands == shared && instructions[2].operands == shared);
        }
        else
        {
            valid = valid && ssa.scratch_exhausted && builder.failure_message.length && output->position == arena_minimum_position;
        }
    }
    arena_destroy(scratch, 1);
    arena_destroy(output, 1);
    return valid;
}
#endif
