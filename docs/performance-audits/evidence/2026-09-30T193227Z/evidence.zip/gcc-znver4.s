	.file	"probe.c"
	.text
	.p2align 4
	.type	probe_rows_bytes, @function
probe_rows_bytes:
.LFB7340:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	vmovdqu64	(%r8), %zmm3
	vmovdqu64	(%r9), %zmm0
	kmovq	probe_byte_masks(%rip), %k1
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	kmovq	8+probe_byte_masks(%rip), %k2
	kmovq	16+probe_byte_masks(%rip), %k3
	kmovq	%rdx, %k4
	movq	16(%rbp), %rax
	vmovdqu64	(%rcx), %zmm1
	vmovdqu64	(%rax), %zmm2
	movq	24(%rbp), %rax
	vpmovzxbd	%xmm3, %zmm3
	vpmovzxbd	%xmm0, %zmm0
	vpmovzxbd	%xmm1, %zmm1
	vpslld	$16, %zmm0, %zmm0
	vpaddd	32(%rbp){1to16}, %zmm1, %zmm1
	vpmovzxbd	%xmm2, %zmm2
	vpslld	$24, %zmm2, %zmm2
	vpternlogd	$254, %zmm2, %zmm3, %zmm0
	vmovdqu64	probe_byte_indices(%rip), %zmm2
	vpermi2b	%zmm0, %zmm1, %zmm2{%k1}{z}
	vmovdqu64	%zmm2, (%rdi)
	vmovdqu64	64+probe_byte_indices(%rip), %zmm2
	vpermi2b	%zmm0, %zmm1, %zmm2{%k2}{z}
	vmovdqu64	%zmm2, 64(%rdi)
	vmovdqu64	128+probe_byte_indices(%rip), %zmm2
	vpermt2b	%zmm0, %zmm2, %zmm1{%k3}{z}
	vmovdqu64	%zmm1, 128(%rdi)
	vmovdqu64	(%rax), %zmm0
	vmovdqu8	%zmm0, (%rsi){%k4}
	vzeroupper
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7340:
	.size	probe_rows_bytes, .-probe_rows_bytes
	.p2align 4
	.type	probe_rows_dwords, @function
probe_rows_dwords:
.LFB7341:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	vpmovzxbd	(%r8), %zmm3
	vpmovzxbd	(%r9), %zmm2
	kmovw	.LC3(%rip), %k1
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	kmovw	.LC4(%rip), %k2
	kmovw	.LC5(%rip), %k3
	kmovq	%rdx, %k4
	movq	16(%rbp), %rax
	vpmovzxbd	(%rcx), %zmm1
	vpmovzxbd	(%rax), %zmm0
	movq	24(%rbp), %rax
	vpslld	$16, %zmm2, %zmm2
	vpaddd	32(%rbp){1to16}, %zmm1, %zmm1
	vpslld	$24, %zmm0, %zmm0
	vpternlogd	$254, %zmm3, %zmm2, %zmm0
	vmovdqa32	.LC0(%rip), %zmm2
	vpermi2d	%zmm0, %zmm1, %zmm2{%k1}{z}
	vmovdqu64	%zmm2, (%rdi)
	vmovdqa32	.LC1(%rip), %zmm2
	vpermi2d	%zmm0, %zmm1, %zmm2{%k2}{z}
	vmovdqu64	%zmm2, 64(%rdi)
	vmovdqa32	.LC2(%rip), %zmm2
	vpermt2d	%zmm0, %zmm2, %zmm1{%k3}{z}
	vmovdqu64	%zmm1, 128(%rdi)
	vmovdqu64	(%rax), %zmm0
	vmovdqu8	%zmm0, (%rsi){%k4}
	vzeroupper
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7341:
	.size	probe_rows_dwords, .-probe_rows_dwords
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC16:
	.string	"PROBE full=%u base=%u fixtures=30720 comparisons=%u failures=%u\n"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB7343:
	.cfi_startproc
	endbr64
	leaq	8(%rsp), %r10
	.cfi_def_cfa 10, 0
	andq	$-64, %rsp
	leaq	probe_byte_indices(%rip), %rdi
	xorl	%edx, %edx
	pushq	-8(%r10)
	pushq	%rbp
	leaq	probe_byte_masks(%rip), %r11
	movq	%rsp, %rbp
	.cfi_escape 0x10,0x6,0x2,0x76,0
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%r10
	.cfi_escape 0xf,0x3,0x76,0x58,0x6
	.cfi_escape 0x10,0xf,0x2,0x76,0x78
	.cfi_escape 0x10,0xe,0x2,0x76,0x70
	.cfi_escape 0x10,0xd,0x2,0x76,0x68
	.cfi_escape 0x10,0xc,0x2,0x76,0x60
	pushq	%rbx
	leaq	probe_word_masks(%rip), %r12
	subq	$1024, %rsp
	.cfi_escape 0x10,0x3,0x2,0x76,0x50
	vmovdqa	.LC6(%rip), %xmm0
	leaq	probe_word_indices(%rip), %rbx
	movq	%fs:40, %rax
	movq	%rax, -56(%rbp)
	xorl	%eax, %eax
	movq	$-16, -1024(%rbp)
	vmovdqa	%xmm0, -1040(%rbp)
.L7:
	movl	(%r12,%rax,4), %r8d
	movl	%eax, %r9d
	movl	$1, %ecx
	sall	$2, %edx
	movb	%dl, (%rdi)
	movl	%r8d, %esi
	andl	$1, %esi
	orq	(%r11,%rax,8), %rsi
	salq	$4, %r9
.L8:
	movl	%ecx, %edx
	movl	%ecx, %r13d
	shrl	$2, %edx
	movl	%edx, %r10d
	andl	$3, %r13d
	shrx	%edx, %r8d, %edx
	andl	$1, %edx
	addq	%r9, %r10
	shlx	%rcx, %rdx, %rdx
	orq	%rdx, %rsi
	movl	(%rbx,%r10,4), %r10d
	leal	0(%r13,%r10,4), %r10d
	movb	%r10b, (%rdi,%rcx)
	incq	%rcx
	cmpq	$64, %rcx
	jne	.L8
	movq	%rsi, (%r11,%rax,8)
	incq	%rax
	cmpq	$3, %rax
	je	.L28
	movq	%rax, %rdx
	addq	$64, %rdi
	salq	$6, %rdx
	movl	(%rbx,%rdx), %edx
	jmp	.L7
.L28:
	vmovdqa64	.LC8(%rip), %zmm24
	vmovdqa64	.LC9(%rip), %zmm25
	leaq	-1040(%rbp), %rax
	movl	$0, -1044(%rbp)
	xorl	%r10d, %r10d
	leaq	-1008(%rbp), %r12
	leaq	-768(%rbp), %r14
	vmovdqa32	.LC12(%rip), %xmm30
	vmovdqa32	.LC13(%rip), %xmm29
	leaq	-208(%rbp), %r11
	leaq	-128(%rbp), %r15
	vmovdqa32	.LC14(%rip), %xmm28
	vmovdqa32	.LC15(%rip), %xmm27
	leaq	-427(%rbp), %r9
	leaq	-493(%rbp), %r8
	leaq	-127(%rbp), %rsi
	leaq	-764(%rbp), %rdi
	vmovq	%rax, %xmm31
	leaq	-559(%rbp), %rax
	vmovq	%rax, %xmm23
	leaq	-295(%rbp), %rax
	vmovq	%rax, %xmm21
	leaq	-361(%rbp), %rax
	vmovq	%rax, %xmm16
.L9:
	vpbroadcastb	%r10d, %zmm4
	leaq	-560(%rbp), %rax
	movl	$1, %edx
	vpunpcklbw	%zmm24, %zmm24, %zmm3
	vpunpckhbw	%zmm24, %zmm24, %zmm2
.L10:
	vpbroadcastb	%edx, %zmm0
	addl	$2, %edx
	addq	$66, %rax
	vpunpcklbw	%zmm0, %zmm0, %zmm1
	vpunpckhbw	%zmm0, %zmm0, %zmm0
	vpmullw	%zmm0, %zmm2, %zmm0
	vpmullw	%zmm1, %zmm3, %zmm1
	vpermt2b	%zmm0, %zmm25, %zmm1
	vpaddb	%zmm4, %zmm1, %zmm0
	vmovdqu8	%zmm0, -65(%rax)
	cmpb	$11, %dl
	jne	.L10
	movq	$0, -1056(%rbp)
.L11:
	movl	$1515870810, %eax
	movl	%r10d, -1048(%rbp)
	xorl	%r13d, %r13d
	vpbroadcastd	%eax, %zmm26
	movl	$-1515870811, %eax
	vpbroadcastd	%eax, %zmm19
	.p2align 4
	.p2align 3
.L24:
	cmpl	$16, %r13d
	ja	.L12
	movl	$1, %r10d
	shlx	%r13, %r10, %r10
	decq	%r10
.L13:
	vmovdqu8	-559(%rbp), %xmm0
	movq	-1056(%rbp), %rbx
	movabsq	$6510615555426900570, %rax
	vmovdqu8	-361(%rbp), %xmm3
	movq	%rax, 192(%r12)
	movq	%rax, 192(%r14)
	movw	$-23131, 64(%r11)
	leaq	-295(%rbp), %rcx
	vmovq	%xmm31, %rax
	vmovdqa64	%zmm26, (%r12)
	movw	$-23131, 64(%r15)
	leaq	-207(%rbp), %rdx
	vmovdqu8	%zmm26, (%r14)
	vmovdqu8	%zmm26, 64(%r14)
	movl	(%rax,%rbx,4), %ebx
	vmovdqu8	%zmm26, 128(%r14)
	xorl	%eax, %eax
	vpmovzxbw	%xmm0, %xmm1
	vpsrldq	$8, %xmm0, %xmm0
	vpmovzxbw	%xmm0, %xmm0
	vpmovzxwd	%xmm1, %xmm9
	vpsrldq	$8, %xmm1, %xmm4
	vpmovzxwd	%xmm0, %xmm8
	vpsrldq	$8, %xmm0, %xmm1
	vmovdqu8	-493(%rbp), %xmm0
	vpmovzxwd	%xmm4, %xmm4
	vpmovzxwd	%xmm1, %xmm1
	vpbroadcastd	%ebx, %xmm2
	vpmovzxbw	%xmm3, %xmm7
	vpsrldq	$8, %xmm3, %xmm3
	vpaddd	%xmm2, %xmm9, %xmm9
	vpaddd	%xmm2, %xmm4, %xmm4
	vpaddd	%xmm2, %xmm8, %xmm8
	vpaddd	%xmm2, %xmm1, %xmm1
	vpmovzxbw	%xmm3, %xmm3
	vpmovzxwd	%xmm7, %xmm11
	vpsrldq	$8, %xmm7, %xmm7
	vpmovzxwd	%xmm7, %xmm7
	vpslld	$24, %xmm11, %xmm11
	vmovdqu8	%zmm19, (%r11)
	vpmovzxbw	%xmm0, %xmm10
	vpsrldq	$8, %xmm0, %xmm0
	vpslld	$24, %xmm7, %xmm7
	vpmovzxbw	%xmm0, %xmm5
	vmovdqu8	-427(%rbp), %xmm0
	vpmovzxwd	%xmm10, %xmm12
	vpsrldq	$8, %xmm10, %xmm10
	vpmovzxwd	%xmm10, %xmm10
	vmovdqu8	%zmm19, (%r15)
	vpmovzxbw	%xmm0, %xmm2
	vpsrldq	$8, %xmm0, %xmm0
	vpmovzxbw	%xmm0, %xmm0
	vpmovzxwd	%xmm2, %xmm6
	vpsrldq	$8, %xmm2, %xmm2
	vpmovzxwd	%xmm2, %xmm2
	vpslld	$16, %xmm6, %xmm6
	vpslld	$16, %xmm2, %xmm2
	vpternlogd	$254, %xmm12, %xmm11, %xmm6
	vpternlogd	$254, %xmm10, %xmm7, %xmm2
	vpmovzxwd	%xmm5, %xmm11
	vpmovzxwd	%xmm0, %xmm7
	vpsrldq	$8, %xmm5, %xmm5
	vpsrldq	$8, %xmm0, %xmm0
	vpmovzxwd	%xmm3, %xmm10
	vpmovzxwd	%xmm5, %xmm5
	vpsrldq	$8, %xmm3, %xmm3
	vpslld	$16, %xmm7, %xmm7
	vpmovzxwd	%xmm0, %xmm0
	vpmovzxwd	%xmm3, %xmm3
	vpslld	$24, %xmm10, %xmm10
	vpternlogd	$254, %xmm11, %xmm10, %xmm7
	vpslld	$24, %xmm3, %xmm3
	vpslld	$16, %xmm0, %xmm0
	vpternlogd	$254, %xmm5, %xmm3, %xmm0
	vpxor	%xmm3, %xmm3, %xmm3
	vmovdqa	%xmm9, %xmm5
	vpermt2d	%xmm3, %xmm30, %xmm5
	vinsertps	$32, %xmm6, %xmm5, %xmm5
	vmovdqu	%xmm5, -1004(%rbp)
	vmovdqa	%xmm3, %xmm5
	vpermt2d	%xmm9, %xmm29, %xmm5
	vpermt2d	%xmm3, %xmm28, %xmm9
	vpblendd	$13, %xmm5, %xmm6, %xmm5
	vpermt2d	%xmm9, %xmm27, %xmm6
	vmovdqu	%xmm5, -988(%rbp)
	vmovdqa	%xmm4, %xmm5
	vpermt2d	%xmm3, %xmm30, %xmm5
	vmovdqu	%xmm6, -972(%rbp)
	vmovq	%rsi, %xmm6
	vinsertps	$32, %xmm2, %xmm5, %xmm5
	vmovdqu	%xmm5, -956(%rbp)
	vmovdqa	%xmm3, %xmm5
	vpermt2d	%xmm4, %xmm29, %xmm5
	vpermt2d	%xmm3, %xmm28, %xmm4
	vpblendd	$13, %xmm5, %xmm2, %xmm5
	vpermt2d	%xmm4, %xmm27, %xmm2
	vmovdqu	%xmm2, -924(%rbp)
	vmovdqa	%xmm8, %xmm2
	vpermt2d	%xmm3, %xmm30, %xmm2
	vmovdqu	%xmm5, -940(%rbp)
	vinsertps	$32, %xmm7, %xmm2, %xmm2
	vmovdqu	%xmm2, -908(%rbp)
	vmovdqa	%xmm3, %xmm2
	vpermt2d	%xmm8, %xmm29, %xmm2
	vpermt2d	%xmm3, %xmm28, %xmm8
	vpblendd	$13, %xmm2, %xmm7, %xmm2
	vpermt2d	%xmm8, %xmm27, %xmm7
	vmovdqu	%xmm2, -892(%rbp)
	vmovdqa	%xmm1, %xmm2
	vpermt2d	%xmm3, %xmm30, %xmm2
	vmovdqu	%xmm7, -876(%rbp)
	vinsertps	$32, %xmm0, %xmm2, %xmm2
	vmovdqu	%xmm2, -860(%rbp)
	vmovdqa	%xmm3, %xmm2
	vpermt2d	%xmm1, %xmm29, %xmm2
	vpermt2d	%xmm3, %xmm28, %xmm1
	vpblendd	$13, %xmm2, %xmm0, %xmm2
	vpermt2d	%xmm1, %xmm27, %xmm0
	vmovdqu	%xmm2, -844(%rbp)
	vmovdqu	%xmm0, -828(%rbp)
	.p2align 5
	.p2align 4
	.p2align 3
.L15:
	btq	%rax, %r10
	jnc	.L14
	movzbl	(%rcx), %esi
	movb	%sil, (%rdx)
.L14:
	incl	%eax
	incq	%rcx
	incq	%rdx
	cmpl	$64, %eax
	jne	.L15
	subq	$8, %rsp
	vmovq	%xmm6, %rsi
	vmovq	%xmm23, %rcx
	movq	%r10, %rdx
	pushq	%rbx
	subq	$16, %rsp
	vmovq	%xmm21, 8(%rsp)
	vmovq	%xmm16, (%rsp)
	vzeroupper
	call	probe_rows_bytes
	vmovdqu8	(%r14), %zmm0
	addq	$32, %rsp
	vpcmpeqd	(%r12), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L16
	vmovdqu8	64(%r14), %zmm0
	vpcmpeqd	64(%r12), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L16
	vmovdqu8	128(%r14), %zmm0
	vpcmpeqd	128(%r12), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L16
	movq	192(%r14), %rax
	cmpq	%rax, 192(%r12)
	je	.L39
	.p2align 4
	.p2align 3
.L16:
	movl	$1, %eax
.L17:
	vmovdqu8	(%r15), %zmm0
	vpcmpeqd	(%r11), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L18
	movzwl	64(%r15), %ecx
	xorl	%edx, %edx
	cmpw	%cx, 64(%r11)
	je	.L19
.L18:
	movl	$1, %edx
.L19:
	movl	-1044(%rbp), %ecx
	addl	%edx, %eax
	vmovdqu8	%zmm26, (%r14)
	movw	$-23131, 64(%r15)
	vmovdqu8	%zmm26, 64(%r14)
	subq	$8, %rsp
	movq	%r10, %rdx
	vmovdqu8	%zmm26, 128(%r14)
	vmovdqu8	%zmm19, (%r15)
	addl	%eax, %ecx
	movabsq	$6510615555426900570, %rax
	movl	%ecx, -1044(%rbp)
	movq	%rax, 192(%r14)
	pushq	%rbx
	vmovq	%xmm23, %rcx
	subq	$16, %rsp
	vmovq	%xmm21, 8(%rsp)
	vmovq	%xmm16, (%rsp)
	vzeroupper
	call	probe_rows_dwords
	vmovdqu8	(%r14), %zmm0
	addq	$32, %rsp
	vpcmpeqd	(%r12), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L20
	vmovdqu8	64(%r14), %zmm0
	vpcmpeqd	64(%r12), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L20
	vmovdqu8	128(%r14), %zmm0
	vpcmpeqd	128(%r12), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L20
	movq	192(%r14), %rax
	cmpq	%rax, 192(%r12)
	je	.L40
	.p2align 4
	.p2align 3
.L20:
	movl	$1, %eax
.L21:
	vmovdqu8	(%r15), %zmm0
	vpcmpeqd	(%r11), %zmm0, %k0
	kortestw	%k0, %k0
	jnc	.L22
	movzwl	64(%r15), %ebx
	xorl	%edx, %edx
	cmpw	%bx, 64(%r11)
	je	.L23
.L22:
	movl	$1, %edx
.L23:
	movl	-1044(%rbp), %ebx
	addl	%edx, %eax
	incl	%r13d
	addl	%eax, %ebx
	movl	%ebx, -1044(%rbp)
	cmpl	$20, %r13d
	jne	.L24
	incq	-1056(%rbp)
	movl	-1048(%rbp), %r10d
	cmpq	$6, -1056(%rbp)
	jne	.L11
	incl	%r10d
	cmpl	$256, %r10d
	jne	.L9
	movl	-1044(%rbp), %ebx
	xorl	%eax, %eax
	movl	$122880, %r8d
	movl	$1, %ecx
	movl	$1, %edx
	leaq	.LC16(%rip), %rsi
	movl	$2, %edi
	vzeroupper
	movl	%ebx, %r9d
	call	__printf_chk@PLT
	xorl	%eax, %eax
	testl	%ebx, %ebx
	setne	%al
	movq	-56(%rbp), %rdx
	subq	%fs:40, %rdx
	jne	.L41
	leaq	-48(%rbp), %rsp
	popq	%rbx
	popq	%r10
	.cfi_remember_state
	.cfi_def_cfa 10, 0
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	leaq	-8(%r10), %rsp
	.cfi_def_cfa 7, 8
	ret
.L12:
	.cfi_restore_state
	movabsq	$-6148914691236517206, %r10
	cmpl	$17, %r13d
	je	.L13
	cmpl	$18, %r13d
	movq	$-1, %r10
	movabsq	$-9223372036854775807, %rax
	cmove	%rax, %r10
	jmp	.L13
.L40:
	xorl	%eax, %eax
	jmp	.L21
.L39:
	xorl	%eax, %eax
	jmp	.L17
.L41:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE7343:
	.size	main, .-main
	.local	probe_byte_masks
	.comm	probe_byte_masks,24,16
	.local	probe_byte_indices
	.comm	probe_byte_indices,192,64
	.section	.rodata
	.align 8
	.type	probe_word_masks, @object
	.size	probe_word_masks, 12
probe_word_masks:
	.long	56173
	.long	28086
	.long	46811
	.align 32
	.type	probe_word_indices, @object
	.size	probe_word_indices, 192
probe_word_indices:
	.long	0
	.long	0
	.long	16
	.long	1
	.long	0
	.long	17
	.long	2
	.long	0
	.long	18
	.long	3
	.long	0
	.long	19
	.long	4
	.long	0
	.long	20
	.long	5
	.long	0
	.long	21
	.long	6
	.long	0
	.long	22
	.long	7
	.long	0
	.long	23
	.long	8
	.long	0
	.long	24
	.long	9
	.long	0
	.long	25
	.long	10
	.long	0
	.long	26
	.long	11
	.long	0
	.long	27
	.long	12
	.long	0
	.long	28
	.long	13
	.long	0
	.long	29
	.long	14
	.long	0
	.long	30
	.long	15
	.long	0
	.long	31
	.align 64
.LC0:
	.long	0
	.long	0
	.long	16
	.long	1
	.long	0
	.long	17
	.long	2
	.long	0
	.long	18
	.long	3
	.long	0
	.long	19
	.long	4
	.long	0
	.long	20
	.long	5
	.align 64
.LC1:
	.long	0
	.long	21
	.long	6
	.long	0
	.long	22
	.long	7
	.long	0
	.long	23
	.long	8
	.long	0
	.long	24
	.long	9
	.long	0
	.long	25
	.long	10
	.long	0
	.align 64
.LC2:
	.long	26
	.long	11
	.long	0
	.long	27
	.long	12
	.long	0
	.long	28
	.long	13
	.long	0
	.long	29
	.long	14
	.long	0
	.long	30
	.long	15
	.long	0
	.long	31
	.section	.rodata.cst2,"aM",@progbits,2
	.align 2
.LC3:
	.value	-9363
	.align 2
.LC4:
	.value	28086
	.align 2
.LC5:
	.value	-18725
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC6:
	.long	0
	.long	1
	.long	63
	.long	2147483647
	.section	.rodata
	.align 64
.LC8:
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.byte	4
	.byte	5
	.byte	6
	.byte	7
	.byte	8
	.byte	9
	.byte	10
	.byte	11
	.byte	12
	.byte	13
	.byte	14
	.byte	15
	.byte	16
	.byte	17
	.byte	18
	.byte	19
	.byte	20
	.byte	21
	.byte	22
	.byte	23
	.byte	24
	.byte	25
	.byte	26
	.byte	27
	.byte	28
	.byte	29
	.byte	30
	.byte	31
	.byte	32
	.byte	33
	.byte	34
	.byte	35
	.byte	36
	.byte	37
	.byte	38
	.byte	39
	.byte	40
	.byte	41
	.byte	42
	.byte	43
	.byte	44
	.byte	45
	.byte	46
	.byte	47
	.byte	48
	.byte	49
	.byte	50
	.byte	51
	.byte	52
	.byte	53
	.byte	54
	.byte	55
	.byte	56
	.byte	57
	.byte	58
	.byte	59
	.byte	60
	.byte	61
	.byte	62
	.byte	63
	.align 64
.LC9:
	.byte	0
	.byte	2
	.byte	4
	.byte	6
	.byte	8
	.byte	10
	.byte	12
	.byte	14
	.byte	64
	.byte	66
	.byte	68
	.byte	70
	.byte	72
	.byte	74
	.byte	76
	.byte	78
	.byte	16
	.byte	18
	.byte	20
	.byte	22
	.byte	24
	.byte	26
	.byte	28
	.byte	30
	.byte	80
	.byte	82
	.byte	84
	.byte	86
	.byte	88
	.byte	90
	.byte	92
	.byte	94
	.byte	32
	.byte	34
	.byte	36
	.byte	38
	.byte	40
	.byte	42
	.byte	44
	.byte	46
	.byte	96
	.byte	98
	.byte	100
	.byte	102
	.byte	104
	.byte	106
	.byte	108
	.byte	110
	.byte	48
	.byte	50
	.byte	52
	.byte	54
	.byte	56
	.byte	58
	.byte	60
	.byte	62
	.byte	112
	.byte	114
	.byte	116
	.byte	118
	.byte	120
	.byte	122
	.byte	124
	.byte	126
	.section	.rodata.cst16
	.align 16
.LC12:
	.long	0
	.long	4
	.long	0
	.long	1
	.align 16
.LC13:
	.long	1
	.long	5
	.long	6
	.long	2
	.align 16
.LC14:
	.long	2
	.long	3
	.long	7
	.long	3
	.align 16
.LC15:
	.long	2
	.long	5
	.long	6
	.long	3
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
