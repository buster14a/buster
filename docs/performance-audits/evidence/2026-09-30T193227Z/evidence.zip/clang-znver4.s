	.file	"probe.c"
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0                          # -- Begin function main
.LCPI0_0:
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	4                               # 0x4
	.long	4                               # 0x4
	.long	4                               # 0x4
	.long	4                               # 0x4
.LCPI0_1:
	.long	8                               # 0x8
	.long	8                               # 0x8
	.long	8                               # 0x8
	.long	8                               # 0x8
	.long	12                              # 0xc
	.long	12                              # 0xc
	.long	12                              # 0xc
	.long	12                              # 0xc
.LCPI0_2:
	.long	16                              # 0x10
	.long	16                              # 0x10
	.long	16                              # 0x10
	.long	16                              # 0x10
	.long	20                              # 0x14
	.long	20                              # 0x14
	.long	20                              # 0x14
	.long	20                              # 0x14
.LCPI0_3:
	.long	24                              # 0x18
	.long	24                              # 0x18
	.long	24                              # 0x18
	.long	24                              # 0x18
	.long	28                              # 0x1c
	.long	28                              # 0x1c
	.long	28                              # 0x1c
	.long	28                              # 0x1c
.LCPI0_6:
	.long	32                              # 0x20
	.long	32                              # 0x20
	.long	32                              # 0x20
	.long	32                              # 0x20
	.long	36                              # 0x24
	.long	36                              # 0x24
	.long	36                              # 0x24
	.long	36                              # 0x24
.LCPI0_7:
	.long	40                              # 0x28
	.long	40                              # 0x28
	.long	40                              # 0x28
	.long	40                              # 0x28
	.long	44                              # 0x2c
	.long	44                              # 0x2c
	.long	44                              # 0x2c
	.long	44                              # 0x2c
.LCPI0_8:
	.long	48                              # 0x30
	.long	48                              # 0x30
	.long	48                              # 0x30
	.long	48                              # 0x30
	.long	52                              # 0x34
	.long	52                              # 0x34
	.long	52                              # 0x34
	.long	52                              # 0x34
.LCPI0_9:
	.long	56                              # 0x38
	.long	56                              # 0x38
	.long	56                              # 0x38
	.long	56                              # 0x38
	.long	60                              # 0x3c
	.long	60                              # 0x3c
	.long	60                              # 0x3c
	.long	60                              # 0x3c
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI0_4:
	.byte	32                              # 0x20
	.byte	16                              # 0x10
	.byte	8                               # 0x8
	.byte	4                               # 0x4
	.byte	2                               # 0x2
	.byte	1                               # 0x1
	.byte	0                               # 0x0
	.byte	0                               # 0x0
.LCPI0_5:
	.quad	216736831629295872              # 0x302010003020100
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
.LCPI0_10:
	.quad	72339073326383361               # 0x101000101000101
	.quad	144678146652766722              # 0x202000202000202
	.quad	289356293305533444              # 0x404000404000404
	.quad	578712586611066888              # 0x808000808000808
	.quad	1152939165513420800             # 0x1000101000101000
	.quad	2305878331026841600             # 0x2000202000202000
	.quad	4611756662053683200             # 0x4000404000404000
	.quad	-9223230749602185216            # 0x8000808000808000
.LCPI0_11:
	.quad	72058697844588800               # 0x100010100010100
	.quad	144117395689177600              # 0x200020200020200
	.quad	288234791378355200              # 0x400040400040400
	.quad	576469582756710400              # 0x800080800080800
	.quad	4521192082898960                # 0x10100010100010
	.quad	9042384165797920                # 0x20200020200020
	.quad	18084768331595840               # 0x40400040400040
	.quad	36169536663191680               # 0x80800080800080
.LCPI0_12:
	.quad	282574505181185                 # 0x1010001010001
	.quad	565149010362370                 # 0x2020002020002
	.quad	1130298020724740                # 0x4040004040004
	.quad	2260596041449480                # 0x8080008080008
	.quad	1157425173222133776             # 0x1010001010001010
	.quad	2314850346444267552             # 0x2020002020002020
	.quad	4629700692888535104             # 0x4040004040004040
	.quad	-9187342687932481408            # 0x8080008080008080
.LCPI0_13:
	.byte	0                               # 0x0
	.byte	1                               # 0x1
	.byte	2                               # 0x2
	.byte	3                               # 0x3
	.byte	4                               # 0x4
	.byte	5                               # 0x5
	.byte	6                               # 0x6
	.byte	7                               # 0x7
	.byte	8                               # 0x8
	.byte	9                               # 0x9
	.byte	10                              # 0xa
	.byte	11                              # 0xb
	.byte	12                              # 0xc
	.byte	13                              # 0xd
	.byte	14                              # 0xe
	.byte	15                              # 0xf
	.byte	16                              # 0x10
	.byte	17                              # 0x11
	.byte	18                              # 0x12
	.byte	19                              # 0x13
	.byte	20                              # 0x14
	.byte	21                              # 0x15
	.byte	22                              # 0x16
	.byte	23                              # 0x17
	.byte	24                              # 0x18
	.byte	25                              # 0x19
	.byte	26                              # 0x1a
	.byte	27                              # 0x1b
	.byte	28                              # 0x1c
	.byte	29                              # 0x1d
	.byte	30                              # 0x1e
	.byte	31                              # 0x1f
	.byte	32                              # 0x20
	.byte	33                              # 0x21
	.byte	34                              # 0x22
	.byte	35                              # 0x23
	.byte	36                              # 0x24
	.byte	37                              # 0x25
	.byte	38                              # 0x26
	.byte	39                              # 0x27
	.byte	40                              # 0x28
	.byte	41                              # 0x29
	.byte	42                              # 0x2a
	.byte	43                              # 0x2b
	.byte	44                              # 0x2c
	.byte	45                              # 0x2d
	.byte	46                              # 0x2e
	.byte	47                              # 0x2f
	.byte	48                              # 0x30
	.byte	49                              # 0x31
	.byte	50                              # 0x32
	.byte	51                              # 0x33
	.byte	52                              # 0x34
	.byte	53                              # 0x35
	.byte	54                              # 0x36
	.byte	55                              # 0x37
	.byte	56                              # 0x38
	.byte	57                              # 0x39
	.byte	58                              # 0x3a
	.byte	59                              # 0x3b
	.byte	60                              # 0x3c
	.byte	61                              # 0x3d
	.byte	62                              # 0x3e
	.byte	63                              # 0x3f
.LCPI0_14:
	.byte	0                               # 0x0
	.byte	3                               # 0x3
	.byte	6                               # 0x6
	.byte	9                               # 0x9
	.byte	12                              # 0xc
	.byte	15                              # 0xf
	.byte	18                              # 0x12
	.byte	21                              # 0x15
	.byte	24                              # 0x18
	.byte	27                              # 0x1b
	.byte	30                              # 0x1e
	.byte	33                              # 0x21
	.byte	36                              # 0x24
	.byte	39                              # 0x27
	.byte	42                              # 0x2a
	.byte	45                              # 0x2d
	.byte	48                              # 0x30
	.byte	51                              # 0x33
	.byte	54                              # 0x36
	.byte	57                              # 0x39
	.byte	60                              # 0x3c
	.byte	63                              # 0x3f
	.byte	66                              # 0x42
	.byte	69                              # 0x45
	.byte	72                              # 0x48
	.byte	75                              # 0x4b
	.byte	78                              # 0x4e
	.byte	81                              # 0x51
	.byte	84                              # 0x54
	.byte	87                              # 0x57
	.byte	90                              # 0x5a
	.byte	93                              # 0x5d
	.byte	96                              # 0x60
	.byte	99                              # 0x63
	.byte	102                             # 0x66
	.byte	105                             # 0x69
	.byte	108                             # 0x6c
	.byte	111                             # 0x6f
	.byte	114                             # 0x72
	.byte	117                             # 0x75
	.byte	120                             # 0x78
	.byte	123                             # 0x7b
	.byte	126                             # 0x7e
	.byte	129                             # 0x81
	.byte	132                             # 0x84
	.byte	135                             # 0x87
	.byte	138                             # 0x8a
	.byte	141                             # 0x8d
	.byte	144                             # 0x90
	.byte	147                             # 0x93
	.byte	150                             # 0x96
	.byte	153                             # 0x99
	.byte	156                             # 0x9c
	.byte	159                             # 0x9f
	.byte	162                             # 0xa2
	.byte	165                             # 0xa5
	.byte	168                             # 0xa8
	.byte	171                             # 0xab
	.byte	174                             # 0xae
	.byte	177                             # 0xb1
	.byte	180                             # 0xb4
	.byte	183                             # 0xb7
	.byte	186                             # 0xba
	.byte	189                             # 0xbd
.LCPI0_15:
	.byte	0                               # 0x0
	.byte	5                               # 0x5
	.byte	10                              # 0xa
	.byte	15                              # 0xf
	.byte	20                              # 0x14
	.byte	25                              # 0x19
	.byte	30                              # 0x1e
	.byte	35                              # 0x23
	.byte	40                              # 0x28
	.byte	45                              # 0x2d
	.byte	50                              # 0x32
	.byte	55                              # 0x37
	.byte	60                              # 0x3c
	.byte	65                              # 0x41
	.byte	70                              # 0x46
	.byte	75                              # 0x4b
	.byte	80                              # 0x50
	.byte	85                              # 0x55
	.byte	90                              # 0x5a
	.byte	95                              # 0x5f
	.byte	100                             # 0x64
	.byte	105                             # 0x69
	.byte	110                             # 0x6e
	.byte	115                             # 0x73
	.byte	120                             # 0x78
	.byte	125                             # 0x7d
	.byte	130                             # 0x82
	.byte	135                             # 0x87
	.byte	140                             # 0x8c
	.byte	145                             # 0x91
	.byte	150                             # 0x96
	.byte	155                             # 0x9b
	.byte	160                             # 0xa0
	.byte	165                             # 0xa5
	.byte	170                             # 0xaa
	.byte	175                             # 0xaf
	.byte	180                             # 0xb4
	.byte	185                             # 0xb9
	.byte	190                             # 0xbe
	.byte	195                             # 0xc3
	.byte	200                             # 0xc8
	.byte	205                             # 0xcd
	.byte	210                             # 0xd2
	.byte	215                             # 0xd7
	.byte	220                             # 0xdc
	.byte	225                             # 0xe1
	.byte	230                             # 0xe6
	.byte	235                             # 0xeb
	.byte	240                             # 0xf0
	.byte	245                             # 0xf5
	.byte	250                             # 0xfa
	.byte	255                             # 0xff
	.byte	4                               # 0x4
	.byte	9                               # 0x9
	.byte	14                              # 0xe
	.byte	19                              # 0x13
	.byte	24                              # 0x18
	.byte	29                              # 0x1d
	.byte	34                              # 0x22
	.byte	39                              # 0x27
	.byte	44                              # 0x2c
	.byte	49                              # 0x31
	.byte	54                              # 0x36
	.byte	59                              # 0x3b
.LCPI0_16:
	.byte	0                               # 0x0
	.byte	7                               # 0x7
	.byte	14                              # 0xe
	.byte	21                              # 0x15
	.byte	28                              # 0x1c
	.byte	35                              # 0x23
	.byte	42                              # 0x2a
	.byte	49                              # 0x31
	.byte	56                              # 0x38
	.byte	63                              # 0x3f
	.byte	70                              # 0x46
	.byte	77                              # 0x4d
	.byte	84                              # 0x54
	.byte	91                              # 0x5b
	.byte	98                              # 0x62
	.byte	105                             # 0x69
	.byte	112                             # 0x70
	.byte	119                             # 0x77
	.byte	126                             # 0x7e
	.byte	133                             # 0x85
	.byte	140                             # 0x8c
	.byte	147                             # 0x93
	.byte	154                             # 0x9a
	.byte	161                             # 0xa1
	.byte	168                             # 0xa8
	.byte	175                             # 0xaf
	.byte	182                             # 0xb6
	.byte	189                             # 0xbd
	.byte	196                             # 0xc4
	.byte	203                             # 0xcb
	.byte	210                             # 0xd2
	.byte	217                             # 0xd9
	.byte	224                             # 0xe0
	.byte	231                             # 0xe7
	.byte	238                             # 0xee
	.byte	245                             # 0xf5
	.byte	252                             # 0xfc
	.byte	3                               # 0x3
	.byte	10                              # 0xa
	.byte	17                              # 0x11
	.byte	24                              # 0x18
	.byte	31                              # 0x1f
	.byte	38                              # 0x26
	.byte	45                              # 0x2d
	.byte	52                              # 0x34
	.byte	59                              # 0x3b
	.byte	66                              # 0x42
	.byte	73                              # 0x49
	.byte	80                              # 0x50
	.byte	87                              # 0x57
	.byte	94                              # 0x5e
	.byte	101                             # 0x65
	.byte	108                             # 0x6c
	.byte	115                             # 0x73
	.byte	122                             # 0x7a
	.byte	129                             # 0x81
	.byte	136                             # 0x88
	.byte	143                             # 0x8f
	.byte	150                             # 0x96
	.byte	157                             # 0x9d
	.byte	164                             # 0xa4
	.byte	171                             # 0xab
	.byte	178                             # 0xb2
	.byte	185                             # 0xb9
.LCPI0_17:
	.byte	0                               # 0x0
	.byte	9                               # 0x9
	.byte	18                              # 0x12
	.byte	27                              # 0x1b
	.byte	36                              # 0x24
	.byte	45                              # 0x2d
	.byte	54                              # 0x36
	.byte	63                              # 0x3f
	.byte	72                              # 0x48
	.byte	81                              # 0x51
	.byte	90                              # 0x5a
	.byte	99                              # 0x63
	.byte	108                             # 0x6c
	.byte	117                             # 0x75
	.byte	126                             # 0x7e
	.byte	135                             # 0x87
	.byte	144                             # 0x90
	.byte	153                             # 0x99
	.byte	162                             # 0xa2
	.byte	171                             # 0xab
	.byte	180                             # 0xb4
	.byte	189                             # 0xbd
	.byte	198                             # 0xc6
	.byte	207                             # 0xcf
	.byte	216                             # 0xd8
	.byte	225                             # 0xe1
	.byte	234                             # 0xea
	.byte	243                             # 0xf3
	.byte	252                             # 0xfc
	.byte	5                               # 0x5
	.byte	14                              # 0xe
	.byte	23                              # 0x17
	.byte	32                              # 0x20
	.byte	41                              # 0x29
	.byte	50                              # 0x32
	.byte	59                              # 0x3b
	.byte	68                              # 0x44
	.byte	77                              # 0x4d
	.byte	86                              # 0x56
	.byte	95                              # 0x5f
	.byte	104                             # 0x68
	.byte	113                             # 0x71
	.byte	122                             # 0x7a
	.byte	131                             # 0x83
	.byte	140                             # 0x8c
	.byte	149                             # 0x95
	.byte	158                             # 0x9e
	.byte	167                             # 0xa7
	.byte	176                             # 0xb0
	.byte	185                             # 0xb9
	.byte	194                             # 0xc2
	.byte	203                             # 0xcb
	.byte	212                             # 0xd4
	.byte	221                             # 0xdd
	.byte	230                             # 0xe6
	.byte	239                             # 0xef
	.byte	248                             # 0xf8
	.byte	1                               # 0x1
	.byte	10                              # 0xa
	.byte	19                              # 0x13
	.byte	28                              # 0x1c
	.byte	37                              # 0x25
	.byte	46                              # 0x2e
	.byte	55                              # 0x37
.LCPI0_18:
	.zero	64,90
.LCPI0_19:
	.zero	64,165
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI0_20:
	.zero	16,90
.LCPI0_21:
	.zero	16,165
	.text
	.globl	main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1208, %rsp                     # imm = 0x4B8
	.cfi_def_cfa_offset 1264
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	vmovdqa	.LCPI0_0(%rip), %ymm3           # ymm3 = [0,0,0,0,4,4,4,4]
	vmovdqa	.LCPI0_1(%rip), %ymm4           # ymm4 = [8,8,8,8,12,12,12,12]
	vmovdqa	.LCPI0_2(%rip), %ymm5           # ymm5 = [16,16,16,16,20,20,20,20]
	vmovdqa	.LCPI0_3(%rip), %ymm6           # ymm6 = [24,24,24,24,28,28,28,28]
	leaq	probe_word_indices(%rip), %rax
	kxnorw	%k0, %k0, %k2
	vpxor	%xmm1, %xmm1, %xmm1
	vpxor	%xmm2, %xmm2, %xmm2
	vpxor	%xmm7, %xmm7, %xmm7
	vpxor	%xmm8, %xmm8, %xmm8
	vpbroadcastq	.LCPI0_5(%rip), %ymm17  # ymm17 = [216736831629295872,216736831629295872,216736831629295872,216736831629295872]
	vmovdqa64	.LCPI0_6(%rip), %ymm16  # ymm16 = [32,32,32,32,36,36,36,36]
	vmovdqa	.LCPI0_9(%rip), %ymm10          # ymm10 = [56,56,56,56,60,60,60,60]
	vpxor	%xmm12, %xmm12, %xmm12
	vpxor	%xmm13, %xmm13, %xmm13
	vpxor	%xmm14, %xmm14, %xmm14
	vpxor	%xmm15, %xmm15, %xmm15
	vmovq	probe_byte_masks(%rip), %xmm11  # xmm11 = mem[0],zero
	kxnorw	%k0, %k0, %k1
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%r14d, %r14d
	vporq	.LCPI0_10(%rip), %zmm11, %zmm11
	vpgatherdd	(%rax,%ymm3), %ymm1 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	(%rax,%ymm4), %ymm2 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	(%rax,%ymm5), %ymm7 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	(%rax,%ymm6), %ymm8 {%k2}
	kxnorw	%k0, %k0, %k2
	vpmovdb	%ymm1, %xmm9
	vpmovdb	%ymm2, %xmm2
	vpmovdb	%ymm7, %xmm1
	vpmovdb	%ymm8, %xmm7
	vinserti128	$1, %xmm2, %ymm9, %ymm2
	vmovdqa	.LCPI0_7(%rip), %ymm8           # ymm8 = [40,40,40,40,44,44,44,44]
	vmovdqa	.LCPI0_8(%rip), %ymm9           # ymm9 = [48,48,48,48,52,52,52,52]
	vinserti128	$1, %xmm7, %ymm1, %ymm7
	vpbroadcastq	.LCPI0_4(%rip), %ymm1   # ymm1 = [32,16,8,4,2,1,0,0,32,16,8,4,2,1,0,0,32,16,8,4,2,1,0,0,32,16,8,4,2,1,0,0]
	vgf2p8affineqb	$0, %ymm1, %ymm7, %ymm7
	vgf2p8affineqb	$0, %ymm1, %ymm2, %ymm2
	vpunpcklqdq	%ymm7, %ymm2, %ymm2     # ymm2 = ymm2[0],ymm7[0],ymm2[2],ymm7[2]
	vpermq	$216, %ymm2, %ymm7              # ymm7 = ymm2[0,2,1,3]
	vporq	%ymm17, %ymm7, %ymm7
	vmovdqa	%ymm7, probe_byte_indices(%rip)
	vpgatherdd	(%rax,%ymm16), %ymm12 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	(%rax,%ymm8), %ymm13 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	(%rax,%ymm9), %ymm14 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	(%rax,%ymm10), %ymm15 {%k2}
	kxnorw	%k0, %k0, %k2
	vpmovdb	%ymm12, %xmm12
	vpmovdb	%ymm13, %xmm13
	vpmovdb	%ymm14, %xmm14
	vpmovdb	%ymm15, %xmm15
	vinserti128	$1, %xmm13, %ymm12, %ymm12
	vpxor	%xmm13, %xmm13, %xmm13
	vgf2p8affineqb	$0, %ymm1, %ymm12, %ymm12
	vinserti128	$1, %xmm15, %ymm14, %ymm14
	vpxor	%xmm15, %xmm15, %xmm15
	vgf2p8affineqb	$0, %ymm1, %ymm14, %ymm14
	vpunpcklqdq	%ymm14, %ymm12, %ymm12  # ymm12 = ymm12[0],ymm14[0],ymm12[2],ymm14[2]
	vpxor	%xmm14, %xmm14, %xmm14
	vpermq	$216, %ymm12, %ymm12            # ymm12 = ymm12[0,2,1,3]
	vporq	%ymm17, %ymm12, %ymm12
	vmovdqa	%ymm12, probe_byte_indices+32(%rip)
	vextracti64x4	$1, %zmm11, %ymm12
	vporq	%zmm12, %zmm11, %zmm11
	vextracti128	$1, %ymm11, %xmm12
	vpor	%xmm12, %xmm11, %xmm11
	vpshufd	$238, %xmm11, %xmm12            # xmm12 = xmm11[2,3,2,3]
	vpor	%xmm12, %xmm11, %xmm11
	vpxor	%xmm12, %xmm12, %xmm12
	vmovq	%xmm11, probe_byte_masks(%rip)
	vpgatherdd	64(%rax,%ymm3), %ymm12 {%k2}
	kxnorw	%k0, %k0, %k2
	vmovq	probe_byte_masks+8(%rip), %xmm11 # xmm11 = mem[0],zero
	vpgatherdd	64(%rax,%ymm4), %ymm13 {%k2}
	kxnorw	%k0, %k0, %k2
	vporq	.LCPI0_11(%rip), %zmm11, %zmm11
	vpgatherdd	64(%rax,%ymm5), %ymm14 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	64(%rax,%ymm6), %ymm15 {%k2}
	kxnorw	%k0, %k0, %k2
	vpmovdb	%ymm12, %xmm12
	vpmovdb	%ymm13, %xmm13
	vpmovdb	%ymm14, %xmm14
	vpmovdb	%ymm15, %xmm15
	vinserti128	$1, %xmm13, %ymm12, %ymm12
	vpxor	%xmm13, %xmm13, %xmm13
	vgf2p8affineqb	$0, %ymm1, %ymm12, %ymm12
	vinserti128	$1, %xmm15, %ymm14, %ymm14
	vpxor	%xmm15, %xmm15, %xmm15
	vgf2p8affineqb	$0, %ymm1, %ymm14, %ymm14
	vpunpcklqdq	%ymm14, %ymm12, %ymm12  # ymm12 = ymm12[0],ymm14[0],ymm12[2],ymm14[2]
	vpxor	%xmm14, %xmm14, %xmm14
	vpermq	$216, %ymm12, %ymm12            # ymm12 = ymm12[0,2,1,3]
	vporq	%ymm17, %ymm12, %ymm12
	vmovdqa	%ymm12, probe_byte_indices+64(%rip)
	vpxor	%xmm12, %xmm12, %xmm12
	vpgatherdd	64(%rax,%ymm16), %ymm12 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	64(%rax,%ymm8), %ymm13 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	64(%rax,%ymm9), %ymm14 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	64(%rax,%ymm10), %ymm15 {%k2}
	kxnorw	%k0, %k0, %k2
	vpmovdb	%ymm12, %xmm12
	vpmovdb	%ymm13, %xmm13
	vpmovdb	%ymm14, %xmm14
	vpmovdb	%ymm15, %xmm15
	vinserti128	$1, %xmm13, %ymm12, %ymm12
	vgf2p8affineqb	$0, %ymm1, %ymm12, %ymm12
	vinserti128	$1, %xmm15, %ymm14, %ymm14
	vgf2p8affineqb	$0, %ymm1, %ymm14, %ymm14
	vpunpcklqdq	%ymm14, %ymm12, %ymm12  # ymm12 = ymm12[0],ymm14[0],ymm12[2],ymm14[2]
	vpermq	$216, %ymm12, %ymm12            # ymm12 = ymm12[0,2,1,3]
	vporq	%ymm17, %ymm12, %ymm12
	vmovdqa	%ymm12, probe_byte_indices+96(%rip)
	vextracti64x4	$1, %zmm11, %ymm12
	vporq	%zmm12, %zmm11, %zmm11
	vextracti128	$1, %ymm11, %xmm12
	vpor	%xmm12, %xmm11, %xmm11
	vpshufd	$238, %xmm11, %xmm12            # xmm12 = xmm11[2,3,2,3]
	vpor	%xmm12, %xmm11, %xmm11
	vpxor	%xmm12, %xmm12, %xmm12
	vmovq	%xmm11, probe_byte_masks+8(%rip)
	vpgatherdd	128(%rax,%ymm3), %ymm12 {%k2}
	kxnorw	%k0, %k0, %k2
	vpxor	%xmm3, %xmm3, %xmm3
	vmovq	probe_byte_masks+16(%rip), %xmm11 # xmm11 = mem[0],zero
	vpgatherdd	128(%rax,%ymm4), %ymm3 {%k2}
	kxnorw	%k0, %k0, %k2
	vpxor	%xmm4, %xmm4, %xmm4
	vporq	.LCPI0_12(%rip), %zmm11, %zmm2
	vpgatherdd	128(%rax,%ymm5), %ymm4 {%k2}
	kxnorw	%k0, %k0, %k2
	vpxor	%xmm5, %xmm5, %xmm5
	vpgatherdd	128(%rax,%ymm6), %ymm5 {%k2}
	kxnorw	%k0, %k0, %k2
	vpmovdb	%ymm12, %xmm6
	vpmovdb	%ymm3, %xmm3
	vpmovdb	%ymm4, %xmm4
	vpmovdb	%ymm5, %xmm5
	vinserti128	$1, %xmm3, %ymm6, %ymm3
	vgf2p8affineqb	$0, %ymm1, %ymm3, %ymm3
	vinserti128	$1, %xmm5, %ymm4, %ymm4
	vpxor	%xmm5, %xmm5, %xmm5
	vgf2p8affineqb	$0, %ymm1, %ymm4, %ymm4
	vpunpcklqdq	%ymm4, %ymm3, %ymm3     # ymm3 = ymm3[0],ymm4[0],ymm3[2],ymm4[2]
	vpxor	%xmm4, %xmm4, %xmm4
	vpermq	$216, %ymm3, %ymm3              # ymm3 = ymm3[0,2,1,3]
	vporq	%ymm17, %ymm3, %ymm3
	vmovdqa	%ymm3, probe_byte_indices+128(%rip)
	vpxor	%xmm3, %xmm3, %xmm3
	vpgatherdd	128(%rax,%ymm16), %ymm3 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	128(%rax,%ymm10), %ymm0 {%k1}
	vpgatherdd	128(%rax,%ymm8), %ymm4 {%k2}
	kxnorw	%k0, %k0, %k2
	vpgatherdd	128(%rax,%ymm9), %ymm5 {%k2}
	xorl	%eax, %eax
	vpmovdb	%ymm3, %xmm3
	vpmovdb	%ymm0, %xmm0
	vpmovdb	%ymm4, %xmm4
	vpmovdb	%ymm5, %xmm5
	vinserti128	$1, %xmm4, %ymm3, %ymm3
	vinserti128	$1, %xmm0, %ymm5, %ymm0
	vgf2p8affineqb	$0, %ymm1, %ymm0, %ymm0
	vgf2p8affineqb	$0, %ymm1, %ymm3, %ymm1
	vpunpcklqdq	%ymm0, %ymm1, %ymm0     # ymm0 = ymm1[0],ymm0[0],ymm1[2],ymm0[2]
	vextracti64x4	$1, %zmm2, %ymm1
	vpermq	$216, %ymm0, %ymm0              # ymm0 = ymm0[0,2,1,3]
	vporq	%ymm17, %ymm0, %ymm0
	vmovdqa	%ymm0, probe_byte_indices+160(%rip)
	vporq	%zmm1, %zmm2, %zmm0
	vextracti128	$1, %ymm0, %xmm1
	vpor	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              # xmm1 = xmm0[2,3,2,3]
	vpor	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, probe_byte_masks+16(%rip)
	jmp	.LBB0_1
	.p2align	4
.LBB0_5:                                #   in Loop: Header=BB0_1 Depth=1
	movq	136(%rsp), %rax                 # 8-byte Reload
	incq	%rax
	cmpq	$256, %rax                      # imm = 0x100
	je	.LBB0_6
.LBB0_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_2 Depth 2
                                        #       Child Loop BB0_3 Depth 3
	vpbroadcastb	%eax, %zmm0
	vpaddb	.LCPI0_13(%rip), %zmm0, %zmm1
	vpaddb	.LCPI0_14(%rip), %zmm0, %zmm2
	vpaddb	.LCPI0_15(%rip), %zmm0, %zmm4
	xorl	%ecx, %ecx
	movq	%rax, 136(%rsp)                 # 8-byte Spill
	vmovdqu64	%zmm1, 529(%rsp)
	vmovdqu64	%zmm2, 595(%rsp)
	vpaddb	.LCPI0_16(%rip), %zmm0, %zmm2
	vpaddb	.LCPI0_17(%rip), %zmm0, %zmm0
	vmovdqu64	%zmm4, 661(%rsp)
	vmovdqu64	%zmm2, 727(%rsp)
	vmovdqu64	%zmm0, 793(%rsp)
	vmovdqu64	%zmm0, 1136(%rsp)       # 64-byte Spill
	vpmovzxbd	661(%rsp), %zmm1        # zmm1 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	727(%rsp), %zmm2        # zmm2 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	595(%rsp), %zmm0        # zmm0 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	529(%rsp), %zmm4        # zmm4 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpslld	$16, %zmm1, %zmm1
	vpslld	$24, %zmm2, %zmm2
	vmovdqu64	%zmm4, 1072(%rsp)       # 64-byte Spill
	vpternlogd	$254, %zmm0, %zmm1, %zmm2 # zmm2 = zmm2 | zmm1 | zmm0
	vextracti32x4	$3, %zmm2, %xmm0
	vextracti32x4	$2, %zmm2, %xmm3
	vpextrd	$3, %xmm2, 36(%rsp)             # 4-byte Folded Spill
	vpextrd	$2, %xmm2, 32(%rsp)             # 4-byte Folded Spill
	vpextrd	$1, %xmm2, 28(%rsp)             # 4-byte Folded Spill
	vmovd	%xmm2, 24(%rsp)                 # 4-byte Folded Spill
	vpextrd	$3, %xmm0, 68(%rsp)             # 4-byte Folded Spill
	vpextrd	$2, %xmm0, 64(%rsp)             # 4-byte Folded Spill
	vpextrd	$1, %xmm0, 60(%rsp)             # 4-byte Folded Spill
	vmovd	%xmm0, 44(%rsp)                 # 4-byte Folded Spill
	vextracti128	$1, %ymm2, %xmm0
	vpextrd	$3, %xmm3, 56(%rsp)             # 4-byte Folded Spill
	vpextrd	$2, %xmm3, 52(%rsp)             # 4-byte Folded Spill
	vpextrd	$1, %xmm3, 48(%rsp)             # 4-byte Folded Spill
	vmovd	%xmm3, 40(%rsp)                 # 4-byte Folded Spill
	vpextrd	$3, %xmm0, 20(%rsp)             # 4-byte Folded Spill
	vpextrd	$2, %xmm0, 16(%rsp)             # 4-byte Folded Spill
	vpextrd	$1, %xmm0, 12(%rsp)             # 4-byte Folded Spill
	vmovd	%xmm0, 8(%rsp)                  # 4-byte Folded Spill
	jmp	.LBB0_2
	.p2align	4
.LBB0_10:                               #   in Loop: Header=BB0_2 Depth=2
	movq	144(%rsp), %rcx                 # 8-byte Reload
	incq	%rcx
	cmpq	$6, %rcx
	je	.LBB0_5
.LBB0_2:                                #   Parent Loop BB0_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB0_3 Depth 3
	leaq	.L__const.main.bases(%rip), %rax
	xorl	%ebx, %ebx
	movq	%rcx, 144(%rsp)                 # 8-byte Spill
	movl	(%rax,%rcx,4), %eax
	vpbroadcastd	%eax, %zmm0
	vpaddd	1072(%rsp), %zmm0, %zmm0        # 64-byte Folded Reload
	movq	%rax, 152(%rsp)                 # 8-byte Spill
	vextracti32x4	$3, %zmm0, %xmm1
	vextracti32x4	$2, %zmm0, %xmm2
	vpextrd	$3, %xmm0, 100(%rsp)            # 4-byte Folded Spill
	vpextrd	$2, %xmm0, 96(%rsp)             # 4-byte Folded Spill
	vpextrd	$1, %xmm0, 92(%rsp)             # 4-byte Folded Spill
	vmovd	%xmm0, 88(%rsp)                 # 4-byte Folded Spill
	vextracti128	$1, %ymm0, %xmm0
	vpextrd	$3, %xmm1, 132(%rsp)            # 4-byte Folded Spill
	vpextrd	$2, %xmm1, 128(%rsp)            # 4-byte Folded Spill
	vpextrd	$1, %xmm1, 124(%rsp)            # 4-byte Folded Spill
	vpextrd	$3, %xmm2, 120(%rsp)            # 4-byte Folded Spill
	vpextrd	$2, %xmm2, 116(%rsp)            # 4-byte Folded Spill
	vpextrd	$1, %xmm2, 112(%rsp)            # 4-byte Folded Spill
	vmovd	%xmm1, 108(%rsp)                # 4-byte Folded Spill
	vmovd	%xmm2, 104(%rsp)                # 4-byte Folded Spill
	vpextrd	$3, %xmm0, 84(%rsp)             # 4-byte Folded Spill
	vpextrd	$2, %xmm0, 80(%rsp)             # 4-byte Folded Spill
	vpextrd	$1, %xmm0, 76(%rsp)             # 4-byte Folded Spill
	vmovd	%xmm0, 72(%rsp)                 # 4-byte Folded Spill
	jmp	.LBB0_3
	.p2align	4
.LBB0_4:                                #   in Loop: Header=BB0_3 Depth=3
	movq	$-1, %rax
	shlxq	%rbx, %rax, %r15
	notq	%r15
.LBB0_9:                                #   in Loop: Header=BB0_3 Depth=3
	vbroadcastf32x4	.LCPI0_20(%rip), %zmm0  # zmm0 = [90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90]
                                        # zmm0 = mem[0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3]
	vmovss	92(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vmovss	96(%rsp), %xmm2                 # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vmovss	76(%rsp), %xmm3                 # 4-byte Reload
                                        # xmm3 = mem[0],zero,zero,zero
	movq	%r15, %rax
	shrq	$32, %rax
	vmovss	68(%rsp), %xmm4                 # 4-byte Reload
                                        # xmm4 = mem[0],zero,zero,zero
	movw	$-23131, 304(%rsp)              # imm = 0xA5A5
	movw	$-23131, 224(%rsp)              # imm = 0xA5A5
	kmovd	%eax, %k2
	movq	%r15, %rax
	shrq	$40, %rax
	kmovd	%eax, %k3
	movq	%r15, %rax
	shrq	$48, %rax
	kmovd	%eax, %k4
	movq	%r15, %rax
	shrq	$56, %rax
	kunpckbw	%k2, %k3, %k2
	kmovd	%eax, %k5
	movl	%r15d, %eax
	shrl	$8, %eax
	kmovd	%eax, %k6
	movl	%r15d, %eax
	shrl	$16, %eax
	kunpckbw	%k4, %k5, %k3
	kmovd	%eax, %k0
	movl	%r15d, %eax
	shrl	$24, %eax
	kunpckwd	%k2, %k3, %k2
	kmovd	%r15d, %k3
	kmovd	%eax, %k1
	movabsq	$6510615555426900570, %rax      # imm = 0x5A5A5A5A5A5A5A5A
	kunpckbw	%k3, %k6, %k3
	vmovups	%zmm0, 864(%rsp)
	vmovups	%zmm0, 928(%rsp)
	vmovups	%zmm0, 992(%rsp)
	vmovups	%zmm0, 320(%rsp)
	vmovups	%zmm0, 384(%rsp)
	vmovups	%zmm0, 448(%rsp)
	vbroadcastf32x4	.LCPI0_21(%rip), %zmm0  # zmm0 = [165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165]
                                        # zmm0 = mem[0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3]
	movq	%rax, 1056(%rsp)
	kunpckbw	%k0, %k1, %k0
	movq	%rax, 512(%rsp)
	leaq	241(%rsp), %rax
	kunpckwd	%k3, %k0, %k0
	kunpckdq	%k0, %k2, %k1
	vmovups	%zmm0, 240(%rsp)
	vmovups	%zmm0, 160(%rsp)
	vmovss	24(%rsp), %xmm0                 # 4-byte Reload
                                        # xmm0 = mem[0],zero,zero,zero
	vunpcklps	%xmm1, %xmm0, %xmm0     # xmm0 = xmm0[0],xmm1[0],xmm0[1],xmm1[1]
	vmovss	88(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vmovlhps	%xmm0, %xmm1, %xmm0             # xmm0 = xmm1[0],xmm0[0]
	vmovss	28(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vshufps	$65, %xmm2, %xmm1, %xmm1        # xmm1 = xmm1[1,0],xmm2[0,1]
	vmovss	100(%rsp), %xmm2                # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vinsertf128	$1, %xmm1, %ymm0, %ymm0
	vmovss	32(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vunpcklps	%xmm2, %xmm1, %xmm1     # xmm1 = xmm1[0],xmm2[0],xmm1[1],xmm2[1]
	vmovss	36(%rsp), %xmm2                 # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vinsertps	$52, %xmm2, %xmm1, %xmm1 # xmm1 = xmm1[0,1],zero,xmm2[0]
	vmovss	8(%rsp), %xmm2                  # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vunpcklps	%xmm3, %xmm2, %xmm2     # xmm2 = xmm2[0],xmm3[0],xmm2[1],xmm3[1]
	vmovss	72(%rsp), %xmm3                 # 4-byte Reload
                                        # xmm3 = mem[0],zero,zero,zero
	vmovlhps	%xmm2, %xmm3, %xmm2             # xmm2 = xmm3[0],xmm2[0]
	vmovss	116(%rsp), %xmm3                # 4-byte Reload
                                        # xmm3 = mem[0],zero,zero,zero
	vinsertf128	$1, %xmm2, %ymm1, %ymm1
	vmovss	84(%rsp), %xmm2                 # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vinsertf64x4	$1, %ymm1, %zmm0, %zmm0
	vmovss	80(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vmovups	%zmm0, 868(%rsp)
	vmovss	12(%rsp), %xmm0                 # 4-byte Reload
                                        # xmm0 = mem[0],zero,zero,zero
	vshufps	$65, %xmm1, %xmm0, %xmm0        # xmm0 = xmm0[1,0],xmm1[0,1]
	vmovss	16(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vunpcklps	%xmm2, %xmm1, %xmm1     # xmm1 = xmm1[0],xmm2[0],xmm1[1],xmm2[1]
	vmovss	20(%rsp), %xmm2                 # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vinsertps	$52, %xmm2, %xmm1, %xmm1 # xmm1 = xmm1[0,1],zero,xmm2[0]
	vmovss	112(%rsp), %xmm2                # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vinsertf128	$1, %xmm1, %ymm0, %ymm0
	vmovss	40(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vunpcklps	%xmm2, %xmm1, %xmm1     # xmm1 = xmm1[0],xmm2[0],xmm1[1],xmm2[1]
	vmovss	104(%rsp), %xmm2                # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vmovlhps	%xmm1, %xmm2, %xmm1             # xmm1 = xmm2[0],xmm1[0]
	vmovss	48(%rsp), %xmm2                 # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vshufps	$65, %xmm3, %xmm2, %xmm2        # xmm2 = xmm2[1,0],xmm3[0,1]
	vmovss	132(%rsp), %xmm3                # 4-byte Reload
                                        # xmm3 = mem[0],zero,zero,zero
	vinsertf128	$1, %xmm2, %ymm1, %ymm1
	vmovss	124(%rsp), %xmm2                # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vinsertf64x4	$1, %ymm1, %zmm0, %zmm0
	vmovss	120(%rsp), %xmm1                # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vmovups	%zmm0, 932(%rsp)
	vmovss	52(%rsp), %xmm0                 # 4-byte Reload
                                        # xmm0 = mem[0],zero,zero,zero
	vunpcklps	%xmm1, %xmm0, %xmm0     # xmm0 = xmm0[0],xmm1[0],xmm0[1],xmm1[1]
	vmovss	56(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vinsertps	$52, %xmm1, %xmm0, %xmm0 # xmm0 = xmm0[0,1],zero,xmm1[0]
	vmovss	44(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vunpcklps	%xmm2, %xmm1, %xmm1     # xmm1 = xmm1[0],xmm2[0],xmm1[1],xmm2[1]
	vmovss	108(%rsp), %xmm2                # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vmovlhps	%xmm1, %xmm2, %xmm1             # xmm1 = xmm2[0],xmm1[0]
	vmovss	128(%rsp), %xmm2                # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vinsertf128	$1, %xmm1, %ymm0, %ymm0
	vmovss	60(%rsp), %xmm1                 # 4-byte Reload
                                        # xmm1 = mem[0],zero,zero,zero
	vshufps	$65, %xmm2, %xmm1, %xmm1        # xmm1 = xmm1[1,0],xmm2[0,1]
	vmovss	64(%rsp), %xmm2                 # 4-byte Reload
                                        # xmm2 = mem[0],zero,zero,zero
	vunpcklps	%xmm3, %xmm2, %xmm2     # xmm2 = xmm2[0],xmm3[0],xmm2[1],xmm3[1]
	vinsertps	$52, %xmm4, %xmm2, %xmm2 # xmm2 = xmm2[0,1],zero,xmm4[0]
	vinsertf128	$1, %xmm2, %ymm1, %ymm1
	vinsertf64x4	$1, %ymm1, %zmm0, %zmm0
	vmovdqu64	1136(%rsp), %zmm1       # 64-byte Reload
	vmovups	%zmm0, 996(%rsp)
	vmovdqu8	%zmm1, (%rax) {%k1}
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movq	160(%rsp), %r12                 # 8-byte Reload
	leaq	603(%rsp), %rbp
	leaq	332(%rsp), %rdi
	leaq	169(%rsp), %rsi
	movq	%r15, %rdx
	leaq	537(%rsp), %rcx
	leaq	669(%rsp), %r9
	movq	%rbp, %r8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	leaq	809(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	leaq	751(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	probe_rows_bytes
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	movl	$200, %edx
	leaq	864(%rsp), %rdi
	leaq	320(%rsp), %rsi
	callq	bcmp@PLT
	cmpl	$1, %eax
	movzwl	224(%rsp), %edx
	movzwl	304(%rsp), %eax
	vmovdqu64	240(%rsp), %zmm0
	movw	$-23131, 224(%rsp)              # imm = 0xA5A5
	sbbl	$-1, %r14d
	vpcmpneqb	160(%rsp), %zmm0, %k1
	xorl	%r13d, %r13d
	movzbl	%al, %ecx
	movzbl	%dl, %esi
	shrl	$8, %eax
	shrl	$8, %edx
	vmovd	%ecx, %xmm1
	vmovd	%esi, %xmm2
	vpinsrb	$1, %eax, %xmm1, %xmm1
	vpinsrb	$1, %edx, %xmm2, %xmm2
	movabsq	$6510615555426900570, %rax      # imm = 0x5A5A5A5A5A5A5A5A
	vpcmpneqb	%zmm2, %zmm1, %k0
	vbroadcastf32x4	.LCPI0_20(%rip), %zmm2  # zmm2 = [90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90]
                                        # zmm2 = mem[0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3]
	vbroadcastf32x4	.LCPI0_21(%rip), %zmm1  # zmm1 = [165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165,165]
                                        # zmm1 = mem[0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3]
	movq	%rax, 512(%rsp)
	kortestq	%k0, %k1
	setne	%r13b
	addl	%r14d, %r13d
	vmovups	%zmm2, 320(%rsp)
	vmovups	%zmm2, 384(%rsp)
	vmovups	%zmm2, 448(%rsp)
	vmovups	%zmm1, 160(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	332(%rsp), %rdi
	leaq	169(%rsp), %rsi
	movq	%r15, %rdx
	leaq	537(%rsp), %rcx
	movq	%rbp, %r8
	leaq	669(%rsp), %r9
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	leaq	809(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	leaq	751(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	probe_rows_dwords
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	movl	$200, %edx
	leaq	864(%rsp), %rdi
	leaq	320(%rsp), %rsi
	callq	bcmp@PLT
	cmpl	$1, %eax
	vmovdqu64	240(%rsp), %zmm0
	movzwl	304(%rsp), %eax
	movzwl	224(%rsp), %edx
	vpcmpneqb	160(%rsp), %zmm0, %k1
	sbbl	$-1, %r13d
	xorl	%r14d, %r14d
	movzbl	%al, %ecx
	movzbl	%dl, %esi
	shrl	$8, %eax
	shrl	$8, %edx
	vmovd	%ecx, %xmm1
	vmovd	%esi, %xmm2
	vpinsrb	$1, %eax, %xmm1, %xmm1
	vpinsrb	$1, %edx, %xmm2, %xmm2
	vpcmpneqb	%zmm2, %zmm1, %k0
	kortestq	%k0, %k1
	setne	%r14b
	incq	%rbx
	addl	%r13d, %r14d
	cmpq	$20, %rbx
	je	.LBB0_10
.LBB0_3:                                #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_2 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	cmpq	$16, %rbx
	jbe	.LBB0_4
# %bb.7:                                #   in Loop: Header=BB0_3 Depth=3
	movabsq	$-6148914691236517206, %r15     # imm = 0xAAAAAAAAAAAAAAAA
	cmpq	$17, %rbx
	je	.LBB0_9
# %bb.8:                                #   in Loop: Header=BB0_3 Depth=3
	xorl	%r15d, %r15d
	cmpq	$18, %rbx
	movabsq	$-9223372036854775807, %rax     # imm = 0x8000000000000001
	setne	%r15b
	negq	%r15
	orq	%rax, %r15
	jmp	.LBB0_9
.LBB0_6:
	leaq	.L.str(%rip), %rdi
	movl	$1, %esi
	movl	$1, %edx
	movl	$122880, %ecx                   # imm = 0x1E000
	movl	%r14d, %r8d
	xorl	%eax, %eax
	vzeroupper
	callq	printf@PLT
	xorl	%eax, %eax
	testl	%r14d, %r14d
	setne	%al
	addq	$1208, %rsp                     # imm = 0x4B8
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function probe_rows_bytes
	.type	probe_rows_bytes,@function
probe_rows_bytes:                       # @probe_rows_bytes
	.cfi_startproc
# %bb.0:
	movq	8(%rsp), %r10
	vpmovzxbd	(%r9), %zmm2            # zmm2 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	(%r8), %zmm1            # zmm1 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	(%rcx), %zmm0           # zmm0 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	kmovq	probe_byte_masks(%rip), %k1
	movq	16(%rsp), %rax
	vpaddd	24(%rsp){1to16}, %zmm0, %zmm0
	vpmovzxbd	(%r10), %zmm3           # zmm3 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpslld	$16, %zmm2, %zmm2
	vpslld	$24, %zmm3, %zmm3
	vpternlogd	$254, %zmm2, %zmm1, %zmm3 # zmm3 = zmm3 | zmm1 | zmm2
	vmovdqa64	probe_byte_indices(%rip), %zmm2
	vpermi2b	%zmm3, %zmm0, %zmm2 {%k1} {z}
	vmovdqu64	%zmm2, (%rdi)
	vmovdqa64	probe_byte_indices+64(%rip), %zmm1
	kmovq	probe_byte_masks+8(%rip), %k1
	vpermi2b	%zmm3, %zmm0, %zmm1 {%k1} {z}
	vmovdqu64	%zmm1, 64(%rdi)
	vmovdqa64	probe_byte_indices+128(%rip), %zmm1
	kmovq	probe_byte_masks+16(%rip), %k1
	vpermi2b	%zmm3, %zmm0, %zmm1 {%k1} {z}
	kmovq	%rdx, %k1
	vmovdqu64	%zmm1, 128(%rdi)
	vmovdqu64	(%rax), %zmm0
	vmovdqu8	%zmm0, (%rsi) {%k1}
	vzeroupper
	retq
.Lfunc_end1:
	.size	probe_rows_bytes, .Lfunc_end1-probe_rows_bytes
	.cfi_endproc
                                        # -- End function
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0                          # -- Begin function probe_rows_dwords
.LCPI2_0:
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
.LCPI2_1:
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
.LCPI2_2:
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.text
	.p2align	4
	.type	probe_rows_dwords,@function
probe_rows_dwords:                      # @probe_rows_dwords
	.cfi_startproc
# %bb.0:
	movq	8(%rsp), %r10
	vpmovzxbd	(%r9), %zmm2            # zmm2 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	(%r8), %zmm1            # zmm1 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpmovzxbd	(%rcx), %zmm0           # zmm0 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vmovdqa64	probe_word_indices+64(%rip), %zmm4
	movq	16(%rsp), %rax
	kmovq	%rdx, %k1
	vpaddd	24(%rsp){1to16}, %zmm0, %zmm0
	vpmovzxbd	(%r10), %zmm3           # zmm3 = mem[0],zero,zero,zero,mem[1],zero,zero,zero,mem[2],zero,zero,zero,mem[3],zero,zero,zero,mem[4],zero,zero,zero,mem[5],zero,zero,zero,mem[6],zero,zero,zero,mem[7],zero,zero,zero,mem[8],zero,zero,zero,mem[9],zero,zero,zero,mem[10],zero,zero,zero,mem[11],zero,zero,zero,mem[12],zero,zero,zero,mem[13],zero,zero,zero,mem[14],zero,zero,zero,mem[15],zero,zero,zero
	vpslld	$16, %zmm2, %zmm2
	vpslld	$24, %zmm3, %zmm3
	vpternlogd	$254, %zmm1, %zmm2, %zmm3 # zmm3 = zmm3 | zmm2 | zmm1
	vmovdqa64	probe_word_indices(%rip), %zmm2
	vpermi2d	%zmm3, %zmm0, %zmm4
	vpermi2d	%zmm3, %zmm0, %zmm2
	vpandd	.LCPI2_0(%rip), %zmm2, %zmm1
	vmovdqa64	probe_word_indices+128(%rip), %zmm2
	vpermi2d	%zmm3, %zmm0, %zmm2
	vmovdqu64	%zmm1, (%rdi)
	vpandd	.LCPI2_1(%rip), %zmm4, %zmm1
	vpandd	.LCPI2_2(%rip), %zmm2, %zmm0
	vmovdqu64	%zmm1, 64(%rdi)
	vmovdqu64	%zmm0, 128(%rdi)
	vmovdqu64	(%rax), %zmm0
	vmovdqu8	%zmm0, (%rsi) {%k1}
	vzeroupper
	retq
.Lfunc_end2:
	.size	probe_rows_dwords, .Lfunc_end2-probe_rows_dwords
	.cfi_endproc
                                        # -- End function
	.type	.L__const.main.bases,@object    # @__const.main.bases
	.section	.rodata,"a",@progbits
	.p2align	4, 0x0
.L__const.main.bases:
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	63                              # 0x3f
	.long	2147483647                      # 0x7fffffff
	.long	4294967280                      # 0xfffffff0
	.long	4294967295                      # 0xffffffff
	.size	.L__const.main.bases, 24

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"PROBE full=%u base=%u fixtures=30720 comparisons=%u failures=%u\n"
	.size	.L.str, 65

	.type	probe_word_indices,@object      # @probe_word_indices
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
probe_word_indices:
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	16                              # 0x10
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	17                              # 0x11
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	18                              # 0x12
	.long	3                               # 0x3
	.long	0                               # 0x0
	.long	19                              # 0x13
	.long	4                               # 0x4
	.long	0                               # 0x0
	.long	20                              # 0x14
	.long	5                               # 0x5
	.long	0                               # 0x0
	.long	21                              # 0x15
	.long	6                               # 0x6
	.long	0                               # 0x0
	.long	22                              # 0x16
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	23                              # 0x17
	.long	8                               # 0x8
	.long	0                               # 0x0
	.long	24                              # 0x18
	.long	9                               # 0x9
	.long	0                               # 0x0
	.long	25                              # 0x19
	.long	10                              # 0xa
	.long	0                               # 0x0
	.long	26                              # 0x1a
	.long	11                              # 0xb
	.long	0                               # 0x0
	.long	27                              # 0x1b
	.long	12                              # 0xc
	.long	0                               # 0x0
	.long	28                              # 0x1c
	.long	13                              # 0xd
	.long	0                               # 0x0
	.long	29                              # 0x1d
	.long	14                              # 0xe
	.long	0                               # 0x0
	.long	30                              # 0x1e
	.long	15                              # 0xf
	.long	0                               # 0x0
	.long	31                              # 0x1f
	.size	probe_word_indices, 192

	.type	probe_byte_indices,@object      # @probe_byte_indices
	.local	probe_byte_indices
	.comm	probe_byte_indices,192,64
	.type	probe_byte_masks,@object        # @probe_byte_masks
	.local	probe_byte_masks
	.comm	probe_byte_masks,24,16
	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
