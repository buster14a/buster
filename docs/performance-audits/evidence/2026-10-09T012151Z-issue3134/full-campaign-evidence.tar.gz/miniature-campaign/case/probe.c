#include "switch.h"
int probe(void) { return SWITCH_VALUE + 3; }
