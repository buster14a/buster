#define SWITCH_VALUE (*(int*)0)
