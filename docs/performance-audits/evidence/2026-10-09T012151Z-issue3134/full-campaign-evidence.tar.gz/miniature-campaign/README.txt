Miniature native shadow campaign

The `run-N` directories retain every recorded attempt, including analyzer logs, normal result files, manifests and shadow observations. Indices 0-8 are initial calibration/negative controls; 12-23 are the fixed timeout-600 changed-source campaign. The gaps are not retained attempts. `case/` is the final clean fixture: probe.c includes switch.h, include-first is absent, and include-second/switch.h defines SWITCH_VALUE as 42. `case/compile_commands.json` records the exact one-TU compile database. Paths name the original task worktree.

Sequence of interest:
- 12/13: unchanged source; first observation then repeat partial-fingerprint match.
- 15: stable timeout-60 baseline used for earlier controls.
- 16/17: source content changed, then repeated.
- 18/19: source content changed again, then repeated.
- 20: clean timeout-600 baseline with no include-first/switch.h.
- 21: created `fault-input/include-first/switch.h` containing `#define SWITCH_VALUE (*(int*)0)`; the earlier include path gained the previously missing header, and the fresh analyzer failed.
- 22: another failed attempt; the first removal attempt had not actually removed the header.
- 23: after verifying successful removal, fresh analysis passed and the partial fingerprint matched run 20.

Every attempt still invoked full fresh analysis. All successful repeated-input attempts report partial fingerprint only; none reports content_fingerprint_match=1, authoritative_eligible=1 or qualified reuse. Failed runs did not advance the successful state.
