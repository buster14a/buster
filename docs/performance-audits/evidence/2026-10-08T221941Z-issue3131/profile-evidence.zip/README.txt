Issue #3131 exact-command analyzer profile evidence

Source commit: 96eba05bf1be5a146afc7ca3a1d1c6ae2fac9473
Source tree:   87db07a5098e4a207b5a19d251f12d956dbf62c1
Clang:         /usr/lib/llvm-21/bin/clang, 21.1.8
Host:          AMD EPYC 9V74 under KVM, 9 visible CPUs (cloud scratch)

The full uninstrumented run selected and passed all 182 Release C TUs using
the ordinary native analyzer driver, 8 shards, 2 workers and default checkers.
Its exact native plan is baseline/manifest.txt; raw compile_commands.json and
CMakeCache.txt are retained at this directory's root. The full run's manifest,
per-shard rows, unit logs, run output and independent aggregate are in
baseline/. current-unit-times.csv ranks every selected TU from those rows.

profiling/compile_commands.json contains only the four current top TUs. Each
command is byte-for-byte the original command string plus Clang's supported
-ftime-trace=<file> and -ftime-trace-granularity=10000. The analyzer driver's
projection is profiling/results/manifest.txt; profiling/traces/ keeps
the four raw bounded JSON traces. The second narrowed projection and its raw
results, per-function traces and analyzer timer output use
profiling/narrow-compile_commands.json, profiling/narrow-results/ and
profiling/traces/narrow/.

bootstrap/ retains the analyzer-reference source/dependency/executable
provenance. target-sources.sha256, generated.sha256, tool-identities.sha256,
clang-version.txt, clang-resource-dir.txt, clang-options.txt, CMakeCache.txt,
compile_commands.json and host.txt pin source, generated input, configuration,
compiler, driver and host identities. The host is not the approved Ryzen 7
9700X; these numbers are diagnostic and do not claim Zen 5 performance.

Every evidence file except SHA256SUMS itself is pinned by SHA256SUMS. Current Clang options were verified using
the captured --help output; the 10 ms trace granularity and narrowed function
runs are diagnostic only and did not replace any required analysis.
