/workspace/scratch/1cd4b38ae5f3/issue3131/build/analyzer-driver: build.c \
  src/buster/lib/base.h src/buster/lib/os.h src/buster/lib/entry_point.h \
  src/buster/lib/file.h src/buster/lib/hash.h src/buster/lib/integer.h \
  src/buster/lib/string.h src/buster/lib/target.h \
  src/buster/lib/x86_64.h src/buster/lib/string.c src/buster/lib/arena.h \
  src/buster/lib/os.c src/buster/lib/os_internal.h \
  src/buster/lib/system_headers.h src/buster/lib/arena.c \
  src/buster/lib/arena_internal.h src/buster/lib/file.c \
  src/buster/lib/hash.c src/buster/lib/integer.c \
  src/buster/lib/entry_point.c src/buster/lib/target.c \
  src/buster/lib/x86_64.c \
  src/buster/lib/compiler/assembly/x86_64_metadata.c \
  src/buster/lib/compiler/assembly/x86_64_metadata.h \
  src/buster/lib/compiler/assembly/x86_64_conditions.inc \
  src/buster/lib/compiler/work_ledger.h src/buster/lib/simd.h \
  src/buster/lib/compiler/assembly/generated/x86_64-assembly.generated.h \
  src/buster/lib/compiler/assembly/generated/x86_64-coverage.generated.inc \
  src/buster/lib/compiler/assembly/arm_a64_canonical_import.c \
  src/buster/lib/compiler/assembly/arm_a64_sysreg_import.c \
  tools/clang_analyze.c tools/optnone_audit.c tools/matrix_phase.c \
  tools/binary_coverage.c tools/differential.c \
  src/buster/lib/compiler/driver/codegen_configurations.h \
  tools/gpu_toolchains.c tools/throughput/hash.h \
  tools/native_retirement_census.c \
  tools/native_retirement_dependency_binding.generated.h \
  tools/uefi_boot.c tools/production_profile.c tools/source_size.c \
  tools/ci_unit_tests.c tools/clang_suite.c tools/clang_suite_smoke.c \
  tools/clang_suite_test.c
