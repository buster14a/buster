from pathlib import Path
import hashlib
import json
import subprocess

work=Path(__file__).resolve().parent
records=[]
for size in (16,1024):
    for shape in ('no-locals','disqualified'):
        retained=shape=='disqualified'
        flags=['-fno-frontend-ssa','-fno-canonical-local-promotion','-fno-canonical-fast'] if retained else []
        label=f'{shape}-zero-{size}'
        command=['taskset','-c','2',str(work/'performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--events','instructions:u','--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline',str(work/'bin'/'baseline'),'--candidate',str(work/'bin'/'candidate'),'--out',str(work/'evidence'/'work'/label),'--','cc','-march=native','-g0',*flags,'-c',str(work/'inputs'/f'{shape}-{size}.c'),'-o',str(work/'zero-output.o')]
        print('CASE '+label,flush=True)
        subprocess.run(command,cwd=work/'buster',check=True)
        objects=[]
        for arm in ('baseline','candidate'):
            result=subprocess.run([str(work/'bin'/arm),'cc','-march=native','-g0',*flags,'-c',str(work/'inputs'/f'{shape}-{size}.c'),'-o',str(work/'zero-output.o')],cwd=work/'buster',capture_output=True,check=True)
            objects.append((work/'zero-output.o').read_bytes())
        assert objects[0]==objects[1]
        records.append({'case':label,'bytes':len(objects[0]),'sha256':hashlib.sha256(objects[0]).hexdigest()})
(work/'evidence'/'zero-control-artifacts.json').write_text(json.dumps(records,indent=2)+'\n')
