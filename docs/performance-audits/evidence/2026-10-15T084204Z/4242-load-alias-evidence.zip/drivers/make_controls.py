from pathlib import Path

out = Path(__file__).parent / 'inputs'
out.mkdir(exist_ok=True)
for size in (16, 1024):
    for shape in ('no-locals', 'eligible', 'escaped'):
        lines = ['extern void escape(unsigned long *);']
        for index in range(size):
            if shape == 'no-locals':
                body = 'return n*7+3;'
            elif shape == 'eligible':
                body = 'unsigned long x=n+3; if(n&1)x+=n;else x*=7;return x+n;'
            else:
                body = 'unsigned long x=n+3;escape(&x);return x+n;'
            lines.append(f'unsigned long f{index}(unsigned long n){{{body}}}')
        (out / f'{shape}-{size}.c').write_text('\n'.join(lines)+'\n')

(out / 'alias-cases.c').write_text('''
extern void escape(unsigned long *);
unsigned long direct(unsigned long n){unsigned long x=n+3;return x+n;}
unsigned long multiple(unsigned long n){unsigned long x=n;unsigned long a=x+1;x=n+7;return a+x;}
unsigned long cross_block(unsigned long n){unsigned long x=n+3;if(n&1)return x*7;return x+n;}
unsigned long pointer(unsigned long *p){unsigned long *x=p;return *x+1;}
unsigned long different_width(unsigned long n){unsigned long x=n;*(unsigned int*)&x=7;return x;}
unsigned long same_width(unsigned long n){unsigned long x=n;*(unsigned long*)&x=7;return x;}
unsigned long escaped(unsigned long n){unsigned long x=n;escape(&x);return x;}
unsigned long volatile_local(unsigned long n){volatile unsigned long x=n;return x;}
unsigned long store_free(unsigned long n){unsigned long x;if(n)goto use;return n;use:return x;}
unsigned long unused(unsigned long n){unsigned long x;return n;}
unsigned long late_escape(unsigned long n){unsigned long x=n;unsigned long a=x+1;escape(&x);return a+x;}
unsigned long mixed(unsigned long n){unsigned long x=n,y=n+7;escape(&x);return x+y;}
''')
