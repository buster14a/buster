from pathlib import Path
import hashlib
import json
import subprocess

work = Path(__file__).resolve().parent
root = work / 'buster'
out = work / 'evidence' / 'differential'
out.mkdir(exist_ok=True)
identities = []
def digest(data):
    return hashlib.sha256(data).hexdigest()

for source in sorted((work/'inputs').glob('*.c')):
    for allocator in ('fast','quality'):
        for retained in (False, True):
            for debug in ('-g0','-g'):
                label = f'{source.stem}-{allocator}-{int(retained)}-{debug[1:]}'
                flags = ['-fno-frontend-ssa','-fno-canonical-local-promotion','-fno-canonical-fast'] if retained else []
                objects = []
                for arm in ('baseline','candidate'):
                    command = [str(work/'bin'/arm),'cc',debug,'-march=native',f'-fregister-allocator={allocator}',*flags,'-c',str(source),'-o',str(work/'differential.o')]
                    if source.stem == 'alias-cases' and debug == '-g0':
                        command.insert(-4, '-fbootstrap-trace='+str(out/f'{label}-{arm}'))
                    result = subprocess.run(command,cwd=root,capture_output=True,check=True)
                    (out/f'{label}-{arm}.log').write_bytes(result.stdout+result.stderr)
                    objects.append((work/'differential.o').read_bytes())
                assert objects[0] == objects[1], label
                if source.stem == 'alias-cases' and debug == '-g0':
                    for kind in ('tokens','ir','mir'):
                        left = (out/f'{label}-baseline.{kind}').read_bytes()
                        right = (out/f'{label}-candidate.{kind}').read_bytes()
                        assert left == right, (label,kind)
                identities.append({'case':label,'bytes':len(objects[0]),'sha256':digest(objects[0])})
for allocator in ('fast','quality'):
    for debug in ('-g0','-g'):
        images=[]
        for arm in ('baseline','candidate'):
            command = [str(work/'bin'/arm),'cc',debug,'-march=native',f'-fregister-allocator={allocator}',str(work/'inputs'/'unity.i'),'-lm','-o',str(work/'differential-unity')]
            result = subprocess.run(command,cwd=root,capture_output=True,check=True)
            (out/f'unity-{allocator}-{debug[1:]}-{arm}.log').write_bytes(result.stdout+result.stderr)
            images.append((work/'differential-unity').read_bytes())
        assert images[0] == images[1]
        identities.append({'case':f'unity-{allocator}-{debug}','bytes':len(images[0]),'sha256':digest(images[0])})
(out/'summary.json').write_text(json.dumps(identities,indent=2)+'\n')
print(f'{len(identities)} complete artifacts identical; 4 token/IR/MIR trace triplets identical',flush=True)
