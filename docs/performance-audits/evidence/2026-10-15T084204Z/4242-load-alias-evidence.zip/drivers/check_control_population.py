from pathlib import Path
import json
import os
import re
import subprocess

work=Path(__file__).resolve().parent
out=work/'evidence'/'control-populations'
out.mkdir(exist_ok=True)
records=[]
for size in (16,1024):
    text='extern unsigned long input; extern void escape(unsigned long *);\n'
    text+='\n'.join(f'unsigned long f{i}(void){{unsigned long x=input+3;escape(&x);return x+input;}}' for i in range(size))+'\n'
    (work/'inputs'/f'disqualified-{size}.c').write_text(text)
    for shape in ('no-locals','eligible','escaped','disqualified'):
        for retained in ((True,False) if shape=='no-locals' else (True,)):
            flags=['-fno-frontend-ssa','-fno-canonical-local-promotion','-fno-canonical-fast'] if retained else []
            label=f'{shape}-{size}-retained-{int(retained)}'
            command=[str(work/'bin'/'census'),'cc','-g0',*flags,'-c',str(work/'inputs'/f'{shape}-{size}.c'),'-o',str(work/'population.o')]
            run=subprocess.run(command,cwd=work/'buster',env={**os.environ,'BUSTER_ALIAS_GUARD':'1'},capture_output=True,check=True)
            (out/(label+'.log')).write_bytes(run.stdout+run.stderr)
            rows=[tuple(map(int,x)) for x in re.findall(rb'ALIAS_CENSUS locals=(\d+) eligible=(\d+) candidates=(\d+) aliases=(\d+)',run.stderr)]
            record={'case':label,'functions':len(rows),'eligible_functions':sum(x[1]>0 for x in rows),'zero_eligible_functions':sum(x[1]==0 for x in rows),'candidate_visits_before':sum(2*x[2] for x in rows),'candidate_visits_after':sum(2*x[2] for x in rows if x[1]),'aliases':sum(x[3] for x in rows)}
            records.append(record)
            print(json.dumps(record),flush=True)
(out/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
