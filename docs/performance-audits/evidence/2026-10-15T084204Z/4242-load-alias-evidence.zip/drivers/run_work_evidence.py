from pathlib import Path
import subprocess

work=Path(__file__).resolve().parent
root=work/'buster'
(work/'evidence'/'work').mkdir(exist_ok=True)
common=['taskset','-c','2',str(work/'performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--events','instructions:u','--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline',str(work/'bin'/'baseline')]
cases=[('aa',work/'inputs'/'unity.i','fast',False,'baseline'),('unity-fast',work/'inputs'/'unity.i','fast',False,'candidate'),('unity-quality',work/'inputs'/'unity.i','quality',False,'candidate')]
for size in (16,1024):
    for shape in ('no-locals','eligible','escaped'):
        cases.append((f'{shape}-{size}',work/'inputs'/f'{shape}-{size}.c','fast',True,'candidate'))
for label,source,allocator,retained,candidate in cases:
    flags=['-fno-frontend-ssa','-fno-canonical-local-promotion','-fno-canonical-fast'] if retained else []
    command=common+['--candidate',str(work/'bin'/candidate),'--out',str(work/'evidence'/'work'/label),'--','cc','-march=native','-g0',f'-fregister-allocator={allocator}',*flags]
    if source.suffix=='.c':
        command += ['-c',str(source),'-o',str(work/'work-output.o')]
    else:
        command += [str(source),'-lm','-o',str(work/'work-unity')]
    print('CASE '+label,flush=True)
    subprocess.run(command,cwd=root,check=True)
