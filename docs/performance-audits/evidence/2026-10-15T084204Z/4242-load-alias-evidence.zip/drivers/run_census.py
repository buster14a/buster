from pathlib import Path
import json
import os
import re
import subprocess

work = Path(__file__).resolve().parent
root = work / 'buster'
out = work / 'evidence' / 'census'
out.mkdir(exist_ok=True)
binary = work / 'bin' / 'census'
records = []
for iteration in range(7):
    order = (False, True) if iteration % 2 == 0 else (True, False)
    for guarded in order:
        label = f'{iteration}-' + ('guarded' if guarded else 'baseline')
        env = dict(os.environ)
        if guarded:
            env['BUSTER_ALIAS_GUARD'] = '1'
        else:
            env.pop('BUSTER_ALIAS_GUARD', None)
        command = ['taskset', '-c', '2', str(binary), 'cc', '-march=native', '-g0', '-fregister-allocator=fast', str(work / 'inputs' / 'unity.i'), '-lm', '-o', str(work / 'census-unity')]
        run = subprocess.run(command, cwd=root, env=env, capture_output=True, check=True)
        (out / (label+'.stdout')).write_bytes(run.stdout)
        (out / (label+'.stderr')).write_bytes(run.stderr)
        rows = [dict(zip(('locals','eligible','candidates','aliases','ns','map'),map(int,m))) for m in re.findall(rb'ALIAS_CENSUS locals=(\d+) eligible=(\d+) candidates=(\d+) aliases=(\d+) ns=(\d+) map=(\d+)',run.stderr)]
        assert rows
        signature = [{k:v for k,v in row.items() if k != 'ns'} for row in rows]
        if records:
            assert signature == records[0]['signature']
        assert (work / 'census-unity').read_bytes() == (work / 'baseline-unity').read_bytes()
        record = {'iteration':iteration,'guarded':guarded,'functions':len(rows), 'zero_eligible_functions':sum(r['eligible']==0 for r in rows), 'initial_local_functions':sum(r['locals']>0 for r in rows), 'eligible_functions':sum(r['eligible']>0 for r in rows),'alias_functions':sum(r['aliases']>0 for r in rows),'aliases':sum(r['aliases'] for r in rows),'baseline_candidate_visits':sum(2*r['candidates'] for r in rows), 'actual_candidate_visits':sum(2*r['candidates'] for r in rows if not guarded or r['eligible']), 'sweep_ns':sum(r['ns'] for r in rows),'zero_eligible_sweep_ns':sum(r['ns'] for r in rows if not r['eligible']), 'signature':signature}
        records.append(record)
        print(json.dumps({k:v for k,v in record.items() if k != 'signature'}),flush=True)
(out / 'summary.json').write_text(json.dumps(records,indent=2)+'\n')
