from pathlib import Path
import subprocess
import sys

root = Path(__file__).parent / 'buster'
path = root / 'src/buster/lib/compiler/codegen/machine_x86_64.c'
base = subprocess.check_output(['git', 'show', '35fee905e39941acafb26db6d6ff3f41eb7d8dc7:src/buster/lib/compiler/codegen/machine_x86_64.c'], cwd=root).decode()
mode = sys.argv[1]
candidate = base.replace('    u32 candidate_count = 0;\n', '    u32 eligible_local_count = local_use_count - 1;\n    u32 candidate_count = 0;\n', 1)
candidate = candidate.replace('                if (!place_use)\n                {\n                    use->local_use = 0;', '                if (!place_use)\n                {\n                    eligible_local_count -= 1;\n                    use->local_use = 0;', 1)
if mode != 'baseline-census':
    candidate = candidate.replace('alias_sweep < 2;', 'alias_sweep < 2 && eligible_local_count;', 1)
if mode.endswith('census'):
    candidate = '#include <stdio.h>\n#include <stdlib.h>\n#include <buster/lib/time.h>\n' + candidate
    candidate = candidate.replace('    u32 alias_count = 0;\n', '    bool alias_guard = getenv("BUSTER_ALIAS_GUARD") != 0;\n    TimeDataType alias_start = timestamp_take();\n    u32 alias_count = 0;\n', 1)
    candidate = candidate.replace('alias_sweep < 2 && eligible_local_count;', 'alias_sweep < 2 && (eligible_local_count || !alias_guard);', 1)
    candidate = candidate.replace('    // A local with no store has no defining value', '    u64 alias_ns = timestamp_ns_between(alias_start, timestamp_take());\n    u64 alias_hash = 0;\n    for (u32 alias_index = 0; alias_index < alias_count; alias_index += 1)\n    {\n        alias_hash = alias_hash * 65599 + alias_values[alias_index];\n        alias_hash = alias_hash * 65599 + load_aliases[alias_values[alias_index]];\n    }\n    fprintf(stderr, "ALIAS_CENSUS locals=%u eligible=%u candidates=%u aliases=%u ns=%llu map=%llu\\n", local_use_count - 1, eligible_local_count, candidate_count, alias_count, (unsigned long long)alias_ns, (unsigned long long)alias_hash);\n    // A local with no store has no defining value', 1)
if mode == 'restore':
    candidate = base
elif mode == 'candidate':
    candidate = candidate.replace('    u32 eligible_local_count = local_use_count - 1;', '    // The operand walk removes each disqualified place once. Zero proves\n    // that no LOAD can seed an alias; DEREFERENCE only extends a seeded one.\n    u32 eligible_local_count = local_use_count - 1;', 1)
    candidate = candidate.replace('    // The values the sweeps alias, in assignment order.  About an eighth of a\n    // function\'s values end up aliased, so the pass that hands each one its\n    // local\'s register reads this list — 128 K entries in a self-compile —\n    // instead of asking all 1.01 M values whether they have an alias.', '    // The values the sweeps alias, in assignment order. Register assignment\n    // reads this sparse list instead of testing every value for an alias.', 1)
path.write_text(candidate)
