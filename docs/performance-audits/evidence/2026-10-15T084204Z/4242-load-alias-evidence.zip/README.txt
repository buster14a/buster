Buster #4242: eligibility-guard experiment, rejected for production under its predeclared 0.1% whole-compile work floor.

Base: 35fee905e39941acafb26db6d6ff3f41eb7d8dc7. Production prototype: 1ffe0608d. Full prototype/test history is in evidence/prototype-commits.patch; final combined patch in evidence/prototype-and-tests.patch. This archive is raw research, not a production implementation.

Layout used by the scripts: a session-owned work/ directory containing drivers, bin/, evidence/, inputs/, and an isolated checkout at work/buster. Copy drivers/*.py to work/. See identities.json and the two issue comments for the exact claim and binary/source bindings. Acceptance binaries were tests-off Clang 23.1.1 Release, -O3 -march=native, -g -fno-omit-frame-pointer, no LTO/PGO. Same configured profile path for both arms. CPU 2 on a shared Ryzen 9 7940HS.

Sequence from buster/ (review scripts and preserved build logs for every exact flag):
1. ./build.sh generate --cc clang ; ./build.sh test_self_host --config Release
2. ./build.sh generate --cc clang --no-include-tests --build-directory build/profile
   ./build.sh build --build-directory build/profile --config Release -t ide
   mkdir -p ../bin ../evidence ; cp build/profile/Release/ide ../bin/baseline
3. python3 ../make_controls.py
   build/profile/Release/ide cc -E -Isrc -Ibuild/profile/generated -DBUSTER_UNITY_BUILD=1 -DBUSTER_INCLUDE_TESTS=0 -march=native src/buster/apps/ide/ide.c -o ../inputs/unity.i
   ../bin/baseline cc -march=native -g0 -fregister-allocator=fast ../inputs/unity.i -lm -o ../baseline-unity
4. python3 ../alias_experiment.py census
   ./build.sh build --build-directory build/profile --config Release -t ide
   cp build/profile/Release/ide ../bin/census ; python3 ../run_census.py
   Census uses one instrumented binary, with the guarded arm selected by BUSTER_ALIAS_GUARD=1. These times are diagnostic. Per-function candidate counts and guard outcomes reconstruct two-sweep visits. The mapping signature hashes ordered alias value/root pairs.
5. python3 ../alias_experiment.py candidate
   ./build.sh build --build-directory build/profile --config Release -t ide
   cp build/profile/Release/ide ../bin/candidate
6. Build tools/performance_evidence.c as documented in docs/agents/benchmarking.md and save it as ../performance-evidence.
   With this session's other builds/tests/profilers idle: python3 ../run_work_evidence.py
   The first recorded invocation was refused for a missing output parent, before any samples. The retained driver creates the parent. Each comparison output must be new; do not mix or overwrite observations.
7. python3 ../check_control_population.py ; python3 ../run_zero_controls.py
   Initial retained-argument controls were discovered to have eligible parameter locals; their counts/measurements remain retained. Supplementary source/flag controls establish true zero eligibility; they do not revise the production acceptance criterion.
8. python3 ../validate_candidate.py
   python3 tools/selection_benchmark.py --compiler ../bin/baseline --candidate ../bin/candidate --allocators fast quality --samples 7 --check --cpu 2 --workloads ../inputs/selection --output ../evidence/selection.json --build-description 'Clang 23.1.1 Release -O3 -march=native tests disabled; base 35fee905; guard 1ffe0608d; timing diagnostic on shared 7940HS'
   The first validation predates supplementary disqualified inputs; four additional FAST zero-control objects are compared in run_zero_controls.py. Full object identities and four token/IR/MIR trace comparisons are retained.

The prototype backend-focused test run used b0d82aa05 and passed 558027 assertions across machine_selection_tests,machine_tests. Its final follow-up only names two case indices and was not rebuilt. Full test_all, mode matrix, candidate self-host, sanitizer and hosted production gates were not run because the production candidate failed its acceptance rule. No speed or Zen 5 claim is made. The final submitted branch contains only the audit/archive and keeps production/test/build source at the base revision.

SHA256SUMS binds every archive member except itself. Large frozen compiler executables remain local; their complete hashes are in evidence/identities.json. Buster first-party licensing is unselected/NOASSERTION; see LICENSES/README.md at the base revision. No external implementation is imported.
