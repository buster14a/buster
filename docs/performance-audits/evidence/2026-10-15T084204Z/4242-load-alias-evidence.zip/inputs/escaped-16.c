extern void escape(unsigned long *);
unsigned long f0(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f1(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f2(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f3(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f4(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f5(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f6(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f7(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f8(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f9(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f10(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f11(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f12(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f13(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f14(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
unsigned long f15(unsigned long n){unsigned long x=n+3;escape(&x);return x+n;}
