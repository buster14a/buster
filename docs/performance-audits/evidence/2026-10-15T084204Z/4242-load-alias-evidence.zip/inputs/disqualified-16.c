extern unsigned long input; extern void escape(unsigned long *);
unsigned long f0(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f1(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f2(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f3(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f4(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f5(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f6(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f7(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f8(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f9(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f10(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f11(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f12(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f13(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f14(void){unsigned long x=input+3;escape(&x);return x+input;}
unsigned long f15(void){unsigned long x=input+3;escape(&x);return x+input;}
