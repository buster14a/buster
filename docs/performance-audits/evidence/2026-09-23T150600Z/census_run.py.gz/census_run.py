#!/usr/bin/env python3
"""Issue #988 census runner: raw JSONL, every attempt retained, no trimming."""
import json
import os
import subprocess
import sys
import time

ide, root, inputs, out_path, reps = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5])
cpu = os.environ.get("CENSUS_CPU", "2")
work = os.path.join(os.path.dirname(out_path), "census-objects")
os.makedirs(work, exist_ok=True)

cases = [
    ("tiny", ["-c", os.path.join(inputs, "tiny.c")]),
    ("basic_c_operations", ["-c", os.path.join(root, "tests/basic_c_operations.c")]),
    ("many_4096", ["-c", os.path.join(inputs, "many_4096.c")]),
    ("many_32768", ["-c", os.path.join(inputs, "many_32768.c")]),
    ("line_heavy_4x25000", ["-c", os.path.join(inputs, "line_heavy_4x25000.c")]),
    ("self_host_object", ["-Isrc", "-I" + os.path.join(root, "build/generated"), "-DBUSTER_UNITY_BUILD=1", "-DBUSTER_INCLUDE_TESTS=0", "-c",
                          "src/buster/apps/ide/ide.c"]),
    ("self_host_linked", ["-Isrc", "-I" + os.path.join(root, "build/generated"), "-DBUSTER_UNITY_BUILD=1", "-DBUSTER_INCLUDE_TESTS=0",
                          "src/buster/apps/ide/ide.c", "-lm"]),
]

with open(out_path, "a") as log:
    for rep in range(-1, reps):
        for name, arguments in cases:
            for debug in ("-g", "-g0"):
                output = os.path.join(work, "%s%s.out" % (name, debug))
                command = ["taskset", "-c", cpu, ide, "cc", debug] + arguments + ["-o", output]
                err_path = output + ".stderr"
                with open(err_path, "wb") as err:
                    start = time.monotonic_ns()
                    process = subprocess.Popen(command, cwd=root, stdout=subprocess.DEVNULL, stderr=err)
                    _, status, usage = os.wait4(process.pid, 0)
                    wall = time.monotonic_ns() - start
                process.returncode = os.waitstatus_to_exitcode(status)
                with open(err_path, "rb") as err:
                    stderr = err.read()
                census = [line for line in stderr.decode(errors="replace").splitlines() if line.startswith("DWARF_CENSUS")]
                record = {
                    "case": name, "debug": debug, "rep": rep, "warmup": rep < 0, "returncode": process.returncode, "wall_ns": wall,
                    "maxrss_kib": usage.ru_maxrss, "minflt": usage.ru_minflt, "utime": usage.ru_utime, "stime": usage.ru_stime,
                    "census": [dict(item.split("=", 1) for item in line.split()[1:]) for line in census],
                    "stderr_other": [line for line in stderr.decode(errors="replace").splitlines() if not line.startswith("DWARF_CENSUS")][:5],
                    "output_bytes": os.path.getsize(output) if os.path.exists(output) else None,
                }
                log.write(json.dumps(record) + "\n")
                log.flush()
                print(name, debug, rep, process.returncode, wall // 1000000, "ms", len(census), "census", flush=True)
