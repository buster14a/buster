#!/usr/bin/env python3
"""Issue #988 frozen census inputs. Deterministic: no seeds, no timestamps."""
import hashlib
import os
import sys

out = sys.argv[1]
os.makedirs(out, exist_ok=True)


def write(name, text):
    path = os.path.join(out, name)
    with open(path, "w") as f:
        f.write(text)
    print(hashlib.sha256(text.encode()).hexdigest(), name, len(text), text.count("\n"))


write("tiny.c", "int tiny(int x)\n{\n    return x + 1;\n}\n")


def many(count):
    lines = ["volatile int sink_%d;" % count]
    for i in range(count):
        lines.append("int many_small_function_%06d(int x)\n{\n    sink_%d = x;\n    return x + %d;\n}" % (i, count, i % 97))
    return "\n".join(lines) + "\n"


write("many_4096.c", many(4096))
write("many_32768.c", many(32768))


def line_heavy(functions, statements):
    lines = ["volatile int heavy_sink;"]
    for f in range(functions):
        lines.append("int line_heavy_%d(int x)\n{\n    int v = x;" % f)
        for s in range(statements):
            lines.append("    v = v * %d + heavy_sink;" % (3 + (s % 5)))
        lines.append("    return v;\n}")
    return "\n".join(lines) + "\n"


write("line_heavy_4x25000.c", line_heavy(4, 25000))
