#!/usr/bin/env python3
"""Issue #988 same-binary paired diagnostic: A = full legacy call, B = line-only
legacy call (BUSTER_DWARF_CENSUS_LINE_ONLY=1). Every attempt is retained."""
import hashlib
import json
import os
import random
import subprocess
import sys
import time

ide, root, inputs, out_path, pairs = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5])
selected = sys.argv[6].split(",") if len(sys.argv) > 6 else None
cpu = os.environ.get("PAIRED_CPU", "2")
seed = 988
work = os.path.join(os.path.dirname(out_path), "paired-objects")
os.makedirs(work, exist_ok=True)
generated = os.path.join(root, "build/generated")
cases = [
    ("self_host_object", ["-Isrc", "-I" + generated, "-DBUSTER_UNITY_BUILD=1", "-DBUSTER_INCLUDE_TESTS=0", "-c", "src/buster/apps/ide/ide.c"]),
    ("many_32768", ["-c", os.path.join(inputs, "many_32768.c")]),
    ("many_4096", ["-c", os.path.join(inputs, "many_4096.c")]),
    ("line_heavy_4x25000", ["-c", os.path.join(inputs, "line_heavy_4x25000.c")]),
    ("basic_c_operations", ["-c", os.path.join(root, "tests/basic_c_operations.c")]),
]
if selected:
    cases = [case for case in cases if case[0] in selected]


def run(name, arguments, variant, pmu):
    output = os.path.join(work, "%s-%s.o" % (name, variant))
    env = dict(os.environ)
    env.pop("BUSTER_DWARF_CENSUS_LINE_ONLY", None)
    if variant == "B":
        env["BUSTER_DWARF_CENSUS_LINE_ONLY"] = "1"
    command = ["taskset", "-c", cpu, ide, "cc", "-g"] + arguments + ["-o", output]
    counters = None
    if pmu:
        counters = output + ".pmu"
        command = ["perf", "stat", "-x", ",", "-e", "instructions:u,cycles:u", "-o", counters, "--"] + command
    err_path = output + ".stderr"
    with open(err_path, "wb") as err:
        start = time.monotonic_ns()
        process = subprocess.Popen(command, cwd=root, stdout=subprocess.DEVNULL, stderr=err, env=env)
        _, status, usage = os.wait4(process.pid, 0)
        wall = time.monotonic_ns() - start
    process.returncode = os.waitstatus_to_exitcode(status)
    with open(err_path, "rb") as err:
        stderr = err.read().decode(errors="replace")
    census = [dict(item.split("=", 1) for item in line.split()[1:]) for line in stderr.splitlines() if line.startswith("DWARF_CENSUS")]
    digest = hashlib.sha256(open(output, "rb").read()).hexdigest() if os.path.exists(output) else None
    record = {"case": name, "variant": variant, "returncode": process.returncode, "wall_ns": wall, "maxrss_kib": usage.ru_maxrss,
              "minflt": usage.ru_minflt, "utime": usage.ru_utime, "stime": usage.ru_stime, "census": census, "sha256": digest}
    if counters:
        values = {}
        for line in open(counters):
            fields = line.strip().split(",")
            if len(fields) > 3 and fields[2] in ("instructions:u", "cycles:u"):
                values[fields[2]] = None if fields[0] in ("<not counted>", "<not supported>") else int(fields[0])
                values[fields[2] + ":running_pct"] = fields[4] if len(fields) > 4 else None
        record["pmu"] = values
    os.remove(output)
    return record


rng = random.Random(seed)
with open(out_path, "a") as log:
    for name, arguments in cases:
        for variant in ("A", "B", "A", "B"):
            record = run(name, arguments, variant, False)
            record.update(phase="warmup")
            log.write(json.dumps(record) + "\n")
        first = rng.choice(("AB", "BA"))
        for pair in range(pairs):
            order = first if pair % 2 == 0 else first[::-1]
            for variant in order:
                record = run(name, arguments, variant, False)
                record.update(phase="timing", pair=pair, order=order)
                log.write(json.dumps(record) + "\n")
            log.flush()
        for replay in range(5):
            for variant in ("A", "B") if replay % 2 == 0 else ("B", "A"):
                record = run(name, arguments, variant, True)
                record.update(phase="pmu", replay=replay)
                log.write(json.dumps(record) + "\n")
        log.flush()
        print(name, "done", flush=True)
