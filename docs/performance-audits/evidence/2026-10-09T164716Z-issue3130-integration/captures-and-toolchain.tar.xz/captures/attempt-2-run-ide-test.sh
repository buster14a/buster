#!/bin/bash
set +e
WORKTREE=/workspace/scratch/bd2658952eb2/issue3130-recovery3-checkout
RUN_LOG=$1
STATUS_FILE=$2
cd "$WORKTREE" || exit 125
source /workspace/scratch/bd2658952eb2/toolchain-recovery-20261009/env.sh
runner_pid=$$
runner_pgid=$(ps -o pgid= -p "$$" | tr -d ' ')
runner_sid=$(ps -o sid= -p "$$" | tr -d ' ')
{
  printf 'command=env BUSTER_SANITIZER_POLICY_MODE=unsupported ./build/Release/ide test --verbose=1\n'
  printf 'commit='; git rev-parse HEAD
  printf 'tree='; git rev-parse HEAD^{tree}
  printf 'runner_pid=%s runner_pgid=%s runner_sid=%s\n' "$runner_pid" "$runner_pgid" "$runner_sid"
  printf 'start_utc='; date -u +%Y-%m-%dT%H:%M:%SZ
  printf 'ide_sha256='; sha256sum build/Release/ide | cut -d' ' -f1
  printf 'clang_version='; clang --version | head -n 1
  printf 'tcc_version='; tcc -version | head -n 1
  /usr/bin/time -f 'elapsed_seconds=%e\nmax_rss_kib=%M' env BUSTER_SANITIZER_POLICY_MODE=unsupported ./build/Release/ide test --verbose=1
  run_status=$?
  printf 'exit_status=%s\n' "$run_status"
  printf 'end_utc='; date -u +%Y-%m-%dT%H:%M:%SZ
} >> "$RUN_LOG" 2>&1
run_status=$?
printf '%s\n' "$run_status" > "$STATUS_FILE.tmp"
mv "$STATUS_FILE.tmp" "$STATUS_FILE"
exit "$run_status"
