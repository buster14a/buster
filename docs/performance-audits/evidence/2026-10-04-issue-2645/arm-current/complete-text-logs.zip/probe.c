long probe(long x) { return x * 3 + 1; }
