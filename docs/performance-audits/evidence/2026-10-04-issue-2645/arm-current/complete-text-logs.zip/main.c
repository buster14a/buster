extern long probe(long); int main(void) { return probe(9) != 28; }
