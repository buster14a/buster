from pathlib import Path
import subprocess

root = Path('/home/david/Documents/Codex/2026-10-15/i/work/buster')
path = root / 'src/buster/lib/compiler/codegen/machine_x86_64.c'
text = path.read_text()

def put(old, new):
    global text
    assert text.count(old) == 1, (old[:100], text.count(old))
    text = text.replace(old, new)

prefix = '''// Temporary diagnostic census; never a performance acceptance build.
BUSTER_GLOBAL_LOCAL u64 selection_census_ns[13];
BUSTER_GLOBAL_LOCAL u64 selection_census_work[24];
BUSTER_GLOBAL_LOCAL void selection_census_tick(TimeDataType* last, u32 phase)
{
    TimeDataType now = timestamp_take();
    selection_census_ns[phase] += timestamp_ns_between(*last, now);
    *last = now;
}
BUSTER_GLOBAL_LOCAL void selection_census_stream(MachineBuilderStream const* stream)
{
    u64 chunks = 0;
    for (MachineBuilderChunk const* chunk = stream->first; chunk; chunk = chunk->next)
    {
        chunks += 1;
    }
    selection_census_work[16] += chunks;
    selection_census_work[17] += chunks * (sizeof(MachineBuilderChunk) + (u64)stream->chunk_capacity * stream->element_size);
    selection_census_work[18] += (u64)stream->total_count * stream->element_size;
    selection_census_work[19] += chunks > 1 ? (u64)stream->total_count * stream->element_size : 0;
}
BUSTER_GLOBAL_LOCAL void selection_census_print(void)
{
    for (u32 i = 0; i < 13; i += 1)
    {
        string_print(S8("SELECT_PHASE phase={u32} ns={u64}\\n"), i, selection_census_ns[i]);
    }
    for (u32 i = 0; i < 24; i += 1)
    {
        string_print(S8("SELECT_WORK counter={u32} count={u64}\\n"), i, selection_census_work[i]);
    }
}

'''
put('MachineSelectResult machine_select_canonical_function_x86_64(', prefix + 'MachineSelectResult machine_select_canonical_function_x86_64(')
put('''    MachineSelectResult result = {
        .failed_opcode = IR_OPCODE_COUNT,
    };''', '''    TimeDataType census_last = timestamp_take();
    MachineSelectResult result = {
        .failed_opcode = IR_OPCODE_COUNT,
    };''')
boundaries = [
    ('    // Every per-value fact the prepasses', 0),
    ('    // Canonical publication owns instruction spans.', 1),
    ('    // Block-parameter incoming values are uses', 2),
    ('    // Classification pass: direct locals become', 3),
    ("    // Aliased load results share their local's virtual register:", 4),
    ('    // A cast that copies a constant materializes', 5),
    ('    selector.virtual_register_count = selector.builder.virtual_registers.total_count;', 6),
    ('    u32 canonical_edge_offset = selector.builder.edges.total_count;', 7),
    ('    if (!machine_selection_finish_canonical_edges(arena, &result.function, function, canonical_edge_offset,', 8),
    ('    bool select_predicates = simd_operation_count != 0;', 9),
    ('    result.mutable_virtual_register_count = machine_function_compact_virtual_registers(arena, &result.function);', 10),
    ('    if (preserve_debug_values &&', 11),
    ('    result.canonical_block_entries = selector.block_entries;', 12),
]
for marker, phase in boundaries:
    put(marker, f'    selection_census_tick(&census_last, {phase});\n' + marker)
put('''                constant_folded_reads[instruction->operands[0].value] += 1;''', '''                constant_folded_reads[instruction->operands[0].value] += 1;
                selection_census_work[6] += 1;''')
put('''                constant_folded_reads[instruction->operands[1].value] += 1;''', '''                constant_folded_reads[instruction->operands[1].value] += 1;
                selection_census_work[7] += 1;''')
put('''            bool selected_result = instruction->result.value < function->value_count &&''', '''            selection_census_work[8] += instruction->opcode == IR_OPCODE_CAST;
            selection_census_work[9] += instruction->opcode == IR_OPCODE_INDEX;
            bool selected_result = instruction->result.value < function->value_count &&''')
put('''            if (value < function->value_count && constant_folded_reads[value] && constant_folded_reads[value] == value_uses[value].use_count)
            {
                selector.fused_dead[value] = 1;''', '''            if (value < function->value_count && constant_folded_reads[value] && constant_folded_reads[value] == value_uses[value].use_count)
            {
                selection_census_work[10] += 1;
                selector.fused_dead[value] = 1;''')
put('''    result.function = machine_function_builder_finish(arena, &selector.builder);''', '''    selection_census_stream(&selector.builder.instructions);
    selection_census_stream(&selector.builder.virtual_registers);
    selection_census_stream(&selector.builder.blocks);
    selection_census_stream(&selector.builder.edges);
    selection_census_stream(&selector.builder.block_parameters);
    selection_census_stream(&selector.builder.edge_copy_sources);
    selection_census_stream(&selector.immediates);
    selection_census_stream(&selector.stack_slots);
    selection_census_stream(&selector.call_targets);
    selection_census_stream(&selector.switch_cases);
    result.function = machine_function_builder_finish(arena, &selector.builder);''')
put('''    result.supported = true;
    result.selector_certified = true;''', '''    selection_census_work[0] += 1;
    selection_census_work[1] += walk_ordinal;
    selection_census_work[2] += function->value_count;
    selection_census_work[3] += function->block_count;
    selection_census_work[4] += candidate_count;
    selection_census_work[5] += alias_count;
    selection_census_work[11] += sizeof(u32) * value_capacity;
    selection_census_work[12] += zero_region_bytes + none_region_bytes;
    selection_census_work[13] += result.function.line_mark_count;
    selection_census_work[14] += result.function.instruction_count;
    selection_census_work[15] += result.function.virtual_register_count;
    selection_census_work[20] += canonical_layout != 0;
    selection_census_work[21] += function->block_count == 1;
    selection_census_work[22] += candidate_count == 0;
    selection_census_work[23] += alias_count == 0;
    result.supported = true;
    result.selector_certified = true;''')
path.write_text(text)

path = root/'src/buster/apps/ide/selection_benchmark.h'
text = path.read_text()
put('''    return sample;
}''', '''    selection_census_print();
    memset(selection_census_ns, 0, sizeof(selection_census_ns));
    memset(selection_census_work, 0, sizeof(selection_census_work));
    return sample;
}''')
path.write_text(text)
path = root/'src/buster/apps/ide/ide.c'
text = path.read_text()
put('''        string_print(S8("CODEGEN_MIR mutable_virtual_registers={u64}\\n"), compile.codegen_statistics.mutable_virtual_register_count);''', '''        selection_census_print();
        string_print(S8("CODEGEN_MIR mutable_virtual_registers={u64}\\n"), compile.codegen_statistics.mutable_virtual_register_count);''')
path.write_text(text)
patch = subprocess.check_output(['git','diff'],cwd=root)
(root.parent/'diagnostic.patch').write_bytes(patch)
print('Installed temporary census; patch retained.')
