from pathlib import Path
p=Path('src/buster/lib/compiler/codegen/register_allocator_fast.c');s=p.read_text()
# The rejected conservative gate changed a successful unity frame. Restore
# original admission and use a sufficient failure certificate after the solve.
s=s.replace('    u32 home_counts[2] = {0};\n','',1)
s=s.replace('        bool eligible = slot_needed[value] && !home_opaque[value];\n        home_count += eligible;\n        home_counts[function->virtual_registers[value].register_class == MACHINE_REGISTER_CLASS_VECTOR] += eligible;','        home_count += slot_needed[value] && !home_opaque[value];',1)
s=s.replace('home_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT &&\n                             machine_fast_block_color_fits(home_counts[0], function->block_count) &&\n                             machine_fast_block_color_fits(home_counts[1], function->block_count);','home_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT;',1)
s=s.replace('slot_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT &&\n                             machine_fast_block_color_fits(shareable_slots, function->block_count);','slot_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT;',1)
start=s.index('// Each new object can test every earlier color,')
end=s.index('BUSTER_GLOBAL_LOCAL u32 machine_fast_color_block_objects',start)
budget=s[start:end]
# Keep the numerical bound only to bypass the certificate on small populations.
budget=budget.replace('// Each new object can test every earlier color, and each test can read every\n// block word. Admit that upper bound before building occupancy; a memory cap\n// alone allowed closure followed by 25 M comparisons that were all discarded.','// Small populations cannot exhaust the comparison budget and need no\n// failure-certificate census. This upper bound never rejects a coloring.')
s=s[:start]+s[end:]
s=s.replace('#define MACHINE_FAST_BLOCK_COLOR_WORD_LIMIT 25000000u\n','',1)
insert=s.index('// Loop closure asks only whether a range meets a backward edge,')
helper=r'''
#define MACHINE_FAST_BLOCK_COLOR_WORD_LIMIT 25000000u
'''+budget+r'''
// If every home occupies one common block, same-class homes form a clique:
// the greedy scan can never merge their groups. Every pair must read through
// at least the later first-occupied word. Sum that lower bound by first-word
// histogram; exceeding the old budget proves it would discard this coloring.
// No successful coloring is rejected. The solve is still needed for the proof,
// but the dense occupancy transpose and quadratic group scan are avoided.
BUSTER_GLOBAL_LOCAL bool machine_fast_home_color_exhausted(Arena* arena, MachineFunction const* function,
    u32 const* values, u32 count, u32 words, u64 const* reads, u64 const* writes, u64 const* live_in, u64 const* live_out)
{
    bool exhausted = false;
    if (!machine_fast_block_color_fits(count, function->block_count))
    {
        u32 counts[2] = {0};
        for (u32 object = 0; object < count; object += 1)
        {
            counts[function->virtual_registers[values[object]].register_class == MACHINE_REGISTER_CLASS_VECTOR] += 1;
        }
        if (!machine_fast_block_color_fits(counts[0], function->block_count) ||
            !machine_fast_block_color_fits(counts[1], function->block_count))
        {
            u32 common = UINT32_MAX;
            for (u32 block = 0; common == UINT32_MAX && block < function->block_count; block += 1)
            {
                bool full = true;
                for (u32 word = 0; full && word < words; word += 1)
                {
                    u64 cell = (u64)block * words + word;
                    u64 mask = word + 1u == words && (count & 63u) ? (UINT64_C(1) << (count & 63u)) - 1u : UINT64_MAX;
                    full = ((reads[cell] | writes[cell] | live_in[cell] | live_out[cell]) & mask) == mask;
                }
                common = full ? block : common;
            }
            if (common != UINT32_MAX)
            {
                u64 mark = arena->position;
                u32 block_words = (u32)(((u64)function->block_count + 63u) / 64u);
                u64* seen = arena_allocate_zeroed(arena, u64, words);
                u32* first_counts = arena_allocate_zeroed(arena, u32, (u64)block_words * 2u);
                for (u32 block = 0; block <= common; block += 1)
                {
                    for (u32 word = 0; word < words; word += 1)
                    {
                        u64 cell = (u64)block * words + word;
                        u64 present = reads[cell] | writes[cell] | live_in[cell] | live_out[cell];
                        u64 first = present & ~seen[word];
                        seen[word] |= present;
                        while (first)
                        {
                            u32 object = word * 64u + trailing_zeroes_u64(first);
                            first &= first - 1u;
                            if (object < count)
                            {
                                bool vector = function->virtual_registers[values[object]].register_class == MACHINE_REGISTER_CLASS_VECTOR;
                                first_counts[(u64)vector * block_words + block / 64u] += 1;
                            }
                        }
                    }
                }
                for (u32 pool = 0; !exhausted && pool < 2u; pool += 1)
                {
                    u64 earlier = 0;
                    u64 cost = 0;
                    for (u32 word = 0; !exhausted && word < block_words; word += 1)
                    {
                        u64 entries = first_counts[(u64)pool * block_words + word];
                        u64 pairs = entries * earlier + (entries ? entries * (entries - 1u) / 2u : 0);
                        exhausted = pairs > (MACHINE_FAST_BLOCK_COLOR_WORD_LIMIT - cost) / (word + 1u);
                        if (!exhausted)
                        {
                            cost += pairs * (word + 1u);
                            earlier += entries;
                        }
                    }
                }
                arena_set_position(arena, mark);
            }
        }
    }
    return exhausted;
}

'''
s=s[:insert]+helper+s[insert:]
old='BUSTER_GLOBAL_LOCAL void machine_fast_close_live_ranges(Arena* arena, MachineFunction const* function, MachineFastPrepass const* prepass, u64 const* reads,\n                                                        u64 const* writes, u32 words, u32* starts, u32* ends, u64* occupied_blocks)'
assert old in s
new='BUSTER_GLOBAL_LOCAL bool machine_fast_close_live_ranges_checked(Arena* arena, MachineFunction const* function, MachineFastPrepass const* prepass, u64 const* reads,\n    u64 const* writes, u32 words, u32* starts, u32* ends, u64* occupied_blocks, u32 const* color_values, u32 color_count)'
s=s.replace(old,new,1)
start=s.index('BUSTER_GLOBAL_LOCAL bool machine_fast_close_live_ranges_checked')
end=s.index('\n#if BUSTER_INCLUDE_TESTS',start)
part=s[start:end]
needle='    for (u32 block_index = 0; block_index < block_count; block_index += 1)'
part=part.replace(needle,'    bool exhausted = occupied_blocks && color_count && machine_fast_home_color_exhausted(arena, function, color_values, color_count,\n        words, reads, writes, live_in, live_out);\n    for (u32 block_index = 0; !exhausted && block_index < block_count; block_index += 1)',1)
# The original function ends with one blank line before its closing brace.
part=part.rstrip();assert part.endswith('}')
part=part[:-1]+'    return !exhausted;\n}\n\n'+old+r'''
{
    machine_fast_close_live_ranges_checked(arena, function, prepass, reads, writes, words, starts, ends, occupied_blocks, 0, 0);
}
'''
s=s[:start]+part+s[end:]
needle='        machine_fast_close_live_ranges(arena, function, prepass, reads, writes, words, starts, ends, occupied);\n        for (u32 home = 0; home < home_count; home += 1)'
assert needle in s
s=s.replace(needle,'        bool closed = machine_fast_close_live_ranges_checked(arena, function, prepass, reads, writes, words, starts, ends, occupied,\n            home_values, record_occupancy ? home_count : 0);\n        if (!closed)\n        {\n            result = (MachineFastBlockObjects){0};\n        }\n        for (u32 home = 0; closed && home < home_count; home += 1)',1)
needle='''        block_pool_size = machine_fast_color_block_objects(arena, function, &objects, true, false, pool_indices, 0, 0);
        if (block_pool_size != UINT32_MAX)
        {
            block_vector_pool_size = machine_fast_color_block_objects(arena, function, &objects, true, true, pool_indices, 0, 0);
        }'''
assert needle in s
s=s.replace(needle,'''        if (objects.count)
        {
            block_pool_size = machine_fast_color_block_objects(arena, function, &objects, true, false, pool_indices, 0, 0);
            if (block_pool_size != UINT32_MAX)
            {
                block_vector_pool_size = machine_fast_color_block_objects(arena, function, &objects, true, true, pool_indices, 0, 0);
            }
        }''',1)
p.write_text(s)
p=Path('docs/agents/machine.md');s=p.read_text();start=s.index('  Block coloring also requires its worst-case');end=s.index('- Retroactive allocation edits',start)
s=s[:start]+'''  Large home populations have an additional sufficient failure check after
  liveness converges. If every home occupies one common block, same-class
  homes cannot share a group. A histogram of first occupied block words gives
  a lower bound on the old greedy scan's word comparisons. Only when that
  lower bound exceeds `MACHINE_FAST_BLOCK_COLOR_WORD_LIMIT` does placement
  skip the occupancy transpose and greedy scan and take the existing fallback.
  This preserves every successful coloring. The conservative upper bound is
  used only to bypass this check on small populations. The separate prepass
  value-liveness cap is unchanged. Empty interval home pools skip their
  instruction-row histograms using the existing eligibility counts.

'''+s[end:];p.write_text(s)
