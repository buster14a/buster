from pathlib import Path
root=Path('/home/david/Documents/Codex/2026-10-15/iden/work/buster')
p=root/'src/buster/lib/compiler/codegen/register_allocator_fast.c'
s=p.read_text()
start=s.index('// Retroactive edits target points')
end=s.index('// True when the virtual register has no use',start)
sort=r'''// Equal-point repair order is executable meaning. Small unsorted streams use
// stable ping-pong merges; large streams use at most four stable byte passes.
// Uniform key bytes need no pass, and ordered streams never move records.
#define MACHINE_FAST_RADIX_EDIT_THRESHOLD 256u
BUSTER_GLOBAL_LOCAL void machine_fast_sort_edits(MachineEdit* edits, MachineEdit* scratch, u32 count)
{
    WORK_LEDGER_RECORD(MACHINE_RETRO_SORT_EDITS, count);
    bool ordered = true;
    u32 differing = 0;
    for (u32 index = 1; index < count; index += 1)
    {
        ordered &= edits[index - 1u].point <= edits[index].point;
        differing |= edits[0].point ^ edits[index].point;
    }
    if (!ordered)
    {
        MachineEdit* source = edits;
        MachineEdit* destination = scratch;
        if (count >= MACHINE_FAST_RADIX_EDIT_THRESHOLD)
        {
            for (u32 shift = 0; shift < 32u; shift += 8u)
            {
                if (!((differing >> shift) & 0xffu))
                {
                    continue;
                }
                u32 offsets[256] = {0};
                for (u32 index = 0; index < count; index += 1)
                {
                    offsets[(source[index].point >> shift) & 0xffu] += 1;
                }
                u32 offset = 0;
                for (u32 bucket = 0; bucket < 256u; bucket += 1)
                {
                    u32 entries = offsets[bucket];
                    offsets[bucket] = offset;
                    offset += entries;
                }
                for (u32 index = 0; index < count; index += 1)
                {
                    destination[offsets[(source[index].point >> shift) & 0xffu]++] = source[index];
                }
                WORK_LEDGER_RECORD(MACHINE_RETRO_SORT_RECORD_MOVES, count);
                MachineEdit* exchanged = source;
                source = destination;
                destination = exchanged;
            }
        }
        else
        {
            for (u32 width = 1; width < count; width *= 2u)
            {
                for (u32 start = 0; start < count; start += 2u * width)
                {
                    u32 middle = BUSTER_MIN(start + width, count);
                    u32 limit = BUSTER_MIN(start + 2u * width, count);
                    u32 left = start;
                    u32 right = middle;
                    u32 out = start;
                    while (left < middle && right < limit)
                    {
                        destination[out++] = source[right].point < source[left].point ? source[right++] : source[left++];
                    }
                    while (left < middle) destination[out++] = source[left++];
                    while (right < limit) destination[out++] = source[right++];
                }
                WORK_LEDGER_RECORD(MACHINE_RETRO_SORT_RECORD_MOVES, count);
                MachineEdit* exchanged = source;
                source = destination;
                destination = exchanged;
            }
        }
        if (source != edits)
        {
            memcpy(edits, source, (u64)count * sizeof(*edits));
            WORK_LEDGER_RECORD(MACHINE_RETRO_SORT_RECORD_MOVES, count);
        }
    }
}

#if BUSTER_INCLUDE_TESTS
bool machine_fast_sort_edits_test(Arena* arena)
{
    bool result = true;
    u32 counts[] = {0, 1, 2, 3, 31, 63, 64, 127, 255, 256, 257, 511, 1024};
    for (u32 shape = 0; shape < 8u; shape += 1)
    {
        for (u32 item = 0; item < BUSTER_ARRAY_LENGTH(counts); item += 1)
        {
            u64 mark = arena->position;
            u32 count = counts[item];
            MachineEdit* guarded = arena_allocate(arena, MachineEdit, (u64)count + 2u);
            MachineEdit* scratch = arena_allocate(arena, MachineEdit, (u64)count + 2u);
            MachineEdit* expected = arena_allocate(arena, MachineEdit, count ? count : 1u);
            memset(guarded, 0xa5, ((u64)count + 2u) * sizeof(*guarded));
            memset(scratch, 0x5a, ((u64)count + 2u) * sizeof(*scratch));
            MachineEdit* edits = guarded + 1;
            u32 random = 0x31974adbu;
            for (u32 index = 0; index < count; index += 1)
            {
                random = random * 1664525u + 1013904223u;
                u32 point = shape == 0 ? index : shape == 1 ? count - index : shape == 2 ? UINT32_MAX :
                            shape == 3 ? random % 7u : shape == 4 ? random & 0xffu :
                            shape == 5 ? (random & 0xffu) << 24u : shape == 6 ? random : index & 1u ? 0 : UINT32_MAX;
                edits[index] = (MachineEdit){.point = point, .kind = (u16)(index + 3u), .flags = (u16)(index ^ 0x55aau),
                                             .subject = index, .location = ~index};
                expected[index] = edits[index];
            }
            // Independent stable insertion oracle compares every record byte,
            // including duplicate keys with different subjects and flags.
            for (u32 index = 1; index < count; index += 1)
            {
                MachineEdit moved = expected[index];
                u32 position = index;
                while (position && expected[position - 1u].point > moved.point)
                {
                    expected[position] = expected[position - 1u];
                    position -= 1u;
                }
                expected[position] = moved;
            }
            machine_fast_sort_edits(edits, scratch + 1, count);
            result &= !memcmp(edits, expected, (u64)count * sizeof(*edits));
            machine_fast_sort_edits(edits, scratch + 1, count);
            result &= !memcmp(edits, expected, (u64)count * sizeof(*edits));
            MachineEdit edit_guard;
            MachineEdit scratch_guard;
            memset(&edit_guard, 0xa5, sizeof(edit_guard));
            memset(&scratch_guard, 0x5a, sizeof(scratch_guard));
            result &= !memcmp(guarded, &edit_guard, sizeof(edit_guard)) && !memcmp(guarded + count + 1u, &edit_guard, sizeof(edit_guard));
            result &= !memcmp(scratch, &scratch_guard, sizeof(scratch_guard)) && !memcmp(scratch + count + 1u, &scratch_guard, sizeof(scratch_guard));
            arena_set_position(arena, mark);
        }
    }
    return result;
}
#endif

'''
s=s[:start]+sort+s[end:]
s=s.replace('#include <buster/lib/os.h>','#include <buster/lib/os.h>\n#include <buster/lib/compiler/work_ledger.h>')
needle='#define MACHINE_FAST_BLOCK_COLOR_WORD_LIMIT 25000000u\n'
budget=r'''
// Each new object can test every earlier color, and each test can read every
// block word. Admit that upper bound before building occupancy; a memory cap
// alone allowed closure followed by 25 M comparisons that were all discarded.
BUSTER_GLOBAL_LOCAL bool machine_fast_block_color_fits(u32 count, u32 block_count)
{
    u64 words = ((u64)block_count + 63u) / 64u;
    u64 pairs = count ? (u64)count * (count - 1u) / 2u : 0;
    return !words || pairs <= MACHINE_FAST_BLOCK_COLOR_WORD_LIMIT / words;
}

#if BUSTER_INCLUDE_TESTS
bool machine_fast_block_color_budget_test(void)
{
    bool result = machine_fast_block_color_fits(0, UINT32_MAX) && machine_fast_block_color_fits(1, UINT32_MAX) &&
                  machine_fast_block_color_fits(1000, 64) && !machine_fast_block_color_fits(1000, 4000) &&
                  !machine_fast_block_color_fits(UINT32_MAX, UINT32_MAX);
    for (u32 words = 1; words <= 8u; words += 1)
    {
        u32 count = 1;
        while ((u64)count * (count - 1u) / 2u <= MACHINE_FAST_BLOCK_COLOR_WORD_LIMIT / words) count += 1u;
        result &= machine_fast_block_color_fits(count - 1u, words * 64u);
        result &= !machine_fast_block_color_fits(count, words * 64u);
    }
    return result;
}
#endif
'''
s=s.replace(needle,needle+budget,1)
s=s.replace('    u32 row_count = function->instruction_count + 2u;\n    u32* row_offsets', '    u32 row_count = function->instruction_count + 2u;\n    WORK_LEDGER_RECORD(MACHINE_HOME_COLOR_HISTOGRAM_ROWS, row_count);\n    u32* row_offsets',1)
s=s.replace('                comparisons += 1;','                comparisons += 1;\n                WORK_LEDGER_RECORD(MACHINE_BLOCK_COLOR_WORD_COMPARISONS, 1);',1)
s=s.replace('MachineStackPlacement machine_fast_placement_build_prepassed(Arena* arena, MachineFunction* function, MachineFastPrepass const* prepass,','BUSTER_GLOBAL_LOCAL MachineStackPlacement machine_fast_placement_scan_prepassed(Arena* arena, MachineFunction* function, MachineFastPrepass const* prepass,',1)
frame_start=s.index('        // Frame layout runs after the scan:')
frame_end=s.index('\n    }\n\n    return placement;\n}',frame_start)
frame=s[frame_start:frame_end]
assert 'state.' not in frame
frame='\n'.join(line[4:] if line.startswith('    ') else line for line in frame.split('\n'))
frame=frame.replace('    u32 home_count = 0;','    u32 home_count = 0;\n    u32 home_counts[2] = {0};',1)
frame=frame.replace('        home_count += slot_needed[value] && !home_opaque[value];','        bool eligible = slot_needed[value] && !home_opaque[value];\n        home_count += eligible;\n        home_counts[function->virtual_registers[value].register_class == MACHINE_REGISTER_CLASS_VECTOR] += eligible;',1)
frame=frame.replace('home_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT;','home_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT &&\n                             machine_fast_block_color_fits(home_counts[0], function->block_count) &&\n                             machine_fast_block_color_fits(home_counts[1], function->block_count);',1)
frame=frame.replace('    for (u32 register_index = 0; register_index < function->virtual_register_count; register_index += 1)\n    {\n        // A home', '    u32 eligible_home_counts[2] = {0};\n    for (u32 register_index = 0; register_index < function->virtual_register_count; register_index += 1)\n    {\n        // A home',1)
frame=frame.replace('        home_starts[register_index] = colorable ? home_starts[register_index] : UINT32_MAX;','        home_starts[register_index] = colorable ? home_starts[register_index] : UINT32_MAX;\n        eligible_home_counts[function->virtual_registers[register_index].register_class == MACHINE_REGISTER_CLASS_VECTOR] += colorable;',1)
frame=frame.replace('slot_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT;','slot_color_bytes <= MACHINE_FAST_BLOCK_COLOR_PLANE_LIMIT &&\n                             machine_fast_block_color_fits(shareable_slots, function->block_count);',1)
frame=frame.replace(': machine_fast_color_homes(arena, function, slot_needed, home_starts, home_ends, false, pool_indices);',': eligible_home_counts[0] ? machine_fast_color_homes(arena, function, slot_needed, home_starts, home_ends, false, pool_indices) : 0;')
frame=frame.replace(': machine_fast_color_homes(arena, function, slot_needed, home_starts, home_ends, true, pool_indices);',': eligible_home_counts[1] ? machine_fast_color_homes(arena, function, slot_needed, home_starts, home_ends, true, pool_indices) : 0;')
frame=frame.replace('    placement.capacity_exceeded = !frame_capacity;','    placement.capacity_exceeded = !frame_capacity;\n    placement.valid = frame_capacity;')
s=s[:frame_start]+'        placement.valid = true;'+s[frame_end:]
insert=s.index('\nBUSTER_GLOBAL_LOCAL MachineStackPlacement machine_fast_placement_build_core')
finish='''
// Frame construction consumes only a completed scan and immutable prepass.
// QUALITY calls it after its traffic and pin checks accept a probe.
BUSTER_GLOBAL_LOCAL void machine_fast_placement_finish(Arena* arena, MachineFunction* function, MachineFastPrepass const* prepass,
                                                       MachineStackPlacement* output)
{
    MachineStackPlacement placement = *output;
    MachineTargetDescription const* description = function->target;
'''+frame+'''
    *output = placement;
}

MachineStackPlacement machine_fast_placement_build_prepassed(Arena* arena, MachineFunction* function, MachineFastPrepass const* prepass,
                                                             u32 const* pinned_registers, u64 pinned_mask, u64 const* pin_active_masks,
                                                             u32 const* pin_span_starts, u32 const* pin_span_ends,
                                                             MachinePinSplitEntry const* split_entries, u32 split_entry_count,
                                                             MachinePinSplitStore const* split_stores, u32 split_store_count)
{
    MachineStackPlacement placement = machine_fast_placement_scan_prepassed(arena, function, prepass, pinned_registers, pinned_mask,
        pin_active_masks, pin_span_starts, pin_span_ends, split_entries, split_entry_count, split_stores, split_store_count);
    if (placement.valid)
    {
        machine_fast_placement_finish(arena, function, prepass, &placement);
    }
    return placement;
}
'''
s=s[:insert]+finish+s[insert:]
s=s.replace('// `machine_fast_placement_build_pinned` then lays the frame out','// `machine_fast_placement_finish` then lays the frame out')
p.write_text(s)
q=root/'src/buster/lib/compiler/codegen/register_allocator_quality.c'
s=q.read_text()
s=s.replace('    MachineStackPlacement baseline = machine_fast_placement_build_prepassed(', '    BUSTER_QUALITY_COUNT(placement_frame_layouts, 1);\n    MachineStackPlacement baseline = machine_fast_placement_build_prepassed(',1)
s=s.replace('        MachineStackPlacement placement = machine_fast_placement_build_prepassed(arena, function, &prepass, pinned_registers, pinned_mask,', '        u64 placement_mark = arena->position;\n        MachineStackPlacement placement = machine_fast_placement_scan_prepassed(arena, function, &prepass, pinned_registers, pinned_mask,',1)
s=s.replace('        // Accept only on modeled improvement,','        BUSTER_QUALITY_COUNT(placement_probe_bytes, arena->position - placement_mark);\n        // Accept only on modeled improvement,',1)
s=s.replace('            BUSTER_QUALITY_COUNT(placement_cost_rejections, 1);','            BUSTER_QUALITY_COUNT(placement_cost_rejections, 1);\n            BUSTER_QUALITY_COUNT(placement_rejected_bytes, arena->position - placement_mark);\n            arena_set_position(arena, placement_mark);',1)
s=s.replace('            BUSTER_QUALITY_COUNT(pin_verification_rejections, 1);','            BUSTER_QUALITY_COUNT(pin_verification_rejections, 1);\n            BUSTER_QUALITY_COUNT(placement_rejected_bytes, arena->position - placement_mark);\n            arena_set_position(arena, placement_mark);',1)
needle='        placement.pinned_register_count = pinned_value_count;'
finish='''        // Rejected scans need no home closure, coloring or frame census.
        // Keep the baseline alive until the accepted probe also passes the
        // ordinary frame-capacity check; a capacity refusal retries as before.
        BUSTER_QUALITY_COUNT(placement_frame_layouts, 1);
        machine_fast_placement_finish(arena, function, &prepass, &placement);
        if (!placement.valid)
        {
            BUSTER_QUALITY_COUNT(placement_cost_rejections, 1);
            BUSTER_QUALITY_COUNT(placement_rejected_bytes, arena->position - placement_mark);
            arena_set_position(arena, placement_mark);
            if (attempt == 0 && split_entry_count)
            {
                continue;
            }
            if (degradable)
            {
                attempt = 1;
                continue;
            }
            break;
        }
'''
s=s.replace(needle,finish+needle,1)
q.write_text(s)
p=root/'src/buster/lib/compiler/codegen/register_allocator_fast_internal.h';s=p.read_text().replace('BUSTER_F_DECL bool machine_fast_close_live_ranges_test', 'BUSTER_F_DECL bool machine_fast_sort_edits_test(Arena* arena);\nBUSTER_F_DECL bool machine_fast_block_color_budget_test(void);\nBUSTER_F_DECL bool machine_fast_close_live_ranges_test',1);p.write_text(s)
p=root/'src/buster/lib/compiler/codegen/register_allocator_quality_internal.h';s=p.read_text().replace('    X(placement_probes) \\', '    X(placement_probes) \\\n    X(placement_probe_bytes) \\\n    X(placement_rejected_bytes) \\\n    X(placement_frame_layouts) \\',1);p.write_text(s)
p=root/'src/buster/lib/compiler/work_ledger.h';s=p.read_text().replace('    X(MACHINE_PLACEMENT_EDITS, machine, placement_edits) \\', '    X(MACHINE_PLACEMENT_EDITS, machine, placement_edits) \\\n    X(MACHINE_RETRO_SORT_EDITS, machine, retro_sort_edits) \\\n    X(MACHINE_RETRO_SORT_RECORD_MOVES, machine, retro_sort_record_moves) \\\n    X(MACHINE_HOME_COLOR_HISTOGRAM_ROWS, machine, home_color_histogram_rows) \\\n    X(MACHINE_BLOCK_COLOR_WORD_COMPARISONS, machine, block_color_word_comparisons) \\',1);p.write_text(s)
p=root/'src/buster/tests/compiler/codegen/machine_test.c';s=p.read_text().replace('    BUSTER_TEST(arguments, machine_fast_close_live_ranges_test(arguments->arena));','    BUSTER_TEST(arguments, machine_fast_sort_edits_test(arguments->arena));\n    BUSTER_TEST(arguments, machine_fast_block_color_budget_test());\n    BUSTER_TEST(arguments, machine_fast_close_live_ranges_test(arguments->arena));',1);p.write_text(s)
