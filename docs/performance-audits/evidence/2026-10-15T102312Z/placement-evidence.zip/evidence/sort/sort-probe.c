#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
typedef uint32_t u32;typedef uint16_t u16;typedef uint64_t u64;
typedef struct {u32 point;u16 kind;u16 flags;u32 subject;u32 location;} MachineEdit;
#define BUSTER_GLOBAL_LOCAL static
#define BUSTER_MIN(a,b) ((a)<(b)?(a):(b))
#define MACHINE_FAST_RADIX_EDIT_THRESHOLD 256u
static u64 moves;
#define WORK_LEDGER_RECORD(name, amount) (moves += (amount))
BUSTER_GLOBAL_LOCAL void baseline_sort(MachineEdit* edits, MachineEdit* scratch, u32 count)
{
    for (u32 width = 1; width < count; width *= 2)
    {
        for (u32 start = 0; start < count; start += 2 * width)
        {
            u32 middle = BUSTER_MIN(start + width, count);
            u32 limit = BUSTER_MIN(start + 2 * width, count);
            u32 left = start;
            u32 right = middle;
            u32 out = start;
            while (left < middle && right < limit)
            {
                scratch[out++] = edits[right].point < edits[left].point ? edits[right++] : edits[left++];
            }
            while (left < middle)
            {
                scratch[out++] = edits[left++];
            }
            while (right < limit)
            {
                scratch[out++] = edits[right++];
            }
        }
        for (u32 index = 0; index < count; index += 1)
        {
            edits[index] = scratch[index];
        }
    }
}
BUSTER_GLOBAL_LOCAL void machine_fast_sort_edits(MachineEdit* edits, MachineEdit* scratch, u32 count)
{

    bool ordered = true;
    u32 differing = 0;
    for (u32 index = 1; index < count; index += 1)
    {
        ordered &= edits[index - 1u].point <= edits[index].point;
        differing |= edits[0].point ^ edits[index].point;
    }
    if (!ordered)
    {
        MachineEdit* source = edits;
        MachineEdit* destination = scratch;
        if (count >= MACHINE_FAST_RADIX_EDIT_THRESHOLD)
        {
            for (u32 shift = 0; shift < 32u; shift += 8u)
            {
                if (!((differing >> shift) & 0xffu))
                {
                    continue;
                }
                u32 offsets[256] = {0};
                for (u32 index = 0; index < count; index += 1)
                {
                    offsets[(source[index].point >> shift) & 0xffu] += 1;
                }
                u32 offset = 0;
                for (u32 bucket = 0; bucket < 256u; bucket += 1)
                {
                    u32 entries = offsets[bucket];
                    offsets[bucket] = offset;
                    offset += entries;
                }
                for (u32 index = 0; index < count; index += 1)
                {
                    destination[offsets[(source[index].point >> shift) & 0xffu]++] = source[index];
                }
                WORK_LEDGER_RECORD(MACHINE_RETRO_SORT_RECORD_MOVES, count);
                MachineEdit* exchanged = source;
                source = destination;
                destination = exchanged;
            }
        }
        else
        {
            for (u32 width = 1; width < count; width *= 2u)
            {
                for (u32 start = 0; start < count; start += 2u * width)
                {
                    u32 middle = BUSTER_MIN(start + width, count);
                    u32 limit = BUSTER_MIN(start + 2u * width, count);
                    u32 left = start;
                    u32 right = middle;
                    u32 out = start;
                    while (left < middle && right < limit)
                    {
                        destination[out++] = source[right].point < source[left].point ? source[right++] : source[left++];
                    }
                    while (left < middle) destination[out++] = source[left++];
                    while (right < limit) destination[out++] = source[right++];
                }
                WORK_LEDGER_RECORD(MACHINE_RETRO_SORT_RECORD_MOVES, count);
                MachineEdit* exchanged = source;
                source = destination;
                destination = exchanged;
            }
        }
        if (source != edits)
        {
            memcpy(edits, source, (u64)count * sizeof(*edits));
            WORK_LEDGER_RECORD(MACHINE_RETRO_SORT_RECORD_MOVES, count);
        }
    }
}

static unsigned long long now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (unsigned long long)t.tv_sec*1000000000ull+(unsigned long long)t.tv_nsec;}
int main(void){u32 sizes[]={0,1,2,3,64,255,256,257,1024,16384,262144};
for(u32 shape=0;shape<8;shape++){for(u32 k=0;k<sizeof(sizes)/sizeof(*sizes);k++){
u32 n=sizes[k];MachineEdit *a=malloc(((size_t)n+1)*sizeof(*a)),*b=malloc(((size_t)n+1)*sizeof(*b)),*scratch=malloc(((size_t)n+1)*sizeof(*scratch));u32 random=123456789;
for(u32 i=0;i<n;i++){random=random*1664525u+1013904223u;u32 key=shape==0?i:shape==1?n-i:shape==2?UINT32_MAX:shape==3?random%7:shape==4?random&255:shape==5?(random&255)<<24:shape==6?random:i&1?0:UINT32_MAX;a[i]=(MachineEdit){key,(u16)(i+3),(u16)(i^0x55aa),i,~i};b[i]=a[i];}
unsigned long long t=now_ns();baseline_sort(a,scratch,n);unsigned long long base=now_ns()-t;t=now_ns();moves=0;machine_fast_sort_edits(b,scratch,n);unsigned long long candidate=now_ns()-t;
if(memcmp(a,b,(size_t)n*sizeof(*a))){fprintf(stderr,"mismatch %u %u\n",shape,n);return 1;}
u32 levels=0;for(u32 w=1;w<n;w*=2)levels++;
printf("shape=%u count=%u baseline_moves=%llu candidate_moves=%llu baseline_ns=%llu candidate_ns=%llu\n",shape,n,(unsigned long long)2*n*levels,(unsigned long long)moves,base,candidate);
free(scratch);free(b);free(a);}}
return 0;}
