int f(int x){return x*5+3;} int main(void){return f(7)!=38;}
