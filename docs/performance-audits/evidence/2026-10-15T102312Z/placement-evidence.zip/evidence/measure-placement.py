from pathlib import Path
import subprocess,json,hashlib
root=Path('../evidence').resolve();tool=root/'performance-evidence';a=root/'profile-baseline/ide';b=root/'profile-candidate/ide';results=[]
cases=[('unity-fast','unity.i','fast',10),('unity-quality','unity.i','quality',10),('nested-2000','nested-2000.c','fast',8),('nested-1000','nested-1000.c','fast',8),('small-fast','small.c','fast',8),('small-quality','small.c','quality',8)]
for name,source,mode,runs in cases:
 if (root/name/'summary.json').exists():
  prior=json.loads((root/name/'summary.json').read_text())
  if prior.get('complete'):
   results.append({'case':name,'reused_complete':True});continue
 args=['cc','-march=native','-g0','-fregister-allocator='+mode,str(root/'inputs'/source),'-lm','-o',str(root/(name+'.out'))]
 if source.startswith('nested'):
  args.insert(1,'-c');args.remove('-lm')
 outputs=[]
 for label,binary in [('baseline',a),('candidate',b)]:
  completed=subprocess.run([str(binary),*args],capture_output=True)
  (root/(name+'-'+label+'.log')).write_bytes(completed.stdout+completed.stderr)
  outputs.append(hashlib.sha256((root/(name+'.out')).read_bytes()).hexdigest() if completed.returncode==0 else None)
 if outputs[0]!=outputs[1] or outputs[0] is None:raise SystemExit(f'output mismatch {name}: {outputs}')
 command=['taskset','-c','2',str(tool),'compare','--claim','work-reduction','--tool','perf-stat','--baseline',str(a),'--candidate',str(b),'--out',str(root/name),'--runs',str(runs),'--events','instructions:u','--min-effect-percent','0.1','--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--candidate-revision','2a02bb7ba5f9205efcd246986bd81b274b4588c9','--',*args]
 completed=subprocess.run(command,capture_output=True,text=True)
 (root/(name+'-compare.log')).write_text(completed.stdout+completed.stderr)
 results.append({'case':name,'returncode':completed.returncode,'output_sha256':outputs[0]});print(json.dumps(results[-1]),flush=True)
 if completed.returncode:raise SystemExit(completed.returncode)
(root/'comparisons.json').write_text(json.dumps(results,indent=2)+'\n')
