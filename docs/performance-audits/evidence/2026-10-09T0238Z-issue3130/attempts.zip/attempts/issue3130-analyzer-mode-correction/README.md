# Analyzer-mode proof correction attempts

The first native self-test after narrowing the driver-expansion option match
failed one new warning-token control. Its fixture expected Clang to emit
`-Wreserved-module-identifier` without passing that option; the real `-###`
output did not contain it. The production option matcher was not weakened. The
corrected control passes `-Wreserved-module-identifier` explicitly and checks
that the normal warning token remains eligible while quoted `-module` and
`-module-file` options remain unsupported. The initial failed self-test and the
corrected passing self-test are both retained.

The first fresh current-source CI-shaped census, made with local producer
commit `00bc73fc05af57281709b29b757171ea1570b16d` / tree
`5823f9db091aa606fc57adef1deae5d3a8436174`, selected 182 rows and formed 12
repeated candidate groups, but proved zero groups and therefore showed 182
executions and zero aliases. This was a false rejection: its raw substring
check for `-module` also matched the ordinary Clang option
`-Wreserved-module-identifier`. The archived failed V2 manifest contains the
compile database authority; its raw SHA-256 was
`6fd11629310e18d5878661a7e10dc179d0333c03b9844e7800bbc69ee8eddd2c`, with
database SHA-256
`ba5356ee37b8ffb16a9b236c46a10b901f1487779f6338a26c9ca96d4af85a12`.

The later analyzer-mode correction also preserves `--analyze` in both the
dependency `-M` query and dynamic-preprocessing `-E` query. Native Clang 21
controls verify that analyzer-only `__TIME__` falls back, that a guarded header
is a positive dependency and content mutation invalidates it, and that a
guarded absolute negative lookup is detected on replay. The passing native
self-test and O0 reader suite are included here with the exact CI generation
and final prepare logs.
