int alias_value(void) { return 1; }
