#!/usr/bin/env bash
set +e
PATH=/usr/lib/llvm-21/bin:$PATH
export PATH
TIMEFORMAT='elapsed_s=%3R'
{ time timeout 240s build/analyzer-driver-o0-base834d clang_analyze build/issue3130-cost-baseline/compile_commands.json --config Release --shards 4 --timeout 2 --quiet --qualify-workers --results build/issue3130-cost-baseline/campaign > build/issue3130-cost-baseline/campaign.log 2>&1; } 2> build/issue3130-cost-baseline/measurement.txt
baseline_status=$?
printf 'shell_status=%s\n' "$baseline_status" >> build/issue3130-cost-baseline/measurement.txt
{ time timeout 240s build/analyzer-driver-o0-final clang_analyze build/issue3130-cost-current/compile_commands.json --config Release --shards 4 --timeout 2 --quiet --qualify-workers --results build/issue3130-cost-current/campaign > build/issue3130-cost-current/campaign.log 2>&1; } 2> build/issue3130-cost-current/measurement.txt
candidate_status=$?
printf 'shell_status=%s\n' "$candidate_status" >> build/issue3130-cost-current/measurement.txt
printf 'baseline_status=%s candidate_status=%s\n' "$baseline_status" "$candidate_status"
