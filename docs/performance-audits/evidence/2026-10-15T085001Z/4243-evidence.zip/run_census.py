from pathlib import Path
import collections
import hashlib
import json
import os
import subprocess

root = Path(__file__).parent.resolve()
repo = root / 'buster'
out = root / 'census'
out.mkdir(exist_ok=False)
cases = ['many-small', 'one-large', 'abi-and-memory', 'pressure-256', 'large-2048', 'large-8192', 'large-32768', 'unity']
summary = {}
commands = []
for case in cases:
    source = root / 'inputs' / (case + ('.i' if case == 'unity' else '.c'))
    arms = {}
    for arm in ['baseline', 'candidate-2k', 'candidate-4k']:
        env = dict(os.environ, BUSTER_CENSUS_SMALL={'baseline': '0', 'candidate-2k': '1', 'candidate-4k': '4'}[arm])
        command = [str(root / 'ide-diagnostic'), 'cc', '-march=native', '-g0',
                   '-fregister-allocator=fast', str(source), '-lm', '-o', str(root / 'census-output')]
        log = out / f'{case}-{arm}.log'
        with log.open('wb') as f:
            subprocess.run(command, cwd=repo, env=dict(env, BUSTER_CENSUS_PRINT='1'), stdout=f, stderr=subprocess.STDOUT, check=True, timeout=180)
        commands.append({'argv': command, 'env': dict(BUSTER_CENSUS_SMALL=env['BUSTER_CENSUS_SMALL'], BUSTER_CENSUS_PRINT='1')})
        totals = collections.Counter()
        streams = collections.defaultdict(collections.Counter)
        functions = 0
        for line in log.read_text().splitlines():
            if line.startswith(('BUILDER_CENSUS ', 'BUILDER_STREAM ')):
                values = dict(x.split('=', 1) for x in line.split()[1:])
                if line.startswith('BUILDER_STREAM '):
                    for k, v in values.items():
                        if k != 'stream': streams[int(values['stream'])][k] += int(v)
                else:
                    functions += 1
                    for k, v in values.items():
                        if k != 'function':
                            if k in ['peak', 'retained']: totals['max_' + k] = max(totals['max_' + k], int(v))
                            else: totals[k] += int(v)
        assert functions > 0, case
        output_hash = hashlib.sha256((root / 'census-output').read_bytes()).hexdigest()
        native = root / 'artifacts' / f'{case}-fast-g0-baseline'
        assert native.is_file() and output_hash == hashlib.sha256(native.read_bytes()).hexdigest(), (case, arm, 'diagnostic output mismatch')
        command = [str(root / 'ide-diagnostic'), 'bench-select', str(source)]
        replay_log = out / f'{case}-{arm}-replay.log'
        with replay_log.open('wb') as f:
            subprocess.run(command, cwd=repo, env=env, stdout=f, stderr=subprocess.STDOUT, check=True, timeout=240)
        commands.append({'argv': command, 'env': dict(BUSTER_CENSUS_SMALL=env['BUSTER_CENSUS_SMALL'])})
        mir = [l for l in replay_log.read_text().splitlines() if l.startswith('BUILDER_MIR ')]
        assert mir, case
        arms[arm] = dict(functions=functions, totals=dict(totals), streams=dict(streams), output_sha256=output_hash,
                         mir_functions=len(mir), mir_aggregate_sha256=hashlib.sha256(('\n'.join(mir) + '\n').encode()).hexdigest())
        if arm == 'baseline': baseline_mir = mir
        else: assert baseline_mir == mir, (case, 'selected MIR mismatch')
    for arm in ['candidate-2k', 'candidate-4k']:
        assert arms['baseline']['functions'] == arms[arm]['functions']
        assert arms['baseline']['totals']['payload'] == arms[arm]['totals']['payload'], case
        assert arms['baseline']['totals']['lookups'] == arms[arm]['totals']['lookups'], case
    summary[case] = arms
    print(json.dumps({case: arms}), flush=True)
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
