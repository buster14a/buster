typedef unsigned long long U;
__attribute__((noinline)) static U arity0(void) { return 7ULL; }
__attribute__((noinline)) static U arity1(U a0) { return a0; }
__attribute__((noinline)) static U arity2(U a0, U a1) { return a0 + a1; }
__attribute__((noinline)) static U arity3(U a0, U a1, U a2) { return a0 + a1 + a2; }
__attribute__((noinline)) static U arity4(U a0, U a1, U a2, U a3) { return a0 + a1 + a2 + a3; }
__attribute__((noinline)) static U arity5(U a0, U a1, U a2, U a3, U a4) { return a0 + a1 + a2 + a3 + a4; }
__attribute__((noinline)) static U arity6(U a0, U a1, U a2, U a3, U a4, U a5) { return a0 + a1 + a2 + a3 + a4 + a5; }
__attribute__((noinline)) static U arity7(U a0, U a1, U a2, U a3, U a4, U a5, U a6) { return a0 + a1 + a2 + a3 + a4 + a5 + a6; }
__attribute__((noinline)) static U arity8(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7; }
__attribute__((noinline)) static U arity9(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8; }
__attribute__((noinline)) static U arity10(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9; }
__attribute__((noinline)) static U arity11(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10; }
__attribute__((noinline)) static U arity12(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11; }
__attribute__((noinline)) static U arity13(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12; }
__attribute__((noinline)) static U arity14(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13; }
__attribute__((noinline)) static U arity15(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14; }
__attribute__((noinline)) static U arity16(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15; }
__attribute__((noinline)) static U arity17(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16; }
__attribute__((noinline)) static U arity18(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16, U a17) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17; }
__attribute__((noinline)) static U arity19(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16, U a17, U a18) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18; }
__attribute__((noinline)) static U arity20(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16, U a17, U a18, U a19) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19; }
__attribute__((noinline)) static U arity21(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16, U a17, U a18, U a19, U a20) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19 + a20; }
__attribute__((noinline)) static U arity22(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16, U a17, U a18, U a19, U a20, U a21) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19 + a20 + a21; }
__attribute__((noinline)) static U arity23(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16, U a17, U a18, U a19, U a20, U a21, U a22) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19 + a20 + a21 + a22; }
__attribute__((noinline)) static U arity24(U a0, U a1, U a2, U a3, U a4, U a5, U a6, U a7, U a8, U a9, U a10, U a11, U a12, U a13, U a14, U a15, U a16, U a17, U a18, U a19, U a20, U a21, U a22, U a23) { return a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19 + a20 + a21 + a22 + a23; }

struct Pair { U a; double b; };
__attribute__((noinline)) static struct Pair pair(struct Pair p) { p.a += 7; p.b += 0.5; return p; }
__attribute__((noinline)) static U memory(signed char* a, unsigned short* b, U* c, int i) { return (U)(long long)a[i] + b[i] + c[i]; }
__attribute__((noinline)) static U loop(U n) { U sum = 0; for (U i = 0; i < n; ++i) { if (i & 1) sum += i; else sum ^= i; } return sum; }
int main(void) { int ok = 1;
ok &= arity0() == 7ULL;
ok &= arity1(1ULL) == 1ULL;
ok &= arity2(1ULL, 2ULL) == 3ULL;
ok &= arity3(1ULL, 2ULL, 3ULL) == 6ULL;
ok &= arity4(1ULL, 2ULL, 3ULL, 4ULL) == 10ULL;
ok &= arity5(1ULL, 2ULL, 3ULL, 4ULL, 5ULL) == 15ULL;
ok &= arity6(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL) == 21ULL;
ok &= arity7(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL) == 28ULL;
ok &= arity8(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL) == 36ULL;
ok &= arity9(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL) == 45ULL;
ok &= arity10(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL) == 55ULL;
ok &= arity11(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL) == 66ULL;
ok &= arity12(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL) == 78ULL;
ok &= arity13(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL) == 91ULL;
ok &= arity14(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL) == 105ULL;
ok &= arity15(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL) == 120ULL;
ok &= arity16(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL) == 136ULL;
ok &= arity17(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL) == 153ULL;
ok &= arity18(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL, 18ULL) == 171ULL;
ok &= arity19(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL, 18ULL, 19ULL) == 190ULL;
ok &= arity20(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL, 18ULL, 19ULL, 20ULL) == 210ULL;
ok &= arity21(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL, 18ULL, 19ULL, 20ULL, 21ULL) == 231ULL;
ok &= arity22(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL, 18ULL, 19ULL, 20ULL, 21ULL, 22ULL) == 253ULL;
ok &= arity23(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL, 18ULL, 19ULL, 20ULL, 21ULL, 22ULL, 23ULL) == 276ULL;
ok &= arity24(1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL, 8ULL, 9ULL, 10ULL, 11ULL, 12ULL, 13ULL, 14ULL, 15ULL, 16ULL, 17ULL, 18ULL, 19ULL, 20ULL, 21ULL, 22ULL, 23ULL, 24ULL) == 300ULL;

struct Pair p = {5, 2.0}; p = pair(p); ok &= p.a == 12 && p.b == 2.5;
signed char a[2] = {-8, -3}; unsigned short b[2] = {60000, 65000}; U c[2] = {0, 4294967296ULL};
ok &= memory(a, b, c, 1) == 4295032293ULL; ok &= loop(10) == 9;
return !ok; }
