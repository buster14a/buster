typedef unsigned long long U;
__attribute__((noinline)) static U f0(void) { U x = 1ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 0ULL; }
__attribute__((noinline)) static U f1(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 1ULL; }
__attribute__((noinline)) static U f2(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 2ULL; }
__attribute__((noinline)) static U f3(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 3ULL; }
__attribute__((noinline)) static U f4(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 4ULL; }
__attribute__((noinline)) static U f5(void) { U x = 6ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 5ULL; }
__attribute__((noinline)) static U f6(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 6ULL; }
__attribute__((noinline)) static U f7(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 7ULL; }
__attribute__((noinline)) static U f8(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 8ULL; }
__attribute__((noinline)) static U f9(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 9ULL; }
__attribute__((noinline)) static U f10(void) { U x = 11ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 10ULL; }
__attribute__((noinline)) static U f11(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 11ULL; }
__attribute__((noinline)) static U f12(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 12ULL; }
__attribute__((noinline)) static U f13(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 13ULL; }
__attribute__((noinline)) static U f14(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 14ULL; }
__attribute__((noinline)) static U f15(void) { U x = 16ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 15ULL; }
__attribute__((noinline)) static U f16(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 16ULL; }
__attribute__((noinline)) static U f17(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 17ULL; }
__attribute__((noinline)) static U f18(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 18ULL; }
__attribute__((noinline)) static U f19(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 19ULL; }
__attribute__((noinline)) static U f20(void) { U x = 21ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 20ULL; }
__attribute__((noinline)) static U f21(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 21ULL; }
__attribute__((noinline)) static U f22(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 22ULL; }
__attribute__((noinline)) static U f23(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 23ULL; }
__attribute__((noinline)) static U f24(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 24ULL; }
__attribute__((noinline)) static U f25(void) { U x = 26ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 25ULL; }
__attribute__((noinline)) static U f26(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 26ULL; }
__attribute__((noinline)) static U f27(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 27ULL; }
__attribute__((noinline)) static U f28(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 28ULL; }
__attribute__((noinline)) static U f29(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 29ULL; }
__attribute__((noinline)) static U f30(void) { U x = 31ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 30ULL; }
__attribute__((noinline)) static U f31(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 31ULL; }
__attribute__((noinline)) static U f32(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 32ULL; }
__attribute__((noinline)) static U f33(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 33ULL; }
__attribute__((noinline)) static U f34(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 34ULL; }
__attribute__((noinline)) static U f35(void) { U x = 36ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 35ULL; }
__attribute__((noinline)) static U f36(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 36ULL; }
__attribute__((noinline)) static U f37(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 37ULL; }
__attribute__((noinline)) static U f38(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 38ULL; }
__attribute__((noinline)) static U f39(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 39ULL; }
__attribute__((noinline)) static U f40(void) { U x = 41ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 40ULL; }
__attribute__((noinline)) static U f41(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 41ULL; }
__attribute__((noinline)) static U f42(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 42ULL; }
__attribute__((noinline)) static U f43(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 43ULL; }
__attribute__((noinline)) static U f44(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 44ULL; }
__attribute__((noinline)) static U f45(void) { U x = 46ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 45ULL; }
__attribute__((noinline)) static U f46(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 46ULL; }
__attribute__((noinline)) static U f47(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 47ULL; }
__attribute__((noinline)) static U f48(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 48ULL; }
__attribute__((noinline)) static U f49(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 49ULL; }
__attribute__((noinline)) static U f50(void) { U x = 51ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 50ULL; }
__attribute__((noinline)) static U f51(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 51ULL; }
__attribute__((noinline)) static U f52(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 52ULL; }
__attribute__((noinline)) static U f53(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 53ULL; }
__attribute__((noinline)) static U f54(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 54ULL; }
__attribute__((noinline)) static U f55(void) { U x = 56ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 55ULL; }
__attribute__((noinline)) static U f56(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 56ULL; }
__attribute__((noinline)) static U f57(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 57ULL; }
__attribute__((noinline)) static U f58(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 58ULL; }
__attribute__((noinline)) static U f59(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 59ULL; }
__attribute__((noinline)) static U f60(void) { U x = 61ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 60ULL; }
__attribute__((noinline)) static U f61(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 61ULL; }
__attribute__((noinline)) static U f62(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 62ULL; }
__attribute__((noinline)) static U f63(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 63ULL; }
__attribute__((noinline)) static U f64(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 64ULL; }
__attribute__((noinline)) static U f65(void) { U x = 66ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 65ULL; }
__attribute__((noinline)) static U f66(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 66ULL; }
__attribute__((noinline)) static U f67(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 67ULL; }
__attribute__((noinline)) static U f68(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 68ULL; }
__attribute__((noinline)) static U f69(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 69ULL; }
__attribute__((noinline)) static U f70(void) { U x = 71ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 70ULL; }
__attribute__((noinline)) static U f71(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 71ULL; }
__attribute__((noinline)) static U f72(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 72ULL; }
__attribute__((noinline)) static U f73(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 73ULL; }
__attribute__((noinline)) static U f74(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 74ULL; }
__attribute__((noinline)) static U f75(void) { U x = 76ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 75ULL; }
__attribute__((noinline)) static U f76(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 76ULL; }
__attribute__((noinline)) static U f77(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 77ULL; }
__attribute__((noinline)) static U f78(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 78ULL; }
__attribute__((noinline)) static U f79(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 79ULL; }
__attribute__((noinline)) static U f80(void) { U x = 81ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 80ULL; }
__attribute__((noinline)) static U f81(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 81ULL; }
__attribute__((noinline)) static U f82(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 82ULL; }
__attribute__((noinline)) static U f83(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 83ULL; }
__attribute__((noinline)) static U f84(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 84ULL; }
__attribute__((noinline)) static U f85(void) { U x = 86ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 85ULL; }
__attribute__((noinline)) static U f86(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 86ULL; }
__attribute__((noinline)) static U f87(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 87ULL; }
__attribute__((noinline)) static U f88(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 88ULL; }
__attribute__((noinline)) static U f89(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 89ULL; }
__attribute__((noinline)) static U f90(void) { U x = 91ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 90ULL; }
__attribute__((noinline)) static U f91(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 91ULL; }
__attribute__((noinline)) static U f92(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 92ULL; }
__attribute__((noinline)) static U f93(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 93ULL; }
__attribute__((noinline)) static U f94(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 94ULL; }
__attribute__((noinline)) static U f95(void) { U x = 96ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 95ULL; }
__attribute__((noinline)) static U f96(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 96ULL; }
__attribute__((noinline)) static U f97(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 97ULL; }
__attribute__((noinline)) static U f98(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 98ULL; }
__attribute__((noinline)) static U f99(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 99ULL; }
__attribute__((noinline)) static U f100(void) { U x = 101ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 100ULL; }
__attribute__((noinline)) static U f101(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 101ULL; }
__attribute__((noinline)) static U f102(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 102ULL; }
__attribute__((noinline)) static U f103(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 103ULL; }
__attribute__((noinline)) static U f104(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 104ULL; }
__attribute__((noinline)) static U f105(void) { U x = 106ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 105ULL; }
__attribute__((noinline)) static U f106(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 106ULL; }
__attribute__((noinline)) static U f107(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 107ULL; }
__attribute__((noinline)) static U f108(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 108ULL; }
__attribute__((noinline)) static U f109(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 109ULL; }
__attribute__((noinline)) static U f110(void) { U x = 111ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 110ULL; }
__attribute__((noinline)) static U f111(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 111ULL; }
__attribute__((noinline)) static U f112(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 112ULL; }
__attribute__((noinline)) static U f113(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 113ULL; }
__attribute__((noinline)) static U f114(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 114ULL; }
__attribute__((noinline)) static U f115(void) { U x = 116ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 115ULL; }
__attribute__((noinline)) static U f116(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 116ULL; }
__attribute__((noinline)) static U f117(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 117ULL; }
__attribute__((noinline)) static U f118(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 118ULL; }
__attribute__((noinline)) static U f119(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 119ULL; }
__attribute__((noinline)) static U f120(void) { U x = 121ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 120ULL; }
__attribute__((noinline)) static U f121(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 121ULL; }
__attribute__((noinline)) static U f122(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 122ULL; }
__attribute__((noinline)) static U f123(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 123ULL; }
__attribute__((noinline)) static U f124(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 124ULL; }
__attribute__((noinline)) static U f125(void) { U x = 126ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 125ULL; }
__attribute__((noinline)) static U f126(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 126ULL; }
__attribute__((noinline)) static U f127(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 127ULL; }
__attribute__((noinline)) static U f128(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 128ULL; }
__attribute__((noinline)) static U f129(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 129ULL; }
__attribute__((noinline)) static U f130(void) { U x = 131ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 130ULL; }
__attribute__((noinline)) static U f131(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 131ULL; }
__attribute__((noinline)) static U f132(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 132ULL; }
__attribute__((noinline)) static U f133(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 133ULL; }
__attribute__((noinline)) static U f134(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 134ULL; }
__attribute__((noinline)) static U f135(void) { U x = 136ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 135ULL; }
__attribute__((noinline)) static U f136(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 136ULL; }
__attribute__((noinline)) static U f137(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 137ULL; }
__attribute__((noinline)) static U f138(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 138ULL; }
__attribute__((noinline)) static U f139(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 139ULL; }
__attribute__((noinline)) static U f140(void) { U x = 141ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 140ULL; }
__attribute__((noinline)) static U f141(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 141ULL; }
__attribute__((noinline)) static U f142(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 142ULL; }
__attribute__((noinline)) static U f143(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 143ULL; }
__attribute__((noinline)) static U f144(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 144ULL; }
__attribute__((noinline)) static U f145(void) { U x = 146ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 145ULL; }
__attribute__((noinline)) static U f146(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 146ULL; }
__attribute__((noinline)) static U f147(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 147ULL; }
__attribute__((noinline)) static U f148(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 148ULL; }
__attribute__((noinline)) static U f149(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 149ULL; }
__attribute__((noinline)) static U f150(void) { U x = 151ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 150ULL; }
__attribute__((noinline)) static U f151(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 151ULL; }
__attribute__((noinline)) static U f152(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 152ULL; }
__attribute__((noinline)) static U f153(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 153ULL; }
__attribute__((noinline)) static U f154(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 154ULL; }
__attribute__((noinline)) static U f155(void) { U x = 156ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 155ULL; }
__attribute__((noinline)) static U f156(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 156ULL; }
__attribute__((noinline)) static U f157(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 157ULL; }
__attribute__((noinline)) static U f158(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 158ULL; }
__attribute__((noinline)) static U f159(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 159ULL; }
__attribute__((noinline)) static U f160(void) { U x = 161ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 160ULL; }
__attribute__((noinline)) static U f161(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 161ULL; }
__attribute__((noinline)) static U f162(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 162ULL; }
__attribute__((noinline)) static U f163(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 163ULL; }
__attribute__((noinline)) static U f164(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 164ULL; }
__attribute__((noinline)) static U f165(void) { U x = 166ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 165ULL; }
__attribute__((noinline)) static U f166(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 166ULL; }
__attribute__((noinline)) static U f167(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 167ULL; }
__attribute__((noinline)) static U f168(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 168ULL; }
__attribute__((noinline)) static U f169(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 169ULL; }
__attribute__((noinline)) static U f170(void) { U x = 171ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 170ULL; }
__attribute__((noinline)) static U f171(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 171ULL; }
__attribute__((noinline)) static U f172(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 172ULL; }
__attribute__((noinline)) static U f173(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 173ULL; }
__attribute__((noinline)) static U f174(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 174ULL; }
__attribute__((noinline)) static U f175(void) { U x = 176ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 175ULL; }
__attribute__((noinline)) static U f176(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 176ULL; }
__attribute__((noinline)) static U f177(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 177ULL; }
__attribute__((noinline)) static U f178(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 178ULL; }
__attribute__((noinline)) static U f179(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 179ULL; }
__attribute__((noinline)) static U f180(void) { U x = 181ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 180ULL; }
__attribute__((noinline)) static U f181(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 181ULL; }
__attribute__((noinline)) static U f182(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 182ULL; }
__attribute__((noinline)) static U f183(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 183ULL; }
__attribute__((noinline)) static U f184(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 184ULL; }
__attribute__((noinline)) static U f185(void) { U x = 186ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 185ULL; }
__attribute__((noinline)) static U f186(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 186ULL; }
__attribute__((noinline)) static U f187(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 187ULL; }
__attribute__((noinline)) static U f188(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 188ULL; }
__attribute__((noinline)) static U f189(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 189ULL; }
__attribute__((noinline)) static U f190(void) { U x = 191ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 190ULL; }
__attribute__((noinline)) static U f191(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 191ULL; }
__attribute__((noinline)) static U f192(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 192ULL; }
__attribute__((noinline)) static U f193(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 193ULL; }
__attribute__((noinline)) static U f194(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 194ULL; }
__attribute__((noinline)) static U f195(void) { U x = 196ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 195ULL; }
__attribute__((noinline)) static U f196(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 196ULL; }
__attribute__((noinline)) static U f197(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 197ULL; }
__attribute__((noinline)) static U f198(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 198ULL; }
__attribute__((noinline)) static U f199(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 199ULL; }
__attribute__((noinline)) static U f200(void) { U x = 201ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 200ULL; }
__attribute__((noinline)) static U f201(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 201ULL; }
__attribute__((noinline)) static U f202(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 202ULL; }
__attribute__((noinline)) static U f203(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 203ULL; }
__attribute__((noinline)) static U f204(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 204ULL; }
__attribute__((noinline)) static U f205(void) { U x = 206ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 205ULL; }
__attribute__((noinline)) static U f206(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 206ULL; }
__attribute__((noinline)) static U f207(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 207ULL; }
__attribute__((noinline)) static U f208(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 208ULL; }
__attribute__((noinline)) static U f209(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 209ULL; }
__attribute__((noinline)) static U f210(void) { U x = 211ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 210ULL; }
__attribute__((noinline)) static U f211(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 211ULL; }
__attribute__((noinline)) static U f212(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 212ULL; }
__attribute__((noinline)) static U f213(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 213ULL; }
__attribute__((noinline)) static U f214(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 214ULL; }
__attribute__((noinline)) static U f215(void) { U x = 216ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 215ULL; }
__attribute__((noinline)) static U f216(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 216ULL; }
__attribute__((noinline)) static U f217(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 217ULL; }
__attribute__((noinline)) static U f218(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 218ULL; }
__attribute__((noinline)) static U f219(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 219ULL; }
__attribute__((noinline)) static U f220(void) { U x = 221ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 220ULL; }
__attribute__((noinline)) static U f221(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 221ULL; }
__attribute__((noinline)) static U f222(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 222ULL; }
__attribute__((noinline)) static U f223(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 223ULL; }
__attribute__((noinline)) static U f224(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 224ULL; }
__attribute__((noinline)) static U f225(void) { U x = 226ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 225ULL; }
__attribute__((noinline)) static U f226(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 226ULL; }
__attribute__((noinline)) static U f227(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 227ULL; }
__attribute__((noinline)) static U f228(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 228ULL; }
__attribute__((noinline)) static U f229(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 229ULL; }
__attribute__((noinline)) static U f230(void) { U x = 231ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 230ULL; }
__attribute__((noinline)) static U f231(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 231ULL; }
__attribute__((noinline)) static U f232(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 232ULL; }
__attribute__((noinline)) static U f233(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 233ULL; }
__attribute__((noinline)) static U f234(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 234ULL; }
__attribute__((noinline)) static U f235(void) { U x = 236ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 235ULL; }
__attribute__((noinline)) static U f236(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 236ULL; }
__attribute__((noinline)) static U f237(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 237ULL; }
__attribute__((noinline)) static U f238(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 238ULL; }
__attribute__((noinline)) static U f239(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 239ULL; }
__attribute__((noinline)) static U f240(void) { U x = 241ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 240ULL; }
__attribute__((noinline)) static U f241(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 241ULL; }
__attribute__((noinline)) static U f242(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 242ULL; }
__attribute__((noinline)) static U f243(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 243ULL; }
__attribute__((noinline)) static U f244(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 244ULL; }
__attribute__((noinline)) static U f245(void) { U x = 246ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 245ULL; }
__attribute__((noinline)) static U f246(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 246ULL; }
__attribute__((noinline)) static U f247(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 247ULL; }
__attribute__((noinline)) static U f248(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 248ULL; }
__attribute__((noinline)) static U f249(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 249ULL; }
__attribute__((noinline)) static U f250(void) { U x = 251ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 250ULL; }
__attribute__((noinline)) static U f251(U a0) { U x = a0; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 251ULL; }
__attribute__((noinline)) static U f252(U a0, U a1) { U x = a0 + a1; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 252ULL; }
__attribute__((noinline)) static U f253(U a0, U a1, U a2) { U x = a0 + a1 + a2; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 253ULL; }
__attribute__((noinline)) static U f254(U a0, U a1, U a2, U a3) { U x = a0 + a1 + a2 + a3; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 254ULL; }
__attribute__((noinline)) static U f255(void) { U x = 256ULL; x ^= x >> 7; x *= 6364136223846793005ULL; return x + 255ULL; }
int main(void) { U sum = 0;
    sum += f0();
    sum += f1(2ULL);
    sum += f2(3ULL, 4ULL);
    sum += f3(4ULL, 5ULL, 6ULL);
    sum += f4(5ULL, 6ULL, 7ULL, 8ULL);
    sum += f5();
    sum += f6(7ULL);
    sum += f7(8ULL, 9ULL);
    sum += f8(9ULL, 10ULL, 11ULL);
    sum += f9(10ULL, 11ULL, 12ULL, 13ULL);
    sum += f10();
    sum += f11(12ULL);
    sum += f12(13ULL, 14ULL);
    sum += f13(14ULL, 15ULL, 16ULL);
    sum += f14(15ULL, 16ULL, 17ULL, 18ULL);
    sum += f15();
    sum += f16(17ULL);
    sum += f17(18ULL, 19ULL);
    sum += f18(19ULL, 20ULL, 21ULL);
    sum += f19(20ULL, 21ULL, 22ULL, 23ULL);
    sum += f20();
    sum += f21(22ULL);
    sum += f22(23ULL, 24ULL);
    sum += f23(24ULL, 25ULL, 26ULL);
    sum += f24(25ULL, 26ULL, 27ULL, 28ULL);
    sum += f25();
    sum += f26(27ULL);
    sum += f27(28ULL, 29ULL);
    sum += f28(29ULL, 30ULL, 31ULL);
    sum += f29(30ULL, 31ULL, 32ULL, 33ULL);
    sum += f30();
    sum += f31(32ULL);
    sum += f32(33ULL, 34ULL);
    sum += f33(34ULL, 35ULL, 36ULL);
    sum += f34(35ULL, 36ULL, 37ULL, 38ULL);
    sum += f35();
    sum += f36(37ULL);
    sum += f37(38ULL, 39ULL);
    sum += f38(39ULL, 40ULL, 41ULL);
    sum += f39(40ULL, 41ULL, 42ULL, 43ULL);
    sum += f40();
    sum += f41(42ULL);
    sum += f42(43ULL, 44ULL);
    sum += f43(44ULL, 45ULL, 46ULL);
    sum += f44(45ULL, 46ULL, 47ULL, 48ULL);
    sum += f45();
    sum += f46(47ULL);
    sum += f47(48ULL, 49ULL);
    sum += f48(49ULL, 50ULL, 51ULL);
    sum += f49(50ULL, 51ULL, 52ULL, 53ULL);
    sum += f50();
    sum += f51(52ULL);
    sum += f52(53ULL, 54ULL);
    sum += f53(54ULL, 55ULL, 56ULL);
    sum += f54(55ULL, 56ULL, 57ULL, 58ULL);
    sum += f55();
    sum += f56(57ULL);
    sum += f57(58ULL, 59ULL);
    sum += f58(59ULL, 60ULL, 61ULL);
    sum += f59(60ULL, 61ULL, 62ULL, 63ULL);
    sum += f60();
    sum += f61(62ULL);
    sum += f62(63ULL, 64ULL);
    sum += f63(64ULL, 65ULL, 66ULL);
    sum += f64(65ULL, 66ULL, 67ULL, 68ULL);
    sum += f65();
    sum += f66(67ULL);
    sum += f67(68ULL, 69ULL);
    sum += f68(69ULL, 70ULL, 71ULL);
    sum += f69(70ULL, 71ULL, 72ULL, 73ULL);
    sum += f70();
    sum += f71(72ULL);
    sum += f72(73ULL, 74ULL);
    sum += f73(74ULL, 75ULL, 76ULL);
    sum += f74(75ULL, 76ULL, 77ULL, 78ULL);
    sum += f75();
    sum += f76(77ULL);
    sum += f77(78ULL, 79ULL);
    sum += f78(79ULL, 80ULL, 81ULL);
    sum += f79(80ULL, 81ULL, 82ULL, 83ULL);
    sum += f80();
    sum += f81(82ULL);
    sum += f82(83ULL, 84ULL);
    sum += f83(84ULL, 85ULL, 86ULL);
    sum += f84(85ULL, 86ULL, 87ULL, 88ULL);
    sum += f85();
    sum += f86(87ULL);
    sum += f87(88ULL, 89ULL);
    sum += f88(89ULL, 90ULL, 91ULL);
    sum += f89(90ULL, 91ULL, 92ULL, 93ULL);
    sum += f90();
    sum += f91(92ULL);
    sum += f92(93ULL, 94ULL);
    sum += f93(94ULL, 95ULL, 96ULL);
    sum += f94(95ULL, 96ULL, 97ULL, 98ULL);
    sum += f95();
    sum += f96(97ULL);
    sum += f97(98ULL, 99ULL);
    sum += f98(99ULL, 100ULL, 101ULL);
    sum += f99(100ULL, 101ULL, 102ULL, 103ULL);
    sum += f100();
    sum += f101(102ULL);
    sum += f102(103ULL, 104ULL);
    sum += f103(104ULL, 105ULL, 106ULL);
    sum += f104(105ULL, 106ULL, 107ULL, 108ULL);
    sum += f105();
    sum += f106(107ULL);
    sum += f107(108ULL, 109ULL);
    sum += f108(109ULL, 110ULL, 111ULL);
    sum += f109(110ULL, 111ULL, 112ULL, 113ULL);
    sum += f110();
    sum += f111(112ULL);
    sum += f112(113ULL, 114ULL);
    sum += f113(114ULL, 115ULL, 116ULL);
    sum += f114(115ULL, 116ULL, 117ULL, 118ULL);
    sum += f115();
    sum += f116(117ULL);
    sum += f117(118ULL, 119ULL);
    sum += f118(119ULL, 120ULL, 121ULL);
    sum += f119(120ULL, 121ULL, 122ULL, 123ULL);
    sum += f120();
    sum += f121(122ULL);
    sum += f122(123ULL, 124ULL);
    sum += f123(124ULL, 125ULL, 126ULL);
    sum += f124(125ULL, 126ULL, 127ULL, 128ULL);
    sum += f125();
    sum += f126(127ULL);
    sum += f127(128ULL, 129ULL);
    sum += f128(129ULL, 130ULL, 131ULL);
    sum += f129(130ULL, 131ULL, 132ULL, 133ULL);
    sum += f130();
    sum += f131(132ULL);
    sum += f132(133ULL, 134ULL);
    sum += f133(134ULL, 135ULL, 136ULL);
    sum += f134(135ULL, 136ULL, 137ULL, 138ULL);
    sum += f135();
    sum += f136(137ULL);
    sum += f137(138ULL, 139ULL);
    sum += f138(139ULL, 140ULL, 141ULL);
    sum += f139(140ULL, 141ULL, 142ULL, 143ULL);
    sum += f140();
    sum += f141(142ULL);
    sum += f142(143ULL, 144ULL);
    sum += f143(144ULL, 145ULL, 146ULL);
    sum += f144(145ULL, 146ULL, 147ULL, 148ULL);
    sum += f145();
    sum += f146(147ULL);
    sum += f147(148ULL, 149ULL);
    sum += f148(149ULL, 150ULL, 151ULL);
    sum += f149(150ULL, 151ULL, 152ULL, 153ULL);
    sum += f150();
    sum += f151(152ULL);
    sum += f152(153ULL, 154ULL);
    sum += f153(154ULL, 155ULL, 156ULL);
    sum += f154(155ULL, 156ULL, 157ULL, 158ULL);
    sum += f155();
    sum += f156(157ULL);
    sum += f157(158ULL, 159ULL);
    sum += f158(159ULL, 160ULL, 161ULL);
    sum += f159(160ULL, 161ULL, 162ULL, 163ULL);
    sum += f160();
    sum += f161(162ULL);
    sum += f162(163ULL, 164ULL);
    sum += f163(164ULL, 165ULL, 166ULL);
    sum += f164(165ULL, 166ULL, 167ULL, 168ULL);
    sum += f165();
    sum += f166(167ULL);
    sum += f167(168ULL, 169ULL);
    sum += f168(169ULL, 170ULL, 171ULL);
    sum += f169(170ULL, 171ULL, 172ULL, 173ULL);
    sum += f170();
    sum += f171(172ULL);
    sum += f172(173ULL, 174ULL);
    sum += f173(174ULL, 175ULL, 176ULL);
    sum += f174(175ULL, 176ULL, 177ULL, 178ULL);
    sum += f175();
    sum += f176(177ULL);
    sum += f177(178ULL, 179ULL);
    sum += f178(179ULL, 180ULL, 181ULL);
    sum += f179(180ULL, 181ULL, 182ULL, 183ULL);
    sum += f180();
    sum += f181(182ULL);
    sum += f182(183ULL, 184ULL);
    sum += f183(184ULL, 185ULL, 186ULL);
    sum += f184(185ULL, 186ULL, 187ULL, 188ULL);
    sum += f185();
    sum += f186(187ULL);
    sum += f187(188ULL, 189ULL);
    sum += f188(189ULL, 190ULL, 191ULL);
    sum += f189(190ULL, 191ULL, 192ULL, 193ULL);
    sum += f190();
    sum += f191(192ULL);
    sum += f192(193ULL, 194ULL);
    sum += f193(194ULL, 195ULL, 196ULL);
    sum += f194(195ULL, 196ULL, 197ULL, 198ULL);
    sum += f195();
    sum += f196(197ULL);
    sum += f197(198ULL, 199ULL);
    sum += f198(199ULL, 200ULL, 201ULL);
    sum += f199(200ULL, 201ULL, 202ULL, 203ULL);
    sum += f200();
    sum += f201(202ULL);
    sum += f202(203ULL, 204ULL);
    sum += f203(204ULL, 205ULL, 206ULL);
    sum += f204(205ULL, 206ULL, 207ULL, 208ULL);
    sum += f205();
    sum += f206(207ULL);
    sum += f207(208ULL, 209ULL);
    sum += f208(209ULL, 210ULL, 211ULL);
    sum += f209(210ULL, 211ULL, 212ULL, 213ULL);
    sum += f210();
    sum += f211(212ULL);
    sum += f212(213ULL, 214ULL);
    sum += f213(214ULL, 215ULL, 216ULL);
    sum += f214(215ULL, 216ULL, 217ULL, 218ULL);
    sum += f215();
    sum += f216(217ULL);
    sum += f217(218ULL, 219ULL);
    sum += f218(219ULL, 220ULL, 221ULL);
    sum += f219(220ULL, 221ULL, 222ULL, 223ULL);
    sum += f220();
    sum += f221(222ULL);
    sum += f222(223ULL, 224ULL);
    sum += f223(224ULL, 225ULL, 226ULL);
    sum += f224(225ULL, 226ULL, 227ULL, 228ULL);
    sum += f225();
    sum += f226(227ULL);
    sum += f227(228ULL, 229ULL);
    sum += f228(229ULL, 230ULL, 231ULL);
    sum += f229(230ULL, 231ULL, 232ULL, 233ULL);
    sum += f230();
    sum += f231(232ULL);
    sum += f232(233ULL, 234ULL);
    sum += f233(234ULL, 235ULL, 236ULL);
    sum += f234(235ULL, 236ULL, 237ULL, 238ULL);
    sum += f235();
    sum += f236(237ULL);
    sum += f237(238ULL, 239ULL);
    sum += f238(239ULL, 240ULL, 241ULL);
    sum += f239(240ULL, 241ULL, 242ULL, 243ULL);
    sum += f240();
    sum += f241(242ULL);
    sum += f242(243ULL, 244ULL);
    sum += f243(244ULL, 245ULL, 246ULL);
    sum += f244(245ULL, 246ULL, 247ULL, 248ULL);
    sum += f245();
    sum += f246(247ULL);
    sum += f247(248ULL, 249ULL);
    sum += f248(249ULL, 250ULL, 251ULL);
    sum += f249(250ULL, 251ULL, 252ULL, 253ULL);
    sum += f250();
    sum += f251(252ULL);
    sum += f252(253ULL, 254ULL);
    sum += f253(254ULL, 255ULL, 256ULL);
    sum += f254(255ULL, 256ULL, 257ULL, 258ULL);
    sum += f255();
return sum != 10655438988279263124ULL; }
