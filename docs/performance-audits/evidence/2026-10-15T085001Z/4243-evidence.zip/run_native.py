from pathlib import Path
import hashlib
import json
import math
import statistics
import subprocess
import sys

root = Path(__file__).parent.resolve()
repo = root / 'buster'
tool = root / 'performance-evidence'
base = root / 'ide-baseline'
cand = root / 'ide-candidate'
base_rev = '35fee905e39941acafb26db6d6ff3f41eb7d8dc7'
cand_rev = '5d7aa3599'
out = root / 'native'
out.mkdir(exist_ok=False)
cand_rev = subprocess.check_output(['git', 'rev-parse', cand_rev], cwd=repo, text=True).strip()

def compare(name, source, mode, candidate=cand):
    args = ['cc', '-march=native', '-g0', f'-fregister-allocator={mode}',
            str(root / 'inputs' / source), '-lm', '-o', str(root / 'measured-output')]
    command = ['taskset', '-c', '2', str(tool), 'compare', '--claim', 'native-runtime',
               '--tool', 'time', '--baseline', str(base), '--candidate', str(candidate),
               '--baseline-revision', base_rev, '--candidate-revision', base_rev if candidate == base else cand_rev,
               '--out', str(out / name), '--runs', '20', '--warmup', '1',
               '--min-effect-percent', '3', '--timeout', '120', '--', *args]
    print(name, flush=True)
    subprocess.run(command, cwd=repo, check=True)

compare('aa-unity-fast', 'unity.i', 'fast', base)
cases = ['many-small', 'one-large', 'abi-and-memory', 'pressure-256', 'large-2048', 'large-8192', 'large-32768', 'unity']
for case in cases:
    for mode in ['fast', 'quality']:
        compare(f'{case}-{mode}', case + ('.i' if case == 'unity' else '.c'), mode)

summary = {}
for path in out.glob('*/summary.json'):
    value = json.loads(path.read_text())
    metrics = {m['name']: m for m in value['metrics']}
    cpu = [[a + b for a, b in zip(metrics['user_seconds'][arm], metrics['system_seconds'][arm])]
           for arm in ['baseline', 'candidate']]
    smaller = sum(c < b for b, c in zip(*cpu))
    larger = sum(c > b for b, c in zip(*cpu))
    n = smaller + larger
    p = min(1.0, 2 * sum(math.comb(n, k) for k in range(min(smaller, larger) + 1)) / 2 ** n)
    change = statistics.median(cpu[1]) / statistics.median(cpu[0]) - 1
    verdict = ('improvement' if p <= 0.05 and change <= -0.03 and smaller > larger else
               'regression' if p <= 0.05 and change >= 0.03 and larger > smaller else
               'within-effect' if p <= 0.05 and abs(change) < 0.03 else 'inconclusive')
    value['metrics'].append({'name': 'cpu_seconds', 'unit': 's', 'baseline': cpu[0], 'candidate': cpu[1],
                             'relative_change': change, 'sign_test_p': p, 'verdict': verdict})
    summary[path.parent.name] = {'complete': value['complete'], 'result': value['result'],
                               'metrics': value['metrics']}
(out / 'all-results.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({name: {'result': v['result'], 'metrics': [{k: m[k] for k in ['name', 'relative_change', 'verdict', 'sign_test_p']} for m in v['metrics']]} for name, v in summary.items()}, indent=2))
