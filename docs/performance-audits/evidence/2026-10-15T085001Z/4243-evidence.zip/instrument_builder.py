from pathlib import Path

root = Path(__file__).parent / 'buster'
path = root / 'src/buster/lib/compiler/codegen/machine.c'
text = path.read_text()

def replace(old, new):
    global text
    assert text.count(old) == 1, (old[:90], text.count(old))
    text = text.replace(old, new)

replace('void machine_stream_initialize(MachineBuilderStream* stream, u64 element_size)', '''// Temporary serial diagnostic, excluded from native acceptance binaries.
BUSTER_GLOBAL_LOCAL u64 builder_census_chunks;
BUSTER_GLOBAL_LOCAL u64 builder_census_reserved;
BUSTER_GLOBAL_LOCAL u64 builder_census_payload;
BUSTER_GLOBAL_LOCAL u64 builder_census_copied;
BUSTER_GLOBAL_LOCAL u64 builder_census_borrowed;
BUSTER_GLOBAL_LOCAL u64 builder_census_index_allocated;
BUSTER_GLOBAL_LOCAL u64 builder_census_index_copied;
BUSTER_GLOBAL_LOCAL u64 builder_census_index_chunks;
BUSTER_GLOBAL_LOCAL u64 builder_census_lookups;
BUSTER_GLOBAL_LOCAL u64 builder_census_chunk_bytes = BUSTER_KB(16);
BUSTER_GLOBAL_LOCAL u32 builder_census_stream_count;
BUSTER_GLOBAL_LOCAL u64 builder_census_streams[64][5];
void machine_stream_initialize(MachineBuilderStream* stream, u64 element_size)''')
replace('(MACHINE_BUILDER_CHUNK_BYTES - sizeof(MachineBuilderChunk)) / element_size', '(builder_census_chunk_bytes - sizeof(MachineBuilderChunk)) / element_size')
replace('''    stream->reserved = 0;''', '''    BUSTER_CHECK(builder_census_stream_count < 64);
    stream->reserved = builder_census_stream_count++;
    memset(builder_census_streams[stream->reserved], 0, sizeof(builder_census_streams[0]));''')
replace('''    MachineBuilderChunk* chunk = (MachineBuilderChunk*)arena_allocate_bytes(''', '''    builder_census_chunks += 1;
    builder_census_reserved += sizeof(MachineBuilderChunk) + (u64)stream->chunk_capacity * stream->element_size;
    builder_census_streams[stream->reserved][0] += 1;
    builder_census_streams[stream->reserved][1] += sizeof(MachineBuilderChunk) + (u64)stream->chunk_capacity * stream->element_size;
    MachineBuilderChunk* chunk = (MachineBuilderChunk*)arena_allocate_bytes(''')
replace('''    chunk->count += 1;
    stream->total_count += 1;''', '''    chunk->count += 1;
    stream->total_count += 1;
    builder_census_payload += stream->element_size;
    builder_census_streams[stream->reserved][2] += stream->element_size;''')
replace('''void machine_stream_cursor_close(MachineBuilderStream* stream, void const* cursor)
{''', '''void machine_stream_cursor_close(MachineBuilderStream* stream, void const* cursor)
{
    builder_census_payload += (u64)stream->total_count * stream->element_size;
    builder_census_streams[stream->reserved][2] += (u64)stream->total_count * stream->element_size;''')
replace('''        u64 chunk_bytes = (u64)chunk->count * stream->element_size;''', '''        u64 chunk_bytes = (u64)chunk->count * stream->element_size;
        builder_census_copied += chunk_bytes;
        builder_census_streams[stream->reserved][3] += chunk_bytes;''')
replace('''        result = (void*)(stream->first + 1);''', '''        builder_census_borrowed += (u64)stream->total_count * stream->element_size;
        builder_census_streams[stream->reserved][4] += (u64)stream->total_count * stream->element_size;
        result = (void*)(stream->first + 1);''')
replace('''    u32 count = builder->virtual_register_chunk_count;''', '''    builder_census_index_chunks += 1;
    u32 count = builder->virtual_register_chunk_count;''')
replace('''        MachineVirtualRegister** chunks = arena_allocate(builder->arena, MachineVirtualRegister*, capacity);''', '''        builder_census_index_allocated += sizeof(MachineVirtualRegister*) * capacity;
        builder_census_index_copied += sizeof(MachineVirtualRegister*) * count;
        MachineVirtualRegister** chunks = arena_allocate(builder->arena, MachineVirtualRegister*, capacity);''')
replace('''    MachineVirtualRegister* row = 0;
    if (builder && virtual_register < builder->virtual_registers.total_count)''', '''    builder_census_lookups += 1;
    MachineVirtualRegister* row = 0;
    if (builder && virtual_register < builder->virtual_registers.total_count)''')
replace('''    MachineSelectResult result = {.failed_opcode = IR_OPCODE_COUNT};
    if (arena && program && function)''', '''    String8 census_policy = os_get_environment_variable(S8("BUSTER_CENSUS_SMALL"));
    builder_census_chunk_bytes = string_equal(census_policy, S8("1")) ? BUSTER_KB(2) : string_equal(census_policy, S8("4")) ? BUSTER_KB(4) : BUSTER_KB(16);
    builder_census_chunks = builder_census_reserved = builder_census_payload = builder_census_copied = builder_census_borrowed = 0;
    builder_census_index_allocated = builder_census_index_copied = builder_census_index_chunks = builder_census_lookups = 0;
    builder_census_stream_count = 0;
    u64 census_start = arena->position;
    u64 census_prior_peak = arena->high_water;
    arena->high_water = arena->position;
    MachineSelectResult result = {.failed_opcode = IR_OPCODE_COUNT};
    if (arena && program && function)''')
replace('''    if (!result.supported && !assume_validated)''', '''    if (string_equal(os_get_environment_variable(S8("BUSTER_CENSUS_PRINT")), S8("1")))
    {
    for (u32 census_stream = 0; census_stream < builder_census_stream_count; census_stream += 1)
    {
        u64* counts = builder_census_streams[census_stream];
        if (counts[0]) string_print(S8("BUILDER_STREAM stream={u32} chunks={u64} reserved={u64} payload={u64} copied={u64} borrowed={u64}\\n"),
                                    census_stream, counts[0], counts[1], counts[2], counts[3], counts[4]);
    }
    string_print(S8("BUILDER_CENSUS function={S8} chunks={u64} reserved={u64} payload={u64} copied={u64} borrowed={u64} index_allocated={u64} index_copied={u64} index_chunks={u64} lookups={u64} retained={u64} peak={u64}\\n"),
                 function->name, builder_census_chunks, builder_census_reserved, builder_census_payload, builder_census_copied, builder_census_borrowed,
                 builder_census_index_allocated, builder_census_index_copied, builder_census_index_chunks, builder_census_lookups,
                 arena->position - census_start, BUSTER_MAX(arena->position, arena->high_water) - census_start);
    }
    arena->high_water = BUSTER_MAX(census_prior_peak, arena->high_water);
    if (!result.supported && !assume_validated)''')
path.write_text(text)

path = root / 'src/buster/apps/ide/selection_benchmark.h'
text = path.read_text()
replace('''                        MachineVerifyResult verification = machine_verify_function(&selected.function);''', '''                        u64 census_position = arena->position;
                        ByteSlice replay = machine_replay_serialize(arena, &selected.function);
                        Sha256 census_hash;
                        sha256_init(&census_hash);
                        sha256_add(&census_hash, replay.pointer, replay.length);
                        MachineFunction* mir = &selected.function;
                        sha256_add(&census_hash, mir->immediates, (u64)mir->immediate_count * sizeof(*mir->immediates));
                        sha256_add(&census_hash, mir->stack_slot_sizes, (u64)mir->stack_slot_count * sizeof(*mir->stack_slot_sizes));
                        if (mir->stack_slot_alignments) sha256_add(&census_hash, mir->stack_slot_alignments, (u64)mir->stack_slot_count * sizeof(*mir->stack_slot_alignments));
                        sha256_add(&census_hash, mir->call_targets, (u64)mir->call_target_count * sizeof(*mir->call_targets));
                        if (mir->call_target_references) sha256_add(&census_hash, mir->call_target_references, (u64)mir->call_target_count * sizeof(*mir->call_target_references));
                        sha256_add(&census_hash, mir->switch_cases, (u64)mir->switch_case_count * sizeof(*mir->switch_cases));
                        sha256_add(&census_hash, mir->va_args, (u64)mir->va_arg_count * sizeof(*mir->va_args));
                        sha256_add(&census_hash, mir->line_marks, (u64)mir->line_mark_count * sizeof(*mir->line_marks));
                        sha256_add(&census_hash, mir->debug_values, (u64)mir->debug_value_count * sizeof(*mir->debug_values));
                        if (mir->stack_slot_memory_flags) sha256_add(&census_hash, mir->stack_slot_memory_flags, mir->stack_slot_count);
                        sha256_add(&census_hash, mir->inline_assembly_operands, (u64)mir->inline_assembly_operand_count * sizeof(*mir->inline_assembly_operands));
                        for (u32 census_asm = 0; census_asm < mir->inline_assembly_count; census_asm += 1)
                        {
                            MachineInlineAssembly row = mir->inline_assemblies[census_asm];
                            sha256_add(&census_hash, row.source.pointer, row.source.length);
                            sha256_add(&census_hash, row.bytes.pointer, row.bytes.length);
                            row.source.pointer = 0;
                            row.bytes.pointer = 0;
                            sha256_add(&census_hash, &row, sizeof(row));
                        }
                        for (u32 census_relocation = 0; census_relocation < mir->inline_assembly_relocation_count; census_relocation += 1)
                        {
                            MachineInlineAssemblyRelocation row = mir->inline_assembly_relocations[census_relocation];
                            sha256_add(&census_hash, row.symbol.pointer, row.symbol.length);
                            row.symbol.pointer = 0;
                            sha256_add(&census_hash, &row, sizeof(row));
                        }
                        char8 census_hex[SHA256_HEX_CAPACITY];
                        sha256_finish_hex(&census_hash, census_hex);
                        string_print(S8("BUILDER_MIR function={S8} bytes={u64} sha256={S8}\\n"), function->name, replay.length, (String8){.pointer = census_hex, .length = 64});
                        arena_set_position(arena, census_position);
                        MachineVerifyResult verification = machine_verify_function(&selected.function);''')
path.write_text(text)

path = root / 'src/buster/lib/compiler/codegen/machine_x86_64.c'
text = path.read_text()
replace('''    result.function.stack_slot_count = selector.stack_slots.total_count;''', '''    result.function.stack_slot_count = selector.stack_slots.total_count;
    builder_census_copied += (u64)selector.stack_slots.total_count * 2 * sizeof(u32);
    builder_census_streams[selector.stack_slots.reserved][3] += (u64)selector.stack_slots.total_count * 2 * sizeof(u32);''')
replace('''    result.function.call_target_count = selector.call_targets.total_count;''', '''    result.function.call_target_count = selector.call_targets.total_count;
    builder_census_copied += (u64)selector.call_targets.total_count * (sizeof(IrSymbolId) + sizeof(u8));
    builder_census_streams[selector.call_targets.reserved][3] += (u64)selector.call_targets.total_count * (sizeof(IrSymbolId) + sizeof(u8));''')
path.write_text(text)
