from pathlib import Path
import hashlib
import json
import platform
import subprocess
import zipfile

root = Path(__file__).parent.resolve()
repo = root / 'buster'
audit_id = '2026-10-15T085001Z'
destination = repo / 'docs/performance-audits/evidence' / audit_id
destination.mkdir(parents=True, exist_ok=True)

files = []
for directory in ['native', 'native-4k', 'census']:
    files.extend(p for p in (root / directory).rglob('*') if p.is_file())
for directory in ['artifacts', 'artifacts-4k']:
    files.extend(p for p in (root / directory).iterdir() if p.is_file() and p.suffix in ['.json', '.log'])
files.extend(p for p in (root / 'inputs').iterdir() if p.name != 'original-unity.i')
patterns = ['*-CMakeCache.txt', '*compile_commands.json', '*-build.log', '*-generate.log',
            '*-self-host.log', '*-mode-matrix.log', '*-test-all.log', '*identities.txt',
            '*-fixed-point.json', 'candidate*.patch', 'diagnostic.patch']
for pattern in patterns:
    files.extend(root.glob(pattern))
for name in ['instrument_builder.py', 'run_census.py', 'run_native.py', 'run_native4.py',
             'check_artifacts.py', 'assemble_evidence.py', 'write_audit.py', 'validation.json', 'frozen-provenance.json',
             'selection-controls.json', 'selection-controls.log', 'native-host-load.txt',
             'transparent-hugepage-policy.txt', 'buster-environment.txt', 'claim-4243.md',
             'second-candidate.md', 'census-checkpoint.md']:
    files.append(root / name)
files = sorted(set(files))
assert all(p.is_file() for p in files)
manifest = dict(schema='buster-4243-chunk-policy-evidence-v1',
                baseline='35fee905e39941acafb26db6d6ff3f41eb7d8dc7',
                candidate_2k='5d7aa3599442f743ff46576235676ac81ecceb40',
                candidate_4k='9d14f16459b611bd3ee7b1b3bfcffb48ed97d7a6',
                claim='native CPU on the recorded host and workloads; no RSS, whole-compiler or Zen 5 improvement claimed',
                host=dict(system=platform.platform(), cpu='AMD Ryzen 9 7940HS', affinity=2),
                stream_ids=['instructions', 'virtual_registers', 'blocks', 'edges', 'block_parameters',
                            'edge_copy_sources', 'immediates', 'stack_slots', 'call_targets', 'switch_cases',
                            'va_args', 'inline_assemblies', 'inline_assembly_operands', 'inline_assembly_relocations'],
                files={str(p.relative_to(root)): dict(bytes=p.stat().st_size,
                       sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files})
archive = destination / '4243-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files: z.write(p, str(p.relative_to(root)))
manifest['archive'] = dict(file=archive.name, bytes=archive.stat().st_size,
                          sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
