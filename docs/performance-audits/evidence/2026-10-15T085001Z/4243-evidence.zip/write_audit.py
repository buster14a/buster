from pathlib import Path
import json
import statistics

root = Path(__file__).parent.resolve()
repo = root / 'buster'
audit_id = '2026-10-15T085001Z'
census = json.loads((root / 'census/summary.json').read_text())
native = json.loads((root / 'native-4k/all-results.json').read_text())
manifest = json.loads((repo / 'docs/performance-audits/evidence' / audit_id / 'manifest.json').read_text())
validation = json.loads((root / 'validation.json').read_text())
baseline = json.loads((root / 'baseline-fixed-point.json').read_text())
candidate = json.loads((root / 'candidate-fixed-point.json').read_text())
assert all(item['exit_code'] == 0 for item in validation.values())
assert baseline['ide-stage1'] == baseline['ide-stage2']
assert candidate['ide-stage1'] == candidate['ide-stage2']

def count(n): return f'{n:,}'
def pair(case, key):
    arms = census[case]
    return f"{count(arms['baseline']['totals'][key])} → {count(arms['candidate-4k']['totals'][key])}"
def metric(case, mode, key):
    return next(m for m in native[f'{case}-{mode}']['metrics'] if m['name'] == key)
def cpu(case, mode):
    m = metric(case, mode, 'cpu_seconds')
    return f"{m['relative_change']*100:+.2f}% ({m['verdict']})"

cases = list(census)
storage_table = '\n'.join(f"| {case} | {count(census[case]['baseline']['totals']['payload'])} | {pair(case, 'reserved')} | {pair(case, 'chunks')} | {pair(case, 'copied')} | {pair(case, 'max_peak')} |" for case in cases)
index_table = '\n'.join(f"| {case} | {count(census[case]['baseline']['totals']['lookups'])} | {pair(case, 'index_chunks')} | {pair(case, 'index_allocated')} | {pair(case, 'index_copied')} |" for case in cases)
native_table = '\n'.join(f"| {case} | {cpu(case, 'fast')} | {cpu(case, 'quality')} | {metric(case, 'fast', 'max_rss_kib')['relative_change']*100:+.2f}% / {metric(case, 'quality', 'max_rss_kib')['relative_change']*100:+.2f}% |" for case in cases)
provenance = json.loads((root / 'frozen-provenance.json').read_text())
compiler_hashes = '\n'.join(f"- `{name}`: `{provenance[name]['sha256']}`." for name in ['ide-baseline', 'ide-candidate', 'ide-candidate-4k'])
validation_table = '\n'.join(f"- `{name}`: {value['result']}." for name, value in validation.items())

body = f'''`{audit_id}` (Linux x86_64, Ryzen 9 7940HS, Clang 23.1.1 native ISA;
**MIR builder chunk policy census and paired native comparison**).

Fixed 4 KiB chunks pass the declared native CPU and resource guards on the
recorded small/medium controls. They replace the 16 KiB default for the shared
machine streams. The 2 KiB candidate is rejected for measured RSS regressions.
**No lower RSS, complete-compiler speedup, or Zen 5 improvement is established.**
Owning issue: [#4243](https://github.com/buster14a/buster/issues/4243).

## Decision, provenance and limits

Baseline: `35fee905e39941acafb26db6d6ff3f41eb7d8dc7`.
2 KiB experiment: `5d7aa3599442f743ff46576235676ac81ecceb40`.
Selected 4 KiB implementation: `9d14f16459b611bd3ee7b1b3bfcffb48ed97d7a6`.
The final production difference is one size constant. Subsequent source work
adds only a test assertion/comment; documentation and evidence do not enter the
tests-off compiler. The index, append, materialization and lifetime algorithms
are unchanged. The shared default also applies to encoder auxiliary streams;
native compile/link observations include their costs.

Trusted Clang Release unity compilers were built serially in one owned checkout
and the same `build/profile` path, with identical saved CMake caches and compile
commands: tests off, `-O3 -march=native`, frame pointers/debug information on,
no LTO/PGO. Executable text/data/BSS sizes match across all three binaries.
The preprocessed unity input was frozen before the policy changes; every arm
compiled the same bytes and flags. Complete input, source-patch, configuration
and binary hashes are retained. Frozen compiler SHA-256 identities:

{compiler_hashes}

This is a shared Ryzen 9 7940HS Linux desktop, logical CPU 2 affinity, with
other sessions active. Native data establish only the recorded host/workload
CPU scope under the repository's `native-host` evidence route. The A/A controls
and all inconclusive results are retained; no retry selected a preferred result.
Transparent-huge-page policy and the inherited Buster environment are recorded.
The cause of the 2 KiB RSS increase is unproven.

The [initial declaration](https://github.com/buster14a/buster/issues/4243#issuecomment-6187870621)
set a 3% native effect floor, identical MIR/artifacts, bounded scratch and a
large-function CPU guard. Before measuring the second candidate,
[its declaration](https://github.com/buster14a/buster/issues/4243#issuecomment-6188163872)
made the 3% RSS guard explicit for one-large/geometric/pressure controls too.
Both candidates use 20 alternating pairs after one warmup per arm. An effect
qualifies only with the declared 3% floor and two-sided exact paired sign test
`p <= 0.05`, with matching effect/sign directions. There were no owned builds,
tests or diagnostic captures during native sampling.

## Native CPU, wall time and RSS

The repository `performance-evidence --tool time` helper records wall time,
user/system CPU, RSS, faults and context switches through `wait4`. Its headline
uses wall time. This experiment's predeclared CPU scope is **user + system per
observation**, recomputed from the raw pairs with the same median-ratio and
sign-test rule. `run_native.py` / `run_native4.py` retain that derivation in
`all-results.json`. The per-metric raw helper summaries remain unchanged.
Medians below without a qualified verdict are observations, not improvements.

| Input | FAST total CPU | QUALITY total CPU | Peak RSS change FAST / QUALITY |
|---|---|---|---|
{native_table}

All 4 KiB RSS metrics remain inside the 3% screen. Some RSS medians increase;
there is no RSS saving claim. The one-large control has 512 generated operations
in its chain, and geometric controls use 2,048/8,192/32,768 operations. Many-small
has 257 functions; mixed ABI covers 29 and pressure covers three. The complete
unity workload contains 6,550 selected functions.

The 2 KiB attempt remains a rejected result: one-large RSS increases 3.22%
(FAST) and 3.25% (QUALITY), and QUALITY pressure increases 3.06%, each significant.
Its qualified CPU savings do not override those resource observations. The
unity A/A total CPU control is -1.55%, `p=0.1153`; many-small A/A is -0.39%,
`p=0.2632`. Wall-time, system-time, fault and switching observations, including
neutral/inconclusive/regressive metrics, are all preserved in the raw evidence.

## Ordinary selection storage census

Temporary serial counters cover all 14 selector streams: the original ten
plus varargs and inline-assembly descriptor/operand/relocation streams. The
manifest maps stream IDs. They count actual chunk allocation requests, row
payload, flatten copies, same-arena borrowing, call/slot column-projection
writes, chunk-index allocations/copies and actual lookup calls. The wrapper
resets the arena high-water field for each selection, then restores its prior
maximum. Copy bytes below include output projection stores; they are not a
memory-bandwidth measurement. Alignment is captured in actual high water;
stream reservation itself counts chunk headers plus row capacity.

Each cell is one ordinary FAST native compile/link, not warm replay. Totals
sum arena suballocations over functions, and **are not simultaneously live
memory, malloc counts, touched pages or RSS**. High water is the maximum one
function's selector arena span, including transient allocation. Encoder
auxiliary streams and downstream edge-splitting copies are outside this
selector census; their execution remains included in native measurements.

| Input | Unchanged payload bytes | Reserved bytes 16 → 4 KiB | Chunks 16 → 4 KiB | Copied/projected bytes 16 → 4 KiB | Per-function high water 16 → 4 KiB |
|---|---:|---:|---:|---:|---:|
{storage_table}

Unity reservation falls 69.77%, but copying rises by 24,407,792 bytes and peak
function scratch falls only 40,040 bytes. Those costs and limits explain why
the reservation total is not presented as a whole-compiler saving.

| Input | Unchanged register lookups | Indexed chunks 16 → 4 KiB | Index allocation bytes 16 → 4 KiB | Index copied bytes 16 → 4 KiB |
|---|---:|---:|---:|---:|
{index_table}

The direct lookup index remains O(1); the geometric 32,768 control shows its
extra allocation/copy cost while retaining bounded high water. Existing tests
sever the linked chunk list before indexed row lookup, so a list-walk regression
cannot hide behind matching row values.

## Correctness and lifetime validation

All three policies have matching per-function SHA-256 identities for selected
MIR structural replay, chunk-backed side tables, line marks and normalized
inline-assembly contents. MIR verification passes on every replay input.
Replay uses retained canonical IR and is kept separate from ordinary census
populations and all acceptance timing. Diagnostic artifacts also match the
corresponding uninstrumented artifact hashes.

Both candidates pass 32 complete linked comparisons each: eight inputs,
FAST/QUALITY and `-g0`/`-g`. All outputs match baseline byte-for-byte. Original
closed-form executable oracles and independent Clang builds pass; each
unity-produced compiler builds and executes the pressure oracle. Empty,
syntax-only, declaration-only, unsupported-signature fallback and argument-count
selector refusal controls pass without a misleading benchmark row.

The focused regression bounds the existing one-chunk borrowed function's four
populated streams plus vreg index to 20 KiB; the 16 KiB policy exceeds this.
Existing tests retain exact row order across multiple chunks and prove that
finishing into another arena copies, surviving immediate builder-arena release.
Shared x86-64/AArch64 backend and FAST/QUALITY validation is covered by the
registered machine suite and mode matrix; cross-generated objects do not
establish native execution on a foreign host.

{validation_table}

Baseline self-host stages match at {count(baseline['ide-stage1']['bytes'])} bytes,
SHA-256 `{baseline['ide-stage1']['sha256']}`. Candidate stages match at
{count(candidate['ide-stage1']['bytes'])} bytes, SHA-256
`{candidate['ide-stage1']['sha256']}`. Hosted checks and protected integration
are tracked on the owning PR/issue; this audit does not mark unrun hosted gates
green.

## Reproduction and retained evidence

[Manifest](evidence/{audit_id}/manifest.json) and
[raw evidence](evidence/{audit_id}/4243-evidence.zip) retain both complete
native attempts, A/A controls, raw census/replay output, frozen inputs, driver
scripts, patches, build metadata, artifact hashes and validation logs. Archive
SHA-256: `{manifest['archive']['sha256']}`. Frozen binaries stay in this
session's owned local workspace and are bound by the recorded identities.

Reproduce the trusted builds serially in an isolated checkout at the three
commits, using `./build.sh generate --cc clang --no-include-tests
--build-directory build/profile` once and the matching Release `ide` target.
Freeze each binary before changing source. Place the evidence scripts/inputs
beside that checkout as their recorded `work/` layout; inspect their root and
revision bindings before executing on a different host. `run_native.py` and
`run_native4.py` run the two paired campaigns. Apply `instrument_builder.py`
only after freezing native binaries, build one diagnostic binary, and run
`run_census.py`: environment policy 0/1/4 selects 16/2/4 KiB in that diagnostic.
Its counters/hash work perturb runtime and never become acceptance binaries.
Restore all three instrumented source files before production validation.
The archive includes all diagnostic changes and commands, not just inferred
formulas. A different host/build path produces fresh identities and requires
its own controls rather than inheriting this host's result.

Buster first-party licensing is unselected (`NOASSERTION`) per
[LICENSES/README.md](../../LICENSES/README.md) at the baseline. Clang/LLVM uses
Apache-2.0 WITH LLVM-exception, with component terms in the
[LLVM notice](../../LICENSES/llvm-LICENSE.txt). No external implementation or
dependency is imported.
'''
(repo / 'docs/performance-audits' / f'{audit_id}.md').write_text(body)
print('Wrote', len(body), 'audit bytes')
