from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path(__file__).parent.resolve()
repo = root / 'buster'
candidate_name = sys.argv[1] if len(sys.argv) > 1 else 'ide-candidate'
out = root / (sys.argv[2] if len(sys.argv) > 2 else 'artifacts')
out.mkdir(exist_ok=False)
cases = ['many-small', 'one-large', 'abi-and-memory', 'pressure-256', 'large-2048', 'large-8192', 'large-32768', 'unity']
records = []
for case in cases:
    source = root / 'inputs' / (case + ('.i' if case == 'unity' else '.c'))
    for mode in ['fast', 'quality']:
        for debug in ['g0', 'g']:
            hashes = []
            for arm in ['baseline', 'candidate']:
                exe = out / f'{case}-{mode}-{debug}-{arm}'
                command = [str(root / ('ide-baseline' if arm == 'baseline' else candidate_name)), 'cc', '-march=native', '-' + debug,
                           f'-fregister-allocator={mode}', str(source), '-lm', '-o', str(exe)]
                p = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
                (out / (exe.name + '.log')).write_bytes(p.stdout)
                assert p.returncode == 0, (command, p.returncode, p.stdout[-2000:])
                hashes.append(hashlib.sha256(exe.read_bytes()).hexdigest())
                if case == 'unity':
                    oracle = out / 'unity-oracle'
                    subprocess.run([str(exe), 'cc', '-g0', str(root / 'inputs' / 'pressure-256.c'), '-o', str(oracle)], check=True, cwd=repo, capture_output=True, timeout=120)
                    subprocess.run([str(oracle)], check=True, timeout=20)
                else:
                    subprocess.run([str(exe)], check=True, timeout=20)
            assert hashes[0] == hashes[1], (case, mode, debug, hashes)
            record = {'case': case, 'mode': mode, 'debug': debug, 'sha256': hashes[0], 'bytes': exe.stat().st_size}
            records.append(record)
            print(json.dumps(record), flush=True)
    if case != 'unity':
        exe = out / ('clang-' + case)
        subprocess.run(['clang', '-O2', str(source), '-o', str(exe)], check=True, timeout=120)
        subprocess.run([str(exe)], check=True, timeout=20)
(out / 'checks.json').write_text(json.dumps(records, indent=2) + '\n')
