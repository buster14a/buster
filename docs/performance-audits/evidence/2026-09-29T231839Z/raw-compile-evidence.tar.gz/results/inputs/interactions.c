/* Isolated hypotheses, not assumed canonical-IR shapes. */
volatile unsigned phase_observed;
unsigned phi_identity(unsigned x, unsigned condition)
{
    unsigned y;
    if (condition) y = x + 0u;
    else y = x;
    return y;
}
unsigned phi_constant_cast(unsigned x, unsigned condition)
{
    unsigned z = 7u, y;
    if (condition) y = (unsigned)z;
    else y = z;
    return y * 3u + (x & 0u);
}
unsigned equal_bits_not_ids(unsigned x, unsigned condition)
{
    unsigned z = 7u, y;
    if (condition) y = z + 0u;
    else y = z;
    return y * 3u + x;
}
unsigned same_type_address(unsigned* pointer, unsigned condition)
{
    unsigned* q = (unsigned*)pointer;
    (void)condition;
    return *(&*q);
}
unsigned pointer_join(unsigned* pointer, unsigned condition)
{
    unsigned* q;
    if (condition) q = pointer + 0;
    else q = pointer;
    return *(&*q);
}
unsigned dead_phi(unsigned b, unsigned a)
{
    unsigned x = a + 2u, y;
    if (b) y = x + 0u;
    else y = x;
    (void)(y + 1u);
    return 0u;
}
unsigned parameter_cap(unsigned n, unsigned x)
{
    unsigned a = x, b = x, c = x, d = x, e = x;
    while (n--)
    {
        a = b + 0u; b = c + 0u; c = d + 0u; d = e + 0u; e = x + 0u;
    }
    return a;
}
unsigned no_match(unsigned x, unsigned y)
{
    return (x * 33u) ^ (y >> 3);
}
unsigned negative_volatile(unsigned x, unsigned y)
{
    unsigned unused = phase_observed;
    phase_observed = x;
    (void)unused;
    return x ^ y;
}
unsigned negative_division(unsigned x, unsigned y)
{
    unsigned unused = x / (y | 1u);
    (void)unused;
    return x;
}
