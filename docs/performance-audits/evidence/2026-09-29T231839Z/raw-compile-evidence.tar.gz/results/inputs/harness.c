#include <stdio.h>
extern volatile unsigned phase_observed;
extern unsigned phi_identity(unsigned, unsigned);
extern unsigned phi_constant_cast(unsigned, unsigned);
extern unsigned equal_bits_not_ids(unsigned, unsigned);
extern unsigned same_type_address(unsigned*, unsigned);
extern unsigned pointer_join(unsigned*, unsigned);
extern unsigned dead_phi(unsigned, unsigned);
extern unsigned parameter_cap(unsigned, unsigned);
extern unsigned no_match(unsigned, unsigned);
extern unsigned negative_volatile(unsigned, unsigned);
extern unsigned negative_division(unsigned, unsigned);
int main(void)
{
    unsigned state = 20260907u;
    for (unsigned i = 0; i < 4096u; ++i)
    {
        state ^= state << 13; state ^= state >> 17; state ^= state << 5;
        unsigned x = state, y = state * 2654435761u, c = i & 1u;
        unsigned data[2] = {x, y};
        phase_observed = y;
        unsigned r[11];
        r[0] = phi_identity(x, c); r[1] = phi_constant_cast(x, c);
        r[2] = equal_bits_not_ids(x, c); r[3] = same_type_address(data + c, c);
        r[4] = pointer_join(data + c, c); r[5] = dead_phi(c, x);
        r[6] = parameter_cap(i & 7u, x); r[7] = no_match(x, y);
        r[8] = negative_volatile(x, y); r[9] = negative_division(x, y);
        r[10] = phase_observed;
        printf("%u %u %u %u %u %u %u %u %u %u %u\n",
               r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10]);
    }
    return 0;
}
