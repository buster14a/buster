#!/usr/bin/env python3
"""Retain exact artifacts, independent consumers and paired work receipts."""
import argparse
import hashlib
import json
import pathlib
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=('validate', 'measure'))
parser.add_argument('--repo', type=pathlib.Path, required=True)
parser.add_argument('--work', type=pathlib.Path, required=True)
parser.add_argument('--candidate-revision', required=True)
args = parser.parse_args()
repo, work = args.repo.resolve(), args.work.resolve()
base_revision = 'c14841ae8e286447cf126de59119a887c13c9e36'
bins = [work / 'bin' / 'ide-baseline', work / 'bin' / 'ide-candidate']
inputs = work / 'inputs'
inputs.mkdir(exist_ok=True)

def run(argv, log, cwd=repo):
    with open(log, 'wb') as output:
        subprocess.run(list(map(str, argv)), cwd=cwd, stdout=output,
                       stderr=subprocess.STDOUT, check=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def generate(n, width, location='late', same=False, name=None):
    name = name or f'grid-{n}-{width}-{location}-{"same" if same else "distinct"}'
    source = inputs / (name + '.c')
    observer = inputs / (name + '-observer.c')
    bits = max(1, (n - 1).bit_length())
    first = width - bits if location == 'late' else 0
    definitions, observations = [], []
    for i in range(n):
        fields = []
        for k in range(width):
            floating = not same and first <= k < first + bits and (i >> (k - first)) & 1
            fields.append(f'{"float" if floating else "int"} f{k};')
            value = 1 + (i + k) % 7
            observations += [f'failed |= g{i}.f{k} != 0;', f'g{i}.f{k} = {value};',
                             f'failed |= g{i}.f{k} != {value};']
        definitions.append(f'struct T{i} {{ {" ".join(fields)} }};')
    source.write_text('\n'.join(definitions + [f'struct T{i} g{i};' for i in range(n)]) + '\n')
    observer.write_text('\n'.join(definitions + [f'extern struct T{i} g{i};' for i in range(n)] +
                                 ['int main(void) { int failed = 0;'] + observations + ['return failed; }']) + '\n')
    return source, observer

if args.action == 'validate':
    out = work / 'artifact-validation'
    out.mkdir()
    grid = [(n, w, 'late', False) for n in (1, 8, 32, 128) for w in (8, 32, 128)]
    grid += [(n, w, location, same) for n in (32, 128) for w in (8, 128)
             for location, same in (('early', False), ('late', True))]
    results = []
    for n, w, location, same in grid:
        source, observer = generate(n, w, location, same)
        name = source.stem
        observer_object = out / (name + '-observer.o')
        run(['clang', '-std=c11', '-O0', '-c', observer, '-o', observer_object],
            out / (name + '-observer.log'))
        for frontend in ('-ffrontend-ssa', '-fno-frontend-ssa'):
            label = name + ('-ssa' if frontend == '-ffrontend-ssa' else '-stack')
            artifacts = []
            for arm, binary in zip(('base', 'candidate'), bins):
                bc = out / (label + '-' + arm + '.bc')
                run([binary, 'cc', '-g0', '-emit-llvm', frontend, source, '-o', bc],
                    out / (label + '-' + arm + '.log'))
                artifacts.append(bc)
            assert artifacts[0].read_bytes() == artifacts[1].read_bytes(), label
            obj, executable = out / (label + '.o'), out / (label + '.exe')
            run(['clang', '-c', artifacts[1], '-o', obj], out / (label + '-consumer.log'))
            run(['clang', observer_object, obj, '-o', executable], out / (label + '-link.log'))
            run([executable], out / (label + '-run.log'))
            results.append(dict(case=label, bytes=artifacts[1].stat().st_size,
                                sha256=sha(artifacts[1]), identical=True, independent_execution=True,
                                source_sha256=sha(source), observer_sha256=sha(observer)))
        print(f'PASS {name}: both frontend forms, exact bytes and independent execution', flush=True)
    for n in (32, 128, 512, 2048):
        for same in (False, True):
            source = inputs / f'types-{"same" if same else "distinct"}-{n}.c'
            artifacts = []
            for arm, binary in zip(('base', 'candidate'), bins):
                bc = out / (source.stem + '-' + arm + '.bc')
                run([binary, 'cc', '-g0', '-emit-llvm', source, '-o', bc], out / (bc.stem + '.log'))
                artifacts.append(bc)
            assert artifacts[0].read_bytes() == artifacts[1].read_bytes(), str(source)
            run(['clang', '-c', artifacts[1], '-o', out / (source.stem + '.o')],
                out / (source.stem + '-consumer.log'))
            results.append(dict(case=source.stem, bytes=artifacts[1].stat().st_size,
                                sha256=sha(artifacts[1]), identical=True, independent_consumption=True,
                                source_sha256=sha(source)))
    manifest = dict(baseline_revision=base_revision, candidate_revision=args.candidate_revision,
                    binaries=[dict(path=str(b), sha256=sha(b)) for b in bins], cases=results)
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'PASS all {len(results)} artifact comparisons', flush=True)
else:
    out = work / 'measurements'
    out.mkdir()
    cases = [(f'distinct-{n}', ['cc', '-g0', '-emit-llvm', str(inputs / f'types-distinct-{n}.c'), '-o', '/dev/null'])
             for n in (32, 128, 512, 2048)]
    cases.append(('same-2048', ['cc', '-g0', '-emit-llvm', str(inputs / 'types-same-2048.c'), '-o', '/dev/null']))
    early, _ = generate(2048, 128, 'early', False, 'types-early-2048')
    cases.append(('early-2048', ['cc', '-g0', '-emit-llvm', str(early), '-o', '/dev/null']))
    cases.append(('native-control', ['cc', '-g0', '-c', str(inputs / 'types-distinct-2048.c'), '-o', '/dev/null']))
    frozen = work / 'frozen-input'
    common = ['cc', '-I' + str(frozen / 'src'), '-I' + str(frozen / 'build/generated'),
              '-DBUSTER_UNITY_BUILD=1', '-DBUSTER_INCLUDE_TESTS=0', '-g0']
    cases.append(('unity-llvm', common + ['-emit-llvm', str(frozen / 'src/buster/apps/ide/ide.c'), '-o', '/dev/null']))
    cases.append(('unity-native', common + ['-c', str(frozen / 'src/buster/apps/ide/ide.c'), '-o', '/dev/null']))
    results = []
    for name, command in cases:
        destination = out / name
        run([work / 'bin/performance-evidence', 'compare', '--claim', 'work-reduction', '--tool', 'perf-stat',
             '--runs', '6', '--events', 'instructions:u', '--baseline', bins[0], '--candidate', bins[1],
             '--baseline-revision', base_revision, '--candidate-revision', args.candidate_revision,
             '--out', destination, '--'] + command, out / (name + '.log'))
        result = json.loads((destination / 'summary.json').read_text())
        assert result['complete'], result
        results.append(dict(case=name, summary=result))
        print(name + ': ' + result['result'], flush=True)
    (out / 'manifest.json').write_text(json.dumps(results, indent=2) + '\n')
