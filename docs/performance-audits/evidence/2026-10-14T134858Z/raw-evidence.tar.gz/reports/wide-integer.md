Observed on 2026-10-14 while validating the bounded #1362 type-index change. This is a pre-existing defect, not an attribution to the index: the trusted baseline at main `c14841ae8e286447cf126de59119a887c13c9e36` and candidate `c24a788bbf410c750d6aee13e215408e7792d76f` produce byte-identical rejected bitcode.

Reproduce from the baseline checkout with a tests-off Clang 23.1.1 Release compiler (`BUSTER_NATIVE_TARGET=x86-64-v3`, required C flags retained):

```sh
./build.sh generate --cc clang --no-include-tests --build-directory build/performance -- -DBUSTER_NATIVE_TARGET=x86-64-v3
./build.sh build --build-directory build/performance --config Release -t ide
build/performance/Release/ide cc -Isrc -Ibuild/performance/generated -DBUSTER_UNITY_BUILD=1 -DBUSTER_INCLUDE_TESTS=0 -g0 -emit-llvm src/buster/apps/ide/ide.c -o unity.bc
opt -passes=verify -disable-output unity.bc
llvm-bcanalyzer -dump unity.bc > unity-records.txt
```

Observed: Buster exits 0, but LLVM 23.1.1 `opt` exits 1 with `Invalid wide integer const record`. The retained frozen-source artifact is 29,358,148 bytes, SHA-256 `f26cadaa8a9be2dd0848a921668a18e7061e227bf8e8d9c0dbba9a5774251af2`; path spellings are bound by the accompanying audit, so a fresh root can change that hash. `llvm-bcanalyzer` shows a module constant `<SETTYPE op0=11/>` followed by an operand-free `<WIDE_INTEGER/>`.

Expected: a successful export is accepted by the independent LLVM reader/verifier, or Buster fails with a structured diagnostic before publishing a successful artifact.

Source evidence: `llvm_bc_wide_integer_constant_for_type_id` in `src/buster/lib/compiler/llvm/bitcode.c` initializes `active_words=0`, updates it only for nonzero words, and can hand that zero count to `llvm_bc_add_constant`. LLVM 23.1.1's [reader](https://github.com/llvm/llvm-project/blob/llvmorg-23.1.1/llvm/lib/Bitcode/Reader/BitcodeReader.cpp#L3200) explicitly rejects an empty `CST_CODE_WIDE_INTEGER`. The exact source construct that reaches this path in the unity unit has not been minimized. Standalone i128 return-zero/one/minus-one and comparison/logical/multiply-zero controls verified successfully; they do not reproduce it.

The current optimization's 48 smaller export comparisons are byte-identical and independently consumed by Clang; its full Release suite, self-host fixed point and focused sanitized LLVM module pass. Those successes do not cover this unity export defect. The unity export is excluded from performance qualification; its raw instruction-count comparison is diagnostic only.

Completion: minimize the actual reachability, add an independent LLVM consumer regression including zero wide constants and unchanged nonzero/negative cases, fix the record or use a valid null constant, preserve deterministic output and structured failure behavior, and make the frozen unity export pass LLVM verification. No ownership claim for the repair is made by this report.

Licenses: Buster first-party license is unselected/NOASSERTION per [LICENSES/README.md at the baseline](https://github.com/buster14a/buster/blob/c14841ae8e286447cf126de59119a887c13c9e36/LICENSES/README.md). LLVM 23.1.1 is Apache-2.0 WITH LLVM-exception, with component exceptions listed in its [license file](https://github.com/llvm/llvm-project/blob/llvmorg-23.1.1/llvm/LICENSE.TXT). No upstream implementation is imported.
