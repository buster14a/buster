Observed on 2026-10-14 during representative-input qualification for the bounded #1362 type-index change. The failure reproduces with the unchanged trusted compiler on main `c14841ae8e286447cf126de59119a887c13c9e36`; no causal attribution to the index is made.

Using a tests-off Clang 23.1.1 Release `ide`, `BUSTER_NATIVE_TARGET=x86-64-v3`, required C flags retained:

```sh
./build.sh generate --cc clang --no-include-tests --build-directory build/performance -- -DBUSTER_NATIVE_TARGET=x86-64-v3
./build.sh build --build-directory build/performance --config Release -t ide
build/performance/Release/ide cc -Isrc -Ibuild/performance/generated -DBUSTER_UNITY_BUILD=0 -DBUSTER_INCLUDE_TESTS=0 -g0 -emit-llvm src/buster/lib/compiler/object/object.c -o object.bc
opt -passes=verify -disable-output object.bc
```

The same failure occurs when the input is `src/buster/lib/compiler/llvm/bitcode.c`.

Observed: Buster returns success and publishes bitcode; independent LLVM 23.1.1 `opt` exits 1 with `INSERTVAL: Invalid instruction with 0 indices`. Expected: successful bitcode is accepted by the independent reader/verifier, or Buster diagnoses an unsupported construct and refuses a successful artifact.

Start at `llvm_bc_emit_instruction` in `src/buster/lib/compiler/llvm/bitcode.c`, which emits `LLVM_BC_FUNC_INSERTVAL` after building the canonical aggregate index path. The exact source construct and whether the missing index is caused by an empty aggregate path, ABI transport or another producer have not been minimized or established. This report records the reader failure, not a proven repair. `src/buster/lib/hash.c` independently verifies under the same configuration, so this is not a blanket inability to read Buster bitcode.

The optimization session keeps both affected real-source files out of performance qualification. Its full Release suite, self-host fixed point and focused sanitized LLVM module pass, and 48 smaller before/after exports are byte-identical and independently consumed; these tests do not cover the failed files. The separate empty wide-integer failure on the full unity export is #4223.

Completion: minimize each failing source to a retained independent consumer regression, determine the missing-index producer, repair valid aggregate indexing or diagnose the unsupported path without partial success, preserve first-seen type/value IDs and ABI behavior, and make both original standalone exports verify. No repair ownership is claimed by this report.

Licenses: Buster first-party license is unselected/NOASSERTION per [LICENSES/README.md at the inspected baseline](https://github.com/buster14a/buster/blob/c14841ae8e286447cf126de59119a887c13c9e36/LICENSES/README.md). LLVM 23.1.1 is Apache-2.0 WITH LLVM-exception with separately identified component terms in its [license file](https://github.com/llvm/llvm-project/blob/llvmorg-23.1.1/llvm/LICENSE.TXT). No upstream implementation is imported.
