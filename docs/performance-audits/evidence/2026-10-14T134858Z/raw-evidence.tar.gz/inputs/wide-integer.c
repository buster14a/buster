__int128 zero(void) { return 0; }
__int128 one(void) { return 1; }
__int128 minus_one(void) { return -1; }
