int equal(__int128 x) { return x == 0; }
int unequal(__int128 x) { return x != 0; }
int logical(__int128 x) { return !x; }
__int128 multiply(__int128 x) { return x * 0; }
