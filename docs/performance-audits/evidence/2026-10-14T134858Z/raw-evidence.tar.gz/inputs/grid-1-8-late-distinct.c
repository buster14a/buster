struct T0 { int f0; int f1; int f2; int f3; int f4; int f5; int f6; int f7; };
struct T0 g0;
