#!/usr/bin/env bash
# Reproduce independent helper correctness, not Buster integration or throughput.
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
python3 - "$root/raw/quality-125-populations-36000528004-1.zip" "$work/capture" <<'PY'
import hashlib, sys, zipfile
from pathlib import Path
archive, destination = map(Path, sys.argv[1:])
expected = '085ce2e62f963059d6f6dafdedc999ba914aff5ee26c04e23026b6c62ab1bc04'
if hashlib.sha256(archive.read_bytes()).hexdigest() != expected:
    raise SystemExit('FAIL: original capture ZIP digest mismatch')
with zipfile.ZipFile(archive) as z:
    for item in z.infolist():
        p = Path(item.filename)
        if p.is_absolute() or '..' in p.parts:
            raise SystemExit('FAIL: unsafe archive member')
    z.extractall(destination)
PY
python3 "$root/analyze_populations.py" "$work/capture" "$work/evidence"
cmp "$root/evidence/replay.txt" "$work/evidence/replay.txt"
cmp "$root/evidence/population-summary.json" "$work/evidence/population-summary.json"
flags=(-std=c11 -g -Wall -Wextra -Wpedantic -Wconversion -Wsign-conversion -Werror
       -fwrapv -fno-strict-aliasing -funsigned-char)
clang "${flags[@]}" -O2 "$root/region_enumeration_test.c" -o "$work/clang-test"
gcc "${flags[@]}" -O2 "$root/region_enumeration_test.c" -o "$work/gcc-test"
clang "${flags[@]}" -O1 -fsanitize=address,undefined -fno-omit-frame-pointer \
    "$root/region_enumeration_test.c" -o "$work/sanitize-test"
"$work/clang-test" "$work/evidence/replay.txt" | tee "$work/clang.log"
"$work/gcc-test" "$work/evidence/replay.txt" > "$work/gcc.log"
ASAN_OPTIONS=halt_on_error=1:detect_leaks=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
    "$work/sanitize-test" "$work/evidence/replay.txt" > "$work/sanitize.log"
cmp "$work/clang.log" "$work/gcc.log"
cmp "$work/clang.log" "$work/sanitize.log"
cmp "$root/enumeration-clang.log" "$work/clang.log"
printf 'PASS: independent replay regenerated and all three helper builds agree.\n'
printf 'NOT RUN: Buster integration, sparse construction, placements, artifacts, full timing.\n'
