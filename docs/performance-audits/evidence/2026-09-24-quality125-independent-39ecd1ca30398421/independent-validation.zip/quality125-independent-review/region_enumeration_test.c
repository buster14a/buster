/* Independent extracted-helper validation for buster14a/buster #125.
 * Not a registered Buster test, full allocator, timing harness or implementation.
 * Scanner: main 5d1c314a8ee3c5f9fb713f6afb85ab1e795f44a0, source blob
 *   2ce4bfdfb73d07cd9a127812700108403b770de8.
 * Heap: other session's 033a0b884a6d45b4489a26f0af948e1b319fd067,
 *   tools/quality_125_sparse_helpers.c blob d0598b6e8b310ece77e17f6bbeda9eafea988da1.
 * Bodies of the scanner and four heap/comparator functions are transcribed
 * unchanged. Types and diagnostic counters below are minimal test adapters.
 * Extra algorithms are independent oracles, never production proposals.
 */
#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint32_t u32;
typedef uint64_t u64;
typedef u64 MachineQualityTraffic;
typedef struct MachineQualityRegionTraffic MachineQualityRegionTraffic;
struct MachineQualityRegionTraffic
{
    MachineQualityTraffic traffic;
    u32 region;
};
_Static_assert(sizeof(MachineQualityRegionTraffic) == 16, "prototype layout");
#define BUSTER_GLOBAL_LOCAL static
static u64 sparse_region_heap_steps;
static u64 sparse_region_heap_entries;
static u64 sparse_region_queries;
#define BUSTER_QUALITY_COUNT(name, amount) (name += (u64)(amount))

u32 machine_quality_region_next(MachineQualityTraffic const* traffic, u32 count, u32 previous_region)
{
    MachineQualityTraffic previous_traffic = previous_region == UINT32_MAX ? 0 : traffic[previous_region];
    MachineQualityTraffic best_traffic = 0;
    u32 best_region = UINT32_MAX;
    for (u32 region_index = 0; region_index < count; region_index += 1)
    {
        MachineQualityTraffic region_traffic = traffic[region_index];
        if (!region_traffic || (previous_region != UINT32_MAX &&
            (region_traffic > previous_traffic || (region_traffic == previous_traffic && region_index <= previous_region))))
        {
            continue;
        }
        if (region_traffic > best_traffic)
        {
            best_traffic = region_traffic;
            best_region = region_index;
        }
    }
    return best_region;
}

BUSTER_GLOBAL_LOCAL bool machine_quality_region_precedes(MachineQualityRegionTraffic left, MachineQualityRegionTraffic right)
{
    return left.traffic > right.traffic || (left.traffic == right.traffic && left.region < right.region);
}

void machine_quality_region_heap_sift(MachineQualityRegionTraffic* heap, u32 count, u32 root)
{
    // The bound prevents 2 * root + 1 overflowing even at UINT32_MAX entries.
    while (root < count / 2)
    {
        BUSTER_QUALITY_COUNT(sparse_region_heap_steps, 1);
        u32 child = 2 * root + 1;
        if (child + 1 < count && machine_quality_region_precedes(heap[child + 1], heap[child]))
        {
            child += 1;
        }
        if (!machine_quality_region_precedes(heap[child], heap[root]))
        {
            break;
        }
        MachineQualityRegionTraffic swapped = heap[root];
        heap[root] = heap[child];
        heap[child] = swapped;
        root = child;
    }
}

void machine_quality_region_heap_build(MachineQualityRegionTraffic* heap, u32 count)
{
    BUSTER_QUALITY_COUNT(sparse_region_heap_entries, count);
    for (u32 root = count / 2; root > 0; root -= 1)
    {
        machine_quality_region_heap_sift(heap, count, root - 1);
    }
}

MachineQualityRegionTraffic machine_quality_region_heap_pop(MachineQualityRegionTraffic* heap, u32* count)
{
    MachineQualityRegionTraffic result = {.traffic = 0, .region = UINT32_MAX};
    BUSTER_QUALITY_COUNT(sparse_region_queries, 1);
    if (*count)
    {
        result = heap[0];
        *count -= 1;
        heap[0] = heap[*count];
        heap[*count] = result;
        machine_quality_region_heap_sift(heap, *count, 0);
    }
    return result;
}

/* Independent oracles: sparse rescan and elementary insertion ordering. */
static MachineQualityRegionTraffic sparse_scan(MachineQualityRegionTraffic const* row, u32 count,
                                               MachineQualityRegionTraffic previous)
{
    MachineQualityRegionTraffic result = {0, UINT32_MAX};
    for (u32 i = 0; i < count; i += 1)
    {
        MachineQualityRegionTraffic value = row[i];
        bool after_previous = previous.region == UINT32_MAX || value.traffic < previous.traffic ||
            (value.traffic == previous.traffic && value.region > previous.region);
        if (after_previous && (value.traffic > result.traffic ||
            (value.traffic == result.traffic && value.region < result.region)))
        {
            result = value;
        }
    }
    return result;
}

static u64 insertion_order(MachineQualityRegionTraffic* row, u32 count)
{
    u64 comparisons = 0;
    for (u32 i = 1; i < count; i += 1)
    {
        MachineQualityRegionTraffic value = row[i];
        u32 j = i;
        while (j)
        {
            comparisons += 1;
            MachineQualityRegionTraffic before = row[j - 1];
            bool ordered = before.traffic > value.traffic ||
                (before.traffic == value.traffic && before.region < value.region);
            if (ordered) break;
            row[j] = before;
            j -= 1;
        }
        row[j] = value;
    }
    return comparisons;
}

static u64 checks;
static u64 real_rows;
static u64 real_selected;
static u64 generated_rows;
static u64 decision_hash = UINT64_C(14695981039346656037);
static u64 real_dense_cell_visits;
static u64 real_sparse_cell_visits;
static u64 real_heap_steps;
static u64 real_heap_entries;
static u64 real_sort_comparisons;

static void check(bool condition)
{
    checks += 1;
    if (!condition)
    {
        fprintf(stderr, "FAIL at check %" PRIu64 "\n", checks);
        abort();
    }
}

static void* allocate(size_t count, size_t size)
{
    void* result = calloc(count ? count : 1, size);
    if (!result)
    {
        fprintf(stderr, "out of memory\n");
        abort();
    }
    return result;
}

static void hash_decision(MachineQualityRegionTraffic value)
{
    decision_hash ^= value.region;
    decision_hash *= UINT64_C(1099511628211);
    decision_hash ^= value.traffic;
    decision_hash *= UINT64_C(1099511628211);
}

static void check_row(u32 l, u32 k, MachineQualityRegionTraffic const* row,
                      u32 observed_queries, u32 observed_count, MachineQualityRegionTraffic const* observed)
{
    MachineQualityTraffic* dense = allocate(l, sizeof(*dense));
    MachineQualityRegionTraffic* heap = allocate(k, sizeof(*heap));
    MachineQualityRegionTraffic* ordered = allocate(k, sizeof(*ordered));
    for (u32 i = 0; i < k; i += 1)
    {
        check(row[i].region < l && row[i].traffic > 0 && !dense[row[i].region]);
        dense[row[i].region] = row[i].traffic;
        heap[i] = row[i];
        ordered[i] = row[i];
    }
    u64 sort_comparisons = insertion_order(ordered, k);
    /* These counts replay observed queries only, including lazy heap setup;
     * they exclude CSR construction/teardown and are NOT comparable timings. */
    if (observed_queries)
    {
        u64 start_steps = sparse_region_heap_steps;
        machine_quality_region_heap_build(heap, k);
        u32 remaining = k;
        for (u32 q = 0; q < observed_queries; q += 1)
        {
            MachineQualityRegionTraffic actual = machine_quality_region_heap_pop(heap, &remaining);
            if (q < observed_count)
            {
                check(actual.region == observed[q].region && actual.traffic == observed[q].traffic);
                hash_decision(actual);
                real_selected += 1;
            }
            else check(actual.region == UINT32_MAX && actual.traffic == 0);
        }
        real_dense_cell_visits += (u64)l * observed_queries;
        real_sparse_cell_visits += (u64)k * observed_queries;
        real_heap_steps += sparse_region_heap_steps - start_steps;
        real_heap_entries += k;
        real_sort_comparisons += sort_comparisons;
    }
    /* Full consumption, partial consumption, full restart from a dirty heap.
     * Heap storage is deliberately not restored between these restarts. */
    for (u32 restart = 0; restart < 3; restart += 1)
    {
        u64 before_build = sparse_region_heap_steps;
        machine_quality_region_heap_build(heap, k);
        check(sparse_region_heap_steps - before_build <= k);
        u32 remaining = k;
        u32 previous = UINT32_MAX;
        MachineQualityRegionTraffic previous_sparse = {0, UINT32_MAX};
        for (u32 q = 0; q <= k; q += 1)
        {
            u32 expected = machine_quality_region_next(dense, l, previous);
            MachineQualityRegionTraffic sparse = sparse_scan(row, k, previous_sparse);
            MachineQualityRegionTraffic actual = machine_quality_region_heap_pop(heap, &remaining);
            check(actual.region == expected && sparse.region == expected);
            if (expected == UINT32_MAX)
            {
                check(actual.traffic == 0 && remaining == 0);
                check(q == k);
                break;
            }
            check(actual.traffic == dense[expected] && sparse.traffic == dense[expected]);
            check(ordered[q].region == expected && ordered[q].traffic == actual.traffic);
            previous = expected;
            previous_sparse = sparse;
            if (restart == 1 && q == k / 2) break;
        }
        u32 levels = 0;
        for (u32 bound = k; bound > 1; bound >>= 1) levels += 1;
        check(sparse_region_heap_steps - before_build <= (u64)k * (levels + 1));
    }
    free(ordered);
    free(heap);
    free(dense);
}

static u32 random_u32(u32* state)
{
    *state ^= *state << 13;
    *state ^= *state >> 17;
    *state ^= *state << 5;
    return *state;
}

static void generated_tests(void)
{
    u32 sizes[] = {0, 1, 2, 3, 4, 7, 8, 15, 16, 31, 32, 63, 64, 65, 127, 128, 136, 255, 512, 1024};
    u32 seed = UINT32_C(0xc001125);
    for (u32 si = 0; si < sizeof(sizes) / sizeof(sizes[0]); si += 1)
    {
        u32 l = sizes[si];
        MachineQualityRegionTraffic* row = allocate(l, sizeof(*row));
        for (u32 shape = 0; shape < 8; shape += 1)
        {
            for (u32 repeat = 0; repeat < 5; repeat += 1)
            {
                u32 k = 0;
                memset(row, 0xa5, (size_t)l * sizeof(*row));
                for (u32 r = 0; r < l; r += 1)
                {
                    u32 rnd = random_u32(&seed);
                    bool occupied = shape == 0 ? false : shape == 1 ? r == l / 2 :
                        shape == 2 ? rnd % 64 == 0 : shape == 3 ? rnd % 4 == 0 : true;
                    if (occupied)
                    {
                        u64 weight = shape == 4 ? 7 : shape == 5 ? (u64)UINT32_MAX + 1 + (rnd % 8) :
                            shape == 6 ? UINT64_C(17592186040320) - (rnd % 16) : (u64)(rnd % 17) + 1;
                        row[k++] = (MachineQualityRegionTraffic){weight, r};
                    }
                }
                /* Random physical layout challenges stability by ID, not position. */
                for (u32 i = k; i > 1; i -= 1)
                {
                    u32 j = random_u32(&seed) % i;
                    MachineQualityRegionTraffic temporary = row[i - 1];
                    row[i - 1] = row[j]; row[j] = temporary;
                }
                check_row(l, k, row, 0, 0, NULL);
                generated_rows += 1;
            }
        }
        free(row);
    }
    u32 zero = 0;
    check(machine_quality_region_next(NULL, 0, UINT32_MAX) == UINT32_MAX);
    check(machine_quality_region_heap_pop(NULL, &zero).region == UINT32_MAX);
    /* This intentionally changing ranking is OUTSIDE the immutable contract.
     * It proves a stored ordering is not generally valid after traffic updates. */
    MachineQualityTraffic mutable_costs[] = {10, 9, 8};
    MachineQualityRegionTraffic stale[] = {{10, 0}, {9, 1}, {8, 2}};
    u32 n = 3;
    machine_quality_region_heap_build(stale, n);
    check(machine_quality_region_heap_pop(stale, &n).region == 0);
    mutable_costs[1] = 1;
    check(machine_quality_region_next(mutable_costs, 3, 0) == 2);
    check(machine_quality_region_heap_pop(stale, &n).region == 1);
}

/* A counted-work growth challenge, not elapsed-time measurement. */
static void complexity_tests(void)
{
    printf("COMPLEXITY_MODEL L,K,dense_cells,sparse_cells,heap_build_steps,heap_pop_steps\n");
    for (u32 l = 1; l <= 4096; l *= 2)
    {
        for (u32 shape = 0; shape < 2; shape += 1)
        {
            u32 k = shape ? l : (l < 4 ? l : 4);
            MachineQualityRegionTraffic* row = allocate(k, sizeof(*row));
            for (u32 i = 0; i < k; i += 1)
                row[i] = (MachineQualityRegionTraffic){1 + ((u64)i * 137 % (k + 1)), i};
            u64 start = sparse_region_heap_steps;
            machine_quality_region_heap_build(row, k);
            u64 build_steps = sparse_region_heap_steps - start;
            check(build_steps <= k);
            u32 n = k;
            u32 levels = 0;
            for (u32 bound = k; bound > 1; bound >>= 1) levels += 1;
            start = sparse_region_heap_steps;
            for (u32 query = 0; query <= k; query += 1)
            {
                MachineQualityRegionTraffic value = machine_quality_region_heap_pop(row, &n);
                check((query == k) == (value.region == UINT32_MAX));
            }
            u64 pop_steps = sparse_region_heap_steps - start;
            check(pop_steps <= (u64)k * levels);
            printf("COMPLEXITY_MODEL %" PRIu32 ",%" PRIu32 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 "\n",
                l, k, (u64)l * (k + 1), (u64)k * (k + 1), build_steps, pop_steps);
            free(row);
        }
    }
}

int main(int argc, char** argv)
{
    int result = 0;
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s evidence/replay.txt\n", argv[0]);
        result = 2;
    }
    else
    {
        FILE* input = fopen(argv[1], "r");
        if (!input)
        {
            perror(argv[1]);
            result = 2;
        }
        else
        {
            u32 count = 0;
            check(fscanf(input, "%" SCNu32, &count) == 1);
            for (u32 index = 0; index < count; index += 1)
            {
                u32 l, k, q, d;
                check(fscanf(input, "%" SCNu32 " %" SCNu32 " %" SCNu32 " %" SCNu32, &l, &k, &q, &d) == 4);
                check(k <= l && q <= k + 1 && d <= k && d <= q);
                MachineQualityRegionTraffic* row = allocate(k, sizeof(*row));
                MachineQualityRegionTraffic* trace = allocate(d, sizeof(*trace));
                for (u32 i = 0; i < k; i += 1)
                    check(fscanf(input, "%" SCNu32 " %" SCNu64, &row[i].region, &row[i].traffic) == 2);
                for (u32 i = 0; i < d; i += 1)
                    check(fscanf(input, "%" SCNu32 " %" SCNu64, &trace[i].region, &trace[i].traffic) == 2);
                check_row(l, k, row, q, d, trace);
                real_rows += 1;
                free(trace); free(row);
            }
            int ch;
            do { ch = fgetc(input); } while (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r');
            check(ch == EOF && !ferror(input));
            check(fclose(input) == 0);
            generated_tests();
            complexity_tests();
            printf("PASS checks=%" PRIu64 " real_rows=%" PRIu64 " recorded_selected_regions=%" PRIu64
                " generated_rows=%" PRIu64 " decision_hash=%016" PRIx64 "\n",
                checks, real_rows, real_selected, generated_rows, decision_hash);
            printf("OPERATION_MODEL_ONLY dense_cell_visits=%" PRIu64 " sparse_scan_cell_visits=%" PRIu64
                " heap_sift_steps=%" PRIu64 " heap_build_entries=%" PRIu64 " insertion_sort_comparisons=%" PRIu64 "\n",
                real_dense_cell_visits, real_sparse_cell_visits, real_heap_steps, real_heap_entries, real_sort_comparisons);
            printf("NOT_RUN full_allocator construction placement ordered_edits emitted_artifacts timing PMU\n");
        }
    }
    return result;
}
