#!/usr/bin/env python3
"""Read the existing #125 hosted diagnostic capture; never a timing harness.

Strictly checks all table/row/query identities before writing deterministic
replay rows for the independently compiled C enumeration test. Source subjects,
placements and emitted objects are not in the capture and cannot be checked.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

PATTERNS = {
    "table": re.compile(r"Q125_TABLE f=(\d+) c=(\d+) l=(\d+) p=(\d+) e=(\d+) ordered=([01])"),
    "row": re.compile(r"Q125_ROW f=(\d+) s=(\d+)((?: \d+:\d+)*)"),
    "decision": re.compile(r"Q125_DECISION f=(\d+) s=(\d+) r=(\d+) w=(\d+)"),
    "query": re.compile(r"Q125_QUERY f=(\d+) s=(\d+) q=(\d+)"),
}
MAX_TRAFFIC = ((1 << 32) - 1) * 4096

def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def load_capture(root: Path, name: str) -> tuple[dict, list, list]:
    tables, rows, decisions, queries = {}, {}, {}, {}
    trace = []
    for lineno, line in enumerate((root / f"{name}.rows.log").read_text().splitlines(), 1):
        matches = [(kind, regex.fullmatch(line)) for kind, regex in PATTERNS.items()]
        match = next(((kind, m) for kind, m in matches if m), None)
        require(match is not None, f"{name}:{lineno}: unknown record")
        kind, m = match
        fields = m.groups()
        if kind == "table":
            f, c, l, p, e, ordered = map(int, fields)
            require(f not in tables and c > 0 and l > 0, f"{name}:{lineno}: bad table")
            tables[f] = dict(f=f, c=c, l=l, p=p, e=e, ordered=ordered)
        elif kind == "row":
            f, s = map(int, fields[:2])
            key = (f, s)
            require(f in tables and 0 <= s < tables[f]["c"] and key not in rows,
                    f"{name}:{lineno}: bad row identity")
            pairs = [tuple(map(int, x.split(":"))) for x in fields[2].split()]
            require(all(0 <= r < tables[f]["l"] and 0 < w <= MAX_TRAFFIC for r, w in pairs),
                    f"{name}:{lineno}: bad traffic")
            require(all(pairs[i - 1][0] < pairs[i][0] for i in range(1, len(pairs))),
                    f"{name}:{lineno}: nonascending or duplicate region")
            rows[key] = pairs
        elif kind == "decision":
            f, s, r, w = map(int, fields)
            key = (f, s)
            require(key in rows and key not in queries, f"{name}:{lineno}: bad decision scope")
            decisions.setdefault(key, []).append((r, w))
            trace.append(dict(form=name, f=f, s=s, r=r, w=w))
        else:
            f, s, q = map(int, fields)
            key = (f, s)
            require(key in rows and key not in queries and q > 0, f"{name}:{lineno}: bad query")
            queries[key] = q
    require(set(decisions) <= set(queries), f"{name}: unterminated decision scope")
    for f, table in tables.items():
        require(all((f, s) in rows for s in range(table["c"])), f"{name}: missing row")
        require(sum(len(rows[f, s]) for s in range(table["c"])) == table["p"],
                f"{name}: occupancy mismatch")
    exhausted = 0
    for key, q in queries.items():
        actual = decisions.get(key, [])
        expected = sorted(rows[key], key=lambda item: (-item[1], item[0]))
        require(actual == expected[:len(actual)], f"{name}: decision order mismatch {key}")
        require(q in (len(actual), len(actual) + 1), f"{name}: query count mismatch {key}")
        if q == len(actual) + 1:
            require(len(actual) == len(expected), f"{name}: false exhaustion {key}")
            exhausted += 1
    metrics = {}
    for line in (root / f"{name}.metrics").read_text().splitlines():
        key, sep, val = line.partition("=")
        if sep and key.startswith("quality_census."):
            metrics[key.removeprefix("quality_census.")] = int(val)
    expected_totals = dict(candidate_region_cells=sum(t["c"] * t["l"] for t in tables.values()),
        candidate_region_nonzero_cells=sum(len(row) for row in rows.values()),
        split_candidates=len(queries), region_selection_passes=sum(queries.values()),
        region_selection_cells=sum(tables[f]["l"] * q for (f, s), q in queries.items()),
        selected_regions=sum(len(d) for d in decisions.values()))
    for key, total in expected_totals.items():
        require(metrics[key] == total, f"{name}: aggregate mismatch for {key}: {metrics[key]} vs {total}")
    bins = {}
    classes = Counter()
    class_cells = Counter()
    class_probes = Counter()
    class_rows = Counter()
    class_nonzero = Counter()
    for f, t in tables.items():
        l, c, p, e = (t[k] for k in ("l", "c", "p", "e"))
        label = "1" if l == 1 else "2-4" if l <= 4 else "5-16" if l <= 16 else "17-64" if l <= 64 else "65+"
        b = bins.setdefault(label, dict(tables=0, candidates=0, cells=0, nonzero=0, queries=0, scanned_cells=0))
        b["tables"] += 1; b["candidates"] += c; b["cells"] += c * l; b["nonzero"] += p
        b["queries"] += sum(queries.get((f, s), 0) for s in range(c))
        b["scanned_cells"] += l * sum(queries.get((f, s), 0) for s in range(c))
        # U counts retained-candidate baseline spill/reload edits, not weighted
        # totals. P <= U <= E. The capture omits U; report bounds, not fake dispatch.
        dense = 8 * c * l
        lower = 16 * p + 8 * c + 20
        upper = 16 * e + 8 * c + 20
        category = "definitely_dense" if l <= 1 or lower >= dense else "guaranteed_sparse_if_ordered" if upper < dense else "unknown_U"
        t["dispatch_bound"] = category
        t["dense_bytes"] = dense
        t["sparse_storage_upper_bound_from_P"] = lower
        classes[category] += 1; class_cells[category] += c*l; class_nonzero[category] += p
        class_rows[category] += c
        class_probes[category] += l * sum(queries.get((f, s), 0) for s in range(c))
    k_hist = Counter(len(row) for row in rows.values())
    queried_k_hist = Counter(len(rows[key]) for key in queries)
    summary = dict(form=name, tables=len(tables), region_table_candidates=len(rows),
        **expected_totals, density=expected_totals["candidate_region_nonzero_cells"] / max(1, expected_totals["candidate_region_cells"]),
        dense_clear_bytes=8 * expected_totals["candidate_region_cells"],
        max_table_cells=max((t["c"] * t["l"] for t in tables.values()), default=0),
        max_regions=max((t["l"] for t in tables.values()), default=0),
        max_candidates=max((t["c"] for t in tables.values()), default=0),
        max_row_nonzero=max(k_hist, default=0), all_edit_streams_ordered=all(t["ordered"] for t in tables.values()),
        exhausted_queries=exhausted, stopped_without_exhaustion=len(queries)-exhausted,
        stop_note="A nonexhausting stop can be assignment OR a plan-capacity break; the trace does not distinguish them.",
        by_region_count=bins, rows_by_nonzero=dict(sorted(k_hist.items())),
        queried_rows_by_nonzero=dict(sorted(queried_k_hist.items())),
        storage_gate_bounds={k:dict(tables=classes[k],candidates=class_rows[k],cells=class_cells[k],nonzero=class_nonzero[k],scanned_cells=class_probes[k]) for k in sorted(classes)},
        metrics=metrics)
    replay = [dict(form=name, f=f, s=s, l=tables[f]["l"], pairs=pairs,
                   q=queries.get((f,s),0), trace=decisions.get((f,s),[]),
                   dispatch_bound=tables[f]["dispatch_bound"])
              for (f,s),pairs in sorted(rows.items())]
    return summary, replay, list(tables.values())


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    summaries, replay, table_rows = [], [], []
    for name in ("direct", "memory", "pressure"):
        summary, rows, tables = load_capture(args.capture, name)
        summaries.append(summary); replay.extend(rows)
        table_rows.extend(dict(form=name, **t) for t in tables)
    (args.output / "population-summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    with (args.output / "tables.csv").open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(table_rows[0]))
        writer.writeheader(); writer.writerows(table_rows)
    # L K Q D (id cost)*K (recorded_id recorded_cost)*D, one row per line.
    with (args.output / "replay.txt").open("w") as file:
        file.write(str(len(replay)) + "\n")
        for row in replay:
            values = [row["l"],len(row["pairs"]),row["q"],len(row["trace"])]
            values.extend(x for pair in row["pairs"] for x in pair)
            values.extend(x for pair in row["trace"] for x in pair)
            file.write(" ".join(map(str, values)) + "\n")
    hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(args.capture.iterdir()) if p.is_file()}
    (args.output / "capture-files.sha256.json").write_text(json.dumps(hashes,indent=2)+"\n")
    compact = [{k:s[k] for k in ("form","tables","region_table_candidates","candidate_region_cells","candidate_region_nonzero_cells","density","split_candidates","region_selection_passes","selected_regions","region_selection_cells","max_regions","max_row_nonzero","all_edit_streams_ordered","storage_gate_bounds")} for s in summaries]
    print(json.dumps(compact,indent=2))
    print("PASS: table, occupancy, region order, query/exhaustion and aggregate identities")

if __name__ == "__main__":
    main()
