# #125 QUALITY next-region selection experiment

**Disposition: executed standalone selector experiment; not an integrated or accepted Buster optimization. No repository branch, production change, PR, issue update, workflow dispatch, merge or closure was made.**

Read `REPORT.md` for the hypothesis, exact policy argument, complexity/storage costs, negative results, and unrun acceptance gates. `identities.json` distinguishes the inspected repository SHA from the independently hashed prototype sources; there is no tested Buster candidate commit.

## Contents

`region_order.c` and `region_order.h` contain the source-derived scalar control, a simpler compact-list control, a lazy region-ID heap, and the tiled-winner prototype. `probe.c` contains deterministic ordering tests, operation-budget checks, changing-eligibility and stale-ranking controls, and the narrowly scoped timing driver. These are external research files, not registered Buster tests or a replacement benchmark/acceptance system.

`raw/tile-screening/` is the final four-strategy experiment (1,488 samples). `raw/first-heap-screening/` retains the earlier three-strategy experiment (1,116 samples), its exact recovered sources, and a rebuilt timing binary whose SHA-256 equals the original measured binary. The two sets are not pooled. `raw/tile-prototype-initial/` retains an intermediate source/test snapshot; the root sources and `raw/tests*.log` are the final test version.

`raw/complexity.csv` contains diagnostic logical operations, not cycles or memory-bus traffic. Counter instrumentation is absent from `raw/probe-timing`. `raw/artifact-inspection.json` records why the downloaded existing CI artifacts did not supply a current QUALITY census. The large downloaded CI ZIPs are not included.

`SHA256SUMS` binds every bundled file except itself. Verify it before making a working copy:

```sh
sha256sum -c SHA256SUMS
```

## Reproduce the selector tests

Use a COPY of this directory so the retained raw evidence is not overwritten. The recorded build used Clang 17.0.0 on a shared Linux x86-64 execution container, not the user's desktop, a standard GitHub runner, or benchpress.

```sh
./build-probe.sh
raw/probe-counts --test > raw/complexity.csv 2> raw/tests.log
raw/probe-timing --test > raw/tests-uninstrumented.stdout 2> raw/tests-uninstrumented.log
ASAN_OPTIONS=halt_on_error=1:detect_leaks=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
raw/probe-sanitized --test > raw/complexity-sanitized.csv 2> raw/tests-sanitized.log
```

The final instrumented and ASan/UBSan tests each reported 12,057 generated populations, 3,973,748 assertions and zero failures. The uninstrumented tests reported 3,973,423 assertions: diagnostic operation assertions are intentionally omitted.

## Reproduce the limited screening

Again use a working COPY. The script fixes the shapes and interleaving before collecting, pins itself and its children to one allowed CPU, and writes commands, input parameters, hashes and raw samples. It fails on a subprocess error.

```sh
python3 run-tile-screening.py
```

The timer includes selection/index construction and consumption, but excludes population generation, workspace allocation/free, the rest of QUALITY and the compiler. There is no dedicated-host or full-compiler acceptance verdict. Do not infer a production dispatch threshold from these warm generated rows.

Full validation must use the repository's existing registered allocator regressions, separate allocation-instrumented compilers, native throughput harness and ordinary-task benchmark policy, with matched trusted Clang-built Buster compilers and frozen inputs. This bundle does not add or replace those mechanisms.
