#ifndef REGION_ORDER_H
#define REGION_ORDER_H

#include <stdbool.h>
#include <stdint.h>

/* Prototype only: these mirror Buster's u32 and MachineQualityTraffic types. */
typedef uint32_t u32;
typedef uint64_t MachineQualityTraffic;

typedef struct RegionProbeWork RegionProbeWork;
struct RegionProbeWork
{
    uint64_t dense_cells;
    uint64_t build_cells;
    uint64_t key_comparisons;
    uint64_t index_writes;
};

/* The scalar function body is transcribed from the pinned production helper. */
u32 machine_quality_region_next(MachineQualityTraffic const* traffic, u32 count, u32 previous_region);

/* At least count writable indices; only the returned prefix is initialized.
 * traffic is immutable until the index is discarded. previous_region is either
 * UINT32_MAX (start), or a positive-traffic index returned by the scalar walk.
 * The heap owns no storage and no traffic, and may not outlive either array. */
u32 region_heap_build(u32* indices, MachineQualityTraffic const* traffic, u32 count, u32 previous_region);
u32 region_heap_pop(u32* indices, u32* count, MachineQualityTraffic const* traffic);

/* Simpler control: the same compact positive-ID list, with linear max removal. */
u32 region_list_build(u32* indices, MachineQualityTraffic const* traffic, u32 count, u32 previous_region);
u32 region_list_pop(u32* indices, u32* count, MachineQualityTraffic const* traffic);

bool region_probe_has_counts(void);
RegionProbeWork region_probe_work(void);
void region_probe_work_reset(void);

/* One complete region-query sequence; no ranking-input mutations. The first
 * query always uses the original scalar function. The lazy alternatives only
 * construct an index when the caller asks for a second region.
 * Requests includes the possible exhaustion query; caller stops on exhaustion.
 * 0 = production scalar; 1 = lazy compact list; 2 = lazy compact heap.
 * This models region enumeration, NOT whole allocation or compiler execution. */
uint64_t region_probe_walk(MachineQualityTraffic const* traffic, u32 count,
                          u32 requests, u32* workspace, u32 strategy);
#endif
