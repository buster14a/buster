#!/usr/bin/env python3
"""Bounded selector-only falsification, NOT Buster performance acceptance.

Inputs and workspaces are prepared before the inner timer. No full allocator,
compiler, arena construction/teardown, cold-table behavior, or 9700X is measured.
"""
from __future__ import annotations
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'raw'
BIN = RAW / 'probe-timing'
shapes = [
    ('empty', 0, 0, 1),
    ('tiny-first', 1, 1, 1), ('tiny-exhaust', 1, 1, 2),
    ('tiny-dense', 4, 4, 5), ('tiny-sparse', 4, 1, 2),
    ('small-first', 16, 16, 1), ('small-two', 16, 16, 2),
    ('small-sparse', 16, 4, 5), ('small-dense', 16, 16, 17),
    ('medium-first', 64, 64, 1), ('medium-two', 64, 64, 2),
    ('medium-sparse', 64, 4, 5), ('medium-dense', 64, 64, 65),
    ('tile-first', 256, 256, 1), ('tile-two', 256, 256, 2),
    ('tile-sparse', 256, 4, 5), ('tile-mixed', 256, 16, 17),
    ('tile-dense', 256, 256, 257),
    ('large-first', 1024, 1024, 1), ('large-two', 1024, 1024, 2),
    ('large-sparse', 1024, 4, 5), ('large-mixed', 1024, 16, 17),
    ('large-dense', 1024, 1024, 1025),
    ('huge-empty', 4096, 0, 1), ('huge-singleton', 4096, 1, 2),
    ('huge-first', 4096, 4096, 1), ('huge-two', 4096, 4096, 2),
    ('huge-sparse', 4096, 4, 5), ('huge-mixed', 4096, 16, 17),
    ('huge-64', 4096, 64, 65), ('huge-dense', 4096, 4096, 4097),
]
# Fix the experiment plan before collecting any results; do not choose a
# production dispatch threshold from these artificial warm-row measurements.
orders = [(0,1,2), (2,1,0), (1,2,0), (0,2,1), (2,0,1), (1,0,2)]
allowed = sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else []
if allowed:
    os.sched_setaffinity(0, {allowed[0]})
metadata = {
    'scope': 'selector-only warm preconstructed rows; not allocator/compiler acceptance',
    'seed': '0x125a20260924', 'shapes': shapes, 'orders': orders, 'cycles': 2,
    'host': platform.uname()._asdict(), 'initial_affinity': allowed,
    'measurement_affinity': sorted(os.sched_getaffinity(0)) if allowed else [],
    'exclusive_host': False, 'workspace_allocation_timed': False,
    'traffic_construction_timed': False, 'index_construction_timed': True,
    'index_consumption_reset_timed': True,
    'binary_sha256': hashlib.sha256(BIN.read_bytes()).hexdigest(),
    'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in [ROOT/'region_order.c', ROOT/'region_order.h', ROOT/'probe.c']},
}
(RAW/'screening-plan.json').write_text(json.dumps(metadata, indent=2)+'\n')
rows = []
with (RAW/'screening.csv').open('w', newline='') as out, (RAW/'screening-commands.jsonl').open('w') as cmds:
    fields = ['shape','cycle','order','position','strategy','L','K','queries','repetitions','elapsed_ns','checksum','ns_per_walk']
    writer = csv.DictWriter(out, fieldnames=fields)
    writer.writeheader()
    for name, count, occupied, queries in shapes:
        repeats = max(1, min(250000, 1000000 // max(1, count * min(queries, occupied+1))))
        for cycle in range(2):
            for order_index, order in enumerate(orders):
                for position, strategy in enumerate(order):
                    argv = [str(BIN), '--bench', str(strategy), str(count), str(occupied), str(queries), str(repeats)]
                    completed = subprocess.run(argv, capture_output=True, text=True, check=True, timeout=10)
                    values = [int(x) for x in completed.stdout.strip().split(',')]
                    if values[:5] != [strategy, count, occupied, queries, repeats]:
                        raise RuntimeError(f'unexpected result identity: {completed.stdout}')
                    row = dict(zip(fields, [name,cycle,order_index,position,strategy,count,occupied,queries,repeats,values[5],values[6],values[5]/repeats]))
                    writer.writerow(row); rows.append(row)
                    cmds.write(json.dumps({'argv':argv,'returncode':completed.returncode,'stderr':completed.stderr})+'\n')
                    out.flush(); cmds.flush()
summary = []
for name, count, occupied, queries in shapes:
    record = {'shape':name,'L':count,'K':occupied,'queries':queries}
    for strategy, label in [(0,'scalar'),(1,'list'),(2,'heap')]:
        samples = [r['ns_per_walk'] for r in rows if r['shape']==name and r['strategy']==strategy]
        record[label+'_median_ns'] = statistics.median(samples)
        record[label+'_min_ns'] = min(samples)
        record[label+'_max_ns'] = max(samples)
    record['list_over_scalar'] = record['list_median_ns']/record['scalar_median_ns']
    record['heap_over_scalar'] = record['heap_median_ns']/record['scalar_median_ns']
    summary.append(record)
(RAW/'screening-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(f'{len(rows)} samples; {len(shapes)} populations; no production performance verdict')
for record in summary:
    print(f"{record['shape']:18s} L={record['L']:4d} K={record['K']:4d} q={record['queries']:4d} scalar={record['scalar_median_ns']:10.1f}ns list/scalar={record['list_over_scalar']:.3f} heap/scalar={record['heap_over_scalar']:.3f}")
