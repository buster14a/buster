#define _POSIX_C_SOURCE 200809L
#include "region_order.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_REGIONS 4096u
static uint64_t assertions;
static uint64_t failures;
static uint64_t populations;
static volatile uint64_t sink;
static MachineQualityTraffic values[MAX_REGIONS];
static MachineQualityTraffic saved[MAX_REGIONS];
static u32 expected[MAX_REGIONS];
static u32 heap_storage[MAX_REGIONS + 2];
static u32 list_storage[MAX_REGIONS + 2];

#define CHECK(condition) do { \
    assertions += 1; \
    if (!(condition)) { \
        if (failures < 12) { fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #condition); } \
        failures += 1; \
    } \
} while (0)

static uint64_t random_next(uint64_t* state)
{
    uint64_t value = *state;
    value ^= value << 13;
    value ^= value >> 7;
    value ^= value << 17;
    *state = value;
    return value;
}

/* Independent, deliberately simple oracle for the required total order. */
static u32 expected_order(u32 count)
{
    u32 used = 0;
    for (u32 id = 0; id < count; id += 1)
    {
        if (values[id])
        {
            u32 position = used;
            while (position && (values[id] > values[expected[position - 1]] ||
                   (values[id] == values[expected[position - 1]] && id < expected[position - 1])))
            {
                expected[position] = expected[position - 1];
                position -= 1;
            }
            expected[position] = id;
            used += 1;
        }
    }
    return used;
}

static void check_tail(u32 count, u32 total, u32 skip)
{
    u32 previous = skip ? expected[skip - 1] : UINT32_MAX;
    u32* heap = heap_storage + 1;
    u32* list = list_storage + 1;
    memset(heap_storage, 0xa5, sizeof(heap_storage));
    memset(list_storage, 0x5a, sizeof(list_storage));
    heap_storage[0] = list_storage[0] = UINT32_C(0xfeed0123);
    heap_storage[count + 1] = list_storage[count + 1] = UINT32_C(0xcafe4567);
    u32 heap_count = region_heap_build(heap, values, count, previous);
    u32 list_count = region_list_build(list, values, count, previous);
    CHECK(heap_count == total - skip);
    CHECK(list_count == total - skip);
    for (u32 position = skip; position <= total; position += 1)
    {
        u32 want = position < total ? expected[position] : UINT32_MAX;
        u32 actual = machine_quality_region_next(values, count, previous);
        CHECK(actual == want);
        CHECK(region_heap_pop(heap, &heap_count, values) == want);
        CHECK(region_list_pop(list, &list_count, values) == want);
        if (want != UINT32_MAX)
        {
            previous = want;
        }
    }
    CHECK(heap_count == 0 && list_count == 0);
    CHECK(region_heap_pop(heap, &heap_count, values) == UINT32_MAX);
    CHECK(region_list_pop(list, &list_count, values) == UINT32_MAX);
    CHECK(heap_storage[0] == UINT32_C(0xfeed0123));
    CHECK(list_storage[0] == UINT32_C(0xfeed0123));
    CHECK(heap_storage[count + 1] == UINT32_C(0xcafe4567));
    CHECK(list_storage[count + 1] == UINT32_C(0xcafe4567));
    CHECK(memcmp(values, saved, count * sizeof(values[0])) == 0);
}

static void check_population(u32 count, bool all_tails)
{
    memcpy(saved, values, count * sizeof(values[0]));
    u32 total = expected_order(count);
    check_tail(count, total, 0);
    if (all_tails)
    {
        for (u32 skip = 1; skip <= total; skip += 1)
        {
            check_tail(count, total, skip);
        }
    }
    else if (total)
    {
        check_tail(count, total, 1);
        check_tail(count, total, total / 2);
        check_tail(count, total, total);
    }
    u32 limits[] = {0, 1, 2, 4, total / 2, total, total + 1};
    for (u32 index = 0; index < sizeof(limits) / sizeof(limits[0]); index += 1)
    {
        uint64_t current = region_probe_walk(values, count, limits[index], heap_storage + 1, 0);
        CHECK(current == region_probe_walk(values, count, limits[index], heap_storage + 1, 1));
        CHECK(current == region_probe_walk(values, count, limits[index], heap_storage + 1, 2));
    }
    populations += 1;
}

static void changing_eligibility(void)
{
    MachineQualityTraffic traffic[] = {100, 100, 99, 98, 98, 1};
    /* Returned IDs must not be prefiltered. In particular, making ID 0 legal
     * after rejecting it must not revisit it. The real allocator is not called
     * here: this checks query/filter ordering, not emitted edits or placements. */
    for (u32 initial_mask = 0; initial_mask < 64; initial_mask += 1)
    {
        u32 previous = UINT32_MAX;
        u32 heap[6];
        u32 heap_count = 0;
        u32 mask = initial_mask;
        for (u32 step = 0; step <= 6; step += 1)
        {
            u32 scalar = machine_quality_region_next(traffic, 6, previous);
            u32 indexed = UINT32_MAX;
            if (step == 0)
            {
                indexed = machine_quality_region_next(traffic, 6, previous);
            }
            else
            {
                if (step == 1)
                {
                    heap_count = region_heap_build(heap, traffic, 6, previous);
                }
                indexed = region_heap_pop(heap, &heap_count, traffic);
            }
            CHECK(indexed == scalar);
            if (scalar == UINT32_MAX)
            {
                break;
            }
            bool scalar_accepted = step >= 2 && ((mask >> scalar) & 1u);
            bool indexed_accepted = step >= 2 && ((mask >> indexed) & 1u);
            CHECK(scalar_accepted == indexed_accepted);
            if (scalar_accepted)
            {
                break;
            }
            mask ^= 1u << ((step + 1) % 6);
            mask |= 1u; /* previously rejected top region becomes eligible */
            previous = scalar;
        }
    }
}

static void mutation_negative_control(void)
{
    MachineQualityTraffic traffic[] = {100, 90, 80};
    u32 heap[3];
    u32 previous = machine_quality_region_next(traffic, 3, UINT32_MAX);
    CHECK(previous == 0);
    u32 count = region_heap_build(heap, traffic, 3, previous);
    traffic[2] = 95;
    /* This intentional stale-index mismatch is required to be observed.
     * Supporting arbitrary ranking mutations is NOT a property of the heap. */
    CHECK(region_heap_pop(heap, &count, traffic) != machine_quality_region_next(traffic, 3, previous));
    count = region_heap_build(heap, traffic, 3, previous);
    CHECK(region_heap_pop(heap, &count, traffic) == machine_quality_region_next(traffic, 3, previous));
}

static u32 ceil_log2(u32 value)
{
    u32 answer = 0;
    uint64_t power = 1;
    while (power < value)
    {
        power *= 2;
        answer += 1;
    }
    return answer;
}

static void complexity_checks(void)
{
    puts("L,K,requests,strategy,dense_cells,build_cells,key_comparisons,index_writes");
    for (u32 count = 1; count <= MAX_REGIONS; count *= 2)
    {
        for (u32 i = 0; i < count; i += 1)
        {
            /* Reverse region priority, with frequent exact ties. */
            values[i] = UINT64_C(0x100000000) + i / 3;
        }
        uint64_t hash = 0;
        for (u32 strategy = 0; strategy < 3; strategy += 1)
        {
            region_probe_work_reset();
            uint64_t result = region_probe_walk(values, count, count + 1, heap_storage + 1, strategy);
            RegionProbeWork work = region_probe_work();
            if (strategy == 0)
            {
                hash = result;
                CHECK(work.dense_cells == (uint64_t)count * (count + 1));
            }
            else
            {
                CHECK(result == hash);
                CHECK(work.dense_cells == count);
                CHECK(work.build_cells == count);
                u32 remaining = count - 1;
                if (strategy == 1)
                {
                    CHECK(work.key_comparisons == (uint64_t)remaining * (remaining ? remaining - 1 : 0) / 2);
                }
                else
                {
                    uint64_t bound = (uint64_t)2 * remaining * (1 + ceil_log2(remaining + 1));
                    CHECK(work.key_comparisons <= bound);
                }
            }
            printf("%u,%u,%u,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 "\n",
                   count, count, count + 1, strategy, work.dense_cells, work.build_cells,
                   work.key_comparisons, work.index_writes);
        }
    }
}

static void run_tests(void)
{
    u32 empty_count = 0;
    CHECK(machine_quality_region_next(NULL, 0, UINT32_MAX) == UINT32_MAX);
    CHECK(region_heap_build(NULL, NULL, 0, UINT32_MAX) == 0);
    CHECK(region_heap_pop(NULL, &empty_count, NULL) == UINT32_MAX);
    CHECK(region_list_build(NULL, NULL, 0, UINT32_MAX) == 0);
    CHECK(region_list_pop(NULL, &empty_count, NULL) == UINT32_MAX);
    MachineQualityTraffic alphabet[] = {0, 1, UINT64_C(0x100000001)};
    uint64_t combinations = 1;
    for (u32 count = 0; count <= 8; count += 1)
    {
        for (uint64_t population = 0; population < combinations; population += 1)
        {
            uint64_t remaining = population;
            for (u32 i = 0; i < count; i += 1)
            {
                values[i] = alphabet[remaining % 3];
                remaining /= 3;
            }
            check_population(count, true);
        }
        combinations *= 3;
    }
    MachineQualityTraffic special[] = {0, 1, 2, UINT32_MAX, UINT64_C(0x100000000),
        UINT64_C(0x100000001), UINT64_C(0x10000000000), (uint64_t)UINT32_MAX * 4096,
        UINT64_MAX - 1, UINT64_MAX};
    uint64_t state = UINT64_C(0x125a20260924);
    for (u32 trial = 0; trial < 2048; trial += 1)
    {
        u32 count = (u32)(random_next(&state) % 258);
        for (u32 i = 0; i < count; i += 1)
        {
            values[i] = special[random_next(&state) % (sizeof(special) / sizeof(special[0]))];
        }
        check_population(count, false);
    }
    u32 boundaries[] = {0, 1, 2, 3, 4, 7, 8, 15, 16, 17, 31, 32, 33, 63, 64, 65,
                        127, 128, 129, 255, 256, 257, 511, 512, 1023, 1024, 2048, 4096};
    for (u32 b = 0; b < sizeof(boundaries) / sizeof(boundaries[0]); b += 1)
    {
        u32 count = boundaries[b];
        for (u32 pattern = 0; pattern < 6; pattern += 1)
        {
            for (u32 i = 0; i < count; i += 1)
            {
                switch (pattern)
                {
                    case 0: values[i] = 0; break;
                    case 1: values[i] = UINT64_C(0x100000001); break;
                    case 2: values[i] = (uint64_t)i + 1; break;
                    case 3: values[i] = (uint64_t)count - i; break;
                    case 4: values[i] = (i % 97 == 0) ? UINT64_C(0x100000001) + i : 0; break;
                    default: values[i] = (i + 1 == count) ? UINT64_MAX : 0; break;
                }
            }
            check_population(count, false);
        }
    }
    changing_eligibility();
    mutation_negative_control();
    if (region_probe_has_counts())
    {
        complexity_checks();
    }
    fprintf(stderr, "populations=%" PRIu64 " assertions=%" PRIu64 " failures=%" PRIu64 "\n",
            populations, assertions, failures);
}

static uint64_t clock_ns(void)
{
    struct timespec now = {0};
    int status = clock_gettime(CLOCK_MONOTONIC, &now);
    if (status != 0)
    {
        perror("clock_gettime");
        failures += 1;
    }
    return (uint64_t)now.tv_sec * UINT64_C(1000000000) + (uint64_t)now.tv_nsec;
}

static void benchmark(u32 strategy, u32 count, u32 occupied, u32 requests, u32 repetitions, uint64_t seed)
{
    /* Frozen, deterministic population. Input construction and capacity
     * allocation are OUTSIDE this timer. Each walk includes first selection,
     * all lazy index construction, queries and active-count consumption.
     * This is not a full allocator or compiler benchmark. */
    memset(values, 0, count * sizeof(values[0]));
    for (u32 i = 0; i < count; i += 1)
    {
        heap_storage[i] = i;
    }
    for (u32 i = 0; i < occupied; i += 1)
    {
        u32 selected = i + (u32)(random_next(&seed) % (count - i));
        u32 id = heap_storage[selected];
        heap_storage[selected] = heap_storage[i];
        heap_storage[i] = id;
        values[id] = UINT64_C(0x100000000) + random_next(&seed) % 17;
    }
    uint64_t wanted = region_probe_walk(values, count, requests, list_storage + 1, 0);
    CHECK(region_probe_walk(values, count, requests, list_storage + 1, strategy) == wanted);
    uint64_t hash = 0;
    for (u32 warmup = 0; warmup < 8; warmup += 1)
    {
        sink ^= region_probe_walk(values, count, requests, list_storage + 1, strategy);
    }
    uint64_t begin = clock_ns();
    for (u32 repetition = 0; repetition < repetitions; repetition += 1)
    {
        /* Separate translation units and no LTO: the caller cannot hoist the
         * external function call or assume it does not touch its workspace. */
        hash += region_probe_walk(values, count, requests, list_storage + 1, strategy);
    }
    uint64_t end = clock_ns();
    sink ^= hash;
    CHECK(hash == wanted * repetitions);
    printf("%u,%u,%u,%u,%u,%" PRIu64 ",%" PRIu64 "\n", strategy, count, occupied,
           requests, repetitions, end - begin, hash);
}

static bool parse_u32(char const* text, u32* output)
{
    char* end = NULL;
    unsigned long long value = strtoull(text, &end, 10);
    bool valid = text[0] >= '0' && text[0] <= '9' && end && end[0] == 0 && value <= UINT32_MAX;
    if (valid)
    {
        *output = (u32)value;
    }
    return valid;
}

int main(int argc, char** argv)
{
    bool usage_ok = true;
    if (argc == 2 && strcmp(argv[1], "--test") == 0)
    {
        run_tests();
    }
    else if (argc == 7 && strcmp(argv[1], "--bench") == 0)
    {
        u32 strategy = 0, count = 0, occupied = 0, requests = 0, repetitions = 0;
        usage_ok = parse_u32(argv[2], &strategy) && parse_u32(argv[3], &count) && parse_u32(argv[4], &occupied) &&
                   parse_u32(argv[5], &requests) && parse_u32(argv[6], &repetitions) &&
                   strategy < 3 && count <= MAX_REGIONS && occupied <= count && repetitions > 0;
        if (usage_ok)
        {
            benchmark(strategy, count, occupied, requests, repetitions, UINT64_C(0x125a20260924));
        }
    }
    else
    {
        usage_ok = false;
    }
    if (!usage_ok)
    {
        fprintf(stderr, "usage: probe --test | --bench strategy L K queries repetitions\n");
    }
    return !usage_ok || failures != 0;
}
