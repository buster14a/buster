#include "region_order.h"

#ifndef REGION_PROBE_COUNTS
#define REGION_PROBE_COUNTS 0
#endif
#if REGION_PROBE_COUNTS
static RegionProbeWork work;
#define COUNT(field, amount) (work.field += (uint64_t)(amount))
#else
#define COUNT(field, amount) ((void)0)
#endif

/* Original scalar policy; the sole added statement is the compile-time-only
 * diagnostic increment. The original body is separately retained as evidence. */
u32 machine_quality_region_next(MachineQualityTraffic const* traffic, u32 count, u32 previous_region)
{
    COUNT(dense_cells, count);
    MachineQualityTraffic previous_traffic = previous_region == UINT32_MAX ? 0 : traffic[previous_region];
    MachineQualityTraffic best_traffic = 0;
    u32 best_region = UINT32_MAX;
    for (u32 region_index = 0; region_index < count; region_index += 1)
    {
        MachineQualityTraffic region_traffic = traffic[region_index];
        if (!region_traffic ||
            (previous_region != UINT32_MAX &&
             (region_traffic > previous_traffic || (region_traffic == previous_traffic && region_index <= previous_region))))
        {
            continue;
        }
        if (region_traffic > best_traffic)
        {
            best_traffic = region_traffic;
            best_region = region_index;
        }
    }
    return best_region;
}

static bool region_precedes(MachineQualityTraffic const* traffic, u32 left, u32 right)
{
    COUNT(key_comparisons, 1);
    return traffic[left] > traffic[right] || (traffic[left] == traffic[right] && left < right);
}

u32 region_list_build(u32* indices, MachineQualityTraffic const* traffic, u32 count, u32 previous_region)
{
    MachineQualityTraffic previous_traffic = previous_region == UINT32_MAX ? 0 : traffic[previous_region];
    u32 used = 0;
    COUNT(build_cells, count);
    for (u32 region = 0; region < count; region += 1)
    {
        MachineQualityTraffic value = traffic[region];
        if (value && (previous_region == UINT32_MAX || value < previous_traffic ||
                      (value == previous_traffic && region > previous_region)))
        {
            indices[used] = region;
            used += 1;
            COUNT(index_writes, 1);
        }
    }
    return used;
}

/* root < count/2 ensures 2*root+1 and its possible sibling cannot overflow
 * u32, even for count==UINT32_MAX. Nothing in an unused/dirty suffix is read. */
static void region_heap_sift(u32* indices, u32 count, u32 root, MachineQualityTraffic const* traffic)
{
    bool done = false;
    while (!done && root < count / 2)
    {
        u32 child = root * 2 + 1;
        u32 right = child + 1;
        if (right < count && region_precedes(traffic, indices[right], indices[child]))
        {
            child = right;
        }
        if (region_precedes(traffic, indices[child], indices[root]))
        {
            u32 exchanged = indices[root];
            indices[root] = indices[child];
            indices[child] = exchanged;
            COUNT(index_writes, 2);
            root = child;
        }
        else
        {
            done = true;
        }
    }
}

u32 region_heap_build(u32* indices, MachineQualityTraffic const* traffic, u32 count, u32 previous_region)
{
    u32 used = region_list_build(indices, traffic, count, previous_region);
    for (u32 parent = used / 2; parent != 0; parent -= 1)
    {
        region_heap_sift(indices, used, parent - 1, traffic);
    }
    return used;
}

u32 region_heap_pop(u32* indices, u32* count, MachineQualityTraffic const* traffic)
{
    u32 result = UINT32_MAX;
    if (*count)
    {
        result = indices[0];
        *count -= 1;
        if (*count)
        {
            indices[0] = indices[*count];
            COUNT(index_writes, 1);
            region_heap_sift(indices, *count, 0, traffic);
        }
    }
    return result;
}

u32 region_list_pop(u32* indices, u32* count, MachineQualityTraffic const* traffic)
{
    u32 result = UINT32_MAX;
    if (*count)
    {
        u32 best = 0;
        for (u32 index = 1; index < *count; index += 1)
        {
            if (region_precedes(traffic, indices[index], indices[best]))
            {
                best = index;
            }
        }
        result = indices[best];
        *count -= 1;
        if (best != *count)
        {
            indices[best] = indices[*count];
            COUNT(index_writes, 1);
        }
    }
    return result;
}

#define REGION_TILE_SIZE 16u

static u32 region_tile_next(MachineQualityTraffic const* traffic, u32 count,
                            u32 start, u32 previous)
{
    MachineQualityTraffic previous_traffic = previous == UINT32_MAX ? 0 : traffic[previous];
    MachineQualityTraffic best_traffic = 0;
    u32 best = UINT32_MAX;
    u32 length = count - start;
    if (length > REGION_TILE_SIZE)
    {
        length = REGION_TILE_SIZE;
    }
    COUNT(build_cells, length);
    for (u32 offset = 0; offset < length; offset += 1)
    {
        u32 region = start + offset;
        MachineQualityTraffic value = traffic[region];
        if (value && (previous == UINT32_MAX || value < previous_traffic ||
                      (value == previous_traffic && region > previous)))
        {
            if (value > best_traffic)
            {
                best_traffic = value;
                best = region;
            }
        }
    }
    return best;
}

static void region_tiles_sift(uint64_t* indices, u32 count, u32 root, MachineQualityTraffic const* traffic)
{
    bool done = false;
    while (!done && root < count / 2)
    {
        u32 child = root * 2 + 1;
        u32 right = child + 1;
        if (right < count && region_precedes(traffic, (u32)indices[right], (u32)indices[child]))
        {
            child = right;
        }
        if (region_precedes(traffic, (u32)indices[child], (u32)indices[root]))
        {
            uint64_t exchanged = indices[root];
            indices[root] = indices[child];
            indices[child] = exchanged;
            COUNT(index_writes, 2);
            root = child;
        }
        else
        {
            done = true;
        }
    }
}

u32 region_tiles_first(uint64_t* workspace, MachineQualityTraffic const* traffic,
                       u32 count, RegionTileOrder* state)
{
    *state = (RegionTileOrder){.previous = UINT32_MAX};
    if (count <= REGION_TILE_SIZE)
    {
        state->previous = machine_quality_region_next(traffic, count, UINT32_MAX);
    }
    else
    {
        /* Division/remainder avoids count+T-1 overflow at UINT32_MAX. */
        u32 tiles = count / REGION_TILE_SIZE + (count % REGION_TILE_SIZE != 0);
        for (u32 tile = 0; tile < tiles; tile += 1)
        {
            u32 winner = region_tile_next(traffic, count, tile * REGION_TILE_SIZE, UINT32_MAX);
            if (winner != UINT32_MAX)
            {
                workspace[state->active] = winner;
                state->active += 1;
                COUNT(index_writes, 1);
                if (state->previous == UINT32_MAX || region_precedes(traffic, winner, state->previous))
                {
                    state->previous = winner;
                }
            }
        }
    }
    return state->previous;
}

u32 region_tiles_next(uint64_t* workspace, MachineQualityTraffic const* traffic,
                      u32 count, RegionTileOrder* state)
{
    if (state->previous != UINT32_MAX)
    {
        if (count <= REGION_TILE_SIZE)
        {
            state->previous = machine_quality_region_next(traffic, count, state->previous);
        }
        else
        {
            if (!state->heap_ready)
            {
                for (u32 parent = state->active / 2; parent != 0; parent -= 1)
                {
                    region_tiles_sift(workspace, state->active, parent - 1, traffic);
                }
                state->heap_ready = true;
            }
            /* The root is the previously returned global winner. All other
             * tile winners still follow it in the fixed total order. Only
             * its tile can have a newly exposed maximum. Never prefilter on
             * changing pin eligibility, and never modify traffic. */
            u32 winner = (u32)workspace[0];
            u32 next = region_tile_next(traffic, count,
                                       (winner / REGION_TILE_SIZE) * REGION_TILE_SIZE, winner);
            if (next != UINT32_MAX)
            {
                workspace[0] = next;
                COUNT(index_writes, 1);
            }
            else
            {
                state->active -= 1;
                if (state->active)
                {
                    workspace[0] = workspace[state->active];
                    COUNT(index_writes, 1);
                }
            }
            if (state->active)
            {
                region_tiles_sift(workspace, state->active, 0, traffic);
                state->previous = (u32)workspace[0];
            }
            else
            {
                state->previous = UINT32_MAX;
            }
        }
    }
    return state->previous;
}

bool region_probe_has_counts(void)
{
    return REGION_PROBE_COUNTS != 0;
}

RegionProbeWork region_probe_work(void)
{
    RegionProbeWork result = {0};
#if REGION_PROBE_COUNTS
    result = work;
#endif
    return result;
}

void region_probe_work_reset(void)
{
#if REGION_PROBE_COUNTS
    work = (RegionProbeWork){0};
#endif
}

uint64_t region_probe_walk(MachineQualityTraffic const* traffic, u32 count,
                          u32 requests, u32* workspace, uint64_t* tile_workspace, u32 strategy)
{
    u32 previous = UINT32_MAX;
    u32 active = 0;
    RegionTileOrder tiles = {0};
    uint64_t hash = UINT64_C(1469598103934665603);
    for (u32 query = 0; query < requests; query += 1)
    {
        u32 region = UINT32_MAX;
        if (strategy == 3)
        {
            if (query == 0)
            {
                region = region_tiles_first(tile_workspace, traffic, count, &tiles);
            }
            else
            {
                region = region_tiles_next(tile_workspace, traffic, count, &tiles);
            }
        }
        else if (strategy == 0 || query == 0)
        {
            region = machine_quality_region_next(traffic, count, previous);
        }
        else
        {
            if (query == 1)
            {
                if (strategy == 1)
                {
                    active = region_list_build(workspace, traffic, count, previous);
                }
                else
                {
                    active = region_heap_build(workspace, traffic, count, previous);
                }
            }
            if (strategy == 1)
            {
                region = region_list_pop(workspace, &active, traffic);
            }
            else
            {
                region = region_heap_pop(workspace, &active, traffic);
            }
        }
        hash = (hash ^ region) * UINT64_C(1099511628211);
        if (region == UINT32_MAX)
        {
            break;
        }
        previous = region;
    }
    return hash;
}
