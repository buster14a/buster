#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${CC:=clang}"
mkdir -p raw
common='-std=c11 -Wall -Wextra -Wpedantic -Werror -fno-lto'
# Separate observer and timing binaries, built serially in this same directory.
$CC $common -O2 -DREGION_PROBE_COUNTS=1 -c region_order.c -o raw/order.o
$CC $common -O2 -c probe.c -o raw/driver.o
$CC raw/order.o raw/driver.o -o raw/probe-counts
$CC $common -O3 -DNDEBUG -DREGION_PROBE_COUNTS=0 -c region_order.c -o raw/order.o
$CC $common -O3 -DNDEBUG -c probe.c -o raw/driver.o
$CC raw/order.o raw/driver.o -o raw/probe-timing
$CC $common -O1 -g -DREGION_PROBE_COUNTS=1 -fsanitize=address,undefined -fno-omit-frame-pointer \
    region_order.c probe.c -o raw/probe-sanitized
$CC --version > raw/clang-version.txt
uname -a > raw/kernel.txt
sha256sum region_order.c region_order.h probe.c build-probe.sh raw/probe-* > raw/build-sha256.txt
