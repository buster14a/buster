#include <stdio.h>
#include <buster/tests/test.h>
#include <buster/lib/compiler/ir/ir.c>
static ProgramState cfg_registered_state;
ProgramState* program_state = &cfg_registered_state;
#undef BUSTER_TEST
#undef BUSTER_REQUIRE
#define BUSTER_TEST(args, expr) do { bool ok_ = (expr); result.test_count += 1; result.succeeded_test_count += ok_; if (!ok_) fprintf(stderr,"FAILED line=%u expr=%s\n",(unsigned)__LINE__,#expr); (void)(args); } while(0)
#define BUSTER_REQUIRE(args, expr) ((expr) ? (result.test_count += 1, result.succeeded_test_count += 1, true) : (result.test_count += 1, fprintf(stderr,"REQUIRE line=%u expr=%s\n",(unsigned)__LINE__,#expr), false))
#include "/home/david/Documents/Codex/2026-10-15/iden-3/work/variants/ir_cfg_test.c"
int main(void)
{
    ThreadContext* context = thread_context_allocate();
    thread_context_select(context);
    Arena* arena = arena_create((ArenaCreation){.reserved_size = 1ull << 30});
    UnitTestArguments args = {.arena = arena};
    UnitTestResult result = ir_cfg_publication_tests(&args);
    printf("cfg_registered tests=%llu passed=%llu\n",(unsigned long long)result.test_count,(unsigned long long)result.succeeded_test_count);
    arena_destroy(arena,1);
    thread_context_release(context);
    return result.test_count == result.succeeded_test_count ? 0 : 1;
}
