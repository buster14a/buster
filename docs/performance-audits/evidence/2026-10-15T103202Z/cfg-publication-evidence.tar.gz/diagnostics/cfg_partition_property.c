#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <buster/lib/compiler/ir/ir.h>
#include <buster/lib/compiler/ir/ir_construction.h>

static ProgramState probe_program_state;
ProgramState* program_state = &probe_program_state;

// These are the two unchanged private result constructors from ir.c.
static IrValidationResult ir_validation_ok(void)
{
    return (IrValidationResult){.error = IR_VALIDATION_NONE, .function = IR_FUNCTION_ID_INVALID,
        .block = IR_BLOCK_ID_INVALID, .instruction = IR_INSTRUCTION_ID_INVALID};
}
static IrValidationResult ir_validation_error(IrValidationError error, IrFunction* function,
                                             IrBlockId block, IrInstructionId instruction)
{
    return (IrValidationResult){.error = error, .function = function->id, .block = block, .instruction = instruction};
}
#include <buster/lib/compiler/ir/ir_cfg.c>

int main(void)
{
    IrValueId operands[36] = {0};
    IrBlockId targets[36] = {0};
    u64 immediates[36] = {0};
    u32 seed = 123456789u;
    u32 certified = 0;
    u32 disjoint_cases = 0;
    bool sound = true;
    for (u32 trial = 0; trial < 200000 && sound; trial += 1)
    {
        IrInstruction rows[8] = {0};
        u32 starts[8];
        u32 lengths[8];
        u32 kind = trial % 3;
        bool disjoint = true;
        for (u32 index = 0; index < 8; index += 1)
        {
            seed = seed * 1664525u + 1013904223u;
            starts[index] = trial % 4 ? (seed >> 16) % 32 : ((index * 5 + trial) % 8) * 4;
            seed = seed * 1664525u + 1013904223u;
            lengths[index] = (seed >> 16) % 4;
            if (kind == 0) { rows[index].operands = operands + starts[index]; rows[index].operand_count = lengths[index]; }
            else if (kind == 1) { rows[index].targets = targets + starts[index]; rows[index].target_count = (u16)lengths[index]; }
            else { rows[index].immediates = immediates + starts[index]; rows[index].immediate_count = (u16)lengths[index]; }
            for (u32 earlier = 0; earlier < index; earlier += 1)
            {
                if (lengths[index] && lengths[earlier])
                    disjoint &= starts[index] >= starts[earlier] + lengths[earlier] || starts[earlier] >= starts[index] + lengths[index];
            }
        }
        IrFunction function = {.instructions = rows, .instruction_count = 8};
        bool proof = ir_cfg_slices_disjoint(&function, (IrCfgSliceKind)kind);
        certified += proof;
        disjoint_cases += disjoint;
        sound &= !proof || disjoint;
    }
    printf("partition cases=200000 certified=%u pairwise_disjoint=%u sound=%u\n", certified, disjoint_cases, sound);
    return sound ? 0 : 1;
}
