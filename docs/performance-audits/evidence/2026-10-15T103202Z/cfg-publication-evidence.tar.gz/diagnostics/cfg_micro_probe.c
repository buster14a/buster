#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <buster/lib/compiler/ir/ir.h>
#include <buster/lib/compiler/ir/ir_construction.h>

static ProgramState probe_program_state;
ProgramState* program_state = &probe_program_state;

// These are the two unchanged private result constructors from ir.c.
static IrValidationResult ir_validation_ok(void)
{
    return (IrValidationResult){.error = IR_VALIDATION_NONE, .function = IR_FUNCTION_ID_INVALID,
        .block = IR_BLOCK_ID_INVALID, .instruction = IR_INSTRUCTION_ID_INVALID};
}
static IrValidationResult ir_validation_error(IrValidationError error, IrFunction* function,
                                             IrBlockId block, IrInstructionId instruction)
{
    return (IrValidationResult){.error = error, .function = function->id, .block = block, .instruction = instruction};
}
#include <buster/lib/compiler/ir/ir_cfg.c>

int main(int argc, char** argv)
{
    u32 n = argc > 2 ? (u32)strtoul(argv[2], 0, 10) : 4096;
    char const* mode = argc > 1 ? argv[1] : "identity";
    bool extras_reverse = strcmp(mode, "extras-reverse") == 0;
    bool extras = strcmp(mode, "extras") == 0 || extras_reverse;
    bool reverse = strcmp(mode, "descending") == 0;
    bool reopen = strcmp(mode, "reopen") == 0;
    bool moved = extras || reopen;
    u32 count = extras ? n + 2 : n;
    u32 block_count = extras ? 3 : reopen ? 2 : 1;
    Arena* arena = arena_create((ArenaCreation){.reserved_size = 1ull << 30});
    Arena* scratch = arena_create((ArenaCreation){.reserved_size = 1ull << 30});
    IrFunction f = {.instruction_count = count, .block_count = block_count, .state = IR_FUNCTION_LOWERED};
    f.instructions = arena_allocate_zeroed(arena, IrInstruction, count);
    f.blocks = arena_allocate_zeroed(arena, IrBlock, block_count);
    IrCfgBlock* blocks = arena_allocate_zeroed(arena, IrCfgBlock, block_count);
    IrValueId* operands = arena_allocate(arena, IrValueId, count);
    for (u32 i = 0; i < count; i += 1)
    {
        operands[i].value = i;
        f.instructions[i] = (IrInstruction){.next = {.value = i + 1 < count ? i + 1 : IR_ID_UNDERLYING_INVALID},
            .opcode = IR_OPCODE_LOCAL, .result = IR_VALUE_ID_INVALID,
            .operands = operands + (reverse ? count - i - 1 : i), .operand_count = 1};
    }
    for (u32 b = 0; b < block_count; b += 1)
    {
        u32 first = extras ? (b == 0 ? 0 : b == 1 ? n + 1 : n) : reopen ? (b == 0 ? count / 2 : 0) : 0;
        if (extras_reverse) first = b == 0 ? n / 2 : b == 1 ? 0 : n;
        u32 last = extras ? (b == 0 ? n - 1 : first) : reopen ? (b == 0 ? count - 1 : count / 2 - 1) : count - 1;
        if (extras_reverse) last = b == 0 ? n - 1 : b == 1 ? n / 2 - 1 : n + 1;
        f.blocks[b] = (IrBlock){.id = {.value = b}, .first_instruction = {.value = first},
            .last_instruction = {.value = last}, .terminated = true, .sealed = true};
        f.instructions[last].opcode = IR_OPCODE_RETURN;
        f.instructions[last].next = IR_INSTRUCTION_ID_INVALID;
    }
    if (extras)
    {
        f.extra_count = n;
        f.extras = arena_allocate_zeroed(arena, IrInstructionExtra, n);
        f.extra_instructions = arena_allocate(arena, IrInstructionId, n);
        for (u32 e = 0; e < n; e += 1)
        {
            f.extra_instructions[e].value = e;
            f.extras[e].reserved = e;
        }
    }
    IrPublishedCfg cfg = {.arena = arena, .blocks = blocks, .block_count = block_count};
    u64 scratch_start = scratch->position;
    IrValidationResult result = ir_cfg_publish_instruction_rows(arena, scratch, &f, &cfg, blocks);
    u64 first_bytes = cfg.allocated_bytes;
    bool intact = result.error == IR_VALIDATION_NONE && cfg.instruction_count == count;
    for (u32 i = 0; i < count; i += 1) intact &= f.instructions[i].next.value == IR_ID_UNDERLYING_INVALID;
    if (extras)
    {
        for (u32 e = 0; e < n; e += 1) intact &= f.extra_instructions[e].value == e && f.extras[e].reserved == (extras_reverse ? (e + n / 2) % n : e);
    }
    if (reopen)
    {
        f.published_cfg = &cfg;
        ir_function_reopen_cfg(&f);
        cfg.allocated_bytes = 0;
        result = ir_cfg_publish_instruction_rows(arena, scratch, &f, &cfg, blocks);
        intact &= result.error == IR_VALIDATION_NONE;
    }
    for (u32 i = 0; i < count; i += 1)
    {
        u32 expected = extras_reverse ? (i < n ? (i + n / 2) % n : i) : reverse ? count - i - 1 : extras ? (i == n ? n + 1 : i == n + 1 ? n : i) : reopen ? (i + count / 2) % count : i;
        intact &= f.instructions[i].operands[0].value == expected;
    }
    printf("{\"mode\":\"%s\",\"n\":%u,\"rows\":%u,\"extra_count\":%u,\"moved\":%u,\"scratch_bytes\":%llu,\"first_copy_bytes\":%llu,\"final_copy_bytes\":%llu,\"extra_order_size\":%zu,\"row_size\":%zu,\"ok\":%u}\n",
        mode,n,count,f.extra_count,moved,(unsigned long long)(scratch->position-scratch_start),
        (unsigned long long)first_bytes,(unsigned long long)cfg.allocated_bytes,sizeof(IrCfgExtraOrder),sizeof(IrInstruction),intact);
    arena_destroy(scratch,1);
    arena_destroy(arena,1);
    return intact ? 0 : 1;
}
