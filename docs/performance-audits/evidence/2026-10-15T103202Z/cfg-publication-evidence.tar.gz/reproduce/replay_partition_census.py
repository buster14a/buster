from pathlib import Path
import collections,re,json
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work')
results=[]
for name in ('sqlite-g0','sqlite-g','unity-g0','unity-g'):
 pools={};slices=collections.defaultdict(list)
 for line in (base/'evidence/census'/f'{name}.log').read_text().splitlines():
  if line.startswith(('CFG_SLICE ','CFG_POOL ')):
   f={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)};key=(f['f'],f['kind'])
   if line.startswith('CFG_POOL '):pools[key]=f
   else:slices[key].append((f['start'],f['end']))
 stats=collections.defaultdict(lambda:collections.Counter())
 for key,rows in slices.items():
  previous=(0,0);first=0;split=0
  for a,b in rows:
   if not first:first=a
   if a<previous[1]:split=first if b<=first else previous[0];break
   previous=(a,b)
  last=[None,None];direction=[None,None];certified=True
  for a,b in rows:
   partition=int(a>=split)
   if not partition and b>split:certified=False;break
   if last[partition] is not None:
    x,y=last[partition]
    if a>=y: d='ascending'
    elif b<=x:d='descending'
    else:certified=False;break
    if direction[partition] is not None and direction[partition]!=d:certified=False;break
    direction[partition]=d
   last[partition]=(a,b)
  if certified:
   # Independent pairwise interval oracle for the accepted proof.
   ordered=sorted(rows)
   assert all(b<=c for (a,b),(c,d) in zip(ordered,ordered[1:])),(name,key)
  stat=stats[key[1]];amount=pools[key]['total']*(8 if key[1]==2 else 4)
  stat['original_pools']+=1;stat['original_copy_bytes']+=amount
  stat['certified_pools']+=certified;stat['avoided_copy_bytes']+=amount if certified else 0
  stat['fallback_pools']+=not certified;stat['fallback_copy_bytes']+=amount if not certified else 0
 result={'case':name,'evidence_class':'replay of baseline native census address intervals; predicted candidate copy reduction, not a candidate allocation measurement','kinds':dict(stats)}
 results.append(result);print(json.dumps(result),flush=True)
(base/'evidence/partition-replay-summary.json').write_text(json.dumps(results,indent=2)+'\n')
