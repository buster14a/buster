from pathlib import Path
import collections,re,json
base=Path('work/evidence')
for name in ['sqlite-g0','sqlite-g','unity-g0','unity-g']:
 pools={};slices=collections.defaultdict(list)
 for l in (base/'census'/f'{name}.log').read_text().splitlines():
  if l.startswith(('CFG_SLICE ','CFG_POOL ')):
   f={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',l)};k=f['f'],f['kind']
   if l.startswith('CFG_POOL '):pools[k]=f
   else:slices[k].append((f['start'],f['end']))
 counts=collections.Counter();sizes=collections.Counter()
 for key,v in slices.items():
  split=next((v[i-1][0] for i in range(1,len(v)) if v[i][0]<v[i-1][1]),0)
  ends=[0,0];ok=True
  for a,b in v:
   k=a>=split
   ok &= a>=ends[k] and (k or b<=split)
   ends[k]=b
  label='two-ascending' if ok else 'fallback'
  counts[(key[1],label)]+=1;sizes[(key[1],label)]+=pools[key]['total']*(8 if key[1]==2 else 4)
 print(name,dict(counts),dict(sizes),flush=True)
