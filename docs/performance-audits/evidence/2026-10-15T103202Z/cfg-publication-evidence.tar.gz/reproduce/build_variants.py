from pathlib import Path
import subprocess,json,hashlib,time
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
results=[]
for variant in ('extras','maps','pools','combined'):
 source=base/'variants'/f'{variant}.c'
 (repo/'src/buster/lib/compiler/ir/ir_cfg.c').write_bytes(source.read_bytes())
 (base/'evidence'/f'{variant}.patch').write_text(subprocess.check_output(['git','diff','--','src/buster/lib/compiler/ir/ir_cfg.c'],cwd=repo,text=True))
 with (base/f'{variant}-build.log').open('w') as log:
  start=time.monotonic();r=subprocess.run(['./build.sh','build','--config','Release','-t','ide'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:
  print('build failed',variant,r.returncode,flush=True);raise SystemExit(r.returncode)
 binary=base/'frozen-compiler'/f'{variant}-ide'
 binary.write_bytes((repo/'build/Release/ide').read_bytes());binary.chmod(0o755)
 row={'variant':variant,'source_base':'84f051c13044938bcb8cbe1ac48ea3ee79defcff','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'seconds':time.monotonic()-start}
 results.append(row);(base/'evidence/variants-build.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(row),flush=True)
