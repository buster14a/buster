from pathlib import Path
base=Path('work');v=base/'variants';s=(base/'evidence/baseline-ir_cfg.c').read_text()
helper='''typedef struct IrCfgSliceRange IrCfgSliceRange;
struct IrCfgSliceRange
{
    u64 begin;
    u64 end;
};

BUSTER_GLOBAL_LOCAL IrCfgSliceRange ir_cfg_slice_range(IrInstruction const* row, u32 kind)
{
    u32 count = kind == 0 ? row->operand_count : kind == 1 ? row->target_count : row->immediate_count;
    u64 begin = kind == 0 ? (u64)(uintptr_t)row->operands : kind == 1 ? (u64)(uintptr_t)row->targets : (u64)(uintptr_t)row->immediates;
    return (IrCfgSliceRange){.begin = count ? begin : 0, .end = count ? begin + (u64)count * (kind == 2 ? sizeof(u64) : sizeof(IrValueId)) : 0};
}

// A failed ascent may interleave construction allocations with later fold
// allocations. Split at the first descent and prove each address partition
// monotone without overlap. No interval may cross the split. More fragmented
// layouts conservatively keep the copy; no proof survives direct row edits.
BUSTER_GLOBAL_LOCAL bool ir_cfg_slices_disjoint(IrFunction const* function, u32 kind)
{
    IrCfgSliceRange previous = {0};
    u64 split = 0;
    u64 first = 0;
    for (u32 index = 0; index < function->instruction_count && !split; index += 1)
    {
        IrCfgSliceRange range = ir_cfg_slice_range(function->instructions + index, kind);
        if (range.end)
        {
            if (!first) first = range.begin;
            if (range.begin < previous.end) split = range.end <= first ? first : previous.begin;
            previous = range;
        }
    }
    IrCfgSliceRange last[2] = {{0}};
    u32 seen = 0;
    u32 ascending = 0;
    u32 descending = 0;
    bool disjoint = true;
    for (u32 index = 0; index < function->instruction_count && disjoint; index += 1)
    {
        IrCfgSliceRange range = ir_cfg_slice_range(function->instructions + index, kind);
        if (range.end)
        {
            u32 partition = range.begin >= split;
            u32 bit = 1u << partition;
            disjoint = partition || range.end <= split;
            if (seen & bit)
            {
                if (range.begin >= last[partition].end)
                {
                    disjoint &= !(descending & bit);
                    ascending |= bit;
                }
                else if (range.end <= last[partition].begin)
                {
                    disjoint &= !(ascending & bit);
                    descending |= bit;
                }
                else
                {
                    disjoint = false;
                }
            }
            last[partition] = range;
            seen |= bit;
        }
    }
    return disjoint;
}

'''
def pools(text):
 anchor='BUSTER_GLOBAL_LOCAL IrValidationResult ir_cfg_separate_operand_slices(Arena* arena, IrFunction* function, IrPublishedCfg* cfg)'
 text=text.replace(anchor,helper+anchor)
 anchor='    if (result.error == IR_VALIDATION_NONE && (!operands_disjoint || !targets_disjoint || !immediates_disjoint))'
 text=text.replace(anchor,'''    if (result.error == IR_VALIDATION_NONE)
    {
        if (!operands_disjoint) operands_disjoint = ir_cfg_slices_disjoint(function, 0);
        if (!targets_disjoint) targets_disjoint = ir_cfg_slices_disjoint(function, 1);
        if (!immediates_disjoint) immediates_disjoint = ir_cfg_slices_disjoint(function, 2);
    }
'''+anchor)
 return text
(v/'pools-fast.c').write_text(pools(s));(v/'combined-fast.c').write_text(pools((v/'extras-maps.c').read_text()))
for variant in ('pools-fast','combined-fast'):
 p=v/variant/'src/buster/lib/compiler/ir';p.mkdir(parents=True,exist_ok=True);(p/'ir_cfg.c').write_bytes((v/f'{variant}.c').read_bytes())
s=(base/'probe/verify_variants.py').read_text().replace("('extras','maps','pools','combined')", "('pools-fast','combined-fast')").replace('variant-probes.json','variant-fast-probes.json')
(base/'probe/verify_fast_variants.py').write_text(s)
print('Prepared two-partition proof without allocation or sorting.')
