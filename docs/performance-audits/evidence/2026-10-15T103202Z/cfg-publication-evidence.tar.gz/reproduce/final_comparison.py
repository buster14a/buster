from pathlib import Path
import subprocess,json,time,hashlib
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
while not (base/'evidence/refined-binary.sha256').exists():time.sleep(2)
summary=[]
for inp in ('sqlite','unity'):
 for debug in ('g0','g'):
  name=f'refined-{inp}-{debug}'
  baseline=json.loads((base/'evidence/baseline-artifacts'/f'{inp}-{debug}.json').read_text())
  argv=baseline['argv'][1:];argv[-1]=str(base/'evidence'/f'{name}.o')
  subprocess.run([str(base/'frozen-compiler/refined-ide')]+argv,cwd=repo,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  digest=hashlib.sha256((base/'evidence'/f'{name}.o').read_bytes()).hexdigest()
  assert digest==baseline['sha256'],name
  argv[-1]=str(base/'evidence/refined-perf-output.o')
  cmd=['taskset','-c','14',str(base/'frozen-compiler/performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--events','instructions:u','--baseline',str(base/'frozen-compiler/baseline-ide'),'--candidate',str(base/'frozen-compiler/refined-ide'),'--out',str(base/'evidence'/name),'--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--candidate-revision','62d2d61160198681ce471b5f3ec14039eb00a6b0','--']+argv
  with (base/'evidence'/f'{name}.log').open('w') as f:r=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
  d=json.loads((base/'evidence'/name/'summary.json').read_text());m=d['metrics'][0]
  row={'case':name,'artifact_sha256':digest,'artifact_identical':True,'metrics':d['metrics']}
  summary.append(row);(base/'evidence/refined-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  print(name,m['verdict'],round(m['relative_change']*100,5),flush=True)
