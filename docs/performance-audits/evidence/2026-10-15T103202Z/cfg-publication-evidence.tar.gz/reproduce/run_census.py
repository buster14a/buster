from pathlib import Path
import subprocess,json,re,collections,hashlib
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
(repo/'src/buster/lib/compiler/ir/ir_cfg.c').write_bytes((base/'evidence/baseline-ir_cfg.c').read_bytes())
summary=[]
for inp in ('sqlite','unity'):
 for debug in ('g0','g'):
  name=f'{inp}-{debug}';folder=base/'evidence/census';folder.mkdir(exist_ok=True)
  original=json.loads((base/'evidence/baseline-artifacts'/f'{name}.json').read_text())
  args=original['argv'];args[0]=str(base/'frozen-compiler/census-ide');args[-1]=str(folder/f'{name}.o')
  args+=['-fsource-metrics='+str(folder/f'{name}.metrics')]
  with (folder/f'{name}.log').open('w') as f:
   r=subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode: print(name,'failed',r.returncode,flush=True);raise SystemExit(r.returncode)
  assert hashlib.sha256((folder/f'{name}.o').read_bytes()).hexdigest()==original['sha256'],name
  rows=[];pools=[];slices=collections.defaultdict(list)
  for line in (folder/f'{name}.log').read_text().splitlines():
   if line.startswith(('CFG_CENSUS ','CFG_POOL ','CFG_SLICE ')):
    fields={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
    if line.startswith('CFG_CENSUS '): rows.append(fields)
    elif line.startswith('CFG_POOL '): pools.append(fields)
    else:slices[(fields['f'],fields['kind'])].append((fields['start'],fields['end']))
  failed=[]
  for pool in pools:
   if not pool['ascending']:
    intervals=slices[(pool['f'],pool['kind'])]
    ordered=sorted(intervals);prev=0;overlap=False
    for a,b in ordered:
     overlap |= a<prev;prev=max(prev,b)
    # Largest number of exact nonadjacent islands in the original visitation order.
    islands=[];peak=0
    if not overlap:
     for a,b in intervals:
      changed=True
      while changed:
       changed=False
       for i,(x,y) in enumerate(islands):
        if a==y or b==x:
         a=min(a,x);b=max(b,y);islands.pop(i);changed=True;break
      islands.append((a,b));peak=max(peak,len(islands))
    failed.append({**pool,'overlap':overlap,'peak_islands':peak,'slices':len(intervals),'copy_bytes':pool['total']*(8 if pool['kind']==2 else 4)})
  result={'case':name,'functions':len(rows),'rows':sum(r['rows'] for r in rows),'identity_functions':sum(not r['moved'] for r in rows),'identity_rows':sum(r['rows'] for r in rows if not r['moved']),'moved_functions':sum(r['moved'] for r in rows),'moved_with_extras':sum(bool(r['extras']) and bool(r['moved']) for r in rows),'extras_in_moved':sum(r['extras'] for r in rows if r['moved']),'ordered_extras_functions':sum(bool(r['moved']) and bool(r['extras']) and bool(r['ordered']) for r in rows),'ordered_extras_rows':sum(r['extras'] for r in rows if r['moved'] and r['ordered']),'unchanged_extras_functions':sum(bool(r['moved']) and bool(r['extras']) and not r['changed_extras'] for r in rows),'pool_failures':failed,'artifact_identical':True}
  (folder/f'{name}.rows.json').write_text(json.dumps(rows,indent=2)+'\n')
  summary.append(result);print(json.dumps(result),flush=True)
(base/'evidence/census-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
