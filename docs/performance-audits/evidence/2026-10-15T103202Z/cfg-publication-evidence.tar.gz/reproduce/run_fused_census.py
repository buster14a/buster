from pathlib import Path
import subprocess,json,hashlib,re
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster';folder=base/'evidence/fused-census';folder.mkdir(exist_ok=True)
summary=[]
for inp in ('sqlite','unity'):
 for debug in ('g0','g'):
  name=f'{inp}-{debug}';baseline=json.loads((base/'evidence/baseline-artifacts'/f'{name}.json').read_text())
  argv=baseline['argv'];argv[0]=str(base/'frozen-compiler/fused-census-ide');argv[-1]=str(folder/f'{name}.o')
  with (folder/f'{name}.log').open('w') as f:r=subprocess.run(argv,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
  assert hashlib.sha256((folder/f'{name}.o').read_bytes()).hexdigest()==baseline['sha256'],name
  totals={'operands':0,'targets':0,'immediates':0};row_count=0;functions=0;ordered_extras=0;unsorted_extras=0
  for line in (folder/f'{name}.log').read_text().splitlines():
   if line.startswith('CFG_COPY '):
    fields={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
    for k in totals:totals[k]+=fields[k]
   elif line.startswith('CFG_CENSUS '):
    fields={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)};functions+=1;row_count+=fields['rows']
    if fields['moved']:
     if fields['ordered']:ordered_extras+=fields['extras']
     else:unsorted_extras+=fields['extras']
  row={'case':name,'functions':functions,'rows':row_count,'copy_bytes':totals,'ordered_extras':ordered_extras,'unsorted_extras':unsorted_extras,'artifact_identical':True}
  summary.append(row);print(json.dumps(row),flush=True)
(base/'evidence/fused-census-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
