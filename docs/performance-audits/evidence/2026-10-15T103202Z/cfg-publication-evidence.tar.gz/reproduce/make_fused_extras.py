from pathlib import Path
base=Path('work');s=(base/'variants/combined-fast.c').read_text();original=(base/'evidence/baseline-ir_cfg.c').read_text()
a=original.index('    u32 count = function->extra_count;',original.index('void ir_cfg_remap_extras'));b=original.index('\n}\n',a)
old=original[a:b]
a=s.index('    u32 count = function->extra_count;',s.index('void ir_cfg_remap_extras'));b=s.index('\n}\n',a)
body='''    u32 count = function->extra_count;
    if (ordered)
    {
        for (u32 index = 0; index < count; index += 1)
        {
            IrInstructionId* instruction = function->extra_instructions + index;
            *instruction = remap[instruction->value];
        }
    }
    else
    {
'''+''.join('    '+l+'\n' for l in old.splitlines()[1:])+'''    }'''
s=s[:a]+body+s[b:]
s=s.replace('IrInstructionId const* remap)\n{\n    u32 count = function->extra_count;', 'IrInstructionId const* remap, bool ordered)\n{\n    u32 count = function->extra_count;')
needle='    for (u32 index = 0; index < function->extra_count && result.error == IR_VALIDATION_NONE; index += 1)'
s=s.replace(needle,'    bool extras_ordered = true;\n    u32 previous_extra = 0;\n'+needle)
needle='''            result = ir_validation_error(IR_VALIDATION_INVALID_ID, function, IR_BLOCK_ID_INVALID, function->extra_instructions[index]);
        }
    }
'''
replacement='''            result = ir_validation_error(IR_VALIDATION_INVALID_ID, function, IR_BLOCK_ID_INVALID, function->extra_instructions[index]);
        }
        else if (moved)
        {
            u32 mapped = remap[function->extra_instructions[index].value].value;
            extras_ordered &= index == 0 || mapped > previous_extra;
            previous_extra = mapped;
        }
    }
'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('ir_cfg_remap_extras(scratch, function, remap);','ir_cfg_remap_extras(scratch, function, remap, extras_ordered);')
(base/'variants/combined-fused.c').write_text(s)
overlay=base/'variants/micro-fused/src/buster/lib/compiler/ir';overlay.mkdir(parents=True,exist_ok=True);(overlay/'ir_cfg.c').write_text(s)
print('Prepared fused extras-order check in existing ID validation.')
