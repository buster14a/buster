from pathlib import Path
import subprocess,json
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
s=(base/'variants/combined-fused.c').read_text()
needle='    if (result.error == IR_VALIDATION_NONE && (!operands_disjoint || !targets_disjoint || !immediates_disjoint))'
insert='''    if (result.error == IR_VALIDATION_NONE)
    {
        fprintf(stderr, "CFG_COPY f=%u operands=%llu targets=%llu immediates=%llu\\n", function->id.value,
            (unsigned long long)(operands_disjoint ? 0 : operand_count * sizeof(IrValueId)),
            (unsigned long long)(targets_disjoint ? 0 : target_count * sizeof(IrBlockId)),
            (unsigned long long)(immediates_disjoint ? 0 : immediate_count * sizeof(u64)));
    }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
needle='''    if (result.error == IR_VALIDATION_NONE)
    {
        result = ir_cfg_separate_operand_slices(arena, function, cfg);
    }
'''
insert='''    if (result.error == IR_VALIDATION_NONE)
    {
        fprintf(stderr, "CFG_CENSUS f=%u rows=%u moved=%u extras=%u ordered=%u\\n", function->id.value, count, (u32)moved, function->extra_count, (u32)extras_ordered);
    }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
overlay=base/'variants/fused-census/src/buster/lib/compiler/ir';overlay.mkdir(parents=True,exist_ok=True);(overlay/'ir_cfg.c').write_text(s)
argv=json.loads((base/'evidence/census-compile-argv.json').read_text());argv=[a.replace('-O3','-O1') for a in argv];argv[1:1]=['-I'+str(base/'variants/fused-census/src')];argv[-1]=str(base/'frozen-compiler/fused-census-ide')
(base/'evidence/fused-census-compile-argv.json').write_text(json.dumps(argv,indent=2)+'\n')
with (base/'fused-census-build.log').open('w') as f:r=subprocess.run(argv,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
print('fused diagnostic build',r.returncode,flush=True)
raise SystemExit(r.returncode)
