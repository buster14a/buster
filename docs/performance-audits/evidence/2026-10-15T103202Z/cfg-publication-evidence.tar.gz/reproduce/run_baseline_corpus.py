from pathlib import Path
import subprocess,json,hashlib,time
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
for input_name in ('sqlite','unity'):
 for debug in ('g0','g'):
  name=f'{input_name}-{debug}'
  out=base/'evidence/baseline-artifacts'/f'{name}.o'
  argv=[str(base/'frozen-compiler/baseline-ide'),'cc','-w','-c','-'+debug]
  if input_name=='unity': argv+=['-I'+str(base/'frozen-input/src'),'-I'+str(base/'frozen-input/build/generated'),'-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0',str(base/'frozen-input/src/buster/apps/ide/ide.c')]
  else: argv+=['-DSQLITE_THREADSAFE=0',str(base/'inputs/sqlite-amalgamation-3530400/sqlite3.c')]
  argv+=['-o',str(out)]
  with (base/'evidence/baseline-artifacts'/f'{name}.log').open('w') as f:
   begin=time.monotonic();r=subprocess.run(argv,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  print(name,r.returncode,round(time.monotonic()-begin,3),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
  (base/'evidence/baseline-artifacts'/f'{name}.json').write_text(json.dumps({'argv':argv,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size},indent=2)+'\n')
