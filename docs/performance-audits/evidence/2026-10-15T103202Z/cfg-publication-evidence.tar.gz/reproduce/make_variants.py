from pathlib import Path
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work')
s=(base/'evidence/baseline-ir_cfg.c').read_text()
v=base/'variants';v.mkdir(exist_ok=True)
start=s.index('    u32 count = function->extra_count;',s.index('void ir_cfg_remap_extras'))
end=s.index('\n}\n',start)
original=s[start:end]
ordered='''    u32 count = function->extra_count;
    bool ordered = true;
    u32 previous = 0;
    for (u32 index = 0; index < count; index += 1)
    {
        IrInstructionId* instruction = function->extra_instructions + index;
        *instruction = remap[instruction->value];
        ordered &= index == 0 || instruction->value > previous;
        previous = instruction->value;
    }
    // A row permutation need not disturb sparse extras' relative order.
    // Map their keys first; only disordered keys require moving payloads.
    if (!ordered)
    {
'''+''.join('    '+l+'\n' for l in original.splitlines()[1:])+'''    }'''
ordered=ordered.replace('.instruction = remap[function->extra_instructions[index].value]', '.instruction = function->extra_instructions[index]')
extras=s[:start]+ordered+s[end:]
(v/'extras.c').write_text(extras)

def maps(text):
 text=text.replace('    u32* inverse = arena_allocate(scratch, u32, count);\n','')
 text=text.replace('                inverse[cursor++] = id.value;','                cursor += 1;')
 b=text.index('        if (moved)\n',text.index('IrValidationResult ir_cfg_publish_instruction_rows'))
 e=text.index('        for (u32 index = 0; index < function->block_count;',b)
 references=text[b:e]
 b=text.index('        // One pass both permutes',text.index('IrValidationResult ir_cfg_publish_instruction_rows'))
 e=text.index('        for (u32 index = 0; index < function->block_count;',b)
 permutation='''        // Definitions and extras consume the old-to-new map before its
        // entries become the visited marks of the in-place permutation.
'''+references+'''        // Each cycle carries its original row forward to the mapped slot.
        // A completed entry is identity. Cycles start at their lowest row,
        // so the outer loop can also discard each final construction link.
        for (u32 index = 0; index < count; index += 1)
        {
            if (remap[index].value != index)
            {
                IrInstruction saved = function->instructions[index];
                IrSourceRange source = function->instruction_canonical_sources ? function->instruction_canonical_sources[index] : (IrSourceRange){0};
                u32 from = index;
                u32 destination = remap[from].value;
                while (destination != index)
                {
                    IrInstruction next = function->instructions[destination];
                    function->instructions[destination] = saved;
                    saved = next;
                    if (function->instruction_canonical_sources)
                    {
                        IrSourceRange next_source = function->instruction_canonical_sources[destination];
                        function->instruction_canonical_sources[destination] = source;
                        source = next_source;
                    }
                    remap[from].value = from;
                    from = destination;
                    destination = remap[from].value;
                }
                function->instructions[index] = saved;
                if (function->instruction_canonical_sources)
                {
                    function->instruction_canonical_sources[index] = source;
                }
                remap[from].value = from;
            }
            function->instructions[index].next = IR_INSTRUCTION_ID_INVALID;
        }
'''
 text=text[:b]+permutation+text[e:]
 return text
(v/'maps.c').write_text(maps(s));(v/'extras-maps.c').write_text(maps(extras))

helper='''typedef struct IrCfgSliceRange IrCfgSliceRange;
struct IrCfgSliceRange
{
    u64 begin;
    u64 end;
};

BUSTER_GLOBAL_LOCAL void ir_cfg_slice_sift(IrCfgSliceRange* ranges, u32 count, u32 root)
{
    IrCfgSliceRange saved = ranges[root];
    bool moving = true;
    while (root < count / 2 && moving)
    {
        u32 child = root * 2 + 1;
        if (child + 1 < count && ranges[child].begin < ranges[child + 1].begin)
        {
            child += 1;
        }
        moving = saved.begin < ranges[child].begin;
        if (moving)
        {
            ranges[root] = ranges[child];
            root = child;
        }
    }
    ranges[root] = saved;
}

// The cheap ascent test is sufficient, not necessary. On failure, sort only
// address ranges in temporary storage; a permutation of disjoint slices is
// still disjoint. No proof survives a caller's later direct row edits.
BUSTER_GLOBAL_LOCAL bool ir_cfg_slices_disjoint(Arena* scratch, IrFunction* function, u32 kind, u32 count)
{
    TemporalArena temporary = arena_begin_temporal(scratch);
    IrCfgSliceRange* ranges = arena_allocate(scratch, IrCfgSliceRange, count);
    u32 cursor = 0;
    for (u32 index = 0; index < function->instruction_count; index += 1)
    {
        IrInstruction const* row = function->instructions + index;
        u32 length = kind == 0 ? row->operand_count : kind == 1 ? row->target_count : row->immediate_count;
        if (length)
        {
            u64 begin = kind == 0 ? (u64)(uintptr_t)row->operands : kind == 1 ? (u64)(uintptr_t)row->targets : (u64)(uintptr_t)row->immediates;
            ranges[cursor++] = (IrCfgSliceRange){.begin = begin, .end = begin + (u64)length * (kind == 2 ? sizeof(u64) : sizeof(IrValueId))};
        }
    }
    BUSTER_CHECK(cursor == count);
    for (u32 root = count / 2; root; root -= 1)
    {
        ir_cfg_slice_sift(ranges, count, root - 1);
    }
    for (u32 end = count; end > 1; end -= 1)
    {
        IrCfgSliceRange swap = ranges[0];
        ranges[0] = ranges[end - 1];
        ranges[end - 1] = swap;
        ir_cfg_slice_sift(ranges, end - 1, 0);
    }
    bool disjoint = true;
    for (u32 index = 1; index < count && disjoint; index += 1)
    {
        disjoint = ranges[index].begin >= ranges[index - 1].end;
    }
    scratch_end(temporary);
    return disjoint;
}

'''
def pools(text):
 anchor='BUSTER_GLOBAL_LOCAL IrValidationResult ir_cfg_separate_operand_slices(Arena* arena, IrFunction* function, IrPublishedCfg* cfg)'
 assert anchor in text
 text=text.replace(anchor,helper+anchor.replace('Arena* arena,','Arena* arena, Arena* scratch,'))
 anchor='    bool operands_disjoint = true;'
 text=text.replace(anchor,'    u32 operand_slices = 0;\n    u32 target_slices = 0;\n    u32 immediate_slices = 0;\n'+anchor)
 for field in ('operand','target','immediate'):
  anchor=f'                {field}_count += row->{field}_count;'
  assert anchor in text
  text=text.replace(anchor,anchor+f'\n                {field}_slices += 1;')
 anchor='    if (result.error == IR_VALIDATION_NONE && (!operands_disjoint || !targets_disjoint || !immediates_disjoint))'
 text=text.replace(anchor,'''    if (result.error == IR_VALIDATION_NONE)
    {
        if (!operands_disjoint) operands_disjoint = ir_cfg_slices_disjoint(scratch, function, 0, operand_slices);
        if (!targets_disjoint) targets_disjoint = ir_cfg_slices_disjoint(scratch, function, 1, target_slices);
        if (!immediates_disjoint) immediates_disjoint = ir_cfg_slices_disjoint(scratch, function, 2, immediate_slices);
    }
'''+anchor)
 text=text.replace('ir_cfg_separate_operand_slices(arena, function, cfg)','ir_cfg_separate_operand_slices(arena, scratch, function, cfg)')
 return text
(v/'pools.c').write_text(pools(s));(v/'combined.c').write_text(pools(maps(extras)))
print('Prepared independent extras/maps/pools and combined variants.')
