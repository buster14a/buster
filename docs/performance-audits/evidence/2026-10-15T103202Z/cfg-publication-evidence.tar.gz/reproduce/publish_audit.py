from pathlib import Path
import json,subprocess,hashlib,tarfile,shutil,platform,datetime
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
impl='62d2d61160198681ce471b5f3ec14039eb00a6b0';baseline='84f051c13044938bcb8cbe1ac48ea3ee79defcff'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==impl
# Capture immutable identities before minting the audit.
manifest={'baseline_revision':baseline,'implementation_revision':impl,'cpu':'AMD Ryzen 9 7940HS','evidence_class':'work-count; native instructions:u plus logical allocations','compiler':'Clang 23.1.1','native_configuration':'Release, O3, march=native, tests disabled; same owned build path','diagnostic_configuration':'baseline O3/candidate O1, BUSTER_OPTIMIZE=1, BUSTER_BENCH_ALLOCATIONS=1; output identity required; no timing','kernel':platform.platform(),'frozen_source_revision':baseline,'files':{}}
for p in [base/'frozen-compiler/baseline-ide',base/'frozen-compiler/refined-ide',base/'frozen-compiler/performance-evidence',repo/'src/buster/lib/compiler/ir/ir_cfg.c',base/'inputs/sqlite-amalgamation-3530400.zip',base/'inputs/sqlite-amalgamation-3530400/sqlite3.c']:
 manifest['files'][str(p)]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
manifest['bootstrap_tcc_version']=subprocess.run(['tcc','-v'],text=True,capture_output=True).stderr.strip()
manifest['native_flags_unchanged']=True
(base/'evidence/final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['baseline-generate.log','baseline-selfhost.log','candidate-selfhost.log','candidate-mode-matrix.log','release-tests.log','sanitize-tests.log','refined-build.log','refined-selfhost.log','refined-mode-matrix.log','refined-release-tests.log','refined-sanitize-tests.log','refined-source-size.log','markdown-links.log','fused-focused-run.log','partition-property-run.log']:
 p=base/name
 if p.exists():
  lines=p.read_text(errors='replace').splitlines()
  summary='\n'.join(lines[-80:])+'\n'
  dest=base/'evidence/validation'/name;dest.parent.mkdir(exist_ok=True);dest.write_text(summary)
  manifest.setdefault('full_validation_logs',{})[name]={'local_path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'published_tail_lines':80}
(base/'evidence/final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Only now mint the audit; subsequent status belongs on the PR, not edits here.
r=subprocess.run(['python3','tools/new_audit.py','--platform','Linux x86_64, Ryzen 9 7940HS, Clang native ISA','CFG publication: ordered extras, one map and bounded slice proofs (#4252/#4253/#4254)'],cwd=repo,text=True,capture_output=True,check=True)
print(r.stdout.strip(),flush=True)
paths=[p for p in (repo/'docs/performance-audits').glob('*.md') if p.name[:10]==datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d')]
audit=max(paths,key=lambda p:p.stat().st_mtime_ns);audit_id=audit.stem
out=repo/'docs/performance-audits/evidence'/audit_id;out.mkdir(parents=True)
archive=out/'cfg-publication-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted((base/'evidence').rglob('*')):
  if p.is_file() and p.suffix not in ('.o','.data') and p.name not in ('perf-output.o','perf-output-fast.o','refined-perf-output.o'):
   tar.add(p,arcname='observations/'+str(p.relative_to(base/'evidence')),recursive=False)
 for p in sorted((base/'variants').glob('*.c')):tar.add(p,arcname='variants/'+p.name,recursive=False)
 for p in [base/'variants/fused-census/src/buster/lib/compiler/ir/ir_cfg.c',base/'probe/cfg_micro_probe.c',base/'probe/cfg_partition_property.c',base/'probe/cfg_registered_runner.c',base/'probe/failed-callgrind.stderr']:
  if p.exists():tar.add(p,arcname='diagnostics/'+('fused-census-ir_cfg.c' if 'fused-census' in str(p) else p.name),recursive=False)
 for p in sorted(base.glob('*.py')):tar.add(p,arcname='reproduce/'+p.name,recursive=False)
checksum=hashlib.sha256(archive.read_bytes()).hexdigest()
full=json.loads((base/'evidence/refined-summary.json').read_text())
micro=json.loads((base/'evidence/refined-micro-summary.json').read_text())
old=json.loads((base/'evidence/census-compact.json').read_text())
new=json.loads((base/'evidence/fused-census-summary.json').read_text())
full_rows='\n'.join(f"| {r['case'].removeprefix('refined-')} | {r['metrics'][0]['relative_change']*100:+.6f}% | {r['metrics'][0]['verdict']} |" for r in full)
copy_rows='\n'.join(f"| {a['case']} | {a['copy_bytes']:,} | {sum(b['copy_bytes'].values()):,} | {(1-sum(b['copy_bytes'].values())/a['copy_bytes'])*100:.2f}% |" for a,b in zip(old,new))
micro_rows='\n'.join(f"| {r['case'].removeprefix('micro-refined-')} | {r['metrics'][0]['relative_change']*100:+.3f}% | {r['metrics'][0]['verdict']} |" for r in micro)
body=f'''
**Work and allocation reduction is established for the affected publication
populations. The four complete frozen source-to-object compiler controls are
within the predeclared 0.1% work effect. No whole-compiler elapsed-time, RSS or
Zen 5 speedup is claimed.** Issues [#4252](https://github.com/buster14a/buster/issues/4252),
[#4253](https://github.com/buster14a/buster/issues/4253),
[#4254](https://github.com/buster14a/buster/issues/4254); implementation
[PR #4268](https://github.com/buster14a/buster/pull/4268).

## Identities and evidence route

Baseline `{baseline}`; implementation `{impl}`. Later documentation/evidence
commits do not change compiler or test source. The matched trusted Clang 23.1.1
Release compilers were built serially in the same owned worktree with `-O3`,
`-march=native`, tests disabled, frame pointers and debug data enabled. Required
C flags remain enabled. The TCC-built native build driver remains the canonical
local bootstrap; the measured compiler images are Clang-built.

Baseline binary SHA-256
`{manifest['files'][str(base/'frozen-compiler/baseline-ide')]['sha256']}`;
candidate
`{manifest['files'][str(base/'frozen-compiler/refined-ide')]['sha256']}`.
Caches, compilation commands, source/fixture/binary hashes, raw observations and
host identity are in the evidence archive. Large compiler images, objects and
3.5 GiB of trace snapshots remain in the owned local workspace and are bound by
hashes and invocation records; they are not embedded in this archive.

The claim is `work-reduction`, using the existing #4013 `performance-evidence`
route with `perf-stat instructions:u`. Six alternating pairs, one warmup per
arm, CPU 14 affinity and the predeclared 0.1% complete-compiler effect screen
were used. All final observations are complete, user-scoped and not multiplexed.
The fresh same-image A/A control changes -0.000186%, inconclusive and far below
the screen. Counter observations do not measure elapsed time or DRAM traffic.
This is a shared Ryzen 9 7940HS desktop, not the approved 9700X host.

## What changed and what stays required

1. Sparse extras' remapped-order check joins the existing ID-bounds loop.
   Ordered keys are remapped without payload sorting or sort scratch. Disordered
   keys keep the original pack/merge/unpack path. The first candidate wrote all
   mapped keys before sorting; its dense disordered fixture cost about 0.6%
   extra instructions. Fusing the check removed that adverse effect. All those
   earlier observations remain retained.
2. Value definitions and extra keys consume the old-to-new map before the row
   permutation. A cycle then carries its row and canonical source forward and
   consumes map entries to identity. No inverse array is allocated for either
   identity or moved functions. Scratch requests fall from 8N to 4N bytes for
   instruction maps; this is allocation traffic, not an RSS claim.
3. A nonascending slice kind gets a bounded, allocation-free proof using two
   address partitions. Each partition must be monotone and nonoverlapping; no
   slice may cross the split. Descending slices and two reversed spans can stay
   in place. Overlap or more fragmented layouts retain the copy fallback. Every
   publication re-proves current slices; direct edits after reopening cannot
   inherit a stale certificate.

The general precise address-sort prototype was rejected: complete-compiler
instruction counts rose 0.26-0.38%, exceeding the work screen. A more expensive
proof is therefore not used to eliminate every conservative copy. The remaining
copies in the table below are deliberate fallback work, not a claim that all
nonaliasing layouts are recognized.

Ownership, invalid-ID, null-slice/count, overflow, exact-tail and termination
checks remain. Dense block-ID spans, sources, values, labels and relocation
ownership remain unchanged. The deferred validator/publication walk fusion in
#1406/#1424 and its measurement hold are untouched.

## Current-source populations and executed copies

Inputs are frozen base-revision compiler unity source and the official SQLite
3.53.4 amalgamation, each `-g0`/`-g`, default driver optimization/allocator,
source-to-object. SQLite also uses `-DSQLITE_THREADSAFE=0`. The archive's exact
argv records are authoritative. SQLite `sqlite3.c` is 9,515,341 bytes, SHA-256
`b1dd5d74ec7f29055a6684fa06fb3c2f6821c87dd38f9a458dfd2e8a1db28189`;
the official archive SHA-256 is
`1e71ddf93849c6a6ecf58b827c0692073d2dd7ee40196158068f7b29f422e87d`.

The baseline census has 312,297 / 359,319 SQLite rows and 1,558,382 / 1,773,705
unity rows. Identity-order rows account for 23,430 / 13,099 and 38,449 / 28,602,
respectively. Moved extras stay ordered for 55/74 and 56/75 SQLite extras, and
218/244 unity extras in both debug modes. Thus the large dense-extra example
is a mechanism stress, not a typical compiler population.

The baseline diagnostic used Clang `-O3`; the candidate diagnostic used `-O1`
with the same `BUSTER_OPTIMIZE=1`, `BUSTER_BENCH_ALLOCATIONS=1` contract. These
are separately identified counter builds, never timing arms. Every diagnostic
object matches the ordinary compiler's object byte-for-byte. Independent sorted
interval checks establish that the baseline's listed copies were disjoint.
The following candidate copy counts were actually executed, not inferred from
address replay:

| Input | Baseline copied bytes | Candidate copied bytes | Removed |
|---|---:|---:|---:|
{copy_rows}

Counts exclude reused storage, original builder allocations, arena padding and
temporary scratch; they do not establish peak-memory or RSS reductions. The
native two-partition results are supported by a separate 200,000-case seeded
ASan/UBSan property diagnostic: 17,941 certificates among 86,444 disjoint cases,
with no false certificate. Conservative refusals are retained.

## Complete compiler work controls

| Frozen compile | User-instruction change | Verdict |
|---|---:|---|
{full_rows}

All four token, canonical IR, selected MIR and object trace streams match
byte-for-byte between arms. Normal untraced objects also match. Bootstrap
tracing deliberately enables validation; it is a separate correctness check,
not a timing arm. Default allocator/mode coverage is complemented by the full
native mode matrix below.

## Direct helper evidence and adverse control

The same C fixture is compiled against the baseline and candidate publisher.
It builds and checks rows, sources/definitions/extras where relevant and
allocation requests. It invokes the actual private helper but does not certify
a complete semantically valid IR module. The measured unit is the entire
fixture process, including identical setup and checks, not a sampled leaf.
Fixture builds use matched Clang `-O2`, tests off and one thread. Their identities
are separate from the native complete compiler images.

| Fixture and rows/extras | User-instruction change | Verdict |
|---|---:|---|
{micro_rows}

At 65,536 ordered extras the earlier 8 MiB sorting scratch and 1,048,576
64-byte merge assignments disappear. Ordered 65,536-row functions use 256 KiB
rather than 512 KiB of map scratch. Descending disjoint slices and the reversed
span/reopen probe copy zero operand bytes rather than 256 KiB. The dense
reverse-extras control remains within effect after the fused check.

## Correctness and remaining integration gates at evidence freeze

- Baseline self-host fixed point: 42,078,720 bytes.
- Final implementation self-host fixed point: 42,082,008 bytes; byte-identical
  stages, machine stage and generated benchmarks pass.
- Final Release `test_all`: 7,165,501 assertions, 64 modules pass.
- Final Release ASan/UBSan/LSan `test_all`: 7,117,688 assertions, 64 modules pass.
  Leak detection and the worker-thread leak canary are enabled. The earlier
  implementation's full Debug sanitizer suite also passed the same assertion
  count; its source anchor is retained separately.
- Final mode matrix: all 12 legs pass, four behavioral executions, eight
  structural checks and two independent image-corruption oracle controls.
  These structural cross-target checks are not native Windows/macOS execution.
- The registered publication regressions enumerate 120 five-row permutations
  against all 32 sparse-extra subsets, plus reopen/republish, and an independent
  slice overlap/payload matrix across the three kinds. The focused publication
  suite passes 477,098 assertions under ASan/UBSan.
- Source-size ratchet: production +3,809 bytes, build unchanged, within limit.
  Markdown links and whitespace checks pass before this new authored audit.

PR-head checks on the implementation were green at the pre-audit readback.
Documentation/evidence publication and the final exact-head/platform checks,
protected group validation, actual merge/main containment and issue closure
remain separate. Their later outcomes belong on PR #4268 and the issues, not
an edit to this immutable audit. No 9700X request, generated native-retirement
identity refresh or queue bypass is part of this work.

## Evidence and licensing

[Raw evidence and reproduction](evidence/{audit_id}/README.md), archive SHA-256
`{checksum}`. Earlier rejected/neutral/adverse observations are retained.
The identification-phase Callgrind loader SIGILL is retained as a failed
pre-main attempt and is excluded from accepted counts; native PMU execution is
the selected evidence route.

Buster first-party terms remain unselected (`NOASSERTION`), verified in
[LICENSES/README.md](../../LICENSES/README.md). SQLite 3.53.4 is public domain,
verified in the official amalgamation's `sqlite3.c` line 35 and `sqlite3.h`
line 4; no SPDX license was inferred. Clang/LLVM uses Apache-2.0 WITH
LLVM-exception, with component terms retained in the repository's
[LLVM license](../../LICENSES/llvm-LICENSE.txt). No third-party implementation
is imported by this change.
'''
audit.write_text(audit.read_text()+body)
readme=f'''# CFG publication evidence: {audit_id}

The [audit](../../{audit_id}.md) owns interpretation and claim boundaries.
[Download the byte-exact archive](cfg-publication-evidence.tar.gz).

Archive SHA-256: `{checksum}`.

- `observations/final-manifest.json`: exact source/binary/input/configuration and full local validation-log hashes.
- `observations/refined-summary.json`: final six-pair complete source-to-object controls; detailed run directories retain raw per-process stdout/stderr and observations.
- `observations/refined-micro-summary.json`: final helper process comparisons including all neutral reverse-extras controls.
- `observations/census-compact.json` and `fused-census-summary.json`: baseline populations and executed final copy counts. `census/` and `fused-census/` retain native diagnostics; address-replay predictions remain explicitly labelled.
- `observations/trace-summary.json`: byte-identical token/IR/MIR/object hashes and byte sizes. Large trace streams and native binaries remain at their recorded owned local paths.
- `variants/`: independently built source variants, including rejected general sorting and the pre-fusion adverse prototype.
- `diagnostics/` and `reproduce/`: exact helper fixture, property checker, source-counter overlay and orchestration. The scripts record this session's absolute paths; point their `base` at a fresh owned workspace when reproducing. Use Git source revisions and recorded compiler flags, and verify the official SQLite archive hash before running.

The comparison entry point is repository-native `tools/performance_evidence.c`:

```sh
clang -std=c11 -Isrc -O2 -Wall -Wextra -Werror -Wno-unused-function -fwrapv -fno-strict-aliasing -funsigned-char tools/performance_evidence.c -lm -o performance-evidence
```

`reproduce/final_comparison.py` gives all frozen workload arguments. Both compiler
arms were built serially in one owned path with tests disabled. `final_micro.py`
uses native `instructions:u`, six pairs, one warmup and a 0.1 percent effect
screen. This is work/allocation evidence; elapsed time, RSS and Zen 5 speed
are not established.
'''
(out/'README.md').write_text(readme)
(base/'audit-path.txt').write_text(str(audit.relative_to(repo))+'\n')
(base/'audit-archive-sha256.txt').write_text(checksum+'\n')
print('AUDIT',audit.relative_to(repo),flush=True)
print('ARCHIVE',archive.stat().st_size,'bytes',checksum,flush=True)
