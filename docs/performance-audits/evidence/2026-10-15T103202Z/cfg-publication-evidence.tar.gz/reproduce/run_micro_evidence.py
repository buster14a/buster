from pathlib import Path
import subprocess,json,hashlib
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
s=(base/'probe/cfg_probe.c').read_text()
s=s.replace('bool extras = strcmp(mode, "extras") == 0;','bool extras_reverse = strcmp(mode, "extras-reverse") == 0;\n    bool extras = strcmp(mode, "extras") == 0 || extras_reverse;')
s=s.replace('        u32 last = extras ?', '        if (extras_reverse) first = b == 0 ? n / 2 : b == 1 ? 0 : n;\n        u32 last = extras ?')
s=s.replace('        f.blocks[b] =', '        if (extras_reverse) last = b == 0 ? n - 1 : b == 1 ? n / 2 - 1 : n + 1;\n        f.blocks[b] =')
s=s.replace('f.extras[e].reserved == e','f.extras[e].reserved == (extras_reverse ? (e + n / 2) % n : e)')
s=s.replace('u32 expected = reverse ?', 'u32 expected = extras_reverse ? (i < n ? (i + n / 2) % n : i) : reverse ?')
fixture=base/'probe/cfg_micro_probe.c';fixture.write_text(s)
for name,source in [('baseline',(base/'evidence/baseline-ir_cfg.c').read_bytes()),('final',(repo/'src/buster/lib/compiler/ir/ir_cfg.c').read_bytes())]:
 overlay=base/'variants'/f'micro-{name}'/'src/buster/lib/compiler/ir';overlay.mkdir(parents=True,exist_ok=True);(overlay/'ir_cfg.c').write_bytes(source)
 binary=base/'probe'/f'cfg_micro_{name}'
 cmd=['clang','-O2','-g','-ffunction-sections','-fdata-sections','-DBUSTER_INCLUDE_TESTS=0','-DBUSTER_LINK_LIBC=1','-DBUSTER_OPTIMIZE=1','-DBUSTER_SINGLE_THREADED=1','-I'+str(base/'variants'/f'micro-{name}'/'src'),'-I'+str(repo/'src'),'-fwrapv','-fno-strict-aliasing','-funsigned-char',str(fixture)]
 cmd += [str(repo/'src/buster/lib'/f'{k}.c') for k in ('arena','os','integer','string','float','time')]+['-Wl,--gc-sections','-lm','-lpthread','-ldl','-o',str(binary)]
 subprocess.run(cmd,check=True)
 subprocess.run([str(binary),'extras-reverse','1024'],check=True,capture_output=True)
manifest={'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'binaries':{n:hashlib.sha256((base/'probe'/f'cfg_micro_{n}').read_bytes()).hexdigest() for n in ('baseline','final')}}
(base/'evidence/micro-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for mode in ('identity','descending','extras','extras-reverse','reopen'):
 for n in (1024,16384,65536):
  name=f'micro-{mode}-{n}'
  cmd=['taskset','-c','14',str(base/'frozen-compiler/performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--events','instructions:u','--baseline',str(base/'probe/cfg_micro_baseline'),'--candidate',str(base/'probe/cfg_micro_final'),'--out',str(base/'evidence'/name),'--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--candidate-revision','3f6c58b73bebf8866091d4d570c2486eb8d5ee95','--',mode,str(n)]
  with (base/'evidence'/f'{name}.log').open('w') as f:r=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
  d=json.loads((base/'evidence'/name/'summary.json').read_text());m=d['metrics'][0]
  print(name,m['verdict'],round(m['relative_change']*100,3),flush=True)
