from pathlib import Path
import subprocess,json,hashlib
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
assert (repo/'src/buster/lib/compiler/ir/ir_cfg.c').read_bytes()==(base/'variants/micro-fused/src/buster/lib/compiler/ir/ir_cfg.c').read_bytes()
manifest={'source_revision':'62d2d61160198681ce471b5f3ec14039eb00a6b0','fixture_sha256':hashlib.sha256((base/'probe/cfg_micro_probe.c').read_bytes()).hexdigest(),'baseline_binary_sha256':hashlib.sha256((base/'probe/cfg_micro_baseline').read_bytes()).hexdigest(),'candidate_binary_sha256':hashlib.sha256((base/'probe/cfg_micro_fused').read_bytes()).hexdigest()}
(base/'evidence/refined-micro-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary=[]
for mode in ('identity','descending','extras','extras-reverse','reopen'):
 for n in (1024,16384,65536):
  name=f'micro-refined-{mode}-{n}'
  cmd=['taskset','-c','14',str(base/'frozen-compiler/performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--events','instructions:u','--baseline',str(base/'probe/cfg_micro_baseline'),'--candidate',str(base/'probe/cfg_micro_fused'),'--out',str(base/'evidence'/name),'--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--candidate-revision',manifest['source_revision'],'--',mode,str(n)]
  with (base/'evidence'/f'{name}.log').open('w') as f:r=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
  d=json.loads((base/'evidence'/name/'summary.json').read_text());m=d['metrics'][0]
  row={'case':name,'metrics':d['metrics']};summary.append(row)
  (base/'evidence/refined-micro-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  print(name,m['verdict'],round(m['relative_change']*100,3),flush=True)
