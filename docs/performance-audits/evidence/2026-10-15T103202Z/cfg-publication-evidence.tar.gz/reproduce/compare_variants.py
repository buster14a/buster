from pathlib import Path
import subprocess,json,time
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster'
summary=[]
for variant in ('extras','maps','pools','combined'):
 deadline=time.monotonic()+1800
 while True:
  try: ready=any(x['variant']==variant for x in json.loads((base/'evidence/variants-build.json').read_text()))
  except (FileNotFoundError,json.JSONDecodeError): ready=False
  if ready: break
  if time.monotonic()>deadline:raise RuntimeError('variant not available: '+variant)
  time.sleep(2)
 for inp in ('sqlite','unity'):
  for debug in ('g0','g'):
   name=f'{variant}-{inp}-{debug}'
   args=['taskset','-c','14',str(base/'frozen-compiler/performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--events','instructions:u','--baseline',str(base/'frozen-compiler/baseline-ide'),'--candidate',str(base/'frozen-compiler'/f'{variant}-ide'),'--out',str(base/'evidence'/name),'--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline-revision','84f051c13044938bcb8cbe1ac48ea3ee79defcff','--','cc','-w','-c','-'+debug]
   if inp=='unity':args+=['-I'+str(base/'frozen-input/src'),'-I'+str(base/'frozen-input/build/generated'),'-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0',str(base/'frozen-input/src/buster/apps/ide/ide.c')]
   else:args+=['-DSQLITE_THREADSAFE=0',str(base/'inputs/sqlite-amalgamation-3530400/sqlite3.c')]
   args+=['-o',str(base/'evidence/perf-output.o')]
   with (base/'evidence'/f'{name}.log').open('w') as log:r=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
   if r.returncode: print('incomplete',name,r.returncode,flush=True);raise SystemExit(r.returncode)
   data=json.loads((base/'evidence'/name/'summary.json').read_text())
   summary.append({'case':name,'complete':data.get('complete'),'results':data.get('results',data.get('comparisons',data.get('metrics')))})
   (base/'evidence/ablation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
   print(name,'complete',flush=True)
