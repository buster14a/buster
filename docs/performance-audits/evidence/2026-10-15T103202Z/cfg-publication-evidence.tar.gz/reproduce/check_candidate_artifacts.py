from pathlib import Path
import subprocess,json,hashlib
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster';folder=base/'evidence/candidate-artifacts';folder.mkdir(exist_ok=True)
results=[]
for inp in ('sqlite','unity'):
 for debug in ('g0','g'):
  name=f'{inp}-{debug}';d=json.loads((base/'evidence/baseline-artifacts'/f'{name}.json').read_text())
  args=d['argv'];args[0]=str(base/'frozen-compiler/combined-fast-ide');args[-1]=str(folder/f'{name}.o')
  with (folder/f'{name}.log').open('w') as f:r=subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
  digest=hashlib.sha256((folder/f'{name}.o').read_bytes()).hexdigest()
  assert digest==d['sha256'],name
  result={'case':name,'sha256':digest,'bytes':(folder/f'{name}.o').stat().st_size,'identical':True}
  results.append(result);print(json.dumps(result),flush=True)
(folder/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
