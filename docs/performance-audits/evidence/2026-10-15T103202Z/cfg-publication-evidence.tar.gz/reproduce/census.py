from pathlib import Path
import json,shlex,subprocess
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work')
repo=base/'buster'
p=repo/'src/buster/lib/compiler/ir/ir_cfg.c'
s=p.read_text()
(base/'evidence/baseline-ir_cfg.c').write_text(s)
needle='''    if (result.error == IR_VALIDATION_NONE && (!operands_disjoint || !targets_disjoint || !immediates_disjoint))\n'''
insert='''    if (result.error == IR_VALIDATION_NONE)
    {
        for (u32 census_kind = 0; census_kind < 3; census_kind += 1)
        {
            bool census_ascending = census_kind == 0 ? operands_disjoint : census_kind == 1 ? targets_disjoint : immediates_disjoint;
            u64 census_total = census_kind == 0 ? operand_count : census_kind == 1 ? target_count : immediate_count;
            fprintf(stderr, "CFG_POOL f=%u kind=%u ascending=%u total=%llu\\n", function->id.value, census_kind, (u32)census_ascending, (unsigned long long)census_total);
            if (!census_ascending)
            {
                for (u32 census_row = 0; census_row < function->instruction_count; census_row += 1)
                {
                    IrInstruction const* census_instruction = function->instructions + census_row;
                    u64 census_begin = (u64)(uintptr_t)(census_kind == 0 ? (void*)census_instruction->operands : census_kind == 1 ? (void*)census_instruction->targets : (void*)census_instruction->immediates);
                    u64 census_count = census_kind == 0 ? census_instruction->operand_count : census_kind == 1 ? census_instruction->target_count : census_instruction->immediate_count;
                    u64 census_end = census_begin + census_count * (census_kind == 2 ? sizeof(u64) : sizeof(IrValueId));
                    if (census_count) fprintf(stderr, "CFG_SLICE f=%u kind=%u start=%llu end=%llu\\n", function->id.value, census_kind, (unsigned long long)census_begin, (unsigned long long)census_end);
                }
            }
        }
    }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
needle='''    if (result.error == IR_VALIDATION_NONE)\n    {\n        result = ir_cfg_separate_operand_slices(arena, function, cfg);\n    }\n'''
insert='''    if (result.error == IR_VALIDATION_NONE)
    {
        bool census_ordered = true;
        u32 census_changed = 0;
        u32 census_previous = 0;
        u32 census_first = count;
        for (u32 census_extra = 0; census_extra < function->extra_count; census_extra += 1)
        {
            u32 census_old = function->extra_instructions[census_extra].value;
            u32 census_new = remap[census_old].value;
            census_ordered &= !census_extra || census_new > census_previous;
            census_changed += census_old != census_new;
            census_previous = census_new;
        }
        for (u32 census_row = 0; census_row < count && census_first == count; census_row += 1)
        {
            if (inverse[census_row] != census_row) census_first = census_row;
        }
        fprintf(stderr, "CFG_CENSUS f=%u rows=%u moved=%u first=%u extras=%u ordered=%u changed_extras=%u\\n", function->id.value, count, (u32)moved, census_first, function->extra_count, (u32)census_ordered, census_changed);
    }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
p.write_text(s)
(base/'evidence/census.patch').write_text(subprocess.check_output(['git','diff','--','src/buster/lib/compiler/ir/ir_cfg.c'],cwd=repo,text=True))
entries=json.loads((repo/'build/compile_commands.json').read_text())
e=next(e for e in entries if e['file'].endswith('/apps/ide/ide.c') and 'CMAKE_INTDIR=\\"Release\\"' in e['command'])
args=shlex.split(e['command'])
new=[];i=0
while i<len(args):
 a=args[i]
 if a in ('-o','-MT','-MF'): i+=2;continue
 if a in ('-MD','-c'): i+=1;continue
 new.append(a.replace('BUSTER_BENCH_ALLOCATIONS=0','BUSTER_BENCH_ALLOCATIONS=1'));i+=1
new+=['-lm','-o',str(base/'frozen-compiler/census-ide')]
(base/'evidence/census-compile-argv.json').write_text(json.dumps(new,indent=2)+'\n')
with (base/'census-build.log').open('w') as f:
 r=subprocess.run(new,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
print('census compiler exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
