from pathlib import Path
import subprocess,json,hashlib
base=Path('/home/david/Documents/Codex/2026-10-15/iden-3/work');repo=base/'buster';root=base/'trace-artifacts';root.mkdir(exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
results=[]
for inp in ('sqlite','unity'):
 for debug in ('g0','g'):
  name=f'{inp}-{debug}';reference=None
  for arm,binary in [('baseline','baseline-ide'),('candidate','refined-ide')]:
   folder=root/arm;folder.mkdir(exist_ok=True);prefix=folder/name
   args=json.loads((base/'evidence/baseline-artifacts'/f'{name}.json').read_text())['argv'][1:];args[-1]=str(prefix)+'.o';args+=['-fbootstrap-trace='+str(prefix)]
   with Path(str(prefix)+'.log').open('w') as f:r=subprocess.run([str(base/'frozen-compiler'/binary)]+args,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
   if r.returncode:print('trace failed',arm,name,r.returncode,flush=True);raise SystemExit(r.returncode)
   fields={ext:{'sha256':digest(Path(str(prefix)+'.'+ext)),'bytes':Path(str(prefix)+'.'+ext).stat().st_size} for ext in ('tokens','ir','mir','o')}
   if reference is None:reference=fields
   else:assert fields==reference,(name,fields,reference)
  row={'case':name,'identical':True,'artifacts':reference};results.append(row);print(name,'token/IR/MIR/object identity',True,flush=True)
(base/'evidence/trace-summary.json').write_text(json.dumps(results,indent=2)+'\n')
