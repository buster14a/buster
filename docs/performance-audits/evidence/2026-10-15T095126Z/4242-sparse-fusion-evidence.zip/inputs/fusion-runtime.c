int input, other;
__attribute__((noinline)) void escape(int *p) { *p += 13; }
__attribute__((noinline)) int no_alias_branch(void)
{
    int x = input;
    escape(&x);
    x = other;
    if (x < input) return 7;
    return 3;
}
__attribute__((noinline)) int alias_branch(void)
{
    int x = input, condition = x < 3;
    x = input + 7;
    if (condition) return x;
    return input;
}
__attribute__((noinline)) int edge_branch(int n)
{
    int x = input;
    if (n & 1) x += 2;
    int condition = x < other;
    x += 7;
    if (condition) return x;
    return -x;
}
__attribute__((noinline)) int no_branch(void)
{
    int x = input;
    escape(&x);
    return x;
}
__attribute__((noinline)) int empty(void) { return 7; }
__attribute__((noinline)) int only_store(void)
{
    int x = 0;
    escape(&x);
    x = input;
    return 3;
}
int main(void)
{
    int failed = 0;
    for (input = -3; input <= 7; input += 1)
    {
        for (other = -3; other <= 7; other += 1)
        {
            failed += no_alias_branch() != (other < input ? 7 : 3);
            failed += alias_branch() != (input < 3 ? input + 7 : input);
            failed += no_branch() != input + 13;
            failed += empty() != 7;
            failed += only_store() != 3;
            for (int n = 0; n < 2; n += 1)
            {
                int old_x = input + (n ? 2 : 0);
                int expected = old_x < other ? old_x + 7 : -(old_x + 7);
                failed += edge_branch(n) != expected;
            }
        }
    }
    return failed != 0;
}
