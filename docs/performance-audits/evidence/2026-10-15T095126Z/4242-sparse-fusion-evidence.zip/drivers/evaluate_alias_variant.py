from pathlib import Path
import json
import random
import statistics
import subprocess
import sys

work=Path(__file__).resolve().parent
variant=sys.argv[1]
baseline=work/'bin'/'baseline'
candidate=work/'bin'/f'candidate-{variant}'
out=work/'evidence'/variant
out.mkdir(exist_ok=True)
source=work/'inputs'/'unity.i'
cells=[('work-fast','work-reduction','perf-stat','fast',6,candidate),('work-quality','work-reduction','perf-stat','quality',6,candidate),('time-aa','native-runtime','time','fast',20,baseline),('time-fast','native-runtime','time','fast',20,candidate),('time-quality','native-runtime','time','quality',20,candidate)]
for label,claim,tool,allocator,runs,arm in cells:
    command=['taskset','-c','2',str(work/'performance-evidence'),'compare','--claim',claim,'--tool',tool,'--runs',str(runs),'--warmup','1','--min-effect-percent','0.1','--baseline',str(baseline),'--candidate',str(arm),'--out',str(out/label)]
    if tool=='perf-stat':
        command+=['--events','instructions:u']
    command+=['--','cc','-march=native','-g0',f'-fregister-allocator={allocator}',str(source),'-lm','-o',str(work/'variant-unity')]
    print('CASE '+label,flush=True)
    subprocess.run(command,cwd=work/'buster',check=True)
    report=json.loads((out/label/'summary.json').read_text())
    if tool=='time':
        for metric in report['metrics']:
            if 'wall' in metric['name'] and metric['baseline'] and metric['candidate']:
                ratios=[b/a for a,b in zip(metric['baseline'],metric['candidate'])]
                rng=random.Random(4242)
                boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(20000))
                receipt={'label':label,'metric':metric['name'],'statistic':'median paired candidate/baseline wall ratio','pairs':len(ratios),'seed':4242,'bootstrap_samples':20000,'median':statistics.median(ratios),'ci95':[boot[500],boot[19499]],'ratios':ratios}
                (out/(label+'-paired-ci.json')).write_text(json.dumps(receipt,indent=2)+'\n')
                print(json.dumps(receipt),flush=True)
