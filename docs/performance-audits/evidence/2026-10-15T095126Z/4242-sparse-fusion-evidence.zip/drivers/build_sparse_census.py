from pathlib import Path
import shutil
import subprocess

work = Path(__file__).resolve().parent
root = work/'buster'
subprocess.run(['python3',str(work/'sparse_fusion_census.py'),'apply'],cwd=root,check=True)
try:
    with (work/'sparse-fusion-census-build.log').open('w') as log:
        subprocess.run(['./build.sh','build','--build-directory','build/profile','--config','Release','-t','ide'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    shutil.copy2(root/'build/profile/Release/ide',work/'bin/census-sparse-fusion')
finally:
    subprocess.run(['python3',str(work/'sparse_fusion_census.py'),'restore'],cwd=root,check=True)
with (work/'evidence/sparse-fusion-census.log').open('w') as log:
    subprocess.run(['python3',str(work/'sparse_fusion_census.py'),'run'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
