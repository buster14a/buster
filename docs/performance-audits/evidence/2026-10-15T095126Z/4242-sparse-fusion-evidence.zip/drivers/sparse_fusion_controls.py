from pathlib import Path
import subprocess

work = Path(__file__).resolve().parent
out = work/'evidence'/'sparse-fusion-controls'
out.mkdir(exist_ok=True)
baseline = work/'bin'/'baseline'
candidate = work/'bin'/'candidate-sparse-fusion'
cells = [('aa-unity',work/'inputs'/'unity.i',baseline)]
cells += [(name,work/'inputs'/(name+'.c'),candidate) for name in ('no-locals-1024','eligible-1024','escaped-1024','disqualified-1024','fusion-runtime')]
for label,source,arm in cells:
    command = ['taskset','-c','2',str(work/'performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline',str(baseline),'--candidate',str(arm),'--baseline-revision','35fee905e39941acafb26db6d6ff3f41eb7d8dc7','--candidate-revision','35fee905e39941acafb26db6d6ff3f41eb7d8dc7' if arm == baseline else 'fe30591bd1adba279b4b73d23dc30262e0e8173b','--events','instructions:u','--out',str(out/label),'--','cc','-march=native','-g0','-fregister-allocator=fast']
    command += [str(source),'-lm','-o',str(work/'control-unity')] if source.suffix == '.i' or label == 'fusion-runtime' else ['-c',str(source),'-o',str(work/'control.o')]
    print('CASE '+label,flush=True)
    subprocess.run(command,cwd=work/'buster',check=True)
