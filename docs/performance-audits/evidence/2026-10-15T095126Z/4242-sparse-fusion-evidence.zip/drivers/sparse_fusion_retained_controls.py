from pathlib import Path
import subprocess

work = Path(__file__).resolve().parent
out = work/'evidence'/'sparse-fusion-controls'
for name in ('no-locals-1024','eligible-1024','escaped-1024'):
    command = ['taskset','-c','2',str(work/'performance-evidence'),'compare','--claim','work-reduction','--tool','perf-stat','--runs','6','--warmup','1','--min-effect-percent','0.1','--baseline',str(work/'bin/baseline'),'--candidate',str(work/'bin/candidate-sparse-fusion'),'--baseline-revision','35fee905e39941acafb26db6d6ff3f41eb7d8dc7','--candidate-revision','fe30591bd1adba279b4b73d23dc30262e0e8173b','--events','instructions:u','--out',str(out/(name+'-retained')),'--','cc','-march=native','-g0','-fregister-allocator=fast','-fno-frontend-ssa','-fno-canonical-local-promotion','-fno-canonical-fast','-c',str(work/'inputs'/(name+'.c')),'-o',str(work/'control.o')]
    print('CASE '+name+'-retained',flush=True)
    subprocess.run(command,cwd=work/'buster',check=True)
