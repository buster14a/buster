from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

work = Path(__file__).resolve().parent
root = work / 'buster'
path = root / 'src/buster/lib/compiler/codegen/machine_x86_64.c'
source = subprocess.check_output(['git', 'show', 'aeda165e8:src/buster/lib/compiler/codegen/machine_x86_64.c'], cwd=root).decode()
mode = sys.argv[1]
if mode == 'restore':
    path.write_text(source)
elif mode == 'apply':
    text = '#include <stdio.h>\n#include <stdlib.h>\n#include <buster/lib/time.h>\n' + source
    text = text.replace('    u32 alias_count = 0;\n', '    bool diagnostic_guard = getenv("BUSTER_ALIAS_GUARD") != 0;\n    u32 diagnostic_probes = 0;\n    u64 diagnostic_fusion_visits = 0;\n    TimeDataType diagnostic_start = timestamp_take();\n    u32 alias_count = 0;\n', 1)
    text = text.replace('        may_alias_loads = value_uses[local_uses[index].value].local_use != 0;', '        diagnostic_probes += 1;\n        may_alias_loads = value_uses[local_uses[index].value].local_use != 0;', 1)
    text = text.replace('alias_sweep < 2 && may_alias_loads;', 'alias_sweep < 2 && (may_alias_loads || !diagnostic_guard);', 1)
    text = text.replace('    // A local with no store has no defining value', '    u64 diagnostic_alias_ns = timestamp_ns_between(diagnostic_start, timestamp_take());\n    u64 diagnostic_alias_hash = 0;\n    for (u32 index = 0; index < alias_count; index += 1)\n    {\n        diagnostic_alias_hash = diagnostic_alias_hash * 65599 + alias_values[index];\n        diagnostic_alias_hash = diagnostic_alias_hash * 65599 + load_aliases[alias_values[index]];\n    }\n    // A local with no store has no defining value', 1)
    text = text.replace('index < local_use_count && alias_count;', 'index < local_use_count && (alias_count || !diagnostic_guard);', 1)
    text = text.replace('u32 first_candidate = alias_count || !block_candidate_count ? 0 : block_candidate_count - 1;', 'u32 first_candidate = alias_count || !diagnostic_guard || !block_candidate_count ? 0 : block_candidate_count - 1;\n        diagnostic_fusion_visits += block_candidate_count - first_candidate;', 1)
    text = text.replace('    // A cast that copies a constant materializes it itself,', '    fprintf(stderr, "SPARSE_FUSION locals=%u probes=%u may=%u candidates=%u aliases=%u map=%llu alias_ns=%llu fusion_visits=%llu\\n", local_use_count - 1, diagnostic_probes, (u32)may_alias_loads, candidate_count, alias_count, (unsigned long long)diagnostic_alias_hash, (unsigned long long)diagnostic_alias_ns, (unsigned long long)diagnostic_fusion_visits);\n    // A cast that copies a constant materializes it itself,', 1)
    assert text.count('SPARSE_FUSION') == 1
    path.write_text(text)
elif mode == 'run':
    out = work / 'evidence' / 'sparse-fusion-census'
    out.mkdir(exist_ok=True)
    pattern = rb'SPARSE_FUSION locals=(\d+) probes=(\d+) may=(\d+) candidates=(\d+) aliases=(\d+) map=(\d+) alias_ns=(\d+) fusion_visits=(\d+)'
    records = []
    signatures = {}
    for allocator in ('fast', 'quality'):
        reference = out / (allocator + '-reference')
        reference_command = ['taskset', '-c', '2', str(work/'bin'/'baseline'), 'cc', '-march=native', '-g0', f'-fregister-allocator={allocator}', str(work/'inputs'/'unity.i'), '-lm', '-o', str(reference)]
        subprocess.run(reference_command, cwd=root, check=True, capture_output=True)
        for pair in range(2):
            for guarded in ((False, True) if pair == 0 else (True, False)):
                label = f'{allocator}-{pair}-' + ('guarded' if guarded else 'baseline')
                env = dict(os.environ)
                env.pop('BUSTER_ALIAS_GUARD', None)
                if guarded:
                    env['BUSTER_ALIAS_GUARD'] = '1'
                command = ['taskset', '-c', '2', str(work/'bin'/'census-sparse-fusion'), 'cc', '-march=native', '-g0', f'-fregister-allocator={allocator}', str(work/'inputs'/'unity.i'), '-lm', '-o', str(work/'census-unity')]
                run = subprocess.run(command, cwd=root, env=env, capture_output=True, check=True)
                (out/(label+'.stdout')).write_bytes(run.stdout)
                (out/(label+'.stderr')).write_bytes(run.stderr)
                rows = [dict(zip(('locals','probes','may','candidates','aliases','map','alias_ns','fusion_visits'), map(int, row))) for row in re.findall(pattern, run.stderr)]
                assert rows
                signature = [{k:v for k,v in row.items() if k not in ('alias_ns','fusion_visits')} for row in rows]
                if allocator in signatures:
                    assert signature == signatures[allocator]
                else:
                    signatures[allocator] = signature
                image = (work/'census-unity').read_bytes()
                assert image == reference.read_bytes()
                record = {'label':label,'allocator':allocator,'pair':pair,'guarded':guarded,'command':command,'functions':len(rows),'alias_functions':sum(row['aliases']>0 for row in rows),'eligible_functions':sum(row['may']>0 for row in rows),'aliases':sum(row['aliases'] for row in rows),'probes':sum(row['probes'] for row in rows),'alias_visits':sum(2*row['candidates'] for row in rows if not guarded or row['may']),'fusion_visits':sum(row['fusion_visits'] for row in rows),'alias_ns':sum(row['alias_ns'] for row in rows),'image_sha256':hashlib.sha256(image).hexdigest(),'rows':rows}
                records.append(record)
                print(json.dumps({k:v for k,v in record.items() if k != 'rows'}),flush=True)
    (out/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
    populations = []
    for name in ('no-locals-1024','eligible-1024','escaped-1024','disqualified-1024'):
        for retained in (False,True):
            label = name + ('-retained' if retained else '-default')
            flags = ['-fno-frontend-ssa','-fno-canonical-local-promotion','-fno-canonical-fast'] if retained else []
            command = [str(work/'bin/census-sparse-fusion'),'cc','-march=native','-g0','-fregister-allocator=fast',*flags,'-c',str(work/'inputs'/(name+'.c')),'-o',str(work/'census-control.o')]
            run = subprocess.run(command,cwd=root,env={**os.environ,'BUSTER_ALIAS_GUARD':'1'},capture_output=True,check=True)
            (out/(label+'.stderr')).write_bytes(run.stderr)
            rows = [dict(zip(('locals','probes','may','candidates','aliases','map','alias_ns','fusion_visits'),map(int,row))) for row in re.findall(pattern,run.stderr)]
            population = {'label':label,'command':command,'functions':len(rows),'locals':sum(row['locals'] for row in rows),'probes':sum(row['probes'] for row in rows),'eligible_functions':sum(row['may']>0 for row in rows),'alias_functions':sum(row['aliases']>0 for row in rows),'aliases':sum(row['aliases'] for row in rows)}
            assert rows
            if name == 'disqualified-1024':
                assert population['eligible_functions'] == 0
            if name == 'eligible-1024' and retained:
                assert population['alias_functions'] > 0
            populations.append(population)
            print(json.dumps(population),flush=True)
    (out/'populations.json').write_text(json.dumps(populations,indent=2)+'\n')
else:
    raise ValueError(mode)
