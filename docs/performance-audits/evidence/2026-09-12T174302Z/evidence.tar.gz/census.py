import os, pathlib, shutil, subprocess, hashlib, json
root=pathlib.Path.cwd()
evidence=pathlib.Path('/dev/shm/buster-125-evidence')
work=evidence/'census'
work.mkdir(exist_ok=True)
env=os.environ|{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1','TMPDIR':'/dev/shm/buster-125-test-tmp'}
records=[]
for name,binary in [('base',evidence/'base-census-ide'),('patch',root/'build-sanitize/Debug/ide')]:
    path=work/'ide'
    shutil.copyfile(binary,path)
    path.chmod(0o700)
    for case,source,extra in [
        ('pressure',root/'tests/basic_c_register_pressure.c',[]),
        ('compiler',evidence/'frozen/src/buster/apps/ide/ide.c',['-I'+str(evidence/'frozen/src'),'-I'+str(evidence/'frozen/generated'),'-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0'])]:
        args=[str(path),'cc','-g0','-O0','-fregister-allocator=quality','-fno-machine-fallback','-fsource-metrics='+str(work/'out.metrics'),*extra,'-c',str(source),'-o',str(work/'out.o')]
        with (work/(name+'-'+case+'.log')).open('w') as log:
            p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=log,timeout=300)
        record={'variant':name,'case':case,'command':args,'returncode':p.returncode,'binary_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        if p.returncode==0:
            shutil.copyfile(work/'out.metrics',work/(name+'-'+case+'.metrics'))
            record['object_sha256']=hashlib.sha256((work/'out.o').read_bytes()).hexdigest()
        records.append(record)
        (work/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
        if p.returncode: raise SystemExit(p.returncode)
(work/'ide').unlink()
