#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/dev/shm/buster-125-test-tmp
export BUSTER_TEST_TEMPORARY_BASE=/dev/shm/buster-125-test-tmp
export BUSTER_TEST_JOBS=1
export BUSTER_QUALITY_SCRATCH_BENCH=1
taskset -c 0 /dev/shm/buster-125-evidence/base-replay-ide test --verbose=0 --ci=1 > /dev/shm/buster-125-evidence/replay-base-0.log 2>&1
taskset -c 0 build/Release/ide test --verbose=0 --ci=1 > /dev/shm/buster-125-evidence/replay-patch-0.log 2>&1
taskset -c 0 build/Release/ide test --verbose=0 --ci=1 > /dev/shm/buster-125-evidence/replay-patch-1.log 2>&1
taskset -c 0 /dev/shm/buster-125-evidence/base-replay-ide test --verbose=0 --ci=1 > /dev/shm/buster-125-evidence/replay-base-1.log 2>&1
unset BUSTER_QUALITY_SCRATCH_BENCH
build/throughput-tools/throughput run --baseline /dev/shm/buster-125-base-ide --candidate /dev/shm/buster-125-ca19de7627d9/build/Release/ide --output /dev/shm/buster-125-evidence/throughput --baseline-id 5f6758b12a7cc1610db33ec2a7f3338d9c008e1e --candidate-id 1e7d99d7 --profile ci --mode quality --pairs 8 --warmups 1 --no-guard --cpu 0 --require-identical-output --pmu > /dev/shm/buster-125-evidence/throughput.log 2>&1
