import json, pathlib, shlex, subprocess, sys
build_name = sys.argv[1] if len(sys.argv) > 1 else "build"
config = sys.argv[2] if len(sys.argv) > 2 else "Release"
label = "census" if config == "Debug" else "replay"
root = pathlib.Path.cwd()
out = pathlib.Path('/dev/shm/buster-125-evidence')
base_quality = out / 'register_allocator_quality_base.c'
base_quality.write_bytes(subprocess.check_output(['git','show','5f6758b12a7cc1610db33ec2a7f3338d9c008e1e:src/buster/lib/compiler/codegen/register_allocator_quality.c']))
base_machine = out / 'machine-base.c'
base_machine.write_text((root/'src/buster/lib/compiler/codegen/machine.c').read_text().replace('#include <buster/lib/compiler/codegen/register_allocator_quality.c>', '#include "'+str(base_quality)+'"'))
commands=subprocess.check_output(['ninja','-C',build_name,'-f','build-'+config+'.ninja','-t','commands',config+'/ide'],text=True).splitlines()
command=next(c for c in commands if c.endswith('/src/buster/lib/compiler/codegen/machine.c'))
args=shlex.split(command)
for option in ['-MT', '-MF']:
    if option in args:
        index=args.index(option)
        del args[index:index+2]
if '-MD' in args: args.remove('-MD')
entry={'directory':str(root/build_name)}
args[args.index('-o')+1]=str(out/('machine-base-'+label+'.o'))
args[-1]=str(base_machine)
subprocess.run(args,cwd=entry['directory'],check=True)
commands=subprocess.check_output(['ninja','-C',build_name,'-f','build-'+config+'.ninja','-t','commands',config+'/ide'],text=True).splitlines()
link=shlex.split(commands[-1])
link=link[2:-2]
link[link.index('-o')+1]=str(out/('base-'+label+'-ide'))
link=[str(out/('machine-base-'+label+'.o')) if a.endswith('/codegen/machine.c.o') else a for a in link]
subprocess.run(link,cwd=root/build_name,check=True)
(out/('baseline-'+label+'-commands.json')).write_text(json.dumps({'compile':args,'compile_cwd':entry['directory'],'link':link,'link_cwd':str(root/build_name)},indent=2)+'\n')
