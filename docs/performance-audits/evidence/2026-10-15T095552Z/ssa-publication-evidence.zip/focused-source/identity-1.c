int test(int(*p)(int),int x){
x=p(x);
return x;}
