extern void sink(int); int f(int x,int c){
while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c)while(c){
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
sink(c ? x : 1);
x=x;
}
return x; }
