int f(int x){
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
x=x+1;
return x; }
