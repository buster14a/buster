from pathlib import Path
import concurrent.futures,subprocess,json,hashlib,time
root=Path('/home/david/Documents/Codex/2026-10-15/ide/work')
repo=root/'buster'; frozen=root/'ssa-frozen-source';out=root/'ssa-corpus';out.mkdir(exist_ok=True)
binaries={'baseline':root/'ide-ssa-baseline','candidate':root/'ide-ssa-candidate'}
files=sorted((frozen/'tests').glob('*.c'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cell(item):
 source,allocator,debug=item;record={'source':str(source.relative_to(frozen)),'allocator':allocator,'debug':debug,'source_sha256':digest(source)}
 results={}
 for arm,binary in binaries.items():
  stem=f'{source.stem}-{allocator}-{debug}-{arm}';obj=out/(stem+'.o');obj.unlink(missing_ok=True)
  command=[str(binary),'cc','-std=gnu17','-w',f'-{debug}',f'-fregister-allocator={allocator}',f'-I{frozen}/src', '-c',str(source),'-o',str(obj)]
  try:
   p=subprocess.run(command,cwd=repo,capture_output=True,timeout=30)
   (out/(stem+'.stderr')).write_bytes(p.stderr)
   results[arm]={'exit':p.returncode,'diagnostic_sha256':hashlib.sha256(p.stderr).hexdigest(),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'object_sha256':digest(obj) if p.returncode==0 and obj.exists() else None,'object_bytes':obj.stat().st_size if p.returncode==0 and obj.exists() else None}
  except subprocess.TimeoutExpired as e:
   results[arm]={'exit':'timeout','diagnostic_sha256':None,'stdout_sha256':None,'object_sha256':None,'object_bytes':None}
 record['arms']=results
 record['identical']=results['baseline']==results['candidate'] and results['baseline']['exit']!='timeout' and (results['baseline']['exit']!=0 or results['baseline']['object_sha256'] is not None)
 return record
items=[(p,a,g) for p in files for a in ['fast','quality'] for g in ['g0','g']]
start=time.time();rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for row in pool.map(cell,items):
  rows.append(row)
  if not row['identical']:print('MISMATCH',json.dumps(row),flush=True)
  if len(rows)%200==0:print('completed',len(rows),'of',len(items),flush=True)
summary={'baseline':str(binaries['baseline']),'candidate':str(binaries['candidate']),'binary_sha256':{a:digest(p) for a,p in binaries.items()},'source_files':len(files),'cells':len(rows),'successes':sum(r['arms']['baseline']['exit']==0 for r in rows),'matching_failures':sum(r['identical'] and r['arms']['baseline']['exit']!=0 for r in rows),'mismatches':sum(not r['identical'] for r in rows),'seconds':time.time()-start,'rows':rows}
(out/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'}),flush=True)
assert summary['mismatches']==0
assert summary['successes']>len(rows)//2
assert all(r['arms']['baseline']['exit']==0 for r in rows if r['source']=='tests/basic_c_frontend_ssa.c')
