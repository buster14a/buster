
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
typedef uint8_t u8;
typedef uint32_t u32;
typedef uint64_t u64;
#define BUSTER_C_INTERNAL static
#define BUSTER_BENCH_ALLOCATIONS 0
#define BUSTER_MAX(a,b) ((a)>(b)?(a):(b))
static u64 replay_user_visits, replay_clear_bytes, replay_scratch_bytes;
#define IR_CONSTRUCTION_RECORD(k,n) RECORD_##k(n)
#define RECORD_SSA_VALUE_SCRATCH_BYTES(n) (replay_scratch_bytes+=(n))
#define RECORD_SSA_VALUE_CLEAR_BYTES(n) (replay_clear_bytes+=(n))
#define RECORD_SSA_SIMPLIFY_PARAMETER_VISITS(n) ((void)0)
#define RECORD_SSA_SIMPLIFY_INCOMING_VISITS(n) ((void)0)
#define RECORD_SSA_SIMPLIFY_BLOCK_VISITS(n) ((void)0)
typedef struct { u32 value; } IrValueId;
typedef struct IrIncoming IrIncoming;
struct IrIncoming { IrIncoming* next; IrValueId predecessor; IrValueId value; };
typedef struct IrBlockParameter IrBlockParameter;
struct IrBlockParameter { IrBlockParameter* next; IrIncoming* first_incoming; IrIncoming* last_incoming; IrValueId value; u32 incoming_count; };
typedef struct { IrBlockParameter* first_parameter; IrBlockParameter* last_parameter; u32 parameter_count; } IrBlock;
typedef struct { IrBlock* blocks; u32 value_count; } IrFunction;
typedef struct { u32 local; } CIrSsaParameter;
typedef struct { u32 parameter; u32 next; } CIrSsaUserOld;
typedef struct { u32 root; u32 previous; u32 next; } CIrSsaUser;
typedef struct { u8* reachable; struct { u32 parameters_removed; } statistics; } CIrDirectSsa;
typedef struct { u8* bytes; u64 position, capacity; } Arena;
static void* replay_allocate(Arena* arena, u64 bytes, u64 alignment) {
    u64 at=(arena->position+alignment-1)&~(alignment-1);
    assert(at+bytes<=arena->capacity);
    arena->position=at+bytes;
    return arena->bytes+at;
}
#define arena_allocate(a,t,n) ((t*)replay_allocate((a),sizeof(t)*(u64)(n),_Alignof(t)))
typedef struct { CIrDirectSsa* direct_ssa; IrFunction* function; Arena* scratch_arena; } CIntegerIrBuilder;
BUSTER_C_INTERNAL u32 c_ir_ssa_root(u32* replacements, u32 value)
{
    u32 root = value;
    while (replacements[root] != root)
    {
        root = replacements[root];
    }
    while (replacements[value] != value)
    {
        u32 next = replacements[value];
        replacements[value] = root;
        value = next;
    }
    return root;
}

BUSTER_C_INTERNAL void c_ir_ssa_retry_push(u64* heap, u32* heap_count, u64 key)
{
    u32 index = (*heap_count)++;
    while (index && heap[(index - 1) / 2] > key)
    {
        heap[index] = heap[(index - 1) / 2];
        index = (index - 1) / 2;
    }
    heap[index] = key;
}

BUSTER_C_INTERNAL u64 c_ir_ssa_retry_pop(u64* heap, u32* heap_count)
{
    u64 result = heap[0];
    u32 count = --(*heap_count);
    u64 key = heap[count];
    u32 index = 0;
    bool sifting = count != 0;
    while (sifting)
    {
        u32 child = index * 2 + 1;
        if (child + 1 < count && heap[child + 1] < heap[child])
        {
            child += 1;
        }
        sifting = child < count && heap[child] < key;
        if (sifting)
        {
            heap[index] = heap[child];
            index = child;
        }
    }
    if (count)
    {
        heap[index] = key;
    }
    return result;
}

BUSTER_C_INTERNAL void c_ir_ssa_simplify_parameters_reference(CIntegerIrBuilder* builder, u8* memory, u32* replacements,
                                                    CIrSsaParameter** pending_by_value, IrBlockParameter** parameter_by_value,
                                                    u32* cursor, u32 active_block_count)
{
    CIrDirectSsa* ssa = builder->direct_ssa;
    IrFunction* function = builder->function;
    u32 count = function->value_count;
    u32* user_first = arena_allocate(builder->scratch_arena, u32, count);
    u32* user_last = arena_allocate(builder->scratch_arena, u32, count);
    u32* order = arena_allocate(builder->scratch_arena, u32, count);
    u32* position = arena_allocate(builder->scratch_arena, u32, count);
    u64* heap = arena_allocate(builder->scratch_arena, u64, count);
    u8* queued = arena_allocate(builder->scratch_arena, u8, count);
    u64 user_capacity = 0;
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
        {
            user_capacity += parameter->incoming_count;
        }
    }
    CIrSsaUserOld* users = arena_allocate(builder->scratch_arena, CIrSsaUserOld, user_capacity ? user_capacity : 1);
    memset(user_first, 0xff, sizeof(*user_first) * count);
    memset(queued, 0, count);
    memset(parameter_by_value, 0, sizeof(*parameter_by_value) * count);
    IR_CONSTRUCTION_RECORD(SSA_VALUE_SCRATCH_BYTES, (sizeof(*user_first) * 4 + sizeof(*heap) + sizeof(*queued)) * (u64)count +
                                                    sizeof(*users) * user_capacity);
    IR_CONSTRUCTION_RECORD(SSA_VALUE_CLEAR_BYTES, (sizeof(*user_first) + sizeof(*queued) + sizeof(*parameter_by_value)) * (u64)count);
    // Number every retained parameter in sweep order, due in sweep zero, and
    // file each incoming row under the root it currently reads. Ascending
    // keys already form a valid heap.
    u32 user_count = 0;
    u32 heap_count = 0;
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
        {
            u32 value = parameter->value.value;
            CIrSsaParameter* pending = pending_by_value[value];
            if ((!pending || !memory[pending->local]) && replacements[value] == value)
            {
                parameter_by_value[value] = parameter;
                position[value] = heap_count;
                order[heap_count] = value;
                heap[heap_count] = heap_count;
                heap_count += 1;
                queued[value] = 1;
                for (IrIncoming* incoming = parameter->first_incoming; incoming; incoming = incoming->next)
                {
                    u32 root = c_ir_ssa_root(replacements, incoming->value.value);
                    if (root != value)
                    {
                        users[user_count] = (CIrSsaUserOld){.parameter = value, .next = UINT32_MAX};
                        if (user_first[root] == UINT32_MAX)
                        {
                            user_first[root] = user_count;
                        }
                        else
                        {
                            users[user_last[root]].next = user_count;
                        }
                        user_last[root] = user_count;
                        user_count += 1;
                    }
                }
            }
        }
    }
#if BUSTER_BENCH_ALLOCATIONS
    // The census counts the sweeps the full block-order sweep would take.
    u64 sweeps = heap_count != 0;
#endif
    while (heap_count)
    {
        u64 key = c_ir_ssa_retry_pop(heap, &heap_count);
        u64 sweep = key >> 32;
        u32 here = (u32)key;
        u32 value = order[here];
        queued[value] = 0;
#if BUSTER_BENCH_ALLOCATIONS
        sweeps = BUSTER_MAX(sweeps, sweep + 1);
#endif
        IrBlockParameter* parameter = parameter_by_value[value];
        IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_PARAMETER_VISITS, 1);
        // An edge out of an unreachable block never runs, so the
        // value it carries cannot reach the parameter: when every
        // edge that can run carries one value, the parameter is
        // that value. A compound statement that ends in `break`,
        // `goto` or `return` leaves its continuation block without
        // predecessors, and the next `case` or label still gets an
        // edge from it, whose value is an unfilled parameter of the
        // dead block. Counting it would keep a merge of every
        // variable read after that label -- and of everything
        // downstream -- alive. With no runnable edge carrying a
        // value, only the dead ones decide, as they always did:
        // every dead root must agree, so the first mismatch is
        // final and a later repeat cannot restore triviality.
        u32 same = UINT32_MAX;
        bool trivial = true;
        u32 dead_same = UINT32_MAX;
        bool dead_trivial = true;
        for (IrIncoming* incoming = parameter->first_incoming; incoming && trivial; incoming = incoming->next)
        {
            IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_INCOMING_VISITS, 1);
            u32 root = c_ir_ssa_root(replacements, incoming->value.value);
            bool runs = ssa->reachable[incoming->predecessor.value] != 0;
            if (root != value && runs)
            {
                trivial = same == UINT32_MAX || root == same;
                same = root;
            }
            else if (root != value)
            {
                dead_trivial = dead_trivial && (dead_same == UINT32_MAX || root == dead_same);
                dead_same = root;
            }
        }
        if (trivial && same == UINT32_MAX)
        {
            trivial = dead_trivial;
            same = dead_same;
        }
        if (trivial && same != UINT32_MAX)
        {
            replacements[value] = same;
            // Every parameter reading this one now reads `same`. The full
            // sweep reaches a later position in this sweep, an earlier one
            // in the next. Move the rows to `same` for its own replacement,
            // minus those that can never requeue again: a replaced reader
            // stays replaced, and `same` now reads itself. Carrying them
            // would grow each list along a chain of trivial loop-header
            // parameters, making N nested loops cost N^3 (#3723).
            u32 kept_first = UINT32_MAX;
            u32 kept_last = UINT32_MAX;
            u32 user = user_first[value];
            while (user != UINT32_MAX)
            {
                replay_user_visits += 1;
                u32 next = users[user].next;
                u32 reader = users[user].parameter;
                if (replacements[reader] == reader)
                {
                    if (!queued[reader])
                    {
                        queued[reader] = 1;
                        u64 due = position[reader] > here ? sweep : sweep + 1;
                        c_ir_ssa_retry_push(heap, &heap_count, due << 32 | position[reader]);
                    }
                    if (reader != same)
                    {
                        users[user].next = UINT32_MAX;
                        if (kept_first == UINT32_MAX)
                        {
                            kept_first = user;
                        }
                        else
                        {
                            users[kept_last].next = user;
                        }
                        kept_last = user;
                    }
                }
                user = next;
            }
            user_first[value] = UINT32_MAX;
            if (kept_first != UINT32_MAX)
            {
                if (user_first[same] == UINT32_MAX)
                {
                    user_first[same] = kept_first;
                }
                else
                {
                    users[user_last[same]].next = kept_first;
                }
                user_last[same] = kept_last;
            }
        }
    }
#if BUSTER_BENCH_ALLOCATIONS
    IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_PASSES, sweeps);
#endif
    // Unlink every replaced or memory-owned parameter in one final sweep, the
    // one block visit simplification makes; numbering above reads the same rows.
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        IR_CONSTRUCTION_RECORD(SSA_SIMPLIFY_BLOCK_VISITS, 1);
        IrBlock* destination = function->blocks + cursor[active];
        IrBlockParameter** link = &destination->first_parameter;
        destination->last_parameter = 0;
        while (*link)
        {
            IrBlockParameter* parameter = *link;
            CIrSsaParameter* pending = pending_by_value[parameter->value.value];
            if ((pending && memory[pending->local]) || replacements[parameter->value.value] != parameter->value.value)
            {
                *link = parameter->next;
                destination->parameter_count -= 1;
                ssa->statistics.parameters_removed += 1;
            }
            else
            {
                destination->last_parameter = parameter;
                link = &parameter->next;
            }
        }
    }
}
// Two distinct non-self roots witness that a parameter cannot simplify.
// Watch their union groups, not each intermediate canonical representative.
// Union by rank moves each live witness only through logarithmically many
// groups; requeue only when the witnesses meet or one becomes the reader.
BUSTER_C_INTERNAL void c_ir_ssa_unwatch(u32* first, CIrSsaUser* users, u32 reader)
{
    for (u32 index = reader * 2; index < reader * 2 + 2; index += 1)
    {
        CIrSsaUser* user = users + index;
        if (user->root != UINT32_MAX)
        {
            if (user->previous == UINT32_MAX)
            {
                first[user->root] = user->next;
            }
            else
            {
                users[user->previous].next = user->next;
            }
            if (user->next != UINT32_MAX)
            {
                users[user->next].previous = user->previous;
            }
            user->root = UINT32_MAX;
        }
    }
}

BUSTER_C_INTERNAL void c_ir_ssa_retry_witness(u32* first, CIrSsaUser* users, u64* heap, u32* heap_count,
                                             u32 reader, u32 here, u64 sweep)
{
    c_ir_ssa_unwatch(first, users, reader);
    u64 due = reader > here ? sweep : sweep + 1;
    c_ir_ssa_retry_push(heap, heap_count, due << 32 | reader);
}

BUSTER_C_INTERNAL void c_ir_ssa_simplify_parameters_new(CIntegerIrBuilder* builder, u8* memory, u32* replacements,
                                                    CIrSsaParameter** pending_by_value, IrBlockParameter** parameter_by_value,
                                                    u32* cursor, u32 active_block_count)
{
    CIrDirectSsa* ssa = builder->direct_ssa;
    IrFunction* function = builder->function;
    u32 count = function->value_count;
    u32 parameter_count = 0;
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
        {
            CIrSsaParameter* pending = pending_by_value[parameter->value.value];
            parameter_count += (!pending || !memory[pending->local]) && replacements[parameter->value.value] == parameter->value.value;
        }
    }
    if (parameter_count)
    {
        u32* first = arena_allocate(builder->scratch_arena, u32, count);
        u32* groups = arena_allocate(builder->scratch_arena, u32, count);
        u32* position = arena_allocate(builder->scratch_arena, u32, count);
        u8* rank = arena_allocate(builder->scratch_arena, u8, count);
        u32* order = arena_allocate(builder->scratch_arena, u32, parameter_count);
        u64* heap = arena_allocate(builder->scratch_arena, u64, parameter_count);
        CIrSsaUser* users = arena_allocate(builder->scratch_arena, CIrSsaUser, (u64)parameter_count * 2);
        memset(first, 0xff, sizeof(*first) * count);
        memset(rank, 0, count);
        memset(parameter_by_value, 0, sizeof(*parameter_by_value) * count);
        for (u32 value = 0; value < count; value += 1)
        {
            groups[value] = value;
        }
        for (u32 index = 0; index < parameter_count * 2; index += 1)
        {
            users[index].root = UINT32_MAX;
        }
        u32 heap_count = 0;
        for (u32 active = 0; active < active_block_count; active += 1)
        {
            for (IrBlockParameter* parameter = function->blocks[cursor[active]].first_parameter; parameter; parameter = parameter->next)
            {
                u32 value = parameter->value.value;
                CIrSsaParameter* pending = pending_by_value[value];
                if ((!pending || !memory[pending->local]) && replacements[value] == value)
                {
                    parameter_by_value[value] = parameter;
                    position[value] = heap_count;
                    order[heap_count] = value;
                    heap[heap_count] = heap_count;
                    heap_count += 1;
                }
            }
        }
        while (heap_count)
        {
            u64 key = c_ir_ssa_retry_pop(heap, &heap_count);
            u64 sweep = key >> 32;
            u32 here = (u32)key;
            u32 value = order[here];
            IrBlockParameter* parameter = parameter_by_value[value];
            u32 same = UINT32_MAX;
            u32 other = UINT32_MAX;
            bool trivial = true;
            u32 dead_same = UINT32_MAX;
            u32 dead_other = UINT32_MAX;
            bool dead_trivial = true;
            for (IrIncoming* incoming = parameter->first_incoming; incoming && trivial; incoming = incoming->next)
            {
                u32 root = c_ir_ssa_root(replacements, incoming->value.value);
                bool runs = ssa->reachable[incoming->predecessor.value] != 0;
                if (root != value && runs)
                {
                    if (same == UINT32_MAX)
                    {
                        same = root;
                    }
                    else if (same != root)
                    {
                        trivial = false;
                        other = root;
                    }
                }
                else if (root != value)
                {
                    if (dead_same == UINT32_MAX)
                    {
                        dead_same = root;
                    }
                    else if (dead_same != root)
                    {
                        dead_trivial = false;
                        dead_other = root;
                    }
                }
            }
            if (trivial && same == UINT32_MAX)
            {
                trivial = dead_trivial;
                same = dead_same;
                other = dead_other;
            }
            if (trivial && same != UINT32_MAX)
            {
                replacements[value] = same;
                u32 kept = c_ir_ssa_root(groups, value);
                u32 moved = c_ir_ssa_root(groups, same);
                if (rank[kept] < rank[moved])
                {
                    u32 swap = kept;
                    kept = moved;
                    moved = swap;
                }
                if (rank[kept] == rank[moved])
                {
                    rank[kept] += 1;
                }
                groups[moved] = kept;
                while (first[moved] != UINT32_MAX)
                {
                    replay_user_visits += 1;
                    u32 user = first[moved];
                    u32 reader = user / 2;
                    u32 next = users[user].next;
                    first[moved] = next;
                    if (next != UINT32_MAX)
                    {
                        users[next].previous = UINT32_MAX;
                    }
                    users[user].root = kept;
                    users[user].previous = UINT32_MAX;
                    users[user].next = first[kept];
                    if (first[kept] != UINT32_MAX)
                    {
                        users[first[kept]].previous = user;
                    }
                    first[kept] = user;
                    if (c_ir_ssa_root(groups, users[user ^ 1].root) == kept)
                    {
                        c_ir_ssa_retry_witness(first, users, heap, &heap_count, reader, here, sweep);
                    }
                }
                // `same` now reads itself if one of its witnesses joined its
                // own group. It can sit in the kept list, which did not move.
                if (parameter_by_value[same])
                {
                    u32 reader = position[same];
                    if (users[reader * 2].root != UINT32_MAX &&
                        (users[reader * 2].root == kept || users[reader * 2 + 1].root == kept))
                    {
                        c_ir_ssa_retry_witness(first, users, heap, &heap_count, reader, here, sweep);
                    }
                }
            }
            else if (!trivial)
            {
                u32 roots[2] = {same, other};
                for (u32 witness = 0; witness < 2; witness += 1)
                {
                    u32 root = c_ir_ssa_root(groups, roots[witness]);
                    u32 user = here * 2 + witness;
                    users[user] = (CIrSsaUser){.root = root, .previous = UINT32_MAX, .next = first[root]};
                    if (first[root] != UINT32_MAX)
                    {
                        users[first[root]].previous = user;
                    }
                    first[root] = user;
                }
            }
        }
    }
    for (u32 active = 0; active < active_block_count; active += 1)
    {
        IrBlock* destination = function->blocks + cursor[active];
        IrBlockParameter** link = &destination->first_parameter;
        destination->last_parameter = 0;
        while (*link)
        {
            IrBlockParameter* parameter = *link;
            CIrSsaParameter* pending = pending_by_value[parameter->value.value];
            if ((pending && memory[pending->local]) || replacements[parameter->value.value] != parameter->value.value)
            {
                *link = parameter->next;
                destination->parameter_count -= 1;
                ssa->statistics.parameters_removed += 1;
            }
            else
            {
                destination->last_parameter = parameter;
                link = &parameter->next;
            }
        }
    }
}

static u32 rng_state;
static u32 random_u32(void) { rng_state=rng_state*1664525u+1013904223u; return rng_state; }
int main(void) {
 for (u32 seed=1;seed<=100000;seed++) {
  rng_state=seed;
  u32 pcount=1+random_u32()%24, count=pcount+3;
  u8 reachable[2]={(u8)(random_u32()%2),(u8)(random_u32()%2)};
  u8 memory[24]={0};
  CIrSsaParameter pending_rows[24];
  CIrSsaParameter* pending[27]={0};
  u32 initial[27];
  u32 incount[24], invalue[24][5], inpred[24][5];
  for(u32 v=0;v<count;v++) initial[v]=v;
  for(u32 v=0;v<pcount;v++) {
   memory[v]=(u8)(random_u32()%8==0);
   pending_rows[v].local=v;
   if(random_u32()%2) pending[v]=pending_rows+v;
   if(random_u32()%12==0) initial[v]=pcount+random_u32()%3;
   incount[v]=random_u32()%6;
   for(u32 i=0;i<incount[v];i++) { invalue[v][i]=random_u32()%count;inpred[v][i]=random_u32()%2; }
  }
  u32 roots[2][27], survivors[2][24], survivor_count[2]={0};
  for(u32 arm=0;arm<2;arm++) {
   Arena arena={.capacity=256ull*count+1024};arena.bytes=malloc(arena.capacity);memset(arena.bytes,0xa5,arena.capacity);
   IrBlockParameter params[24]={0}; IrIncoming incoming[24][5]={0};
   IrBlockParameter* byvalue[27];memset(byvalue,0,sizeof(byvalue));
   u32 replacements[27];memcpy(replacements,initial,count*sizeof(u32));
   IrBlock block={.first_parameter=params,.last_parameter=params+pcount-1,.parameter_count=pcount};
   IrFunction function={.blocks=&block,.value_count=count};CIrDirectSsa ssa={.reachable=reachable};
   CIntegerIrBuilder builder={.direct_ssa=&ssa,.function=&function,.scratch_arena=&arena};
   for(u32 v=0;v<pcount;v++) {
    params[v].value.value=v;params[v].next=v+1<pcount?params+v+1:0;params[v].incoming_count=incount[v];
    if(incount[v]) { params[v].first_incoming=incoming[v];params[v].last_incoming=incoming[v]+incount[v]-1; }
    for(u32 i=0;i<incount[v];i++) { incoming[v][i].value.value=invalue[v][i];incoming[v][i].predecessor.value=inpred[v][i];incoming[v][i].next=i+1<incount[v]?incoming[v]+i+1:0; }
   }
   u32 cursor[1]={0};
   if(arm) c_ir_ssa_simplify_parameters_new(&builder,memory,replacements,pending,byvalue,cursor,1);
   else c_ir_ssa_simplify_parameters_reference(&builder,memory,replacements,pending,byvalue,cursor,1);
   for(u32 v=0;v<count;v++) roots[arm][v]=c_ir_ssa_root(replacements,v);
   for(IrBlockParameter* param=block.first_parameter;param;param=param->next) survivors[arm][survivor_count[arm]++]=param->value.value;
   assert(survivor_count[arm]==block.parameter_count);
   free(arena.bytes);
  }
  if(memcmp(roots[0],roots[1],count*sizeof(u32)) || survivor_count[0]!=survivor_count[1] || memcmp(survivors[0],survivors[1],survivor_count[0]*sizeof(u32))) {
   printf("mismatch seed=%u parameters=%u reach=%u,%u\n",seed,pcount,reachable[0],reachable[1]);
   for(u32 v=0;v<pcount;v++) { printf("p%u initial=%u memory=%u pending=%u roots=%u,%u:",v,initial[v],memory[v],pending[v]!=0,roots[0][v],roots[1][v]);for(u32 i=0;i<incount[v];i++)printf(" %u@%u",invalue[v][i],inpred[v][i]);puts(""); }
   return 1;
  }
 }
 puts("100000 randomized parameter graphs: identical roots, survivors and order");return 0;
}
