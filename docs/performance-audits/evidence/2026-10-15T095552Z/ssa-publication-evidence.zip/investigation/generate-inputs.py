# Generate the C reproducer; N loops and N conditional expressions, O(N) source.
from pathlib import Path
for n in [32,64,128,256,512,1024,2048]:
    Path(f"fanout-{n}.c").write_text("extern void sink(int); int f(int x,int c){\n" + "while(c)"*n + "{\n" + "sink(c ? x : 1);\n"*n + "x=x;\n}\nreturn x; }\n")
