// The callee half of the packed/aligned layout pair.  It answers the sizes and
// offsets its own compiler computed and passes the packed aggregates by value,
// which is where a layout disagreement between the two compilers surfaces.
// See basic_c_packed_layout_caller.c for what each answer pins down.
#include "basic_c_packed_layout_shapes.h"

char packed_layout_aligned_object[3] __attribute__((aligned(64)));
packed_layout_raised packed_layout_raised_object;

int packed_layout_below_natural_object __attribute__((aligned(2))) = 31337;

unsigned long long packed_layout_record_size(void)
{
    return sizeof(struct packed_record);
}

unsigned long long packed_layout_record_value_offset(void)
{
    struct packed_record record;
    return (unsigned long long)((char *)&record.value - (char *)&record);
}

unsigned long long packed_layout_aligned_record_size(void)
{
    return sizeof(struct packed_aligned_record);
}

unsigned long long packed_layout_aligned_record_alignment(void)
{
    return _Alignof(struct packed_aligned_record);
}

unsigned long long packed_layout_bit_record_size(void)
{
    return sizeof(struct packed_bit_record);
}

unsigned long long packed_layout_bit_union_size(void)
{
    return sizeof(union packed_bit_union);
}

unsigned long long packed_layout_bit_union_tail_offset(void)
{
    struct packed_bit_union_record record;
    return (unsigned long long)((char *)&record.tail - (char *)&record);
}

struct packed_bit_union_record packed_layout_make_bit_union_record(int value, char tail)
{
    struct packed_bit_union_record record;
    record.bits.value = value;
    record.tail = tail;
    return record;
}

int packed_layout_bit_union_value(struct packed_bit_union_record record)
{
    return record.bits.value * 100 + record.tail;
}

unsigned long long packed_layout_split_size(void)
{
    return sizeof(struct packed_split_record);
}

unsigned long long packed_layout_split_tail_offset(void)
{
    struct packed_split_record record;
    return (unsigned long long)((char *)&record.tail - (char *)&record);
}

void packed_layout_write_split(struct packed_split_record* record, long long value)
{
    record->lead = 'L';
    record->value = value;
    record->tail = 't';
}

long long packed_layout_read_split(const struct packed_split_record* record)
{
    return record->value + record->tail + record->lead;
}

struct packed_split_record packed_layout_make_split(long long value)
{
    struct packed_split_record record;
    record.lead = 'S';
    record.value = value;
    record.tail = 'v';
    return record;
}

long long packed_layout_split_sum(struct packed_split_record record)
{
    return record.value + record.tail + record.lead;
}

struct packed_bit_pass_record packed_layout_make_bit_pass(char lead, int value, char tail)
{
    struct packed_bit_pass_record record;
    record.lead = lead;
    record.value = value;
    record.tail = tail;
    return record;
}

long long packed_layout_bit_pass_sum(struct packed_bit_pass_record record)
{
    return (long long)record.lead * 1000000 + record.value + record.tail;
}

struct packed_bit_cross_record packed_layout_make_bit_cross(int value)
{
    struct packed_bit_cross_record record;
    for (int index = 0; index < 7; index += 1)
    {
        record.lead[index] = (char)(index + 1);
    }
    record.value = value;
    record.tail = 'c';
    return record;
}

long long packed_layout_bit_cross_sum(struct packed_bit_cross_record record)
{
    return (long long)record.lead[0] * 1000000 + (long long)record.lead[6] * 100000 + record.value + record.tail;
}

struct packed_bit_named_record packed_layout_make_bit_named(float lead, int value)
{
    struct packed_bit_named_record record;
    record.lead = lead;
    record.value = value;
    return record;
}

long long packed_layout_bit_named_sum(struct packed_bit_named_record record)
{
    return (long long)(record.lead * 4) + record.value;
}

struct packed_bit_padded_record packed_layout_make_bit_padded(float lead)
{
    struct packed_bit_padded_record record;
    record.lead = lead;
    return record;
}

float packed_layout_bit_padded_lead(struct packed_bit_padded_record record)
{
    return record.lead;
}

struct packed_bit_padded_record packed_layout_bit_padded_neighbors(int left, struct packed_bit_padded_record record,
                                                                 int right, float before, float after)
{
    record.lead = record.lead + (float)left + (float)right + before + after;
    return record;
}

// The unselected return register is zero, so a caller cannot pass by reading
// a coincidentally live copy of the float from the other register class.
#if defined(__x86_64__) && defined(__linux__)
#if PACKED_LAYOUT_SYSV_INTEGER_BITFIELDS
__asm__(".text\n.globl packed_layout_bit_padded_register_result\n"
        "packed_layout_bit_padded_register_result:\n"
        "mov $0x42350000, %eax\npxor %xmm0, %xmm0\nret\n");
#else
__asm__(".text\n.globl packed_layout_bit_padded_register_result\n"
        "packed_layout_bit_padded_register_result:\n"
        "mov $0x42350000, %ecx\nmovd %ecx, %xmm0\nxor %eax, %eax\nret\n");
#endif
#else
struct packed_bit_padded_record packed_layout_bit_padded_register_result(void)
{
    struct packed_bit_padded_record record = {45.25f};
    return record;
}
#endif

unsigned long long packed_layout_below_natural_size(void)
{
    return sizeof(struct below_natural_record);
}

unsigned long long packed_layout_below_natural_offset(void)
{
    struct below_natural_record record;
    return (unsigned long long)((char *)&record.value - (char *)&record);
}

struct below_natural_record packed_layout_make_below_natural(char tag, int value)
{
    struct below_natural_record record;
    record.tag = tag;
    record.value = value;
    return record;
}

struct packed_record packed_layout_make_record(char tag, int value, short trailer)
{
    struct packed_record record;
    record.tag = tag;
    record.value = value;
    record.trailer = trailer;
    return record;
}

int packed_layout_record_middle(struct packed_record record)
{
    return record.value;
}

struct packed_aligned_record packed_layout_make_aligned_record(char tag, int value)
{
    struct packed_aligned_record record;
    record.tag = tag;
    record.value = value;
    return record;
}

int packed_layout_bit_pair(struct packed_bit_record record)
{
    return (int)record.low * 100 + (int)record.high;
}

void packed_layout_fill_aligned_object(char first)
{
    packed_layout_aligned_object[0] = first;
    packed_layout_aligned_object[1] = (char)(first + 1);
    packed_layout_aligned_object[2] = (char)(first + 2);
}

unsigned long long packed_layout_raised_record_size(void)
{
    return sizeof(struct packed_layout_raised_record);
}

unsigned long long packed_layout_raised_record_alignment(void)
{
    return _Alignof(struct packed_layout_raised_record);
}

unsigned long long packed_layout_raised_record_value_offset(void)
{
    struct packed_layout_raised_record record;
    return (unsigned long long)((char *)&record.value - (char *)&record);
}

unsigned long long packed_layout_lowered_record_size(void)
{
    return sizeof(struct packed_layout_lowered_record);
}

unsigned long long packed_layout_lowered_record_value_offset(void)
{
    struct packed_layout_lowered_record record;
    return (unsigned long long)((char *)&record.value - (char *)&record);
}

struct packed_layout_raised_record packed_layout_make_raised_record(char tag, int value)
{
    struct packed_layout_raised_record record;
    record.tag = tag;
    record.value = value;
    return record;
}

#if PACKED_LAYOUT_HOST_PASSES_UNDERALIGNED_IN_MEMORY
int packed_layout_lowered_middle(struct packed_layout_lowered_record record)
{
    return record.value;
}
#endif

void packed_layout_fill_raised_object(int value)
{
    packed_layout_raised_object = value;
}

unsigned long long packed_layout_const_record_size(void)
{
    return sizeof(struct packed_layout_const_record);
}

unsigned long long packed_layout_const_record_alignment(void)
{
    return _Alignof(struct packed_layout_const_record);
}

unsigned long long packed_layout_const_record_value_offset(void)
{
    struct packed_layout_const_record record = {0, 0};
    return (unsigned long long)((char *)&record.value - (char *)&record);
}

unsigned long long packed_layout_volatile_record_size(void)
{
    return sizeof(struct packed_layout_volatile_record);
}

unsigned long long packed_layout_volatile_record_value_offset(void)
{
    struct packed_layout_volatile_record record;
    return (unsigned long long)((char *)&record.value - (char *)&record);
}

// A const member is written by the initializer rather than by assignment, so
// the record is built where it is declared.
struct packed_layout_const_record packed_layout_make_const_record(char tag, int value)
{
    struct packed_layout_const_record record = {tag, value};
    return record;
}

#if PACKED_LAYOUT_HOST_PASSES_UNDERALIGNED_IN_MEMORY
int packed_layout_volatile_middle(struct packed_layout_volatile_record record)
{
    return record.value;
}
#endif
