// Compile provider and consumer separately, then exchange them with Clang/GCC.
// The reference answer is a scalar lane calculation with adjacent sentinels.
typedef unsigned int WideAbiVector __attribute__((vector_size(32)));
typedef union WideAbiStorage { WideAbiVector vector; unsigned int lanes[8]; } WideAbiStorage;

WideAbiVector wide_abi_make(unsigned int seed);
WideAbiVector wide_abi_mix(WideAbiVector first, unsigned int tag, WideAbiVector second);
WideAbiVector wide_abi_ninth(WideAbiVector, WideAbiVector, WideAbiVector, WideAbiVector,
                           WideAbiVector, WideAbiVector, WideAbiVector, WideAbiVector, WideAbiVector);

unsigned long long wide_abi_varargs(unsigned int marker, ...);

#if !defined(WIDE_ABI_CONSUMER_ONLY)
unsigned long long wide_abi_varargs(unsigned int marker, ...)
{
    __builtin_va_list cursor;
    __builtin_va_list copied;
    __builtin_va_start(cursor, marker);
    unsigned long long prefix = __builtin_va_arg(cursor, unsigned long long);
    __builtin_va_copy(copied, cursor);
    WideAbiStorage first = {.vector = __builtin_va_arg(cursor, WideAbiVector)};
    WideAbiStorage again = {.vector = __builtin_va_arg(copied, WideAbiVector)};
    WideAbiStorage second = {.vector = __builtin_va_arg(cursor, WideAbiVector)};
    unsigned long long tail = __builtin_va_arg(cursor, unsigned long long);
    unsigned long long result = marker + prefix + tail;
    for (unsigned int lane = 0; lane < 8; lane += 1)
    {
        result += first.lanes[lane] + second.lanes[lane] + again.lanes[lane];
    }
    __builtin_va_end(copied);
    __builtin_va_end(cursor);
    return result;
}

WideAbiVector wide_abi_make(unsigned int seed)
{
    WideAbiStorage result;
    for (unsigned int lane = 0; lane < 8; lane += 1) { result.lanes[lane] = seed + lane * 17u; }
    return result.vector;
}

WideAbiVector wide_abi_mix(WideAbiVector first, unsigned int tag, WideAbiVector second)
{
    WideAbiVector result = first + second;
    for (unsigned int lane = 0; lane < 8; lane += 1) { result[lane] ^= tag + lane; }
    return result;
}

WideAbiVector wide_abi_ninth(WideAbiVector a, WideAbiVector b, WideAbiVector c, WideAbiVector d,
    WideAbiVector e, WideAbiVector f, WideAbiVector g, WideAbiVector h, WideAbiVector i)
{
    return a + b + c + d + e + f + g + h + i;
}
#endif

#if !defined(WIDE_ABI_PROVIDER_ONLY)
int main(void)
{
    struct { unsigned int before[4]; WideAbiStorage value; unsigned int after[4]; } destination;
    WideAbiStorage first;
    WideAbiStorage second;
    for (unsigned int lane = 0; lane < 4; lane += 1)
    {
        destination.before[lane] = 0x51c0ffeeu + lane;
        destination.after[lane] = 0xdecaf00du + lane;
    }
    for (unsigned int lane = 0; lane < 8; lane += 1)
    {
        first.lanes[lane] = 10u + lane * 17u;
        second.lanes[lane] = 100u + lane * 23u;
    }
    int result = 0;
    destination.value.vector = wide_abi_make(10u);
    for (unsigned int lane = 0; lane < 8; lane += 1)
    {
        if (destination.value.lanes[lane] != first.lanes[lane]) { result = 1; }
    }
    WideAbiVector (*volatile indirect)(WideAbiVector, unsigned int, WideAbiVector) = wide_abi_mix;
    destination.value.vector = indirect(first.vector, 0x1234u, second.vector);
    for (unsigned int lane = 0; lane < 8; lane += 1)
    {
        if (destination.value.lanes[lane] != ((first.lanes[lane] + second.lanes[lane]) ^ (0x1234u + lane))) { result = 2; }
    }
    destination.value.vector = wide_abi_ninth(first.vector, second.vector, first.vector, second.vector,
        first.vector, second.vector, first.vector, second.vector, first.vector);
    for (unsigned int lane = 0; lane < 8; lane += 1)
    {
        if (destination.value.lanes[lane] != 5u * first.lanes[lane] + 4u * second.lanes[lane]) { result = 3; }
    }
    for (unsigned int lane = 0; lane < 4; lane += 1)
    {
        if (destination.before[lane] != 0x51c0ffeeu + lane || destination.after[lane] != 0xdecaf00du + lane) { result = 4; }
    }
    unsigned long long expected = 7u + 11u + 13u;
    for (unsigned int lane = 0; lane < 8; lane += 1) { expected += 2u * first.lanes[lane] + second.lanes[lane]; }
    if (wide_abi_varargs(7u, 11ull, first.vector, second.vector, 13ull) != expected) { result = 5; }
    return result;
}
#endif
