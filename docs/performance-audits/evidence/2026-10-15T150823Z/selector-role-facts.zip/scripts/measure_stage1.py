from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
repo = root / 'buster'
evidence = root / 'evidence'
subjects = root / 'subjects'
baseline = subjects / 'ide-baseline'
candidate = subjects / 'ide-roles'
source = evidence / 'frozen-unity.i'
runner = subjects / 'performance-evidence'

def run_comparison(name, tool, claim, left, right, arguments, pairs):
    command = ['taskset', '-c', '2', str(runner), 'compare', '--claim', claim,
               '--tool', tool, '--baseline', str(left), '--candidate', str(right),
               '--out', str(evidence / name), '--runs', str(pairs),
               '--min-effect-percent', '0.5']
    if tool == 'perf-stat':
        command += ['--events', 'instructions:u']
    command += ['--', *arguments]
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{name}: exit {result.returncode}; see log')
    print(name + ': ' + json.loads((evidence / name / 'summary.json').read_text())['result'], flush=True)

identities = []
for allocator in ['fast', 'quality']:
    output = evidence / ('frozen-output-' + allocator)
    arguments = ['cc', '-march=native', '-g', '-fregister-allocator=' + allocator,
                 str(source), '-lm', '-o', str(output)]
    for name, compiler in [('baseline', baseline), ('candidate', candidate)]:
        with (root / ('identity-' + allocator + '-' + name + '.log')).open('w') as log:
            subprocess.run(['taskset', '-c', '2', str(compiler), *arguments], cwd=repo,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        data = output.read_bytes()
        identities.append({'allocator': allocator, 'compiler': name, 'bytes': len(data),
                           'sha256': hashlib.sha256(data).hexdigest(), 'arguments': arguments})
    assert identities[-1]['sha256'] == identities[-2]['sha256'], identities[-2:]
    if allocator == 'fast':
        run_comparison('stage1-native-aa', 'time', 'native-runtime', baseline, baseline, arguments, 6)
    run_comparison('stage1-work-' + allocator, 'perf-stat', 'work-reduction', baseline, candidate, arguments, 6)
    run_comparison('stage1-native-' + allocator, 'time', 'native-runtime', baseline, candidate, arguments, 10)
(evidence / 'artifact-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
with (root / 'selection-controls.log').open('w') as log:
    subprocess.run(['python3', 'tools/selection_benchmark.py', '--compiler', str(baseline),
                    '--candidate', str(candidate), '--samples', '10', '--allocators', 'fast', 'quality',
                    '--check', '--cpu', '2', '--workloads', str(evidence / 'controls'),
                    '--output', str(evidence / 'selection-controls.json'),
                    '--build-description', 'Clang 23.1.1 tests-off Release same build/profile root'],
                   cwd=repo, stdout=log, stderr=subprocess.STDOUT, check=True)
print('stage-1 and selector controls complete', flush=True)
