from pathlib import Path
import json,hashlib,zipfile,shutil,statistics,subprocess,datetime
root=Path('.').resolve(); evidence=root.parent/'evidence'; work=root.parent
out=root/'docs/performance-audits/evidence/2026-10-13T163513Z'; out.mkdir(parents=True,exist_ok=True)
paths=[]
for prefix in ['major-confirm-fast8','major-confirm-quality8','major-scaling-fast1','major-scaling-fast2','major-scaling-fast4','major-scaling-fast16','major-scaling-quality1','major-scaling-quality2','major-scaling-quality4','major-scaling-quality16','major-small8','major-population-fast8','major-population-quality8','major-few-large8']:
 paths += [p for p in (evidence/prefix).rglob('*') if p.is_file()]
 paths += [evidence/(prefix+'.log')]
names=['major-measurement-plan.json','major-binaries.sha256','major-base.CMakeCache.txt','major-base.compile_commands.json','major-final.CMakeCache.txt','major-final.compile_commands.json','major-baseline-selfhost.log','major-final-selfhost.log','major-final-mode-matrix.log','major-test-all.log','major-focused-final.log','major-tsan-final.log','major-sanitize-final.log','major-single-generate.log','major-single-build.log','major-single-thread.json','major-source-size.log','major-markdown.log','major-evidence-tool-selftest.log','major-unity-identity.json','major-cross-functions.json','major-cross-functions-a64.json','major-function-census.json','major-function-census.log','major-functions.metrics','major-trace-proof.json','major-base-perf.data','major-base-perf.log','major-base-perf-report.txt','major-final-probes.log','major-secondary.log','major-gcc-syntax.log','major-gcc.compile_commands.json','major-few-census.log','major-small-census.log','major-final-pmu-base1.txt','major-final-pmu-final1.txt','major-final-pmu-final8.txt']
paths += [evidence/n for n in names]
paths += list(evidence.glob('major-trace[18].*'))
paths += [p for p in (work/'frozen/build/generated').rglob('*') if p.is_file()]
paths += [evidence/'frozen-manifest.json',work/'major_screen.py',work/'major_screen2.py',work/'major_secondary.py',work/'major_final_probes.py',work/'major_gcc_syntax.py',work/'package_major_evidence.py']
paths += [work/'frozen'/n for n in ['test-function-lanes160.c','test-function-lanes-a64.c','few-large-functions.c']]
# Keep a compact readable summary next to the complete byte-preserving archive.
summary={'schema':'buster-function-lanes-evidence-v1','baseline_revision':'de6eea9f7f0c97b221a9171fe159a85ec8c4b682','measured_source_revision':'14eae53800ad41b42a72c1c86ce33619679242b8','host':'AMD Ryzen 9 7940HS, Linux 7.2.9-2-cachyos, 16 logical CPUs','scope':'native-host elapsed time and resource evidence; no Zen 5 claim','cells':[]}
for p in sorted(evidence.glob('major-*/summary.json')):
 j=json.loads(p.read_text())
 if j.get('candidate',{}).get('revision')!=summary['measured_source_revision']: continue
 entry={'name':p.parent.name,'complete':j['complete'],'runs':j['runs'],'warmup':j['warmup'],'result':j['result'],'baseline':j['baseline'],'candidate':j['candidate'],'arguments':j['arguments'],'metrics':[]}
 for m in j['metrics']:
  entry['metrics'].append({'name':m['name'],'baseline_median':statistics.median(m['baseline']),'candidate_median':statistics.median(m['candidate']),'relative_change':m['relative_change'],'verdict':m['verdict'],'sign_test_p':m.get('sign_test_p')})
 summary['cells'].append(entry)
production=subprocess.run(['git','ls-files','src','CMakeLists.txt','cmake','build.c','build.sh','build.ps1'],capture_output=True,text=True,check=True).stdout.splitlines()
summary['production_source_sha256']=hashlib.sha256(''.join(f'{hashlib.sha256((root/p).read_bytes()).hexdigest()}  {p}\n' for p in production if (root/p).is_file()).encode()).hexdigest()
summary['retained_local_subjects']=[str((work/'bin/ide-major-base').resolve()),str((work/'bin/ide-major-final').resolve())]
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
unique={str(p.resolve()):p.resolve() for p in paths}
manifest={}
with zipfile.ZipFile(out/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(unique.values()):
  if not p.is_file(): raise RuntimeError(f'missing evidence {p}')
  name=str(p.relative_to(work)); data=p.read_bytes(); manifest[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
 z.writestr('SHA256SUMS',''.join(f'{h}  {p}\n' for p,h in sorted(manifest.items())))
with zipfile.ZipFile(out/'raw-evidence.zip') as z:
 for p,h in manifest.items(): assert hashlib.sha256(z.read(p)).hexdigest()==h,p
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
(out/'README.md').write_text('''# Retained function-lane evidence

`summary.json` contains readable paired results and source/binary identities.
`raw-evidence.zip` retains every raw observation and selected final validation
log without changing their bytes, plus frozen generated workloads, acquisition
scripts, CFG/function-size census, sampling profile and bootstrap traces.
Its internal `SHA256SUMS` pins each member, including empty output streams;
the external manifest pins the archive and summary. Both manifests were checked
against the retained bytes. The archive groups many empty/raw files for review
and transfer; it does not replace or alter their contents.

The trusted compiler binaries remain in the task's local `work/bin` and are
identified by their hashes and build commands; they are not published binaries.
The frozen full compiler input is identified by `frozen-manifest.json` and the
4cc005528 source revision. Generated stress inputs are included in the archive.
Linux native-runtime evidence does not establish Zen 5 performance, native
Windows/macOS runtime behavior, or issue #54's target-host acceptance.

Buster's first-party license remains unselected; see
[LICENSES/README.md](../../../../LICENSES/README.md). No external source was
imported by this implementation.
''')
# Include README in the outer binding as well.
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('archive',out/'raw-evidence.zip','files',len(manifest),'bytes',(out/'raw-evidence.zip').stat().st_size)
print('source_binding',summary['production_source_sha256'])
