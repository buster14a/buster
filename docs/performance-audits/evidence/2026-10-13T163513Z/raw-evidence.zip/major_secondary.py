import subprocess,json,statistics
from pathlib import Path
base=['../bin/performance-evidence-major','compare','--claim','native-runtime','--tool','time','--baseline','../bin/ide-major-base','--candidate','../bin/ide-major-final','--baseline-revision','de6eea9f7f0c97b221a9171fe159a85ec8c4b682','--candidate-revision','14eae53800ad41b42a72c1c86ce33619679242b8','--min-effect-percent','3']
common=['-Isrc','-Ibuild/generated','-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0','-g','src/buster/apps/ide/ide.c','-lm','-o','../evidence/major-timing-output']
cells=[]
for mode in ['fast','quality']:
 for jobs in [1,2,4,16]:
  cells.append((f'scaling-{mode}{jobs}',10,1,['cc',f'-fcompile-jobs={jobs}',f'-fregister-allocator={mode}']+common))
cells.append(('small8',20,2,['cc','-fcompile-jobs=8','-g','tests/basic_c_call_abi.c','-o','../evidence/major-timing-output']))
for mode in ['fast','quality']:
 cells.append((f'population-{mode}8',20,2,['cc','-fcompile-jobs=8',f'-fregister-allocator={mode}','-nostdinc','-g','-c','test-function-lanes160.c','-o','../evidence/major-timing-output']))
for name,runs,warmup,args in cells:
 out=Path('../evidence/major-'+name)
 cmd=base+['--runs',str(runs),'--warmup',str(warmup),'--out',str(out),'--']+args
 with out.with_suffix('.log').open('w') as f: p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 j=json.loads((out/'summary.json').read_text())
 wall=next(m for m in j['metrics'] if m['name']=='wall_seconds')
 print(name,p.returncode,j['complete'],j['result'], 'medians',statistics.median(wall['baseline']),statistics.median(wall['candidate']),flush=True)
 if not j['complete']: raise SystemExit(1)
