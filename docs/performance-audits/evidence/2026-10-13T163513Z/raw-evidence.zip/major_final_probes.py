import subprocess,hashlib,json,statistics
from pathlib import Path
args=['-Isrc','-Ibuild/generated','-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0','-g','src/buster/apps/ide/ide.c','-lm','-o','../evidence/major-proof-output']
rows=[]
for mode in ['fast','quality']:
 for name,jobs in [('base',1)]+[('final',j) for j in [1,2,4,8,16]]:
  p=subprocess.run(['../bin/ide-major-'+name,'cc',f'-fregister-allocator={mode}',f'-fcompile-jobs={jobs}']+args,capture_output=True)
  h=hashlib.sha256(Path('../evidence/major-proof-output').read_bytes()).hexdigest() if not p.returncode else ''
  rows.append({'mode':mode,'binary':name,'jobs':jobs,'exit':p.returncode,'sha256':h,'stderr':p.stderr.decode()})
 print('unity identity',mode,'all_success',all(r['exit']==0 for r in rows if r['mode']==mode),'all_identical',len(set(r['sha256'] for r in rows if r['mode']==mode))==1,flush=True)
Path('../evidence/major-unity-identity.json').write_text(json.dumps(rows,indent=2)+'\n')
cmd=['../bin/ide-major-base','cc','-v','-fmetrics-out=../evidence/major-functions.metrics','-fmetrics-functions']+args
with Path('../evidence/major-function-census.log').open('w') as f: subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
records=[]
for line in Path('../evidence/major-functions.metrics').read_text().splitlines():
 if line.startswith('CC_METRICS_FUNCTION '):
  d=dict(word.split('=',1) for word in line.split()[1:]);records.append({'name':bytes.fromhex(d['name_hex']).decode(),'code_bytes':int(d['code_bytes'])})
sizes=sorted(r['code_bytes'] for r in records)
census={'functions':len(sizes),'total_function_code_bytes':sum(sizes),'median':statistics.median(sizes),'p90':sizes[int(len(sizes)*.90)],'p99':sizes[int(len(sizes)*.99)],'maximum':max(sizes),'top20':sorted(records,key=lambda r:r['code_bytes'],reverse=True)[:20],'note':'machine-code size is a work-skew proxy, not per-function duration'}
Path('../evidence/major-function-census.json').write_text(json.dumps(census,indent=2)+'\n');print('census',census,flush=True)
# Tracing deliberately clamps to one function lane, preserving every trace byte.
traces=[]
for jobs in [1,8]:
 prefix='../evidence/major-trace'+str(jobs)
 p=subprocess.run(['../bin/ide-major-final','cc','-nostdinc','-g','-v',f'-fcompile-jobs={jobs}','-fbootstrap-trace='+prefix,'-c','test-function-lanes160.c','-o','../evidence/major-proof-output'],capture_output=True)
 files={p.suffix:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('../evidence').glob('major-trace'+str(jobs)+'.*')}
 traces.append({'jobs':jobs,'exit':p.returncode,'hashes':files,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
Path('../evidence/major-trace-proof.json').write_text(json.dumps(traces,indent=2)+'\n');print('traces',[(r['jobs'],r['exit'],r['hashes']) for r in traces],flush=True)
