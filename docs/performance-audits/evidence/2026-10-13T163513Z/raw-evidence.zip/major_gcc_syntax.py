import json,subprocess,shlex
from pathlib import Path
commands=json.loads(Path('build/gcc/compile_commands.json').read_text()); seen=set()
for item in commands:
 if not any(item['file'].endswith(x) for x in ['/codegen/codegen.c','/codegen/machine.c','/driver/driver.c','/apps/ide/ide.c']): continue
 if item['file'] in seen: continue
 seen.add(item['file']); argv=shlex.split(item['command']);out=[];skip=False
 for arg in argv:
  if skip: skip=False;continue
  if arg=='-o': skip=True;continue
  if arg=='-c':continue
  out.append(arg)
 print('command:',shlex.join(out+['-fsyntax-only']),flush=True)
 p=subprocess.run(out+['-fsyntax-only'],cwd=item['directory'],capture_output=True,text=True)
 print('file:',item['file'],'exit:',p.returncode,flush=True);print(p.stdout+p.stderr,flush=True)
 if p.returncode: raise SystemExit(p.returncode)
assert len(seen)==4,len(seen)
print('GCC_NONUNITY_SYNTAX status=pass files=4')
