#undef FN
#define FN(name) name##_0
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_1
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_2
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_3
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_4
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_5
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_6
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_7
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_8
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_9
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_10
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_11
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_12
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_13
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_14
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_15
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_16
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_17
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_18
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_19
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_20
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_21
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_22
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_23
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_24
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_25
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_26
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_27
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_28
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_29
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_30
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_31
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_32
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_33
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_34
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_35
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_36
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_37
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_38
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_39
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_40
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_41
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_42
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_43
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_44
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_45
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_46
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_47
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_48
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_49
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_50
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_51
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_52
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_53
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_54
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_55
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_56
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_57
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_58
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_59
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_60
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_61
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_62
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_63
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_64
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_65
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_66
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_67
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_68
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_69
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_70
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_71
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_72
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_73
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_74
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_75
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_76
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_77
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_78
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_79
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_80
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_81
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_82
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_83
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_84
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_85
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_86
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_87
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_88
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_89
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_90
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_91
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_92
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_93
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_94
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_95
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_96
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_97
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_98
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_99
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_100
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_101
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_102
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_103
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_104
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_105
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_106
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_107
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_108
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_109
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_110
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_111
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_112
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_113
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_114
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_115
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_116
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_117
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_118
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_119
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_120
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_121
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_122
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_123
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_124
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_125
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_126
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##_127
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_0
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_1
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_2
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_3
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_4
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_5
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_6
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_7
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_8
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_9
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_10
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_11
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_12
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_13
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_14
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_15
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_16
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_17
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_18
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_19
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_20
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_21
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_22
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_23
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_24
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_25
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_26
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_27
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_28
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_29
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_30
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_31
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_32
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_33
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_34
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_35
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_36
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_37
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_38
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_39
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_40
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_41
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_42
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_43
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_44
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_45
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_46
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_47
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_48
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_49
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_50
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_51
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_52
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_53
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_54
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_55
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_56
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_57
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_58
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_59
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_60
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_61
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_62
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_63
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_64
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_65
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_66
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_67
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_68
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_69
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_70
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_71
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_72
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_73
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_74
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_75
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_76
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_77
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_78
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_79
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_80
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_81
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_82
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_83
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_84
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_85
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_86
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_87
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_88
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_89
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_90
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_91
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_92
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_93
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_94
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_95
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_96
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_97
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_98
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_99
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_100
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_101
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_102
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_103
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_104
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_105
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_106
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_107
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_108
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_109
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_110
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_111
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_112
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_113
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_114
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_115
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_116
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_117
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_118
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_119
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_120
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_121
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_122
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_123
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_124
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_125
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_126
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
#undef FN
#define FN(name) name##extra_127
typedef long long i64;
typedef unsigned long long u64;
long double FN(ld_mix)(long double a, long double b) { return a * b + a / b - (a < b ? a : -b); }
int FN(ld_compare)(long double a, long double b) { return (a < b) + (a == b) * 2 + (a >= b) * 4; }
i64 FN(ld_to_integer)(long double a) { return (i64)a; }
long double FN(integer_to_ld)(i64 a) { return (long double)a; }
u64 FN(unsigned_divide)(u64 a, u64 b) { return a / b + a % b; }
int FN(signed_divide)(int a, int b) { return a / b + a % b; }
int FN(fetch_nand)(int* p, int v) { return __atomic_fetch_nand(p, v, __ATOMIC_SEQ_CST); }
i64 FN(compare_exchange)(i64* p, i64 e, i64 d)
{ __atomic_compare_exchange_n(p, &e, d, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); return e; }
float FN(integer_to_float)(int x) { return (float)x; }
double FN(unsigned_to_double)(u64 x) { return (double)x; }
int FN(double_less)(double a, double b) { return a < b; }
unsigned char FN(nonzero)(unsigned x) { return (unsigned char)(x != 0); }
struct FN(fields) { char c; short s; int i; i64 l; char pad[300]; i64 far; };
i64 FN(copy_fields)(struct FN(fields)* from, struct FN(fields)* to)
{ to->c = from->c; to->s = from->s; to->i = from->i; to->far = from->l + from->far; return to->l + from->c; }
int FN(scaled_sum)(int* v, int n) { int s = 0; for (int i = 0; i < n; i += 1) s += v[i] * (i + 3) - (v[i] >> 2); return s; }
int FN(asm_add)(int a, int b) { __asm__("addl %1, %0" : "+r"(a) : "r"(b)); return a; }
u64 FN(rotate)(u64 x, int k) { return (x << (k & 63)) | (x >> ((64 - k) & 63)); }
int FN(caller)(int* p) { return FN(signed_divide)(*p, 3) + FN(asm_add)(*p, 7); }
