import subprocess,time,json,hashlib
from pathlib import Path
rows=[]
args=['cc','-Isrc','-Ibuild/generated','-DBUSTER_UNITY_BUILD=1','-DBUSTER_INCLUDE_TESTS=0','-g','src/buster/apps/ide/ide.c','-lm','-o','../evidence/major-screen-self']
for repetition in range(3):
    cells=[('base',1),('prototype',1),('prototype',4),('prototype',8)]
    if repetition%2: cells.reverse()
    for binary,jobs in cells:
        exe='../bin/ide-major-'+binary
        cmd=[exe,'cc',f'-fcompile-jobs={jobs}']+args[1:]
        start=time.perf_counter(); run=subprocess.run(cmd,capture_output=True); seconds=time.perf_counter()-start
        out=Path('../evidence/major-screen-self')
        row={'binary':binary,'jobs':jobs,'repetition':repetition,'seconds':seconds,'returncode':run.returncode,'sha256':hashlib.sha256(out.read_bytes()).hexdigest() if run.returncode==0 else '', 'error':run.stderr.decode()[-1000:]}
        rows.append(row); print(json.dumps(row),flush=True)
Path('../evidence/major-prototype-screen.json').write_text(json.dumps(rows,indent=2)+'\n')
