int a[-1];
