/* Independent A64 ADD/SUB (extended register) audit fixture.
 * This does not contain, include, or execute Buster's encoder.
 * Oracle: Arm ADD/ADDS/SUB/SUBS (extended register), field diagram and
 * Assembler Symbols. Generate text for an external assembler; then verify
 * its extracted .text against independently written field arithmetic.
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *const names[4] = {"add", "adds", "sub", "subs"};
static const char *const extensions[8] = {
    "uxtb", "uxth", "uxtw", "uxtx", "sxtb", "sxth", "sxtw", "sxtx"
};
static const unsigned registers[3][3] = {{0, 1, 2}, {30, 31, 31}, {31, 30, 0}};

static void register_name(char output[16], unsigned width, unsigned index, int sp)
{
    if (index == 31)
    {
        snprintf(output, 16, "%s", sp ? (width == 64 ? "sp" : "wsp") :
                                       (width == 64 ? "xzr" : "wzr"));
    }
    else
    {
        snprintf(output, 16, "%c%u", width == 64 ? 'x' : 'w', index);
    }
}

int main(int argc, char **argv)
{
    int status = EXIT_FAILURE;
    FILE *input = NULL;
    unsigned cases = 0;
    unsigned mismatches = 0;
    unsigned source_rejection_predictions = 0;
    int generate = argc == 2 && strcmp(argv[1], "generate") == 0;
    int verify = argc == 3 && strcmp(argv[1], "verify") == 0;
    if (verify)
    {
        input = fopen(argv[2], "rb");
    }
    if (generate || (verify && input))
    {
        if (generate) puts(".text");
        for (unsigned sf = 0; sf < 2; sf += 1)
        {
            for (unsigned op = 0; op < 4; op += 1)
            {
                for (unsigned option = 0; option < 8; option += 1)
                {
                    for (unsigned amount = 0; amount < 5; amount += 1)
                    {
                        for (unsigned r = 0; r < 3; r += 1)
                        {
                            unsigned width = sf ? 64u : 32u;
                            unsigned source_width = sf && (option == 3 || option == 7) ? 64u : 32u;
                            unsigned rd = registers[r][0], rn = registers[r][1], rm = registers[r][2];
                            uint32_t expected = UINT32_C(0x0b200000) | (sf << 31) |
                                ((op >> 1) << 30) | ((op & 1) << 29) | (rm << 16) |
                                (option << 13) | (amount << 10) | (rn << 5) | rd;
                            char d[16], n[16], m[16];
                            register_name(d, width, rd, !(op & 1));
                            register_name(n, width, rn, 1);
                            register_name(m, source_width, rm, 0);
                            if (generate)
                            {
                                printf("%s %s, %s, %s, %s #%u // case %u, expected 0x%08x\n",
                                       names[op], d, n, m, extensions[option], amount, cases, expected);
                            }
                            else
                            {
                                unsigned char bytes[4] = {0};
                                size_t got = fread(bytes, 1, 4, input);
                                uint32_t actual = (uint32_t)bytes[0] | ((uint32_t)bytes[1] << 8) |
                                    ((uint32_t)bytes[2] << 16) | ((uint32_t)bytes[3] << 24);
                                if (got != 4 || actual != expected)
                                {
                                    fprintf(stderr, "case %u: got %zu bytes, word %08x, expected %08x\n",
                                            cases, got, actual, expected);
                                    mismatches += 1;
                                }
                            }
                            source_rejection_predictions += !sf && (option == 3 || option == 7);
                            cases += 1;
                        }
                    }
                }
            }
        }
        if (verify && (fgetc(input) != EOF || ferror(input))) mismatches += 1;
        if (generate && ferror(stdout)) mismatches += 1;
        if (verify)
        {
            printf("external_assembler_words=%u mismatches=%u\n", cases, mismatches);
            printf("source_only_predicted_Buster_rejections=%u (NOT a Buster execution result)\n",
                   source_rejection_predictions);
        }
        status = mismatches ? EXIT_FAILURE : EXIT_SUCCESS;
    }
    else
    {
        fprintf(stderr, "usage: %s generate | verify TEXT.bin\n", argv[0]);
    }
    if (input && fclose(input)) status = EXIT_FAILURE;
    return status;
}
