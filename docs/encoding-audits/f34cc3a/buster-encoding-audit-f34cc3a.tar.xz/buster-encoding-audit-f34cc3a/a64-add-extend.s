.text
add w0, w1, w2, uxtx
add w0, w1, w2, sxtx
adds w0, w1, w2, uxtx #4
sub w0, w1, w2, sxtx #4
add x0, x1, x2, uxtx
add x0, x1, w2, uxtw
