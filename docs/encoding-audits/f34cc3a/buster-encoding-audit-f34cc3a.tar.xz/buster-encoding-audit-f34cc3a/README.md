# Encoding audit evidence package

Start with REPORT.md. The finding is recorded in buster14a/buster issue #2625.

Pinned Buster commit: f34cc3a56296be1b1244647775e1a40a67dae3ef.

IMPORTANT: the existing Buster C harness was not compiled or run. The candidate
patch is untested against Buster and has not been committed or merged.
Only the standalone external reference checks were executed on the cloud host.

Contents:
- REPORT.md: findings, exact source/specification references, constraints,
  measurements, limitations, reproduction, and licensing notes.
- coverage.json: machine-readable distinction between executed, source-derived,
  authored-but-unrun, catalog populations, and unverified work.
- candidate-fix-and-regression.patch: candidate modifications to two existing C files.
- buster_extension_regression.c: 162-line insertion block for the existing test body;
  not a standalone translation unit.
- extension_oracle.c: independent 960-case reference generator and word checker.
- extension_negative_oracle.c: independent negative reference driver.
- *.s: generated reference assembly inputs.
- *.disassembly.txt: captured external decoder output.
- extension-*-result.txt: captured results, including the negative-driver discrepancy.
- extension-negative-cases.tsv and extension-negative-diagnostics.txt: all negative outcomes.
- source-excerpts.txt: exact pinned source excerpts relevant to the patch.
- tool-versions.txt: captured toolchain and host identification.
- patch-syntax-check.txt: git apply --numstat, NOT an application/build/test check.
- SHA256SUMS: content hashes for the other files in this package.

The negative reference driver returned exit status 1: 252 of 256 cases were
rejected, not the expected 256. The four accepted width spellings are documented
in the report and must not be silently counted as Buster failures.

No executables, object files, Arm XML, fonts, vendor implementation, or new Buster
dependency are included.
