/* Independent external-assembler negative controls; no Buster code. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

static const char *const names[4] = {"add", "adds", "sub", "subs"};
static const char *const extensions[8] = {
    "uxtb", "uxth", "uxtw", "uxtx", "sxtb", "sxth", "sxtw", "sxtx"
};

int main(void)
{
    int status = EXIT_FAILURE;
    unsigned cases = 0, rejected = 0, infrastructure_errors = 0;
    FILE *log = fopen("extension-negative-cases.tsv", "w");
    FILE *raw = fopen("extension-reserved.s", "w");
    if (log && raw)
    {
        fputs("case\tkind\texit_code\tinstruction\n", log);
        fputs(".text\n", raw);
        for (unsigned family = 0; family < 2; family += 1)
        {
            for (unsigned sf = 0; sf < 2; sf += 1)
            {
                for (unsigned op = 0; op < 4; op += 1)
                {
                    for (unsigned option = 0; option < 8; option += 1)
                    {
                        unsigned limit = family == 0 ? 1u : 3u;
                        for (unsigned a = 0; a < limit; a += 1)
                        {
                            unsigned amount = family == 0 ? 0u : a + 5u;
                            unsigned source_x = sf && (option == 3 || option == 7);
                            if (family == 0) source_x = !source_x;
                            char instruction[160];
                            snprintf(instruction, sizeof(instruction), "%s %c0, %c1, %c2, %s #%u",
                                     names[op], sf ? 'x' : 'w', sf ? 'x' : 'w',
                                     source_x ? 'x' : 'w', extensions[option], amount);
                            FILE *input = fopen("extension-negative-input.s", "w");
                            if (input)
                            {
                                fprintf(input, ".text\n%s\n", instruction);
                                int io_ok = !ferror(input);
                                io_ok &= fclose(input) == 0;
                                int child_status = 0;
                                pid_t child = io_ok ? fork() : (pid_t)-1;
                                if (child == 0)
                                {
                                    int fd = open("extension-negative-diagnostics.txt", O_WRONLY | O_CREAT | O_APPEND, 0600);
                                    if (fd < 0 || dup2(fd, STDERR_FILENO) < 0) _exit(126);
                                    close(fd);
                                    execlp("clang", "clang", "--target=aarch64-unknown-linux-gnu", "-c",
                                           "extension-negative-input.s", "-o", "extension-negative-input.o", (char *)NULL);
                                    _exit(127);
                                }
                                pid_t waited = child > 0 ? waitpid(child, &child_status, 0) : (pid_t)-1;
                                int exit_code = waited == child && child > 0 && WIFEXITED(child_status) ?
                                                WEXITSTATUS(child_status) : -1;
                                rejected += exit_code == 1;
                                infrastructure_errors += exit_code != 0 && exit_code != 1;
                                fprintf(log, "%u\t%s\t%d\t%s\n", cases,
                                        family == 0 ? "wrong_source_width" : "reserved_imm3", exit_code, instruction);
                            }
                            else infrastructure_errors += 1;
                            if (family == 1)
                            {
                                uint32_t word = UINT32_C(0x0b200000) | (sf << 31) | ((op >> 1) << 30) |
                                                ((op & 1) << 29) | (2u << 16) | (option << 13) | (amount << 10) | (1u << 5);
                                fprintf(raw, ".inst 0x%08x // reserved imm3, case %u\n", word, cases);
                            }
                            cases += 1;
                        }
                    }
                }
            }
        }
        printf("external_assembler_negative_cases=%u rejected=%u infrastructure_errors=%u\n",
               cases, rejected, infrastructure_errors);
        status = cases == 256 && rejected == cases && !infrastructure_errors && !ferror(log) && !ferror(raw) ?
                 EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (log && fclose(log)) status = EXIT_FAILURE;
    if (raw && fclose(raw)) status = EXIT_FAILURE;
    return status;
}
