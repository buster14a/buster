.text
adds x0, x1, w2, uxtx #0
adds x0, x1, w2, sxtx #0
subs x0, x1, w2, uxtx #0
subs x0, x1, w2, sxtx #0
