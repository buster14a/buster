Buster vs Cuik comparison, 29 September 2026

Open Buster-vs-Cuik-comparison.html for the full report.
measurement-evidence/ contains shared inputs, independent validators, raw timing samples, summaries, compiler/source hashes, dependency identities, build commands/logs and disassembly.
Executable binaries and .o files are omitted. The capture scripts expect the original relative layout; rebuild both pinned compilers and link the supplied validators before adapting/running them.
The three source-review notes are intermediate research. Where their pre-measurement caveats differ from the final report, the final report and measurement records are authoritative.
Measurements are diagnostic EPYC cloud observations, not a Zen5 or general compiler-performance certification.

Workspace paths in delivered records are redacted to CAPTURE_ROOT. Delivered reproduction-source identities are recorded separately from capture identities.
