# Buster vs Cuik measurement notes

Pins: Buster `e642c1e32e40568c168d36b0f281c76e4c939139`; Cuik `a7677f74e5391dcc7fdedad61468f4f207c9998f`.

Host: AMD EPYC 9V74 cloud KVM VM with 9 exposed logical CPUs. This is not a Ryzen 9700X or Zen5 measurement, not the user's desktop, not dedicated-host admission. Raw paired observations are diagnostic; no confidence interval or statistically admitted universal speedup is asserted.

Both baseline source trees remained clean, no source patches. Read Buster AGENTS, docs/agents/build.md, docs/agents/benchmarking.md, newest audit2026-09-29T184335Z before build. Buster built with Clang20.1.2 as trusted compiler producer, with Clang-built build.c using documented hosted bootstrap exception (not canonical TCC-bootstrap acceptance). Its normal Release build retains tests, debug information in the compiler executable, O3 and march=native. Cuik built with same Clang20 producer, its own default O2/march=haswell flags, debug information in compiler binary, exact pinned submodules. This is a comparison of supported/default project compiler builds, not equal producer-flag binaries. There were no overlapping owned builds during timing capture. Binary/source hashes, dependencies and complete generated build commands accompany evidence.

Buster config/commands from buster root:
`clang-20 -Isrc -Wall -Werror -Wno-unused-function -Wno-unused-variable -g build.c -o ../measurement-bin/buster-build`
`../measurement-bin/buster-build generate --build-directory=CAPTURE_ROOT/buster-measurement-build --cc clang --linker lld`
`../measurement-bin/buster-build build --build-directory=CAPTURE_ROOT/buster-measurement-build --config Release -t ide`
PATH alias clang points to /usr/bin/clang-20, lld points to locally extracted LLD20. Cuik command from cuik root:
`luajit build.lua -driver -x64`
Lua5.4 failed generator global unpack; Lua5.1 would fail lexgen LuaJIT integer literals. Final successful LuaJIT build is unmodified source. Locally extracted packages and pinned git submodules only; no system package installation.

Generated target for both is x86-64 Linux SystemV. Buster explicit `-march=baseline`, no x86 target features beyond SSE2. Cuik target `x64_linux_gnu`; these fixtures use baseline integer instructions only. Both debug outputs disabled: Buster-g0, Cuik omits-g. Compile-only-c object emission, one thread Cuik-j1, Buster-c serial by documented driver policy. Buster FAST and QUALITY-O2 with-fno-machine-fallback, Cuik boolean optimizer-O. These optimization policies do different work; comparison is time to each valid artifact, not equal optimizer work.

Method: one warmup per mode/source then11 retained samples, mode order alternates forward/reverse each cycle; wall time Python perf_counter_ns brackets child creation plus process completion; RSS wait4 child ru_maxrss in KiB. Every sample and full command retained. No cold-cache/production-PGO measurement. No links within compile timings. 450-byte probe file has4 functions (3 public plus static helper);192679-byte synthetic file has1024 distinct functions containing unsigned arithmetic/branch/rotate, no system headers. Probes heavily reflect startup overhead; synthetic is not representative application preprocessing or self-host corpus.

Correctness gate: host Clang20 independent reference harness validates division boundaries and10000 pseudorandom unsigned inputs, helper loops on10000 inputs, sums for all lengths0..257. Separate host harness tests all1024 synthetic functions across50 inputs each,51200 checks. Buster FAST/QUALITY and Cuik optimized pass. Cuik unoptimized fails fn_0/input0 with-O0 reference harness; optimized reference harness itself has caller-variable corruption. Disassembly writes+8/+16(%rsp) without frame allocation at function entry on SysV; never include its timings in valid performance verdicts. These tests cannot prove general language/ABI correctness.

Results versus Buster FAST (medians of11, see compile-summary.json):
* Small probes: Cuik12.710ms vs Buster15.877ms; Cuik19.94% lower process time,1.249x speed,42.31% lower peak RSS. QUALITY15.453ms.
*1024 synthetic functions: Buster52.580ms vs Cuik104.966ms; Buster49.91% lower time,1.996x speed,11.62% lower peak RSS (48020 vs54336KiB). QUALITY54.553ms.
* Synthetic text: Buster344053 vs Cuik65472 bytes; Cuik80.97% smaller,5.255x size ratio. Both Buster modes same size.
* Probe text: FAST600, QUALITY570, Cuik144 bytes; Cuik76.00% smaller thanFAST/74.74% smaller thanQUALITY. Text is compared, not total object bytes, because section/layout policies differ. Total object bytes available as secondary data.

Runtime microprobe: common external Clang20-O2 harness calls divide10 twenty million times on LCG-generated unsigned inputs; generated function stays external so no harness inlining. Timing measured inside harness around loop only with clock_gettime CLOCK_MONOTONIC; eleven retained samples after warmup, alternating order; checksums identical and full correctness gate outside measured interval. FAST51.661ms, QUALITY50.947ms, Cuik33.833ms; Cuik34.51% lower than FAST,1.527x speed. This prices full divide-call microkernel including LCG/call overhead/prologues; do not attribute whole gap exclusively to division strength reduction. Cuik emits magic-number mulhi/shift, Buster hardwareDIV; Cuik inlines static helper, Buster retains call. Inspect exact disassembly.

Both generated ELF object types lack .note.GNU-stack: host GNU ld warns and produces executable GNU_STACK for ordinary linking. This is a shared weakness, not a winner; use explicit link-znoexecstack for controlled deployment if appropriate and repair ELF note emission upstream.

Not run: actual application corpus, libc/system-header conformance, self-host fixed point, full regression suites, target runtime other than Linuxx86,9700X measurements, coldstart, parallel scalability, counters, hosted CI. No claim that one compiler is generally faster/more correct follows from these microtests. Baseline defects cannot be turned into a runtime win.
