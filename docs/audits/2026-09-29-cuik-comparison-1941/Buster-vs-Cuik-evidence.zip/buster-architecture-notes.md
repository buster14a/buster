# Current Buster architecture, feature and evidence notes for Cuik comparison

Inspected exact commit `e642c1e32e40568c168d36b0f281c76e4c939139` in `CAPTURE_ROOT/buster`. Read-only inspection, no builds or benchmarks started by this agent. Claims below describe source implementation and committed contracts, not fresh execution success or measured speed.

## Scope correction

Buster is currently a **C compiler**, not an active custom-language compiler. C is sole active frontend; former `.bbb` language/editor/interpreter removed, corpus dormant. `ide` is a headless compiler/test/bench/metadata application. Buster monorepo also contains independent shared/platform/graphics/application components. Compare compiler subtrees, not whole repository, for implementation size.

Sources:
- [project map lines 16–43](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/project.md#L16-L43)
- [README](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/README.md)
- [compiler catalogue](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/projects/compiler.md)

## Source-language support

Driver accepts GNU89/GNU90, GNU99/GNU9x, GNU11, GNU17/GNU18, GNU23/GNU2x and strict c99/c9x/iso9899:1999, c11, c17/c18, c23/c2x spellings. Default GNU17. These options and tests do not establish complete standard conformance. C89/C90 strict spellings absent from the dialect setter.

Current semantic implementation includes C11 `_Generic`, atomics, TLS, VLA and GNU extended asm/computed labels/statement expressions/attributes/range designators/vectors; fixed-width Microsoft integer suffixes; C23 token normalization, `constexpr`, auto type inference, `typeof_unqual`, `nullptr`, fixed-base/large enums. Current implementations include `_Float16`, real and complex float/double/long double, 128-bit integers and platform layouts. Complex integer and `_Imaginary` deliberately unsupported; C23 bit-precise integer suffixes are not added by ordinary integer parsing. Runtime float-to-i128 x86-64 still unsupported. Do not advertise full C23 implementation or quantify percentage of C conformance without a standard feature suite.

Sources:
- [driver dialect setter lines 105–174](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/driver/driver.c#L105-L174)
- [C23 declaration keywords](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/frontend/c/c_parse.c#L105-L135)
- [frontend foundations](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/frontend/foundations.md)
- [wide floats/assembly guide](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/frontend/wide-floats-assembly.md)

Cuik README claims C11 frontend. Buster wins **implemented dialect breadth** over that documented contract, but neither source inventory proves fewer bugs or greater C11 conformance. A fair conformance comparison must feed identical well-defined C11 files under each compiler's actual supported target/data model.

## Frontend and representations

Explicit stages source load/translation/lex/preprocess -> declaration syntax and semantic model -> canonical IR. `c_parse_ast` name is historical: header comment in c_parse.c explicitly says it builds no tree, records declarations and assertion/body token ranges, later consumers re-walk indexed token ranges. CTypeParseMachine uses explicit frames, avoiding input-dependent recursion. Semantic model retains types/entities/scopes/identifier uses and indexes.

`CToken` = **12 bytes**, offset + symbol + u16 length + u8 kind + u8 punctuator. Optional 1-byte CTokenShape sidecar for hot parse classification. Spelling/locations recovered lazily; identifier identity established in preprocessing and preserved through later stages. C lexing has AVX-512 64-byte mask/compaction path using VBMI/VBMI2 and scalar/SWAR fallbacks. Translating ordinary bytes and finding literals/comments also SIMD paths. These prove mechanism, not speed advantage over Cuik.

Canonical IrValue = **16 bytes**, IrInstruction = **64 bytes** on 64-bit host; rare instruction payloads and source ranges side tables. IrInstruction still has three operand/target/immediate pointers; arrays are flat, linked block/incoming construction is converted to published immutable CFG slices. Native MIR MachineInstruction = **24 bytes**, simple opcode projection **16 bytes**, general opcode metadata **96 bytes**. Exact row sizes are not directly equivalent to TB sea-of-nodes, which owns additional input/user/extra arrays and other semantics.

Default C lowerer directly constructs pruned block-argument SSA for eligible owners, with per-owner recovery to memory for escapes/uninitialized uses; memory-form frontend retained independent differential reference. Shared local promotion remains independent fallback. This is already implemented: don't recommend "add SSA" or "compact tokens" as if absent.

Sources:
- [c_parse.c orientation](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/frontend/c/c_parse.c#L1-L95)
- [CToken layout lines 108–160](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/frontend/c/c.h#L108-L160)
- [IR layouts lines 391–547](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/ir/ir.h#L391-L547)
- [direct SSA contract](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/frontend/foundations.md#L7-L169)
- [machine row/layout facts](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/machine.md#L5-L23)
- [SIMD design/implemented C lexer](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/simd.md)

## Middle end / generated-code tradeoff

Default bounded FAST pipeline: integer folding/identities, narrow cast elimination, conservative address identity cancellation, transitive DCE of classified pure instructions, at most four trivial-parameter sweeps, shared compaction. Does **not** provide floating/division/remainder folding, branch deletion, iterative global propagation. Loads (even nonvolatile), divisions, floats, calls, SIMD, atomics and traps remain observable/retained conservatively. No ordinary inliner, even `always_inline`; simd.h uses macro wrappers for this reason. Avoid saying -O2 selects a strong optimizer: native FAST register allocator used at **every -O level** including -O0. `quality` allocator explicitly selected separately.

Native backend pipeline canonical IR -> machine selection -> scheduling/placement -> encoding. Modes `none` direct canonical stack, `mir-stack`, `fast`, `quality`. Default FAST; QUALITY pressure-first scheduling/pinning and separate cost policy. Scheduler metadata is explicitly **not** a latency/hazard model. Current native backend still has per-function direct fallback for unimplemented MIR signature/opcode/unwind etc; `-fno-machine-fallback` makes rejection strict. Thus "all MIR-only retired" is false current state.

Possible Cuik/TB wins (verify with optimizer agent): stronger optimizer repertoire and inliner, with register allocation and target lowering tuned for generated quality. Concrete remedies for Buster: preserve speed default, add independent measured quality tiers, start with cheap call/integer/branch simplification on observed corpus, shared fact publication/use indexes rather than another IR; certify each mutation and benchmark total compile+RSS alongside runtime/text/frame sizes. User explicitly requested solutions, so discussing generated-code work is within request even AGENTS default priority is throughput.

Sources:
- [FAST contract and bounded pass list](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/canonical-fast-pipeline.md)
- [allocator modes/default/fallback lines 76–114](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/driver.md#L76-L114)
- [no inliner explanation](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/simd.md#L132-L148)
- [FAST allocator orientation](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/codegen/register_allocator_fast.c#L1-L42)

## Parallel compilation and startup

`-fcompile-jobs=N` uses persistent SPMD gang, private TU arenas and ordered publication; defaults **one worker**. Only consecutive native C inputs within a link invocation are batched. -c/-S/-E/syntax/LLVM/GPU/Wasm/eBPF paths and function compilation within each TU remain serial. Worker request clamped to logical CPU/input count and nested gang guard. No adaptive grain/dynamic claims/cgroup admission/physical memory estimation. Committed guide explicitly calls feature "not an accepted throughput improvement"; source structure alone cannot establish parallel speedup.

Serial prewarm of shared tables is required before gang creation. Full both-target/all-form prewarm is extra opt-in cost. Per-invocation x86 metadata decode on compile path remains a startup floor. Cuik driver DAG/TU/function task scheduling likely wins available concurrency and compiler-as-library scheduling flexibility, not measured scale factor.

Remedies: benchmark N=1/2/4/8 on qualified 9700X both equal tiny TUs and skewed real TUs; report throughput, peak RSS, cold startup, repeated in-process compilation, source-indexed stable diagnostic/object output. Extend -c concurrency if useful; add dynamic work claims for skewed pending cohorts only after ownership/lifetimes proven. Immutable target tables/offline generation or split minimal codegen tables from exhaustive assembler metadata could lower startup, but must measure binary size/page faults and preserve feature correctness. Function parallelization needs independent signature/source-cursor/inline-asm ownership, not just prewarming.

Sources:
- [TU lanes exact scope/default](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/driver.md#L27-L62)
- [persistent lane/prewarm and metadata floor](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/parallelism.md)

## Targets / object / linker / nonnative

Native implemented x86-64 and AArch64, ELF64/COFF/Mach-O with SysV/Windows/Darwin conventions and desktop/mobile host test paths; x86-64+AArch64 UEFI images. Hosted compiler CI six desktop OS/arch lanes + Android/iOS + independent UEFI boot lane. Don't equate each backend-enum target to executed full compatibility.

Own object readers/writers, own linker, own assembler and generic host-native object JIT. x86-64 Linux shared objects and PIE supported; AArch64 ELF shared, PE DLL, Mach-O dylib absent writer. GNU assembly directive subset, no branch relaxation: forward label branches choose near form. x86 exact metadata supports modern vectors/APX/XOP forms with feature checks; AArch64 semantic/encoding broad tables, target execution separate.

Direct Wasm64 Memory64 and wasm32 WASI Preview1, direct Linux eBPF with BTF, dependency-free binary LLVM bitcode emission. GPU SPIR-V/NVPTX/AMDGCN/Metal/DXIL is **external tool orchestration**, not own C-to-GPU backend; binary bitcode writer **does not run LLVM optimizers or codegen**. Wasm direct backend scalar subset: aggregate locals yes; aggregate function ABI, indirect calls/tables, atomics/TLS/SIMD, asm deliberately rejected. Bitcode own explicit ABI/opcode/varargs limits. These count as feature breadth, not production-ready parity.

Sources:
- [source map compiler modules](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/project.md#L69-L96)
- [shared+PIE current boundary](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/driver.md#L406-L449)
- [assembly unit directive/relaxation boundary](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/driver.md#L219-L274)
- [Wasm64](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/WASM64.md)
- [WASI](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/WASI.md)
- [LLVM bitcode boundaries](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/LLVM_BITCODE.md)

## Diagnostics / debug / reusable API

Buster public reusable phases `c_lex`, `c_preprocess`, `c_parse_ast`, `c_analyze_semantics_only`, `c_lower_to_ir` and complete public tokens/semantic model; codegen/object/link/JIT have their own public APIs. Not accurate to claim no library interface. Cuik packaging libCuik/libTB separately simpler than Buster modules in monorepo/headless ide.

`CPreprocessOptions` receives include-path arrays, source_path, initial String8, disable_external_includes; **no VFS callback/buffer provider in public interface**. Buster style bans compiler callbacks, so remedy use indexed immutable input-buffer/provider table and direct provider operations, not import callback-heavy style.

`CompilerDiagnostic` has stable codes, logical+original path/position, optional flat notes/backend context, retained ownership/order. Renderer only path:line:column severity+message lines; **no source excerpt/caret, fix-it edits or recursive macro expansion backtrace**. docs explicitly state no inferred expansion stacks or secondary locations. Cuik diagnostic.h/c code has fix-it hints, macro backtrace, source/caret/ranges and callback, so Cuik wins user-facing diagnostic richness; Buster wins structured backend refusal telemetry if Cuik lacks equivalent. No honest percentage for diagnostic quality; quantify available features instead (e.g. Cuik up to 3 fixits vs Buster 0 edit field).

Buster DWARF4 writer + external DWARF5 section reader/linker; CodeView/PDB writers and canonical debug model, final virtual-register/spill debug locations, unavailable rather than fabricated provenance. Dedicated debug/test suites exist. No active graphical IDE or discovered LSP. Generic JIT object loader supported x86-64/AArch64 hosts with explicit imports and executable page finalization; Apple MAP_JIT limitations documented.

Sources:
- [public frontend phases](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/frontend/c/c.h#L1492-L1577)
- [preprocess options without VFS](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/frontend/c/c.h#L472-L506)
- [shared diagnostic model](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/diagnostic.h)
- [actual terminal renderer lines 47–86](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/diagnostic.c#L47-L86)
- [diagnostics provenance/limits](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/diagnostics.md)
- [JIT API and host limits](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/src/buster/lib/compiler/jit/jit.h)
- [external DWARF reader+writer distinction](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/driver.md#L460-L480)

## Correctness and evidence discipline

Buster extensive registered C/module/IR/encoder/object/link/JIT/driver tests; ASan/UBSan/fuzz/multi-host compiler configurations, strict fallback controls, metamorphic/differential tests, cross-target execution-mode matrix **24 legs** = 4 allocators * 2 native architectures * 3 desktop formats; host-native execution else qemu/Wine else disassembly or downgraded object check. Strict curated driver corpus **396 objects** = 11 fixtures * 6 targets * 3 MIR allocators * 2 frontend forms, plus atomic/vector/etc independent cases. Object generation not target execution or full conformance.

Self-host gate compiles whole unity executable twice then byte-equal fixed point and stage2 benchmark, documented on Linux/Windows x86-64 and macOS. Stronger Linux x86-64 audit three generations with token/IR/MIR/diagnostic/binary evidence and all allocator modes. Existence of contract/test source is a Buster engineering/evidence win over unfinished Cuik only when Cuik inventory supports it; no fresh all-green claim without run logs.

13 compatibility harnesses (cJSON,zlib,Lua,yyjson,stb,LZ4,SQLite,sbase,DoomGeneric,QuickJS,musl,libc-test,CPython) with pinned pristine inputs; some historical documents stale. In particular CPython guide says no `-shared` while current driver has x86-64 shared/PIE. Historical QuickJS compile/runtime/frame figures are Buster-vs-Clang, old revision/hardware, **not Buster-vs-Cuik evidence**.

Sources:
- [tests and CI](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/testing.md)
- [self-host contract](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/build.md#L11-L50)
- [mode matrix contract](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/build.md#L245-L280)
- [strict 396-object floor and limitations](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/driver.md#L172-L205)
- [compatibility harness index](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/compatibility.md)

## Dependencies, build and licensing

Compiler/toolchain linked without LLVM, external GPU optional; C-only/no-new-dependencies policy. Build scripts bootstrap native **build.c using pinned TCC**, then CMake+Ninja; standard GitHub hosted driver Clang bootstrap exception. Clang/GCC/Zig/MSVC host build coverage. Compiler-native frontend may use installed resource/system headers; do not claim "no dependency at all".

First-party license **not selected**; README + THIRD_PARTY_NOTICES explicitly warn upstream notices not grant on Buster. Arm XML-derived metadata **unresolved redistribution review**. Cuik LICENSE permissive MIT if agent verified -> decisive reuse/distribution licensing win for Cuik. Remedy decide explicit first-party license and resolve/replace restricted metadata; this is observed project contract, not hypothetical unsolicited safety warning.

Build orchestration very large (build.c ~2MB at historical source-size baseline); compare source bytes exact pinned revision and compiler-only matching components if root measurement agent does. Buster source-size ratchet measures separately production/build/tests/generated/docs/dormant to avoid cheating by deleting tests/docs. Whole monorepo code size is not a speed or reliability measure.

Sources:
- [current bootstrap build contract](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/agents/build.md#L52-L73)
- [first-party and third-party boundary](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/THIRD_PARTY_NOTICES.md#L1-L35)
- [Arm permission review](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/THIRD_PARTY_NOTICES.md#L146-L179)
- [size rules](https://github.com/buster14a/buster/blob/e642c1e32e40568c168d36b0f281c76e4c939139/docs/source-size.md)

## Benchmark feasibility / fair interpretation

Do not run Buster built-in `bench` or stage2 numbers against Cuik whole-driver times and call that ratio compiler speed. Compile identical raw and preprocessed C inputs to matching -c ELF64 x86-64 outputs, same host-built producer flags and compiler feature baseline; distinguish debug/no-debug, cold invocations vs warm in-process, build-time vs compiler-time, fallback count/quality tier. `-O2` flags are not equivalent optimization work across implementations.

Buster driver invocation examples:

```sh
/immutable/buster/ide cc -std=c11 -target x86_64-unknown-linux -march=baseline -g0 -fregister-allocator=fast -c input.c -o buster.o
/immutable/buster/ide cc -std=c11 -target x86_64-unknown-linux -march=znver5 -g0 -fregister-allocator=fast -c input.c -o buster.o
/immutable/buster/ide cc -std=c11 -fsyntax-only input.c
```

Keep -v/timing/probe counters out of timing series; replay separate for source/IR/fallback census. Self-host stage2 slower or fallback implementation is separate from optimized trusted host-built compiler. Cuik compiler can require baseline arch features independent of producer host flags; document failures/unsupported paths rather than silently drop them. Raw source size denominators differ from preprocessed token/source metric denominators.

No trustworthy quantified Cuik-vs-Buster speedup has been produced by this source-only architecture task. Feature wins above are conditional on Cuik agent's verified exact-head implementation and performance outcomes supplied by root measurement agent.
