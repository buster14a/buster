unsigned long long divide10(unsigned long long x) { return x / 10; }
static unsigned long long helper(unsigned long long x) { return x * 3 + 7; }
unsigned long long helper_loop(unsigned long long x, unsigned int n) { for (unsigned int i = 0; i < n; i++) { x = helper(x); } return x; }
unsigned long long sum_loop(const unsigned int *p, unsigned int n) { unsigned long long sum = 0; for (unsigned int i = 0; i < n; i++) { sum += p[i]; } return sum; }
