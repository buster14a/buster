import pathlib,subprocess,os,json,time,hashlib,statistics,platform
P=pathlib.Path(__file__).resolve().parent
R=P.parent
base=[str(R/'buster-measurement-build/Release/ide'),'cc','-g0','-march=baseline','-target','x86_64-unknown-linux','-fno-machine-fallback','-c']
cuik=[str(R/'cuik/bin/cuik'),'-c','-j1','-lang','c11','-target','x64_linux_gnu']
modes={'buster-fast':base+['-O2','-fregister-allocator=fast'],'buster-quality':base+['-O2','-fregister-allocator=quality'],'cuik-unoptimized':cuik,'cuik-optimized':cuik+['-O']}
rows=[]
for source in ('probes.c','synthetic-1024.c'):
 for sample in range(-1,11):
  ordered=list(modes);ordered=ordered if sample%2==0 else list(reversed(ordered))
  for name in ordered:
   output=P/(name+'-'+source+'.o')
   cmd=modes[name]+[str(P/source),'-o',str(output)]
   with (P/(name+'-'+source+'.stdout')).open('wb') as stdout,(P/(name+'-'+source+'.stderr')).open('wb') as stderr:
    start=time.perf_counter_ns(); process=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,cwd=R)
    _,status,usage=os.wait4(process.pid,0);elapsed=time.perf_counter_ns()-start;process.returncode=os.waitstatus_to_exitcode(status)
   row={'source':source,'sample':sample,'mode':name,'wall_ns':elapsed,'peak_rss_kib':usage.ru_maxrss,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,'exit':process.returncode,'command':cmd}
   rows.append(row)
   if process.returncode: print(json.dumps(row),flush=True);raise SystemExit('Compilation failed '+str(P/(name+'-'+source+'.stderr')))
   if sample==0:
    row['output_sha256']=hashlib.sha256(output.read_bytes()).hexdigest();row['object_bytes']=output.stat().st_size
    section=subprocess.check_output(['size','-A',str(output)],text=True)
    row['text_bytes']=int(next(line.split()[1] for line in section.splitlines() if line.strip().startswith('.text ')))
    (P/(name+'-'+source+'.disassembly.txt')).write_text(subprocess.check_output(['objdump','-dr',str(output)],text=True))
  (P/'compile-samples.json').write_text(json.dumps(rows,indent=2))
summary=[]
for source in ('probes.c','synthetic-1024.c'):
 for name in modes:
  family=[x for x in rows if x['source']==source and x['mode']==name and x['sample']>=0]
  summary.append({'source':source,'mode':name,'samples':len(family),'median_wall_ns':statistics.median(x['wall_ns'] for x in family),'min_wall_ns':min(x['wall_ns'] for x in family),'max_wall_ns':max(x['wall_ns'] for x in family),'median_rss_kib':statistics.median(x['peak_rss_kib'] for x in family),**{k:family[0][k] for k in ('object_bytes','text_bytes')}})
(P/'compile-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
