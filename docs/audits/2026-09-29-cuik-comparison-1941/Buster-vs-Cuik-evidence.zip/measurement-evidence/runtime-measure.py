import pathlib,subprocess,json,statistics
P=pathlib.Path(__file__).resolve().parent
modes=['buster-fast','buster-quality','cuik-optimized']
rows=[]
for sample in range(-1,11):
 for name in (modes if sample%2==0 else list(reversed(modes))):
  cmd=[str(P/(name+'-probe-runtime')),'20000000']
  process=subprocess.run(cmd,capture_output=True,text=True,check=True)
  ns,checksum=map(int,process.stdout.split())
  rows.append({'sample':sample,'mode':name,'runtime_ns':ns,'checksum':checksum,'command':cmd})
assert len(set(x['checksum'] for x in rows))==1
(P/'division-runtime-samples.json').write_text(json.dumps(rows,indent=2))
summary=[]
for name in modes:
 family=[x for x in rows if x['mode']==name and x['sample']>=0]
 summary.append({'mode':name,'samples':len(family),'median_runtime_ns':statistics.median(x['runtime_ns'] for x in family),'min_runtime_ns':min(x['runtime_ns'] for x in family),'max_runtime_ns':max(x['runtime_ns'] for x in family),'checksum':family[0]['checksum']})
(P/'division-runtime-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
