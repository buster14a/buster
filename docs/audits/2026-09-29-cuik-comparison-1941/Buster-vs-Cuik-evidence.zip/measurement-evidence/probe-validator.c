#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
extern unsigned long long divide10(unsigned long long);
extern unsigned long long helper_loop(unsigned long long,unsigned int);
extern unsigned long long sum_loop(const unsigned int*,unsigned int);
int main(int argc,char **argv) {
    uint64_t state=UINT64_C(0x1234567890abcdef);
    unsigned int p[257]; for(unsigned int i=0;i<257;i++)p[i]=i*UINT32_C(3456773);
    unsigned long long sum=0;
    for(unsigned int n=0;n<=257;n++) { if(sum_loop(p,n)!=sum)return 3; if(n<257)sum+=p[n]; }
    uint64_t cases[]={0,1,9,10,11,UINT64_MAX,UINT64_MAX-9,UINT64_C(1000000000000)};
    for(unsigned int i=0;i<sizeof(cases)/sizeof(cases[0]);i++)if(divide10(cases[i])!=cases[i]/10)return 1;
    for(unsigned int i=0;i<10000;i++) {state=state*UINT64_C(6364136223846793005)+1;if(divide10(state)!=state/10)return 2;uint64_t x=state;unsigned int n=i%257;for(unsigned int j=0;j<n;j++)x=x*3+7;if(helper_loop(state,n)!=x)return 4;}
    if(argc>1) {
        unsigned long count=strtoul(argv[1],0,10);sum=0;
        struct timespec begin,end;clock_gettime(CLOCK_MONOTONIC,&begin);
        for(unsigned long i=0;i<count;i++){state=state*UINT64_C(6364136223846793005)+1;sum+=divide10(state);}
        clock_gettime(CLOCK_MONOTONIC,&end);
        uint64_t ns=(uint64_t)(end.tv_sec-begin.tv_sec)*UINT64_C(1000000000)+(uint64_t)(end.tv_nsec-begin.tv_nsec);
        printf("%llu %llu\n",(unsigned long long)ns,sum);
    } else puts("validation passed");
    return 0;
}
