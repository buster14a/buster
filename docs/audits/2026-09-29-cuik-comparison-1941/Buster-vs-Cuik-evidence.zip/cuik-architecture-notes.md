# Cuik architecture inspection

Inspection pin: `a7677f74e5391dcc7fdedad61468f4f207c9998f`, 2026-07-24. Source-only inspection of local clean clone; no builds or benchmark runs by this agent. This is intermediate research, not a deliverable. Every file URL below uses this pin. Current README explicitly warns unfinished/buggy; claims faster-than-Clang are unmeasured project claims.

Base URL: https://github.com/RealNeGate/Cuik/blob/a7677f74e5391dcc7fdedad61468f4f207c9998f/

## Verified capabilities and important qualifications

| Area | Verified current source | Evidence | Comparison implication |
|---|---|---|---|
| Compiler libraries | libCuik frontend, preprocessing component, independent TB backend; DLL/SO build options; public phase/token/AST APIs | README.md:13; build.lua:46-86; include/cuik_lex.h:210-245; include/cuik_parse.h:36-61; docs/BUILDING.txt:11-13 | Cuik wins standalone library packaging/introspection convenience. Buster also has reusable preprocess/parse/sema/lower APIs: do not claim it lacks modularity. |
| VFS | CPP descriptor accepts locate/get-file callbacks and user data | include/cuik_lex.h:210-225 | Cuik stronger editor/embedding file-source injection; Buster's include paths do not provide in-memory include overlays. |
| Integrated build API | Public sys/cc/ld build-step DAG, dependency scheduler; multiple TUs compiled inside one process | include/cuik_driver.h:143-166; cuik_c/driver/driver.c:547-597; main/main_driver.c:210-231 | Cuik stronger embeddable graph orchestration. Buster has persistent lanes; throughput winner needs a matched workload. |
| Backend JIT | TB JIT allocation/placement/end implemented and publicly exposed | include/tb.h:632-671; tb/jit.c:257,367,384 | Backend capability exists; C CLI `-run` prints unsupported and exits that path (driver.c:399-402). Do not say C CLI JIT works. |
| AST expressions | Contiguous postfix `Subexpr` stream, separate type and cast-type arrays | include/cuik_ast.h:711-746; cuik_c/sema.c:1430-1449 | Useful cache/locality idea, but Buster's token-range semantic design is different; no measured memory/speed victory. |
| Interning | Global NBHS atom set with thread-local arenas, Murmur hash; stable interned names | cuik_pp/atoms.c:7-67 | Alternative interning design, not evidence of a speedup. Lifetime cleanup incomplete (`atoms_free` empty). |
| Diagnostics | Source excerpts/carets/ranges, recursive macro invocation backtrace, up to 3 fixit hints; callback and buffered output | cuik_pp/diagnostic.c:157-191,198-206,255-278; include/cuik_lex.h:343-351 | Cuik wins human-facing explanation/fixit capabilities. Buster wins stable structured diagnostic codes/fields (Buster agent verified). |
| Include optimization | Include guards and pragma once recognized/cached | cuik_pp/cpp.c:152-162,753-758; cuik_pp/cpp_directive.h:399-417,459-469 | Normal compiler feature, benchmark macro/header workloads before scoring performance. |
| Lexer | Generated DFA (meta/lexgen.lua), perfect-hash keyword classification, optional x86 128-bit keyword compare | cuik_pp/lexer.c:18-57 | Do not claim broad AVX-512 lexing. CPP line-map SIMD code is disabled (`#if 1` scalar path, cpp.c:527-564). |
| Own linker | Public TB linker, object/library/module inputs, parallel importing/exporting design; CLI `-based` selects it for PE/ELF | include/tb_linker.h:29-64; linker/README.txt; driver.c:407-456 | Architectural opportunity to avoid object round-trip, but immature and not a speed victory without measuring. Default Linux path delegates to clang system linker (gnu.c:57-77). |
| Object/debug output | COFF, ELF64, Mach-O, Wasm object exporters wired. CodeView and SDG debug format implementation | tb/exporter.c:8-35 | Presence != proven full target ABI support. DWARF enum has no active format implementation; CLI `-g` picks CodeView regardless of OS (driver.c:386-388). |
| Platforms | Ordinary CI builds Windows x64 CLI+DLL and Linux x64 CLI | .github/workflows/ci.yml:4-62 | Buster's verified target/CI matrix is materially broader. Darwin link hook returns false (toolchains/darwin.c:16-18). |
| Languages | C frontend described C11 mostly; current driver defaults C23 enum, provides C11/C23/GLSL selection; experimental Go parser dormant in CLI | cuik_c/README.txt:51; main/main_driver.c:126-133,205-213; driver_arg_parse.h:59-61 | Do not claim complete C23, GLSL, Go, or C++ compiler. |
| Frontend omissions | `_Complex`/`_Imaginary` rejected; GNU statement expressions rejected; attributes/declspec only partial | decl_parser.h:394-396,18,36-60,420-438; expr_parser.h:339 | Compare exact supported subsets; not aggregate correctness percentages. |
| Preprocessor omissions | `#error`, `#warning`, `#embed` dispatcher commented out; embed implementation disabled | cpp.c:708-725; cpp_directive.h:512 onward under #if 0 | Significant source-supported limitations. Unknown directive error behavior means don't infer silently accepted. |
| API maturity | Ordinal public declarations differ from actual names; old `cuik_driver_compile` declaration has no implementation found | include/cuik_parse.h:38-39 vs parser.c:426/430; include/cuik_driver.h:93 | Library architecture is attractive; not stable production SDK. |
| Tests/CI | 45 .c files in tests directory, not 45 verified passing tests; handwritten differential suite compares with Clang; ordinary workflow frontend tests absent; TB tests gated to `refs/heads/aaa` | tests/suite/gold.lua, tests/suite/test.lua; .github/workflows/ci.yml:63-102 | Buster stronger validation infrastructure if source corroborated. No rate claims. |

## Quantified structural facts, not measured throughput

- Current `cuiksched_per_function` batch size is **10,000 functions** (driver_sched.h:48). Thus a module with up to 10,000 functions submits one backend task, which can leave most workers idle. IR-generation batching is **50 top-level statements** (same file:36), dispatched in driver.c:877-907. No speedup factor can be derived just from these numbers.
- Worker pool is work stealing with atomics/futex waits (common/pool.c:358-460). `-j N` initializes **N child threads plus main** (pool.c:527-539). Default CLI thread count is zero unless supplied. Source flags are `-j` and boolean `-O`, despite old README mentioning `--threads` (driver_arg_parse.h:65,78,542-556).
- Local symbol table has **16,384 local slots** and a **1 MiB allocation buffer** (include/cuik_symtab.h:57-78), reverse linear local lookup. Sema postfix temporary stack is **128 entries** (sema.c:1430,1447). These are limits/implementation facts, not equivalent to total expressions or per-function instruction limits.
- Main IRgen forcibly selects **`x86_64-v1`** (driver.c:853-860). It is not using Zen 5 code selection merely because AVX/feature names exist elsewhere.
- Test inventory: **64 files**, **45 .c**. Physical C/h/inc source lines by component: frontend cuik_c **14,190**, preprocessor **5,803**, TB **43,325**, linker **4,137**. Includes vendored code and tests as applicable, not a fair comparison to the whole Buster monorepo or a maintainability score.

## Advice when Buster loses

1. **Diagnostic UX**: Preserve Buster's structured codes; add explicit secondary ranges, macro provenance IDs/parent indices, fixit replacement ranges/text; render source excerpts and carets and ordered expansion notes. Cuik shows this can coexist with compact locations and buffered diagnostics. Use indexed records and iterative traversal to respect Buster's ban on input-dependent recursion. Benefit is feature parity; compiler slowdown/improvement unmeasured.
2. **Embedding/VFS**: Provide indexed source-buffer overlays and include resolution tables at API boundary, plus explicit lifetime/version ownership. Cuik's callbacks are the model for capability, not implementation: Buster AGENTS forbids callback dispatch. Keep direct calls and work tables.
3. **Library packaging**: Ship tested `libbuster_compiler` static/shared target and small public API with retained-arena handles; compile/load/introspection sample. Buster phase decomposition already exists, so don't propose a new frontend IR or rewrite merely for modularity. Add export/API contract checks to avoid Cuik's header/implementation drift.
4. **Embeddable build orchestration**: Expose a direct data-only compile-plan/dependency graph executed on Buster's persistent lanes. Cuik's graph is useful for IDE/hot reload/multiple source files; avoid copying its fixed 10k backend batches/task leaks.
5. **Compact expression design**: If profiles show repeated token re-walks dominate Buster, retain compact typed facts keyed by token/semantic indices or homogeneous lowered operations within canonical IR. Cuik's postfix stream motivates cache-friendly batching; it does not establish a measured superiority over Buster token ranges.
6. **Link integration**: Consider explicit in-memory canonical-module/object fragments into linker to reduce disk/process overhead only after a matched link-time audit. Cuik's own linker is immature; Buster should retain its stronger validation/ABI contracts.

## Citation status

Web source repo page retrieved successfully as `turn1view0`, supports README modular C11 frontend/TB and unfinished warning. Pinned raw and blob file web opens returned DisabledError; do NOT cite these failed web refs. For source findings use the pinned GitHub links above (connector/local source inspected). Parent must open web refs itself before citing subagent ref under tool rules.
