#!/usr/bin/env python3
"""Render the comparison from frozen measurement data and pinned source analysis."""
import json, pathlib, html, hashlib, os
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.colors import HexColor, white
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'deliverables'; OUT.mkdir(exist_ok=True)
D=json.loads((ROOT/'summary.json').read_text())
RAW=json.loads((ROOT/'raw_results.json').read_text())
PINS=D['commits']
BLUE=HexColor('#153e58'); TEAL=HexColor('#087f8c'); GRAY=HexColor('#526171')
font_base=pathlib.Path(os.environ.get('CODEX_PRIMARY_RUNTIME_NODE_MODULES','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules'))/'pdfjs-dist/standard_fonts'
font_regular=font_base/'LiberationSans-Regular.ttf'; font_bold=font_base/'LiberationSans-Bold.ttf'
if not font_regular.exists():
    font_regular=pathlib.Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf');font_bold=font_regular.with_name('DejaVuSans-Bold.ttf')
pdfmetrics.registerFont(TTFont('CompareSans',str(font_regular)))
pdfmetrics.registerFont(TTFont('CompareSans-Bold',str(font_bold)))
pdfmetrics.registerFontFamily('CompareSans',normal='CompareSans',bold='CompareSans-Bold',italic='CompareSans',boldItalic='CompareSans-Bold')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleX', fontName='Helvetica-Bold', fontSize=27, leading=31, textColor=BLUE, spaceAfter=14))
styles.add(ParagraphStyle(name='H1X', fontName='Helvetica-Bold', fontSize=18, leading=22, textColor=BLUE, spaceAfter=12))
styles.add(ParagraphStyle(name='H2X', fontName='Helvetica-Bold', fontSize=11.5, leading=15, textColor=TEAL, spaceBefore=8, spaceAfter=5))
styles.add(ParagraphStyle(name='BodyX', fontName='Helvetica', fontSize=9.7, leading=14, spaceAfter=8))
styles.add(ParagraphStyle(name='SmallX', fontName='Helvetica', fontSize=8.2, leading=11.5, textColor=GRAY, spaceAfter=6))
styles.add(ParagraphStyle(name='CellX', fontName='Helvetica', fontSize=8.4, leading=11))
styles.add(ParagraphStyle(name='HeadX', fontName='Helvetica-Bold', fontSize=8.4, leading=11, textColor=white))
for style in styles.byName.values():
    if getattr(style,'fontName',None)=='Helvetica':style.fontName='CompareSans'
    elif getattr(style,'fontName',None)=='Helvetica-Bold':style.fontName='CompareSans-Bold'
story=[]
def p(s,style='BodyX'): story.append(Paragraph(s,styles[style]))
def h(s): p(s,'H1X')
def sub(s): p(s,'H2X')
def page(): story.append(PageBreak())
def table(headers,rows,widths):
    arr=[[Paragraph(html.escape(str(v)),styles['HeadX']) for v in headers]]
    arr += [[Paragraph(html.escape(str(v)),styles['CellX']) for v in row] for row in rows]
    t=Table(arr,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('ROWBACKGROUNDS',(0,1),(-1,-1),[white,HexColor('#f1f5f7')]),('LINEBELOW',(0,0),(-1,0),0.6,BLUE)]))
    story.append(t);story.append(Spacer(1,9))
def ms(v): return f'{v*1000:,.2f}'
def med(c,n): return D['compile'][c][n]['median_s']
def rt(k,n): return D['runtime'][k]['compilers'][n]['median_s']
def link(label,url): return f'<link href="{html.escape(url,quote=True)}" color="#087f8c">{html.escape(label)}</link>'
W=511
order=['scalar_4.c','scalar_32.c','scalar_512.c','scalar_4096.c','macro_1024.c','cJSON.c','cjson_driver.c','runtime.c']
labels={'scalar_4.c':'4 functions','scalar_32.c':'32 functions','scalar_512.c':'512 functions','scalar_4096.c':'4,096 functions','macro_1024.c':'1,024 macro functions','cJSON.c':'cJSON 1.7.19','cjson_driver.c':'cJSON driver','runtime.c':'8-kernel runtime TU'}
klabels={'reduction':'Integer reduction','division':'Integer division','licm':'Loop invariants','gvn':'Repeated expressions','inlining':'Small-helper calls','branches':'Dependent branch','memory':'Indexed memory','floating':'Floating arithmetic','cjson_parse_print':'cJSON parse/print'}

# 1. Concrete conclusion and scope.
p('Buster vs Claude\'s C Compiler','TitleX')
p('Measured native compilation, generated code, semantics, architecture, and engineering priorities.','H2X')
p('29 September 2026 | Pinned-source comparison | Exploratory hosted measurements','SmallX')
p('<b>Buster wins compilation throughput on the larger tested inputs. CCC wins scalar code size and the observed scalar runtime medians. Buster wins native SIMD code generation in the vector probe, debug output, and included validation infrastructure. There is no universal winner.</b>')
table(['Decision','Evidence'],[
('Fast builds of substantial C units','Buster FAST: 2.30x faster for cJSON; 3.71x for macro functions; 6.32x for 4,096 functions.'),
('Tiny compilation units','CCC: 2.84 ms vs Buster 20.71 ms for four functions. The Buster range is noisy: 13.97-26.98 ms.'),
('Scalar generated programs','CCC: 1.09-3.65x faster observed medians across nine cells; cJSON 1.18x. Small differences need exclusive-host confirmation.'),
('Scalar .text size','CCC: 27.8-81.6% smaller across all eight compile workloads.'),
('Native 512-bit vector add','Buster 36 B vs CCC 610 B: 94.1% less .text, one native vpaddq. No vector runtime timing.'),
('Peak compiler RSS','CCC wins seven cells; Buster uses 41.3% less RSS on 4,096 functions.'),
('Reliability conclusion','All chosen runtime checks pass. This does not establish general C conformance or a compiler-wide correctness percentage.')],[155,356])
p('Buster revision: '+PINS['buster'],'SmallX')
p('CCC revision: '+PINS['ccc'],'SmallX')
p('The Buster comparison uses its current C-only native compiler, not the removed custom-language frontend and not an LLVM optimizing backend. Its LLVM bitcode output is a distinct path. CCC means Anthropic\'s anthropics/claudes-c-compiler, not Clang or Claude Code itself.','SmallX')
p('<b>Host limit:</b> EPYC 9V74 shared virtual machine, x86-64 Linux, with AVX-512 exposed. This is not Ryzen 9700X / Zen 5 acceptance evidence. Results apply to the recorded binaries, inputs, flags, and host.','SmallX')

# 2. Compilation.
page();h('Compilation time and scaling')
p('Median wall time in milliseconds. Seven rotated-order observations after warmup, process creation included; no compiler build runs inside the observations. Winner column compares Buster FAST with CCC. QUALITY and Clang are separate context.')
rows=[]
for c in order:
    row=D['compile'][c]; winner='Buster' if row['time_winner']=='buster_fast' else 'CCC'
    rows.append([labels[c],ms(row['buster_fast']['median_s']),ms(row['buster_quality']['median_s']),ms(row['ccc']['median_s']),ms(row['clang20']['median_s']),f'{winner} {row["winner_speedup_factor"]:.2f}x'])
table(['Input','Buster FAST','QUALITY','CCC','Clang 20','Winner'],rows,[137,69,64,65,68,108])
sub('What the scaling reveals')
p('Buster\'s fixed process cost dominates very small units. At 512 and 4,096 functions, its lower marginal work cost reverses the result. Across 32 to 4,096 functions, the observed wall increment is 93.86 ms for Buster versus 683.09 ms for CCC. This is a measured difference for this generator, not a general asymptotic-complexity proof.')
p('CCC performs richer SSA transforms, emits text assembly, applies text peepholes, and reparses assembly into ELF. Buster emits native machine representations directly and applies a bounded canonical FAST pipeline. These structural differences explain plausible cost sources, but the observed ratios are end-to-object results; no fraction of the difference is attributed to a phase without a matched diagnostic.')
sub('Action when Buster loses small-TU compilation')
p('Profile an immutable binary on empty, four-function, and 32-function units. Separate loader/process time, eager table initialization, predefined symbols, arena setup, source discovery, and backend preparation. Initialize only data demanded by the selected operation. Reuse a persistent compiler or batch native translation units when the surrounding build can do so. No specific startup culprit was proved here.')
p('Target the observed floor before further lexer SIMD work: four-function Buster time needs an 86.3% reduction to match the current CCC median, while 32 functions need 59.0%. Those percentages are competitive gaps, not predicted gains from a proposed patch.','SmallX')

# 3. RSS and code footprint.
page();h('Peak memory and scalar code size')
p('RSS values are median MiB from three separate C fork/exec/wait4 captures. The original Python wrapper had an inherited pre-exec memory floor; original samples are retained, and accepted wall timings are unchanged. Code bytes are the sum of emitted .text sections, excluding debug data.')
rows=[]
for c in order:
 r=D['compile'][c]; b=r['buster_fast'];cc=r['ccc']
 rows.append([labels[c],f'{b["median_peak_rss_kib"]/1024:.2f}',f'{cc["median_peak_rss_kib"]/1024:.2f}',f'{b["text_bytes"]:,}',f'{cc["text_bytes"]:,}',f'{r["ccc_text_reduction_pct"]:.1f}%'])
table(['Input','Buster RSS','CCC RSS','Buster .text B','CCC .text B','CCC smaller'],rows,[137,67,65,86,83,73])
sub('Memory winner depends on input size')
p('CCC\'s four-function peak is 8.25 MiB against Buster 22.82 MiB. On cJSON it uses 23.38 MiB against 36.16 MiB. On 4,096 functions the order reverses: Buster 89.34 MiB against CCC 152.22 MiB, a 41.3% reduction. The macro cell\'s 3.4% RSS difference is small and should not be overgeneralized.')
sub('Code size is the larger Buster weakness')
p('CCC reduces cJSON .text by 27.8% and macro-function .text by 81.6%. Even the simple exported scalar functions are about 58% smaller. A four-function case emits 694 B in Buster, 295 B in CCC, and 142 B in Clang. This is code-section size, not executable disk size or instruction-cache miss measurement.')
p('Disassembly of f0: Buster 166 B versus CCC 73 B. Buster retains stack homes and generic shifts/multiplication where CCC uses smaller instruction forms. Prioritize immediate shifts, legal LEA patterns, memory operands, copy elimination, and unnecessary leaf-frame removal before adding an expensive global optimizer.')
p('For RSS, collect allocation-by-phase and per-site counters separately from timing. Investigate retained source/token/IR pools and startup allocations before changing arena policy. Reuse bounded scratch; release per-TU state at safe ownership boundaries. A smaller reservation is not necessarily smaller RSS.','SmallX')

# 4. Runtime.
page();h('Generated-program runtime')
p('Milliseconds, five rotated observations after warmup. Each row uses identical source, input seed, and fixed row-specific repetition count across compilers. Arrays are small; the indexed-memory cell is not a DRAM/cache-miss benchmark. All timed results match the Clang oracle.')
rows=[]
for k,r in D['runtime'].items():
 rows.append([klabels[k],ms(rt(k,'buster_fast')),ms(rt(k,'buster_quality')),ms(rt(k,'ccc')),ms(rt(k,'clang20')),f'{r["ccc_speedup_over_buster"]:.2f}x'])
table(['Kernel','FAST','QUALITY','CCC','Clang 20','CCC faster'],rows,[137,69,64,65,68,108])
p('CCC has the lower observed FAST-comparison median in every row. The small floating-point gap needs stronger host control; all results are exploratory, without simultaneous confidence bounds or an admitted global performance verdict. CCC even beats Clang in the particular dependent-branch cell; that is not a general claim of superior optimization.')
sub('QUALITY is not the remedy demonstrated here')
p('FAST and QUALITY produce whole-file identical objects for every synthetic TU, including the eight-kernel runtime TU. Their linked runtime .text is byte-identical. The timing differences therefore do not demonstrate allocator-generated code improvements. For cJSON, QUALITY saves 745 code bytes (1.36%) but has no demonstrated runtime benefit in this capture.')
sub('Current native path, not fallback artifacts')
p('Separate untimed Buster profiles report zero fallback functions and zero runtime fallback locals for the tested native path. The runtime gaps belong to actual FAST code generation. Buster\'s canonical fallback remains implemented in the repository; this report does not claim native retirement is complete.')
p('Eight synthetic kernels were checked over three seeds and three repetition counts before timing. cJSON has separate parse/print oracle checks. These successful observations are a bounded correctness result, not GCC torture, PostgreSQL regression, kernel boot, or whole-compiler conformance evidence.','SmallX')

# 5. Exact causes and improvements.
page();h('Where CCC makes better scalar code')
table(['Loss / measured CCC advantage','Observed implementation difference','Buster remedy'],[
('Helpers: 1.91x faster','Buster retains two helper calls per inner iteration; CCC inlines them.','Add explicitly selected, budgeted tiny-function inlining; preserve argument evaluation, ABI, recursion/SCC limits, debug provenance.'),
('Loop invariants: 2.48x faster','Buster repeats x*y, x+y, and the seed mask in the inner loop; CCC hoists them.','Build reusable loop/dominance facts. Hoist proven pure operations; do not hoist potentially trapping or memory/atomic/FP-observable operations by default.'),
('Division: 1.52x faster','Buster executes both divisions; CCC replaces unsigned /37 with magic multiply and shift.','Implement target-lowered constant unsigned division with independent wide-integer equivalence tests and cost checks.'),
('Branch cell: 3.65x faster','CCC uses cmovne for the tested diamond; Buster retains conditional branches.','Select branchless operations for short, side-effect-free diamonds using target cost and register-pressure limits; do not convert every branch.'),
('Repeated expressions: 2.23x faster','CCC has GVN/copy propagation; Buster\'s four-pass canonical FAST pipeline has no general value numbering.','Begin with bounded block-local value numbering, then sparse propagation/constant-branch cleanup. Treat memory and FP identities conservatively.'),
('Reduction: 2.51x faster; memory: 1.78x','Observed overall code-quality gaps; no isolated single-cause experiment. Clang remains much faster in the reduction cell.','Inspect loop control, scalar spills and missed simplification. After scalar cleanup, evaluate a narrow opt-in reduction vectorizer with tail, overflow and alias tests.')],[137,187,187])
sub('Preserve Buster\'s compile-throughput advantage')
p('Keep FAST as a deliberate fast tier. Add a distinct optimizing tier rather than making every compile run a CCC-sized pipeline. Attach work/retained-memory limits, collect pass changes and costs outside timed runs, and skip clean functions. Reuse CFG/liveness facts with explicit invalidation. CCC\'s dirty-function and pass-dependency scheduling is a useful architectural example.')
p('The measured 1.5-3.7x runtime gaps are reference targets for this corpus. They are not predictions that any one pass will deliver that gain. Require unchanged semantic checks plus matched compilation-time, RSS, code-size and runtime observations for each candidate.','SmallX')

# 6. Native SIMD.
page();h('SIMD and Zen 5')
table(['Dimension','Buster','CCC','Verdict'],[
('Compiler implementation','Compact AVX-512 lexer/translation kernels, packed arena/index-based representations.','String-based preprocessing, token ownership, SSA vectors/maps, assembly text roundtrips.','Buster has stronger SIMD-oriented design; measured large-input throughput favors Buster on this host.'),
('Header-free 64-byte vector add','One native ZMM vpaddq; .text 36 B.','Eight scalar lane additions; .text 610 B.','Buster: 94.1% less code (16.94x size ratio), no runtime ratio measured.'),
('Stock immintrin.h test','Clang 20 header inclusion fails on unrelated __builtin_ia32_clui.','Bundled headers compile but the requested AVX-512 operation scalarizes.','CCC wins this inclusion test; Buster wins native code generation once reachable.'),
('CPU feature selection','Recognizes znver5 target model; true mask bank k1-k7.','No x86 tuning model found; x86 -march lacks tuning; CPU-support builtin always false.','Buster capability advantage. Actual 9700X performance remains unmeasured.'),
('Loop autovectorization','No native general loop vectorizer found.','No native general loop vectorizer found.','Neither wins a demonstrated auto-vectorization capability.'),
('Self-built compiler SIMD','Compact lexer guard excludes __BUSTER__; trusted Clang build uses the SIMD path.','C compiler written in Rust; C self-compilation is not applicable.','Buster self-built stages need separate profiling; trusted-host result cannot be transferred.')],[119,146,145,101])
sub('High-priority Buster improvements')
p('Repair the stock intrinsic-header barrier tracked in '+link('#1419','https://github.com/buster14a/buster/issues/1419')+'. Register precise builtin signatures so unused supported header wrappers can be analyzed; give structured errors when an unsupported operation is actually required. Freeze and validate a resource-header version, or distribute a complete supported header set. Avoid scalar stubs with wrong intrinsic semantics.')
p('For the vector probe, Clang emits 22 B versus Buster 36 B by using a memory operand and omitting the frame. Those are concrete selector/prologue opportunities: a 38.9% code-size gap to Clang in one function. Add real runtime vector checks before claiming corresponding throughput gains.')
p('Schedule an exclusive 9700X comparison with native-CPU host builds, scalar and wide-vector workloads, multi-TU scaling, cache-capacity crossings, and precise feature/OS state. Four wide execution lanes do not make parsing, linking, irregular control flow, or cache misses disappear.','SmallX')

# 7. Semantics & frontend.
page();h('C semantics and frontend compatibility')
table(['Aspect','Finding','Winner / limitation'],[
('C/C++ language scope','Both current projects are C compilers. Buster\'s custom frontend is dormant. Neither is a C++ compiler.','Tie in active language scope.'),
('ISO conformance / GNU coverage','Both have substantial C/GNU implementations and limitations; Buster has C23 subset support, CCC shallow -std handling. No common exhaustive conformance suite was run.','No global correctness or standards winner.'),
('Implicit C11 atomics','Buster emits lock cmpxchg for _Atomic counter++; CCC plain load/add/store, matching qualifier erasure in source. Explicit CCC atomic builtins are a separate implemented path.','Buster wins this semantics probe. No performance comparison against a non-atomic implementation.'),
('GNU error attribute','Clang diagnoses. Buster accepts source and preserves external call; CCC accepts and removes call.','Neither enforces the required diagnostic in the probe. Buster preserves the reference.'),
('Fortify request','Buster preserves -D_FORTIFY_SOURCE=2 macro; CCC explicitly undefines it.','Buster wins request preservation; full fortify-wrapper support not established.'),
('CPU dispatch builtin','Buster rejects __builtin_cpu_supports; CCC accepts but falsely reports AVX512F unavailable; oracle reports available.','Buster needs implementation; CCC\'s apparent acceptance is misleading.'),
('Wide floating types','Buster binary16 runtime exists; bfloat16 runtime refused; AArch64 binary128 transport/widening exists but arithmetic/comparison/narrowing remain unsupported. CCC has ARM/RV binary128 libcalls, while x86 _Float128 aliases long double.','Coverage is split. CCC has source-implemented AArch64/RV wide arithmetic breadth, not a verified execution win here.'),
('Intrinsic headers / host resources','Buster consumes an embedded host resource-header path. CCC ships 17 intrinsic header files, often scalar-emulated.','CCC wins self-contained header packaging; operation semantics must be checked.')],[115,287,109])
p('Buster remedies: implement CPU feature queries with compiler/target/OS-state semantics; diagnose GNU error attributes at referenced calls; close the validated header surface; add binary128 runtime helper lowering with the exact target ABI and fenv/NaN tests. Do not discard semantic checks or advertise unsupported features merely to make configure scripts pass.','SmallX')

# 8. Backend / deployment matrix.
page();h('Targets, artifacts, debugging, and tooling')
table(['Aspect','Buster','CCC','Verdict'],[
('Native architecture targets','x86-64 and AArch64.','x86-64, i686, AArch64, RV64.','CCC 4 vs 2 native architecture targets; +i686 and RV64.'),
('Host / object platform coverage','Linux/macOS/Windows and additional mobile/UEFI targets; ELF64/COFF/Mach-O.','Linux-developed ELF compiler; Windows/macOS not validated in supplied project.','Buster: 3 object families vs 1, broader OS/ABI infrastructure.'),
('Native toolchain independence','Own native codegen, encoders, object/link/JIT modules. No LLVM dependency for timed native path.','Own native codegen, assembler/linker; Cargo manifest zero dependencies.','Both native paths are custom; CCC does not win by a presumed Buster LLVM dependency.'),
('Dynamic linking breadth','Own -shared/-pie image path limited to Linux x86-64 in driver.','ELF shared/link implementations for four native backends.','CCC broader source-implemented ELF CPU coverage; no four-target execution sweep here.'),
('Non-native output','Direct Wasm64 and LLVM bitcode, plus specialized paths with explicit limits; GPU orchestration distinct.','No matching backend output surface found.','Buster breadth advantage; output existence is not target-runtime proof.'),
('Debugging / unwind','Own DWARF4, CodeView/PDB and unwind machinery; probe .debug_info/.debug_line/.eh_frame present.','Default standalone assembler discards debug/CFI directives; probe has no corresponding sections.','Buster wins emitted debug/unwind evidence; section presence is not a full debugger test.'),
('CLI integration','ide cc subcommand; tested cc --version and --help rejected. Unsupported options generally diagnosed.','Standalone ccc / per-arch binaries; GCC version/triple interface. Unknown -f/-m flags silently ignored.','CCC wins packaging/interface; Buster wins explicit unsupported-option feedback.'),
('Parallel compile scheduling','Opt-in -fcompile-jobs=N persistent native multi-input link lane gang; default 1.','Input sources compiled sequentially within invocation. Build system may parallelize processes.','Buster has internal scheduling capability; no scaling speedup measured.'),
('Profiling interfaces','Source work census, per-pass timing, allocation/PMU/throughput tools and provenance.','CCC_TIME_PHASES/TIME_PASSES, change counts, pass disabling.','Both useful. Buster stronger performance-admission infrastructure.')],[108,151,151,101])
p('Add a small buster-cc entry point, real version/triple query responses, relocatable builtin resources, and representative configure/CMake smoke tests. These address the measured interface gap without changing the optimizing pipeline. New i686/RV64 backends are larger investments; for your Zen 5 priority, current runtime/startup/header gaps have a more direct payoff.','SmallX')

# 9. Quality of evidence and maintainability.
page();h('Validation, maturity, and maintainability')
table(['Aspect','Evidence','Verdict'],[
('Included validation infrastructure','Buster includes desktop OS/architecture CI, sanitizer/fuzz, differential, ABI, metamorphic, self-host, strict fallback and pinned compatibility harnesses. CCC has 499 in-source test declarations; documented tests/ and .github/ trees absent at pinned checkout.','Buster infrastructure/reproducibility winner; not proof of greater intrinsic correctness.'),
('Reported ecosystem breadth','Anthropic historical report describes Linux 6.9, QEMU, FFmpeg, SQLite, PostgreSQL, Redis and GCC torture. Current CCC tracker has 285 rows with failures, incomplete targets and changed time budgets. Buster has 13 pinned compatibility harnesses identified in audit.','CCC wins reported external-project breadth. The reports were not independently reproduced in this comparison.'),
('Self-host validation','Buster implements a full-unity two-generation byte-identical fixed-point gate, not rerun in this comparison. CCC is Rust-written, so a C compiler cannot compile its implementation language.','Buster has applicable C self-host gate; no language-independent correctness ratio follows.'),
('Compiler source footprint','CCC Rust: 351 files, 186,696 physical lines, 8,154,079 B. Buster compiler C/H: 130 files, 383,469 lines, 30,723,563 B; excluding generated files, 111 files/283,281 lines/14,281,451 B. Shared Buster foundations excluded.','CCC smaller physical compiler-source footprint. Scope/language/generated data prevent a maintainability score.'),
('Memory-safety design','CCC source is safe Rust by inspection (no executable unsafe blocks found); Buster uses C arenas, indices and validation contracts. Neither compiler implementation was audited for security here.','CCC has language-level memory-safety advantage; no measured defect/security rate.'),
('Licensing and reuse clarity','CCC declares CC0-1.0. Buster README explicitly says third-party notices do not grant a license to first-party code.','CCC clearer external reuse terms; Buster needs an intentional first-party licensing decision if external adoption is desired.'),
('Maintenance risk','CCC has a richer transform surface and publicly warned unvalidated AI-authored documentation; Buster has larger dense modules, generated metadata and many invariant/admission mechanisms.','No objective universal winner. Auditability depends on clear contracts and reproducible tests, not LOC or test-count ratios.')],[116,288,107])
p('Do not divide Buster\'s millions of assertions by CCC\'s 499 test declarations, or compare either to a historical 99% torture result. Those denominators differ. The common-input checks in this run are the directly comparable correctness evidence.','SmallX')
p('Buster\'s validation expansion should target pristine pinned GCC torture, Linux kernel configurations with boot tests, PostgreSQL regressions and FFmpeg checkasm. Keep unsupported cases and failed checks visible, and retain independent execution evidence. That closes the most useful CCC ecosystem advantage.','SmallX')

# 10. Priorities.
page();h('Recommended order for Buster')
table(['Priority','Concrete work','Success evidence'],[
('1. Startup and RSS floor','Attribute fixed small-TU costs; make unrelated tables/resources lazy; bounded persistent/batched compilation where appropriate.','Four/32-function wall and peak RSS improve; cJSON/large-input throughput stays within predeclared budgets. No guessed initialization culprit.'),
('2. Cheap native instruction selection','Immediate shifts, LEA/multiply idioms, legal memory operands, redundant-copy removal, leaf frames, lock xadd for simple equivalent fetch-add.','Exact disassembly changes plus semantic regressions, ABI/self-host validation, code-size and compile-time measures.'),
('3. Reach existing SIMD through headers','Implement validated builtin signatures and referenced-operation diagnostics; close #1419; freeze the resource interface.','Stock immintrin test compiles; genuine wide instructions and runtime lane/mask/FMA semantics match an independent oracle.'),
('4. Explicit optimizing tier','Bounded tiny inlining, local value numbering/SCCP/constant CFG cleanup, constant division, loop-invariant motion, careful if-conversion. Reuse analyses and dirty worklists.','Each candidate isolates its effect on relevant lost runtime cell and documents added compile/RSS cost. Keep FAST default.'),
('5. Precise frontend contracts','Implement CPU-support query and GNU error attribute enforcement. Add binary128 runtime lowering when target demand justifies it.','The concrete probes stop rejecting supported operations or silently accepting unenforced semantics; target ABI/fenv validation for wide FP.'),
('6. Standalone distribution','buster-cc facade, real version/triple queries, bundled/versioned resources, chosen first-party reuse terms.','Stock configure/CMake/build workflows consume an installed compiler without monorepo path assumptions.'),
('7. Wider real-source validation','Pin GCC torture, Linux boot configurations, PostgreSQL and FFmpeg oracles.','Pristine builds and full target executions with exact revisions, retained logs, explicit failure/unsupported inventories.'),
('8. Exclusive Zen 5 follow-up','Run frozen artifacts on 9700X; measure startup/large TUs, wide SIMD, multi-TU scaling, cache-capacity crossings and sustained mixed kernels.','Noise controls, A/A, exact binary/input/environment hashes and matched source/host-build controls. No VM result promoted to Zen 5 admission.')],[110,243,158])
p('<b>Decision for your current goals:</b> Buster is already the stronger choice for fast substantial C compilation on the measured configuration. CCC supplies concrete optimization techniques and ecosystem targets to learn from. First remove fixed overhead and poor instruction forms; then offer runtime optimization as an explicit, budgeted choice. A broad optimizer by itself would not guarantee better overall time to an artifact.','BodyX')

# 11. Method detail.
page();h('Reproduction and interpretation limits')
sub('Builds and operation boundaries')
p('Buster: Clang 20.1.2 Release, unity, tests off, host -O3/-march=native; hosted Clang build-driver exception, default native linker selection. CCC: Rust 1.90.0, stock cargo release --bin ccc --offline, no GCC assembler/linker features. These are different projects\' release host builds, not identical compiler-host instruction targets.')
p('Common timed C flags: -O2 -std=gnu17 -fno-pic. Buster adds -g0 because debug defaults on; QUALITY adds -fregister-allocator=quality. CCC omits all -g options because its parser interprets -g0 as enabling debug. Each compiler uses its own optimizer; -O2 does not imply identical effort or codegen features.')
p('Artifact target defaults also differ: the Buster profile reports cpu=znver4 and vector_bits=512, while CCC and Clang use their default x86-64 configurations. This compares the recorded native defaults, not an identical CPU-feature/cost-model sweep. Buster profiles report no native/split SIMD operations for the scalar corpus; Clang uses SSE2 in its reduction. Host compiler ISA and emitted-program ISA are distinct.')
p('Compilation observations end at objects. Runtime observations link those objects using the same Clang 20 -no-pie driver to control linker/runtime differences. Separate untimed probes confirm each compiler\'s own standalone linking on no-header and stdio programs. Large-project link speed, LTO, runtime loader cost and multi-target execution are not measured.')
sub('Inputs and sampling')
p('Four deterministic exported scalar-function sizes, one 1,024-function macro generator, the eight-kernel TU, stock cJSON 1.7.19 and its small driver. cJSON pin c859b25da02955fef659d658b8f324b5cde87be3. The library source is unchanged and its MIT license is included. Unsigned arithmetic avoids signed-overflow UB; floating operations use exact binary fractions. Checksums are consumed and checked before and during timing.')
p('Parent and child affinity CPU0; shared host activity remains possible. Seven rotating compile samples, five rotating runtime samples, no overlapping timed workers. Raw minima/maxima, compiler/input SHA-256, command argv, validation outputs and failures are retained. Three independent C wait4 RSS observations repair the Python pre-exec floor; the original data remain available.')
sub('What remains unranked')
p('General C standard compliance; broad optimizer soundness; security defect rates; Zen 5 throughput; instruction-cache/DRAM behavior; compilation/function/TU concurrency scaling; full Linux/kernel/PostgreSQL/FFmpeg compatibility; wide-FP target execution; linker performance on real projects; debugging variables/stepping end-to-end. Source capability comparisons and historical reports are explicitly distinct from measured results.')
p('No universal speedup is obtained by averaging unrelated dimensions. The optional equal-weight runtime geometric mean in summary.json is only a descriptive statistic for this selected corpus and is not used to declare a general winner.','SmallX')
p('Frozen raw_results.json SHA-256:<br/>'+hashlib.sha256((ROOT/'raw_results.json').read_bytes()).hexdigest(),'SmallX')

# 12. Source map.
page();h('Primary source map and evidence package')
p('All source claims refer to the pinned commits above. Local analysis notes include precise symbol/line references; links below point to the inspected implementations. The February engineering article is historical primary reporting, not current measured proof.','SmallX')
refs=[
('Buster active compiler catalogue','buster','docs/projects/compiler.md'),
('Buster canonical FAST pass contract','buster','docs/canonical-fast-pipeline.md'),
('Buster FAST transforms','buster','src/buster/lib/compiler/ir/ir_fast.c'),
('Buster driver / allocator / target behavior','buster','src/buster/lib/compiler/driver/driver.c'),
('Buster CLI and multi-TU scheduling','buster','docs/agents/driver.md'),
('Buster atomic type and access contracts','buster','docs/agents/frontend/atomics.md'),
('Buster wide-float boundary','buster','docs/agents/frontend/wide-floats-assembly.md'),
('Buster compact lexer guards','buster','src/buster/lib/compiler/frontend/c/c_internal.h'),
('Buster build and self-host contracts','buster','docs/agents/build.md'),
('Buster validation/CI','buster','docs/agents/testing.md'),
('Buster reproducible performance harness','buster','tools/throughput/README.md'),
('CCC optimizer orchestration and analysis reuse','ccc','src/passes/mod.rs'),
('CCC register allocation','ccc','src/backend/regalloc.rs'),
('CCC option handling','ccc','src/driver/cli.rs'),
('CCC source pipeline and fortify erasure','ccc','src/driver/pipeline.rs'),
('CCC atomic qualifier erasure','ccc','src/frontend/parser/types.rs'),
('CCC scalar AVX-512 header','ccc','include/avx512fintrin.h'),
('CCC debug directive dropping','ccc','src/backend/elf_writer_common.rs'),
('CCC CPU support builtin','ccc','src/ir/lowering/expr_builtins.rs'),
('CCC GNU error call lowering','ccc','src/ir/lowering/expr_calls.rs'),
('CCC current project claims and disclaimer','ccc','README.md'),
('CCC project tracker (mixed outcomes)','ccc','ideas/new_projects_myasm.txt'),
]
for i,(label,repo,path) in enumerate(refs,1):
 full='buster14a/buster' if repo=='buster' else 'anthropics/claudes-c-compiler'
 p(f'{i}. '+link(label,f'https://github.com/{full}/blob/{PINS[repo]}/{path}'),'SmallX')
p('23. '+link('Anthropic historical compiler engineering article','https://www.anthropic.com/engineering/building-c-compiler'),'SmallX')
p('24. '+link('Buster intrinsic-header compatibility issue #1419','https://github.com/buster14a/buster/issues/1419'),'SmallX')
sub('Package contents')
p('Buster_vs_Claude_C_Compiler_evidence.zip contains generated and stock workload sources, benchmark.py, C wait4 RSS observer, raw_results.json, summary.json, all feature probes and disassembly, untimed profiles, measurement notes, pinned-source audit notes, a build/reproduction README, and this report generator. Compiler binaries and repository clones are omitted; rebuild from the pinned repositories.','SmallX')

def footer(canvas,doc):
 canvas.saveState();canvas.setStrokeColor(HexColor('#d8e2e8'));canvas.line(42,39,553,39)
 canvas.setFont('CompareSans',8);canvas.setFillColor(GRAY)
 canvas.drawString(42,25,'Buster / CCC | 2026-09-29 | Pinned-source exploratory comparison')
 canvas.drawRightString(553,25,str(doc.page));canvas.restoreState()
doc=SimpleDocTemplate(str(OUT/'Buster_vs_Claude_C_Compiler.pdf'),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=40,bottomMargin=52,title='Buster vs Claude\'s C Compiler',author='Compiler comparison')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT/'Buster_vs_Claude_C_Compiler.pdf')
