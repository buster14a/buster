/* Tiny timer avoids Python's pre-exec RSS floor for very small compilers. */
#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
int main(int argc,char **argv) {
    struct timespec begin,end;
    struct rusage usage;
    pid_t child,waited;
    int status;
    FILE *stream;
    if(argc<3) return 2;
    clock_gettime(CLOCK_MONOTONIC,&begin);
    child=fork();
    if(child<0) return 3;
    if(child==0) { execvp(argv[2],argv+2); _exit(127); }
    do { waited=wait4(child,&status,0,&usage); } while(waited<0 && errno==EINTR);
    if(waited<0) return 4;
    clock_gettime(CLOCK_MONOTONIC,&end);
    stream=fopen(argv[1],"w");
    if(!stream) return 5;
    fprintf(stream,"{\"wall_s\":%.9f,\"peak_rss_kib\":%ld,\"user_s\":%.9f,\"system_s\":%.9f}",
        (double)(end.tv_sec-begin.tv_sec)+(double)(end.tv_nsec-begin.tv_nsec)*1e-9,
        usage.ru_maxrss,(double)usage.ru_utime.tv_sec+(double)usage.ru_utime.tv_usec*1e-6,
        (double)usage.ru_stime.tv_sec+(double)usage.ru_stime.tv_usec*1e-6);
    fclose(stream);
    return WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status);
}
