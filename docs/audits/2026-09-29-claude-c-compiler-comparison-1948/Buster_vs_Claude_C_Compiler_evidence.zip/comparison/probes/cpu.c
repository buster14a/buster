int main(void) { return __builtin_cpu_supports("avx512f") ? 0 : 1; }
