typedef unsigned long long V8 __attribute__((vector_size(64)));
void vector_add(V8 *out,const V8 *a,const V8 *b) { *out=*a+*b; }
