#include <immintrin.h>
void add512(void *restrict out, const void *restrict a, const void *restrict b) { __m512i x=_mm512_loadu_si512(a); __m512i y=_mm512_loadu_si512(b); _mm512_storeu_si512(out, _mm512_add_epi64(x,y)); }
