import json,pathlib,subprocess,re
HERE=pathlib.Path(__file__).resolve().parent;WORK=HERE.parent.parent
DATA=json.loads((HERE/'results.json').read_text())
def run(cmd):
 p=subprocess.run(cmd,text=True,cwd=WORK,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
 r={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};DATA['commands'].append(r);return r
COMPILERS={'buster':[str(WORK/'buster/build/Release/ide'),'cc'],'ccc':[str(WORK/'ccc/target/release/ccc')],'clang20':['/usr/bin/clang-20']}
cmd=COMPILERS['buster']+['-D_FORTIFY_SOURCE=2','-E',str(HERE/'fortify.c')]
r=run(cmd);DATA['summary']['buster']['fortify_without_P']={'compile_exit':r['exit_code'],'preprocessed':r['stdout'],'stderr':r['stderr']}
(HERE/'native_vector.c').write_text('typedef unsigned long long V8 __attribute__((vector_size(64)));\nvoid vector_add(V8 *out,const V8 *a,const V8 *b) { *out=*a+*b; }\n')
for name,base in COMPILERS.items():
 flags=['-O2'];flags+=['-mavx512f'] if name=='ccc' else ['-g0','-march=znver5']
 obj=HERE/(name+'_native_vector.o');r=run(base+flags+['-c',str(HERE/'native_vector.c'),'-o',str(obj)])
 summary={'compile_exit':r['exit_code'],'stderr':r['stderr']}
 if r['exit_code']==0:
  d=run(['/usr/bin/objdump','-dr',str(obj)]);(HERE/(name+'_native_vector.disasm.txt')).write_text(d['stdout'])
  summary.update({'zmm_in_disasm':'zmm' in d['stdout'],'vpaddq_count':len(re.findall(r'\bvpaddq\b',d['stdout'])),'disasm':d['stdout']})
 DATA['summary'][name]['native_vector']=summary
(HERE/'results.json').write_text(json.dumps(DATA,indent=2))
print(json.dumps({n:{k:v for k,v in x.items() if k in ['native_vector','fortify_without_P']} for n,x in DATA['summary'].items()},indent=2))
