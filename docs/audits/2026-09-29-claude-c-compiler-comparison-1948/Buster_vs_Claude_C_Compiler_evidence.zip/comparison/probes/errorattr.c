void forbidden(void) __attribute__((error("forbidden_called")));
void trigger(void) { forbidden(); }
