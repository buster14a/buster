_Atomic unsigned long counter;
unsigned long bump(void) { return counter++; }
