#ifdef _FORTIFY_SOURCE
int requested_fortify = _FORTIFY_SOURCE;
#else
int requested_fortify = 0;
#endif
