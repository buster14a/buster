import json, pathlib, subprocess, re, os
HERE=pathlib.Path(__file__).resolve().parent
WORK=HERE.parent.parent
SOURCES={
'no_header':'int main(void) { return 0; }\n',
'stdio':'#include <stdio.h>\nint main(void) { puts("compiler-probe-ok"); return 0; }\n',
'debug':'int square(int x) { int y=x*x; return y+1; }\n',
'atomic':'_Atomic unsigned long counter;\nunsigned long bump(void) { return counter++; }\n',
'cpu':'int main(void) { return __builtin_cpu_supports("avx512f") ? 0 : 1; }\n',
'fortify':'#ifdef _FORTIFY_SOURCE\nint requested_fortify = _FORTIFY_SOURCE;\n#else\nint requested_fortify = 0;\n#endif\n',
'errorattr':'void forbidden(void) __attribute__((error("forbidden_called")));\nvoid trigger(void) { forbidden(); }\n',
'avx512':'#include <immintrin.h>\nvoid add512(void *restrict out, const void *restrict a, const void *restrict b) { __m512i x=_mm512_loadu_si512(a); __m512i y=_mm512_loadu_si512(b); _mm512_storeu_si512(out, _mm512_add_epi64(x,y)); }\n',
}
for name,text in SOURCES.items(): (HERE/(name+'.c')).write_text(text)
COMPILERS={'buster':[str(WORK/'buster/build/Release/ide'),'cc'],'ccc':[str(WORK/'ccc/target/release/ccc')],'clang20':['/usr/bin/clang-20']}
DATA={'scope':'Untimed feature probes on EPYC9V74 VM. Valid GCC/Clang GNU C source; standalone links use each compiler own default link path. No claims of race correctness from disassembly alone.','compiler_versions':{},'commands':[],'summary':{}}
def run(cmd):
    try:
        p=subprocess.run(cmd,cwd=WORK,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
        r={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    except subprocess.TimeoutExpired as e:
        r={'command':cmd,'exit_code':'timeout20s','stdout':str(e.stdout),'stderr':str(e.stderr)}
    DATA['commands'].append(r)
    return r
for compiler,cmd in COMPILERS.items():
    v=run(cmd+['--version']); DATA['compiler_versions'][compiler]=v
    DATA['summary'][compiler]={}
    for name in ['no_header','stdio','debug','atomic','cpu','fortify','errorattr','avx512']:
        source=str(HERE/(name+'.c'))
        prefix=cmd+['-O2']
        if compiler!='ccc': prefix+=['-g0']
        suffix=[]
        if name in ['no_header','stdio','cpu']:
            output=HERE/(compiler+'_'+name)
            suffix=['-o',str(output)]
        elif name=='fortify':
            output=None
            suffix=['-D_FORTIFY_SOURCE=2','-E','-P']
        else:
            output=HERE/(compiler+'_'+name+'.o')
            suffix=['-c','-o',str(output)]
            if name=='debug': prefix=[a for a in prefix if a!='-g0']+['-g']
            if name=='avx512':
                if compiler=='ccc': prefix+=['-mavx512f']
                else: prefix+=['-march=znver5','-isystem','/usr/lib/llvm-20/lib/clang/20/include']
        r=run(prefix+suffix+[source]); summary={'compile_exit':r['exit_code']}
        if r['exit_code']==0:
            if name in ['no_header','stdio','cpu']:
                executed=run([str(output)]); summary.update({'runtime_exit':executed['exit_code'],'runtime_stdout':executed['stdout']})
            elif name=='fortify':
                summary['preprocessed']=r['stdout']
            elif name in ['debug','atomic','avx512']:
                if name=='debug':
                    sections=run(['/usr/bin/readelf','-SW',str(output)])
                    summary['debug_sections']=[line for line in sections['stdout'].splitlines() if '.debug_' in line or '.eh_frame' in line]
                    summary['has_debug_info']='.debug_info' in sections['stdout']
                    summary['has_debug_line']='.debug_line' in sections['stdout']
                else:
                    dump=run(['/usr/bin/objdump','-dr',str(output)])
                    (HERE/(compiler+'_'+name+'.disasm.txt')).write_text(dump['stdout'])
                    summary['lock_in_disasm']='lock ' in dump['stdout']
                    summary['zmm_in_disasm']='zmm' in dump['stdout']
                    summary['vpaddq_count']=len(re.findall(r'\bvpaddq\b',dump['stdout']))
                    summary['scalar_add_count']=len(re.findall(r'\badd\s',dump['stdout']))
                    summary['disasm_lines']=len(dump['stdout'].splitlines())
        else:
            summary['stderr_excerpt']=r['stderr'][:900]
        DATA['summary'][compiler][name]=summary
        (HERE/'results.json').write_text(json.dumps(DATA,indent=2))
print(json.dumps(DATA['summary'],indent=2))
