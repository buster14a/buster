#include <stdio.h>
int main(void) { puts("compiler-probe-ok"); return 0; }
