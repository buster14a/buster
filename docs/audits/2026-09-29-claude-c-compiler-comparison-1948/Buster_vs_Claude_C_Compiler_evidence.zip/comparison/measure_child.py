#!/usr/bin/env python3
"""Measure exactly one compiler child; no GNU time dependency required."""
import json, resource, subprocess, sys, time
start=time.perf_counter_ns()
result=subprocess.run(sys.argv[2:])
elapsed=(time.perf_counter_ns()-start)/1e9
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
with open(sys.argv[1],'w') as stream:
    json.dump({'wall_s':elapsed,'peak_rss_kib':usage.ru_maxrss,'user_s':usage.ru_utime,'system_s':usage.ru_stime},stream)
raise SystemExit(result.returncode)
