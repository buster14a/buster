#!/usr/bin/env python3
"""Exploratory compiler comparison; run only after compiler builds stop.

python3 benchmark.py --generate   # write deterministic compile workloads
python3 benchmark.py --run        # validate, measure, save every raw sample
"""
import argparse, hashlib, json, os, pathlib, platform, statistics, subprocess, sys, time

ROOT=pathlib.Path(__file__).resolve().parent
WORK=ROOT.parent
SOURCES=ROOT/'sources'
OUT=ROOT/'outputs'
COMMON=['-O2','-std=gnu17','-fno-pic']
COMPILERS={
    'buster_fast':[str(WORK/'buster/build/Release/ide'),'cc']+COMMON+['-g0'],
    'buster_quality':[str(WORK/'buster/build/Release/ide'),'cc']+COMMON+['-g0','-fregister-allocator=quality'],
    'ccc':[str(WORK/'ccc/target/release/ccc')]+COMMON,
    'clang20':['/usr/bin/clang-20']+COMMON,
}
KERNELS=['reduction','division','licm','gvn','inlining','branches','memory','floating']

def generate():
    SOURCES.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
    for n in [4,32,512,4096]:
        lines=['typedef unsigned long long U64;']
        for i in range(n):
            lines.append(f'U64 f{i}(U64 x,U64 y) {{ x=(x^y)*{(i%127)*2+3}ull; y=(y+x)>>{i%23+1}u; return (x+y)^(x<<{i%17+1}u); }}')
        (SOURCES/f'scalar_{n}.c').write_text('\n'.join(lines)+'\n')
    lines=['typedef unsigned long long U64;', '#define CAT_(a,b) a##b', '#define CAT(a,b) CAT_(a,b)', '#define STEP(x,y,c) (((x)^(y))*(c)+(x))', '#define FN(i,c) U64 CAT(macro_,i)(U64 x,U64 y) { return STEP(STEP(STEP(x,y,c),y,c),x,c); }']
    lines += [f'FN({i},{(i%127)*2+3}ull)' for i in range(1024)]
    (SOURCES/'macro_1024.c').write_text('\n'.join(lines)+'\n')

def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def run(cmd,timeout=180):
    start=time.perf_counter_ns()
    try: p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        return {'command':cmd,'wall_s':(time.perf_counter_ns()-start)/1e9,'exit_code':-999,'stdout':str(exc.stdout),'stderr':str(exc.stderr),'timed_out_s':timeout}
    return {'command':cmd,'wall_s':(time.perf_counter_ns()-start)/1e9,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
def text_size(path):
    p=run(['/usr/bin/size','-A',str(path)])
    rows=[line.split() for line in p['stdout'].splitlines()]
    return sum(int(row[1]) for row in rows if len(row)>1 and (row[0]=='.text' or row[0].startswith('.text.')))
def git_head(repo):
    return subprocess.run(['git','rev-parse','HEAD'],cwd=WORK/repo,text=True,stdout=subprocess.PIPE,check=True).stdout.strip()
def summarize(samples):
    vals=[s['wall_s'] for s in samples if s['exit_code']==0]
    return {'median_s':statistics.median(vals),'min_s':min(vals),'max_s':max(vals)} if vals else None
def benchmark():
    generate()
    subprocess.run(['/usr/bin/clang-20','-O2',str(ROOT/'measure_child.c'),'-o',str(ROOT/'measure_child')],check=True)
    for command in COMPILERS.values():
        if not pathlib.Path(command[0]).is_file(): raise SystemExit(f'Compiler missing: {command[0]}')
    affinity=None
    try:
        affinity=sorted(os.sched_getaffinity(0)); os.sched_setaffinity(0,{affinity[0]})
    except (AttributeError,OSError): pass
    data={'methods':{'compile_samples':7,'runtime_samples':5,'common_flags':COMMON,'debug_policy':'Buster -g0 because debug defaults on. CCC omits all -g flags because it interprets -g0 as debug on. Clang omits -g (debug defaults off).','linker':['/usr/bin/clang-20','-no-pie'],'affinity_before':affinity,'affinity_used':sorted(os.sched_getaffinity(0)) if affinity else None,'host_scope':'Hosted EPYC 9V74 VM, exploratory; not Zen 5, not acceptance/performance evidence. Shared VM and unrelated background build observed; affinity cannot exclude neighbor/host load.','wall_clock':'time.perf_counter_ns around subprocess, includes spawn/startup; RSS and compile wall time from tiny C fork/exec/wait4 wrapper ru_maxrss in KiB and CLOCK_MONOTONIC around compiler child; excludes timing wrapper startup; full compiler process.','runtime_policy':'Exact stdout oracle checks for seeds 1/123456789/4294967295 and repetitions 1/3/19; timings seed123456789. Same kernel-specific repetitions for all compilers, chosen by iterative Clang20 ~50ms calibration. Includes process startup and array initialization.','optimization_semantics':'-O2 is each compiler native implementation; does not imply equal optimization pipelines. Buster QUALITY differs only allocator option.','source_status':'Synthetic benchmark, no system headers; unsigned arithmetic wraparound; FP exact power-of-two operations, union representation checksum. Stock cJSON1.7.19 unmodified.'},'provenance':{'timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'platform':platform.platform(),'cpuinfo':pathlib.Path('/proc/cpuinfo').read_text(),'commits':{repo:git_head(repo) for repo in ['buster','ccc']},'compilers':{name:{'command_prefix':cmd,'binary_sha256':sha(cmd[0]),'binary_bytes':pathlib.Path(cmd[0]).stat().st_size} for name,cmd in COMPILERS.items()},'sources':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(SOURCES.glob('*')) if p.is_file()},'process_load_start':run(['ps','-eo','comm,pcpu'])['stdout']},'compile':{},'runtime':{},'validation':[]}
    def save(): (ROOT/'raw_results.json').write_text(json.dumps(data,indent=2)+'\n')
    # Validate all runtime objects and oracle stdout before publishing any runtime speed.
    executables={}
    for name,prefix in COMPILERS.items():
        obj=OUT/f'runtime_{name}.o'; exe=OUT/f'runtime_{name}'
        result=run(prefix+['-c',str(SOURCES/'runtime.c'),'-o',str(obj)])
        data['validation'].append({'compiler':name,'stage':'runtime_compile',**result}); save()
        if result['exit_code']!=0: continue
        result=run(['/usr/bin/clang-20','-no-pie',str(obj),'-o',str(exe)])
        data['validation'].append({'compiler':name,'stage':'runtime_link',**result}); save()
        if result['exit_code']==0: executables[name]=exe
    if 'clang20' not in executables: raise RuntimeError('Oracle did not compile/link')
    good={kernel:set(executables) for kernel in KERNELS}
    for k,kernel in enumerate(KERNELS):
        for seed in [1,123456789,4294967295]:
            for reps in [1,3,19]:
                oracle=run([str(executables['clang20']),str(k),str(reps),str(seed)])
                for name in executables:
                    if name=='clang20': continue
                    result=run([str(executables[name]),str(k),str(reps),str(seed)])
                    equal=result['exit_code']==0 and result['stdout']==oracle['stdout']
                    data['validation'].append({'compiler':name,'kernel':kernel,'seed':seed,'reps':reps,'expected':oracle['stdout'],'match':equal,**result})
                    if not equal: good[kernel].discard(name)
        save()
    data['methods']['runtime_validated_compilers']={kernel:sorted(names) for kernel,names in good.items()}; save()
    print('Validated runtime compilers:',data['methods']['runtime_validated_compilers'],flush=True)
    # Compile-only measurements alternate compiler order each round.
    names=list(COMPILERS)
    for source in sorted(SOURCES.glob('*.c')):
        data['compile'][source.name]={name:{'samples':[]} for name in names}
        for name in names: # unmeasured warmup also detects unsupported workloads
            obj=OUT/f'{source.stem}_{name}.o'
            r=run(COMPILERS[name]+['-c',str(source),'-o',str(obj)])
            row=data['compile'][source.name][name]; row['warmup']=r
            if r['exit_code']==0: row['text_bytes']=text_size(obj); row['object_bytes']=obj.stat().st_size
        save()
        for round_i in range(7):
            order=names[round_i%len(names):]+names[:round_i%len(names)]
            if round_i%2: order.reverse()
            for name in order:
                row=data['compile'][source.name][name]
                if row['warmup']['exit_code']!=0: continue
                obj=OUT/f'{source.stem}_{name}.o'; rssfile=OUT/'child_usage.json'
                compile_cmd=COMPILERS[name]+['-c',str(source),'-o',str(obj)]
                result=run([str(ROOT/'measure_child'),str(rssfile)]+compile_cmd)
                result['measurement_command']=result['command']; result['command']=compile_cmd
                result['measurement_wrapper_wall_s']=result['wall_s']
                try: result.update(json.loads(rssfile.read_text()))
                except (ValueError,FileNotFoundError): result['peak_rss_kib']=None
                result['round']=round_i; row['samples'].append(result); save()
        for name,row in data['compile'][source.name].items():
            row['summary']=summarize(row['samples'])
            rss=[s['peak_rss_kib'] for s in row['samples'] if s['exit_code']==0 and s['peak_rss_kib'] is not None]
            if rss: row['summary']['median_peak_rss_kib']=statistics.median(rss)
        save(); print('Measured compilation',source.name,flush=True)
    # Choose same repetitions per kernel based on Clang20, cap pathological lengths.
    for k,kernel in enumerate(KERNELS):
        active=[n for n in names if n in good[kernel]]
        reps=1000
        calibrations=[]
        for attempt in range(5):
            calibration=run([str(executables['clang20']),str(k),str(reps),'123456789']); calibrations.append(calibration)
            if calibration['wall_s']>=0.035 or reps>=20000000: break
            reps=max(reps+1,min(20000000,int(reps*0.05/max(0.001,calibration['wall_s']-0.001))))
        expected=run([str(executables['clang20']),str(k),str(reps),'123456789'])['stdout']
        data['runtime'][kernel]={'reps':reps,'calibrations':calibrations,'expected':expected,'compilers':{name:{'samples':[],'text_bytes':text_size(OUT/f'runtime_{name}.o')} for name in active}}
        for name in active: # warmup and verify full timed workload
            result=run([str(executables[name]),str(k),str(reps),'123456789'])
            data['runtime'][kernel]['compilers'][name]['warmup']=result
            if result['exit_code']!=0 or result['stdout']!=expected: raise RuntimeError(f'Full runtime mismatch {name} {kernel}')
        for round_i in range(5):
            order=active[round_i%len(active):]+active[:round_i%len(active)]
            if round_i%2: order.reverse()
            for name in order:
                result=run([str(executables[name]),str(k),str(reps),'123456789'])
                result['round']=round_i; result['checksum_match']=result['exit_code']==0 and result['stdout']==expected
                data['runtime'][kernel]['compilers'][name]['samples'].append(result); save()
                if not result['checksum_match']: raise RuntimeError(f'Timed runtime mismatch {name} {kernel}')
        for name,row in data['runtime'][kernel]['compilers'].items(): row['summary']=summarize(row['samples'])
        save(); print('Measured runtime',kernel,'reps',reps,flush=True)
    # Stock pinned cJSON parse/print/free end-to-end workload, common CRT/libm.
    cjson_exes={}
    for name in names:
        if data['compile']['cJSON.c'][name]['warmup']['exit_code']!=0 or data['compile']['cjson_driver.c'][name]['warmup']['exit_code']!=0: continue
        exe=OUT/f'cjson_{name}'
        result=run(['/usr/bin/clang-20','-no-pie',str(OUT/f'cJSON_{name}.o'),str(OUT/f'cjson_driver_{name}.o'),'-lm','-o',str(exe)])
        data['validation'].append({'compiler':name,'stage':'cjson_link',**result})
        if result['exit_code']==0: cjson_exes[name]=exe
    if 'clang20' in cjson_exes:
        good_cjson=set(cjson_exes)
        for reps in [1,3,19]:
            oracle=run([str(cjson_exes['clang20']),str(reps)])
            for name in cjson_exes:
                result=run([str(cjson_exes[name]),str(reps)])
                match=result['exit_code']==0 and result['stdout']==oracle['stdout']
                data['validation'].append({'compiler':name,'kernel':'cjson_parse_print','reps':reps,'expected':oracle['stdout'],'match':match,**result})
                if not match: good_cjson.discard(name)
        reps=1000; calibrations=[]
        for attempt in range(5):
            result=run([str(cjson_exes['clang20']),str(reps)]); calibrations.append(result)
            if result['wall_s']>=0.035 or reps>=1000000: break
            reps=max(reps+1,min(1000000,int(reps*0.05/max(0.001,result['wall_s']-0.001))))
        expected=run([str(cjson_exes['clang20']),str(reps)])['stdout']
        active=[name for name in names if name in good_cjson]
        rows={name:{'samples':[],'text_bytes':text_size(OUT/f'cJSON_{name}.o')+text_size(OUT/f'cjson_driver_{name}.o')} for name in active}
        data['runtime']['cjson_parse_print']={'reps':reps,'calibrations':calibrations,'expected':expected,'compilers':rows}
        for name in active:
            result=run([str(cjson_exes[name]),str(reps)]); rows[name]['warmup']=result
            if result['exit_code']!=0 or result['stdout']!=expected: raise RuntimeError(f'Full cJSON runtime mismatch {name}')
        for round_i in range(5):
            order=active[round_i%len(active):]+active[:round_i%len(active)]
            if round_i%2: order.reverse()
            for name in order:
                result=run([str(cjson_exes[name]),str(reps)])
                result['round']=round_i; result['checksum_match']=result['exit_code']==0 and result['stdout']==expected
                rows[name]['samples'].append(result); save()
                if not result['checksum_match']: raise RuntimeError(f'Timed cJSON runtime mismatch {name}')
        for name,row in rows.items(): row['summary']=summarize(row['samples'])
        print('Measured runtime cJSON parse/print reps',reps,flush=True)
    data['provenance']['process_load_end']=run(['ps','-eo','comm,pcpu'])['stdout']; save()

def refresh_rss():
    """Repair RSS floor without changing accepted wall/runtime samples."""
    subprocess.run(['/usr/bin/clang-20','-O2',str(ROOT/'measure_child.c'),'-o',str(ROOT/'measure_child')],check=True)
    data=json.loads((ROOT/'raw_results.json').read_text())
    try: os.sched_setaffinity(0,set(data['methods']['affinity_used']))
    except (TypeError,OSError): pass
    data['methods']['rss_refresh']={'samples':3,'method':'Tiny C fork/exec/wait4 wrapper ru_maxrss in KiB, exact compiler child; original Python wrapper child RSS had ~10MiB pre-exec floor and is retained in original compile samples for provenance. Compile wall and runtime samples unchanged.','timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'timer_sha256':sha(ROOT/'measure_child'),'timer_build':['/usr/bin/clang-20','-O2',str(ROOT/'measure_child.c'),'-o',str(ROOT/'measure_child')]}
    for source,rows in data['compile'].items():
        for name,row in rows.items():
            row['rss_samples']=[]
            if row['warmup']['exit_code']!=0: continue
            for round_i in range(3):
                usagefile=OUT/'rss_refresh.json'; compile_cmd=COMPILERS[name]+['-c',str(SOURCES/source),'-o',str(OUT/f'{pathlib.Path(source).stem}_{name}.o')]
                result=run([str(ROOT/'measure_child'),str(usagefile)]+compile_cmd)
                result['measurement_command']=result['command']; result['command']=compile_cmd
                result.update(json.loads(usagefile.read_text())); row['rss_samples'].append(result)
            row['summary']['median_peak_rss_kib_original_python']=row['summary']['median_peak_rss_kib']
            row['summary']['median_peak_rss_kib']=statistics.median(s['peak_rss_kib'] for s in row['rss_samples'] if s['exit_code']==0)
        (ROOT/'raw_results.json').write_text(json.dumps(data,indent=2)+'\n')
        print('Refreshed RSS',source,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--generate',action='store_true'); p.add_argument('--run',action='store_true'); p.add_argument('--rss-refresh',action='store_true'); args=p.parse_args()
    if args.generate: generate()
    if args.run: benchmark()
    if args.rss_refresh: refresh_rss()
