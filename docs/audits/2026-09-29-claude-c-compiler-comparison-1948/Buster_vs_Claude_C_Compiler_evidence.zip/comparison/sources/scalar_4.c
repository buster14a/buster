typedef unsigned long long U64;
U64 f0(U64 x,U64 y) { x=(x^y)*3ull; y=(y+x)>>1u; return (x+y)^(x<<1u); }
U64 f1(U64 x,U64 y) { x=(x^y)*5ull; y=(y+x)>>2u; return (x+y)^(x<<2u); }
U64 f2(U64 x,U64 y) { x=(x^y)*7ull; y=(y+x)>>3u; return (x+y)^(x<<3u); }
U64 f3(U64 x,U64 y) { x=(x^y)*9ull; y=(y+x)>>4u; return (x+y)^(x<<4u); }
