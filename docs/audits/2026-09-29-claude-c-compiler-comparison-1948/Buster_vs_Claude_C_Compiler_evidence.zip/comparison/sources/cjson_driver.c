#include "cJSON.h"
extern int printf(const char *, ...);
typedef unsigned long long U64;
static U64 parse(const char *s) { U64 x=0; while(*s>='0' && *s<='9') { x=x*10u+(U64)(*s-'0'); ++s; } return x; }
int main(int argc,char **argv) {
    const char *json="{\"items\":[{\"name\":\"Buster\",\"id\":14,\"enabled\":true},{\"name\":\"CCC\",\"id\":37,\"enabled\":false}],\"values\":[1,2,3,4,8,16,32,64,128,256],\"nested\":{\"null\":null,\"message\":\"compiler comparison\",\"binary_fraction\":1.25}}";
    U64 reps=argc>1?parse(argv[1]):1u,hash=0,r;
    for(r=0;r<reps;++r) {
        cJSON *root=cJSON_Parse(json);
        char *out; const unsigned char *p;
        if(!root) return 2;
        out=cJSON_PrintUnformatted(root); if(!out) return 3;
        p=(const unsigned char *)out;
        while(*p) { hash=(hash^*p)*1099511628211ull; ++p; }
        cJSON_free(out); cJSON_Delete(root);
    }
    printf("%016llx\n",hash); return 0;
}
