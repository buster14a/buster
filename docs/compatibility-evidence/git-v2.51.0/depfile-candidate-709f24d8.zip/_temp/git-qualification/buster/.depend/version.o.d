version.o: \
  version.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./version.h \
  ./strbuf.h \
  ./gettext.h \
  ./version-def.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./version.h:

./strbuf.h:

./gettext.h:

./version-def.h:
