trace.o: \
  trace.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./abspath.h \
  ./repository.h \
  ./strmap.h \
  ./hashmap.h \
  ./repo-settings.h \
  ./quote.h \
  ./setup.h \
  ./refs.h \
  ./commit.h \
  ./object.h \
  ./hash.h \
  ./sha1dc_git.h \
  ./sha1dc/sha1.h \
  ./sha256/block/sha256.h \
  ./add-interactive.h \
  ./color.h \
  ./string-list.h \
  ./trace.h \
  ./strbuf.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./abspath.h:

./repository.h:

./strmap.h:

./hashmap.h:

./repo-settings.h:

./quote.h:

./setup.h:

./refs.h:

./commit.h:

./object.h:

./hash.h:

./sha1dc_git.h:

./sha1dc/sha1.h:

./sha256/block/sha256.h:

./add-interactive.h:

./color.h:

./string-list.h:

./trace.h:

./strbuf.h:
