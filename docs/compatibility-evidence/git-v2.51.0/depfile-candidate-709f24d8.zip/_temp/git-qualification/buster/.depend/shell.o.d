shell.o: \
  shell.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./quote.h \
  ./exec-cmd.h \
  ./strbuf.h \
  ./run-command.h \
  ./thread-utils.h \
  ./strvec.h \
  ./alias.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./quote.h:

./exec-cmd.h:

./strbuf.h:

./run-command.h:

./thread-utils.h:

./strvec.h:

./alias.h:
