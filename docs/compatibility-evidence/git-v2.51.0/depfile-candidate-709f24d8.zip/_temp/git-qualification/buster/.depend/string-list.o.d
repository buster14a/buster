string-list.o: \
  string-list.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./string-list.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./string-list.h:
