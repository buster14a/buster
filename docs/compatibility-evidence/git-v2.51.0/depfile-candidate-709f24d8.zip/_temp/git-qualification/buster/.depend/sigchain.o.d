sigchain.o: \
  sigchain.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./sigchain.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./sigchain.h:
