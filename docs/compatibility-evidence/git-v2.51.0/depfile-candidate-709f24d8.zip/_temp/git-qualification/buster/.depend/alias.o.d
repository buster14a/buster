alias.o: \
  alias.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./alias.h \
  ./config.h \
  ./hashmap.h \
  ./string-list.h \
  ./repository.h \
  ./strmap.h \
  ./repo-settings.h \
  ./parse.h \
  ./gettext.h \
  ./strbuf.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./alias.h:

./config.h:

./hashmap.h:

./string-list.h:

./repository.h:

./strmap.h:

./repo-settings.h:

./parse.h:

./gettext.h:

./strbuf.h:
