write-or-die.o: \
  write-or-die.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./parse.h \
  ./run-command.h \
  ./thread-utils.h \
  ./strvec.h \
  ./write-or-die.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./parse.h:

./run-command.h:

./thread-utils.h:

./strvec.h:

./write-or-die.h:
