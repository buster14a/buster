tree-diff.o: \
  tree-diff.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./diff.h \
  ./hash.h \
  ./sha1dc_git.h \
  ./sha1dc/sha1.h \
  ./sha256/block/sha256.h \
  ./repository.h \
  ./strmap.h \
  ./hashmap.h \
  ./repo-settings.h \
  ./pathspec.h \
  ./strbuf.h \
  ./diffcore.h \
  ./tree.h \
  ./object.h \
  ./tree-walk.h \
  ./environment.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./diff.h:

./hash.h:

./sha1dc_git.h:

./sha1dc/sha1.h:

./sha256/block/sha256.h:

./repository.h:

./strmap.h:

./hashmap.h:

./repo-settings.h:

./pathspec.h:

./strbuf.h:

./diffcore.h:

./tree.h:

./object.h:

./tree-walk.h:

./environment.h:
