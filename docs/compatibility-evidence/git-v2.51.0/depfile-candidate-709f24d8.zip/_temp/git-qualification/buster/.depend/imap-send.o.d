imap-send.o: \
  imap-send.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./advice.h \
  ./config.h \
  ./hashmap.h \
  ./string-list.h \
  ./repository.h \
  ./strmap.h \
  ./repo-settings.h \
  ./parse.h \
  ./credential.h \
  ./strvec.h \
  ./environment.h \
  ./gettext.h \
  ./run-command.h \
  ./thread-utils.h \
  ./parse-options.h \
  ./setup.h \
  ./refs.h \
  ./commit.h \
  ./object.h \
  ./hash.h \
  ./sha1dc_git.h \
  ./sha1dc/sha1.h \
  ./sha256/block/sha256.h \
  ./add-interactive.h \
  ./color.h \
  ./strbuf.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./advice.h:

./config.h:

./hashmap.h:

./string-list.h:

./repository.h:

./strmap.h:

./repo-settings.h:

./parse.h:

./credential.h:

./strvec.h:

./environment.h:

./gettext.h:

./run-command.h:

./thread-utils.h:

./parse-options.h:

./setup.h:

./refs.h:

./commit.h:

./object.h:

./hash.h:

./sha1dc_git.h:

./sha1dc/sha1.h:

./sha256/block/sha256.h:

./add-interactive.h:

./color.h:

./strbuf.h:
