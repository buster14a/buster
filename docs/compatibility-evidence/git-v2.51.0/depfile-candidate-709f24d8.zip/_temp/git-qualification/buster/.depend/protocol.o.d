protocol.o: \
  protocol.c \
  ./git-compat-util.h \
  ./compat/posix.h \
  ./compat/../sane-ctype.h \
  ./compat/bswap.h \
  ./wrapper.h \
  ./banned.h \
  ./config.h \
  ./hashmap.h \
  ./string-list.h \
  ./repository.h \
  ./strmap.h \
  ./repo-settings.h \
  ./parse.h \
  ./environment.h \
  ./protocol.h \
  ./trace2.h

./git-compat-util.h:

./compat/posix.h:

./compat/../sane-ctype.h:

./compat/bswap.h:

./wrapper.h:

./banned.h:

./config.h:

./hashmap.h:

./string-list.h:

./repository.h:

./strmap.h:

./repo-settings.h:

./parse.h:

./environment.h:

./protocol.h:

./trace2.h:
