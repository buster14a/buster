progress.o: progress.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h pager.h \
  progress.h gettext.h repository.h strmap.h hashmap.h repo-settings.h \
  strbuf.h trace.h trace2.h utf8.h parse.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
pager.h:
progress.h:
gettext.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
strbuf.h:
trace.h:
trace2.h:
utf8.h:
parse.h:
