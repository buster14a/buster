scalar.o: scalar.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  gettext.h parse-options.h config.h hashmap.h string-list.h \
  repository.h strmap.h repo-settings.h parse.h run-command.h \
  thread-utils.h strvec.h simple-ipc.h pkt-line.h strbuf.h \
  fsmonitor-ipc.h fsmonitor-settings.h refs.h commit.h object.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h add-interactive.h \
  color.h dir.h pathspec.h statinfo.h packfile.h list.h odb.h oidset.h \
  khash.h oidmap.h help.h setup.h trace2.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
gettext.h:
parse-options.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
run-command.h:
thread-utils.h:
strvec.h:
simple-ipc.h:
pkt-line.h:
strbuf.h:
fsmonitor-ipc.h:
fsmonitor-settings.h:
refs.h:
commit.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
add-interactive.h:
color.h:
dir.h:
pathspec.h:
statinfo.h:
packfile.h:
list.h:
odb.h:
oidset.h:
khash.h:
oidmap.h:
help.h:
setup.h:
trace2.h:
