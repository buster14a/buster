oidset.o: oidset.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h oidset.h \
  khash.h hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h hex.h \
  hex-ll.h strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
oidset.h:
khash.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
hex.h:
hex-ll.h:
strbuf.h:
