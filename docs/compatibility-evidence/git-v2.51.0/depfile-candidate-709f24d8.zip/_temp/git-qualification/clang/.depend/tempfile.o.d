tempfile.o: tempfile.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  path.h strbuf.h repository.h strmap.h hashmap.h repo-settings.h \
  tempfile.h list.h sigchain.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
path.h:
strbuf.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
tempfile.h:
list.h:
sigchain.h:
