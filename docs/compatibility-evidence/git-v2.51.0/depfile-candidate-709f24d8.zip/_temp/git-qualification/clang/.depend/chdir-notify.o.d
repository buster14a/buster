chdir-notify.o: chdir-notify.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  chdir-notify.h list.h path.h strbuf.h trace.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
chdir-notify.h:
list.h:
path.h:
strbuf.h:
trace.h:
