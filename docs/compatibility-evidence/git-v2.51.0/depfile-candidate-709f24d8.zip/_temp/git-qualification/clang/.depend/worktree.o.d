worktree.o: worktree.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  environment.h repo-settings.h gettext.h path.h strbuf.h repository.h \
  strmap.h hashmap.h refs.h commit.h object.h hash.h sha1dc_git.h \
  sha1dc/sha1.h sha256/block/sha256.h add-interactive.h color.h setup.h \
  string-list.h worktree.h dir.h pathspec.h statinfo.h wt-status.h \
  remote.h refspec.h strvec.h config.h parse.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
environment.h:
repo-settings.h:
gettext.h:
path.h:
strbuf.h:
repository.h:
strmap.h:
hashmap.h:
refs.h:
commit.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
add-interactive.h:
color.h:
setup.h:
string-list.h:
worktree.h:
dir.h:
pathspec.h:
statinfo.h:
wt-status.h:
remote.h:
refspec.h:
strvec.h:
config.h:
parse.h:
