strmap.o: strmap.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h strmap.h \
  hashmap.h mem-pool.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
strmap.h:
hashmap.h:
mem-pool.h:
