object.o: object.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h gettext.h \
  hex.h hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h hex-ll.h \
  object.h replace-object.h oidmap.h hashmap.h repository.h strmap.h \
  repo-settings.h odb.h list.h oidset.h khash.h string-list.h \
  thread-utils.h object-file.h git-zlib.h compat/zlib-compat.h blob.h \
  statinfo.h tree.h commit.h add-interactive.h color.h tag.h alloc.h \
  commit-graph.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
hex.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
hex-ll.h:
object.h:
replace-object.h:
oidmap.h:
hashmap.h:
repository.h:
strmap.h:
repo-settings.h:
odb.h:
list.h:
oidset.h:
khash.h:
string-list.h:
thread-utils.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
blob.h:
statinfo.h:
tree.h:
commit.h:
add-interactive.h:
color.h:
tag.h:
alloc.h:
commit-graph.h:
