streaming.o: streaming.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h convert.h \
  hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h repository.h \
  strmap.h hashmap.h repo-settings.h string-list.h environment.h \
  streaming.h object.h object-file.h git-zlib.h compat/zlib-compat.h \
  odb.h list.h oidset.h khash.h oidmap.h thread-utils.h replace-object.h \
  packfile.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
convert.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
string-list.h:
environment.h:
streaming.h:
object.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
replace-object.h:
packfile.h:
