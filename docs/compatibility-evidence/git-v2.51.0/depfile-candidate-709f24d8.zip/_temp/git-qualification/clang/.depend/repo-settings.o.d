repo-settings.o: repo-settings.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h config.h \
  hashmap.h string-list.h repository.h strmap.h repo-settings.h parse.h \
  midx.h pack-objects.h odb.h object.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h list.h oidset.h khash.h oidmap.h thread-utils.h \
  pack.h csum-file.h write-or-die.h packfile.h setup.h refs.h commit.h \
  add-interactive.h color.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
midx.h:
pack-objects.h:
odb.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
pack.h:
csum-file.h:
write-or-die.h:
packfile.h:
setup.h:
refs.h:
commit.h:
add-interactive.h:
color.h:
