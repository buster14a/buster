git-zlib.o: git-zlib.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h git-zlib.h \
  compat/zlib-compat.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
git-zlib.h:
compat/zlib-compat.h:
