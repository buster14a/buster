object-file.o: object-file.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h \
  bulk-checkin.h object.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h repository.h strmap.h hashmap.h repo-settings.h \
  convert.h string-list.h dir.h pathspec.h statinfo.h strbuf.h \
  environment.h fsck.h oidset.h khash.h gettext.h hex.h hex-ll.h loose.h \
  object-file-convert.h object-file.h git-zlib.h compat/zlib-compat.h \
  odb.h list.h oidmap.h thread-utils.h oidtree.h cbtree.h mem-pool.h \
  pack.h csum-file.h write-or-die.h packfile.h path.h read-cache-ll.h \
  setup.h refs.h commit.h add-interactive.h color.h streaming.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
bulk-checkin.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
convert.h:
string-list.h:
dir.h:
pathspec.h:
statinfo.h:
strbuf.h:
environment.h:
fsck.h:
oidset.h:
khash.h:
gettext.h:
hex.h:
hex-ll.h:
loose.h:
object-file-convert.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
odb.h:
list.h:
oidmap.h:
thread-utils.h:
oidtree.h:
cbtree.h:
mem-pool.h:
pack.h:
csum-file.h:
write-or-die.h:
packfile.h:
path.h:
read-cache-ll.h:
setup.h:
refs.h:
commit.h:
add-interactive.h:
color.h:
streaming.h:
