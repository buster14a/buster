mailinfo.o: mailinfo.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h config.h \
  hashmap.h string-list.h repository.h strmap.h repo-settings.h parse.h \
  environment.h gettext.h hex-ll.h utf8.h strbuf.h mailinfo.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
environment.h:
gettext.h:
hex-ll.h:
utf8.h:
strbuf.h:
mailinfo.h:
