loose.o: loose.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h path.h odb.h hashmap.h object.h list.h oidset.h \
  khash.h oidmap.h string-list.h thread-utils.h repository.h strmap.h \
  repo-settings.h hex.h hex-ll.h gettext.h loose.h lockfile.h tempfile.h \
  strbuf.h oidtree.h cbtree.h mem-pool.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
path.h:
odb.h:
hashmap.h:
object.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
repository.h:
strmap.h:
repo-settings.h:
hex.h:
hex-ll.h:
gettext.h:
loose.h:
lockfile.h:
tempfile.h:
strbuf.h:
oidtree.h:
cbtree.h:
mem-pool.h:
