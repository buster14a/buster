quote.o: quote.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h path.h quote.h strbuf.h strvec.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
path.h:
quote.h:
strbuf.h:
strvec.h:
