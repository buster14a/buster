prompt.o: prompt.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h parse.h \
  environment.h repo-settings.h run-command.h thread-utils.h strvec.h \
  strbuf.h prompt.h compat/terminal.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
parse.h:
environment.h:
repo-settings.h:
run-command.h:
thread-utils.h:
strvec.h:
strbuf.h:
prompt.h:
compat/terminal.h:
