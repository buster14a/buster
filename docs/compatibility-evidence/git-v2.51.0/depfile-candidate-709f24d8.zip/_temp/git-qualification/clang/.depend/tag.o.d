tag.o: tag.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h environment.h repo-settings.h tag.h \
  object.h hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h \
  repository.h strmap.h hashmap.h object-name.h strbuf.h odb.h list.h \
  oidset.h khash.h oidmap.h string-list.h thread-utils.h commit.h \
  add-interactive.h color.h tree.h blob.h alloc.h gpg-interface.h hex.h \
  hex-ll.h packfile.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
environment.h:
repo-settings.h:
tag.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
object-name.h:
strbuf.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
commit.h:
add-interactive.h:
color.h:
tree.h:
blob.h:
alloc.h:
gpg-interface.h:
hex.h:
hex-ll.h:
packfile.h:
