diffcore-pickaxe.o: diffcore-pickaxe.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h diff.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h pathspec.h strbuf.h \
  diffcore.h xdiff-interface.h xdiff/xdiff.h kwset.h oidset.h khash.h \
  pretty.h date.h string-list.h quote.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
diff.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
pathspec.h:
strbuf.h:
diffcore.h:
xdiff-interface.h:
xdiff/xdiff.h:
kwset.h:
oidset.h:
khash.h:
pretty.h:
date.h:
string-list.h:
quote.h:
