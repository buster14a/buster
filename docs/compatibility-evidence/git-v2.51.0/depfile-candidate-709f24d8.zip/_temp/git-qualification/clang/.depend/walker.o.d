walker.o: walker.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h gettext.h \
  hex.h hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h \
  repository.h strmap.h hashmap.h repo-settings.h hex-ll.h walker.h \
  remote.h refspec.h string-list.h strvec.h odb.h object.h list.h \
  oidset.h khash.h oidmap.h thread-utils.h commit.h add-interactive.h \
  color.h strbuf.h tree.h tree-walk.h tag.h blob.h refs.h progress.h \
  prio-queue.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
hex.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
hex-ll.h:
walker.h:
remote.h:
refspec.h:
string-list.h:
strvec.h:
odb.h:
object.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
commit.h:
add-interactive.h:
color.h:
strbuf.h:
tree.h:
tree-walk.h:
tag.h:
blob.h:
refs.h:
progress.h:
prio-queue.h:
