statinfo.o: statinfo.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h environment.h \
  repo-settings.h statinfo.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
environment.h:
repo-settings.h:
statinfo.h:
