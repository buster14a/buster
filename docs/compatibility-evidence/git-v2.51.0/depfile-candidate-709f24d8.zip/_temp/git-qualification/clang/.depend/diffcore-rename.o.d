diffcore-rename.o: diffcore-rename.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h diff.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h repository.h strmap.h \
  hashmap.h repo-settings.h pathspec.h strbuf.h diffcore.h object-file.h \
  git-zlib.h compat/zlib-compat.h object.h odb.h list.h oidset.h khash.h \
  oidmap.h string-list.h thread-utils.h mem-pool.h oid-array.h \
  progress.h gettext.h promisor-remote.h trace2.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
diff.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
pathspec.h:
strbuf.h:
diffcore.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
object.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
mem-pool.h:
oid-array.h:
progress.h:
gettext.h:
promisor-remote.h:
trace2.h:
