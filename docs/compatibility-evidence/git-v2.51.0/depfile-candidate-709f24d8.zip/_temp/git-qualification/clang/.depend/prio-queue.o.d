prio-queue.o: prio-queue.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h prio-queue.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
prio-queue.h:
