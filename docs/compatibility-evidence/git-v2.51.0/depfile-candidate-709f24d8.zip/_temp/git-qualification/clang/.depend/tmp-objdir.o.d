tmp-objdir.o: tmp-objdir.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h tmp-objdir.h \
  abspath.h chdir-notify.h dir.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h hashmap.h pathspec.h statinfo.h strbuf.h \
  environment.h repo-settings.h object-file.h git-zlib.h \
  compat/zlib-compat.h object.h odb.h list.h oidset.h khash.h oidmap.h \
  string-list.h thread-utils.h repository.h strmap.h path.h strvec.h \
  quote.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
tmp-objdir.h:
abspath.h:
chdir-notify.h:
dir.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
hashmap.h:
pathspec.h:
statinfo.h:
strbuf.h:
environment.h:
repo-settings.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
object.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
repository.h:
strmap.h:
path.h:
strvec.h:
quote.h:
