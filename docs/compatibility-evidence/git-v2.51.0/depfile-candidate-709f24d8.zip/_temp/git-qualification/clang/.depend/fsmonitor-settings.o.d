fsmonitor-settings.o: fsmonitor-settings.c git-compat-util.h \
  compat/posix.h compat/../sane-ctype.h compat/bswap.h wrapper.h \
  banned.h config.h hashmap.h string-list.h repository.h strmap.h \
  repo-settings.h parse.h gettext.h fsmonitor-ipc.h simple-ipc.h \
  pkt-line.h strbuf.h fsmonitor-settings.h fsmonitor-path-utils.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
gettext.h:
fsmonitor-ipc.h:
simple-ipc.h:
pkt-line.h:
strbuf.h:
fsmonitor-settings.h:
fsmonitor-path-utils.h:
