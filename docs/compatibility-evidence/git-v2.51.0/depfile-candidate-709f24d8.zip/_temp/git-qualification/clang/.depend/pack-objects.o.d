pack-objects.o: pack-objects.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h object.h \
  hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h pack.h \
  csum-file.h write-or-die.h pack-objects.h odb.h hashmap.h list.h \
  oidset.h khash.h oidmap.h string-list.h thread-utils.h repository.h \
  strmap.h repo-settings.h packfile.h parse.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
pack.h:
csum-file.h:
write-or-die.h:
pack-objects.h:
odb.h:
hashmap.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
repository.h:
strmap.h:
repo-settings.h:
packfile.h:
parse.h:
