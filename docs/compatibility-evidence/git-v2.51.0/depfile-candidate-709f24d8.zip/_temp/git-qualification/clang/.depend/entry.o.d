entry.o: entry.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h odb.h hashmap.h object.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h repository.h strmap.h \
  repo-settings.h list.h oidset.h khash.h oidmap.h string-list.h \
  thread-utils.h dir.h pathspec.h statinfo.h strbuf.h environment.h \
  gettext.h hex.h hex-ll.h name-hash.h sparse-index.h streaming.h \
  submodule.h symlinks.h progress.h fsmonitor.h fsmonitor-ll.h \
  fsmonitor-settings.h read-cache-ll.h trace.h entry.h convert.h \
  parallel-checkout.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
odb.h:
hashmap.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
repo-settings.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
dir.h:
pathspec.h:
statinfo.h:
strbuf.h:
environment.h:
gettext.h:
hex.h:
hex-ll.h:
name-hash.h:
sparse-index.h:
streaming.h:
submodule.h:
symlinks.h:
progress.h:
fsmonitor.h:
fsmonitor-ll.h:
fsmonitor-settings.h:
read-cache-ll.h:
trace.h:
entry.h:
convert.h:
parallel-checkout.h:
