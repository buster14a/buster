mailmap.o: mailmap.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h environment.h \
  repo-settings.h string-list.h mailmap.h object-name.h object.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h repository.h strmap.h \
  hashmap.h strbuf.h odb.h list.h oidset.h khash.h oidmap.h \
  thread-utils.h setup.h refs.h commit.h add-interactive.h color.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
environment.h:
repo-settings.h:
string-list.h:
mailmap.h:
object-name.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
strbuf.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
setup.h:
refs.h:
commit.h:
add-interactive.h:
color.h:
