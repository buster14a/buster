read-cache.o: read-cache.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h \
  bulk-checkin.h object.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h repository.h strmap.h hashmap.h repo-settings.h \
  config.h string-list.h parse.h date.h diff.h pathspec.h strbuf.h \
  diffcore.h hex.h hex-ll.h tempfile.h list.h lockfile.h cache-tree.h \
  tree.h tree-walk.h refs.h commit.h add-interactive.h color.h dir.h \
  statinfo.h object-file.h git-zlib.h compat/zlib-compat.h odb.h \
  oidset.h khash.h oidmap.h thread-utils.h oid-array.h environment.h \
  gettext.h mem-pool.h name-hash.h object-name.h path.h preload-index.h \
  read-cache.h read-cache-ll.h resolve-undo.h revision.h grep.h \
  userdiff.h notes-cache.h notes.h pretty.h commit-slab-decl.h \
  decorate.h ident.h list-objects-filter-options.h strvec.h trace2.h \
  varint.h split-index.h symlinks.h utf8.h fsmonitor.h fsmonitor-ll.h \
  fsmonitor-settings.h trace.h progress.h sparse-index.h csum-file.h \
  write-or-die.h promisor-remote.h hook.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
bulk-checkin.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
config.h:
string-list.h:
parse.h:
date.h:
diff.h:
pathspec.h:
strbuf.h:
diffcore.h:
hex.h:
hex-ll.h:
tempfile.h:
list.h:
lockfile.h:
cache-tree.h:
tree.h:
tree-walk.h:
refs.h:
commit.h:
add-interactive.h:
color.h:
dir.h:
statinfo.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
odb.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
oid-array.h:
environment.h:
gettext.h:
mem-pool.h:
name-hash.h:
object-name.h:
path.h:
preload-index.h:
read-cache.h:
read-cache-ll.h:
resolve-undo.h:
revision.h:
grep.h:
userdiff.h:
notes-cache.h:
notes.h:
pretty.h:
commit-slab-decl.h:
decorate.h:
ident.h:
list-objects-filter-options.h:
strvec.h:
trace2.h:
varint.h:
split-index.h:
symlinks.h:
utf8.h:
fsmonitor.h:
fsmonitor-ll.h:
fsmonitor-settings.h:
trace.h:
progress.h:
sparse-index.h:
csum-file.h:
write-or-die.h:
promisor-remote.h:
hook.h:
