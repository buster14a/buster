diagnose.o: diagnose.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h diagnose.h \
  strbuf.h compat/disk.h abspath.h gettext.h archive.h pathspec.h \
  string-list.h dir.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h hashmap.h statinfo.h help.h hex.h hex-ll.h \
  strvec.h odb.h object.h list.h oidset.h khash.h oidmap.h \
  thread-utils.h repository.h strmap.h repo-settings.h packfile.h \
  parse-options.h write-or-die.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
diagnose.h:
strbuf.h:
compat/disk.h:
abspath.h:
gettext.h:
archive.h:
pathspec.h:
string-list.h:
dir.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
hashmap.h:
statinfo.h:
help.h:
hex.h:
hex-ll.h:
strvec.h:
odb.h:
object.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
repository.h:
strmap.h:
repo-settings.h:
packfile.h:
parse-options.h:
write-or-die.h:
