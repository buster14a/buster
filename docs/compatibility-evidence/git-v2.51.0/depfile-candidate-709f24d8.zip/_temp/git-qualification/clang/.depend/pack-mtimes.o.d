pack-mtimes.o: pack-mtimes.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h gettext.h \
  pack-mtimes.h odb.h hashmap.h object.h hash.h sha1dc_git.h \
  sha1dc/sha1.h sha256/block/sha256.h list.h oidset.h khash.h oidmap.h \
  string-list.h thread-utils.h repository.h strmap.h repo-settings.h \
  packfile.h strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
pack-mtimes.h:
odb.h:
hashmap.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
repository.h:
strmap.h:
repo-settings.h:
packfile.h:
strbuf.h:
