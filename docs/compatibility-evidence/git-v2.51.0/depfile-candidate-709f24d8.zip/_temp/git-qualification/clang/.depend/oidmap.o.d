oidmap.o: oidmap.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h oidmap.h hashmap.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
oidmap.h:
hashmap.h:
