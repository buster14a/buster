config.o: config.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  date.h branch.h config.h hashmap.h string-list.h repository.h strmap.h \
  repo-settings.h parse.h convert.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h environment.h gettext.h git-zlib.h \
  compat/zlib-compat.h lockfile.h tempfile.h list.h strbuf.h exec-cmd.h \
  quote.h object-name.h object.h odb.h oidset.h khash.h oidmap.h \
  thread-utils.h path.h utf8.h color.h refs.h commit.h add-interactive.h \
  setup.h strvec.h trace2.h wildmatch.h write-or-die.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
date.h:
branch.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
convert.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
environment.h:
gettext.h:
git-zlib.h:
compat/zlib-compat.h:
lockfile.h:
tempfile.h:
list.h:
strbuf.h:
exec-cmd.h:
quote.h:
object-name.h:
object.h:
odb.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
path.h:
utf8.h:
color.h:
refs.h:
commit.h:
add-interactive.h:
setup.h:
strvec.h:
trace2.h:
wildmatch.h:
write-or-die.h:
