archive-tar.o: archive-tar.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h config.h \
  hashmap.h string-list.h repository.h strmap.h repo-settings.h parse.h \
  gettext.h git-zlib.h compat/zlib-compat.h hex.h hash.h sha1dc_git.h \
  sha1dc/sha1.h sha256/block/sha256.h hex-ll.h tar.h archive.h \
  pathspec.h odb.h object.h list.h oidset.h khash.h oidmap.h \
  thread-utils.h strbuf.h streaming.h run-command.h strvec.h \
  write-or-die.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
gettext.h:
git-zlib.h:
compat/zlib-compat.h:
hex.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
hex-ll.h:
tar.h:
archive.h:
pathspec.h:
odb.h:
object.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
strbuf.h:
streaming.h:
run-command.h:
strvec.h:
write-or-die.h:
