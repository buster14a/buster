help.o: help.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h git-zlib.h compat/zlib-compat.h \
  config.h hashmap.h string-list.h repository.h strmap.h repo-settings.h \
  parse.h builtin.h exec-cmd.h run-command.h thread-utils.h strvec.h \
  levenshtein.h gettext.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h help.h strbuf.h command-list.h column.h \
  version.h refs.h commit.h object.h add-interactive.h color.h \
  parse-options.h prompt.h fsmonitor-ipc.h simple-ipc.h pkt-line.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
git-zlib.h:
compat/zlib-compat.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
builtin.h:
exec-cmd.h:
run-command.h:
thread-utils.h:
strvec.h:
levenshtein.h:
gettext.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
help.h:
strbuf.h:
command-list.h:
column.h:
version.h:
refs.h:
commit.h:
object.h:
add-interactive.h:
color.h:
parse-options.h:
prompt.h:
fsmonitor-ipc.h:
simple-ipc.h:
pkt-line.h:
