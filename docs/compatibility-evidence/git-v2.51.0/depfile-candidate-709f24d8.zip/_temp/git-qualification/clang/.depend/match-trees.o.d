match-trees.o: match-trees.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h hex.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h hex-ll.h \
  match-trees.h strbuf.h tree.h object.h tree-walk.h object-file.h \
  git-zlib.h compat/zlib-compat.h odb.h hashmap.h list.h oidset.h \
  khash.h oidmap.h string-list.h thread-utils.h repository.h strmap.h \
  repo-settings.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
hex.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
hex-ll.h:
match-trees.h:
strbuf.h:
tree.h:
object.h:
tree-walk.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
odb.h:
hashmap.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
repository.h:
strmap.h:
repo-settings.h:
