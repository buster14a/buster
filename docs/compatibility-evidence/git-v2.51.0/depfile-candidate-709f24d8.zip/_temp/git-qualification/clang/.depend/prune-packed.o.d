prune-packed.o: prune-packed.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h gettext.h \
  object-file.h git-zlib.h compat/zlib-compat.h object.h hash.h \
  sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h repository.h strmap.h \
  hashmap.h repo-settings.h odb.h list.h oidset.h khash.h oidmap.h \
  string-list.h thread-utils.h packfile.h progress.h prune-packed.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
packfile.h:
progress.h:
prune-packed.h:
