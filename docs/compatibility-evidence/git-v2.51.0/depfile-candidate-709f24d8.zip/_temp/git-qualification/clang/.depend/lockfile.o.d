lockfile.o: lockfile.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  gettext.h lockfile.h tempfile.h list.h strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
gettext.h:
lockfile.h:
tempfile.h:
list.h:
strbuf.h:
