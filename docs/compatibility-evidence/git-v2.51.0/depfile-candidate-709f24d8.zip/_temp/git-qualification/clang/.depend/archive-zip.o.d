archive-zip.o: archive-zip.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h config.h \
  hashmap.h string-list.h repository.h strmap.h repo-settings.h parse.h \
  archive.h pathspec.h gettext.h git-zlib.h compat/zlib-compat.h hex.h \
  hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h hex-ll.h \
  streaming.h object.h utf8.h odb.h list.h oidset.h khash.h oidmap.h \
  thread-utils.h strbuf.h userdiff.h notes-cache.h notes.h \
  write-or-die.h xdiff-interface.h xdiff/xdiff.h date.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
archive.h:
pathspec.h:
gettext.h:
git-zlib.h:
compat/zlib-compat.h:
hex.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
hex-ll.h:
streaming.h:
object.h:
utf8.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
strbuf.h:
userdiff.h:
notes-cache.h:
notes.h:
write-or-die.h:
xdiff-interface.h:
xdiff/xdiff.h:
date.h:
