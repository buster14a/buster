urlmatch.o: urlmatch.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h gettext.h \
  hex-ll.h strbuf.h urlmatch.h string-list.h config.h hashmap.h \
  repository.h strmap.h repo-settings.h parse.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
hex-ll.h:
strbuf.h:
urlmatch.h:
string-list.h:
config.h:
hashmap.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
