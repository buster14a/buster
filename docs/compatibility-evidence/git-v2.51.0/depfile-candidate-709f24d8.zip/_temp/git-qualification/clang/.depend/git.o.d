git.o: git.c builtin.h git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h repository.h \
  strmap.h hashmap.h repo-settings.h config.h string-list.h parse.h \
  environment.h exec-cmd.h gettext.h help.h strbuf.h object-file.h \
  git-zlib.h compat/zlib-compat.h object.h hash.h sha1dc_git.h \
  sha1dc/sha1.h sha256/block/sha256.h odb.h list.h oidset.h khash.h \
  oidmap.h thread-utils.h pager.h read-cache-ll.h statinfo.h \
  run-command.h strvec.h alias.h replace-object.h setup.h refs.h \
  commit.h add-interactive.h color.h attr.h shallow.h lockfile.h \
  tempfile.h trace.h trace2.h
builtin.h:
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
config.h:
string-list.h:
parse.h:
environment.h:
exec-cmd.h:
gettext.h:
help.h:
strbuf.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
pager.h:
read-cache-ll.h:
statinfo.h:
run-command.h:
strvec.h:
alias.h:
replace-object.h:
setup.h:
refs.h:
commit.h:
add-interactive.h:
color.h:
attr.h:
shallow.h:
lockfile.h:
tempfile.h:
trace.h:
trace2.h:
