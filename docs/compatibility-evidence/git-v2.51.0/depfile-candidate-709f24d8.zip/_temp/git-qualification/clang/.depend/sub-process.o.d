sub-process.o: sub-process.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h sub-process.h \
  hashmap.h run-command.h thread-utils.h strvec.h sigchain.h pkt-line.h \
  strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
sub-process.h:
hashmap.h:
run-command.h:
thread-utils.h:
strvec.h:
sigchain.h:
pkt-line.h:
strbuf.h:
