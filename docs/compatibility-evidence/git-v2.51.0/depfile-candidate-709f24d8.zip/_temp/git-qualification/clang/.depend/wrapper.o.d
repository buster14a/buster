wrapper.o: wrapper.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  parse.h gettext.h strbuf.h trace2.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
parse.h:
gettext.h:
strbuf.h:
trace2.h:
