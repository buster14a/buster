parse-options.o: parse-options.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h \
  parse-options.h gettext.h abspath.h parse.h strbuf.h string-list.h \
  utf8.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
parse-options.h:
gettext.h:
abspath.h:
parse.h:
strbuf.h:
string-list.h:
utf8.h:
