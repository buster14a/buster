tree.o: tree.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h hex.h hash.h sha1dc_git.h \
  sha1dc/sha1.h sha256/block/sha256.h repository.h strmap.h hashmap.h \
  repo-settings.h hex-ll.h tree.h object.h object-name.h strbuf.h odb.h \
  list.h oidset.h khash.h oidmap.h string-list.h thread-utils.h commit.h \
  add-interactive.h color.h alloc.h tree-walk.h environment.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
hex.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
hex-ll.h:
tree.h:
object.h:
object-name.h:
strbuf.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
commit.h:
add-interactive.h:
color.h:
alloc.h:
tree-walk.h:
environment.h:
