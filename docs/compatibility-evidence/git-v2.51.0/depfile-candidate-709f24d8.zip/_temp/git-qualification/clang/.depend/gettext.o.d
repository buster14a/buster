gettext.o: gettext.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  environment.h repo-settings.h exec-cmd.h gettext.h utf8.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
environment.h:
repo-settings.h:
exec-cmd.h:
gettext.h:
utf8.h:
