date.o: date.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h date.h gettext.h pager.h strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
date.h:
gettext.h:
pager.h:
strbuf.h:
