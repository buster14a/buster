hook.o: hook.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h abspath.h advice.h gettext.h hook.h \
  strvec.h path.h run-command.h thread-utils.h config.h hashmap.h \
  string-list.h repository.h strmap.h repo-settings.h parse.h strbuf.h \
  environment.h setup.h refs.h commit.h object.h hash.h sha1dc_git.h \
  sha1dc/sha1.h sha256/block/sha256.h add-interactive.h color.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
advice.h:
gettext.h:
hook.h:
strvec.h:
path.h:
run-command.h:
thread-utils.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
strbuf.h:
environment.h:
setup.h:
refs.h:
commit.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
add-interactive.h:
color.h:
