color.o: color.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h config.h hashmap.h string-list.h \
  repository.h strmap.h repo-settings.h parse.h color.h editor.h \
  gettext.h hex-ll.h pager.h strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
color.h:
editor.h:
gettext.h:
hex-ll.h:
pager.h:
strbuf.h:
