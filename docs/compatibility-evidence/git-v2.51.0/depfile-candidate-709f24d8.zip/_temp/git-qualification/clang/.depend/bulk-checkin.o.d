bulk-checkin.o: bulk-checkin.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h \
  bulk-checkin.h object.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h repository.h strmap.h hashmap.h repo-settings.h \
  environment.h gettext.h hex.h hex-ll.h lockfile.h tempfile.h list.h \
  strbuf.h csum-file.h write-or-die.h pack.h tmp-objdir.h packfile.h \
  odb.h oidset.h khash.h oidmap.h string-list.h thread-utils.h \
  object-file.h git-zlib.h compat/zlib-compat.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
bulk-checkin.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
environment.h:
gettext.h:
hex.h:
hex-ll.h:
lockfile.h:
tempfile.h:
list.h:
strbuf.h:
csum-file.h:
write-or-die.h:
pack.h:
tmp-objdir.h:
packfile.h:
odb.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
