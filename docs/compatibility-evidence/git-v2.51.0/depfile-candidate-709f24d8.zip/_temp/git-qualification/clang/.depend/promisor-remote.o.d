promisor-remote.o: promisor-remote.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h gettext.h \
  hex.h hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h \
  repository.h strmap.h hashmap.h repo-settings.h hex-ll.h odb.h \
  object.h list.h oidset.h khash.h oidmap.h string-list.h thread-utils.h \
  promisor-remote.h config.h parse.h trace2.h transport.h run-command.h \
  strvec.h remote.h refspec.h list-objects-filter-options.h strbuf.h \
  packfile.h environment.h url.h version.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
hex.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
hex-ll.h:
odb.h:
object.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
string-list.h:
thread-utils.h:
promisor-remote.h:
config.h:
parse.h:
trace2.h:
transport.h:
run-command.h:
strvec.h:
remote.h:
refspec.h:
list-objects-filter-options.h:
strbuf.h:
packfile.h:
environment.h:
url.h:
version.h:
