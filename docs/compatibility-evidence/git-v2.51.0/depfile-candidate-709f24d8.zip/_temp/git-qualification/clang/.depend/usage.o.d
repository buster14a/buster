usage.o: usage.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h gettext.h trace2.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
trace2.h:
