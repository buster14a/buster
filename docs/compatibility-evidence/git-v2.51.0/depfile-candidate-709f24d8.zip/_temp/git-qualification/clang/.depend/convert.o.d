convert.o: convert.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h advice.h \
  config.h hashmap.h string-list.h repository.h strmap.h repo-settings.h \
  parse.h convert.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h copy.h gettext.h hex.h hex-ll.h object-file.h \
  git-zlib.h compat/zlib-compat.h object.h odb.h list.h oidset.h khash.h \
  oidmap.h thread-utils.h attr.h run-command.h strvec.h quote.h \
  read-cache-ll.h statinfo.h sigchain.h pkt-line.h strbuf.h \
  sub-process.h trace.h utf8.h merge-ll.h xdiff/xdiff.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
advice.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
convert.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
copy.h:
gettext.h:
hex.h:
hex-ll.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
object.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
attr.h:
run-command.h:
strvec.h:
quote.h:
read-cache-ll.h:
statinfo.h:
sigchain.h:
pkt-line.h:
strbuf.h:
sub-process.h:
trace.h:
utf8.h:
merge-ll.h:
xdiff/xdiff.h:
