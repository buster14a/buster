ident.o: ident.c git-compat-util.h compat/posix.h compat/../sane-ctype.h \
  compat/bswap.h wrapper.h banned.h ident.h string-list.h config.h \
  hashmap.h repository.h strmap.h repo-settings.h parse.h date.h \
  gettext.h mailmap.h strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
ident.h:
string-list.h:
config.h:
hashmap.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
date.h:
gettext.h:
mailmap.h:
strbuf.h:
