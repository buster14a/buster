archive.o: archive.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h abspath.h \
  config.h hashmap.h string-list.h repository.h strmap.h repo-settings.h \
  parse.h convert.h hash.h sha1dc_git.h sha1dc/sha1.h \
  sha256/block/sha256.h environment.h gettext.h git-zlib.h \
  compat/zlib-compat.h hex.h hex-ll.h object-name.h object.h strbuf.h \
  path.h pretty.h date.h setup.h refs.h commit.h add-interactive.h \
  color.h odb.h list.h oidset.h khash.h oidmap.h thread-utils.h tree.h \
  tree-walk.h attr.h archive.h pathspec.h parse-options.h unpack-trees.h \
  read-cache-ll.h statinfo.h strvec.h quote.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
abspath.h:
config.h:
hashmap.h:
string-list.h:
repository.h:
strmap.h:
repo-settings.h:
parse.h:
convert.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
environment.h:
gettext.h:
git-zlib.h:
compat/zlib-compat.h:
hex.h:
hex-ll.h:
object-name.h:
object.h:
strbuf.h:
path.h:
pretty.h:
date.h:
setup.h:
refs.h:
commit.h:
add-interactive.h:
color.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
tree.h:
tree-walk.h:
attr.h:
archive.h:
pathspec.h:
parse-options.h:
unpack-trees.h:
read-cache-ll.h:
statinfo.h:
strvec.h:
quote.h:
