notes-cache.o: notes-cache.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h notes-cache.h \
  notes.h string-list.h object-file.h git-zlib.h compat/zlib-compat.h \
  object.h hash.h sha1dc_git.h sha1dc/sha1.h sha256/block/sha256.h \
  repository.h strmap.h hashmap.h repo-settings.h odb.h list.h oidset.h \
  khash.h oidmap.h thread-utils.h pretty.h date.h commit.h \
  add-interactive.h color.h refs.h strbuf.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
notes-cache.h:
notes.h:
string-list.h:
object-file.h:
git-zlib.h:
compat/zlib-compat.h:
object.h:
hash.h:
sha1dc_git.h:
sha1dc/sha1.h:
sha256/block/sha256.h:
repository.h:
strmap.h:
hashmap.h:
repo-settings.h:
odb.h:
list.h:
oidset.h:
khash.h:
oidmap.h:
thread-utils.h:
pretty.h:
date.h:
commit.h:
add-interactive.h:
color.h:
refs.h:
strbuf.h:
