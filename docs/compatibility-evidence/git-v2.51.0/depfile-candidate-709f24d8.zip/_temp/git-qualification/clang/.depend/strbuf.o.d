strbuf.o: strbuf.c git-compat-util.h compat/posix.h \
  compat/../sane-ctype.h compat/bswap.h wrapper.h banned.h gettext.h \
  hex-ll.h strbuf.h string-list.h utf8.h date.h
git-compat-util.h:
compat/posix.h:
compat/../sane-ctype.h:
compat/bswap.h:
wrapper.h:
banned.h:
gettext.h:
hex-ll.h:
strbuf.h:
string-list.h:
utf8.h:
date.h:
